python
import sys
sys.path.insert(0, '/work/tools')
import gdb_trace
gdb_trace.main('/work/experiments/runs/runtime-validation-20261109-O2/planned-42/3.json')
end
