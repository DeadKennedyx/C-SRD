#include <stdint.h>
/* Population count of the low byte; higher input bits are irrelevant. */
uint32_t popcount8(uint32_t x) { unsigned int csrd_value_0 = ((x) & (255u)); unsigned int csrd_value_1 = ((csrd_value_0) >> (1u)); unsigned int csrd_value_2 = ((csrd_value_1) & (85u)); unsigned int csrd_value_3 = ((3505419713u * (csrd_value_0)) + 645999226u); unsigned int csrd_value_4 = ((3505419713u * (csrd_value_2)) + 645999226u); unsigned int csrd_value_5 = (((csrd_value_3) - (csrd_value_4)) + 645999226u); unsigned int csrd_value_6 = (723294785u * ((csrd_value_5) - 645999226u)); unsigned int csrd_value_7 = ((csrd_value_6) & (51u)); unsigned int csrd_value_8 = ((csrd_value_6) >> (2u)); unsigned int csrd_value_9 = ((csrd_value_8) & (51u)); unsigned int csrd_value_10 = ((3505419713u * (csrd_value_7)) + 645999226u); unsigned int csrd_value_11 = ((3505419713u * (csrd_value_9)) + 645999226u); unsigned int csrd_value_12 = (((csrd_value_10) + (csrd_value_11)) - 645999226u); unsigned int csrd_value_13 = (723294785u * ((csrd_value_12) - 645999226u)); unsigned int csrd_value_14 = ((csrd_value_13) >> (4u)); unsigned int csrd_value_15 = ((3505419713u * (csrd_value_14)) + 645999226u); unsigned int csrd_value_16 = (((csrd_value_12) + (csrd_value_15)) - 645999226u); unsigned int csrd_value_17 = (723294785u * ((csrd_value_16) - 645999226u)); unsigned int csrd_value_18 = ((csrd_value_17) & (15u)); return csrd_value_18;







}
