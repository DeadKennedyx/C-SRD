#include <stdint.h>
/* Population count of the low byte; higher input bits are irrelevant. */
uint32_t popcount8(uint32_t x) { unsigned int csrd_value_0 = ((x) ^ 1963201069u); unsigned int csrd_value_1 = (((csrd_value_0) & (1963201234u)) ^ (((csrd_value_0) ^ (1963201234u)) & 1963201069u)); unsigned int csrd_value_2 = (((csrd_value_1) >> 1u) ^ 1334188859u); unsigned int csrd_value_3 = (((csrd_value_2) & (1963201144u)) ^ (((csrd_value_2) ^ (1963201144u)) & 1963201069u)); unsigned int csrd_value_4 = ((csrd_value_1) ^ 1963201069u); unsigned int csrd_value_5 = ((csrd_value_3) ^ 1963201069u); unsigned int csrd_value_6 = ((csrd_value_4) - (csrd_value_5)); unsigned int csrd_value_7 = ((csrd_value_6) ^ 1963201069u); unsigned int csrd_value_8 = (((csrd_value_7) & (1963201054u)) ^ (((csrd_value_7) ^ (1963201054u)) & 1963201069u)); unsigned int csrd_value_9 = (((csrd_value_7) >> 2u) ^ 1749358246u); unsigned int csrd_value_10 = (((csrd_value_9) & (1963201054u)) ^ (((csrd_value_9) ^ (1963201054u)) & 1963201069u)); unsigned int csrd_value_11 = ((csrd_value_8) ^ 1963201069u); unsigned int csrd_value_12 = ((csrd_value_10) ^ 1963201069u); unsigned int csrd_value_13 = ((csrd_value_11) + (csrd_value_12)); unsigned int csrd_value_14 = ((csrd_value_13) >> (4u)); unsigned int csrd_value_15 = ((csrd_value_13) + (csrd_value_14)); unsigned int csrd_value_16 = ((csrd_value_15) & (15u)); return csrd_value_16;







}
