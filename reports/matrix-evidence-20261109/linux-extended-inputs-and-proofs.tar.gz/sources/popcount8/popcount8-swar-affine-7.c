#include <stdint.h>
/* Population count of the low byte; higher input bits are irrelevant. */
uint32_t popcount8(uint32_t x) { unsigned int csrd_value_0 = ((x) & (255u)); unsigned int csrd_value_1 = ((csrd_value_0) >> (1u)); unsigned int csrd_value_2 = ((csrd_value_1) & (85u)); unsigned int csrd_value_3 = ((2609647505u * (csrd_value_0)) + 4001897916u); unsigned int csrd_value_4 = ((2609647505u * (csrd_value_2)) + 4001897916u); unsigned int csrd_value_5 = (((csrd_value_3) - (csrd_value_4)) + 4001897916u); unsigned int csrd_value_6 = (647795057u * ((csrd_value_5) - 4001897916u)); unsigned int csrd_value_7 = ((csrd_value_6) & (51u)); unsigned int csrd_value_8 = ((csrd_value_6) >> (2u)); unsigned int csrd_value_9 = ((csrd_value_8) & (51u)); unsigned int csrd_value_10 = ((2609647505u * (csrd_value_7)) + 4001897916u); unsigned int csrd_value_11 = ((2609647505u * (csrd_value_9)) + 4001897916u); unsigned int csrd_value_12 = (((csrd_value_10) + (csrd_value_11)) - 4001897916u); unsigned int csrd_value_13 = (647795057u * ((csrd_value_12) - 4001897916u)); unsigned int csrd_value_14 = ((csrd_value_13) >> (4u)); unsigned int csrd_value_15 = ((2609647505u * (csrd_value_14)) + 4001897916u); unsigned int csrd_value_16 = (((csrd_value_12) + (csrd_value_15)) - 4001897916u); unsigned int csrd_value_17 = (647795057u * ((csrd_value_16) - 4001897916u)); unsigned int csrd_value_18 = ((csrd_value_17) & (15u)); return csrd_value_18;







}
