#include <stdint.h>
/* Intentional negative control: agrees with linear except at one input pair. */
uint32_t kernel(uint32_t x, uint32_t y) { unsigned int csrd_value_0 = ((2010586713u * (x)) + 278101063u); unsigned int csrd_value_1 = ((2010586713u * (y)) + 278101063u); unsigned int csrd_value_2 = (((csrd_value_0) + (csrd_value_1)) - 278101063u); unsigned int csrd_value_3 = ((3u * (csrd_value_2)) + 3738765170u); unsigned int csrd_value_4 = (((csrd_value_3) + (919718426u)) - 278101063u); unsigned int csrd_value_5 = (x == 1129534020u); unsigned int csrd_value_6 = (y == 0u); unsigned int csrd_value_7 = (((csrd_value_4) + (2288687776u)) - 278101063u); unsigned int csrd_value_8 = ((csrd_value_6) ? (csrd_value_7) : (csrd_value_4)); unsigned int csrd_value_9 = ((csrd_value_5) ? (csrd_value_8) : (csrd_value_4)); unsigned int csrd_value_10 = (2621327849u * ((csrd_value_9) - 278101063u)); return csrd_value_10;



}
