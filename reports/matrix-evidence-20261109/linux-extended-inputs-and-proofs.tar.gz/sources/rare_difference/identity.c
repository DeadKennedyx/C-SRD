#include <stdint.h>
/* Intentional negative control: agrees with linear except at one input pair. */
uint32_t kernel(uint32_t x, uint32_t y) { unsigned int csrd_value_0 = ((x) + (y)); unsigned int csrd_value_1 = (3u * (csrd_value_0)); unsigned int csrd_value_2 = ((csrd_value_1) + (11u)); unsigned int csrd_value_3 = (x == 1129534020u); unsigned int csrd_value_4 = (y == 0u); unsigned int csrd_value_5 = ((csrd_value_2) + (1u)); unsigned int csrd_value_6 = ((csrd_value_4) ? (csrd_value_5) : (csrd_value_2)); unsigned int csrd_value_7 = ((csrd_value_3) ? (csrd_value_6) : (csrd_value_2)); return csrd_value_7;



}
