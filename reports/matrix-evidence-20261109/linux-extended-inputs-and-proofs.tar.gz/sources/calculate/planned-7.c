#include <stdint.h>

uint32_t calculate(uint32_t x, uint32_t y)
{ unsigned int csrd_value_0 = ((x) + (y)); unsigned int csrd_value_1 = ((2284942353u * (csrd_value_0)) + 1046485312u); unsigned int csrd_value_2 = ((3u * (csrd_value_1)) + 2201996672u); unsigned int csrd_value_3 = (((csrd_value_2) + (411047419u)) - 1046485312u); unsigned int csrd_value_4 = (3575774449u * ((csrd_value_3) - 1046485312u)); return csrd_value_4;


}
