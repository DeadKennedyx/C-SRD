#include <stdint.h>

uint32_t calculate(uint32_t x, uint32_t y)
{ unsigned int csrd_value_0 = ((x) + (y)); unsigned int csrd_value_1 = ((1789947473u * (csrd_value_0)) + 1549411197u); unsigned int csrd_value_2 = ((3u * (csrd_value_1)) + 1196144902u); unsigned int csrd_value_3 = (((csrd_value_2) + (4058964216u)) - 1549411197u); unsigned int csrd_value_4 = (846699185u * ((csrd_value_3) - 1549411197u)); return csrd_value_4;


}
