#include <stdint.h>

uint32_t calculate(uint32_t x, uint32_t y)
{ unsigned int csrd_value_0 = ((2284942353u * (x)) + 1046485312u); unsigned int csrd_value_1 = ((2284942353u * (y)) + 1046485312u); unsigned int csrd_value_2 = (((csrd_value_0) + (csrd_value_1)) - 1046485312u); unsigned int csrd_value_3 = ((3u * (csrd_value_2)) + 2201996672u); unsigned int csrd_value_4 = (((csrd_value_3) + (411047419u)) - 1046485312u); unsigned int csrd_value_5 = (3575774449u * ((csrd_value_4) - 1046485312u)); return csrd_value_5;


}
