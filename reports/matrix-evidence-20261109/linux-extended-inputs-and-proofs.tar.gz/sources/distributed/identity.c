#include <stdint.h>
uint32_t kernel(uint32_t x, uint32_t y) { unsigned int csrd_value_0 = (3u * (x)); unsigned int csrd_value_1 = (3u * (y)); unsigned int csrd_value_2 = ((csrd_value_0) + (csrd_value_1)); unsigned int csrd_value_3 = ((csrd_value_2) + (11u)); return csrd_value_3;}
