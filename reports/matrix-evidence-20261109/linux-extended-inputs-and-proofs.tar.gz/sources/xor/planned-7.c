#include <stdint.h>
uint32_t kernel(uint32_t x, uint32_t y) { unsigned int csrd_value_0 = ((x) ^ 2111446532u); unsigned int csrd_value_1 = ((y) ^ 2111446532u); unsigned int csrd_value_2 = (((csrd_value_0) ^ (csrd_value_1)) ^ 2111446532u); unsigned int csrd_value_3 = ((csrd_value_2) ^ 2111446532u); return csrd_value_3;}
