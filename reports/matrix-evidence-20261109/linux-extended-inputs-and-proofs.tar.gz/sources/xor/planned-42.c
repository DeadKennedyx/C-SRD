#include <stdint.h>
uint32_t kernel(uint32_t x, uint32_t y) { unsigned int csrd_value_0 = ((x) ^ 1732534814u); unsigned int csrd_value_1 = ((y) ^ 1732534814u); unsigned int csrd_value_2 = (((csrd_value_0) ^ (csrd_value_1)) ^ 1732534814u); unsigned int csrd_value_3 = ((csrd_value_2) ^ 1732534814u); return csrd_value_3;}
