#include <stdint.h>
uint32_t kernel(uint32_t x, uint32_t y) { unsigned int csrd_value_0 = (y < x); unsigned int csrd_value_1 = ((1823414877u * (y)) + 292881497u); unsigned int csrd_value_2 = ((1823414877u * (x)) + 292881497u); unsigned int csrd_value_3 = ((csrd_value_0) ? (csrd_value_1) : (csrd_value_2)); unsigned int csrd_value_4 = (261130741u * ((csrd_value_3) - 292881497u)); return csrd_value_4;



}
