#include <stdint.h>
uint32_t kernel(uint32_t x, uint32_t y) { unsigned int csrd_value_0 = (y < x); unsigned int csrd_value_1 = ((2010586713u * (y)) + 278101063u); unsigned int csrd_value_2 = ((2010586713u * (x)) + 278101063u); unsigned int csrd_value_3 = ((csrd_value_0) ? (csrd_value_1) : (csrd_value_2)); unsigned int csrd_value_4 = (2621327849u * ((csrd_value_3) - 278101063u)); return csrd_value_4;



}
