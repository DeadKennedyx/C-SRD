#include <stdint.h>
uint32_t kernel(uint32_t x, uint32_t y) {
    unsigned int csrd_value_0 = (y < x);
    unsigned int csrd_value_1 = ((csrd_value_0) ? (y) : (x));
    return csrd_value_1;
}
