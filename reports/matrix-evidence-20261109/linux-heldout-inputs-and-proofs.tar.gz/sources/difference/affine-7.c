#include <stdint.h>
uint32_t kernel(uint32_t x, uint32_t y) { unsigned int csrd_value_0 = ((1823414877u * (x)) + 292881497u); unsigned int csrd_value_1 = ((1823414877u * (y)) + 292881497u); unsigned int csrd_value_2 = (((csrd_value_0) - (csrd_value_1)) + 292881497u); unsigned int csrd_value_3 = (261130741u * ((csrd_value_2) - 292881497u)); return csrd_value_3;}
