; 
(set-info :status unknown)
(assert
 (let (($x6 (or false true)))
(and (distinct true $x6) true)))
(check-sat)
