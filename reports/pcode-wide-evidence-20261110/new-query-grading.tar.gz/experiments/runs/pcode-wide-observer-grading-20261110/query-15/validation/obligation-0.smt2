; 
(set-info :status unknown)
(assert
 (let (($x16 (or false true)))
(and (distinct true $x16) true)))
(check-sat)
