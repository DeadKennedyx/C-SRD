; 
(set-info :status unknown)
(declare-fun local_0 () Bool)
(assert
 (let (($x18621 (and true local_0)))
(let (($x18622 (or false $x18621)))
(and (distinct local_0 $x18622) true))))
(check-sat)
