; 
(set-info :status unknown)
(declare-fun local_1 () Bool)
(declare-fun local_0 () Bool)
(assert
 (let (($x29692 (and local_0 local_1)))
(and (distinct $x29692 (or false (and (and true local_0) local_1))) true)))
(check-sat)
