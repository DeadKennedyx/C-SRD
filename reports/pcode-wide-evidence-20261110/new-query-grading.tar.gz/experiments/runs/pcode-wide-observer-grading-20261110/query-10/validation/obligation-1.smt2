; 
(set-info :status unknown)
(declare-fun local_0 () Bool)
(assert
 (let (($x18516 (not local_0)))
(and (distinct $x18516 (or false (and true $x18516))) true)))
(check-sat)
