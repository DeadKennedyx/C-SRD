; 
(set-info :status unknown)
(declare-fun local_1 () Bool)
(declare-fun local_0 () Bool)
(declare-fun local_2 () Bool)
(assert
 (let (($x18620 (and true local_1)))
(let (($x19217 (or (or (or false (and true local_2)) (and true local_0)) $x18620)))
(and (distinct (or local_2 local_0 local_1) $x19217) true))))
(check-sat)
