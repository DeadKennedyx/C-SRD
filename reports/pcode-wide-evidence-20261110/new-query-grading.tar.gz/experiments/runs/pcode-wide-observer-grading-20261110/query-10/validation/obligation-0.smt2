; 
(set-info :status unknown)
(assert
 (let (($x18476 (or false true)))
(and (distinct true $x18476) true)))
(check-sat)
