; 
(set-info :status unknown)
(declare-fun local_1 () Bool)
(declare-fun local_0 () Bool)
(assert
 (let (($x19142 (or (or false (and (and true (not local_0)) (not local_1))) (and (and true local_0) local_1))))
(let (($x19146 (= local_0 local_1)))
(and (distinct $x19146 $x19142) true))))
(check-sat)
