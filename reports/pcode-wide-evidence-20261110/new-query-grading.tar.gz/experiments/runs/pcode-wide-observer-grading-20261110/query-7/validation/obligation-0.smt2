; 
(set-info :status unknown)
(assert
 (let (($x80 (or false true)))
(and (distinct true $x80) true)))
(check-sat)
