; 
(set-info :status unknown)
(declare-fun local_1 () Bool)
(declare-fun local_0 () Bool)
(assert
 (let (($x18330 (and true local_0)))
(let (($x18491 (and $x18330 local_1)))
(let (($x23572 (or false $x18491)))
(let (($x26308 (and local_0 local_1)))
(and (distinct $x26308 $x23572) true))))))
(check-sat)
