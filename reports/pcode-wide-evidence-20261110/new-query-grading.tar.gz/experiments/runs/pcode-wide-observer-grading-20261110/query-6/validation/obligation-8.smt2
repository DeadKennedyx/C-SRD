; 
(set-info :status unknown)
(declare-fun local_2 () Bool)
(declare-fun local_0 () Bool)
(declare-fun local_1 () Bool)
(assert
 (let (($x18409 (and true local_2)))
(let (($x18330 (and true local_0)))
(let (($x18434 (or (or false (and true local_1)) $x18330)))
(and (distinct (or local_1 local_0 local_2) (or $x18434 $x18409)) true)))))
(check-sat)
