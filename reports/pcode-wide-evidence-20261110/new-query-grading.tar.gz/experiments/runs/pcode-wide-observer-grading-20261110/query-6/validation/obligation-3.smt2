; 
(set-info :status unknown)
(declare-fun local_2 () Bool)
(declare-fun local_1 () Bool)
(declare-fun local_0 () Bool)
(assert
 (let (($x18351 (or (or false (and true local_0)) (and true local_1))))
(and (distinct (or local_0 local_1 local_2) (or $x18351 (and true local_2))) true)))
(check-sat)
