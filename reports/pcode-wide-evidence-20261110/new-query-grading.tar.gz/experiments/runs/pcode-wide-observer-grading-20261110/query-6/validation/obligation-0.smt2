; 
(set-info :status unknown)
(assert
 (let (($x16334 (or false true)))
(and (distinct true $x16334) true)))
(check-sat)
