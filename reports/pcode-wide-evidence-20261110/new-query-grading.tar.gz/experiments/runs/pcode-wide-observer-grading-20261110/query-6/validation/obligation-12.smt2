; 
(set-info :status unknown)
(declare-fun local_0 () Bool)
(assert
 (let (($x18330 (and true local_0)))
(let (($x18350 (or false $x18330)))
(and (distinct local_0 $x18350) true))))
(check-sat)
