; 
(set-info :status unknown)
(declare-fun local_1 () Bool)
(declare-fun local_0 () Bool)
(assert
 (let (($x18494 (or (or false (and (and true (not local_0)) (not local_1))) (and (and true local_0) local_1))))
(let (($x18495 (= local_0 local_1)))
(and (distinct $x18495 $x18494) true))))
(check-sat)
