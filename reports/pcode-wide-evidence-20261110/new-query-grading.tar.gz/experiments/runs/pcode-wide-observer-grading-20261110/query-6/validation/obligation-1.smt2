; 
(set-info :status unknown)
(declare-fun local_0 () Bool)
(assert
 (let (($x18308 (not local_0)))
(and (distinct $x18308 (or false (and true $x18308))) true)))
(check-sat)
