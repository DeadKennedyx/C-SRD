; 
(set-info :status unknown)
(declare-fun local_1 () Bool)
(declare-fun local_0 () Bool)
(assert
 (let (($x6540 (and true local_0)))
(let (($x6163 (and $x6540 local_1)))
(let (($x6164 (or false $x6163)))
(let (($x9292 (and local_0 local_1)))
(and (distinct $x9292 $x6164) true))))))
(check-sat)
