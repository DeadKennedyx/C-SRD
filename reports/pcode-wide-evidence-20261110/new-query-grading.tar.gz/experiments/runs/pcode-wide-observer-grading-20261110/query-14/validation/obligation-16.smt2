; 
(set-info :status unknown)
(declare-fun local_0 () Bool)
(declare-fun local_1 () Bool)
(assert
 (let (($x6462 (and true local_1)))
(let (($x6312 (and $x6462 local_0)))
(let (($x6468 (or false $x6312)))
(let (($x9286 (and local_1 local_0)))
(and (distinct $x9286 $x6468) true))))))
(check-sat)
