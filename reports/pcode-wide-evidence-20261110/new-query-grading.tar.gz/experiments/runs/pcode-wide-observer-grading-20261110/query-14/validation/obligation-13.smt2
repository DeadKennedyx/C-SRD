; 
(set-info :status unknown)
(declare-fun local_0 () Bool)
(declare-fun local_1 () Bool)
(declare-fun local_2 () Bool)
(assert
 (let (($x7121 (or (or false (and (and true local_1) local_2)) (and (and true (not local_1)) local_0))))
(let (($x7122 (ite local_1 local_2 local_0)))
(and (distinct $x7122 $x7121) true))))
(check-sat)
