; 
(set-info :status unknown)
(declare-fun local_0 () Bool)
(declare-fun local_1 () Bool)
(assert
 (let (($x6317 (or (or false (and (and true (not local_1)) (not local_0))) (and (and true local_1) local_0))))
(let (($x6318 (= local_1 local_0)))
(and (distinct $x6318 $x6317) true))))
(check-sat)
