; 
(set-info :status unknown)
(declare-fun local_2 () Bool)
(declare-fun local_0 () Bool)
(declare-fun local_1 () Bool)
(assert
 (let (($x6083 (and true local_2)))
(let (($x6540 (and true local_0)))
(let (($x6346 (or (or false (and true local_1)) $x6540)))
(and (distinct (or local_1 local_0 local_2) (or $x6346 $x6083)) true)))))
(check-sat)
