; 
(set-info :status unknown)
(declare-fun local_1 () Bool)
(declare-fun local_2 () Bool)
(declare-fun local_0 () Bool)
(assert
 (let (($x6138 (or (or false (and (and true local_2) local_0)) (and (and true (not local_2)) local_1))))
(let (($x6274 (ite local_2 local_0 local_1)))
(and (distinct $x6274 $x6138) true))))
(check-sat)
