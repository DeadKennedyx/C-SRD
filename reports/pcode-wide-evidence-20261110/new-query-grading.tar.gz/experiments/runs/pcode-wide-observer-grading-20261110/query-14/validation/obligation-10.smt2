; 
(set-info :status unknown)
(declare-fun local_2 () Bool)
(declare-fun local_1 () Bool)
(declare-fun local_0 () Bool)
(assert
 (let (($x6469 (or (or false (and (and true local_1) local_0)) (and (and true (not local_1)) local_2))))
(let (($x6470 (ite local_1 local_0 local_2)))
(and (distinct $x6470 $x6469) true))))
(check-sat)
