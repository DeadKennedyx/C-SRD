; 
(set-info :status unknown)
(declare-fun local_1 () Bool)
(declare-fun local_0 () Bool)
(assert
 (let (($x6540 (and true local_0)))
(let (($x6163 (and $x6540 local_1)))
(let (($x6331 (or (or false (and (and true (not local_0)) (not local_1))) $x6163)))
(let (($x6332 (= local_0 local_1)))
(and (distinct $x6332 $x6331) true))))))
(check-sat)
