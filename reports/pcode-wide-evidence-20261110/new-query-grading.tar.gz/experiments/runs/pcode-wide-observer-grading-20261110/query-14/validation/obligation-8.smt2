; 
(set-info :status unknown)
(declare-fun local_2 () Bool)
(declare-fun local_1 () Bool)
(declare-fun local_0 () Bool)
(assert
 (let (($x6462 (and true local_1)))
(let (($x6088 (or (or false (and true local_0)) $x6462)))
(let (($x6085 (or local_0 local_1 local_2)))
(and (distinct $x6085 (or $x6088 (and true local_2))) true)))))
(check-sat)
