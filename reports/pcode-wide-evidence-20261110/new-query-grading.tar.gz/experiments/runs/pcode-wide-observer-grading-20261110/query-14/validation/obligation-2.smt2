; 
(set-info :status unknown)
(declare-fun local_0 () Bool)
(assert
 (let (($x6281 (not local_0)))
(and (distinct $x6281 (or false (and true $x6281))) true)))
(check-sat)
