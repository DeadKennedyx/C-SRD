; 
(set-info :status unknown)
(declare-fun local_0 () Bool)
(declare-fun local_1 () Bool)
(declare-fun local_2 () Bool)
(assert
 (let (($x6540 (and true local_0)))
(let (($x6225 (or (or (or false (and true local_2)) (and true local_1)) $x6540)))
(and (distinct (or local_2 local_1 local_0) $x6225) true))))
(check-sat)
