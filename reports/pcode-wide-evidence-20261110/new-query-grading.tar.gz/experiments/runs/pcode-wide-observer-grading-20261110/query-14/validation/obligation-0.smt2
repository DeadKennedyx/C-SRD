; 
(set-info :status unknown)
(assert
 (let (($x6012 (or false true)))
(and (distinct true $x6012) true)))
(check-sat)
