; 
(set-info :status unknown)
(declare-fun local_0 () Bool)
(assert
 (let (($x6540 (and true local_0)))
(let (($x6703 (or false $x6540)))
(and (distinct local_0 $x6703) true))))
(check-sat)
