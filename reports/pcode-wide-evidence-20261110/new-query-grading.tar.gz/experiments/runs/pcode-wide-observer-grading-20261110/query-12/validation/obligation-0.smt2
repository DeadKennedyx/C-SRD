; 
(set-info :status unknown)
(assert
 (let (($x6054 (or false true)))
(and (distinct true $x6054) true)))
(check-sat)
