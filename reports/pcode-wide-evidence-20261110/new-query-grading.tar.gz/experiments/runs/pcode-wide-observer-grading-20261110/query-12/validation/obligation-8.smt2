; 
(set-info :status unknown)
(declare-fun local_2 () Bool)
(declare-fun local_1 () Bool)
(declare-fun local_0 () Bool)
(assert
 (let (($x6084 (and true local_1)))
(let (($x6087 (or (or false (and true local_0)) $x6084)))
(and (distinct (or local_0 local_1 local_2) (or $x6087 (and true local_2))) true))))
(check-sat)
