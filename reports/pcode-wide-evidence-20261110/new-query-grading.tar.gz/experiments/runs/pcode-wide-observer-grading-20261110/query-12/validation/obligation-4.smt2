; 
(set-info :status unknown)
(declare-fun local_1 () Bool)
(declare-fun local_0 () Bool)
(assert
 (let (($x6085 (and true local_0)))
(let (($x6110 (and $x6085 local_1)))
(let (($x6126 (or (or false (and (and true (not local_0)) (not local_1))) $x6110)))
(let (($x6127 (= local_0 local_1)))
(and (distinct $x6127 $x6126) true))))))
(check-sat)
