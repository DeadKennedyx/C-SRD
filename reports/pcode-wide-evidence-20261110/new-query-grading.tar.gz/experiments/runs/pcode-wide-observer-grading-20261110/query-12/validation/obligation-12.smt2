; 
(set-info :status unknown)
(declare-fun local_0 () Bool)
(declare-fun local_2 () Bool)
(declare-fun local_1 () Bool)
(assert
 (let (($x7030 (or (or false (and (and true local_2) local_1)) (and (and true (not local_2)) local_0))))
(let (($x7031 (ite local_2 local_1 local_0)))
(and (distinct $x7031 $x7030) true))))
(check-sat)
