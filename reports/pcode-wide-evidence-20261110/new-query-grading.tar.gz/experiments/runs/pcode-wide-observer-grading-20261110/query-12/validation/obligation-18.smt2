; 
(set-info :status unknown)
(declare-fun local_1 () Bool)
(declare-fun local_0 () Bool)
(assert
 (let (($x6085 (and true local_0)))
(let (($x6110 (and $x6085 local_1)))
(let (($x6111 (or false $x6110)))
(let (($x9365 (and local_0 local_1)))
(and (distinct $x9365 $x6111) true))))))
(check-sat)
