; 
(set-info :status unknown)
(declare-fun local_0 () Bool)
(assert
 (let (($x6085 (and true local_0)))
(let (($x6086 (or false $x6085)))
(and (distinct local_0 $x6086) true))))
(check-sat)
