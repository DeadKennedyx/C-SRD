; 
(set-info :status unknown)
(declare-fun local_0 () Bool)
(declare-fun local_1 () Bool)
(declare-fun local_2 () Bool)
(assert
 (let (($x7171 (or (or false (and (and true local_1) local_2)) (and (and true (not local_1)) local_0))))
(let (($x7172 (ite local_1 local_2 local_0)))
(and (distinct $x7172 $x7171) true))))
(check-sat)
