; 
(set-info :status unknown)
(declare-fun local_0 () Bool)
(assert
 (let (($x6080 (not local_0)))
(and (distinct $x6080 (or false (and true $x6080))) true)))
(check-sat)
