; 
(set-info :status unknown)
(declare-fun local_1 () Bool)
(declare-fun local_2 () Bool)
(declare-fun local_0 () Bool)
(assert
 (let (($x6507 (or (or false (and (and true local_2) local_0)) (and (and true (not local_2)) local_1))))
(let (($x6508 (ite local_2 local_0 local_1)))
(and (distinct $x6508 $x6507) true))))
(check-sat)
