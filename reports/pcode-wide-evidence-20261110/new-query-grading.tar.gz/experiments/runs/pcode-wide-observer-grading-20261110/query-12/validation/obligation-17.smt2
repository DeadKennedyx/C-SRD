; 
(set-info :status unknown)
(declare-fun local_0 () Bool)
(declare-fun local_2 () Bool)
(declare-fun local_1 () Bool)
(assert
 (let (($x9360 (and local_1 local_2 local_0)))
(and (distinct $x9360 (or false (and (and (and true local_1) local_2) local_0))) true)))
(check-sat)
