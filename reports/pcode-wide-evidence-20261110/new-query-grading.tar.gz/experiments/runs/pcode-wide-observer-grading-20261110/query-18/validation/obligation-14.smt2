; 
(set-info :status unknown)
(declare-fun local_1 () Bool)
(declare-fun local_0 () Bool)
(assert
 (let (($x19008 (and true local_0)))
(let (($x16920 (and $x19008 local_1)))
(let (($x24364 (or false $x16920)))
(let (($x27117 (and local_0 local_1)))
(and (distinct $x27117 $x24364) true))))))
(check-sat)
