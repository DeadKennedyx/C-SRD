; 
(set-info :status unknown)
(assert
 (let (($x16868 (or false true)))
(and (distinct true $x16868) true)))
(check-sat)
