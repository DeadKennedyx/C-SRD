; 
(set-info :status unknown)
(declare-fun local_1 () Bool)
(declare-fun local_0 () Bool)
(assert
 (let (($x16923 (or (or false (and (and true (not local_0)) (not local_1))) (and (and true local_0) local_1))))
(let (($x16924 (= local_0 local_1)))
(and (distinct $x16924 $x16923) true))))
(check-sat)
