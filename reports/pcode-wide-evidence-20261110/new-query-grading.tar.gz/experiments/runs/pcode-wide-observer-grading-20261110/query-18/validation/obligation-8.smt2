; 
(set-info :status unknown)
(declare-fun local_2 () Bool)
(declare-fun local_0 () Bool)
(declare-fun local_1 () Bool)
(assert
 (let (($x19035 (and true local_2)))
(let (($x19008 (and true local_0)))
(let (($x19010 (or (or false (and true local_1)) $x19008)))
(and (distinct (or local_1 local_0 local_2) (or $x19010 $x19035)) true)))))
(check-sat)
