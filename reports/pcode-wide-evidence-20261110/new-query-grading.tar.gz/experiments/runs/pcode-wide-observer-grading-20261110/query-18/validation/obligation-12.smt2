; 
(set-info :status unknown)
(declare-fun local_2 () Bool)
(declare-fun local_1 () Bool)
(declare-fun local_0 () Bool)
(assert
 (let (($x25629 (or (or false (and (and true local_1) local_0)) (and (and true (not local_1)) local_2))))
(let (($x25630 (ite local_1 local_0 local_2)))
(and (distinct $x25630 $x25629) true))))
(check-sat)
