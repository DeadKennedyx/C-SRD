; 
(set-info :status unknown)
(declare-fun local_0 () Bool)
(assert
 (let (($x18984 (not local_0)))
(and (distinct $x18984 (or false (and true $x18984))) true)))
(check-sat)
