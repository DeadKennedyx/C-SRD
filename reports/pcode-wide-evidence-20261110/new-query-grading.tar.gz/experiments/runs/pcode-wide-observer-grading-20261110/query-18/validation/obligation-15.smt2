; 
(set-info :status unknown)
(declare-fun local_0 () Bool)
(assert
 (let (($x19008 (and true local_0)))
(let (($x19018 (or false $x19008)))
(and (distinct local_0 $x19018) true))))
(check-sat)
