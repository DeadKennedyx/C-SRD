unsigned int f(unsigned int p0, unsigned int p1) {
    unsigned int v0 = (0u | p0);
    unsigned int v1 = (p1 | 0u);
    unsigned int v2 = (v0 >> 24u);
    unsigned int v3 = (v1 << 8u);
    unsigned int v4 = (v2 | v3);
    (void)p0;
    (void)p1;
    return v4;
}
