unsigned int f(unsigned int x,unsigned int y){return (x<<8u)|(y>>24u);}
