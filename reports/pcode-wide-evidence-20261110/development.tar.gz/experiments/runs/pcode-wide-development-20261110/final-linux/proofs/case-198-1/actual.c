unsigned int f(unsigned int p0,unsigned int p1,unsigned int p2,unsigned int p3,unsigned int p4,unsigned int p5,unsigned int p6,unsigned int p7,unsigned int p8){
    unsigned int v0 = p1;
    v0 = v0 & 65535u;
    unsigned int v1 = (p0 & 2147483647u);
    unsigned int v2 = (v1 << 1u);
    unsigned int v3 = (p0 >> 31u);
    unsigned int v4 = (v0 << 1u);
    unsigned int v5 = (v3 | v4);
    unsigned int v6 = (v5 & 65535u);
(void)p0;
(void)p1;
(void)p2;
(void)p3;
(void)p4;
(void)p5;
(void)p6;
(void)p7;
(void)p8;
(void)v0;
(void)v1;
(void)v2;
(void)v3;
(void)v4;
(void)v5;
(void)v6;
return v6;
}
