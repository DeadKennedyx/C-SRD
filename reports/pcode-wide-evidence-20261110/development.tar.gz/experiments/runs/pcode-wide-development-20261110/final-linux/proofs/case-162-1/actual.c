unsigned int f(unsigned int p0,unsigned int p1,unsigned int p2,unsigned int p3,unsigned int p4,unsigned int p5,unsigned int p6,unsigned int p7,unsigned int p8){
    unsigned int v0 = p1;
    v0 = v0 & 255u;
    unsigned int v1 = (p0 & 255u);
(void)p0;
(void)p1;
(void)p2;
(void)p3;
(void)p4;
(void)p5;
(void)p6;
(void)p7;
(void)p8;
(void)v0;
(void)v1;
return v1;
}
