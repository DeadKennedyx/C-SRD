
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

uint kernel(uint p0,uint p1)

{
  undefined8 uVar1;
  ulong uVar2;
  undefined8 uVar3;
  uint uVar4;
  uint5 uVar5;
  undefined1 auVar6 [16];
  undefined1 auVar7 [16];
  undefined1 auVar8 [16];
  uint uVar9;
  uint5 uVar10;
  undefined1 auVar11 [16];
  undefined1 auVar12 [16];
  undefined1 auVar13 [16];
  undefined1 auVar14 [16];
  uint5 uVar15;
  ulong uVar16;
  ulong uVar17;
  ulong uVar18;
  undefined1 auVar19 [16];
  
  auVar11._4_4_ = p0;
  auVar11._0_4_ = p0;
  auVar11._8_4_ = p0;
  auVar11._12_4_ = p0;
  auVar6._0_8_ = CONCAT44(p1,p0);
  auVar7[8] = (char)_UNK_00100b58;
  auVar7._0_8_ = _DAT_00100b50;
  auVar7[9] = (char)((ulong)_UNK_00100b58 >> 8);
  auVar7[10] = (char)((ulong)_UNK_00100b58 >> 0x10);
  auVar7[0xb] = (char)((ulong)_UNK_00100b58 >> 0x18);
  auVar7[0xc] = (char)((ulong)_UNK_00100b58 >> 0x20);
  auVar7[0xd] = (char)((ulong)_UNK_00100b58 >> 0x28);
  auVar7[0xe] = (char)((ulong)_UNK_00100b58 >> 0x30);
  auVar7[0xf] = (char)((ulong)_UNK_00100b58 >> 0x38);
  auVar12 = NEON_ushl(auVar11,auVar7,4);
  uVar18 = NEON_ushl(CONCAT44(p1,p1),DAT_00100b88,4);
  uVar17 = NEON_ushl(CONCAT44(p1,p1),DAT_00100b80,4);
  auVar6._8_8_ = auVar6._0_8_;
  uVar10 = CONCAT14(auVar12[4],(uint)(auVar12[0] & 1)) & 0x1ffffffff;
  auVar14[8] = (char)_UNK_00100b48;
  auVar14._0_8_ = _DAT_00100b40;
  auVar14[9] = (char)((ulong)_UNK_00100b48 >> 8);
  auVar14[10] = (char)((ulong)_UNK_00100b48 >> 0x10);
  auVar14[0xb] = (char)((ulong)_UNK_00100b48 >> 0x18);
  auVar14[0xc] = (char)((ulong)_UNK_00100b48 >> 0x20);
  auVar14[0xd] = (char)((ulong)_UNK_00100b48 >> 0x28);
  auVar14[0xe] = (char)((ulong)_UNK_00100b48 >> 0x30);
  auVar14[0xf] = (char)((ulong)_UNK_00100b48 >> 0x38);
  auVar7 = NEON_ushl(auVar6,auVar14,4);
  uVar5 = CONCAT14(auVar7[4],(uint)(auVar7[0] & 1)) & 0x1ffffffff;
  uVar15 = CONCAT14(auVar12[4] * '\x02',(uint)(auVar12[0] * '\x02' & 4)) & 0x4ffffffff;
  auVar13[0] = (byte)uVar15 | (byte)uVar10;
  auVar13._1_3_ = 0;
  auVar13[4] = (byte)(uVar15 >> 0x20) | (byte)(uVar10 >> 0x20);
  auVar13._5_3_ = 0;
  auVar13[8] = auVar12[8] * '\x02' & 4 | auVar12[8] & 1;
  auVar13._9_3_ = 0;
  auVar13[0xc] = auVar12[0xc] * '\x02' & 4 | auVar12[0xc] & 1;
  auVar13._13_3_ = 0;
  auVar8[0] = auVar7[0] * '\x02' & 4 | (byte)uVar5;
  auVar8._1_3_ = 0;
  auVar8[4] = auVar7[4] * '\x02' & 4U | (byte)(uVar5 >> 0x20);
  auVar8._5_3_ = 0;
  auVar8[8] = auVar7[8] * '\x02' & 4 | auVar7[8] & 1;
  auVar8._9_3_ = 0;
  auVar8[0xc] = auVar7[0xc] * '\x02' & 4 | auVar7[0xc] & 1;
  auVar8._13_3_ = 0;
  auVar19[8] = (char)_UNK_00100b78;
  auVar19._0_8_ = _DAT_00100b70;
  auVar19[9] = (char)((ulong)_UNK_00100b78 >> 8);
  auVar19[10] = (char)((ulong)_UNK_00100b78 >> 0x10);
  auVar19[0xb] = (char)((ulong)_UNK_00100b78 >> 0x18);
  auVar19[0xc] = (char)((ulong)_UNK_00100b78 >> 0x20);
  auVar19[0xd] = (char)((ulong)_UNK_00100b78 >> 0x28);
  auVar19[0xe] = (char)((ulong)_UNK_00100b78 >> 0x30);
  auVar19[0xf] = (char)((ulong)_UNK_00100b78 >> 0x38);
  auVar14 = NEON_ushl(auVar13,auVar19,4);
  uVar16 = CONCAT44((int)(uVar18 >> 0x20) * 2,(int)uVar18 * 2) & 0x400000004;
  uVar2 = CONCAT44((int)(uVar17 >> 0x20) * 2,(int)uVar17 * 2) & 0x400000004;
  auVar12[8] = (char)_UNK_00100b68;
  auVar12._0_8_ = _DAT_00100b60;
  auVar12[9] = (char)((ulong)_UNK_00100b68 >> 8);
  auVar12[10] = (char)((ulong)_UNK_00100b68 >> 0x10);
  auVar12[0xb] = (char)((ulong)_UNK_00100b68 >> 0x18);
  auVar12[0xc] = (char)((ulong)_UNK_00100b68 >> 0x20);
  auVar12[0xd] = (char)((ulong)_UNK_00100b68 >> 0x28);
  auVar12[0xe] = (char)((ulong)_UNK_00100b68 >> 0x30);
  auVar12[0xf] = (char)((ulong)_UNK_00100b68 >> 0x38);
  auVar7 = NEON_ushl(auVar8,auVar12,4);
  auVar12 = NEON_ext(auVar14,auVar14,8,1);
  auVar19 = NEON_ext(auVar7,auVar7,8,1);
  uVar1 = NEON_ushl((ulong)CONCAT14((byte)(uVar16 >> 0x20) | (byte)((uVar18 & 0x100000001) >> 0x20),
                                    (uint)(byte)((byte)uVar16 | (byte)(uVar18 & 0x100000001))),
                    DAT_00100b98,4);
  uVar3 = NEON_ushl((ulong)CONCAT14((byte)(uVar2 >> 0x20) | (byte)((uVar17 & 0x100000001) >> 0x20),
                                    (uint)(byte)((byte)uVar2 | (byte)(uVar17 & 0x100000001))),
                    DAT_00100b90,4);
  uVar9 = CONCAT13(auVar14[3] | auVar12[3],
                   CONCAT12(auVar14[2] | auVar12[2],
                            CONCAT11(auVar14[1] | auVar12[1],auVar14[0] | auVar12[0])));
  uVar4 = CONCAT13(auVar7[3] | auVar19[3],
                   CONCAT12(auVar7[2] | auVar19[2],
                            CONCAT11(auVar7[1] | auVar19[1],auVar7[0] | auVar19[0])));
  return uVar4 | (uint)(CONCAT17(auVar7[7] | auVar19[7],
                                 CONCAT16(auVar7[6] | auVar19[6],
                                          CONCAT15(auVar7[5] | auVar19[5],
                                                   CONCAT14(auVar7[4] | auVar19[4],uVar4)))) >> 0x20
                       ) | (p0 >> 1 & 4 | p0 >> 2 & 1) << 4 |
         (p1 & 1) << 1 | (p1 & 2) << 2 | (p1 >> 1 & 4 | p1 >> 2 & 1) << 5 |
         p0 & 1 | (p0 & 2) << 1 |
         (uVar9 | (uint)uVar1 |
         (uint)(CONCAT17(auVar14[7] | auVar12[7],
                         CONCAT16(auVar14[6] | auVar12[6],
                                  CONCAT15(auVar14[5] | auVar12[5],
                                           CONCAT14(auVar14[4] | auVar12[4],uVar9)))) >> 0x20)) +
         (int)((ulong)uVar1 >> 0x20) + (int)uVar3 + (int)((ulong)uVar3 >> 0x20);
}

