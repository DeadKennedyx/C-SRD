
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

uint kernel(uint p0,uint p1)

{
  uint uVar1;
  byte bVar2;
  undefined2 uVar3;
  undefined4 uVar4;
  undefined1 uVar7;
  ulong uVar5;
  ulong uVar6;
  undefined1 uVar10;
  int iVar8;
  undefined1 uVar12;
  int iVar11;
  undefined8 uVar9;
  
  uVar5 = CONCAT44(p0,p1) & 0xffff0000ffff;
  bVar2 = (byte)uVar5;
  uVar10 = (undefined1)(p1 >> 8);
  uVar7 = (undefined1)(uVar5 >> 0x20);
  uVar12 = (undefined1)(p0 >> 8);
  uVar1 = (uint)CONCAT12(uVar10,(ushort)bVar2);
  iVar8 = uVar1 << 4;
  iVar11 = (uint)(uint3)(CONCAT16(uVar12,(uint6)CONCAT14(uVar7,uVar1)) >> 0x20) << 4;
  uVar3 = CONCAT11((char)((uint)iVar8 >> 8),bVar2);
  uVar4 = CONCAT13((char)((uint)iVar8 >> 0x18),CONCAT12(uVar10,uVar3));
  uVar5 = CONCAT62((int6)(CONCAT17((char)((uint)iVar11 >> 0x18),
                                   CONCAT16(uVar12,CONCAT15((char)((uint)iVar11 >> 8),
                                                            CONCAT14(uVar7,uVar4)))) >> 0x10),uVar3)
          & 0xffffffffffffff0f;
  uVar6 = CONCAT44((int)(uVar5 >> 0x20),CONCAT22((short)((uint)uVar4 >> 0x10),(short)uVar5)) &
          0xffffffffff0fffff;
  uVar5 = CONCAT26((short)(uVar6 >> 0x30),CONCAT24((short)(uVar5 >> 0x20),(int)uVar6)) &
          0xff0fff0fffffffff;
  iVar8 = (int)uVar5 << 2;
  iVar11 = (int)(uVar5 >> 0x20) << 2;
  uVar5 = CONCAT17((byte)((uint)iVar11 >> 0x18) | (byte)(uVar5 >> 0x38),
                   CONCAT16((byte)((uint)iVar11 >> 0x10) | (byte)(uVar5 >> 0x30),
                            CONCAT15((byte)((uint)iVar11 >> 8) | (byte)(uVar5 >> 0x28),
                                     CONCAT14((byte)iVar11 | (byte)(uVar5 >> 0x20),
                                              CONCAT13((byte)((uint)iVar8 >> 0x18) |
                                                       (byte)(uVar5 >> 0x18),
                                                       CONCAT12((byte)((uint)iVar8 >> 0x10) |
                                                                (byte)(uVar5 >> 0x10),
                                                                CONCAT11((byte)((uint)iVar8 >> 8) |
                                                                         (byte)(uVar5 >> 8),
                                                                         (byte)iVar8 | (byte)uVar5))
                                                      ))))) & 0x3333333333333333;
  uVar9 = NEON_ushl(uVar5,DAT_00100a48,4);
  iVar8 = (int)uVar5 << 1;
  uVar5 = CONCAT17((byte)((ulong)uVar9 >> 0x38) | (byte)(uVar5 >> 0x38),
                   CONCAT16((byte)((ulong)uVar9 >> 0x30) | (byte)(uVar5 >> 0x30),
                            CONCAT15((byte)((ulong)uVar9 >> 0x28) | (byte)(uVar5 >> 0x28),
                                     CONCAT14((byte)((ulong)uVar9 >> 0x20) | (byte)(uVar5 >> 0x20),
                                              CONCAT13((byte)((ulong)uVar9 >> 0x18) |
                                                       (byte)((uint)iVar8 >> 0x18),
                                                       CONCAT12((byte)((ulong)uVar9 >> 0x10) |
                                                                (byte)((uint)iVar8 >> 0x10),
                                                                CONCAT11((byte)((ulong)uVar9 >> 8) |
                                                                         (byte)((uint)iVar8 >> 8),
                                                                         (byte)uVar9 | (byte)iVar8))
                                                      ))))) & DAT_00100a50;
  return CONCAT13((byte)(uVar5 >> 0x18) | (byte)(uVar5 >> 0x38),
                  CONCAT12((byte)(uVar5 >> 0x10) | (byte)(uVar5 >> 0x30),
                           CONCAT11((byte)(uVar5 >> 8) | (byte)(uVar5 >> 0x28),
                                    (byte)uVar5 | (byte)(uVar5 >> 0x20))));
}

