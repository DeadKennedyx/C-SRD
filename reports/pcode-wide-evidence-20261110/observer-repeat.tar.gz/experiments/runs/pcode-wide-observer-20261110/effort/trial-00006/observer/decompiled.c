
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

uint kernel(uint p0,uint p1)

{
  uint uVar1;
  uint uVar2;
  
  uVar1 = p1 & 0xff ^ p0 ^ 0xffffffff;
  uVar2 = -(uVar1 & 1) & 0xedb88320 ^ uVar1 >> 1;
  uVar1 = -(uVar1 >> 1 & 1) & 0xedb88320 ^ uVar2 >> 1;
  uVar2 = -(uVar2 >> 1 & 1) & 0xedb88320 ^ uVar1 >> 1;
  uVar1 = -(uVar1 >> 1 & 1) & 0xedb88320 ^ uVar2 >> 1;
  uVar2 = -(uVar2 >> 1 & 1) & 0xedb88320 ^ uVar1 >> 1;
  uVar1 = -(uVar1 >> 1 & 1) & 0xedb88320 ^ uVar2 >> 1;
  return -(uVar1 >> 1 & 1) & 0xedb88320 ^
         (-(uVar2 >> 1 & 1) & 0xedb88320 ^ uVar1 >> 1) >> 1 ^ 0xffffffff;
}

