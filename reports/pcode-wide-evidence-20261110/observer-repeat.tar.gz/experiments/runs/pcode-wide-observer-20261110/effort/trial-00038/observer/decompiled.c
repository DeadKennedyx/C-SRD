
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

uint kernel(uint p0)

{
  return (p0 & 0xff) * 0x1d + (p0 >> 0x10 & 0xff) * 0x4d + (p0 >> 8 & 0xff) * 0x96 >> 8;
}

