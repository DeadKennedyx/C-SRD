
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

uint kernel(uint p0,uint p1)

{
  uint uVar1;
  uint uVar2;
  uint uVar3;
  uint uVar4;
  uint uVar5;
  uint uVar6;
  uint uVar7;
  uint uVar8;
  uint uVar9;
  uint uVar10;
  uint uVar11;
  uint uVar12;
  uint uVar13;
  uint uVar14;
  
  uVar7 = p1 >> 10 & 3;
  uVar5 = p0 >> 10 & 3;
  uVar3 = p1 >> 0xe & 3;
  uVar4 = p1 >> 6 & 3;
  uVar12 = p0 >> 6 & 3;
  uVar10 = p0 >> 0xe & 3;
  uVar9 = p1 >> 2 & 3;
  uVar8 = p1 >> 8 & 3;
  uVar14 = p0 >> 2 & 3;
  uVar13 = p0 >> 8 & 3;
  uVar6 = p1 >> 4 & 3;
  uVar11 = p0 >> 4 & 3;
  uVar2 = p1 >> 0xc & 3;
  uVar1 = p0 >> 0xc & 3;
  return (((uVar7 | uVar7 << 1) & 5) << 1 | (uVar5 | uVar5 << 1) & 5) << 0x14 |
         (((uVar4 | uVar4 << 1) & 5) << 1 | (uVar12 | uVar12 << 1) & 5) << 0xc |
         ((p1 & 3 | (p1 & 3) << 1) & 5) << 1 | (p0 & 3 | (p0 & 3) << 1) & 5 |
         (((uVar3 | uVar3 << 1) & 5) << 1 | (uVar10 | uVar10 << 1) & 5) << 0x1c |
         (((uVar9 | uVar9 << 1) & 5) << 1 | (uVar14 | uVar14 << 1) & 5) << 4 |
         (((uVar8 | uVar8 << 1) & 5) << 1 | (uVar13 | uVar13 << 1) & 5) << 0x10 |
         (((uVar6 | uVar6 << 1) & 5) << 1 | (uVar11 | uVar11 << 1) & 5) << 8 |
         (((uVar2 | uVar2 << 1) & 5) << 1 | (uVar1 | uVar1 << 1) & 5) << 0x18;
}

