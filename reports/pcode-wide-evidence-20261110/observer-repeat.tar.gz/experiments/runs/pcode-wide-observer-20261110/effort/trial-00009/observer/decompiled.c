
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

uint kernel(uint p0,uint p1)

{
  uint uVar1;
  uint uVar2;
  uint uVar3;
  uint uVar4;
  uint uVar5;
  
  uVar2 = ~p0 & 0xffff ^ p1 & 0xff;
  uVar1 = p0 >> 0x10 ^ 0xffff;
  uVar5 = -(uVar2 & 1);
  uVar2 = uVar2 >> 1;
  uVar3 = uVar5 & 0xedb8 ^ uVar1 >> 1;
  uVar4 = -(uVar2 & 1);
  uVar2 = (((uVar1 & 1) << 0xf | uVar2) ^ uVar5 & 0x8320) >> 1;
  uVar1 = uVar4 & 0xedb8 ^ uVar3 >> 1;
  uVar5 = -(uVar2 & 1);
  uVar2 = (((uVar3 & 1) << 0xf | uVar2) ^ uVar4 & 0x8320) >> 1;
  uVar3 = uVar5 & 0xedb8 ^ uVar1 >> 1;
  uVar4 = -(uVar2 & 1);
  uVar2 = (((uVar1 & 1) << 0xf | uVar2) ^ uVar5 & 0x8320) >> 1;
  uVar1 = uVar4 & 0xedb8 ^ uVar3 >> 1;
  uVar5 = -(uVar2 & 1);
  uVar2 = (((uVar3 & 1) << 0xf | uVar2) ^ uVar4 & 0x8320) >> 1;
  uVar3 = uVar5 & 0xedb8 ^ uVar1 >> 1;
  uVar4 = -(uVar2 & 1);
  uVar2 = (((uVar1 & 1) << 0xf | uVar2) ^ uVar5 & 0x8320) >> 1;
  uVar1 = uVar4 & 0xedb8 ^ uVar3 >> 1;
  uVar5 = -(uVar2 & 1);
  uVar2 = (((uVar3 & 1) << 0xf | uVar2) ^ uVar4 & 0x8320) >> 1;
  uVar3 = uVar5 & 0xedb8 ^ uVar1 >> 1;
  uVar4 = -(uVar2 & 1);
  return ((uVar3 & 1) << 0xf | (((uVar1 & 1) << 0xf | uVar2) ^ uVar5 & 0x8320) >> 1) ^
         uVar4 & 0x8320 ^ 0xffff | (uVar4 & 0xedb8 ^ uVar3 >> 1) << 0x10 ^ 0xffff0000;
}

