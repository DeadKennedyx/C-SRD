
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

uint kernel(uint p0,uint p1)

{
  uint uVar1;
  uint uVar2;
  uint uVar3;
  uint uVar4;
  
  uVar4 = p1 >> 8 & 0xff;
  uVar3 = p0 >> 8 & 0xff;
  uVar4 = (uVar4 | uVar4 << 4) & 0xf0f;
  uVar1 = ((p1 & 0xff) << 4 | p1 & 0xff) & 0xf0f;
  uVar3 = (uVar3 | uVar3 << 4) & 0xf0f;
  uVar2 = ((p0 & 0xff) << 4 | p0 & 0xff) & 0xf0f;
  uVar4 = (uVar4 | uVar4 << 2) & 0x3333;
  uVar1 = (uVar1 | uVar1 << 2) & 0x3333;
  uVar3 = (uVar3 | uVar3 << 2) & 0x3333;
  uVar2 = (uVar2 | uVar2 << 2) & 0x3333;
  return ((uVar1 | uVar1 << 1) & 0x5555) << 1 | (uVar2 | uVar2 << 1) & 0x5555 |
         (((uVar4 | uVar4 << 1) & 0x5555) << 1 | (uVar3 | uVar3 << 1) & 0x5555) << 0x10;
}

