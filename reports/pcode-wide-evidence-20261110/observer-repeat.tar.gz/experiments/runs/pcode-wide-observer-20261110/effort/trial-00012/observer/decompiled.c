
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

uint kernel(uint p0,uint p1)

{
  uint uVar1;
  uint uVar2;
  uint uVar3;
  uint uVar4;
  uint uVar5;
  uint uVar6;
  uint uVar7;
  
  uVar1 = (p1 & 0xff) + (p0 & 0xff);
  uVar6 = uVar1 >> 6 & 3;
  uVar2 = (uVar1 >> 8) + (p0 >> 8 & 0xff);
  uVar3 = (uVar1 * 4 & 0xfc) + (uVar2 & 0xff);
  uVar4 = (uVar2 >> 8) + (p0 >> 0x10 & 0xff);
  uVar5 = (uVar6 | uVar2 * 4 & 0xfc) + (uVar4 & 0xff) + (uVar3 >> 8);
  uVar1 = ((uVar6 | uVar3 * 4 & 0xfc) ^ uVar1 & 0xff) + (p1 >> 8 & 0xff);
  uVar2 = (uVar2 >> 6 & 3) + (p0 >> 0x18) + (uVar4 >> 8) + uVar4 * 4 + (uVar5 >> 8);
  uVar7 = uVar1 >> 6 & 3;
  uVar3 = ((uVar3 >> 6 & 3 | uVar5 * 4 & 0xfc) ^ uVar3 & 0xff) + (uVar1 >> 8);
  uVar4 = ((uVar5 >> 6 & 3 | uVar2 * 4 & 0xfc) ^ uVar5 & 0xff) + (uVar3 >> 8);
  uVar5 = (uVar3 & 0xff) + (uVar1 * 4 & 0xfc);
  uVar6 = (uVar7 | uVar3 * 4 & 0xfc) + (uVar4 & 0xff) + (uVar5 >> 8);
  uVar1 = ((uVar7 | uVar5 * 4 & 0xfc) ^ uVar1 & 0xff) + (p1 >> 0x10 & 0xff);
  uVar2 = (uVar2 ^ (uVar2 & 0xc0) >> 6) + ((uVar3 & 0xff) >> 6) + (uVar4 >> 8) + (uVar4 & 0xff) * 4
          + (uVar6 >> 8);
  uVar7 = uVar1 >> 6 & 3;
  uVar3 = ((uVar5 >> 6 & 3 | uVar6 * 4 & 0xfc) ^ uVar5 & 0xff) + (uVar1 >> 8);
  uVar4 = ((uVar6 >> 6 & 3 | uVar2 * 4 & 0xfc) ^ uVar6 & 0xff) + (uVar3 >> 8);
  uVar5 = (uVar3 & 0xff) + (uVar1 * 4 & 0xfc);
  uVar6 = (uVar7 | uVar3 * 4 & 0xfc) + (uVar4 & 0xff) + (uVar5 >> 8);
  uVar2 = (uVar2 ^ (uVar2 & 0xc0) >> 6) + ((uVar3 & 0xff) >> 6) + (uVar4 >> 8) + (uVar4 & 0xff) * 4
          + (uVar6 >> 8);
  uVar1 = ((uVar7 | uVar5 * 4 & 0xfc) ^ uVar1 & 0xff) + (p1 >> 0x18);
  uVar3 = ((uVar5 >> 6 & 3 | uVar6 * 4 & 0xfc) ^ uVar5 & 0xff) + (uVar1 >> 8);
  uVar7 = uVar1 >> 6 & 3;
  uVar4 = ((uVar6 >> 6 & 3 | uVar2 * 4 & 0xfc) ^ uVar6 & 0xff) + (uVar3 >> 8);
  uVar5 = (uVar3 & 0xff) + (uVar1 * 4 & 0xfc);
  uVar6 = (uVar7 | uVar5 * 4 & 0xfc) ^ uVar1 & 0xff;
  uVar1 = (uVar7 | uVar3 * 4 & 0xfc) + (uVar4 & 0xff) + (uVar5 >> 8);
  uVar2 = (uVar2 ^ (uVar2 & 0xc0) >> 6) + ((uVar3 & 0xff) >> 6) + (uVar4 >> 8) + (uVar4 & 0xff) * 4
          + (uVar1 >> 8);
  uVar3 = (uVar6 & 0x1f) * 8 + uVar6;
  uVar4 = uVar2 & 0xff;
  uVar5 = (uVar5 >> 6 & 3 | uVar1 * 4 & 0xfc) ^ uVar5 & 0xff;
  uVar7 = (uVar1 >> 6 & 3 | uVar2 * 4 & 0xfc) ^ uVar1 & 0xff;
  uVar1 = (uVar3 >> 8) + (uVar6 >> 5) + uVar5 + (uVar5 & 0x1f) * 8;
  uVar2 = uVar7 + (uVar5 >> 5) + (uVar7 & 0x1f) * 8 + (uVar1 >> 8);
  uVar4 = (uVar4 ^ uVar4 >> 6) * 9 + (uVar7 >> 5) + (uVar2 >> 8);
  uVar5 = uVar2 & 0xff ^ (uVar4 & 0xf8) >> 3;
  uVar3 = (uVar1 >> 3 & 0x1f | uVar2 * 0x20 & 0xe0) ^ uVar3 & 0xff;
  uVar6 = (uVar2 >> 3 & 0x1f | uVar4 * 0x20 & 0xe0) ^ uVar1 & 0xff;
  uVar1 = uVar6 + (uVar3 & 1) * 0x80;
  uVar2 = uVar5 + (uVar3 >> 1) + (uVar6 & 1) * 0x80 + (uVar1 >> 8);
  return uVar2 * 0x10000 & 0xff0000 | uVar1 * 0x100 & 0xff00 |
         (uVar4 + uVar5 * 0x80 + (uVar6 >> 1) + (uVar2 >> 8)) * 0x1000000 | uVar3;
}

