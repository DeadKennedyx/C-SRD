
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

uint kernel(uint p0,uint p1)

{
  uint uVar1;
  uint3 uVar2;
  byte bVar4;
  uint uVar3;
  byte bVar6;
  uint7 uVar5;
  byte bVar7;
  int iVar8;
  byte bVar11;
  ulong uVar9;
  int iVar12;
  undefined8 uVar10;
  
  uVar9 = CONCAT44(p0 >> 8,p1 >> 8) & 0xf0000000f;
  uVar5 = (uint7)(CONCAT44(p0 >> 4,p1 >> 4) >> 8) & 0xf0000000f;
  bVar7 = (byte)uVar9;
  bVar4 = (byte)uVar5;
  uVar3 = (uint)CONCAT11(bVar4,bVar7);
  bVar11 = (byte)(uVar9 >> 0x20);
  bVar6 = (byte)(uVar5 >> 0x20);
  iVar8 = uVar3 << 2;
  iVar12 = (uint)(ushort)(CONCAT15(bVar6,CONCAT14(bVar11,uVar3)) >> 0x20) << 2;
  uVar2 = (uint3)CONCAT11((byte)((uint)iVar8 >> 8) | bVar4,(byte)iVar8 | bVar7);
  uVar9 = (ulong)CONCAT15((byte)((uint)iVar12 >> 8) | bVar6,
                          CONCAT14((byte)iVar12 | bVar11,(uint)uVar2)) & 0x333300003333;
  uVar10 = NEON_ushl(uVar9,DAT_00100a88,4);
  iVar8 = (uVar2 & 0x3333) << 1;
  uVar3 = p1 & 0xf | (p1 & 0xf0) << 4;
  uVar1 = p0 & 0xf | (p0 & 0xf0) << 4;
  uVar9 = CONCAT15((byte)((ulong)uVar10 >> 0x28) | (byte)(uVar9 >> 0x28),
                   CONCAT14((byte)((ulong)uVar10 >> 0x20) | (byte)(uVar9 >> 0x20),
                            (uint)CONCAT11((byte)((ulong)uVar10 >> 8) | (byte)((uint)iVar8 >> 8),
                                           (byte)uVar10 | (byte)iVar8))) & DAT_00100a90;
  uVar3 = (uVar3 | uVar3 << 2) & 0xf3f3f3f3;
  uVar1 = (uVar1 | uVar1 << 2) & 0xf3f3f3f3;
  return (uVar1 | uVar1 << 1) & 0xdddddddd | (uVar3 << 2 | uVar3 << 1) & 0xbbbbbbbb |
         (uint)CONCAT11((byte)(uVar9 >> 8) | (byte)(uVar9 >> 0x28),
                        (byte)uVar9 | (byte)(uVar9 >> 0x20)) << 0x10;
}

