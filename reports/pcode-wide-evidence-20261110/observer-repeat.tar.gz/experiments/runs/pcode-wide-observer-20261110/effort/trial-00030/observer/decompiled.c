
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

uint kernel(uint p0)

{
  uint uVar1;
  uint uVar2;
  uint uVar3;
  ulong uVar4;
  uint uVar5;
  uint uVar6;
  ulong uVar7;
  uint uVar8;
  uint uVar9;
  int iVar10;
  ulong uVar11;
  
  uVar7 = NEON_ushl(CONCAT44(p0,p0),DAT_00100ab0,4);
  uVar4 = NEON_ushl(CONCAT44(p0,p0),DAT_00100ab8,4);
  uVar2 = (p0 & 0xf) * 0x1d;
  uVar6 = (int)(uVar7 & 0xf0000000f) * (int)DAT_00100ac0;
  iVar10 = (int)((ulong)DAT_00100ac0 >> 0x20);
  uVar8 = (int)((uVar7 & 0xf0000000f) >> 0x20) * iVar10;
  uVar1 = (p0 >> 4 & 0xf) * 0x1d + (uVar2 >> 4);
  uVar3 = (int)(uVar4 & 0xf0000000f) * (int)DAT_00100ac0 + (uVar6 >> 4);
  uVar5 = (int)((uVar4 & 0xf0000000f) >> 0x20) * iVar10 + (uVar8 >> 4);
  uVar4 = CONCAT44(uVar8,uVar5) & DAT_00100ac8;
  uVar7 = CONCAT44(uVar6,uVar3) & 0xf0000000f;
  uVar11 = CONCAT44(uVar5 >> 4,uVar3 >> 4) & 0xf0000000f;
  uVar9 = (int)(uVar7 >> 0x20) + (int)(uVar4 >> 0x20);
  uVar6 = (int)uVar7 + (int)uVar4 + (uVar9 >> 4);
  uVar8 = (int)uVar11 + (int)(uVar11 >> 0x20) + (uVar6 >> 4);
  uVar6 = (uVar8 & 0xf) + (uVar1 >> 4 & 0xf) +
          ((uVar1 & 0xf) + ((uVar9 & 0xf) + (uVar2 & 0xf) >> 4) + (uVar6 & 0xf) >> 4);
  return (uVar8 + ((uVar5 >> 8) + (uVar1 >> 8) + (uVar3 >> 8)) * 0x10 & 0xff0) + uVar6 & 0xff0 |
         uVar6 & 0xf;
}

