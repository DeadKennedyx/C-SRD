unsigned int kernel(unsigned int p0) {
    unsigned int v0 = (p0 & 255u);
    unsigned int v1 = (p0 >> 8u);
    unsigned int v2 = (v1 & 255u);
    unsigned int v3 = (p0 >> 16u);
    unsigned int v4 = (v3 & 255u);
    unsigned int v5 = (v2 * 150u);
    unsigned int v6 = (v4 * 77u);
    unsigned int v7 = (v0 * 29u);
    unsigned int v8 = (v5 & 255u);
    unsigned int v9 = (v5 >> 8u);
    unsigned int v10 = (v6 & 255u);
    unsigned int v11 = (v8 + v10);
    unsigned int v12 = (v7 & 255u);
    unsigned int v13 = (v7 >> 8u);
    unsigned int v14 = (v6 >> 8u);
    unsigned int v15 = (v9 + v14);
    unsigned int v16 = (v11 >> 8u);
    unsigned int v17 = (v13 + v16);
    unsigned int v18 = (v11 & 255u);
    unsigned int v19 = (v12 + v18);
    unsigned int v20 = (v15 + v17);
    unsigned int v21 = (v19 >> 8u);
    unsigned int v22 = (v20 + v21);
    (void)p0;
    return v22;
}
