
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

uint kernel(uint p0,uint p1)

{
  uint uVar1;
  uint uVar2;
  uint uVar3;
  uint uVar4;
  byte bVar5;
  byte bVar7;
  ulong uVar6;
  byte bVar8;
  byte bVar11;
  undefined8 uVar9;
  ulong uVar10;
  undefined8 uVar12;
  ulong uVar13;
  
  uVar9 = NEON_ushl(CONCAT44(p1,p0),DAT_00100b08,4);
  uVar6 = NEON_ushl(CONCAT44(p1,p0),DAT_00100b00,4);
  uVar10 = NEON_rev64(uVar9,4);
  uVar13 = CONCAT44((int)(uVar6 >> 0x20) << 2,(int)uVar6 << 2) & 0x3000000030;
  bVar5 = (byte)uVar13 | (byte)(uVar6 & 0x300000003);
  bVar7 = (byte)(uVar13 >> 0x20) | (byte)((uVar6 & 0x300000003) >> 0x20);
  uVar6 = CONCAT44((int)(uVar10 >> 0x20) << 2,(int)uVar10 << 2) & 0x3000000030;
  uVar12 = NEON_ushl((ulong)CONCAT14(bVar7,(uint)bVar5),DAT_00100b20,4);
  bVar8 = (byte)uVar6 | (byte)(uVar10 & 0x300000003);
  bVar11 = (byte)(uVar6 >> 0x20) | (byte)((uVar10 & 0x300000003) >> 0x20);
  uVar9 = NEON_ushl((ulong)CONCAT14(bVar11,(uint)bVar8),DAT_00100b10,4);
  uVar3 = p0 >> 2 & 0x30 | p0 >> 4 & 3;
  uVar6 = CONCAT17((char)((ulong)uVar12 >> 0x38),
                   CONCAT16((char)((ulong)uVar12 >> 0x30),
                            CONCAT15((char)((ulong)uVar12 >> 0x28),
                                     CONCAT14((byte)((ulong)uVar12 >> 0x20) | bVar7 << 1,
                                              CONCAT13((char)((ulong)uVar12 >> 0x18),
                                                       CONCAT12((char)((ulong)uVar12 >> 0x10),
                                                                CONCAT11((char)((ulong)uVar12 >> 8),
                                                                         (byte)uVar12 | bVar5)))))))
          & DAT_00100b28;
  uVar4 = p1 >> 2 & 0x30 | p1 >> 4 & 3;
  uVar1 = p0 & 3 | (p0 & 0xc) << 2;
  uVar2 = p1 & 3 | (p1 & 0xc) << 2;
  uVar10 = CONCAT17((char)((ulong)uVar9 >> 0x38),
                    CONCAT16((char)((ulong)uVar9 >> 0x30),
                             CONCAT15((char)((ulong)uVar9 >> 0x28),
                                      CONCAT14((byte)((ulong)uVar9 >> 0x20) | bVar11,
                                               CONCAT13((char)((ulong)uVar9 >> 0x18),
                                                        CONCAT12((char)((ulong)uVar9 >> 0x10),
                                                                 CONCAT11((char)((ulong)uVar9 >> 8),
                                                                          (byte)uVar9 | bVar8 << 1))
                                                       ))))) & DAT_00100b18;
  uVar9 = NEON_ushl(CONCAT17((byte)(uVar6 >> 0x38) | (byte)(uVar10 >> 0x38),
                             CONCAT16((byte)(uVar6 >> 0x30) | (byte)(uVar10 >> 0x30),
                                      CONCAT15((byte)(uVar6 >> 0x28) | (byte)(uVar10 >> 0x28),
                                               CONCAT14((byte)(uVar6 >> 0x20) |
                                                        (byte)(uVar10 >> 0x20),
                                                        CONCAT13((byte)(uVar6 >> 0x18) |
                                                                 (byte)(uVar10 >> 0x18),
                                                                 CONCAT12((byte)(uVar6 >> 0x10) |
                                                                          (byte)(uVar10 >> 0x10),
                                                                          CONCAT11((byte)(uVar6 >> 8
                                                                                         ) | (byte)(
                                                  uVar10 >> 8),(byte)uVar6 | (byte)uVar10))))))),
                    DAT_00100b30,4);
  return (uVar1 | uVar1 << 1) & 0xdddddddd | (uVar2 << 2 | uVar2 << 1) & 0xbbbbbbbb |
         ((uVar4 << 2 | uVar4 << 1) & 0xbbbbbbbb | (uVar3 | uVar3 << 1) & 0xdddddddd) << 8 |
         (uint)uVar9 | (uint)((ulong)uVar9 >> 0x20);
}

