
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

uint kernel(uint p0,uint p1)

{
  uint uVar1;
  uint uVar2;
  uint uVar3;
  
  uVar1 = (p1 & 0xff) + (p0 & 0xffff);
  uVar2 = (uVar1 * 0x400 & 0xfc00) + (uVar1 & 0xffff);
  uVar3 = ((uVar1 >> 0x10) + (p0 >> 0x10)) * 0x401 + ((uVar1 & 0xffff) >> 6) + (uVar2 >> 0x10);
  uVar1 = ((uVar2 >> 6 & 0x3ff | uVar3 * 0x400 & 0xfc00) ^ uVar2 & 0xffff) + (p1 >> 8 & 0xff);
  uVar2 = (uVar1 * 0x400 & 0xfc00) + (uVar1 & 0xffff);
  uVar3 = ((uVar3 ^ (uVar3 & 0xffc0) >> 6) + (uVar1 >> 0x10)) * 0x401 + ((uVar1 & 0xffff) >> 6) +
          (uVar2 >> 0x10);
  uVar1 = ((uVar2 >> 6 & 0x3ff | uVar3 * 0x400 & 0xfc00) ^ uVar2 & 0xffff) + (p1 >> 0x10 & 0xff);
  uVar2 = (uVar1 * 0x400 & 0xfc00) + (uVar1 & 0xffff);
  uVar1 = ((uVar3 ^ (uVar3 & 0xffc0) >> 6) + (uVar1 >> 0x10)) * 0x401 + ((uVar1 & 0xffff) >> 6) +
          (uVar2 >> 0x10);
  uVar2 = ((uVar2 >> 6 & 0x3ff | uVar1 * 0x400 & 0xfc00) ^ uVar2 & 0xffff) + (p1 >> 0x18);
  uVar3 = (uVar2 * 0x400 & 0xfc00) + (uVar2 & 0xffff);
  uVar1 = ((uVar1 ^ (uVar1 & 0xffc0) >> 6) + (uVar2 >> 0x10)) * 0x401 + ((uVar2 & 0xffff) >> 6) +
          (uVar3 >> 0x10);
  uVar3 = (uVar3 >> 6 & 0x3ff | uVar1 * 0x400 & 0xfc00) ^ uVar3 & 0xffff;
  uVar2 = (uVar3 & 0x1fff) * 8 + uVar3;
  uVar1 = (uVar1 ^ (uVar1 & 0xffc0) >> 6) * 9 + (uVar3 >> 0xd) + (uVar2 >> 0x10);
  uVar2 = (uVar2 >> 0xb & 0x1f | uVar1 * 0x20 & 0xffe0) ^ uVar2 & 0xffff;
  return (uVar2 & 1) * 0x8000 + uVar2 +
         ((uVar1 ^ (uVar1 & 0xf800) >> 0xb) * 0x8001 + (uVar2 >> 1)) * 0x10000;
}

