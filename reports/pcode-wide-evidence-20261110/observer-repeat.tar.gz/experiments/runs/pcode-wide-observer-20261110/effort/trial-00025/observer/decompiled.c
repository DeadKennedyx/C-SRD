
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

uint kernel(uint p0,uint p1)

{
  uint uVar1;
  uint uVar2;
  uint uVar3;
  uint uVar4;
  uint uVar5;
  uint uVar6;
  uint uVar7;
  uint uVar8;
  
  uVar6 = p1 >> 0xc & 0xf;
  uVar8 = p0 >> 0xc & 0xf;
  uVar5 = p1 >> 4 & 0xf;
  uVar7 = p0 >> 4 & 0xf;
  uVar6 = (uVar6 | uVar6 << 2) & 0x33;
  uVar4 = p1 >> 8 & 0xf;
  uVar8 = (uVar8 | uVar8 << 2) & 0x33;
  uVar5 = (uVar5 | uVar5 << 2) & 0x33;
  uVar3 = p0 >> 8 & 0xf;
  uVar7 = (uVar7 | uVar7 << 2) & 0x33;
  uVar1 = (p1 & 0xf | (p1 & 0xf) << 2) & 0x33;
  uVar4 = (uVar4 | uVar4 << 2) & 0x33;
  uVar2 = (p0 & 0xf | (p0 & 0xf) << 2) & 0x33;
  uVar3 = (uVar3 | uVar3 << 2) & 0x33;
  return (((uVar6 | uVar6 << 1) & 0x55) << 1 | (uVar8 | uVar8 << 1) & 0x55) << 0x18 |
         (((uVar5 | uVar5 << 1) & 0x55) << 1 | (uVar7 | uVar7 << 1) & 0x55) << 8 |
         ((uVar1 | uVar1 << 1) & 0x55) << 1 | (uVar2 | uVar2 << 1) & 0x55 |
         (((uVar4 | uVar4 << 1) & 0x55) << 1 | (uVar3 | uVar3 << 1) & 0x55) << 0x10;
}

