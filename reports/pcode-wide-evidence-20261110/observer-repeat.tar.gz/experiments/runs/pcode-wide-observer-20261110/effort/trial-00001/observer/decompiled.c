
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

uint kernel(uint p0,uint p1)

{
  uint uVar1;
  uint uVar2;
  uint uVar3;
  uint uVar4;
  uint uVar5;
  uint uVar6;
  uint uVar7;
  uint uVar8;
  uint uVar9;
  uint uVar10;
  uint uVar11;
  uint uVar12;
  uint uVar13;
  uint uVar14;
  
  uVar1 = p0 ^ p1 ^ 0xffffffff;
  uVar2 = p0 >> 8 ^ 0xffffffff;
  uVar3 = p0 >> 0x10 ^ 0xffffffff;
  uVar8 = -(uVar1 & 1);
  uVar9 = -(uVar1 >> 1 & 1);
  uVar4 = ((uVar2 & 1) << 7 | uVar1 >> 1 & 0x7f) ^ (uVar1 & 1) << 5;
  uVar2 = uVar8 & 0x83 ^ (uVar2 >> 1 & 0x7f | (uVar3 & 1) << 7);
  uVar5 = uVar8 & 0xb8 ^ (~p0 >> 0x11 & 0x80 | uVar3 >> 1 & 0x7f);
  uVar8 = uVar8 & 0xed ^ ~p0 >> 0x19;
  uVar1 = (uVar4 >> 1 | (uVar2 & 1) << 7) ^ (uVar1 & 2) << 4;
  uVar7 = uVar5 >> 1;
  uVar2 = (uVar2 >> 1 | (uVar3 >> 1 & 1) << 7) ^ uVar9 & 0x83;
  uVar10 = -(uVar4 >> 1 & 1);
  uVar6 = uVar9 & 0xed ^ uVar8 >> 1;
  uVar4 = (uVar1 >> 1 | uVar2 << 7) & 0xfe ^ (uVar4 >> 1 & 1) << 5;
  uVar2 = (uVar2 >> 1 | (uVar7 & 1) << 7) ^ uVar10 & 0x83;
  uVar11 = -(uVar1 >> 1 & 1);
  uVar8 = (((uVar7 | (uVar8 & 1) << 7) ^ uVar9 & 0xb8) >> 1 | (uVar6 & 1) << 7) ^ uVar10 & 0xb8;
  uVar6 = uVar10 & 0xed ^ uVar6 >> 1;
  uVar1 = (uVar4 >> 1 | (uVar2 & 1) << 7) ^ (uVar1 >> 1 & 1) << 5;
  uVar2 = (uVar2 >> 1 | (uVar3 >> 3 & 1) << 7) ^ uVar11 & 0x83;
  uVar12 = -(uVar4 >> 1 & 1);
  uVar3 = (uVar8 >> 1 | (uVar6 & 1) << 7) ^ uVar11 & 0xb8;
  uVar10 = uVar3 >> 1;
  uVar6 = uVar11 & 0xed ^ uVar6 >> 1;
  uVar4 = (uVar1 >> 1 | uVar2 << 7) & 0xfe ^ (uVar4 >> 1 & 1) << 5;
  uVar2 = (uVar2 >> 1 | (uVar5 >> 3 & 1) << 7) ^ uVar12 & 0x83;
  uVar5 = uVar12 & 0xed ^ uVar6 >> 1;
  uVar11 = -(uVar1 >> 1 & 1);
  uVar1 = (uVar4 >> 1 | (uVar2 & 1) << 7) ^ (uVar1 >> 1 & 1) << 5;
  uVar2 = (uVar2 >> 1 | (uVar10 & 1) << 7) ^ uVar11 & 0x83;
  uVar7 = uVar11 & 0xed ^ uVar5 >> 1;
  uVar13 = -(uVar4 >> 1 & 1);
  uVar8 = (uVar2 >> 1 | (uVar8 >> 3 & 1) << 7) ^ uVar13 & 0x83;
  uVar9 = uVar13 & 0xed ^ uVar7 >> 1;
  uVar14 = -(uVar1 >> 1 & 1);
  return ((((uVar1 >> 1 | uVar2 << 7) & 0xfe ^ (uVar4 >> 1 & 1) << 5) >> 1 | (uVar8 & 1) << 7) ^
          (uVar1 >> 1 & 1) << 5 | ((uVar8 >> 1 | (uVar3 >> 3 & 1) << 7) ^ uVar14 & 0x83) << 8 |
          (uVar14 & 0xed ^ uVar9 >> 1 ^ 0xffffffff) << 0x18 |
         ((((((((uVar10 | (uVar6 & 1) << 7) ^ uVar12 & 0xb8) >> 1 | uVar5 << 7) & 0xfc ^
             uVar11 & 0xb8) >> 1 | (uVar7 & 1) << 7) ^ uVar13 & 0xb8) >> 1 | (uVar9 & 1) << 7) ^
         uVar14 & 0xb8) << 0x10 ^ 0xff0000) ^ 0xffff;
}

