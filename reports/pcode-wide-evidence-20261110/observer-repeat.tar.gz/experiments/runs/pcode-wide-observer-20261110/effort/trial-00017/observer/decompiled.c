
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

uint kernel(uint p0,uint p1)

{
  uint uVar1;
  uint uVar2;
  uint uVar3;
  uint uVar4;
  uint uVar5;
  uint uVar6;
  uint uVar7;
  
  uVar1 = (p1 & 0xff) + (p0 & 0xff);
  uVar3 = (p0 >> 8 & 0xff) + (uVar1 >> 8);
  uVar6 = uVar1 >> 6 & 3;
  uVar2 = (uVar1 * 4 & 0xfc) + (uVar3 & 0xff);
  uVar4 = (p0 >> 0x10 & 0xff) + (uVar3 >> 8);
  uVar5 = (uVar3 * 4 & 0xfc | uVar6) + (uVar2 >> 8) + (uVar4 & 0xff);
  uVar1 = (p1 >> 8 & 0xff) + (((uVar2 * 4 & 0x3fc | uVar6) ^ uVar1) & 0xff);
  uVar6 = (uVar4 * 4 & 0xfc | uVar3 >> 6 & 3) + (uVar5 >> 8) + (uVar4 >> 8) + (p0 >> 0x18);
  uVar2 = (uVar1 >> 8) + (((uVar2 >> 6 & 3 | uVar5 * 4 & 0x3fc) ^ uVar2) & 0xff);
  uVar7 = uVar1 >> 6 & 3;
  uVar3 = (uVar1 * 4 & 0xfc) + (uVar2 & 0xff);
  uVar4 = (uVar2 >> 8) + (((uVar5 >> 6 & 3 | uVar6 * 4 & 0x3fc) ^ uVar5) & 0xff);
  uVar5 = (uVar2 * 4 & 0xfc | uVar7) + (uVar4 & 0xff) + (uVar3 >> 8);
  uVar1 = (p1 >> 0x10 & 0xff) + (((uVar3 * 4 & 0x3fc | uVar7) ^ uVar1) & 0xff);
  uVar6 = (uVar4 * 4 & 0xfc | uVar2 >> 6 & 3) + (uVar5 >> 8) +
          (uVar6 >> 6 & 3 ^ uVar6 & 0xff) + (uVar4 >> 8);
  uVar2 = (uVar1 >> 8) + (((uVar3 >> 6 & 3 | uVar5 * 4 & 0x3fc) ^ uVar3) & 0xff);
  uVar7 = uVar1 >> 6 & 3;
  uVar3 = (uVar1 * 4 & 0xfc) + (uVar2 & 0xff);
  uVar4 = (uVar2 >> 8) + (((uVar5 >> 6 & 3 | uVar6 * 4 & 0x3fc) ^ uVar5) & 0xff);
  uVar5 = (uVar2 * 4 & 0xfc | uVar7) + (uVar4 & 0xff) + (uVar3 >> 8);
  uVar1 = (p1 >> 0x18) + (((uVar3 * 4 & 0x3fc | uVar7) ^ uVar1) & 0xff);
  uVar6 = (uVar4 * 4 & 0xfc | uVar2 >> 6 & 3) + (uVar5 >> 8) +
          (uVar6 >> 6 & 3 ^ uVar6 & 0xff) + (uVar4 >> 8);
  uVar2 = (uVar1 >> 8) + (((uVar3 >> 6 & 3 | uVar5 * 4 & 0x3fc) ^ uVar3) & 0xff);
  uVar7 = uVar1 >> 6 & 3;
  uVar3 = (uVar1 * 4 & 0xfc) + (uVar2 & 0xff);
  uVar4 = (uVar2 >> 8) + (((uVar5 >> 6 & 3 | uVar6 * 4 & 0x3fc) ^ uVar5) & 0xff);
  uVar5 = (uVar2 * 4 & 0xfc | uVar7) + (uVar4 & 0xff) + (uVar3 >> 8);
  uVar1 = (uVar3 * 4 & 0x3fc | uVar7) ^ uVar1;
  uVar3 = (uVar3 >> 6 & 3 | uVar5 * 4 & 0x3fc) ^ uVar3;
  uVar4 = (uVar4 * 4 & 0xfc | uVar2 >> 6 & 3) + (uVar5 >> 8) +
          (uVar6 >> 6 & 3 ^ uVar6 & 0xff) + (uVar4 >> 8);
  uVar2 = (uVar1 & 0x1f) * 8 + (uVar1 & 0xff);
  uVar5 = (uVar5 >> 6 & 3 | uVar4 * 4 & 0x3fc) ^ uVar5;
  uVar6 = ((uVar3 & 0x1f) << 3 | uVar1 >> 5 & 7) + (uVar2 >> 8) + (uVar3 & 0xff);
  uVar4 = uVar4 >> 6 & 3 ^ uVar4 & 0xff;
  uVar1 = ((uVar5 & 0x1f) << 3 | uVar3 >> 5 & 7) + (uVar6 >> 8) + (uVar5 & 0xff);
  uVar3 = uVar4 + (uVar5 >> 5 & 7 | (uVar4 & 0x1f) << 3) + (uVar1 >> 8);
  uVar2 = (uVar6 >> 3 & 0x1f | uVar1 * 0x20 & 0x1fe0) ^ uVar2;
  uVar6 = (uVar1 >> 3 & 0x1f | uVar3 * 0x20 & 0x1fe0) ^ uVar6;
  uVar5 = uVar3 >> 3 & 0x1f ^ uVar1 & 0xff;
  uVar1 = (uVar2 & 1) * 0x80 + (uVar6 & 0xff);
  uVar4 = ((uVar6 & 1) << 7 | uVar2 >> 1 & 0x7f) + uVar5 + (uVar1 >> 8);
  return uVar4 * 0x10000 & 0xff0000 |
         ((uVar6 >> 1 & 0x7f | (uVar5 & 1) << 7) + (uVar3 & 0xff) + (uVar4 >> 8)) * 0x1000000 |
         uVar1 * 0x100 & 0xff00 | uVar2 & 0xff;
}

