unsigned int kernel(unsigned int p0) {
    unsigned int v0 = (p0 >> 8u);
    unsigned int v1 = (v0 & 255u);
    unsigned int v2 = (p0 & 255u);
    unsigned int v3 = (p0 >> 16u);
    unsigned int v4 = (v3 & 255u);
    unsigned int v5 = (v1 * 150u);
    unsigned int v6 = (v4 * 77u);
    unsigned int v7 = (v5 + v6);
    unsigned int v8 = (v2 * 29u);
    unsigned int v9 = (v7 + v8);
    unsigned int v10 = (v9 >> 8u);
    (void)p0;
    return v10;
}
