
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

uint kernel(uint p0)

{
  uint uVar1;
  uint uVar2;
  uint uVar3;
  uint uVar4;
  
  uVar2 = (p0 >> 8 & 0xff) * 0x96;
  uVar3 = (p0 & 0xff) * 0x1d;
  uVar4 = (p0 >> 0x10 & 0xff) * 0x4d;
  uVar1 = (uVar2 & 0xfe) + (uVar4 & 0xff);
  return (uVar2 >> 8) + (uVar3 >> 8) + (uVar4 >> 8) + (uVar1 >> 8) +
         ((uVar1 & 0xff) + (uVar3 & 0xff) >> 8);
}

