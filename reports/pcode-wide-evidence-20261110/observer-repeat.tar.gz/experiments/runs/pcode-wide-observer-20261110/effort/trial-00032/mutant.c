unsigned int kernel(unsigned int p0) {
    unsigned int v0 = (p0 >> 8u);
    unsigned int v1 = (v0 & 255u);
    unsigned int v2 = (p0 >> 16u);
    unsigned int v3 = (v2 & 255u);
    unsigned int v4 = (v1 * 150u);
    unsigned int v5 = (p0 & 255u);
    unsigned int v6 = (v5 * 29u);
    unsigned int v7 = (v3 * 77u);
    unsigned int v8 = (v4 >> 8u);
    unsigned int v9 = (v4 & 254u);
    unsigned int v10 = (v6 >> 8u);
    unsigned int v11 = (v8 + v10);
    unsigned int v12 = (v7 & 255u);
    unsigned int v13 = (v9 + v12);
    unsigned int v14 = (v7 >> 8u);
    unsigned int v15 = (v11 + v14);
    unsigned int v16 = (v13 & 255u);
    unsigned int v17 = (v6 & 255u);
    unsigned int v18 = (v16 + v17);
    unsigned int v19 = (v13 >> 8u);
    unsigned int v20 = (v15 + v19);
    unsigned int v21 = (v18 >> 8u);
    unsigned int v22 = (v20 + v21);
    (void)p0;
    return (v22 + 1u);
}
