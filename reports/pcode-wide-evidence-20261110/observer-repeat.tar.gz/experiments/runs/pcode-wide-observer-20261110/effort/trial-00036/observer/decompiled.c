
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

uint kernel(uint p0)

{
  uint uVar1;
  uint uVar2;
  uint uVar3;
  uint uVar4;
  uint uVar5;
  uint uVar6;
  uint uVar7;
  
  uVar5 = (p0 >> 0x10 & 0xf) * 0x4d;
  uVar6 = (p0 & 0xf) * 0x1d;
  uVar7 = (p0 >> 8 & 0xf) * 0x96;
  uVar1 = (uVar5 & 0xf) + (uVar7 & 0xf);
  uVar2 = (uVar5 >> 4) + (p0 >> 0x14 & 0xf) * 0x4d;
  uVar3 = (uVar6 >> 4) + (p0 >> 4 & 0xf) * 0x1d;
  uVar4 = (uVar7 >> 4) + (p0 >> 0xc & 0xf) * 0x96;
  uVar5 = (uVar2 & 0xf) + (uVar4 & 0xf) + (uVar1 >> 4);
  uVar7 = (uVar2 >> 4 & 0xf) + (uVar4 >> 4 & 0xf) + (uVar5 >> 4);
  uVar1 = (uVar7 & 0xf) +
          ((uVar3 & 0xf) + ((uVar1 & 0xf) + (uVar6 & 0xf) >> 4) + (uVar5 & 0xf) >> 4) +
          (uVar3 >> 4 & 0xf);
  return uVar1 & 0xf |
         ((uVar3 >> 8) + (uVar7 >> 4) + (uVar4 >> 8) + (uVar2 >> 8) + (uVar1 >> 4)) * 0x10;
}

