
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

uint kernel(uint p0,uint p1)

{
  uint uVar1;
  uint uVar2;
  
  uVar1 = ((p1 & 0xffff) << 8 | p1 & 0xffff) & 0xff00ff;
  uVar2 = ((p0 & 0xffff) << 8 | p0 & 0xffff) & 0xff00ff;
  uVar1 = (uVar1 | uVar1 << 4) & 0xf0f0f0f;
  uVar2 = (uVar2 | uVar2 << 4) & 0xf0f0f0f;
  uVar1 = (uVar1 | uVar1 << 2) & 0x33333333;
  uVar2 = (uVar2 | uVar2 << 2) & 0x33333333;
  return ((uVar1 | uVar1 << 1) & 0x55555555) << 1 | (uVar2 | uVar2 << 1) & 0x55555555;
}

