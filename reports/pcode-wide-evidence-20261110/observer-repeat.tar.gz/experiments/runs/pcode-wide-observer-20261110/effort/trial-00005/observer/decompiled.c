
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

uint kernel(uint p0,uint p1)

{
  uint uVar1;
  uint uVar2;
  uint uVar3;
  uint uVar4;
  uint uVar5;
  uint uVar6;
  uint uVar7;
  uint uVar8;
  uint uVar9;
  
  uVar1 = p0 ^ p1 ^ 0xffffffff;
  uVar2 = p0 >> 0x18 ^ 0xff;
  uVar9 = -(uVar1 & 1);
  uVar7 = uVar1 >> 1;
  uVar3 = uVar9 & 0xed ^ uVar2 >> 1;
  uVar2 = (~(p0 >> 0x10) >> 1 & 0x7f | (uVar2 & 1) << 7) ^ uVar9 & 0xb8;
  uVar9 = ((~(p0 >> 0x10) & 1) << 7 | ~(p0 >> 8) >> 1 & 0x7f) ^ uVar9 & 0x83;
  uVar5 = -(uVar7 & 1);
  uVar4 = uVar5 & 0xed ^ uVar3 >> 1;
  uVar1 = (((~(p0 >> 8) & 1) << 7 | uVar7 & 0x7f) ^ (uVar1 & 1) << 5) >> 1;
  uVar3 = ((uVar3 & 1) << 7 | uVar2 >> 1) ^ uVar5 & 0xb8;
  uVar5 = ((uVar2 & 1) << 7 | uVar9 >> 1) ^ uVar5 & 0x83;
  uVar6 = -(uVar1 & 1);
  uVar8 = ((uVar4 & 1) << 7 | uVar3 >> 1) ^ uVar6 & 0xb8;
  uVar4 = uVar6 & 0xed ^ uVar4 >> 1;
  uVar2 = (((uVar9 & 1) << 7 | uVar1) ^ (uVar7 & 1) << 5) >> 1;
  uVar3 = ((uVar3 & 1) << 7 | uVar5 >> 1) ^ uVar6 & 0x83;
  uVar7 = -(uVar2 & 1);
  uVar1 = (((uVar5 & 1) << 7 | uVar2) ^ (uVar1 & 1) << 5) >> 1;
  uVar9 = ((uVar8 & 1) << 7 | uVar3 >> 1) ^ uVar7 & 0x83;
  uVar5 = ((uVar4 & 1) << 7 | uVar8 >> 1) ^ uVar7 & 0xb8;
  uVar4 = uVar7 & 0xed ^ uVar4 >> 1;
  uVar7 = -(uVar1 & 1);
  uVar2 = (((uVar3 & 1) << 7 | uVar1) ^ (uVar2 & 1) << 5) >> 1;
  uVar3 = uVar7 & 0xed ^ uVar4 >> 1;
  uVar8 = ((uVar5 & 1) << 7 | uVar9 >> 1) ^ uVar7 & 0x83;
  uVar4 = ((uVar4 & 1) << 7 | uVar5 >> 1) ^ uVar7 & 0xb8;
  uVar7 = -(uVar2 & 1);
  uVar5 = uVar7 & 0xed ^ uVar3 >> 1;
  uVar1 = (((uVar9 & 1) << 7 | uVar2) ^ (uVar1 & 1) << 5) >> 1;
  uVar3 = ((uVar3 & 1) << 7 | uVar4 >> 1) ^ uVar7 & 0xb8;
  uVar9 = ((uVar4 & 1) << 7 | uVar8 >> 1) ^ uVar7 & 0x83;
  uVar7 = -(uVar1 & 1);
  uVar4 = ((uVar5 & 1) << 7 | uVar3 >> 1) ^ uVar7 & 0xb8;
  uVar5 = uVar7 & 0xed ^ uVar5 >> 1;
  uVar2 = (((uVar8 & 1) << 7 | uVar1) ^ (uVar2 & 1) << 5) >> 1;
  uVar3 = ((uVar3 & 1) << 7 | uVar9 >> 1) ^ uVar7 & 0x83;
  uVar8 = -(uVar2 & 1);
  return (((uVar4 & 1) << 7 | uVar3 >> 1) ^ uVar8 & 0x83) << 8 ^ 0xff00 |
         (((uVar5 & 1) << 7 | uVar4 >> 1) ^ uVar8 & 0xb8) << 0x10 ^ 0xff0000 |
         ((uVar3 & 1) << 7 | (((uVar9 & 1) << 7 | uVar2) ^ (uVar1 & 1) << 5) >> 1) ^ uVar8 & 0x20 ^
         0xff | (uVar8 & 0xed ^ uVar5 >> 1) << 0x18 ^ 0xff000000;
}

