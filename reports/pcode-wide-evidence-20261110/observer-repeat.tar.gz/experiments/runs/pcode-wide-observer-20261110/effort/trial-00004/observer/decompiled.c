
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

uint kernel(uint p0,uint p1)

{
  uint uVar1;
  uint uVar2;
  uint uVar3;
  uint uVar4;
  uint uVar5;
  uint uVar6;
  uint uVar7;
  uint uVar8;
  uint uVar9;
  uint uVar10;
  uint uVar11;
  uint uVar12;
  
  uVar12 = p0 & 0xffff ^ p1 & 0xff ^ 0xffff;
  uVar6 = -(uVar12 >> 1 & 1);
  uVar1 = -(uVar12 & 1) & 0x76dc ^ ~p0 >> 0x12;
  uVar2 = -(uVar12 & 1) & 0x832 ^ (uVar12 | (p0 ^ 0xffffffff) & 0x10000) >> 5;
  uVar7 = -(uVar12 >> 2 & 1);
  uVar4 = uVar1 << 0xd;
  uVar1 = uVar1 ^ uVar6 & 0xedb8;
  uVar6 = (uVar2 | ~p0 >> 5 & 0x1000) ^ uVar6 & 0x1064;
  uVar8 = -(uVar12 >> 3 & 1);
  uVar3 = uVar7 & 0xedb8 ^ uVar1 >> 1;
  uVar5 = uVar3 >> 1;
  uVar9 = -(uVar12 >> 4 & 1);
  uVar10 = -(uVar12 >> 5 & 1);
  uVar11 = -(uVar2 >> 1 & 1);
  uVar2 = uVar9 >> 2 & 0x3b6e ^ (uVar5 ^ uVar8 & 0xedb8) >> 3;
  uVar12 = 0xffff;
  if ((uVar6 & 4) != 0) {
    uVar12 = 0x1247;
  }
  return ((((((((((uVar4 & 0x2000 | uVar6) ^ uVar7 & 0x20c8 | uVar4 & 0x4000) ^ uVar8 & 0x4190 |
                uVar5 << 0xf) & 0xfffc ^ uVar9 & 0x8320) >> 1 | (uVar1 >> 3 & 1) << 0xf) ^
             uVar10 & 0x8320) >> 1 | (uVar3 >> 3 & 1) << 0xf) ^ uVar11 & 0x8320) >> 1 |
          (uVar2 & 1) << 0xf) ^ (int)(uVar6 << 0x1d) >> 0x1f & 0x8320U |
         (uVar12 ^ (uVar2 ^ uVar10 & 0x76dc ^ uVar11 & 0xedb8) >> 1) << 0x10) ^ 0xffff;
}

