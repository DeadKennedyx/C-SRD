unsigned int kernel(unsigned int p0) {
    unsigned int v0 = (p0 >> 16u);
    unsigned int v3 = (p0 ^ v0);
    unsigned int v4 = (v3 >> 8u);
    unsigned int v6 = (v3 ^ v4);
    unsigned int v7 = (v6 >> 4u);
    unsigned int v9 = (v6 ^ v7);
    unsigned int v10 = (v9 >> 2u);
    unsigned int v12 = (v9 ^ v10);
    unsigned int v13 = (v12 >> 1u);
    unsigned int v15 = (v12 ^ v13);
    unsigned int v16 = (v15 & 1u);
    unsigned int v19 = v16;
    (void)p0;
    return v19;
}
