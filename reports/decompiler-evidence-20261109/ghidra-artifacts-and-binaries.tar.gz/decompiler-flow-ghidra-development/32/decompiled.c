
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

uint kernel(uint p0)

{
  uint uVar1;
  
  uVar1 = p0 ^ p0 >> 0x10;
  uVar1 = uVar1 ^ uVar1 >> 8;
  uVar1 = uVar1 ^ uVar1 >> 4;
  uVar1 = uVar1 ^ uVar1 >> 2;
  return (uVar1 ^ uVar1 >> 1) & 1;
}

