unsigned int kernel(unsigned int p0, unsigned int p1) {
    unsigned int v1 = (p0 * 6561u);
    unsigned int v2 = (p1 * 820u);
    unsigned int v0 = (v1 + v2);
    unsigned int v7 = (v0 + 102u);
    unsigned int v10 = v7;
    (void)p0;
    (void)p1;
    return v10;
}
