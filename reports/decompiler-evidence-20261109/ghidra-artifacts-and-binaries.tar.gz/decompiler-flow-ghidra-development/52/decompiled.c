
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

uint kernel(uint p0,uint p1)

{
  uint uVar1;
  
  uVar1 = p1 + 4;
  do {
    p0 = p0 * 9 + p1;
    p1 = p1 + 1;
  } while (p1 != uVar1);
  return p0;
}

