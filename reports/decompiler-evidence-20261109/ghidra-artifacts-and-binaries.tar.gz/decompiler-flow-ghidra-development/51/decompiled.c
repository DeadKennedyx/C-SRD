
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

uint kernel(uint p0,uint p1)

{
  int iVar1;
  uint uVar2;
  
  uVar2 = p0 * 0x77d71e59 + 0x10937c47;
  iVar1 = uVar2 * 9 + 0x7b641dc8;
  if ((uVar2 & 1) != 0) {
    iVar1 = p0 * 0x36901121 + 0x10937c47;
  }
  return p1 * 0x334 + iVar1 * -0x129f877f + 0x2dcd189f;
}

