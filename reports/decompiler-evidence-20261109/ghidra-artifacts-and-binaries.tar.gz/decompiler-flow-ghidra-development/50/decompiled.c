
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

uint kernel(uint p0,uint p1)

{
  return p1 * 0x334 + p0 * 0x19a1 + 0x66;
}

