unsigned int kernel(unsigned int p0, unsigned int p1) {
    unsigned int v3 = (p0 * 6561u);
    unsigned int v4 = (p1 * 820u);
    unsigned int v1 = (v3 + v4);
    unsigned int v0 = (v1 + 102u);
    unsigned int v10 = v0;
    (void)p0;
    (void)p1;
    return v10;
}
