
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

uint kernel(uint p0,uint p1)

{
  int iVar1;
  uint uVar2;
  
  uVar2 = p1 * 0x77d71e59 + 0x10937c47;
  iVar1 = uVar2 * 0xd + 0x39162cac;
  if ((uVar2 & 1) != 0) {
    iVar1 = p1 * 0x15ec8a85 + 0x10937c47;
  }
  return iVar1 * 0x251ecad1 + p0 * -0xb7 + 0x44358418;
}

