unsigned int kernel(unsigned int p0, unsigned int p1) {
    unsigned int v0 = (p0 * 4294967113u);
    unsigned int v4 = (p1 * 2197u);
    unsigned int v3 = (v4 + 15u);
    unsigned int v6 = (v0 + v3);
    unsigned int v10 = v6;
    (void)p0;
    (void)p1;
    return (v10 + 1u);
}
