
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

uint kernel(uint p0)

{
  return (p0 >> 0x13 | p0 << 0xd) * 7 - 0x1f;
}

