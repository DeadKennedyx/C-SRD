
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

uint kernel(uint p0)

{
  int iVar1;
  uint uVar2;
  uint uVar3;
  
  uVar3 = p0 >> 0x13 | p0 << 0xd;
  uVar2 = uVar3 * 0x77d71e59 + 0x10937c47;
  iVar1 = uVar2 * 7 + -0x6374e9aa;
  if ((uVar2 & 1) != 0) {
    iVar1 = uVar3 * 0x46e1d46f + 0x10937c47;
  }
  return iVar1 * -0x63c1b617 + 0x7e21a442;
}

