unsigned int kernel(unsigned int p0) {
    unsigned int v4 = (p0 >> 24u);
    unsigned int v0 = (p0 & 255u);
    unsigned int v3 = (v4 + v0);
    unsigned int v7 = (p0 >> 8u);
    unsigned int v6 = (v7 & 255u);
    unsigned int v9 = (v3 + v6);
    unsigned int v12 = (p0 >> 16u);
    unsigned int v11 = (v12 & 255u);
    unsigned int v14 = (v9 + v11);
    unsigned int v17 = v14;
    (void)p0;
    return v17;
}
