
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

uint kernel(uint p0)

{
  return (p0 >> 0x18) + (p0 & 0xff) + (p0 >> 8 & 0xff) + (p0 >> 0x10 & 0xff);
}

