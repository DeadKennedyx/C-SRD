
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

uint kernel(uint p0,uint p1)

{
  return p0 * -0xb7 + p1 * 0x895 + 0xf;
}

