; ModuleID = '/work/experiments/runs/decompiler-flow-linux-development-v2/bounded_arithmetic/build-clang-O2-native-affine-42-split-scale/validation/compiler-0-O2/candidate.i'
source_filename = "/work/experiments/runs/decompiler-flow-linux-development-v2/bounded_arithmetic/build-clang-O2-native-affine-42-split-scale/validation/compiler-0-O2/candidate.i"
target datalayout = "e-m:e-i8:8:32-i16:16:32-i64:64-i128:128-n32:64-S128"
target triple = "aarch64-unknown-linux-gnu"

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local i32 @kernel(i32 noundef %0, i32 noundef %1) local_unnamed_addr #0 {
  %3 = mul i32 %0, 2010586713
  %4 = add i32 %3, 278101063
  %5 = and i32 %4, 1
  %6 = icmp eq i32 %5, 0
  %7 = mul i32 %0, 915411233
  %8 = add i32 %7, 278101063
  %9 = mul i32 %4, 9
  %10 = add i32 %9, 2070158792
  %11 = select i1 %6, i32 %10, i32 %8
  %12 = mul i32 %1, 2010586713
  %13 = add i32 %11, %12
  %14 = mul i32 %13, 9
  %15 = add i32 %12, 2070158792
  %16 = add i32 %15, %14
  %17 = add i32 %16, 2010586713
  %18 = and i32 %17, 1
  %19 = icmp eq i32 %18, 0
  %20 = mul i32 %16, 9
  %21 = add i32 %20, -1309397271
  %22 = mul i32 %17, 9
  %23 = add i32 %22, 2070158792
  %24 = select i1 %19, i32 %23, i32 %21
  %25 = add i32 %24, %12
  %26 = mul i32 %25, 9
  %27 = add i32 %26, %12
  %28 = mul i32 %27, -1673639447
  %29 = add i32 %28, 1865336702
  ret i32 %29
}

attributes #0 = { mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable "frame-pointer"="non-leaf" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+fp-armv8,+neon,+outline-atomics,-fmv" }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 1, !"wchar_size", i32 4}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 1}
!5 = !{!"Ubuntu clang version 18.1.3 (1ubuntu1)"}
