; ModuleID = '/work/experiments/runs/decompiler-flow-linux-development-v2/bounded_arithmetic/build-clang-O1-sanitizers-affine-42-split-scale/validation/compiler-0-O1/candidate.i'
source_filename = "/work/experiments/runs/decompiler-flow-linux-development-v2/bounded_arithmetic/build-clang-O1-sanitizers-affine-42-split-scale/validation/compiler-0-O1/candidate.i"
target datalayout = "e-m:e-i8:8:32-i16:16:32-i64:64-i128:128-n32:64-S128"
target triple = "aarch64-unknown-linux-gnu"

$asan.module_ctor = comdat any

@llvm.used = appending global [1 x ptr] [ptr @asan.module_ctor], section "llvm.metadata"
@___asan_globals_registered = common hidden global i64 0
@__start_asan_globals = extern_weak hidden global i64
@__stop_asan_globals = extern_weak hidden global i64
@llvm.global_ctors = appending global [1 x { i32, ptr, ptr }] [{ i32, ptr, ptr } { i32 1, ptr @asan.module_ctor, ptr @asan.module_ctor }]

; Function Attrs: mustprogress nofree norecurse nosync nounwind sanitize_address willreturn memory(none) uwtable
define dso_local i32 @kernel(i32 noundef %x, i32 noundef %y) local_unnamed_addr #0 !func_sanitize !6 {
entry:
  %mul = mul i32 %x, 2010586713
  %add = add i32 %mul, 278101063
  %and = and i32 %add, 1
  %cmp.not = icmp eq i32 %and, 0
  %0 = mul i32 %x, 915411233
  %add3 = add i32 %0, 278101063
  %mul4 = mul i32 %add, 9
  %add5 = add i32 %mul4, 2070158792
  %csrd_value_1.0 = select i1 %cmp.not, i32 %add5, i32 %add3
  %mul6 = mul i32 %y, 2010586713
  %sub9 = add i32 %csrd_value_1.0, %mul6
  %csrd_value_5.0.in = mul i32 %sub9, 9
  %csrd_value_5.0 = add i32 %mul6, 2070158792
  %sub24 = add i32 %csrd_value_5.0, %csrd_value_5.0.in
  %sub26 = add i32 %sub24, 2010586713
  %and27 = and i32 %sub26, 1
  %cmp28.not = icmp eq i32 %and27, 0
  %1 = mul i32 %sub24, 9
  %add33 = add i32 %1, -1309397271
  %mul35 = mul i32 %sub26, 9
  %add36 = add i32 %mul35, 2070158792
  %csrd_value_8.0 = select i1 %cmp28.not, i32 %add36, i32 %add33
  %sub39 = add i32 %csrd_value_8.0, %mul6
  %csrd_value_11.0.in = mul i32 %sub39, 9
  %add7 = add i32 %csrd_value_11.0.in, %mul6
  %2 = mul i32 %add7, -1673639447
  %mul58 = add i32 %2, 1865336702
  ret i32 %mul58
}

declare void @__asan_register_elf_globals(i64, i64, i64)

declare void @__asan_init()

; Function Attrs: nounwind uwtable
define internal void @asan.module_ctor() #1 comdat {
  call void @__asan_init()
  call void @__asan_version_mismatch_check_v8()
  call void @__asan_register_elf_globals(i64 ptrtoint (ptr @___asan_globals_registered to i64), i64 ptrtoint (ptr @__start_asan_globals to i64), i64 ptrtoint (ptr @__stop_asan_globals to i64))
  ret void
}

declare void @__asan_version_mismatch_check_v8()

attributes #0 = { mustprogress nofree norecurse nosync nounwind sanitize_address willreturn memory(none) uwtable "frame-pointer"="non-leaf" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+fp-armv8,+neon,+outline-atomics,+v8a,-fmv" }
attributes #1 = { nounwind uwtable "frame-pointer"="non-leaf" }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 1, !"wchar_size", i32 4}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 1}
!5 = !{!"Ubuntu clang version 18.1.3 (1ubuntu1)"}
!6 = !{i32 -1056584962, i32 -455559067}
