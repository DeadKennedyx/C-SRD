#include <stdint.h>
uint32_t kernel(uint32_t x, uint32_t y) { unsigned int csrd_value_0 = ((2010586713u * (x)) + 278101063u); unsigned int csrd_value_1 = ((9u * (csrd_value_0)) + 2070158792u); unsigned int csrd_value_2 = ((2010586713u * (y)) + 278101063u); unsigned int csrd_value_3 = (((csrd_value_1) + (csrd_value_2)) - 278101063u); unsigned int csrd_value_4 = (((csrd_value_3) + (278101063u)) - 278101063u); unsigned int csrd_value_5 = ((9u * (csrd_value_4)) + 2070158792u); unsigned int csrd_value_6 = (((csrd_value_5) + (csrd_value_2)) - 278101063u); unsigned int csrd_value_7 = (((csrd_value_6) + (2288687776u)) - 278101063u); unsigned int csrd_value_8 = ((9u * (csrd_value_7)) + 2070158792u); unsigned int csrd_value_9 = (((csrd_value_8) + (csrd_value_2)) - 278101063u); unsigned int csrd_value_10 = (((csrd_value_9) + (4307193u)) - 278101063u); unsigned int csrd_value_11 = ((9u * (csrd_value_10)) + 2070158792u); unsigned int csrd_value_12 = (((csrd_value_11) + (csrd_value_2)) - 278101063u); unsigned int csrd_value_13 = (((csrd_value_12) + (2014893906u)) - 278101063u); unsigned int csrd_value_14 = (2621327849u * ((csrd_value_13) - 278101063u)); return csrd_value_14;





}
