; ModuleID = '/work/experiments/runs/decompiler-flow-linux-development-v2/bounded_arithmetic/build-clang-O0-planned-42/validation/compiler-0-O0/candidate.i'
source_filename = "/work/experiments/runs/decompiler-flow-linux-development-v2/bounded_arithmetic/build-clang-O0-planned-42/validation/compiler-0-O0/candidate.i"
target datalayout = "e-m:e-i8:8:32-i16:16:32-i64:64-i128:128-n32:64-S128"
target triple = "aarch64-unknown-linux-gnu"

; Function Attrs: noinline nounwind optnone uwtable
define dso_local i32 @kernel(i32 noundef %0, i32 noundef %1) #0 {
  %3 = alloca i32, align 4
  %4 = alloca i32, align 4
  %5 = alloca i32, align 4
  %6 = alloca i32, align 4
  %7 = alloca i32, align 4
  %8 = alloca i32, align 4
  %9 = alloca i32, align 4
  %10 = alloca i32, align 4
  %11 = alloca i32, align 4
  %12 = alloca i32, align 4
  %13 = alloca i32, align 4
  %14 = alloca i32, align 4
  %15 = alloca i32, align 4
  %16 = alloca i32, align 4
  %17 = alloca i32, align 4
  %18 = alloca i32, align 4
  %19 = alloca i32, align 4
  store i32 %0, ptr %3, align 4
  store i32 %1, ptr %4, align 4
  %20 = load i32, ptr %3, align 4
  %21 = mul i32 2010586713, %20
  %22 = add i32 %21, 278101063
  store i32 %22, ptr %5, align 4
  %23 = load i32, ptr %5, align 4
  %24 = mul i32 9, %23
  %25 = add i32 %24, 2070158792
  store i32 %25, ptr %6, align 4
  %26 = load i32, ptr %4, align 4
  %27 = mul i32 2010586713, %26
  %28 = add i32 %27, 278101063
  store i32 %28, ptr %7, align 4
  %29 = load i32, ptr %6, align 4
  %30 = load i32, ptr %7, align 4
  %31 = add i32 %29, %30
  %32 = sub i32 %31, 278101063
  store i32 %32, ptr %8, align 4
  %33 = load i32, ptr %8, align 4
  %34 = add i32 %33, 278101063
  %35 = sub i32 %34, 278101063
  store i32 %35, ptr %9, align 4
  %36 = load i32, ptr %9, align 4
  %37 = mul i32 9, %36
  %38 = add i32 %37, 2070158792
  store i32 %38, ptr %10, align 4
  %39 = load i32, ptr %10, align 4
  %40 = load i32, ptr %7, align 4
  %41 = add i32 %39, %40
  %42 = sub i32 %41, 278101063
  store i32 %42, ptr %11, align 4
  %43 = load i32, ptr %11, align 4
  %44 = add i32 %43, -2006279520
  %45 = sub i32 %44, 278101063
  store i32 %45, ptr %12, align 4
  %46 = load i32, ptr %12, align 4
  %47 = sub i32 %46, 278101063
  %48 = mul i32 -1673639447, %47
  store i32 %48, ptr %13, align 4
  %49 = load i32, ptr %13, align 4
  %50 = mul i32 9, %49
  store i32 %50, ptr %14, align 4
  %51 = load i32, ptr %14, align 4
  %52 = load i32, ptr %4, align 4
  %53 = add i32 %51, %52
  store i32 %53, ptr %15, align 4
  %54 = load i32, ptr %15, align 4
  %55 = add i32 %54, 2
  store i32 %55, ptr %16, align 4
  %56 = load i32, ptr %16, align 4
  %57 = mul i32 9, %56
  store i32 %57, ptr %17, align 4
  %58 = load i32, ptr %17, align 4
  %59 = load i32, ptr %4, align 4
  %60 = add i32 %58, %59
  store i32 %60, ptr %18, align 4
  %61 = load i32, ptr %18, align 4
  %62 = add i32 %61, 3
  store i32 %62, ptr %19, align 4
  %63 = load i32, ptr %19, align 4
  ret i32 %63
}

attributes #0 = { noinline nounwind optnone uwtable "frame-pointer"="non-leaf" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+fp-armv8,+neon,+outline-atomics,+v8a,-fmv" }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 1, !"wchar_size", i32 4}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 1}
!5 = !{!"Ubuntu clang version 18.1.3 (1ubuntu1)"}
