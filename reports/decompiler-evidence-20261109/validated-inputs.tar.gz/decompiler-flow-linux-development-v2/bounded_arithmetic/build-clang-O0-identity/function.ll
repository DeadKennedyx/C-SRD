; ModuleID = '/work/experiments/runs/decompiler-flow-linux-development-v2/bounded_arithmetic/build-clang-O0-identity/validation/compiler-0-O0/candidate.i'
source_filename = "/work/experiments/runs/decompiler-flow-linux-development-v2/bounded_arithmetic/build-clang-O0-identity/validation/compiler-0-O0/candidate.i"
target datalayout = "e-m:e-i8:8:32-i16:16:32-i64:64-i128:128-n32:64-S128"
target triple = "aarch64-unknown-linux-gnu"

; Function Attrs: noinline nounwind optnone uwtable
define dso_local i32 @kernel(i32 noundef %0, i32 noundef %1) #0 {
  %3 = alloca i32, align 4
  %4 = alloca i32, align 4
  %5 = alloca i32, align 4
  %6 = alloca i32, align 4
  %7 = alloca i32, align 4
  %8 = alloca i32, align 4
  %9 = alloca i32, align 4
  %10 = alloca i32, align 4
  %11 = alloca i32, align 4
  %12 = alloca i32, align 4
  %13 = alloca i32, align 4
  %14 = alloca i32, align 4
  %15 = alloca i32, align 4
  %16 = alloca i32, align 4
  store i32 %0, ptr %3, align 4
  store i32 %1, ptr %4, align 4
  %17 = load i32, ptr %3, align 4
  %18 = mul i32 9, %17
  store i32 %18, ptr %5, align 4
  %19 = load i32, ptr %5, align 4
  %20 = load i32, ptr %4, align 4
  %21 = add i32 %19, %20
  store i32 %21, ptr %6, align 4
  %22 = load i32, ptr %6, align 4
  %23 = add i32 %22, 0
  store i32 %23, ptr %7, align 4
  %24 = load i32, ptr %7, align 4
  %25 = mul i32 9, %24
  store i32 %25, ptr %8, align 4
  %26 = load i32, ptr %8, align 4
  %27 = load i32, ptr %4, align 4
  %28 = add i32 %26, %27
  store i32 %28, ptr %9, align 4
  %29 = load i32, ptr %9, align 4
  %30 = add i32 %29, 1
  store i32 %30, ptr %10, align 4
  %31 = load i32, ptr %10, align 4
  %32 = mul i32 9, %31
  store i32 %32, ptr %11, align 4
  %33 = load i32, ptr %11, align 4
  %34 = load i32, ptr %4, align 4
  %35 = add i32 %33, %34
  store i32 %35, ptr %12, align 4
  %36 = load i32, ptr %12, align 4
  %37 = add i32 %36, 2
  store i32 %37, ptr %13, align 4
  %38 = load i32, ptr %13, align 4
  %39 = mul i32 9, %38
  store i32 %39, ptr %14, align 4
  %40 = load i32, ptr %14, align 4
  %41 = load i32, ptr %4, align 4
  %42 = add i32 %40, %41
  store i32 %42, ptr %15, align 4
  %43 = load i32, ptr %15, align 4
  %44 = add i32 %43, 3
  store i32 %44, ptr %16, align 4
  %45 = load i32, ptr %16, align 4
  ret i32 %45
}

attributes #0 = { noinline nounwind optnone uwtable "frame-pointer"="non-leaf" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+fp-armv8,+neon,+outline-atomics,+v8a,-fmv" }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 1, !"wchar_size", i32 4}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 1}
!5 = !{!"Ubuntu clang version 18.1.3 (1ubuntu1)"}
