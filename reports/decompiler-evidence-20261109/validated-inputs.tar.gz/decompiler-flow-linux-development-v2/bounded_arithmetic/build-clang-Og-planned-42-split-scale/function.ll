; ModuleID = '/work/experiments/runs/decompiler-flow-linux-development-v2/bounded_arithmetic/build-clang-Og-planned-42-split-scale/validation/compiler-0-Og/candidate.i'
source_filename = "/work/experiments/runs/decompiler-flow-linux-development-v2/bounded_arithmetic/build-clang-Og-planned-42-split-scale/validation/compiler-0-Og/candidate.i"
target datalayout = "e-m:e-i8:8:32-i16:16:32-i64:64-i128:128-n32:64-S128"
target triple = "aarch64-unknown-linux-gnu"

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local i32 @kernel(i32 noundef %0, i32 noundef %1) local_unnamed_addr #0 {
  %3 = mul i32 %0, 2010586713
  %4 = add i32 %3, 278101063
  %5 = and i32 %4, 1
  %6 = icmp eq i32 %5, 0
  %7 = mul i32 %0, 915411233
  %8 = add i32 %7, 278101063
  %9 = mul i32 %4, 9
  %10 = add i32 %9, 2070158792
  %11 = select i1 %6, i32 %10, i32 %8
  %12 = mul i32 %1, 2010586713
  %13 = add i32 %11, %12
  %14 = mul i32 %13, 9
  %15 = add i32 %14, %12
  %16 = mul i32 %15, 2117114161
  %17 = add i32 %1, -391839046
  %18 = add i32 %17, %16
  %19 = mul i32 %18, 9
  %20 = add i32 %1, 21
  %21 = add i32 %20, %19
  ret i32 %21
}

attributes #0 = { mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable "frame-pointer"="non-leaf" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+fp-armv8,+neon,+outline-atomics,+v8a,-fmv" }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 1, !"wchar_size", i32 4}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 1}
!5 = !{!"Ubuntu clang version 18.1.3 (1ubuntu1)"}
