; ModuleID = '/work/experiments/runs/decompiler-flow-linux-development-v2/bounded_arithmetic/build-clang-O0-affine-42-split-scale/validation/compiler-0-O0/candidate.i'
source_filename = "/work/experiments/runs/decompiler-flow-linux-development-v2/bounded_arithmetic/build-clang-O0-affine-42-split-scale/validation/compiler-0-O0/candidate.i"
target datalayout = "e-m:e-i8:8:32-i16:16:32-i64:64-i128:128-n32:64-S128"
target triple = "aarch64-unknown-linux-gnu"

; Function Attrs: noinline nounwind optnone uwtable
define dso_local i32 @kernel(i32 noundef %0, i32 noundef %1) #0 {
  %3 = alloca i32, align 4
  %4 = alloca i32, align 4
  %5 = alloca i32, align 4
  %6 = alloca i32, align 4
  %7 = alloca i32, align 4
  %8 = alloca i32, align 4
  %9 = alloca i32, align 4
  %10 = alloca i32, align 4
  %11 = alloca i32, align 4
  %12 = alloca i32, align 4
  %13 = alloca i32, align 4
  %14 = alloca i32, align 4
  %15 = alloca i32, align 4
  %16 = alloca i32, align 4
  %17 = alloca i32, align 4
  %18 = alloca i32, align 4
  %19 = alloca i32, align 4
  store i32 %0, ptr %3, align 4
  store i32 %1, ptr %4, align 4
  %20 = load i32, ptr %3, align 4
  %21 = mul i32 2010586713, %20
  %22 = add i32 %21, 278101063
  store i32 %22, ptr %5, align 4
  store i32 0, ptr %6, align 4
  %23 = load i32, ptr %5, align 4
  %24 = and i32 %23, 1
  %25 = icmp ne i32 %24, 0
  br i1 %25, label %26, label %32

26:                                               ; preds = %2
  %27 = load i32, ptr %5, align 4
  %28 = sub i32 %27, 1
  %29 = mul i32 9, %28
  %30 = add i32 %29, 2070158792
  %31 = add i32 %30, 9
  store i32 %31, ptr %6, align 4
  br label %36

32:                                               ; preds = %2
  %33 = load i32, ptr %5, align 4
  %34 = mul i32 9, %33
  %35 = add i32 %34, 2070158792
  store i32 %35, ptr %6, align 4
  br label %36

36:                                               ; preds = %32, %26
  %37 = load i32, ptr %4, align 4
  %38 = mul i32 2010586713, %37
  %39 = add i32 %38, 278101063
  store i32 %39, ptr %7, align 4
  %40 = load i32, ptr %6, align 4
  %41 = load i32, ptr %7, align 4
  %42 = add i32 %40, %41
  %43 = sub i32 %42, 278101063
  store i32 %43, ptr %8, align 4
  %44 = load i32, ptr %8, align 4
  %45 = add i32 %44, 278101063
  %46 = sub i32 %45, 278101063
  store i32 %46, ptr %9, align 4
  store i32 0, ptr %10, align 4
  %47 = load i32, ptr %9, align 4
  %48 = and i32 %47, 1
  %49 = icmp ne i32 %48, 0
  br i1 %49, label %50, label %56

50:                                               ; preds = %36
  %51 = load i32, ptr %9, align 4
  %52 = sub i32 %51, 1
  %53 = mul i32 9, %52
  %54 = add i32 %53, 2070158792
  %55 = add i32 %54, 9
  store i32 %55, ptr %10, align 4
  br label %60

56:                                               ; preds = %36
  %57 = load i32, ptr %9, align 4
  %58 = mul i32 9, %57
  %59 = add i32 %58, 2070158792
  store i32 %59, ptr %10, align 4
  br label %60

60:                                               ; preds = %56, %50
  %61 = load i32, ptr %10, align 4
  %62 = load i32, ptr %7, align 4
  %63 = add i32 %61, %62
  %64 = sub i32 %63, 278101063
  store i32 %64, ptr %11, align 4
  %65 = load i32, ptr %11, align 4
  %66 = add i32 %65, -2006279520
  %67 = sub i32 %66, 278101063
  store i32 %67, ptr %12, align 4
  store i32 0, ptr %13, align 4
  %68 = load i32, ptr %12, align 4
  %69 = and i32 %68, 1
  %70 = icmp ne i32 %69, 0
  br i1 %70, label %71, label %77

71:                                               ; preds = %60
  %72 = load i32, ptr %12, align 4
  %73 = sub i32 %72, 1
  %74 = mul i32 9, %73
  %75 = add i32 %74, 2070158792
  %76 = add i32 %75, 9
  store i32 %76, ptr %13, align 4
  br label %81

77:                                               ; preds = %60
  %78 = load i32, ptr %12, align 4
  %79 = mul i32 9, %78
  %80 = add i32 %79, 2070158792
  store i32 %80, ptr %13, align 4
  br label %81

81:                                               ; preds = %77, %71
  %82 = load i32, ptr %13, align 4
  %83 = load i32, ptr %7, align 4
  %84 = add i32 %82, %83
  %85 = sub i32 %84, 278101063
  store i32 %85, ptr %14, align 4
  %86 = load i32, ptr %14, align 4
  %87 = add i32 %86, 4307193
  %88 = sub i32 %87, 278101063
  store i32 %88, ptr %15, align 4
  store i32 0, ptr %16, align 4
  %89 = load i32, ptr %15, align 4
  %90 = and i32 %89, 1
  %91 = icmp ne i32 %90, 0
  br i1 %91, label %92, label %98

92:                                               ; preds = %81
  %93 = load i32, ptr %15, align 4
  %94 = sub i32 %93, 1
  %95 = mul i32 9, %94
  %96 = add i32 %95, 2070158792
  %97 = add i32 %96, 9
  store i32 %97, ptr %16, align 4
  br label %102

98:                                               ; preds = %81
  %99 = load i32, ptr %15, align 4
  %100 = mul i32 9, %99
  %101 = add i32 %100, 2070158792
  store i32 %101, ptr %16, align 4
  br label %102

102:                                              ; preds = %98, %92
  %103 = load i32, ptr %16, align 4
  %104 = load i32, ptr %7, align 4
  %105 = add i32 %103, %104
  %106 = sub i32 %105, 278101063
  store i32 %106, ptr %17, align 4
  %107 = load i32, ptr %17, align 4
  %108 = add i32 %107, 2014893906
  %109 = sub i32 %108, 278101063
  store i32 %109, ptr %18, align 4
  %110 = load i32, ptr %18, align 4
  %111 = sub i32 %110, 278101063
  %112 = mul i32 -1673639447, %111
  store i32 %112, ptr %19, align 4
  %113 = load i32, ptr %19, align 4
  ret i32 %113
}

attributes #0 = { noinline nounwind optnone uwtable "frame-pointer"="non-leaf" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+fp-armv8,+neon,+outline-atomics,+v8a,-fmv" }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 1, !"wchar_size", i32 4}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 1}
!5 = !{!"Ubuntu clang version 18.1.3 (1ubuntu1)"}
