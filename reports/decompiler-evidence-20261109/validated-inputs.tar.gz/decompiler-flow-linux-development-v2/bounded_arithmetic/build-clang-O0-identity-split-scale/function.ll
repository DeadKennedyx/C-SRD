; ModuleID = '/work/experiments/runs/decompiler-flow-linux-development-v2/bounded_arithmetic/build-clang-O0-identity-split-scale/validation/compiler-0-O0/candidate.i'
source_filename = "/work/experiments/runs/decompiler-flow-linux-development-v2/bounded_arithmetic/build-clang-O0-identity-split-scale/validation/compiler-0-O0/candidate.i"
target datalayout = "e-m:e-i8:8:32-i16:16:32-i64:64-i128:128-n32:64-S128"
target triple = "aarch64-unknown-linux-gnu"

; Function Attrs: noinline nounwind optnone uwtable
define dso_local i32 @kernel(i32 noundef %0, i32 noundef %1) #0 {
  %3 = alloca i32, align 4
  %4 = alloca i32, align 4
  %5 = alloca i32, align 4
  %6 = alloca i32, align 4
  %7 = alloca i32, align 4
  %8 = alloca i32, align 4
  %9 = alloca i32, align 4
  %10 = alloca i32, align 4
  %11 = alloca i32, align 4
  %12 = alloca i32, align 4
  %13 = alloca i32, align 4
  %14 = alloca i32, align 4
  %15 = alloca i32, align 4
  %16 = alloca i32, align 4
  store i32 %0, ptr %3, align 4
  store i32 %1, ptr %4, align 4
  store i32 0, ptr %5, align 4
  %17 = load i32, ptr %3, align 4
  %18 = and i32 %17, 1
  %19 = icmp ne i32 %18, 0
  br i1 %19, label %20, label %25

20:                                               ; preds = %2
  %21 = load i32, ptr %3, align 4
  %22 = sub i32 %21, 1
  %23 = mul i32 9, %22
  %24 = add i32 %23, 9
  store i32 %24, ptr %5, align 4
  br label %28

25:                                               ; preds = %2
  %26 = load i32, ptr %3, align 4
  %27 = mul i32 9, %26
  store i32 %27, ptr %5, align 4
  br label %28

28:                                               ; preds = %25, %20
  %29 = load i32, ptr %5, align 4
  %30 = load i32, ptr %4, align 4
  %31 = add i32 %29, %30
  store i32 %31, ptr %6, align 4
  %32 = load i32, ptr %6, align 4
  %33 = add i32 %32, 0
  store i32 %33, ptr %7, align 4
  store i32 0, ptr %8, align 4
  %34 = load i32, ptr %7, align 4
  %35 = and i32 %34, 1
  %36 = icmp ne i32 %35, 0
  br i1 %36, label %37, label %42

37:                                               ; preds = %28
  %38 = load i32, ptr %7, align 4
  %39 = sub i32 %38, 1
  %40 = mul i32 9, %39
  %41 = add i32 %40, 9
  store i32 %41, ptr %8, align 4
  br label %45

42:                                               ; preds = %28
  %43 = load i32, ptr %7, align 4
  %44 = mul i32 9, %43
  store i32 %44, ptr %8, align 4
  br label %45

45:                                               ; preds = %42, %37
  %46 = load i32, ptr %8, align 4
  %47 = load i32, ptr %4, align 4
  %48 = add i32 %46, %47
  store i32 %48, ptr %9, align 4
  %49 = load i32, ptr %9, align 4
  %50 = add i32 %49, 1
  store i32 %50, ptr %10, align 4
  store i32 0, ptr %11, align 4
  %51 = load i32, ptr %10, align 4
  %52 = and i32 %51, 1
  %53 = icmp ne i32 %52, 0
  br i1 %53, label %54, label %59

54:                                               ; preds = %45
  %55 = load i32, ptr %10, align 4
  %56 = sub i32 %55, 1
  %57 = mul i32 9, %56
  %58 = add i32 %57, 9
  store i32 %58, ptr %11, align 4
  br label %62

59:                                               ; preds = %45
  %60 = load i32, ptr %10, align 4
  %61 = mul i32 9, %60
  store i32 %61, ptr %11, align 4
  br label %62

62:                                               ; preds = %59, %54
  %63 = load i32, ptr %11, align 4
  %64 = load i32, ptr %4, align 4
  %65 = add i32 %63, %64
  store i32 %65, ptr %12, align 4
  %66 = load i32, ptr %12, align 4
  %67 = add i32 %66, 2
  store i32 %67, ptr %13, align 4
  store i32 0, ptr %14, align 4
  %68 = load i32, ptr %13, align 4
  %69 = and i32 %68, 1
  %70 = icmp ne i32 %69, 0
  br i1 %70, label %71, label %76

71:                                               ; preds = %62
  %72 = load i32, ptr %13, align 4
  %73 = sub i32 %72, 1
  %74 = mul i32 9, %73
  %75 = add i32 %74, 9
  store i32 %75, ptr %14, align 4
  br label %79

76:                                               ; preds = %62
  %77 = load i32, ptr %13, align 4
  %78 = mul i32 9, %77
  store i32 %78, ptr %14, align 4
  br label %79

79:                                               ; preds = %76, %71
  %80 = load i32, ptr %14, align 4
  %81 = load i32, ptr %4, align 4
  %82 = add i32 %80, %81
  store i32 %82, ptr %15, align 4
  %83 = load i32, ptr %15, align 4
  %84 = add i32 %83, 3
  store i32 %84, ptr %16, align 4
  %85 = load i32, ptr %16, align 4
  ret i32 %85
}

attributes #0 = { noinline nounwind optnone uwtable "frame-pointer"="non-leaf" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+fp-armv8,+neon,+outline-atomics,+v8a,-fmv" }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 1, !"wchar_size", i32 4}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 1}
!5 = !{!"Ubuntu clang version 18.1.3 (1ubuntu1)"}
