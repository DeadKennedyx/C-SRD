
/Users/admin/C-SRD/experiments/runs/private-regions-cost-native-20261110/clang-O2-lto/original:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001000004f8 <_main>:
1000004f8:     	cmp	w0, #0x3
1000004fc:     	b.ne	0x100000628 <_main+0x130>
100000500:     	sub	sp, sp, #0x90
100000504:     	stp	x24, x23, [sp, #0x50]
100000508:     	stp	x22, x21, [sp, #0x60]
10000050c:     	stp	x20, x19, [sp, #0x70]
100000510:     	stp	x29, x30, [sp, #0x80]
100000514:     	add	x29, sp, #0x80
100000518:     	ldr	x0, [x1, #0x8]
10000051c:     	mov	x20, x1
100000520:     	mov	x1, #0x0                ; =0
100000524:     	mov	w2, #0xa                ; =10
100000528:     	bl	0x1000006e8 <_strtoul+0x1000006e8>
10000052c:     	mov	x19, x0
100000530:     	ldr	x0, [x20, #0x10]
100000534:     	mov	x1, #0x0                ; =0
100000538:     	mov	w2, #0xa                ; =10
10000053c:     	bl	0x1000006e8 <_strtoul+0x1000006e8>
100000540:     	mov	x20, x0
100000544:     	add	x1, sp, #0x40
100000548:     	mov	w0, #0x6                ; =6
10000054c:     	bl	0x1000006d0 <_strtoul+0x1000006d0>
100000550:     	cbnz	w0, 0x100000654 <_main+0x15c>
100000554:     	adrp	x23, 0x100008000 <_event_hash>
100000558:     	adrp	x22, 0x100008000 <_event_hash>
10000055c:     	adrp	x21, 0x100008000 <_event_hash>
100000560:     	cbz	x19, 0x100000640 <_main+0x148>
100000564:     	mov	x8, #0x0                ; =0
100000568:     	mov	w24, #0x0               ; =0
10000056c:     	ldr	w14, [x23, #0x4]
100000570:     	ldr	w13, [x21]
100000574:     	mov	w9, #0x1                ; =1
100000578:     	mov	x10, #-0x3333333333333334 ; =-3689348814741910324
10000057c:     	movk	x10, #0xcccd
100000580:     	mov	w11, #0xa               ; =10
100000584:     	ldr	w12, [x22, #0x8]
100000588:     	b	0x1000005bc <_main+0xc4>
10000058c:     	adds	w12, w20, #0x11
100000590:     	add	w15, w12, w12, lsl #1
100000594:     	add	w16, w14, w24
100000598:     	add	w15, w15, w16
10000059c:     	sub	w14, w15, w12
1000005a0:     	add	w13, w13, w13, lsl #5
1000005a4:     	eor	w13, w13, w15
1000005a8:     	cinc	w24, w16, eq
1000005ac:     	add	x8, x8, #0x1
1000005b0:     	add	w9, w9, #0x1
1000005b4:     	cmp	x8, x19
1000005b8:     	b.eq	0x100000630 <_main+0x138>
1000005bc:     	umulh	x15, x8, x10
1000005c0:     	lsr	x15, x15, #3
1000005c4:     	eor	w16, w20, w20, lsl #13
1000005c8:     	eor	w16, w16, w16, lsr #17
1000005cc:     	eor	w20, w16, w16, lsl #5
1000005d0:     	msub	x16, x15, x11, x8
1000005d4:     	add	w14, w14, w20
1000005d8:     	add	w14, w14, w14, lsl #1
1000005dc:     	add	w14, w14, #0xb
1000005e0:     	add	w13, w13, w13, lsl #5
1000005e4:     	eor	w13, w13, w14
1000005e8:     	cmp	x16, #0x2
1000005ec:     	b.lo	0x10000058c <_main+0x94>
1000005f0:     	msub	w15, w15, w11, w9
1000005f4:     	add	w13, w13, w13, lsl #5
1000005f8:     	eor	w13, w13, w14
1000005fc:     	add	w12, w12, w14
100000600:     	add	w16, w12, w14
100000604:     	add	w14, w16, w14
100000608:     	add	w14, w14, w14, lsl #2
10000060c:     	sub	w14, w14, #0x7
100000610:     	add	w13, w13, w13, lsl #5
100000614:     	eor	w13, w13, w16
100000618:     	sub	w15, w15, #0x1
10000061c:     	cmp	w15, #0x2
100000620:     	b.gt	0x1000005f4 <_main+0xfc>
100000624:     	b	0x10000058c <_main+0x94>
100000628:     	mov	w0, #0x2                ; =2
10000062c:     	ret
100000630:     	str	w14, [x23, #0x4]
100000634:     	str	w13, [x21]
100000638:     	str	w12, [x22, #0x8]
10000063c:     	b	0x100000644 <_main+0x14c>
100000640:     	mov	w24, #0x0               ; =0
100000644:     	add	x1, sp, #0x30
100000648:     	mov	w0, #0x6                ; =6
10000064c:     	bl	0x1000006d0 <_strtoul+0x1000006d0>
100000650:     	cbz	w0, 0x100000670 <_main+0x178>
100000654:     	mov	w0, #0x2                ; =2
100000658:     	ldp	x29, x30, [sp, #0x80]
10000065c:     	ldp	x20, x19, [sp, #0x70]
100000660:     	ldp	x22, x21, [sp, #0x60]
100000664:     	ldp	x24, x23, [sp, #0x50]
100000668:     	add	sp, sp, #0x90
10000066c:     	ret
100000670:     	ldp	x8, x9, [sp, #0x30]
100000674:     	ldp	x10, x11, [sp, #0x40]
100000678:     	sub	x8, x8, x10
10000067c:     	scvtf	d0, x8
100000680:     	sub	x8, x9, x11
100000684:     	scvtf	d1, x8
100000688:     	mov	x8, #0xd695             ; =54933
10000068c:     	movk	x8, #0xe826, lsl #16
100000690:     	movk	x8, #0x2e0b, lsl #32
100000694:     	movk	x8, #0x3e11, lsl #48
100000698:     	fmov	d2, x8
10000069c:     	fmadd	d0, d1, d2, d0
1000006a0:     	ldr	w8, [x23, #0x4]
1000006a4:     	ldr	w9, [x22, #0x8]
1000006a8:     	ldr	w10, [x21]
1000006ac:     	stp	xzr, x10, [sp, #0x20]
1000006b0:     	stp	x8, x9, [sp, #0x10]
1000006b4:     	str	x24, [sp, #0x8]
1000006b8:     	str	d0, [sp]
1000006bc:     	adrp	x0, 0x100000000 <_strtoul+0x100000000>
1000006c0:     	add	x0, x0, #0x6f4
1000006c4:     	bl	0x1000006dc <_strtoul+0x1000006dc>
1000006c8:     	mov	w0, #0x0                ; =0
1000006cc:     	b	0x100000658 <_main+0x160>

Disassembly of section __TEXT,__stubs:

00000001000006d0 <__stubs>:
1000006d0:     	adrp	x16, 0x100004000 <_strtoul+0x100004000>
1000006d4:     	ldr	x16, [x16]
1000006d8:     	br	x16
1000006dc:     	adrp	x16, 0x100004000 <_strtoul+0x100004000>
1000006e0:     	ldr	x16, [x16, #0x8]
1000006e4:     	br	x16
1000006e8:     	adrp	x16, 0x100004000 <_strtoul+0x100004000>
1000006ec:     	ldr	x16, [x16, #0x10]
1000006f0:     	br	x16
