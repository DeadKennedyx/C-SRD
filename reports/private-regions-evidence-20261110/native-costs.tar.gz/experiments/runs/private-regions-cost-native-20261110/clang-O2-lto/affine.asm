
/Users/admin/C-SRD/experiments/runs/private-regions-cost-native-20261110/clang-O2-lto/affine:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001000004f8 <_main>:
1000004f8:     	cmp	w0, #0x3
1000004fc:     	b.ne	0x100000674 <_main+0x17c>
100000500:     	sub	sp, sp, #0x90
100000504:     	stp	x24, x23, [sp, #0x50]
100000508:     	stp	x22, x21, [sp, #0x60]
10000050c:     	stp	x20, x19, [sp, #0x70]
100000510:     	stp	x29, x30, [sp, #0x80]
100000514:     	add	x29, sp, #0x80
100000518:     	ldr	x0, [x1, #0x8]
10000051c:     	mov	x20, x1
100000520:     	mov	x1, #0x0                ; =0
100000524:     	mov	w2, #0xa                ; =10
100000528:     	bl	0x100000734 <_strtoul+0x100000734>
10000052c:     	mov	x19, x0
100000530:     	ldr	x0, [x20, #0x10]
100000534:     	mov	x1, #0x0                ; =0
100000538:     	mov	w2, #0xa                ; =10
10000053c:     	bl	0x100000734 <_strtoul+0x100000734>
100000540:     	mov	x20, x0
100000544:     	add	x1, sp, #0x40
100000548:     	mov	w0, #0x6                ; =6
10000054c:     	bl	0x10000071c <_strtoul+0x10000071c>
100000550:     	cbnz	w0, 0x1000006a0 <_main+0x1a8>
100000554:     	adrp	x23, 0x100008000 <_event_hash>
100000558:     	adrp	x22, 0x100008000 <_event_hash>
10000055c:     	adrp	x21, 0x100008000 <_event_hash>
100000560:     	cbz	x19, 0x10000068c <_main+0x194>
100000564:     	mov	x8, #0x0                ; =0
100000568:     	mov	w24, #0x0               ; =0
10000056c:     	mov	w9, #0x1a01             ; =6657
100000570:     	movk	w9, #0xcfe2, lsl #16
100000574:     	ldr	w3, [x23, #0x4]
100000578:     	ldr	w2, [x21]
10000057c:     	mov	w10, #0x1               ; =1
100000580:     	mov	x11, #-0x3333333333333334 ; =-3689348814741910324
100000584:     	movk	x11, #0xcccd
100000588:     	ldr	w1, [x22, #0x8]
10000058c:     	mov	w12, #0xa               ; =10
100000590:     	mov	w13, #0x19ff            ; =6655
100000594:     	movk	w13, #0x8d3e, lsl #16
100000598:     	mov	w14, #0xe601            ; =58881
10000059c:     	movk	w14, #0x72c1, lsl #16
1000005a0:     	mov	w15, #0xb203            ; =45571
1000005a4:     	movk	w15, #0x5845, lsl #16
1000005a8:     	mov	w16, #0x286             ; =646
1000005ac:     	movk	w16, #0x2d, lsl #16
1000005b0:     	mov	w17, #0x899c            ; =35228
1000005b4:     	movk	w17, #0x3d93, lsl #16
1000005b8:     	mov	w0, #0x61ad             ; =25005
1000005bc:     	movk	w0, #0xd945, lsl #16
1000005c0:     	b	0x100000608 <_main+0x110>
1000005c4:     	add	w4, w3, w24
1000005c8:     	mul	w1, w4, w14
1000005cc:     	madd	w1, w20, w15, w1
1000005d0:     	add	w3, w1, w16
1000005d4:     	madd	w1, w20, w13, w3
1000005d8:     	add	w5, w1, w17
1000005dc:     	add	w1, w20, #0x11
1000005e0:     	madd	w6, w3, w9, w0
1000005e4:     	mul	w3, w5, w9
1000005e8:     	add	w2, w2, w2, lsl #5
1000005ec:     	eor	w2, w2, w6
1000005f0:     	cmp	w6, w3
1000005f4:     	cinc	w24, w4, eq
1000005f8:     	add	x8, x8, #0x1
1000005fc:     	add	w10, w10, #0x1
100000600:     	cmp	x8, x19
100000604:     	b.eq	0x10000067c <_main+0x184>
100000608:     	umulh	x4, x8, x11
10000060c:     	lsr	x4, x4, #3
100000610:     	eor	w5, w20, w20, lsl #13
100000614:     	eor	w5, w5, w5, lsr #17
100000618:     	eor	w20, w5, w5, lsl #5
10000061c:     	msub	x5, x4, x12, x8
100000620:     	add	w3, w3, w20
100000624:     	add	w3, w3, w3, lsl #1
100000628:     	add	w3, w3, #0xb
10000062c:     	add	w2, w2, w2, lsl #5
100000630:     	eor	w2, w2, w3
100000634:     	cmp	x5, #0x2
100000638:     	b.lo	0x1000005c4 <_main+0xcc>
10000063c:     	msub	w4, w4, w12, w10
100000640:     	add	w2, w2, w2, lsl #5
100000644:     	eor	w2, w2, w3
100000648:     	add	w1, w1, w3
10000064c:     	add	w5, w1, w3
100000650:     	add	w3, w5, w3
100000654:     	add	w3, w3, w3, lsl #2
100000658:     	sub	w3, w3, #0x7
10000065c:     	add	w2, w2, w2, lsl #5
100000660:     	eor	w2, w2, w5
100000664:     	sub	w4, w4, #0x1
100000668:     	cmp	w4, #0x2
10000066c:     	b.gt	0x100000640 <_main+0x148>
100000670:     	b	0x1000005c4 <_main+0xcc>
100000674:     	mov	w0, #0x2                ; =2
100000678:     	ret
10000067c:     	str	w3, [x23, #0x4]
100000680:     	str	w2, [x21]
100000684:     	str	w1, [x22, #0x8]
100000688:     	b	0x100000690 <_main+0x198>
10000068c:     	mov	w24, #0x0               ; =0
100000690:     	add	x1, sp, #0x30
100000694:     	mov	w0, #0x6                ; =6
100000698:     	bl	0x10000071c <_strtoul+0x10000071c>
10000069c:     	cbz	w0, 0x1000006bc <_main+0x1c4>
1000006a0:     	mov	w0, #0x2                ; =2
1000006a4:     	ldp	x29, x30, [sp, #0x80]
1000006a8:     	ldp	x20, x19, [sp, #0x70]
1000006ac:     	ldp	x22, x21, [sp, #0x60]
1000006b0:     	ldp	x24, x23, [sp, #0x50]
1000006b4:     	add	sp, sp, #0x90
1000006b8:     	ret
1000006bc:     	ldp	x8, x9, [sp, #0x30]
1000006c0:     	ldp	x10, x11, [sp, #0x40]
1000006c4:     	sub	x8, x8, x10
1000006c8:     	scvtf	d0, x8
1000006cc:     	sub	x8, x9, x11
1000006d0:     	scvtf	d1, x8
1000006d4:     	mov	x8, #0xd695             ; =54933
1000006d8:     	movk	x8, #0xe826, lsl #16
1000006dc:     	movk	x8, #0x2e0b, lsl #32
1000006e0:     	movk	x8, #0x3e11, lsl #48
1000006e4:     	fmov	d2, x8
1000006e8:     	fmadd	d0, d1, d2, d0
1000006ec:     	ldr	w8, [x23, #0x4]
1000006f0:     	ldr	w9, [x22, #0x8]
1000006f4:     	ldr	w10, [x21]
1000006f8:     	stp	xzr, x10, [sp, #0x20]
1000006fc:     	stp	x8, x9, [sp, #0x10]
100000700:     	str	x24, [sp, #0x8]
100000704:     	str	d0, [sp]
100000708:     	adrp	x0, 0x100000000 <_strtoul+0x100000000>
10000070c:     	add	x0, x0, #0x740
100000710:     	bl	0x100000728 <_strtoul+0x100000728>
100000714:     	mov	w0, #0x0                ; =0
100000718:     	b	0x1000006a4 <_main+0x1ac>

Disassembly of section __TEXT,__stubs:

000000010000071c <__stubs>:
10000071c:     	adrp	x16, 0x100004000 <_strtoul+0x100004000>
100000720:     	ldr	x16, [x16]
100000724:     	br	x16
100000728:     	adrp	x16, 0x100004000 <_strtoul+0x100004000>
10000072c:     	ldr	x16, [x16, #0x8]
100000730:     	br	x16
100000734:     	adrp	x16, 0x100004000 <_strtoul+0x100004000>
100000738:     	ldr	x16, [x16, #0x10]
10000073c:     	br	x16
