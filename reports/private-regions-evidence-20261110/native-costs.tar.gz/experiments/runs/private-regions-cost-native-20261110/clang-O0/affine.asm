
/Users/admin/C-SRD/experiments/runs/private-regions-cost-native-20261110/clang-O0/affine:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001000004f8 <_region_pipeline>:
1000004f8:     	sub	sp, sp, #0x40
1000004fc:     	stp	x29, x30, [sp, #0x30]
100000500:     	add	x29, sp, #0x30
100000504:     	mov	w8, #0xc69              ; =3177
100000508:     	movk	w8, #0x513c, lsl #16
10000050c:     	str	w8, [sp]
100000510:     	stur	x0, [x29, #-0x10]
100000514:     	stur	w1, [x29, #-0x14]
100000518:     	str	w2, [sp, #0x18]
10000051c:     	ldur	x8, [x29, #-0x10]
100000520:     	ldr	w8, [x8]
100000524:     	str	w8, [sp, #0x14]
100000528:     	ldur	w9, [x29, #-0x14]
10000052c:     	mov	w8, #0xcc3f             ; =52287
100000530:     	movk	w8, #0xdfc3, lsl #16
100000534:     	mul	w10, w8, w9
100000538:     	mov	w9, #0x5bcf             ; =23503
10000053c:     	movk	w9, #0x8510, lsl #16
100000540:     	add	w10, w10, w9
100000544:     	str	w10, [sp, #0x10]
100000548:     	ldr	w10, [sp, #0x14]
10000054c:     	mul	w8, w8, w10
100000550:     	add	w8, w8, w9
100000554:     	str	w8, [sp, #0xc]
100000558:     	ldr	w8, [sp, #0x10]
10000055c:     	ldr	w9, [sp, #0xc]
100000560:     	add	w8, w8, w9
100000564:     	mov	w9, #0xa431             ; =42033
100000568:     	movk	w9, #0x7aef, lsl #16
10000056c:     	add	w8, w8, w9
100000570:     	str	w8, [sp, #0x10]
100000574:     	ldr	w9, [sp, #0x10]
100000578:     	mov	w8, #0x3                ; =3
10000057c:     	mul	w8, w8, w9
100000580:     	mov	w9, #0x4862             ; =18530
100000584:     	movk	w9, #0xf5df, lsl #16
100000588:     	add	w8, w8, w9
10000058c:     	mov	w9, #0x2284             ; =8836
100000590:     	movk	w9, #0x227a, lsl #16
100000594:     	add	w8, w8, w9
100000598:     	mov	w9, #0xa431             ; =42033
10000059c:     	movk	w9, #0x7aef, lsl #16
1000005a0:     	add	w8, w8, w9
1000005a4:     	str	w8, [sp, #0x10]
1000005a8:     	ldr	w8, [sp, #0x10]
1000005ac:     	mov	w9, #0xa431             ; =42033
1000005b0:     	movk	w9, #0x7aef, lsl #16
1000005b4:     	add	w9, w8, w9
1000005b8:     	mov	w8, #0x23bf             ; =9151
1000005bc:     	movk	w8, #0x7082, lsl #16
1000005c0:     	mul	w8, w8, w9
1000005c4:     	stur	w8, [x29, #-0x14]
1000005c8:     	ldur	w0, [x29, #-0x14]
1000005cc:     	bl	0x100000818 <_record_event>
1000005d0:     	ldr	w8, [sp, #0x18]
1000005d4:     	tbnz	w8, #0x1f, 0x1000005dc <_region_pipeline+0xe4>
1000005d8:     	b	0x1000005e8 <_region_pipeline+0xf0>
1000005dc:     	ldur	w8, [x29, #-0x14]
1000005e0:     	stur	w8, [x29, #-0x4]
1000005e4:     	b	0x1000006c8 <_region_pipeline+0x1d0>
1000005e8:     	b	0x1000005ec <_region_pipeline+0xf4>
1000005ec:     	ldr	w8, [sp, #0x18]
1000005f0:     	subs	w9, w8, #0x1
1000005f4:     	str	w9, [sp, #0x18]
1000005f8:     	subs	w8, w8, #0x0
1000005fc:     	b.gt	0x100000604 <_region_pipeline+0x10c>
100000600:     	b	0x1000006bc <_region_pipeline+0x1c4>
100000604:     	ldur	w0, [x29, #-0x14]
100000608:     	bl	0x100000844 <_next_value>
10000060c:     	ldr	w9, [sp]
100000610:     	str	w0, [sp, #0x14]
100000614:     	ldur	w10, [x29, #-0x14]
100000618:     	mov	w8, #0xa955             ; =43349
10000061c:     	movk	w8, #0x467, lsl #16
100000620:     	mul	w10, w8, w10
100000624:     	add	w10, w10, w9
100000628:     	str	w10, [sp, #0x8]
10000062c:     	ldr	w10, [sp, #0x14]
100000630:     	mul	w8, w8, w10
100000634:     	add	w8, w8, w9
100000638:     	str	w8, [sp, #0x4]
10000063c:     	ldr	w8, [sp, #0x8]
100000640:     	ldr	w10, [sp, #0x4]
100000644:     	add	w8, w8, w10
100000648:     	mov	w10, #0xf397            ; =62359
10000064c:     	movk	w10, #0xaec3, lsl #16
100000650:     	add	w8, w8, w10
100000654:     	str	w8, [sp, #0x8]
100000658:     	ldr	w10, [sp, #0x8]
10000065c:     	mov	w8, #0x5                ; =5
100000660:     	mul	w8, w8, w10
100000664:     	mov	w10, #0xce5c            ; =52828
100000668:     	movk	w10, #0xbb0f, lsl #16
10000066c:     	add	w8, w8, w10
100000670:     	mov	w10, #0x5244            ; =21060
100000674:     	movk	w10, #0x8fee, lsl #16
100000678:     	add	w8, w8, w10
10000067c:     	add	w8, w8, w9
100000680:     	str	w8, [sp, #0x8]
100000684:     	ldr	w8, [sp, #0x8]
100000688:     	mov	w9, #0xf397             ; =62359
10000068c:     	movk	w9, #0xaec3, lsl #16
100000690:     	add	w9, w8, w9
100000694:     	mov	w8, #0xbfd              ; =3069
100000698:     	movk	w8, #0xc02b, lsl #16
10000069c:     	mul	w8, w8, w9
1000006a0:     	stur	w8, [x29, #-0x14]
1000006a4:     	ldur	w8, [x29, #-0x14]
1000006a8:     	ldur	x9, [x29, #-0x10]
1000006ac:     	str	w8, [x9]
1000006b0:     	ldr	w0, [sp, #0x14]
1000006b4:     	bl	0x100000818 <_record_event>
1000006b8:     	b	0x1000005ec <_region_pipeline+0xf4>
1000006bc:     	ldur	w8, [x29, #-0x14]
1000006c0:     	stur	w8, [x29, #-0x4]
1000006c4:     	b	0x1000006c8 <_region_pipeline+0x1d0>
1000006c8:     	ldur	w0, [x29, #-0x4]
1000006cc:     	ldp	x29, x30, [sp, #0x30]
1000006d0:     	add	sp, sp, #0x40
1000006d4:     	ret

00000001000006d8 <_region_outputs>:
1000006d8:     	sub	sp, sp, #0x30
1000006dc:     	stp	x29, x30, [sp, #0x20]
1000006e0:     	add	x29, sp, #0x20
1000006e4:     	mov	w10, #0x6571            ; =25969
1000006e8:     	movk	w10, #0xbd9, lsl #16
1000006ec:     	mov	w8, #0x1a01             ; =6657
1000006f0:     	movk	w8, #0xcfe2, lsl #16
1000006f4:     	stur	x0, [x29, #-0x8]
1000006f8:     	stur	w1, [x29, #-0xc]
1000006fc:     	str	w2, [sp, #0x10]
100000700:     	ldur	w11, [x29, #-0xc]
100000704:     	mov	w9, #0xe601             ; =58881
100000708:     	movk	w9, #0x72c1, lsl #16
10000070c:     	mul	w11, w9, w11
100000710:     	add	w11, w11, w10
100000714:     	str	w11, [sp, #0x8]
100000718:     	ldr	w11, [sp, #0x10]
10000071c:     	mul	w9, w9, w11
100000720:     	add	w9, w9, w10
100000724:     	str	w9, [sp, #0x4]
100000728:     	mov	w9, #0xab82             ; =43906
10000072c:     	movk	w9, #0xaab9, lsl #16
100000730:     	str	w9, [sp]
100000734:     	ldr	w9, [sp]
100000738:     	ldr	w11, [sp, #0x8]
10000073c:     	add	w9, w9, w11
100000740:     	mov	w11, #0x9a8f            ; =39567
100000744:     	movk	w11, #0xf426, lsl #16
100000748:     	add	w9, w9, w11
10000074c:     	str	w9, [sp]
100000750:     	ldr	w11, [sp]
100000754:     	mov	w9, #0x3                ; =3
100000758:     	mul	w9, w9, w11
10000075c:     	mov	w11, #0x351e            ; =13598
100000760:     	movk	w11, #0xe84d, lsl #16
100000764:     	add	w9, w9, w11
100000768:     	ldr	w11, [sp, #0x4]
10000076c:     	add	w9, w9, w11
100000770:     	mov	w11, #0x9a8f            ; =39567
100000774:     	movk	w11, #0xf426, lsl #16
100000778:     	add	w9, w9, w11
10000077c:     	str	w9, [sp, #0x8]
100000780:     	ldr	w9, [sp, #0x8]
100000784:     	ldr	w11, [sp]
100000788:     	subs	w9, w9, w11
10000078c:     	add	w9, w9, w10
100000790:     	str	w9, [sp, #0x4]
100000794:     	ldr	w9, [sp]
100000798:     	mov	w10, #0x9a8f            ; =39567
10000079c:     	movk	w10, #0xf426, lsl #16
1000007a0:     	add	w9, w9, w10
1000007a4:     	mul	w9, w8, w9
1000007a8:     	str	w9, [sp, #0xc]
1000007ac:     	ldr	w9, [sp, #0x8]
1000007b0:     	mov	w10, #0x9a8f            ; =39567
1000007b4:     	movk	w10, #0xf426, lsl #16
1000007b8:     	add	w9, w9, w10
1000007bc:     	mul	w9, w8, w9
1000007c0:     	stur	w9, [x29, #-0xc]
1000007c4:     	ldr	w9, [sp, #0x4]
1000007c8:     	mov	w10, #0x9a8f            ; =39567
1000007cc:     	movk	w10, #0xf426, lsl #16
1000007d0:     	add	w9, w9, w10
1000007d4:     	mul	w8, w8, w9
1000007d8:     	str	w8, [sp, #0x10]
1000007dc:     	ldur	w0, [x29, #-0xc]
1000007e0:     	bl	0x100000818 <_record_event>
1000007e4:     	ldr	w8, [sp, #0x10]
1000007e8:     	ldur	x9, [x29, #-0x8]
1000007ec:     	str	w8, [x9]
1000007f0:     	ldr	w8, [sp, #0xc]
1000007f4:     	ldur	x9, [x29, #-0x8]
1000007f8:     	str	w8, [x9, #0x4]
1000007fc:     	ldur	w8, [x29, #-0xc]
100000800:     	ldr	w9, [sp, #0x10]
100000804:     	subs	w8, w8, w9
100000808:     	cset	w0, eq
10000080c:     	ldp	x29, x30, [sp, #0x20]
100000810:     	add	sp, sp, #0x30
100000814:     	ret

0000000100000818 <_record_event>:
100000818:     	sub	sp, sp, #0x10
10000081c:     	str	w0, [sp, #0xc]
100000820:     	adrp	x9, 0x100008000 <_event_hash>
100000824:     	ldr	w8, [x9]
100000828:     	mov	w10, #0x21              ; =33
10000082c:     	mul	w8, w8, w10
100000830:     	ldr	w10, [sp, #0xc]
100000834:     	eor	w8, w8, w10
100000838:     	str	w8, [x9]
10000083c:     	add	sp, sp, #0x10
100000840:     	ret

0000000100000844 <_next_value>:
100000844:     	sub	sp, sp, #0x20
100000848:     	stp	x29, x30, [sp, #0x10]
10000084c:     	add	x29, sp, #0x10
100000850:     	stur	w0, [x29, #-0x4]
100000854:     	ldur	w0, [x29, #-0x4]
100000858:     	bl	0x100000818 <_record_event>
10000085c:     	ldur	w10, [x29, #-0x4]
100000860:     	adrp	x9, 0x100008000 <_event_hash>
100000864:     	add	x9, x9, #0x4
100000868:     	ldr	w8, [x9, #0x4]
10000086c:     	add	w8, w8, w10
100000870:     	str	w8, [x9, #0x4]
100000874:     	ldur	w8, [x29, #-0x4]
100000878:     	ldr	w9, [x9, #0x4]
10000087c:     	add	w0, w8, w9
100000880:     	ldp	x29, x30, [sp, #0x10]
100000884:     	add	sp, sp, #0x20
100000888:     	ret

000000010000088c <_main>:
10000088c:     	sub	sp, sp, #0xb0
100000890:     	stp	x29, x30, [sp, #0xa0]
100000894:     	add	x29, sp, #0xa0
100000898:     	stur	wzr, [x29, #-0x4]
10000089c:     	stur	w0, [x29, #-0x8]
1000008a0:     	stur	x1, [x29, #-0x10]
1000008a4:     	ldur	w8, [x29, #-0x8]
1000008a8:     	subs	w8, w8, #0x3
1000008ac:     	b.ne	0x1000008b4 <_main+0x28>
1000008b0:     	b	0x1000008c0 <_main+0x34>
1000008b4:     	mov	w8, #0x2                ; =2
1000008b8:     	stur	w8, [x29, #-0x4]
1000008bc:     	b	0x100000a9c <_main+0x210>
1000008c0:     	ldur	x8, [x29, #-0x10]
1000008c4:     	ldr	x0, [x8, #0x8]
1000008c8:     	mov	x1, #0x0                ; =0
1000008cc:     	str	x1, [sp, #0x40]
1000008d0:     	mov	w2, #0xa                ; =10
1000008d4:     	str	w2, [sp, #0x4c]
1000008d8:     	bl	0x100000ac4 <_strtoul+0x100000ac4>
1000008dc:     	ldr	x1, [sp, #0x40]
1000008e0:     	ldr	w2, [sp, #0x4c]
1000008e4:     	stur	x0, [x29, #-0x18]
1000008e8:     	ldur	x8, [x29, #-0x10]
1000008ec:     	ldr	x0, [x8, #0x10]
1000008f0:     	bl	0x100000ac4 <_strtoul+0x100000ac4>
1000008f4:     	mov	x8, x0
1000008f8:     	stur	w8, [x29, #-0x1c]
1000008fc:     	stur	wzr, [x29, #-0x20]
100000900:     	mov	w0, #0x6                ; =6
100000904:     	sub	x1, x29, #0x30
100000908:     	bl	0x100000aac <_strtoul+0x100000aac>
10000090c:     	cbnz	w0, 0x100000914 <_main+0x88>
100000910:     	b	0x100000920 <_main+0x94>
100000914:     	mov	w8, #0x2                ; =2
100000918:     	stur	w8, [x29, #-0x4]
10000091c:     	b	0x100000a9c <_main+0x210>
100000920:     	stur	xzr, [x29, #-0x48]
100000924:     	b	0x100000928 <_main+0x9c>
100000928:     	ldur	x8, [x29, #-0x48]
10000092c:     	ldur	x9, [x29, #-0x18]
100000930:     	subs	x8, x8, x9
100000934:     	b.lo	0x10000093c <_main+0xb0>
100000938:     	b	0x1000009d8 <_main+0x14c>
10000093c:     	ldur	w9, [x29, #-0x1c]
100000940:     	ldur	w8, [x29, #-0x1c]
100000944:     	eor	w8, w8, w9, lsl #13
100000948:     	stur	w8, [x29, #-0x1c]
10000094c:     	ldur	w9, [x29, #-0x1c]
100000950:     	ldur	w8, [x29, #-0x1c]
100000954:     	eor	w8, w8, w9, lsr #17
100000958:     	stur	w8, [x29, #-0x1c]
10000095c:     	ldur	w9, [x29, #-0x1c]
100000960:     	ldur	w8, [x29, #-0x1c]
100000964:     	eor	w8, w8, w9, lsl #5
100000968:     	stur	w8, [x29, #-0x1c]
10000096c:     	ldur	w1, [x29, #-0x1c]
100000970:     	ldur	x8, [x29, #-0x48]
100000974:     	mov	x10, #0xa               ; =10
100000978:     	udiv	x9, x8, x10
10000097c:     	mul	x9, x9, x10
100000980:     	subs	x8, x8, x9
100000984:     	subs	w2, w8, #0x1
100000988:     	adrp	x0, 0x100008000 <_event_hash>
10000098c:     	add	x0, x0, #0x4
100000990:     	str	x0, [sp, #0x38]
100000994:     	bl	0x1000004f8 <_region_pipeline>
100000998:     	mov	x9, x0
10000099c:     	ldr	x0, [sp, #0x38]
1000009a0:     	ldur	w8, [x29, #-0x20]
1000009a4:     	add	w8, w8, w9
1000009a8:     	stur	w8, [x29, #-0x20]
1000009ac:     	ldur	w1, [x29, #-0x1c]
1000009b0:     	ldur	w2, [x29, #-0x20]
1000009b4:     	bl	0x1000006d8 <_region_outputs>
1000009b8:     	ldur	w8, [x29, #-0x20]
1000009bc:     	add	w8, w8, w0
1000009c0:     	stur	w8, [x29, #-0x20]
1000009c4:     	b	0x1000009c8 <_main+0x13c>
1000009c8:     	ldur	x8, [x29, #-0x48]
1000009cc:     	add	x8, x8, #0x1
1000009d0:     	stur	x8, [x29, #-0x48]
1000009d4:     	b	0x100000928 <_main+0x9c>
1000009d8:     	mov	w0, #0x6                ; =6
1000009dc:     	sub	x1, x29, #0x40
1000009e0:     	bl	0x100000aac <_strtoul+0x100000aac>
1000009e4:     	cbnz	w0, 0x1000009ec <_main+0x160>
1000009e8:     	b	0x1000009f8 <_main+0x16c>
1000009ec:     	mov	w8, #0x2                ; =2
1000009f0:     	stur	w8, [x29, #-0x4]
1000009f4:     	b	0x100000a9c <_main+0x210>
1000009f8:     	ldur	x8, [x29, #-0x40]
1000009fc:     	ldur	x9, [x29, #-0x30]
100000a00:     	subs	x8, x8, x9
100000a04:     	scvtf	d2, x8
100000a08:     	ldur	x8, [x29, #-0x38]
100000a0c:     	ldur	x9, [x29, #-0x28]
100000a10:     	subs	x8, x8, x9
100000a14:     	scvtf	d0, x8
100000a18:     	mov	x8, #0xd695             ; =54933
100000a1c:     	movk	x8, #0xe826, lsl #16
100000a20:     	movk	x8, #0x2e0b, lsl #32
100000a24:     	movk	x8, #0x3e11, lsl #48
100000a28:     	fmov	d1, x8
100000a2c:     	fmadd	d0, d0, d1, d2
100000a30:     	str	d0, [sp, #0x50]
100000a34:     	ldr	d0, [sp, #0x50]
100000a38:     	ldur	w8, [x29, #-0x20]
100000a3c:     	mov	x13, x8
100000a40:     	adrp	x9, 0x100008000 <_event_hash>
100000a44:     	adrp	x8, 0x100008000 <_event_hash>
100000a48:     	add	x8, x8, #0x4
100000a4c:     	ldr	w9, [x9, #0x4]
100000a50:     	mov	x12, x9
100000a54:     	ldr	w9, [x8, #0x4]
100000a58:     	mov	x11, x9
100000a5c:     	ldr	w8, [x8, #0x8]
100000a60:     	mov	x10, x8
100000a64:     	adrp	x8, 0x100008000 <_event_hash>
100000a68:     	ldr	w8, [x8]
100000a6c:     	mov	x9, sp
100000a70:     	str	d0, [x9]
100000a74:     	str	x13, [x9, #0x8]
100000a78:     	str	x12, [x9, #0x10]
100000a7c:     	str	x11, [x9, #0x18]
100000a80:     	str	x10, [x9, #0x20]
100000a84:     	str	x8, [x9, #0x28]
100000a88:     	adrp	x0, 0x100000000 <_strtoul+0x100000000>
100000a8c:     	add	x0, x0, #0xad0
100000a90:     	bl	0x100000ab8 <_strtoul+0x100000ab8>
100000a94:     	stur	wzr, [x29, #-0x4]
100000a98:     	b	0x100000a9c <_main+0x210>
100000a9c:     	ldur	w0, [x29, #-0x4]
100000aa0:     	ldp	x29, x30, [sp, #0xa0]
100000aa4:     	add	sp, sp, #0xb0
100000aa8:     	ret

Disassembly of section __TEXT,__stubs:

0000000100000aac <__stubs>:
100000aac:     	adrp	x16, 0x100004000 <_strtoul+0x100004000>
100000ab0:     	ldr	x16, [x16]
100000ab4:     	br	x16
100000ab8:     	adrp	x16, 0x100004000 <_strtoul+0x100004000>
100000abc:     	ldr	x16, [x16, #0x8]
100000ac0:     	br	x16
100000ac4:     	adrp	x16, 0x100004000 <_strtoul+0x100004000>
100000ac8:     	ldr	x16, [x16, #0x10]
100000acc:     	br	x16
