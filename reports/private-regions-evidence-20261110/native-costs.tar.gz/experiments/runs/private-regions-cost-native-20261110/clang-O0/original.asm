
/Users/admin/C-SRD/experiments/runs/private-regions-cost-native-20261110/clang-O0/original:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001000004f8 <_region_pipeline>:
1000004f8:     	sub	sp, sp, #0x30
1000004fc:     	stp	x29, x30, [sp, #0x20]
100000500:     	add	x29, sp, #0x20
100000504:     	str	x0, [sp, #0x10]
100000508:     	str	w1, [sp, #0xc]
10000050c:     	str	w2, [sp, #0x8]
100000510:     	ldr	x8, [sp, #0x10]
100000514:     	ldr	w8, [x8]
100000518:     	str	w8, [sp, #0x4]
10000051c:     	ldr	w8, [sp, #0xc]
100000520:     	ldr	w9, [sp, #0x4]
100000524:     	add	w8, w8, w9
100000528:     	str	w8, [sp, #0xc]
10000052c:     	ldr	w9, [sp, #0xc]
100000530:     	mov	w8, #0x3                ; =3
100000534:     	mul	w8, w8, w9
100000538:     	add	w8, w8, #0xb
10000053c:     	str	w8, [sp, #0xc]
100000540:     	ldr	w0, [sp, #0xc]
100000544:     	bl	0x100000674 <_record_event>
100000548:     	ldr	w8, [sp, #0x8]
10000054c:     	tbnz	w8, #0x1f, 0x100000554 <_region_pipeline+0x5c>
100000550:     	b	0x100000560 <_region_pipeline+0x68>
100000554:     	ldr	w8, [sp, #0xc]
100000558:     	stur	w8, [x29, #-0x4]
10000055c:     	b	0x1000005d0 <_region_pipeline+0xd8>
100000560:     	b	0x100000564 <_region_pipeline+0x6c>
100000564:     	ldr	w8, [sp, #0x8]
100000568:     	subs	w9, w8, #0x1
10000056c:     	str	w9, [sp, #0x8]
100000570:     	subs	w8, w8, #0x0
100000574:     	b.gt	0x10000057c <_region_pipeline+0x84>
100000578:     	b	0x1000005c4 <_region_pipeline+0xcc>
10000057c:     	ldr	w0, [sp, #0xc]
100000580:     	bl	0x1000006a0 <_next_value>
100000584:     	str	w0, [sp, #0x4]
100000588:     	ldr	w8, [sp, #0xc]
10000058c:     	ldr	w9, [sp, #0x4]
100000590:     	add	w8, w8, w9
100000594:     	str	w8, [sp, #0xc]
100000598:     	ldr	w9, [sp, #0xc]
10000059c:     	mov	w8, #0x5                ; =5
1000005a0:     	mul	w8, w8, w9
1000005a4:     	subs	w8, w8, #0x7
1000005a8:     	str	w8, [sp, #0xc]
1000005ac:     	ldr	w8, [sp, #0xc]
1000005b0:     	ldr	x9, [sp, #0x10]
1000005b4:     	str	w8, [x9]
1000005b8:     	ldr	w0, [sp, #0x4]
1000005bc:     	bl	0x100000674 <_record_event>
1000005c0:     	b	0x100000564 <_region_pipeline+0x6c>
1000005c4:     	ldr	w8, [sp, #0xc]
1000005c8:     	stur	w8, [x29, #-0x4]
1000005cc:     	b	0x1000005d0 <_region_pipeline+0xd8>
1000005d0:     	ldur	w0, [x29, #-0x4]
1000005d4:     	ldp	x29, x30, [sp, #0x20]
1000005d8:     	add	sp, sp, #0x30
1000005dc:     	ret

00000001000005e0 <_region_outputs>:
1000005e0:     	sub	sp, sp, #0x30
1000005e4:     	stp	x29, x30, [sp, #0x20]
1000005e8:     	add	x29, sp, #0x20
1000005ec:     	stur	x0, [x29, #-0x8]
1000005f0:     	stur	w1, [x29, #-0xc]
1000005f4:     	str	w2, [sp, #0x10]
1000005f8:     	mov	w8, #0x11               ; =17
1000005fc:     	str	w8, [sp, #0xc]
100000600:     	ldr	w8, [sp, #0xc]
100000604:     	ldur	w9, [x29, #-0xc]
100000608:     	add	w8, w8, w9
10000060c:     	str	w8, [sp, #0xc]
100000610:     	ldr	w9, [sp, #0xc]
100000614:     	mov	w8, #0x3                ; =3
100000618:     	mul	w8, w8, w9
10000061c:     	ldr	w9, [sp, #0x10]
100000620:     	add	w8, w8, w9
100000624:     	stur	w8, [x29, #-0xc]
100000628:     	ldur	w8, [x29, #-0xc]
10000062c:     	ldr	w9, [sp, #0xc]
100000630:     	subs	w8, w8, w9
100000634:     	str	w8, [sp, #0x10]
100000638:     	ldur	w0, [x29, #-0xc]
10000063c:     	bl	0x100000674 <_record_event>
100000640:     	ldr	w8, [sp, #0x10]
100000644:     	ldur	x9, [x29, #-0x8]
100000648:     	str	w8, [x9]
10000064c:     	ldr	w8, [sp, #0xc]
100000650:     	ldur	x9, [x29, #-0x8]
100000654:     	str	w8, [x9, #0x4]
100000658:     	ldur	w8, [x29, #-0xc]
10000065c:     	ldr	w9, [sp, #0x10]
100000660:     	subs	w8, w8, w9
100000664:     	cset	w0, eq
100000668:     	ldp	x29, x30, [sp, #0x20]
10000066c:     	add	sp, sp, #0x30
100000670:     	ret

0000000100000674 <_record_event>:
100000674:     	sub	sp, sp, #0x10
100000678:     	str	w0, [sp, #0xc]
10000067c:     	adrp	x9, 0x100008000 <_event_hash>
100000680:     	ldr	w8, [x9]
100000684:     	mov	w10, #0x21              ; =33
100000688:     	mul	w8, w8, w10
10000068c:     	ldr	w10, [sp, #0xc]
100000690:     	eor	w8, w8, w10
100000694:     	str	w8, [x9]
100000698:     	add	sp, sp, #0x10
10000069c:     	ret

00000001000006a0 <_next_value>:
1000006a0:     	sub	sp, sp, #0x20
1000006a4:     	stp	x29, x30, [sp, #0x10]
1000006a8:     	add	x29, sp, #0x10
1000006ac:     	stur	w0, [x29, #-0x4]
1000006b0:     	ldur	w0, [x29, #-0x4]
1000006b4:     	bl	0x100000674 <_record_event>
1000006b8:     	ldur	w10, [x29, #-0x4]
1000006bc:     	adrp	x9, 0x100008000 <_event_hash>
1000006c0:     	add	x9, x9, #0x4
1000006c4:     	ldr	w8, [x9, #0x4]
1000006c8:     	add	w8, w8, w10
1000006cc:     	str	w8, [x9, #0x4]
1000006d0:     	ldur	w8, [x29, #-0x4]
1000006d4:     	ldr	w9, [x9, #0x4]
1000006d8:     	add	w0, w8, w9
1000006dc:     	ldp	x29, x30, [sp, #0x10]
1000006e0:     	add	sp, sp, #0x20
1000006e4:     	ret

00000001000006e8 <_main>:
1000006e8:     	sub	sp, sp, #0xb0
1000006ec:     	stp	x29, x30, [sp, #0xa0]
1000006f0:     	add	x29, sp, #0xa0
1000006f4:     	stur	wzr, [x29, #-0x4]
1000006f8:     	stur	w0, [x29, #-0x8]
1000006fc:     	stur	x1, [x29, #-0x10]
100000700:     	ldur	w8, [x29, #-0x8]
100000704:     	subs	w8, w8, #0x3
100000708:     	b.ne	0x100000710 <_main+0x28>
10000070c:     	b	0x10000071c <_main+0x34>
100000710:     	mov	w8, #0x2                ; =2
100000714:     	stur	w8, [x29, #-0x4]
100000718:     	b	0x1000008f8 <_main+0x210>
10000071c:     	ldur	x8, [x29, #-0x10]
100000720:     	ldr	x0, [x8, #0x8]
100000724:     	mov	x1, #0x0                ; =0
100000728:     	str	x1, [sp, #0x40]
10000072c:     	mov	w2, #0xa                ; =10
100000730:     	str	w2, [sp, #0x4c]
100000734:     	bl	0x100000920 <_strtoul+0x100000920>
100000738:     	ldr	x1, [sp, #0x40]
10000073c:     	ldr	w2, [sp, #0x4c]
100000740:     	stur	x0, [x29, #-0x18]
100000744:     	ldur	x8, [x29, #-0x10]
100000748:     	ldr	x0, [x8, #0x10]
10000074c:     	bl	0x100000920 <_strtoul+0x100000920>
100000750:     	mov	x8, x0
100000754:     	stur	w8, [x29, #-0x1c]
100000758:     	stur	wzr, [x29, #-0x20]
10000075c:     	mov	w0, #0x6                ; =6
100000760:     	sub	x1, x29, #0x30
100000764:     	bl	0x100000908 <_strtoul+0x100000908>
100000768:     	cbnz	w0, 0x100000770 <_main+0x88>
10000076c:     	b	0x10000077c <_main+0x94>
100000770:     	mov	w8, #0x2                ; =2
100000774:     	stur	w8, [x29, #-0x4]
100000778:     	b	0x1000008f8 <_main+0x210>
10000077c:     	stur	xzr, [x29, #-0x48]
100000780:     	b	0x100000784 <_main+0x9c>
100000784:     	ldur	x8, [x29, #-0x48]
100000788:     	ldur	x9, [x29, #-0x18]
10000078c:     	subs	x8, x8, x9
100000790:     	b.lo	0x100000798 <_main+0xb0>
100000794:     	b	0x100000834 <_main+0x14c>
100000798:     	ldur	w9, [x29, #-0x1c]
10000079c:     	ldur	w8, [x29, #-0x1c]
1000007a0:     	eor	w8, w8, w9, lsl #13
1000007a4:     	stur	w8, [x29, #-0x1c]
1000007a8:     	ldur	w9, [x29, #-0x1c]
1000007ac:     	ldur	w8, [x29, #-0x1c]
1000007b0:     	eor	w8, w8, w9, lsr #17
1000007b4:     	stur	w8, [x29, #-0x1c]
1000007b8:     	ldur	w9, [x29, #-0x1c]
1000007bc:     	ldur	w8, [x29, #-0x1c]
1000007c0:     	eor	w8, w8, w9, lsl #5
1000007c4:     	stur	w8, [x29, #-0x1c]
1000007c8:     	ldur	w1, [x29, #-0x1c]
1000007cc:     	ldur	x8, [x29, #-0x48]
1000007d0:     	mov	x10, #0xa               ; =10
1000007d4:     	udiv	x9, x8, x10
1000007d8:     	mul	x9, x9, x10
1000007dc:     	subs	x8, x8, x9
1000007e0:     	subs	w2, w8, #0x1
1000007e4:     	adrp	x0, 0x100008000 <_event_hash>
1000007e8:     	add	x0, x0, #0x4
1000007ec:     	str	x0, [sp, #0x38]
1000007f0:     	bl	0x1000004f8 <_region_pipeline>
1000007f4:     	mov	x9, x0
1000007f8:     	ldr	x0, [sp, #0x38]
1000007fc:     	ldur	w8, [x29, #-0x20]
100000800:     	add	w8, w8, w9
100000804:     	stur	w8, [x29, #-0x20]
100000808:     	ldur	w1, [x29, #-0x1c]
10000080c:     	ldur	w2, [x29, #-0x20]
100000810:     	bl	0x1000005e0 <_region_outputs>
100000814:     	ldur	w8, [x29, #-0x20]
100000818:     	add	w8, w8, w0
10000081c:     	stur	w8, [x29, #-0x20]
100000820:     	b	0x100000824 <_main+0x13c>
100000824:     	ldur	x8, [x29, #-0x48]
100000828:     	add	x8, x8, #0x1
10000082c:     	stur	x8, [x29, #-0x48]
100000830:     	b	0x100000784 <_main+0x9c>
100000834:     	mov	w0, #0x6                ; =6
100000838:     	sub	x1, x29, #0x40
10000083c:     	bl	0x100000908 <_strtoul+0x100000908>
100000840:     	cbnz	w0, 0x100000848 <_main+0x160>
100000844:     	b	0x100000854 <_main+0x16c>
100000848:     	mov	w8, #0x2                ; =2
10000084c:     	stur	w8, [x29, #-0x4]
100000850:     	b	0x1000008f8 <_main+0x210>
100000854:     	ldur	x8, [x29, #-0x40]
100000858:     	ldur	x9, [x29, #-0x30]
10000085c:     	subs	x8, x8, x9
100000860:     	scvtf	d2, x8
100000864:     	ldur	x8, [x29, #-0x38]
100000868:     	ldur	x9, [x29, #-0x28]
10000086c:     	subs	x8, x8, x9
100000870:     	scvtf	d0, x8
100000874:     	mov	x8, #0xd695             ; =54933
100000878:     	movk	x8, #0xe826, lsl #16
10000087c:     	movk	x8, #0x2e0b, lsl #32
100000880:     	movk	x8, #0x3e11, lsl #48
100000884:     	fmov	d1, x8
100000888:     	fmadd	d0, d0, d1, d2
10000088c:     	str	d0, [sp, #0x50]
100000890:     	ldr	d0, [sp, #0x50]
100000894:     	ldur	w8, [x29, #-0x20]
100000898:     	mov	x13, x8
10000089c:     	adrp	x9, 0x100008000 <_event_hash>
1000008a0:     	adrp	x8, 0x100008000 <_event_hash>
1000008a4:     	add	x8, x8, #0x4
1000008a8:     	ldr	w9, [x9, #0x4]
1000008ac:     	mov	x12, x9
1000008b0:     	ldr	w9, [x8, #0x4]
1000008b4:     	mov	x11, x9
1000008b8:     	ldr	w8, [x8, #0x8]
1000008bc:     	mov	x10, x8
1000008c0:     	adrp	x8, 0x100008000 <_event_hash>
1000008c4:     	ldr	w8, [x8]
1000008c8:     	mov	x9, sp
1000008cc:     	str	d0, [x9]
1000008d0:     	str	x13, [x9, #0x8]
1000008d4:     	str	x12, [x9, #0x10]
1000008d8:     	str	x11, [x9, #0x18]
1000008dc:     	str	x10, [x9, #0x20]
1000008e0:     	str	x8, [x9, #0x28]
1000008e4:     	adrp	x0, 0x100000000 <_strtoul+0x100000000>
1000008e8:     	add	x0, x0, #0x92c
1000008ec:     	bl	0x100000914 <_strtoul+0x100000914>
1000008f0:     	stur	wzr, [x29, #-0x4]
1000008f4:     	b	0x1000008f8 <_main+0x210>
1000008f8:     	ldur	w0, [x29, #-0x4]
1000008fc:     	ldp	x29, x30, [sp, #0xa0]
100000900:     	add	sp, sp, #0xb0
100000904:     	ret

Disassembly of section __TEXT,__stubs:

0000000100000908 <__stubs>:
100000908:     	adrp	x16, 0x100004000 <_strtoul+0x100004000>
10000090c:     	ldr	x16, [x16]
100000910:     	br	x16
100000914:     	adrp	x16, 0x100004000 <_strtoul+0x100004000>
100000918:     	ldr	x16, [x16, #0x8]
10000091c:     	br	x16
100000920:     	adrp	x16, 0x100004000 <_strtoul+0x100004000>
100000924:     	ldr	x16, [x16, #0x10]
100000928:     	br	x16
