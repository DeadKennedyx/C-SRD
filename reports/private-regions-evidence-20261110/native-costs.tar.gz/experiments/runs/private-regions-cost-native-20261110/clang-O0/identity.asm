
/Users/admin/C-SRD/experiments/runs/private-regions-cost-native-20261110/clang-O0/identity:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001000004f8 <_region_pipeline>:
1000004f8:     	sub	sp, sp, #0x40
1000004fc:     	stp	x29, x30, [sp, #0x30]
100000500:     	add	x29, sp, #0x30
100000504:     	stur	x0, [x29, #-0x10]
100000508:     	stur	w1, [x29, #-0x14]
10000050c:     	str	w2, [sp, #0x18]
100000510:     	ldur	x8, [x29, #-0x10]
100000514:     	ldr	w8, [x8]
100000518:     	str	w8, [sp, #0x14]
10000051c:     	ldur	w8, [x29, #-0x14]
100000520:     	str	w8, [sp, #0x10]
100000524:     	ldr	w8, [sp, #0x14]
100000528:     	str	w8, [sp, #0xc]
10000052c:     	ldr	w8, [sp, #0x10]
100000530:     	ldr	w9, [sp, #0xc]
100000534:     	add	w8, w8, w9
100000538:     	str	w8, [sp, #0x10]
10000053c:     	ldr	w9, [sp, #0x10]
100000540:     	mov	w8, #0x3                ; =3
100000544:     	mul	w8, w8, w9
100000548:     	add	w8, w8, #0xb
10000054c:     	str	w8, [sp, #0x10]
100000550:     	ldr	w8, [sp, #0x10]
100000554:     	stur	w8, [x29, #-0x14]
100000558:     	ldur	w0, [x29, #-0x14]
10000055c:     	bl	0x1000006cc <_record_event>
100000560:     	ldr	w8, [sp, #0x18]
100000564:     	tbnz	w8, #0x1f, 0x10000056c <_region_pipeline+0x74>
100000568:     	b	0x100000578 <_region_pipeline+0x80>
10000056c:     	ldur	w8, [x29, #-0x14]
100000570:     	stur	w8, [x29, #-0x4]
100000574:     	b	0x100000600 <_region_pipeline+0x108>
100000578:     	b	0x10000057c <_region_pipeline+0x84>
10000057c:     	ldr	w8, [sp, #0x18]
100000580:     	subs	w9, w8, #0x1
100000584:     	str	w9, [sp, #0x18]
100000588:     	subs	w8, w8, #0x0
10000058c:     	b.gt	0x100000594 <_region_pipeline+0x9c>
100000590:     	b	0x1000005f4 <_region_pipeline+0xfc>
100000594:     	ldur	w0, [x29, #-0x14]
100000598:     	bl	0x1000006f8 <_next_value>
10000059c:     	str	w0, [sp, #0x14]
1000005a0:     	ldur	w8, [x29, #-0x14]
1000005a4:     	str	w8, [sp, #0x8]
1000005a8:     	ldr	w8, [sp, #0x14]
1000005ac:     	str	w8, [sp, #0x4]
1000005b0:     	ldr	w8, [sp, #0x8]
1000005b4:     	ldr	w9, [sp, #0x4]
1000005b8:     	add	w8, w8, w9
1000005bc:     	str	w8, [sp, #0x8]
1000005c0:     	ldr	w9, [sp, #0x8]
1000005c4:     	mov	w8, #0x5                ; =5
1000005c8:     	mul	w8, w8, w9
1000005cc:     	subs	w8, w8, #0x7
1000005d0:     	str	w8, [sp, #0x8]
1000005d4:     	ldr	w8, [sp, #0x8]
1000005d8:     	stur	w8, [x29, #-0x14]
1000005dc:     	ldur	w8, [x29, #-0x14]
1000005e0:     	ldur	x9, [x29, #-0x10]
1000005e4:     	str	w8, [x9]
1000005e8:     	ldr	w0, [sp, #0x14]
1000005ec:     	bl	0x1000006cc <_record_event>
1000005f0:     	b	0x10000057c <_region_pipeline+0x84>
1000005f4:     	ldur	w8, [x29, #-0x14]
1000005f8:     	stur	w8, [x29, #-0x4]
1000005fc:     	b	0x100000600 <_region_pipeline+0x108>
100000600:     	ldur	w0, [x29, #-0x4]
100000604:     	ldp	x29, x30, [sp, #0x30]
100000608:     	add	sp, sp, #0x40
10000060c:     	ret

0000000100000610 <_region_outputs>:
100000610:     	sub	sp, sp, #0x30
100000614:     	stp	x29, x30, [sp, #0x20]
100000618:     	add	x29, sp, #0x20
10000061c:     	stur	x0, [x29, #-0x8]
100000620:     	stur	w1, [x29, #-0xc]
100000624:     	str	w2, [sp, #0x10]
100000628:     	ldur	w8, [x29, #-0xc]
10000062c:     	str	w8, [sp, #0x8]
100000630:     	ldr	w8, [sp, #0x10]
100000634:     	str	w8, [sp, #0x4]
100000638:     	mov	w8, #0x11               ; =17
10000063c:     	str	w8, [sp]
100000640:     	ldr	w8, [sp]
100000644:     	ldr	w9, [sp, #0x8]
100000648:     	add	w8, w8, w9
10000064c:     	str	w8, [sp]
100000650:     	ldr	w9, [sp]
100000654:     	mov	w8, #0x3                ; =3
100000658:     	mul	w8, w8, w9
10000065c:     	ldr	w9, [sp, #0x4]
100000660:     	add	w8, w8, w9
100000664:     	str	w8, [sp, #0x8]
100000668:     	ldr	w8, [sp, #0x8]
10000066c:     	ldr	w9, [sp]
100000670:     	subs	w8, w8, w9
100000674:     	str	w8, [sp, #0x4]
100000678:     	ldr	w8, [sp]
10000067c:     	str	w8, [sp, #0xc]
100000680:     	ldr	w8, [sp, #0x8]
100000684:     	stur	w8, [x29, #-0xc]
100000688:     	ldr	w8, [sp, #0x4]
10000068c:     	str	w8, [sp, #0x10]
100000690:     	ldur	w0, [x29, #-0xc]
100000694:     	bl	0x1000006cc <_record_event>
100000698:     	ldr	w8, [sp, #0x10]
10000069c:     	ldur	x9, [x29, #-0x8]
1000006a0:     	str	w8, [x9]
1000006a4:     	ldr	w8, [sp, #0xc]
1000006a8:     	ldur	x9, [x29, #-0x8]
1000006ac:     	str	w8, [x9, #0x4]
1000006b0:     	ldur	w8, [x29, #-0xc]
1000006b4:     	ldr	w9, [sp, #0x10]
1000006b8:     	subs	w8, w8, w9
1000006bc:     	cset	w0, eq
1000006c0:     	ldp	x29, x30, [sp, #0x20]
1000006c4:     	add	sp, sp, #0x30
1000006c8:     	ret

00000001000006cc <_record_event>:
1000006cc:     	sub	sp, sp, #0x10
1000006d0:     	str	w0, [sp, #0xc]
1000006d4:     	adrp	x9, 0x100008000 <_event_hash>
1000006d8:     	ldr	w8, [x9]
1000006dc:     	mov	w10, #0x21              ; =33
1000006e0:     	mul	w8, w8, w10
1000006e4:     	ldr	w10, [sp, #0xc]
1000006e8:     	eor	w8, w8, w10
1000006ec:     	str	w8, [x9]
1000006f0:     	add	sp, sp, #0x10
1000006f4:     	ret

00000001000006f8 <_next_value>:
1000006f8:     	sub	sp, sp, #0x20
1000006fc:     	stp	x29, x30, [sp, #0x10]
100000700:     	add	x29, sp, #0x10
100000704:     	stur	w0, [x29, #-0x4]
100000708:     	ldur	w0, [x29, #-0x4]
10000070c:     	bl	0x1000006cc <_record_event>
100000710:     	ldur	w10, [x29, #-0x4]
100000714:     	adrp	x9, 0x100008000 <_event_hash>
100000718:     	add	x9, x9, #0x4
10000071c:     	ldr	w8, [x9, #0x4]
100000720:     	add	w8, w8, w10
100000724:     	str	w8, [x9, #0x4]
100000728:     	ldur	w8, [x29, #-0x4]
10000072c:     	ldr	w9, [x9, #0x4]
100000730:     	add	w0, w8, w9
100000734:     	ldp	x29, x30, [sp, #0x10]
100000738:     	add	sp, sp, #0x20
10000073c:     	ret

0000000100000740 <_main>:
100000740:     	sub	sp, sp, #0xb0
100000744:     	stp	x29, x30, [sp, #0xa0]
100000748:     	add	x29, sp, #0xa0
10000074c:     	stur	wzr, [x29, #-0x4]
100000750:     	stur	w0, [x29, #-0x8]
100000754:     	stur	x1, [x29, #-0x10]
100000758:     	ldur	w8, [x29, #-0x8]
10000075c:     	subs	w8, w8, #0x3
100000760:     	b.ne	0x100000768 <_main+0x28>
100000764:     	b	0x100000774 <_main+0x34>
100000768:     	mov	w8, #0x2                ; =2
10000076c:     	stur	w8, [x29, #-0x4]
100000770:     	b	0x100000950 <_main+0x210>
100000774:     	ldur	x8, [x29, #-0x10]
100000778:     	ldr	x0, [x8, #0x8]
10000077c:     	mov	x1, #0x0                ; =0
100000780:     	str	x1, [sp, #0x40]
100000784:     	mov	w2, #0xa                ; =10
100000788:     	str	w2, [sp, #0x4c]
10000078c:     	bl	0x100000978 <_strtoul+0x100000978>
100000790:     	ldr	x1, [sp, #0x40]
100000794:     	ldr	w2, [sp, #0x4c]
100000798:     	stur	x0, [x29, #-0x18]
10000079c:     	ldur	x8, [x29, #-0x10]
1000007a0:     	ldr	x0, [x8, #0x10]
1000007a4:     	bl	0x100000978 <_strtoul+0x100000978>
1000007a8:     	mov	x8, x0
1000007ac:     	stur	w8, [x29, #-0x1c]
1000007b0:     	stur	wzr, [x29, #-0x20]
1000007b4:     	mov	w0, #0x6                ; =6
1000007b8:     	sub	x1, x29, #0x30
1000007bc:     	bl	0x100000960 <_strtoul+0x100000960>
1000007c0:     	cbnz	w0, 0x1000007c8 <_main+0x88>
1000007c4:     	b	0x1000007d4 <_main+0x94>
1000007c8:     	mov	w8, #0x2                ; =2
1000007cc:     	stur	w8, [x29, #-0x4]
1000007d0:     	b	0x100000950 <_main+0x210>
1000007d4:     	stur	xzr, [x29, #-0x48]
1000007d8:     	b	0x1000007dc <_main+0x9c>
1000007dc:     	ldur	x8, [x29, #-0x48]
1000007e0:     	ldur	x9, [x29, #-0x18]
1000007e4:     	subs	x8, x8, x9
1000007e8:     	b.lo	0x1000007f0 <_main+0xb0>
1000007ec:     	b	0x10000088c <_main+0x14c>
1000007f0:     	ldur	w9, [x29, #-0x1c]
1000007f4:     	ldur	w8, [x29, #-0x1c]
1000007f8:     	eor	w8, w8, w9, lsl #13
1000007fc:     	stur	w8, [x29, #-0x1c]
100000800:     	ldur	w9, [x29, #-0x1c]
100000804:     	ldur	w8, [x29, #-0x1c]
100000808:     	eor	w8, w8, w9, lsr #17
10000080c:     	stur	w8, [x29, #-0x1c]
100000810:     	ldur	w9, [x29, #-0x1c]
100000814:     	ldur	w8, [x29, #-0x1c]
100000818:     	eor	w8, w8, w9, lsl #5
10000081c:     	stur	w8, [x29, #-0x1c]
100000820:     	ldur	w1, [x29, #-0x1c]
100000824:     	ldur	x8, [x29, #-0x48]
100000828:     	mov	x10, #0xa               ; =10
10000082c:     	udiv	x9, x8, x10
100000830:     	mul	x9, x9, x10
100000834:     	subs	x8, x8, x9
100000838:     	subs	w2, w8, #0x1
10000083c:     	adrp	x0, 0x100008000 <_event_hash>
100000840:     	add	x0, x0, #0x4
100000844:     	str	x0, [sp, #0x38]
100000848:     	bl	0x1000004f8 <_region_pipeline>
10000084c:     	mov	x9, x0
100000850:     	ldr	x0, [sp, #0x38]
100000854:     	ldur	w8, [x29, #-0x20]
100000858:     	add	w8, w8, w9
10000085c:     	stur	w8, [x29, #-0x20]
100000860:     	ldur	w1, [x29, #-0x1c]
100000864:     	ldur	w2, [x29, #-0x20]
100000868:     	bl	0x100000610 <_region_outputs>
10000086c:     	ldur	w8, [x29, #-0x20]
100000870:     	add	w8, w8, w0
100000874:     	stur	w8, [x29, #-0x20]
100000878:     	b	0x10000087c <_main+0x13c>
10000087c:     	ldur	x8, [x29, #-0x48]
100000880:     	add	x8, x8, #0x1
100000884:     	stur	x8, [x29, #-0x48]
100000888:     	b	0x1000007dc <_main+0x9c>
10000088c:     	mov	w0, #0x6                ; =6
100000890:     	sub	x1, x29, #0x40
100000894:     	bl	0x100000960 <_strtoul+0x100000960>
100000898:     	cbnz	w0, 0x1000008a0 <_main+0x160>
10000089c:     	b	0x1000008ac <_main+0x16c>
1000008a0:     	mov	w8, #0x2                ; =2
1000008a4:     	stur	w8, [x29, #-0x4]
1000008a8:     	b	0x100000950 <_main+0x210>
1000008ac:     	ldur	x8, [x29, #-0x40]
1000008b0:     	ldur	x9, [x29, #-0x30]
1000008b4:     	subs	x8, x8, x9
1000008b8:     	scvtf	d2, x8
1000008bc:     	ldur	x8, [x29, #-0x38]
1000008c0:     	ldur	x9, [x29, #-0x28]
1000008c4:     	subs	x8, x8, x9
1000008c8:     	scvtf	d0, x8
1000008cc:     	mov	x8, #0xd695             ; =54933
1000008d0:     	movk	x8, #0xe826, lsl #16
1000008d4:     	movk	x8, #0x2e0b, lsl #32
1000008d8:     	movk	x8, #0x3e11, lsl #48
1000008dc:     	fmov	d1, x8
1000008e0:     	fmadd	d0, d0, d1, d2
1000008e4:     	str	d0, [sp, #0x50]
1000008e8:     	ldr	d0, [sp, #0x50]
1000008ec:     	ldur	w8, [x29, #-0x20]
1000008f0:     	mov	x13, x8
1000008f4:     	adrp	x9, 0x100008000 <_event_hash>
1000008f8:     	adrp	x8, 0x100008000 <_event_hash>
1000008fc:     	add	x8, x8, #0x4
100000900:     	ldr	w9, [x9, #0x4]
100000904:     	mov	x12, x9
100000908:     	ldr	w9, [x8, #0x4]
10000090c:     	mov	x11, x9
100000910:     	ldr	w8, [x8, #0x8]
100000914:     	mov	x10, x8
100000918:     	adrp	x8, 0x100008000 <_event_hash>
10000091c:     	ldr	w8, [x8]
100000920:     	mov	x9, sp
100000924:     	str	d0, [x9]
100000928:     	str	x13, [x9, #0x8]
10000092c:     	str	x12, [x9, #0x10]
100000930:     	str	x11, [x9, #0x18]
100000934:     	str	x10, [x9, #0x20]
100000938:     	str	x8, [x9, #0x28]
10000093c:     	adrp	x0, 0x100000000 <_strtoul+0x100000000>
100000940:     	add	x0, x0, #0x984
100000944:     	bl	0x10000096c <_strtoul+0x10000096c>
100000948:     	stur	wzr, [x29, #-0x4]
10000094c:     	b	0x100000950 <_main+0x210>
100000950:     	ldur	w0, [x29, #-0x4]
100000954:     	ldp	x29, x30, [sp, #0xa0]
100000958:     	add	sp, sp, #0xb0
10000095c:     	ret

Disassembly of section __TEXT,__stubs:

0000000100000960 <__stubs>:
100000960:     	adrp	x16, 0x100004000 <_strtoul+0x100004000>
100000964:     	ldr	x16, [x16]
100000968:     	br	x16
10000096c:     	adrp	x16, 0x100004000 <_strtoul+0x100004000>
100000970:     	ldr	x16, [x16, #0x8]
100000974:     	br	x16
100000978:     	adrp	x16, 0x100004000 <_strtoul+0x100004000>
10000097c:     	ldr	x16, [x16, #0x10]
100000980:     	br	x16
