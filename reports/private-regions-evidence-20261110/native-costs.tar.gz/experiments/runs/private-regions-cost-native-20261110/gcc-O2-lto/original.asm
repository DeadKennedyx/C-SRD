
/Users/admin/C-SRD/experiments/runs/private-regions-cost-native-20261110/gcc-O2-lto/original:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001000006a0 <_region_pipeline>:
1000006a0:     	mov	x6, x0
1000006a4:     	ldr	w0, [x0]
1000006a8:     	adrp	x7, 0x100008000 <_memory>
1000006ac:     	add	w1, w1, w0
1000006b0:     	add	w1, w1, w1, lsl #1
1000006b4:     	add	w0, w1, #0xb
1000006b8:     	ldr	w1, [x7, #0xc]
1000006bc:     	add	w1, w1, w1, lsl #5
1000006c0:     	eor	w1, w1, w0
1000006c4:     	str	w1, [x7, #0xc]
1000006c8:     	cmp	w2, #0x0
1000006cc:     	b.le	0x100000720 <_region_pipeline+0x80>
1000006d0:     	adrp	x4, 0x100008000 <_memory>
1000006d4:     	sub	w2, w2, #0x1
1000006d8:     	add	x4, x4, #0x0
1000006dc:     	nop
1000006e0:     	ldr	w3, [x4, #0x4]
1000006e4:     	add	w1, w1, w1, lsl #5
1000006e8:     	sub	w2, w2, #0x1
1000006ec:     	eor	w1, w1, w0
1000006f0:     	add	w1, w1, w1, lsl #5
1000006f4:     	add	w3, w0, w3
1000006f8:     	add	w5, w0, w3
1000006fc:     	add	w0, w3, w0, lsl #1
100000700:     	str	w3, [x4, #0x4]
100000704:     	eor	w1, w1, w5
100000708:     	add	w0, w0, w0, lsl #2
10000070c:     	sub	w0, w0, #0x7
100000710:     	str	w0, [x6]
100000714:     	cmn	w2, #0x1
100000718:     	b.ne	0x1000006e0 <_region_pipeline+0x40>
10000071c:     	str	w1, [x7, #0xc]
100000720:     	ret

0000000100000724 <_record_event>:
100000724:     	adrp	x2, 0x100008000 <_memory>
100000728:     	ldr	w1, [x2, #0xc]
10000072c:     	add	w1, w1, w1, lsl #5
100000730:     	eor	w1, w1, w0
100000734:     	str	w1, [x2, #0xc]
100000738:     	ret
10000073c:     	nop

0000000100000740 <_next_value>:
100000740:     	adrp	x2, 0x100008000 <_memory>
100000744:     	ldr	w1, [x2, #0xc]
100000748:     	add	w1, w1, w1, lsl #5
10000074c:     	eor	w1, w1, w0
100000750:     	str	w1, [x2, #0xc]
100000754:     	adrp	x2, 0x100008000 <_memory>
100000758:     	add	x2, x2, #0x0
10000075c:     	ldr	w1, [x2, #0x4]
100000760:     	add	w1, w0, w1
100000764:     	add	w0, w1, w0
100000768:     	str	w1, [x2, #0x4]
10000076c:     	ret

0000000100000770 <_region_outputs>:
100000770:     	add	w1, w1, #0x11
100000774:     	adrp	x5, 0x100008000 <_memory>
100000778:     	add	w3, w1, w1, lsl #1
10000077c:     	add	w2, w3, w2
100000780:     	ldr	w3, [x5, #0xc]
100000784:     	sub	w4, w2, w1
100000788:     	cmp	w2, w4
10000078c:     	add	w3, w3, w3, lsl #5
100000790:     	eor	w3, w3, w2
100000794:     	str	w3, [x5, #0xc]
100000798:     	stp	w4, w1, [x0]
10000079c:     	cset	w0, eq
1000007a0:     	ret

Disassembly of section __TEXT,__text_startup:

00000001000007c0 <_main>:
1000007c0:     	sub	sp, sp, #0x70
1000007c4:     	stp	x29, x30, [sp, #0x30]
1000007c8:     	add	x29, sp, #0x30
1000007cc:     	stp	x19, x20, [sp, #0x40]
1000007d0:     	cmp	w0, #0x3
1000007d4:     	b.eq	0x1000007f0 <_main+0x30>
1000007d8:     	mov	w19, #0x2               ; =2
1000007dc:     	ldp	x29, x30, [sp, #0x30]
1000007e0:     	mov	w0, w19
1000007e4:     	ldp	x19, x20, [sp, #0x40]
1000007e8:     	add	sp, sp, #0x70
1000007ec:     	ret
1000007f0:     	mov	x20, x1
1000007f4:     	mov	w2, #0xa                ; =10
1000007f8:     	ldr	x0, [x20, #0x8]
1000007fc:     	mov	x1, #0x0                ; =0
100000800:     	bl	0x10000096c <_strtoul+0x10000096c>
100000804:     	mov	x1, #0x0                ; =0
100000808:     	mov	x19, x0
10000080c:     	ldr	x0, [x20, #0x10]
100000810:     	mov	w2, #0xa                ; =10
100000814:     	bl	0x10000096c <_strtoul+0x10000096c>
100000818:     	mov	x20, x0
10000081c:     	add	x1, x29, #0x30
100000820:     	mov	w0, #0x6                ; =6
100000824:     	bl	0x100000954 <_strtoul+0x100000954>
100000828:     	cbnz	w0, 0x1000007d8 <_main+0x18>
10000082c:     	cbz	x19, 0x10000094c <_main+0x18c>
100000830:     	mov	x10, #-0x3333333333333334 ; =-3689348814741910324
100000834:     	adrp	x12, 0x100008000 <_memory>
100000838:     	adrp	x11, 0x100008000 <_memory>
10000083c:     	mov	w8, w20
100000840:     	mov	x9, #0x0                ; =0
100000844:     	mov	w20, #0x0               ; =0
100000848:     	movk	x10, #0xcccd
10000084c:     	add	x12, x12, #0x0
100000850:     	add	x11, x11, #0xc
100000854:     	nop
100000858:     	nop
10000085c:     	nop
100000860:     	umulh	x2, x9, x10
100000864:     	mov	x0, x12
100000868:     	eor	w8, w8, w8, lsl #13
10000086c:     	lsr	x2, x2, #3
100000870:     	eor	w8, w8, w8, lsr #17
100000874:     	add	x2, x2, x2, lsl #2
100000878:     	eor	w8, w8, w8, lsl #5
10000087c:     	sub	x2, x9, x2, lsl #1
100000880:     	add	x9, x9, #0x1
100000884:     	mov	w1, w8
100000888:     	sub	w2, w2, #0x1
10000088c:     	bl	0x1000006a0 <_region_pipeline>
100000890:     	ldr	w1, [x11]
100000894:     	add	w3, w8, #0x11
100000898:     	add	w0, w0, w20
10000089c:     	add	w2, w3, w3, lsl #1
1000008a0:     	add	w2, w2, w0
1000008a4:     	sub	w4, w2, w3
1000008a8:     	add	w1, w1, w1, lsl #5
1000008ac:     	cmp	w2, w4
1000008b0:     	cinc	w20, w0, eq
1000008b4:     	stp	w4, w3, [x12]
1000008b8:     	eor	w1, w1, w2
1000008bc:     	str	w1, [x11]
1000008c0:     	cmp	x19, x9
1000008c4:     	b.ne	0x100000860 <_main+0xa0>
1000008c8:     	add	x1, x29, #0x20
1000008cc:     	mov	w0, #0x6                ; =6
1000008d0:     	bl	0x100000954 <_strtoul+0x100000954>
1000008d4:     	mov	w19, w0
1000008d8:     	cbnz	w0, 0x1000007d8 <_main+0x18>
1000008dc:     	adrp	x0, 0x100008000 <_memory>
1000008e0:     	ldr	w0, [x0, #0xc]
1000008e4:     	str	w0, [sp, #0x28]
1000008e8:     	adrp	x0, 0x100008000 <_memory>
1000008ec:     	add	x0, x0, #0x0
1000008f0:     	ldr	w1, [x0, #0x8]
1000008f4:     	str	w1, [sp, #0x20]
1000008f8:     	ldp	w0, w1, [x0]
1000008fc:     	str	w20, [sp, #0x8]
100000900:     	str	w0, [sp, #0x10]
100000904:     	ldr	x0, [x29, #0x28]
100000908:     	str	w1, [sp, #0x18]
10000090c:     	ldr	x1, [x29, #0x38]
100000910:     	sub	x0, x0, x1
100000914:     	ldr	x1, [x29, #0x30]
100000918:     	scvtf	d0, x0
10000091c:     	adrp	x0, 0x100000000 <_strtoul+0x100000000>
100000920:     	ldr	d30, [x0, #0x990]
100000924:     	ldr	x0, [x29, #0x20]
100000928:     	fmul	d30, d0, d30
10000092c:     	sub	x0, x0, x1
100000930:     	scvtf	d31, x0
100000934:     	adrp	x0, 0x100000000 <_strtoul+0x100000000>
100000938:     	add	x0, x0, #0x978
10000093c:     	fadd	d31, d30, d31
100000940:     	str	d31, [sp]
100000944:     	bl	0x100000960 <_strtoul+0x100000960>
100000948:     	b	0x1000007dc <_main+0x1c>
10000094c:     	mov	w20, #0x0               ; =0
100000950:     	b	0x1000008c8 <_main+0x108>

Disassembly of section __TEXT,__stubs:

0000000100000954 <__stubs>:
100000954:     	adrp	x16, 0x100004000 <_strtoul+0x100004000>
100000958:     	ldr	x16, [x16]
10000095c:     	br	x16
100000960:     	adrp	x16, 0x100004000 <_strtoul+0x100004000>
100000964:     	ldr	x16, [x16, #0x8]
100000968:     	br	x16
10000096c:     	adrp	x16, 0x100004000 <_strtoul+0x100004000>
100000970:     	ldr	x16, [x16, #0x10]
100000974:     	br	x16
