
/Users/admin/C-SRD/experiments/runs/private-regions-cost-native-20261110/gcc-O2-lto/affine:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001000006a0 <_region_pipeline>:
1000006a0:     	mov	x6, x0
1000006a4:     	ldr	w0, [x0]
1000006a8:     	adrp	x7, 0x100008000 <_memory>
1000006ac:     	add	w1, w1, w0
1000006b0:     	add	w1, w1, w1, lsl #1
1000006b4:     	add	w0, w1, #0xb
1000006b8:     	ldr	w1, [x7, #0xc]
1000006bc:     	add	w1, w1, w1, lsl #5
1000006c0:     	eor	w1, w1, w0
1000006c4:     	str	w1, [x7, #0xc]
1000006c8:     	cmp	w2, #0x0
1000006cc:     	b.le	0x100000720 <_region_pipeline+0x80>
1000006d0:     	adrp	x4, 0x100008000 <_memory>
1000006d4:     	sub	w2, w2, #0x1
1000006d8:     	add	x4, x4, #0x0
1000006dc:     	nop
1000006e0:     	ldr	w3, [x4, #0x4]
1000006e4:     	add	w1, w1, w1, lsl #5
1000006e8:     	sub	w2, w2, #0x1
1000006ec:     	eor	w1, w1, w0
1000006f0:     	add	w1, w1, w1, lsl #5
1000006f4:     	add	w3, w0, w3
1000006f8:     	add	w5, w0, w3
1000006fc:     	add	w0, w3, w0, lsl #1
100000700:     	str	w3, [x4, #0x4]
100000704:     	eor	w1, w1, w5
100000708:     	add	w0, w0, w0, lsl #2
10000070c:     	sub	w0, w0, #0x7
100000710:     	str	w0, [x6]
100000714:     	cmn	w2, #0x1
100000718:     	b.ne	0x1000006e0 <_region_pipeline+0x40>
10000071c:     	str	w1, [x7, #0xc]
100000720:     	ret

0000000100000724 <_record_event>:
100000724:     	adrp	x2, 0x100008000 <_memory>
100000728:     	ldr	w1, [x2, #0xc]
10000072c:     	add	w1, w1, w1, lsl #5
100000730:     	eor	w1, w1, w0
100000734:     	str	w1, [x2, #0xc]
100000738:     	ret
10000073c:     	nop

0000000100000740 <_next_value>:
100000740:     	adrp	x2, 0x100008000 <_memory>
100000744:     	ldr	w1, [x2, #0xc]
100000748:     	add	w1, w1, w1, lsl #5
10000074c:     	eor	w1, w1, w0
100000750:     	str	w1, [x2, #0xc]
100000754:     	adrp	x2, 0x100008000 <_memory>
100000758:     	add	x2, x2, #0x0
10000075c:     	ldr	w1, [x2, #0x4]
100000760:     	add	w1, w0, w1
100000764:     	add	w0, w1, w0
100000768:     	str	w1, [x2, #0x4]
10000076c:     	ret

0000000100000770 <_region_outputs>:
100000770:     	mov	w4, #0xf695             ; =63125
100000774:     	mov	w3, #0x2a16             ; =10774
100000778:     	movk	w4, #0xf36a, lsl #16
10000077c:     	movk	w3, #0x95d9, lsl #16
100000780:     	mov	w5, #0x6b9e             ; =27550
100000784:     	madd	w3, w1, w4, w3
100000788:     	movk	w5, #0x2882, lsl #16
10000078c:     	add	w1, w1, #0x11
100000790:     	madd	w2, w2, w4, w5
100000794:     	mov	w5, #0x24bd             ; =9405
100000798:     	add	w4, w3, w3, lsl #1
10000079c:     	movk	w5, #0x922f, lsl #16
1000007a0:     	add	w2, w2, w4
1000007a4:     	mov	w4, #0xd5d3             ; =54739
1000007a8:     	movk	w4, #0x8eb6, lsl #16
1000007ac:     	madd	w4, w2, w5, w4
1000007b0:     	sub	w2, w2, w3
1000007b4:     	mul	w2, w2, w5
1000007b8:     	adrp	x5, 0x100008000 <_memory>
1000007bc:     	ldr	w3, [x5, #0xc]
1000007c0:     	cmp	w2, w4
1000007c4:     	add	w3, w3, w3, lsl #5
1000007c8:     	eor	w3, w3, w4
1000007cc:     	str	w3, [x5, #0xc]
1000007d0:     	stp	w2, w1, [x0]
1000007d4:     	cset	w0, eq
1000007d8:     	ret

Disassembly of section __TEXT,__text_startup:

00000001000007e0 <_main>:
1000007e0:     	sub	sp, sp, #0x80
1000007e4:     	stp	x29, x30, [sp, #0x30]
1000007e8:     	add	x29, sp, #0x30
1000007ec:     	stp	x19, x20, [sp, #0x40]
1000007f0:     	cmp	w0, #0x3
1000007f4:     	b.eq	0x100000810 <_main+0x30>
1000007f8:     	mov	w19, #0x2               ; =2
1000007fc:     	ldp	x29, x30, [sp, #0x30]
100000800:     	mov	w0, w19
100000804:     	ldp	x19, x20, [sp, #0x40]
100000808:     	add	sp, sp, #0x80
10000080c:     	ret
100000810:     	mov	x20, x1
100000814:     	mov	w2, #0xa                ; =10
100000818:     	ldr	x0, [x20, #0x8]
10000081c:     	mov	x1, #0x0                ; =0
100000820:     	bl	0x1000009bc <_strtoul+0x1000009bc>
100000824:     	mov	x1, #0x0                ; =0
100000828:     	mov	x19, x0
10000082c:     	ldr	x0, [x20, #0x10]
100000830:     	mov	w2, #0xa                ; =10
100000834:     	bl	0x1000009bc <_strtoul+0x1000009bc>
100000838:     	mov	x20, x0
10000083c:     	add	x1, x29, #0x40
100000840:     	mov	w0, #0x6                ; =6
100000844:     	bl	0x1000009a4 <_strtoul+0x1000009a4>
100000848:     	cbnz	w0, 0x1000007f8 <_main+0x18>
10000084c:     	cbz	x19, 0x10000099c <_main+0x1bc>
100000850:     	mov	x11, #-0x3333333333333334 ; =-3689348814741910324
100000854:     	mov	w15, #0xf695            ; =63125
100000858:     	stp	x21, x22, [x29, #0x20]
10000085c:     	mov	w10, #0x2a16            ; =10774
100000860:     	mov	w9, #0x6b9e             ; =27550
100000864:     	mov	w14, #0x24bd            ; =9405
100000868:     	mov	w8, w20
10000086c:     	mov	x13, #0x0               ; =0
100000870:     	mov	w20, #0x0               ; =0
100000874:     	adrp	x12, 0x100008000 <_memory>
100000878:     	adrp	x21, 0x100008000 <_memory>
10000087c:     	movk	x11, #0xcccd
100000880:     	movk	w15, #0xf36a, lsl #16
100000884:     	movk	w10, #0x95d9, lsl #16
100000888:     	movk	w9, #0x2882, lsl #16
10000088c:     	movk	w14, #0x922f, lsl #16
100000890:     	umulh	x2, x13, x11
100000894:     	add	x22, x12, #0x0
100000898:     	eor	w8, w8, w8, lsl #13
10000089c:     	mov	x0, x22
1000008a0:     	lsr	x2, x2, #3
1000008a4:     	eor	w8, w8, w8, lsr #17
1000008a8:     	add	x2, x2, x2, lsl #2
1000008ac:     	eor	w8, w8, w8, lsl #5
1000008b0:     	sub	x2, x13, x2, lsl #1
1000008b4:     	add	x13, x13, #0x1
1000008b8:     	mov	w1, w8
1000008bc:     	sub	w2, w2, #0x1
1000008c0:     	bl	0x1000006a0 <_region_pipeline>
1000008c4:     	madd	w2, w8, w15, w10
1000008c8:     	add	w0, w0, w20
1000008cc:     	madd	w1, w0, w15, w9
1000008d0:     	add	w3, w2, w2, lsl #1
1000008d4:     	add	w1, w1, w3
1000008d8:     	mov	w3, #0xd5d3             ; =54739
1000008dc:     	movk	w3, #0x8eb6, lsl #16
1000008e0:     	madd	w3, w1, w14, w3
1000008e4:     	sub	w1, w1, w2
1000008e8:     	ldr	w2, [x21, #0xc]
1000008ec:     	mul	w1, w1, w14
1000008f0:     	add	w2, w2, w2, lsl #5
1000008f4:     	cmp	w3, w1
1000008f8:     	cinc	w20, w0, eq
1000008fc:     	eor	w2, w2, w3
100000900:     	str	w2, [x21, #0xc]
100000904:     	add	w2, w8, #0x11
100000908:     	stp	w1, w2, [x22]
10000090c:     	cmp	x19, x13
100000910:     	b.ne	0x100000890 <_main+0xb0>
100000914:     	ldp	x21, x22, [x29, #0x20]
100000918:     	add	x1, x29, #0x30
10000091c:     	mov	w0, #0x6                ; =6
100000920:     	bl	0x1000009a4 <_strtoul+0x1000009a4>
100000924:     	mov	w19, w0
100000928:     	cbnz	w0, 0x1000007f8 <_main+0x18>
10000092c:     	adrp	x0, 0x100008000 <_memory>
100000930:     	ldr	w0, [x0, #0xc]
100000934:     	str	w0, [sp, #0x28]
100000938:     	adrp	x0, 0x100008000 <_memory>
10000093c:     	add	x0, x0, #0x0
100000940:     	ldr	w1, [x0, #0x8]
100000944:     	str	w1, [sp, #0x20]
100000948:     	ldp	w0, w1, [x0]
10000094c:     	str	w20, [sp, #0x8]
100000950:     	str	w0, [sp, #0x10]
100000954:     	ldr	x0, [x29, #0x38]
100000958:     	str	w1, [sp, #0x18]
10000095c:     	ldr	x1, [x29, #0x48]
100000960:     	sub	x0, x0, x1
100000964:     	ldr	x1, [x29, #0x40]
100000968:     	scvtf	d0, x0
10000096c:     	adrp	x0, 0x100000000 <_strtoul+0x100000000>
100000970:     	ldr	d30, [x0, #0x9e0]
100000974:     	ldr	x0, [x29, #0x30]
100000978:     	fmul	d30, d0, d30
10000097c:     	sub	x0, x0, x1
100000980:     	scvtf	d31, x0
100000984:     	adrp	x0, 0x100000000 <_strtoul+0x100000000>
100000988:     	add	x0, x0, #0x9c8
10000098c:     	fadd	d31, d30, d31
100000990:     	str	d31, [sp]
100000994:     	bl	0x1000009b0 <_strtoul+0x1000009b0>
100000998:     	b	0x1000007fc <_main+0x1c>
10000099c:     	mov	w20, #0x0               ; =0
1000009a0:     	b	0x100000918 <_main+0x138>

Disassembly of section __TEXT,__stubs:

00000001000009a4 <__stubs>:
1000009a4:     	adrp	x16, 0x100004000 <_strtoul+0x100004000>
1000009a8:     	ldr	x16, [x16]
1000009ac:     	br	x16
1000009b0:     	adrp	x16, 0x100004000 <_strtoul+0x100004000>
1000009b4:     	ldr	x16, [x16, #0x8]
1000009b8:     	br	x16
1000009bc:     	adrp	x16, 0x100004000 <_strtoul+0x100004000>
1000009c0:     	ldr	x16, [x16, #0x10]
1000009c4:     	br	x16
