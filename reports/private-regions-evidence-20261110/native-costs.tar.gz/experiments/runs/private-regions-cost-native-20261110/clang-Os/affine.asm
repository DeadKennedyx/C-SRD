
/Users/admin/C-SRD/experiments/runs/private-regions-cost-native-20261110/clang-Os/affine:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000100000548 <_region_pipeline>:
100000548:     	stp	x22, x21, [sp, #-0x30]!
10000054c:     	stp	x20, x19, [sp, #0x10]
100000550:     	stp	x29, x30, [sp, #0x20]
100000554:     	add	x29, sp, #0x20
100000558:     	mov	x21, x2
10000055c:     	mov	x19, x0
100000560:     	ldr	w8, [x0]
100000564:     	add	w8, w8, w1
100000568:     	add	w8, w8, w8, lsl #1
10000056c:     	add	w20, w8, #0xb
100000570:     	mov	x0, x20
100000574:     	bl	0x10000064c <_record_event>
100000578:     	cmp	w21, #0x1
10000057c:     	b.lt	0x1000005ac <_region_pipeline+0x64>
100000580:     	add	w21, w21, #0x1
100000584:     	mov	x0, x20
100000588:     	bl	0x100000664 <_next_value>
10000058c:     	add	w8, w0, w20
100000590:     	add	w8, w8, w8, lsl #2
100000594:     	sub	w20, w8, #0x7
100000598:     	str	w20, [x19]
10000059c:     	bl	0x10000064c <_record_event>
1000005a0:     	sub	w21, w21, #0x1
1000005a4:     	cmp	w21, #0x1
1000005a8:     	b.hi	0x100000584 <_region_pipeline+0x3c>
1000005ac:     	mov	x0, x20
1000005b0:     	ldp	x29, x30, [sp, #0x20]
1000005b4:     	ldp	x20, x19, [sp, #0x10]
1000005b8:     	ldp	x22, x21, [sp], #0x30
1000005bc:     	ret

00000001000005c0 <_region_outputs>:
1000005c0:     	stp	x22, x21, [sp, #-0x30]!
1000005c4:     	stp	x20, x19, [sp, #0x10]
1000005c8:     	stp	x29, x30, [sp, #0x20]
1000005cc:     	add	x29, sp, #0x20
1000005d0:     	mov	x19, x0
1000005d4:     	mov	w8, #0x19ff             ; =6655
1000005d8:     	movk	w8, #0x8d3e, lsl #16
1000005dc:     	mov	w9, #0xe601             ; =58881
1000005e0:     	movk	w9, #0x72c1, lsl #16
1000005e4:     	mul	w9, w2, w9
1000005e8:     	mov	w10, #0xb203            ; =45571
1000005ec:     	movk	w10, #0x5845, lsl #16
1000005f0:     	madd	w9, w1, w10, w9
1000005f4:     	madd	w8, w1, w8, w9
1000005f8:     	mov	w10, #0x1a01            ; =6657
1000005fc:     	movk	w10, #0xcfe2, lsl #16
100000600:     	mov	w11, #0x286             ; =646
100000604:     	movk	w11, #0x2d, lsl #16
100000608:     	mul	w11, w11, w10
10000060c:     	madd	w8, w8, w10, w11
100000610:     	add	w21, w1, #0x11
100000614:     	mov	w11, #0x33              ; =51
100000618:     	madd	w20, w9, w10, w11
10000061c:     	mov	w9, #0x899c             ; =35228
100000620:     	movk	w9, #0x3d93, lsl #16
100000624:     	madd	w22, w9, w10, w8
100000628:     	mov	x0, x20
10000062c:     	bl	0x10000064c <_record_event>
100000630:     	stp	w22, w21, [x19]
100000634:     	cmp	w20, w22
100000638:     	cset	w0, eq
10000063c:     	ldp	x29, x30, [sp, #0x20]
100000640:     	ldp	x20, x19, [sp, #0x10]
100000644:     	ldp	x22, x21, [sp], #0x30
100000648:     	ret

000000010000064c <_record_event>:
10000064c:     	adrp	x8, 0x100008000 <_event_hash>
100000650:     	ldr	w9, [x8]
100000654:     	add	w9, w9, w9, lsl #5
100000658:     	eor	w9, w9, w0
10000065c:     	str	w9, [x8]
100000660:     	ret

0000000100000664 <_next_value>:
100000664:     	adrp	x8, 0x100008000 <_event_hash>
100000668:     	ldr	w9, [x8]
10000066c:     	add	w9, w9, w9, lsl #5
100000670:     	eor	w9, w9, w0
100000674:     	str	w9, [x8]
100000678:     	adrp	x8, 0x100008000 <_event_hash>
10000067c:     	ldr	w9, [x8, #0x8]
100000680:     	add	w9, w9, w0
100000684:     	add	w0, w9, w0
100000688:     	str	w9, [x8, #0x8]
10000068c:     	ret

0000000100000690 <_main>:
100000690:     	cmp	w0, #0x3
100000694:     	b.ne	0x100000764 <_main+0xd4>
100000698:     	sub	sp, sp, #0xa0
10000069c:     	stp	x26, x25, [sp, #0x50]
1000006a0:     	stp	x24, x23, [sp, #0x60]
1000006a4:     	stp	x22, x21, [sp, #0x70]
1000006a8:     	stp	x20, x19, [sp, #0x80]
1000006ac:     	stp	x29, x30, [sp, #0x90]
1000006b0:     	add	x29, sp, #0x90
1000006b4:     	mov	x20, x1
1000006b8:     	ldr	x0, [x1, #0x8]
1000006bc:     	mov	x1, #0x0                ; =0
1000006c0:     	mov	w2, #0xa                ; =10
1000006c4:     	bl	0x100000818 <_strtoul+0x100000818>
1000006c8:     	mov	x19, x0
1000006cc:     	ldr	x0, [x20, #0x10]
1000006d0:     	mov	x1, #0x0                ; =0
1000006d4:     	mov	w2, #0xa                ; =10
1000006d8:     	bl	0x100000818 <_strtoul+0x100000818>
1000006dc:     	mov	x20, x0
1000006e0:     	add	x1, sp, #0x40
1000006e4:     	mov	w0, #0x6                ; =6
1000006e8:     	bl	0x100000800 <_strtoul+0x100000800>
1000006ec:     	cbnz	w0, 0x100000780 <_main+0xf0>
1000006f0:     	cbz	x19, 0x10000076c <_main+0xdc>
1000006f4:     	mov	x23, #0x0               ; =0
1000006f8:     	mov	w22, #0x0               ; =0
1000006fc:     	mov	w24, #-0x1              ; =-1
100000700:     	mov	x25, #-0x3333333333333334 ; =-3689348814741910324
100000704:     	movk	x25, #0xcccd
100000708:     	mov	w26, #0xa               ; =10
10000070c:     	adrp	x21, 0x100008000 <_event_hash>
100000710:     	add	x21, x21, #0x4
100000714:     	umulh	x8, x23, x25
100000718:     	lsr	x8, x8, #3
10000071c:     	msub	w2, w8, w26, w24
100000720:     	eor	w8, w20, w20, lsl #13
100000724:     	eor	w8, w8, w8, lsr #17
100000728:     	eor	w20, w8, w8, lsl #5
10000072c:     	mov	x0, x21
100000730:     	mov	x1, x20
100000734:     	bl	0x100000548 <_region_pipeline>
100000738:     	add	w22, w0, w22
10000073c:     	mov	x0, x21
100000740:     	mov	x1, x20
100000744:     	mov	x2, x22
100000748:     	bl	0x1000005c0 <_region_outputs>
10000074c:     	add	w22, w22, w0
100000750:     	add	x23, x23, #0x1
100000754:     	add	w24, w24, #0x1
100000758:     	subs	x19, x19, #0x1
10000075c:     	b.ne	0x100000714 <_main+0x84>
100000760:     	b	0x100000770 <_main+0xe0>
100000764:     	mov	w0, #0x2                ; =2
100000768:     	ret
10000076c:     	mov	w22, #0x0               ; =0
100000770:     	add	x1, sp, #0x30
100000774:     	mov	w0, #0x6                ; =6
100000778:     	bl	0x100000800 <_strtoul+0x100000800>
10000077c:     	cbz	w0, 0x1000007a0 <_main+0x110>
100000780:     	mov	w0, #0x2                ; =2
100000784:     	ldp	x29, x30, [sp, #0x90]
100000788:     	ldp	x20, x19, [sp, #0x80]
10000078c:     	ldp	x22, x21, [sp, #0x70]
100000790:     	ldp	x24, x23, [sp, #0x60]
100000794:     	ldp	x26, x25, [sp, #0x50]
100000798:     	add	sp, sp, #0xa0
10000079c:     	ret
1000007a0:     	ldp	x8, x9, [sp, #0x30]
1000007a4:     	ldp	x10, x11, [sp, #0x40]
1000007a8:     	sub	x8, x8, x10
1000007ac:     	adrp	x10, 0x100008000 <_event_hash>
1000007b0:     	add	x10, x10, #0x4
1000007b4:     	scvtf	d0, x8
1000007b8:     	sub	x8, x9, x11
1000007bc:     	scvtf	d1, x8
1000007c0:     	adrp	x8, 0x100000000 <_strtoul+0x100000000>
1000007c4:     	ldr	d2, [x8, #0x828]
1000007c8:     	fmadd	d0, d1, d2, d0
1000007cc:     	ldp	w8, w9, [x10]
1000007d0:     	ldr	w10, [x10, #0x8]
1000007d4:     	adrp	x11, 0x100008000 <_event_hash>
1000007d8:     	ldr	w11, [x11]
1000007dc:     	stp	x10, x11, [sp, #0x20]
1000007e0:     	stp	x8, x9, [sp, #0x10]
1000007e4:     	str	x22, [sp, #0x8]
1000007e8:     	str	d0, [sp]
1000007ec:     	adrp	x0, 0x100000000 <_strtoul+0x100000000>
1000007f0:     	add	x0, x0, #0x830
1000007f4:     	bl	0x10000080c <_strtoul+0x10000080c>
1000007f8:     	mov	w0, #0x0                ; =0
1000007fc:     	b	0x100000784 <_main+0xf4>

Disassembly of section __TEXT,__stubs:

0000000100000800 <__stubs>:
100000800:     	adrp	x16, 0x100004000 <_strtoul+0x100004000>
100000804:     	ldr	x16, [x16]
100000808:     	br	x16
10000080c:     	adrp	x16, 0x100004000 <_strtoul+0x100004000>
100000810:     	ldr	x16, [x16, #0x8]
100000814:     	br	x16
100000818:     	adrp	x16, 0x100004000 <_strtoul+0x100004000>
10000081c:     	ldr	x16, [x16, #0x10]
100000820:     	br	x16
