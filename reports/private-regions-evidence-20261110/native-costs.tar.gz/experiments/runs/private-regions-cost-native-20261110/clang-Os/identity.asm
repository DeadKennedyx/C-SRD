
/Users/admin/C-SRD/experiments/runs/private-regions-cost-native-20261110/clang-Os/identity:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000100000548 <_region_pipeline>:
100000548:     	stp	x22, x21, [sp, #-0x30]!
10000054c:     	stp	x20, x19, [sp, #0x10]
100000550:     	stp	x29, x30, [sp, #0x20]
100000554:     	add	x29, sp, #0x20
100000558:     	mov	x21, x2
10000055c:     	mov	x19, x0
100000560:     	ldr	w8, [x0]
100000564:     	add	w8, w8, w1
100000568:     	add	w8, w8, w8, lsl #1
10000056c:     	add	w20, w8, #0xb
100000570:     	mov	x0, x20
100000574:     	bl	0x100000604 <_record_event>
100000578:     	cmp	w21, #0x1
10000057c:     	b.lt	0x1000005ac <_region_pipeline+0x64>
100000580:     	add	w21, w21, #0x1
100000584:     	mov	x0, x20
100000588:     	bl	0x10000061c <_next_value>
10000058c:     	add	w8, w0, w20
100000590:     	add	w8, w8, w8, lsl #2
100000594:     	sub	w20, w8, #0x7
100000598:     	str	w20, [x19]
10000059c:     	bl	0x100000604 <_record_event>
1000005a0:     	sub	w21, w21, #0x1
1000005a4:     	cmp	w21, #0x1
1000005a8:     	b.hi	0x100000584 <_region_pipeline+0x3c>
1000005ac:     	mov	x0, x20
1000005b0:     	ldp	x29, x30, [sp, #0x20]
1000005b4:     	ldp	x20, x19, [sp, #0x10]
1000005b8:     	ldp	x22, x21, [sp], #0x30
1000005bc:     	ret

00000001000005c0 <_region_outputs>:
1000005c0:     	stp	x22, x21, [sp, #-0x30]!
1000005c4:     	stp	x20, x19, [sp, #0x10]
1000005c8:     	stp	x29, x30, [sp, #0x20]
1000005cc:     	add	x29, sp, #0x20
1000005d0:     	mov	x19, x0
1000005d4:     	add	w20, w1, #0x11
1000005d8:     	add	w8, w20, w20, lsl #1
1000005dc:     	add	w0, w8, w2
1000005e0:     	sub	w21, w0, w20
1000005e4:     	bl	0x100000604 <_record_event>
1000005e8:     	stp	w21, w20, [x19]
1000005ec:     	cmp	w20, #0x0
1000005f0:     	cset	w0, eq
1000005f4:     	ldp	x29, x30, [sp, #0x20]
1000005f8:     	ldp	x20, x19, [sp, #0x10]
1000005fc:     	ldp	x22, x21, [sp], #0x30
100000600:     	ret

0000000100000604 <_record_event>:
100000604:     	adrp	x8, 0x100008000 <_event_hash>
100000608:     	ldr	w9, [x8]
10000060c:     	add	w9, w9, w9, lsl #5
100000610:     	eor	w9, w9, w0
100000614:     	str	w9, [x8]
100000618:     	ret

000000010000061c <_next_value>:
10000061c:     	adrp	x8, 0x100008000 <_event_hash>
100000620:     	ldr	w9, [x8]
100000624:     	add	w9, w9, w9, lsl #5
100000628:     	eor	w9, w9, w0
10000062c:     	str	w9, [x8]
100000630:     	adrp	x8, 0x100008000 <_event_hash>
100000634:     	ldr	w9, [x8, #0x8]
100000638:     	add	w9, w9, w0
10000063c:     	add	w0, w9, w0
100000640:     	str	w9, [x8, #0x8]
100000644:     	ret

0000000100000648 <_main>:
100000648:     	cmp	w0, #0x3
10000064c:     	b.ne	0x10000071c <_main+0xd4>
100000650:     	sub	sp, sp, #0xa0
100000654:     	stp	x26, x25, [sp, #0x50]
100000658:     	stp	x24, x23, [sp, #0x60]
10000065c:     	stp	x22, x21, [sp, #0x70]
100000660:     	stp	x20, x19, [sp, #0x80]
100000664:     	stp	x29, x30, [sp, #0x90]
100000668:     	add	x29, sp, #0x90
10000066c:     	mov	x20, x1
100000670:     	ldr	x0, [x1, #0x8]
100000674:     	mov	x1, #0x0                ; =0
100000678:     	mov	w2, #0xa                ; =10
10000067c:     	bl	0x1000007d0 <_strtoul+0x1000007d0>
100000680:     	mov	x19, x0
100000684:     	ldr	x0, [x20, #0x10]
100000688:     	mov	x1, #0x0                ; =0
10000068c:     	mov	w2, #0xa                ; =10
100000690:     	bl	0x1000007d0 <_strtoul+0x1000007d0>
100000694:     	mov	x20, x0
100000698:     	add	x1, sp, #0x40
10000069c:     	mov	w0, #0x6                ; =6
1000006a0:     	bl	0x1000007b8 <_strtoul+0x1000007b8>
1000006a4:     	cbnz	w0, 0x100000738 <_main+0xf0>
1000006a8:     	cbz	x19, 0x100000724 <_main+0xdc>
1000006ac:     	mov	x23, #0x0               ; =0
1000006b0:     	mov	w22, #0x0               ; =0
1000006b4:     	mov	w24, #-0x1              ; =-1
1000006b8:     	mov	x25, #-0x3333333333333334 ; =-3689348814741910324
1000006bc:     	movk	x25, #0xcccd
1000006c0:     	mov	w26, #0xa               ; =10
1000006c4:     	adrp	x21, 0x100008000 <_event_hash>
1000006c8:     	add	x21, x21, #0x4
1000006cc:     	umulh	x8, x23, x25
1000006d0:     	lsr	x8, x8, #3
1000006d4:     	msub	w2, w8, w26, w24
1000006d8:     	eor	w8, w20, w20, lsl #13
1000006dc:     	eor	w8, w8, w8, lsr #17
1000006e0:     	eor	w20, w8, w8, lsl #5
1000006e4:     	mov	x0, x21
1000006e8:     	mov	x1, x20
1000006ec:     	bl	0x100000548 <_region_pipeline>
1000006f0:     	add	w22, w0, w22
1000006f4:     	mov	x0, x21
1000006f8:     	mov	x1, x20
1000006fc:     	mov	x2, x22
100000700:     	bl	0x1000005c0 <_region_outputs>
100000704:     	add	w22, w22, w0
100000708:     	add	x23, x23, #0x1
10000070c:     	add	w24, w24, #0x1
100000710:     	subs	x19, x19, #0x1
100000714:     	b.ne	0x1000006cc <_main+0x84>
100000718:     	b	0x100000728 <_main+0xe0>
10000071c:     	mov	w0, #0x2                ; =2
100000720:     	ret
100000724:     	mov	w22, #0x0               ; =0
100000728:     	add	x1, sp, #0x30
10000072c:     	mov	w0, #0x6                ; =6
100000730:     	bl	0x1000007b8 <_strtoul+0x1000007b8>
100000734:     	cbz	w0, 0x100000758 <_main+0x110>
100000738:     	mov	w0, #0x2                ; =2
10000073c:     	ldp	x29, x30, [sp, #0x90]
100000740:     	ldp	x20, x19, [sp, #0x80]
100000744:     	ldp	x22, x21, [sp, #0x70]
100000748:     	ldp	x24, x23, [sp, #0x60]
10000074c:     	ldp	x26, x25, [sp, #0x50]
100000750:     	add	sp, sp, #0xa0
100000754:     	ret
100000758:     	ldp	x8, x9, [sp, #0x30]
10000075c:     	ldp	x10, x11, [sp, #0x40]
100000760:     	sub	x8, x8, x10
100000764:     	adrp	x10, 0x100008000 <_event_hash>
100000768:     	add	x10, x10, #0x4
10000076c:     	scvtf	d0, x8
100000770:     	sub	x8, x9, x11
100000774:     	scvtf	d1, x8
100000778:     	adrp	x8, 0x100000000 <_strtoul+0x100000000>
10000077c:     	ldr	d2, [x8, #0x7e0]
100000780:     	fmadd	d0, d1, d2, d0
100000784:     	ldp	w8, w9, [x10]
100000788:     	ldr	w10, [x10, #0x8]
10000078c:     	adrp	x11, 0x100008000 <_event_hash>
100000790:     	ldr	w11, [x11]
100000794:     	stp	x10, x11, [sp, #0x20]
100000798:     	stp	x8, x9, [sp, #0x10]
10000079c:     	str	x22, [sp, #0x8]
1000007a0:     	str	d0, [sp]
1000007a4:     	adrp	x0, 0x100000000 <_strtoul+0x100000000>
1000007a8:     	add	x0, x0, #0x7e8
1000007ac:     	bl	0x1000007c4 <_strtoul+0x1000007c4>
1000007b0:     	mov	w0, #0x0                ; =0
1000007b4:     	b	0x10000073c <_main+0xf4>

Disassembly of section __TEXT,__stubs:

00000001000007b8 <__stubs>:
1000007b8:     	adrp	x16, 0x100004000 <_strtoul+0x100004000>
1000007bc:     	ldr	x16, [x16]
1000007c0:     	br	x16
1000007c4:     	adrp	x16, 0x100004000 <_strtoul+0x100004000>
1000007c8:     	ldr	x16, [x16, #0x8]
1000007cc:     	br	x16
1000007d0:     	adrp	x16, 0x100004000 <_strtoul+0x100004000>
1000007d4:     	ldr	x16, [x16, #0x10]
1000007d8:     	br	x16
