
/Users/admin/C-SRD/experiments/runs/private-regions-cost-native-20261110/gcc-Os/affine:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000100000698 <_region_pipeline>:
100000698:     	stp	x29, x30, [sp, #-0x30]!
10000069c:     	mov	x29, sp
1000006a0:     	stp	x19, x20, [sp, #0x10]
1000006a4:     	mov	w20, w2
1000006a8:     	str	x21, [sp, #0x20]
1000006ac:     	mov	x21, x0
1000006b0:     	ldr	w0, [x0]
1000006b4:     	add	w19, w1, w0
1000006b8:     	add	w19, w19, w19, lsl #1
1000006bc:     	add	w19, w19, #0xb
1000006c0:     	mov	w0, w19
1000006c4:     	bl	0x100000790 <_record_event>
1000006c8:     	tbz	w20, #0x1f, 0x100000700 <_region_pipeline+0x68>
1000006cc:     	ldr	x21, [sp, #0x20]
1000006d0:     	mov	w0, w19
1000006d4:     	ldp	x19, x20, [sp, #0x10]
1000006d8:     	ldp	x29, x30, [sp], #0x30
1000006dc:     	ret
1000006e0:     	mov	w0, w19
1000006e4:     	sub	w20, w20, #0x1
1000006e8:     	bl	0x1000007a8 <_next_value>
1000006ec:     	add	w19, w19, w0
1000006f0:     	add	w19, w19, w19, lsl #2
1000006f4:     	sub	w19, w19, #0x7
1000006f8:     	str	w19, [x21]
1000006fc:     	bl	0x100000790 <_record_event>
100000700:     	cbnz	w20, 0x1000006e0 <_region_pipeline+0x48>
100000704:     	b	0x1000006cc <_region_pipeline+0x34>

0000000100000708 <_region_outputs>:
100000708:     	stp	x29, x30, [sp, #-0x40]!
10000070c:     	mov	x29, sp
100000710:     	mov	w3, #0x2a16             ; =10774
100000714:     	mov	w4, #0x6b9e             ; =27550
100000718:     	movk	w3, #0x95d9, lsl #16
10000071c:     	movk	w4, #0x2882, lsl #16
100000720:     	str	x21, [sp, #0x20]
100000724:     	mov	x21, x0
100000728:     	mov	w0, #0xf695             ; =63125
10000072c:     	movk	w0, #0xf36a, lsl #16
100000730:     	stp	x19, x20, [sp, #0x10]
100000734:     	mov	w20, #0xd5d3            ; =54739
100000738:     	movk	w20, #0x8eb6, lsl #16
10000073c:     	madd	w3, w1, w0, w3
100000740:     	madd	w19, w2, w0, w4
100000744:     	str	w1, [x29, #0x3c]
100000748:     	add	w0, w3, w3, lsl #1
10000074c:     	add	w19, w19, w0
100000750:     	mov	w0, #0x24bd             ; =9405
100000754:     	movk	w0, #0x922f, lsl #16
100000758:     	madd	w20, w19, w0, w20
10000075c:     	sub	w19, w19, w3
100000760:     	mul	w19, w19, w0
100000764:     	mov	w0, w20
100000768:     	bl	0x100000790 <_record_event>
10000076c:     	ldr	w1, [x29, #0x3c]
100000770:     	cmp	w19, w20
100000774:     	cset	w0, eq
100000778:     	add	w1, w1, #0x11
10000077c:     	stp	w19, w1, [x21]
100000780:     	ldr	x21, [sp, #0x20]
100000784:     	ldp	x19, x20, [sp, #0x10]
100000788:     	ldp	x29, x30, [sp], #0x40
10000078c:     	ret

0000000100000790 <_record_event>:
100000790:     	adrp	x2, 0x100008000 <_event_hash>
100000794:     	ldr	w1, [x2]
100000798:     	add	w1, w1, w1, lsl #5
10000079c:     	eor	w1, w1, w0
1000007a0:     	str	w1, [x2]
1000007a4:     	ret

00000001000007a8 <_next_value>:
1000007a8:     	stp	x29, x30, [sp, #-0x10]!
1000007ac:     	mov	x29, sp
1000007b0:     	bl	0x100000790 <_record_event>
1000007b4:     	adrp	x2, 0x100008000 <_event_hash>
1000007b8:     	ldp	x29, x30, [sp], #0x10
1000007bc:     	add	x2, x2, #0x4
1000007c0:     	ldr	w1, [x2, #0x4]
1000007c4:     	add	w1, w0, w1
1000007c8:     	add	w0, w1, w0
1000007cc:     	str	w1, [x2, #0x4]
1000007d0:     	ret

Disassembly of section __TEXT,__text_startup:

00000001000007d4 <_main>:
1000007d4:     	sub	sp, sp, #0x90
1000007d8:     	stp	x29, x30, [sp, #0x30]
1000007dc:     	add	x29, sp, #0x30
1000007e0:     	stp	x19, x20, [sp, #0x40]
1000007e4:     	stp	x21, x22, [sp, #0x50]
1000007e8:     	stp	x23, x24, [sp, #0x60]
1000007ec:     	cmp	w0, #0x3
1000007f0:     	b.eq	0x100000814 <_main+0x40>
1000007f4:     	mov	w19, #0x2               ; =2
1000007f8:     	ldp	x29, x30, [sp, #0x30]
1000007fc:     	mov	w0, w19
100000800:     	ldp	x19, x20, [sp, #0x40]
100000804:     	ldp	x21, x22, [sp, #0x50]
100000808:     	ldp	x23, x24, [sp, #0x60]
10000080c:     	add	sp, sp, #0x90
100000810:     	ret
100000814:     	mov	x19, x1
100000818:     	mov	w2, #0xa                ; =10
10000081c:     	ldr	x0, [x19, #0x8]
100000820:     	mov	x1, #0x0                ; =0
100000824:     	bl	0x10000094c <_strtoul+0x10000094c>
100000828:     	mov	x1, #0x0                ; =0
10000082c:     	mov	x23, x0
100000830:     	ldr	x0, [x19, #0x10]
100000834:     	mov	w2, #0xa                ; =10
100000838:     	bl	0x10000094c <_strtoul+0x10000094c>
10000083c:     	mov	x19, x0
100000840:     	add	x1, x29, #0x40
100000844:     	mov	w0, #0x6                ; =6
100000848:     	bl	0x100000934 <_strtoul+0x100000934>
10000084c:     	cbnz	w0, 0x1000007f4 <_main+0x20>
100000850:     	adrp	x22, 0x100008000 <_event_hash>
100000854:     	mov	x21, #0x0               ; =0
100000858:     	mov	w20, #0x0               ; =0
10000085c:     	mov	x24, #0xa               ; =10
100000860:     	add	x22, x22, #0x4
100000864:     	cmp	x21, x23
100000868:     	b.ne	0x1000008f0 <_main+0x11c>
10000086c:     	add	x1, x29, #0x50
100000870:     	mov	w0, #0x6                ; =6
100000874:     	bl	0x100000934 <_strtoul+0x100000934>
100000878:     	mov	w19, w0
10000087c:     	cbnz	w0, 0x1000007f4 <_main+0x20>
100000880:     	adrp	x0, 0x100008000 <_event_hash>
100000884:     	ldr	w0, [x0]
100000888:     	str	w0, [sp, #0x28]
10000088c:     	adrp	x0, 0x100008000 <_event_hash>
100000890:     	add	x0, x0, #0x4
100000894:     	ldr	w1, [x0, #0x8]
100000898:     	str	w1, [sp, #0x20]
10000089c:     	ldp	w0, w1, [x0]
1000008a0:     	str	w20, [sp, #0x8]
1000008a4:     	str	w0, [sp, #0x10]
1000008a8:     	ldr	x0, [x29, #0x58]
1000008ac:     	str	w1, [sp, #0x18]
1000008b0:     	ldr	x1, [x29, #0x48]
1000008b4:     	sub	x0, x0, x1
1000008b8:     	ldr	x1, [x29, #0x40]
1000008bc:     	scvtf	d0, x0
1000008c0:     	adrp	x0, 0x100000000 <_strtoul+0x100000000>
1000008c4:     	ldr	d30, [x0, #0x970]
1000008c8:     	ldr	x0, [x29, #0x50]
1000008cc:     	fmul	d30, d0, d30
1000008d0:     	sub	x0, x0, x1
1000008d4:     	scvtf	d31, x0
1000008d8:     	adrp	x0, 0x100000000 <_strtoul+0x100000000>
1000008dc:     	add	x0, x0, #0x958
1000008e0:     	fadd	d31, d30, d31
1000008e4:     	str	d31, [sp]
1000008e8:     	bl	0x100000940 <_strtoul+0x100000940>
1000008ec:     	b	0x1000007f8 <_main+0x24>
1000008f0:     	udiv	x2, x21, x24
1000008f4:     	mov	x0, x22
1000008f8:     	eor	w19, w19, w19, lsl #13
1000008fc:     	eor	w19, w19, w19, lsr #17
100000900:     	eor	w19, w19, w19, lsl #5
100000904:     	msub	x2, x2, x24, x21
100000908:     	mov	w1, w19
10000090c:     	add	x21, x21, #0x1
100000910:     	sub	w2, w2, #0x1
100000914:     	bl	0x100000698 <_region_pipeline>
100000918:     	add	w20, w20, w0
10000091c:     	mov	w1, w19
100000920:     	mov	w2, w20
100000924:     	mov	x0, x22
100000928:     	bl	0x100000708 <_region_outputs>
10000092c:     	add	w20, w0, w20
100000930:     	b	0x100000864 <_main+0x90>

Disassembly of section __TEXT,__stubs:

0000000100000934 <__stubs>:
100000934:     	adrp	x16, 0x100004000 <_strtoul+0x100004000>
100000938:     	ldr	x16, [x16]
10000093c:     	br	x16
100000940:     	adrp	x16, 0x100004000 <_strtoul+0x100004000>
100000944:     	ldr	x16, [x16, #0x8]
100000948:     	br	x16
10000094c:     	adrp	x16, 0x100004000 <_strtoul+0x100004000>
100000950:     	ldr	x16, [x16, #0x10]
100000954:     	br	x16
