
/Users/admin/C-SRD/experiments/runs/private-regions-cost-native-20261110/gcc-Os/identity:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000100000698 <_region_pipeline>:
100000698:     	stp	x29, x30, [sp, #-0x30]!
10000069c:     	mov	x29, sp
1000006a0:     	stp	x19, x20, [sp, #0x10]
1000006a4:     	mov	w20, w2
1000006a8:     	str	x21, [sp, #0x20]
1000006ac:     	mov	x21, x0
1000006b0:     	ldr	w0, [x0]
1000006b4:     	add	w19, w1, w0
1000006b8:     	add	w19, w19, w19, lsl #1
1000006bc:     	add	w19, w19, #0xb
1000006c0:     	mov	w0, w19
1000006c4:     	bl	0x100000750 <_record_event>
1000006c8:     	tbz	w20, #0x1f, 0x100000700 <_region_pipeline+0x68>
1000006cc:     	ldr	x21, [sp, #0x20]
1000006d0:     	mov	w0, w19
1000006d4:     	ldp	x19, x20, [sp, #0x10]
1000006d8:     	ldp	x29, x30, [sp], #0x30
1000006dc:     	ret
1000006e0:     	mov	w0, w19
1000006e4:     	sub	w20, w20, #0x1
1000006e8:     	bl	0x100000768 <_next_value>
1000006ec:     	add	w19, w19, w0
1000006f0:     	add	w19, w19, w19, lsl #2
1000006f4:     	sub	w19, w19, #0x7
1000006f8:     	str	w19, [x21]
1000006fc:     	bl	0x100000750 <_record_event>
100000700:     	cbnz	w20, 0x1000006e0 <_region_pipeline+0x48>
100000704:     	b	0x1000006cc <_region_pipeline+0x34>

0000000100000708 <_region_outputs>:
100000708:     	stp	x29, x30, [sp, #-0x30]!
10000070c:     	mov	x29, sp
100000710:     	stp	x19, x20, [sp, #0x10]
100000714:     	add	w19, w1, #0x11
100000718:     	add	w20, w19, w19, lsl #1
10000071c:     	add	w20, w20, w2
100000720:     	stp	x21, x22, [sp, #0x20]
100000724:     	mov	x21, x0
100000728:     	sub	w22, w20, w19
10000072c:     	mov	w0, w20
100000730:     	bl	0x100000750 <_record_event>
100000734:     	cmp	w20, w22
100000738:     	cset	w0, eq
10000073c:     	stp	w22, w19, [x21]
100000740:     	ldp	x19, x20, [sp, #0x10]
100000744:     	ldp	x21, x22, [sp, #0x20]
100000748:     	ldp	x29, x30, [sp], #0x30
10000074c:     	ret

0000000100000750 <_record_event>:
100000750:     	adrp	x2, 0x100008000 <_event_hash>
100000754:     	ldr	w1, [x2]
100000758:     	add	w1, w1, w1, lsl #5
10000075c:     	eor	w1, w1, w0
100000760:     	str	w1, [x2]
100000764:     	ret

0000000100000768 <_next_value>:
100000768:     	stp	x29, x30, [sp, #-0x10]!
10000076c:     	mov	x29, sp
100000770:     	bl	0x100000750 <_record_event>
100000774:     	adrp	x2, 0x100008000 <_event_hash>
100000778:     	ldp	x29, x30, [sp], #0x10
10000077c:     	add	x2, x2, #0x4
100000780:     	ldr	w1, [x2, #0x4]
100000784:     	add	w1, w0, w1
100000788:     	add	w0, w1, w0
10000078c:     	str	w1, [x2, #0x4]
100000790:     	ret

Disassembly of section __TEXT,__text_startup:

0000000100000794 <_main>:
100000794:     	sub	sp, sp, #0x90
100000798:     	stp	x29, x30, [sp, #0x30]
10000079c:     	add	x29, sp, #0x30
1000007a0:     	stp	x19, x20, [sp, #0x40]
1000007a4:     	stp	x21, x22, [sp, #0x50]
1000007a8:     	stp	x23, x24, [sp, #0x60]
1000007ac:     	cmp	w0, #0x3
1000007b0:     	b.eq	0x1000007d4 <_main+0x40>
1000007b4:     	mov	w19, #0x2               ; =2
1000007b8:     	ldp	x29, x30, [sp, #0x30]
1000007bc:     	mov	w0, w19
1000007c0:     	ldp	x19, x20, [sp, #0x40]
1000007c4:     	ldp	x21, x22, [sp, #0x50]
1000007c8:     	ldp	x23, x24, [sp, #0x60]
1000007cc:     	add	sp, sp, #0x90
1000007d0:     	ret
1000007d4:     	mov	x19, x1
1000007d8:     	mov	w2, #0xa                ; =10
1000007dc:     	ldr	x0, [x19, #0x8]
1000007e0:     	mov	x1, #0x0                ; =0
1000007e4:     	bl	0x10000090c <_strtoul+0x10000090c>
1000007e8:     	mov	x1, #0x0                ; =0
1000007ec:     	mov	x23, x0
1000007f0:     	ldr	x0, [x19, #0x10]
1000007f4:     	mov	w2, #0xa                ; =10
1000007f8:     	bl	0x10000090c <_strtoul+0x10000090c>
1000007fc:     	mov	x19, x0
100000800:     	add	x1, x29, #0x40
100000804:     	mov	w0, #0x6                ; =6
100000808:     	bl	0x1000008f4 <_strtoul+0x1000008f4>
10000080c:     	cbnz	w0, 0x1000007b4 <_main+0x20>
100000810:     	adrp	x22, 0x100008000 <_event_hash>
100000814:     	mov	x21, #0x0               ; =0
100000818:     	mov	w20, #0x0               ; =0
10000081c:     	mov	x24, #0xa               ; =10
100000820:     	add	x22, x22, #0x4
100000824:     	cmp	x21, x23
100000828:     	b.ne	0x1000008b0 <_main+0x11c>
10000082c:     	add	x1, x29, #0x50
100000830:     	mov	w0, #0x6                ; =6
100000834:     	bl	0x1000008f4 <_strtoul+0x1000008f4>
100000838:     	mov	w19, w0
10000083c:     	cbnz	w0, 0x1000007b4 <_main+0x20>
100000840:     	adrp	x0, 0x100008000 <_event_hash>
100000844:     	ldr	w0, [x0]
100000848:     	str	w0, [sp, #0x28]
10000084c:     	adrp	x0, 0x100008000 <_event_hash>
100000850:     	add	x0, x0, #0x4
100000854:     	ldr	w1, [x0, #0x8]
100000858:     	str	w1, [sp, #0x20]
10000085c:     	ldp	w0, w1, [x0]
100000860:     	str	w20, [sp, #0x8]
100000864:     	str	w0, [sp, #0x10]
100000868:     	ldr	x0, [x29, #0x58]
10000086c:     	str	w1, [sp, #0x18]
100000870:     	ldr	x1, [x29, #0x48]
100000874:     	sub	x0, x0, x1
100000878:     	ldr	x1, [x29, #0x40]
10000087c:     	scvtf	d0, x0
100000880:     	adrp	x0, 0x100000000 <_strtoul+0x100000000>
100000884:     	ldr	d30, [x0, #0x930]
100000888:     	ldr	x0, [x29, #0x50]
10000088c:     	fmul	d30, d0, d30
100000890:     	sub	x0, x0, x1
100000894:     	scvtf	d31, x0
100000898:     	adrp	x0, 0x100000000 <_strtoul+0x100000000>
10000089c:     	add	x0, x0, #0x918
1000008a0:     	fadd	d31, d30, d31
1000008a4:     	str	d31, [sp]
1000008a8:     	bl	0x100000900 <_strtoul+0x100000900>
1000008ac:     	b	0x1000007b8 <_main+0x24>
1000008b0:     	udiv	x2, x21, x24
1000008b4:     	mov	x0, x22
1000008b8:     	eor	w19, w19, w19, lsl #13
1000008bc:     	eor	w19, w19, w19, lsr #17
1000008c0:     	eor	w19, w19, w19, lsl #5
1000008c4:     	msub	x2, x2, x24, x21
1000008c8:     	mov	w1, w19
1000008cc:     	add	x21, x21, #0x1
1000008d0:     	sub	w2, w2, #0x1
1000008d4:     	bl	0x100000698 <_region_pipeline>
1000008d8:     	add	w20, w20, w0
1000008dc:     	mov	w1, w19
1000008e0:     	mov	w2, w20
1000008e4:     	mov	x0, x22
1000008e8:     	bl	0x100000708 <_region_outputs>
1000008ec:     	add	w20, w0, w20
1000008f0:     	b	0x100000824 <_main+0x90>

Disassembly of section __TEXT,__stubs:

00000001000008f4 <__stubs>:
1000008f4:     	adrp	x16, 0x100004000 <_strtoul+0x100004000>
1000008f8:     	ldr	x16, [x16]
1000008fc:     	br	x16
100000900:     	adrp	x16, 0x100004000 <_strtoul+0x100004000>
100000904:     	ldr	x16, [x16, #0x8]
100000908:     	br	x16
10000090c:     	adrp	x16, 0x100004000 <_strtoul+0x100004000>
100000910:     	ldr	x16, [x16, #0x10]
100000914:     	br	x16
