
/Users/admin/C-SRD/experiments/runs/private-regions-cost-native-20261110/gcc-O3/identity:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001000006a0 <_region_pipeline>:
1000006a0:     	stp	x29, x30, [sp, #-0x30]!
1000006a4:     	mov	x29, sp
1000006a8:     	stp	x19, x20, [sp, #0x10]
1000006ac:     	mov	w20, w2
1000006b0:     	str	x21, [sp, #0x20]
1000006b4:     	mov	x21, x0
1000006b8:     	ldr	w0, [x0]
1000006bc:     	add	w19, w1, w0
1000006c0:     	add	w19, w19, w19, lsl #1
1000006c4:     	add	w19, w19, #0xb
1000006c8:     	mov	w0, w19
1000006cc:     	bl	0x100000780 <_record_event>
1000006d0:     	cmp	w20, #0x0
1000006d4:     	b.le	0x100000704 <_region_pipeline+0x64>
1000006d8:     	nop
1000006dc:     	nop
1000006e0:     	mov	w0, w19
1000006e4:     	bl	0x1000007a0 <_next_value>
1000006e8:     	add	w1, w0, w19
1000006ec:     	add	w1, w1, w1, lsl #2
1000006f0:     	sub	w19, w1, #0x7
1000006f4:     	str	w19, [x21]
1000006f8:     	bl	0x100000780 <_record_event>
1000006fc:     	subs	w20, w20, #0x1
100000700:     	b.ne	0x1000006e0 <_region_pipeline+0x40>
100000704:     	ldr	x21, [sp, #0x20]
100000708:     	mov	w0, w19
10000070c:     	ldp	x19, x20, [sp, #0x10]
100000710:     	ldp	x29, x30, [sp], #0x30
100000714:     	ret
100000718:     	nop
10000071c:     	nop

0000000100000720 <_region_outputs>:
100000720:     	stp	x29, x30, [sp, #-0x30]!
100000724:     	mov	x29, sp
100000728:     	stp	x19, x20, [sp, #0x10]
10000072c:     	add	w19, w1, #0x11
100000730:     	add	w20, w19, w19, lsl #1
100000734:     	add	w20, w20, w2
100000738:     	stp	x21, x22, [sp, #0x20]
10000073c:     	mov	x21, x0
100000740:     	sub	w22, w20, w19
100000744:     	mov	w0, w20
100000748:     	bl	0x100000780 <_record_event>
10000074c:     	cmp	w20, w22
100000750:     	cset	w0, eq
100000754:     	stp	w22, w19, [x21]
100000758:     	ldp	x19, x20, [sp, #0x10]
10000075c:     	ldp	x21, x22, [sp, #0x20]
100000760:     	ldp	x29, x30, [sp], #0x30
100000764:     	ret
		...

0000000100000780 <_record_event>:
100000780:     	adrp	x2, 0x100008000 <_event_hash>
100000784:     	ldr	w1, [x2]
100000788:     	add	w1, w1, w1, lsl #5
10000078c:     	eor	w1, w1, w0
100000790:     	str	w1, [x2]
100000794:     	ret
100000798:     	nop
10000079c:     	nop

00000001000007a0 <_next_value>:
1000007a0:     	adrp	x4, 0x100008000 <_event_hash>
1000007a4:     	adrp	x2, 0x100008000 <_event_hash>
1000007a8:     	ldr	w1, [x4]
1000007ac:     	add	x2, x2, #0x4
1000007b0:     	ldr	w3, [x2, #0x4]
1000007b4:     	add	w1, w1, w1, lsl #5
1000007b8:     	add	w3, w0, w3
1000007bc:     	eor	w1, w1, w0
1000007c0:     	add	w0, w3, w0
1000007c4:     	str	w1, [x4]
1000007c8:     	str	w3, [x2, #0x4]
1000007cc:     	ret

Disassembly of section __TEXT,__text_startup:

00000001000007e0 <_main>:
1000007e0:     	sub	sp, sp, #0x90
1000007e4:     	stp	x29, x30, [sp, #0x30]
1000007e8:     	add	x29, sp, #0x30
1000007ec:     	stp	x19, x20, [sp, #0x40]
1000007f0:     	cmp	w0, #0x3
1000007f4:     	b.eq	0x100000810 <_main+0x30>
1000007f8:     	mov	w19, #0x2               ; =2
1000007fc:     	ldp	x29, x30, [sp, #0x30]
100000800:     	mov	w0, w19
100000804:     	ldp	x19, x20, [sp, #0x40]
100000808:     	add	sp, sp, #0x90
10000080c:     	ret
100000810:     	mov	x19, x1
100000814:     	mov	w2, #0xa                ; =10
100000818:     	stp	x21, x22, [x29, #0x20]
10000081c:     	mov	x1, #0x0                ; =0
100000820:     	ldr	x0, [x19, #0x8]
100000824:     	bl	0x10000096c <_strtoul+0x10000096c>
100000828:     	mov	x1, #0x0                ; =0
10000082c:     	mov	x21, x0
100000830:     	ldr	x0, [x19, #0x10]
100000834:     	mov	w2, #0xa                ; =10
100000838:     	bl	0x10000096c <_strtoul+0x10000096c>
10000083c:     	mov	x19, x0
100000840:     	add	x1, x29, #0x40
100000844:     	mov	w0, #0x6                ; =6
100000848:     	bl	0x100000954 <_strtoul+0x100000954>
10000084c:     	cbnz	w0, 0x100000944 <_main+0x164>
100000850:     	cbz	x21, 0x10000094c <_main+0x16c>
100000854:     	adrp	x22, 0x100008000 <_event_hash>
100000858:     	stp	x23, x24, [x29, #0x30]
10000085c:     	mov	x23, #-0x3333333333333334 ; =-3689348814741910324
100000860:     	mov	x24, #0x0               ; =0
100000864:     	mov	w20, #0x0               ; =0
100000868:     	add	x22, x22, #0x4
10000086c:     	movk	x23, #0xcccd
100000870:     	umulh	x1, x24, x23
100000874:     	mov	x0, x22
100000878:     	eor	w19, w19, w19, lsl #13
10000087c:     	lsr	x1, x1, #3
100000880:     	eor	w19, w19, w19, lsr #17
100000884:     	add	x1, x1, x1, lsl #2
100000888:     	eor	w19, w19, w19, lsl #5
10000088c:     	sub	x2, x24, x1, lsl #1
100000890:     	add	x24, x24, #0x1
100000894:     	mov	w1, w19
100000898:     	sub	w2, w2, #0x1
10000089c:     	bl	0x1000006a0 <_region_pipeline>
1000008a0:     	add	w20, w0, w20
1000008a4:     	mov	w1, w19
1000008a8:     	mov	w2, w20
1000008ac:     	mov	x0, x22
1000008b0:     	bl	0x100000720 <_region_outputs>
1000008b4:     	add	w20, w0, w20
1000008b8:     	cmp	x21, x24
1000008bc:     	b.ne	0x100000870 <_main+0x90>
1000008c0:     	ldp	x23, x24, [x29, #0x30]
1000008c4:     	add	x1, x29, #0x50
1000008c8:     	mov	w0, #0x6                ; =6
1000008cc:     	bl	0x100000954 <_strtoul+0x100000954>
1000008d0:     	mov	w19, w0
1000008d4:     	cbnz	w0, 0x100000944 <_main+0x164>
1000008d8:     	ldp	x6, x4, [x29, #0x40]
1000008dc:     	adrp	x0, 0x100000000 <_strtoul+0x100000000>
1000008e0:     	adrp	x1, 0x100008000 <_event_hash>
1000008e4:     	add	x1, x1, #0x4
1000008e8:     	adrp	x5, 0x100008000 <_event_hash>
1000008ec:     	ldp	x2, x3, [x29, #0x50]
1000008f0:     	str	w20, [sp, #0x8]
1000008f4:     	ldr	d30, [x0, #0x990]
1000008f8:     	adrp	x0, 0x100000000 <_strtoul+0x100000000>
1000008fc:     	sub	x3, x3, x4
100000900:     	sub	x2, x2, x6
100000904:     	ldr	w4, [x1, #0x8]
100000908:     	add	x0, x0, #0x978
10000090c:     	scvtf	d0, x3
100000910:     	scvtf	d31, x2
100000914:     	ldp	w3, w1, [x1]
100000918:     	str	w4, [sp, #0x20]
10000091c:     	fmul	d30, d0, d30
100000920:     	str	w1, [sp, #0x18]
100000924:     	ldr	w1, [x5]
100000928:     	str	w3, [sp, #0x10]
10000092c:     	fadd	d31, d30, d31
100000930:     	str	w1, [sp, #0x28]
100000934:     	str	d31, [sp]
100000938:     	bl	0x100000960 <_strtoul+0x100000960>
10000093c:     	ldp	x21, x22, [x29, #0x20]
100000940:     	b	0x1000007fc <_main+0x1c>
100000944:     	ldp	x21, x22, [x29, #0x20]
100000948:     	b	0x1000007f8 <_main+0x18>
10000094c:     	mov	w20, #0x0               ; =0
100000950:     	b	0x1000008c4 <_main+0xe4>

Disassembly of section __TEXT,__stubs:

0000000100000954 <__stubs>:
100000954:     	adrp	x16, 0x100004000 <_strtoul+0x100004000>
100000958:     	ldr	x16, [x16]
10000095c:     	br	x16
100000960:     	adrp	x16, 0x100004000 <_strtoul+0x100004000>
100000964:     	ldr	x16, [x16, #0x8]
100000968:     	br	x16
10000096c:     	adrp	x16, 0x100004000 <_strtoul+0x100004000>
100000970:     	ldr	x16, [x16, #0x10]
100000974:     	br	x16
