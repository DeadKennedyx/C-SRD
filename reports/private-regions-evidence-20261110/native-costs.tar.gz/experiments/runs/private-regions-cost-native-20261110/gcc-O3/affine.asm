
/Users/admin/C-SRD/experiments/runs/private-regions-cost-native-20261110/gcc-O3/affine:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001000006a0 <_region_pipeline>:
1000006a0:     	stp	x29, x30, [sp, #-0x30]!
1000006a4:     	mov	x29, sp
1000006a8:     	stp	x19, x20, [sp, #0x10]
1000006ac:     	mov	w20, w2
1000006b0:     	str	x21, [sp, #0x20]
1000006b4:     	mov	x21, x0
1000006b8:     	ldr	w0, [x0]
1000006bc:     	add	w19, w1, w0
1000006c0:     	add	w19, w19, w19, lsl #1
1000006c4:     	add	w19, w19, #0xb
1000006c8:     	mov	w0, w19
1000006cc:     	bl	0x1000007c0 <_record_event>
1000006d0:     	cmp	w20, #0x0
1000006d4:     	b.le	0x100000704 <_region_pipeline+0x64>
1000006d8:     	nop
1000006dc:     	nop
1000006e0:     	mov	w0, w19
1000006e4:     	bl	0x1000007e0 <_next_value>
1000006e8:     	add	w1, w0, w19
1000006ec:     	add	w1, w1, w1, lsl #2
1000006f0:     	sub	w19, w1, #0x7
1000006f4:     	str	w19, [x21]
1000006f8:     	bl	0x1000007c0 <_record_event>
1000006fc:     	subs	w20, w20, #0x1
100000700:     	b.ne	0x1000006e0 <_region_pipeline+0x40>
100000704:     	ldr	x21, [sp, #0x20]
100000708:     	mov	w0, w19
10000070c:     	ldp	x19, x20, [sp, #0x10]
100000710:     	ldp	x29, x30, [sp], #0x30
100000714:     	ret
100000718:     	nop
10000071c:     	nop

0000000100000720 <_region_outputs>:
100000720:     	mov	w5, #0xf695             ; =63125
100000724:     	mov	w3, #0x2a16             ; =10774
100000728:     	stp	x29, x30, [sp, #-0x40]!
10000072c:     	movk	w5, #0xf36a, lsl #16
100000730:     	movk	w3, #0x95d9, lsl #16
100000734:     	mov	w7, #0x6b9e             ; =27550
100000738:     	mov	x29, sp
10000073c:     	madd	w3, w1, w5, w3
100000740:     	movk	w7, #0x2882, lsl #16
100000744:     	stp	x19, x20, [sp, #0x10]
100000748:     	mov	w4, #0x24bd             ; =9405
10000074c:     	mov	w6, #0xd5d3             ; =54739
100000750:     	madd	w20, w2, w5, w7
100000754:     	movk	w4, #0x922f, lsl #16
100000758:     	movk	w6, #0x8eb6, lsl #16
10000075c:     	str	x21, [sp, #0x20]
100000760:     	mov	x21, x0
100000764:     	add	w0, w3, w3, lsl #1
100000768:     	str	w1, [x29, #0x3c]
10000076c:     	add	w20, w20, w0
100000770:     	sub	w3, w20, w3
100000774:     	madd	w20, w20, w4, w6
100000778:     	mul	w19, w3, w4
10000077c:     	mov	w0, w20
100000780:     	bl	0x1000007c0 <_record_event>
100000784:     	ldr	w1, [x29, #0x3c]
100000788:     	cmp	w19, w20
10000078c:     	cset	w0, eq
100000790:     	add	w1, w1, #0x11
100000794:     	stp	w19, w1, [x21]
100000798:     	ldr	x21, [sp, #0x20]
10000079c:     	ldp	x19, x20, [sp, #0x10]
1000007a0:     	ldp	x29, x30, [sp], #0x40
1000007a4:     	ret
		...

00000001000007c0 <_record_event>:
1000007c0:     	adrp	x2, 0x100008000 <_event_hash>
1000007c4:     	ldr	w1, [x2]
1000007c8:     	add	w1, w1, w1, lsl #5
1000007cc:     	eor	w1, w1, w0
1000007d0:     	str	w1, [x2]
1000007d4:     	ret
1000007d8:     	nop
1000007dc:     	nop

00000001000007e0 <_next_value>:
1000007e0:     	adrp	x4, 0x100008000 <_event_hash>
1000007e4:     	adrp	x2, 0x100008000 <_event_hash>
1000007e8:     	ldr	w1, [x4]
1000007ec:     	add	x2, x2, #0x4
1000007f0:     	ldr	w3, [x2, #0x4]
1000007f4:     	add	w1, w1, w1, lsl #5
1000007f8:     	add	w3, w0, w3
1000007fc:     	eor	w1, w1, w0
100000800:     	add	w0, w3, w0
100000804:     	str	w1, [x4]
100000808:     	str	w3, [x2, #0x4]
10000080c:     	ret

Disassembly of section __TEXT,__text_startup:

0000000100000820 <_main>:
100000820:     	sub	sp, sp, #0x90
100000824:     	stp	x29, x30, [sp, #0x30]
100000828:     	add	x29, sp, #0x30
10000082c:     	stp	x19, x20, [sp, #0x40]
100000830:     	cmp	w0, #0x3
100000834:     	b.eq	0x100000850 <_main+0x30>
100000838:     	mov	w19, #0x2               ; =2
10000083c:     	ldp	x29, x30, [sp, #0x30]
100000840:     	mov	w0, w19
100000844:     	ldp	x19, x20, [sp, #0x40]
100000848:     	add	sp, sp, #0x90
10000084c:     	ret
100000850:     	mov	x19, x1
100000854:     	mov	w2, #0xa                ; =10
100000858:     	stp	x21, x22, [x29, #0x20]
10000085c:     	mov	x1, #0x0                ; =0
100000860:     	ldr	x0, [x19, #0x8]
100000864:     	bl	0x1000009ac <_strtoul+0x1000009ac>
100000868:     	mov	x1, #0x0                ; =0
10000086c:     	mov	x21, x0
100000870:     	ldr	x0, [x19, #0x10]
100000874:     	mov	w2, #0xa                ; =10
100000878:     	bl	0x1000009ac <_strtoul+0x1000009ac>
10000087c:     	mov	x19, x0
100000880:     	add	x1, x29, #0x40
100000884:     	mov	w0, #0x6                ; =6
100000888:     	bl	0x100000994 <_strtoul+0x100000994>
10000088c:     	cbnz	w0, 0x100000984 <_main+0x164>
100000890:     	cbz	x21, 0x10000098c <_main+0x16c>
100000894:     	adrp	x22, 0x100008000 <_event_hash>
100000898:     	stp	x23, x24, [x29, #0x30]
10000089c:     	mov	x23, #-0x3333333333333334 ; =-3689348814741910324
1000008a0:     	mov	x24, #0x0               ; =0
1000008a4:     	mov	w20, #0x0               ; =0
1000008a8:     	add	x22, x22, #0x4
1000008ac:     	movk	x23, #0xcccd
1000008b0:     	umulh	x1, x24, x23
1000008b4:     	mov	x0, x22
1000008b8:     	eor	w19, w19, w19, lsl #13
1000008bc:     	lsr	x1, x1, #3
1000008c0:     	eor	w19, w19, w19, lsr #17
1000008c4:     	add	x1, x1, x1, lsl #2
1000008c8:     	eor	w19, w19, w19, lsl #5
1000008cc:     	sub	x2, x24, x1, lsl #1
1000008d0:     	add	x24, x24, #0x1
1000008d4:     	mov	w1, w19
1000008d8:     	sub	w2, w2, #0x1
1000008dc:     	bl	0x1000006a0 <_region_pipeline>
1000008e0:     	add	w20, w0, w20
1000008e4:     	mov	w1, w19
1000008e8:     	mov	w2, w20
1000008ec:     	mov	x0, x22
1000008f0:     	bl	0x100000720 <_region_outputs>
1000008f4:     	add	w20, w0, w20
1000008f8:     	cmp	x21, x24
1000008fc:     	b.ne	0x1000008b0 <_main+0x90>
100000900:     	ldp	x23, x24, [x29, #0x30]
100000904:     	add	x1, x29, #0x50
100000908:     	mov	w0, #0x6                ; =6
10000090c:     	bl	0x100000994 <_strtoul+0x100000994>
100000910:     	mov	w19, w0
100000914:     	cbnz	w0, 0x100000984 <_main+0x164>
100000918:     	ldp	x6, x4, [x29, #0x40]
10000091c:     	adrp	x0, 0x100000000 <_strtoul+0x100000000>
100000920:     	adrp	x1, 0x100008000 <_event_hash>
100000924:     	add	x1, x1, #0x4
100000928:     	adrp	x5, 0x100008000 <_event_hash>
10000092c:     	ldp	x2, x3, [x29, #0x50]
100000930:     	str	w20, [sp, #0x8]
100000934:     	ldr	d30, [x0, #0x9d0]
100000938:     	adrp	x0, 0x100000000 <_strtoul+0x100000000>
10000093c:     	sub	x3, x3, x4
100000940:     	sub	x2, x2, x6
100000944:     	ldr	w4, [x1, #0x8]
100000948:     	add	x0, x0, #0x9b8
10000094c:     	scvtf	d0, x3
100000950:     	scvtf	d31, x2
100000954:     	ldp	w3, w1, [x1]
100000958:     	str	w4, [sp, #0x20]
10000095c:     	fmul	d30, d0, d30
100000960:     	str	w1, [sp, #0x18]
100000964:     	ldr	w1, [x5]
100000968:     	str	w3, [sp, #0x10]
10000096c:     	fadd	d31, d30, d31
100000970:     	str	w1, [sp, #0x28]
100000974:     	str	d31, [sp]
100000978:     	bl	0x1000009a0 <_strtoul+0x1000009a0>
10000097c:     	ldp	x21, x22, [x29, #0x20]
100000980:     	b	0x10000083c <_main+0x1c>
100000984:     	ldp	x21, x22, [x29, #0x20]
100000988:     	b	0x100000838 <_main+0x18>
10000098c:     	mov	w20, #0x0               ; =0
100000990:     	b	0x100000904 <_main+0xe4>

Disassembly of section __TEXT,__stubs:

0000000100000994 <__stubs>:
100000994:     	adrp	x16, 0x100004000 <_strtoul+0x100004000>
100000998:     	ldr	x16, [x16]
10000099c:     	br	x16
1000009a0:     	adrp	x16, 0x100004000 <_strtoul+0x100004000>
1000009a4:     	ldr	x16, [x16, #0x8]
1000009a8:     	br	x16
1000009ac:     	adrp	x16, 0x100004000 <_strtoul+0x100004000>
1000009b0:     	ldr	x16, [x16, #0x10]
1000009b4:     	br	x16
