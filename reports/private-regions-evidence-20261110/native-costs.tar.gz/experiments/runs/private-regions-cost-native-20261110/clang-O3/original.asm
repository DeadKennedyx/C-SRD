
/Users/admin/C-SRD/experiments/runs/private-regions-cost-native-20261110/clang-O3/original:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001000004f8 <_region_pipeline>:
1000004f8:     	stp	x22, x21, [sp, #-0x30]!
1000004fc:     	stp	x20, x19, [sp, #0x10]
100000500:     	stp	x29, x30, [sp, #0x20]
100000504:     	add	x29, sp, #0x20
100000508:     	mov	x21, x2
10000050c:     	mov	x19, x0
100000510:     	ldr	w8, [x0]
100000514:     	add	w8, w8, w1
100000518:     	add	w8, w8, w8, lsl #1
10000051c:     	add	w20, w8, #0xb
100000520:     	mov	x0, x20
100000524:     	bl	0x1000005b4 <_record_event>
100000528:     	cmp	w21, #0x1
10000052c:     	b.lt	0x10000055c <_region_pipeline+0x64>
100000530:     	add	w21, w21, #0x1
100000534:     	mov	x0, x20
100000538:     	bl	0x1000005cc <_next_value>
10000053c:     	add	w8, w0, w20
100000540:     	add	w8, w8, w8, lsl #2
100000544:     	sub	w20, w8, #0x7
100000548:     	str	w20, [x19]
10000054c:     	bl	0x1000005b4 <_record_event>
100000550:     	sub	w21, w21, #0x1
100000554:     	cmp	w21, #0x1
100000558:     	b.hi	0x100000534 <_region_pipeline+0x3c>
10000055c:     	mov	x0, x20
100000560:     	ldp	x29, x30, [sp, #0x20]
100000564:     	ldp	x20, x19, [sp, #0x10]
100000568:     	ldp	x22, x21, [sp], #0x30
10000056c:     	ret

0000000100000570 <_region_outputs>:
100000570:     	stp	x22, x21, [sp, #-0x30]!
100000574:     	stp	x20, x19, [sp, #0x10]
100000578:     	stp	x29, x30, [sp, #0x20]
10000057c:     	add	x29, sp, #0x20
100000580:     	mov	x19, x0
100000584:     	add	w20, w1, #0x11
100000588:     	add	w8, w20, w20, lsl #1
10000058c:     	add	w0, w8, w2
100000590:     	sub	w21, w0, w20
100000594:     	bl	0x1000005b4 <_record_event>
100000598:     	stp	w21, w20, [x19]
10000059c:     	cmp	w20, #0x0
1000005a0:     	cset	w0, eq
1000005a4:     	ldp	x29, x30, [sp, #0x20]
1000005a8:     	ldp	x20, x19, [sp, #0x10]
1000005ac:     	ldp	x22, x21, [sp], #0x30
1000005b0:     	ret

00000001000005b4 <_record_event>:
1000005b4:     	adrp	x8, 0x100008000 <__MergedGlobals>
1000005b8:     	ldr	w9, [x8]
1000005bc:     	add	w9, w9, w9, lsl #5
1000005c0:     	eor	w9, w9, w0
1000005c4:     	str	w9, [x8]
1000005c8:     	ret

00000001000005cc <_next_value>:
1000005cc:     	adrp	x8, 0x100008000 <__MergedGlobals>
1000005d0:     	add	x8, x8, #0x0
1000005d4:     	ldr	w9, [x8]
1000005d8:     	add	w9, w9, w9, lsl #5
1000005dc:     	eor	w9, w9, w0
1000005e0:     	str	w9, [x8]
1000005e4:     	ldr	w9, [x8, #0x8]
1000005e8:     	add	w9, w9, w0
1000005ec:     	add	w0, w9, w0
1000005f0:     	str	w9, [x8, #0x8]
1000005f4:     	ret

00000001000005f8 <_main>:
1000005f8:     	cmp	w0, #0x3
1000005fc:     	b.ne	0x1000006f8 <_main+0x100>
100000600:     	sub	sp, sp, #0xa0
100000604:     	stp	x26, x25, [sp, #0x50]
100000608:     	stp	x24, x23, [sp, #0x60]
10000060c:     	stp	x22, x21, [sp, #0x70]
100000610:     	stp	x20, x19, [sp, #0x80]
100000614:     	stp	x29, x30, [sp, #0x90]
100000618:     	add	x29, sp, #0x90
10000061c:     	ldr	x0, [x1, #0x8]
100000620:     	mov	x20, x1
100000624:     	mov	x1, #0x0                ; =0
100000628:     	mov	w2, #0xa                ; =10
10000062c:     	bl	0x100000790 <_strtoul+0x100000790>
100000630:     	mov	x19, x0
100000634:     	ldr	x0, [x20, #0x10]
100000638:     	mov	x1, #0x0                ; =0
10000063c:     	mov	w2, #0xa                ; =10
100000640:     	bl	0x100000790 <_strtoul+0x100000790>
100000644:     	mov	x20, x0
100000648:     	add	x1, sp, #0x40
10000064c:     	mov	w0, #0x6                ; =6
100000650:     	bl	0x100000778 <_strtoul+0x100000778>
100000654:     	cbnz	w0, 0x1000006d8 <_main+0xe0>
100000658:     	cbz	x19, 0x100000700 <_main+0x108>
10000065c:     	mov	x23, #0x0               ; =0
100000660:     	mov	w22, #0x0               ; =0
100000664:     	mov	w24, #-0x1              ; =-1
100000668:     	mov	x25, #-0x3333333333333334 ; =-3689348814741910324
10000066c:     	movk	x25, #0xcccd
100000670:     	mov	w26, #0xa               ; =10
100000674:     	adrp	x21, 0x100008000 <__MergedGlobals>
100000678:     	add	x21, x21, #0x4
10000067c:     	umulh	x8, x23, x25
100000680:     	lsr	x8, x8, #3
100000684:     	msub	w2, w8, w26, w24
100000688:     	eor	w8, w20, w20, lsl #13
10000068c:     	eor	w8, w8, w8, lsr #17
100000690:     	eor	w20, w8, w8, lsl #5
100000694:     	mov	x0, x21
100000698:     	mov	x1, x20
10000069c:     	bl	0x1000004f8 <_region_pipeline>
1000006a0:     	add	w22, w0, w22
1000006a4:     	mov	x0, x21
1000006a8:     	mov	x1, x20
1000006ac:     	mov	x2, x22
1000006b0:     	bl	0x100000570 <_region_outputs>
1000006b4:     	add	w22, w22, w0
1000006b8:     	add	x23, x23, #0x1
1000006bc:     	add	w24, w24, #0x1
1000006c0:     	subs	x19, x19, #0x1
1000006c4:     	b.ne	0x10000067c <_main+0x84>
1000006c8:     	add	x1, sp, #0x30
1000006cc:     	mov	w0, #0x6                ; =6
1000006d0:     	bl	0x100000778 <_strtoul+0x100000778>
1000006d4:     	cbz	w0, 0x100000714 <_main+0x11c>
1000006d8:     	mov	w0, #0x2                ; =2
1000006dc:     	ldp	x29, x30, [sp, #0x90]
1000006e0:     	ldp	x20, x19, [sp, #0x80]
1000006e4:     	ldp	x22, x21, [sp, #0x70]
1000006e8:     	ldp	x24, x23, [sp, #0x60]
1000006ec:     	ldp	x26, x25, [sp, #0x50]
1000006f0:     	add	sp, sp, #0xa0
1000006f4:     	ret
1000006f8:     	mov	w0, #0x2                ; =2
1000006fc:     	ret
100000700:     	mov	w22, #0x0               ; =0
100000704:     	add	x1, sp, #0x30
100000708:     	mov	w0, #0x6                ; =6
10000070c:     	bl	0x100000778 <_strtoul+0x100000778>
100000710:     	cbnz	w0, 0x1000006d8 <_main+0xe0>
100000714:     	ldp	x8, x9, [sp, #0x30]
100000718:     	ldp	x10, x11, [sp, #0x40]
10000071c:     	sub	x8, x8, x10
100000720:     	scvtf	d0, x8
100000724:     	sub	x8, x9, x11
100000728:     	scvtf	d1, x8
10000072c:     	mov	x8, #0xd695             ; =54933
100000730:     	movk	x8, #0xe826, lsl #16
100000734:     	movk	x8, #0x2e0b, lsl #32
100000738:     	movk	x8, #0x3e11, lsl #48
10000073c:     	fmov	d2, x8
100000740:     	fmadd	d0, d1, d2, d0
100000744:     	adrp	x8, 0x100008000 <__MergedGlobals>
100000748:     	add	x8, x8, #0x0
10000074c:     	ldp	w9, w10, [x8, #0x8]
100000750:     	ldp	w8, w11, [x8]
100000754:     	stp	x10, x8, [sp, #0x20]
100000758:     	stp	x11, x9, [sp, #0x10]
10000075c:     	str	x22, [sp, #0x8]
100000760:     	str	d0, [sp]
100000764:     	adrp	x0, 0x100000000 <_strtoul+0x100000000>
100000768:     	add	x0, x0, #0x79c
10000076c:     	bl	0x100000784 <_strtoul+0x100000784>
100000770:     	mov	w0, #0x0                ; =0
100000774:     	b	0x1000006dc <_main+0xe4>

Disassembly of section __TEXT,__stubs:

0000000100000778 <__stubs>:
100000778:     	adrp	x16, 0x100004000 <_strtoul+0x100004000>
10000077c:     	ldr	x16, [x16]
100000780:     	br	x16
100000784:     	adrp	x16, 0x100004000 <_strtoul+0x100004000>
100000788:     	ldr	x16, [x16, #0x8]
10000078c:     	br	x16
100000790:     	adrp	x16, 0x100004000 <_strtoul+0x100004000>
100000794:     	ldr	x16, [x16, #0x10]
100000798:     	br	x16
