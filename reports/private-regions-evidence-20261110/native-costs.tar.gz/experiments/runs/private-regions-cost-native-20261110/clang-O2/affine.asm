
/Users/admin/C-SRD/experiments/runs/private-regions-cost-native-20261110/clang-O2/affine:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001000004f8 <_region_pipeline>:
1000004f8:     	stp	x22, x21, [sp, #-0x30]!
1000004fc:     	stp	x20, x19, [sp, #0x10]
100000500:     	stp	x29, x30, [sp, #0x20]
100000504:     	add	x29, sp, #0x20
100000508:     	mov	x21, x2
10000050c:     	mov	x19, x0
100000510:     	ldr	w8, [x0]
100000514:     	add	w8, w8, w1
100000518:     	add	w8, w8, w8, lsl #1
10000051c:     	add	w20, w8, #0xb
100000520:     	mov	x0, x20
100000524:     	bl	0x1000005fc <_record_event>
100000528:     	cmp	w21, #0x1
10000052c:     	b.lt	0x10000055c <_region_pipeline+0x64>
100000530:     	add	w21, w21, #0x1
100000534:     	mov	x0, x20
100000538:     	bl	0x100000614 <_next_value>
10000053c:     	add	w8, w0, w20
100000540:     	add	w8, w8, w8, lsl #2
100000544:     	sub	w20, w8, #0x7
100000548:     	str	w20, [x19]
10000054c:     	bl	0x1000005fc <_record_event>
100000550:     	sub	w21, w21, #0x1
100000554:     	cmp	w21, #0x1
100000558:     	b.hi	0x100000534 <_region_pipeline+0x3c>
10000055c:     	mov	x0, x20
100000560:     	ldp	x29, x30, [sp, #0x20]
100000564:     	ldp	x20, x19, [sp, #0x10]
100000568:     	ldp	x22, x21, [sp], #0x30
10000056c:     	ret

0000000100000570 <_region_outputs>:
100000570:     	stp	x22, x21, [sp, #-0x30]!
100000574:     	stp	x20, x19, [sp, #0x10]
100000578:     	stp	x29, x30, [sp, #0x20]
10000057c:     	add	x29, sp, #0x20
100000580:     	mov	x19, x0
100000584:     	mov	w8, #0x19ff             ; =6655
100000588:     	movk	w8, #0x8d3e, lsl #16
10000058c:     	mov	w9, #0xe601             ; =58881
100000590:     	movk	w9, #0x72c1, lsl #16
100000594:     	mul	w9, w2, w9
100000598:     	mov	w10, #0xb203            ; =45571
10000059c:     	movk	w10, #0x5845, lsl #16
1000005a0:     	madd	w9, w1, w10, w9
1000005a4:     	madd	w8, w1, w8, w9
1000005a8:     	mov	w10, #0x1a01            ; =6657
1000005ac:     	movk	w10, #0xcfe2, lsl #16
1000005b0:     	mov	w11, #0x286             ; =646
1000005b4:     	movk	w11, #0x2d, lsl #16
1000005b8:     	mul	w11, w11, w10
1000005bc:     	madd	w8, w8, w10, w11
1000005c0:     	add	w21, w1, #0x11
1000005c4:     	mov	w11, #0x33              ; =51
1000005c8:     	madd	w20, w9, w10, w11
1000005cc:     	mov	w9, #0x899c             ; =35228
1000005d0:     	movk	w9, #0x3d93, lsl #16
1000005d4:     	madd	w22, w9, w10, w8
1000005d8:     	mov	x0, x20
1000005dc:     	bl	0x1000005fc <_record_event>
1000005e0:     	stp	w22, w21, [x19]
1000005e4:     	cmp	w20, w22
1000005e8:     	cset	w0, eq
1000005ec:     	ldp	x29, x30, [sp, #0x20]
1000005f0:     	ldp	x20, x19, [sp, #0x10]
1000005f4:     	ldp	x22, x21, [sp], #0x30
1000005f8:     	ret

00000001000005fc <_record_event>:
1000005fc:     	adrp	x8, 0x100008000 <_event_hash>
100000600:     	ldr	w9, [x8]
100000604:     	add	w9, w9, w9, lsl #5
100000608:     	eor	w9, w9, w0
10000060c:     	str	w9, [x8]
100000610:     	ret

0000000100000614 <_next_value>:
100000614:     	adrp	x8, 0x100008000 <_event_hash>
100000618:     	ldr	w9, [x8]
10000061c:     	add	w9, w9, w9, lsl #5
100000620:     	eor	w9, w9, w0
100000624:     	str	w9, [x8]
100000628:     	adrp	x8, 0x100008000 <_event_hash>
10000062c:     	ldr	w9, [x8, #0x8]
100000630:     	add	w9, w9, w0
100000634:     	add	w0, w9, w0
100000638:     	str	w9, [x8, #0x8]
10000063c:     	ret

0000000100000640 <_main>:
100000640:     	cmp	w0, #0x3
100000644:     	b.ne	0x100000714 <_main+0xd4>
100000648:     	sub	sp, sp, #0xa0
10000064c:     	stp	x26, x25, [sp, #0x50]
100000650:     	stp	x24, x23, [sp, #0x60]
100000654:     	stp	x22, x21, [sp, #0x70]
100000658:     	stp	x20, x19, [sp, #0x80]
10000065c:     	stp	x29, x30, [sp, #0x90]
100000660:     	add	x29, sp, #0x90
100000664:     	ldr	x0, [x1, #0x8]
100000668:     	mov	x20, x1
10000066c:     	mov	x1, #0x0                ; =0
100000670:     	mov	w2, #0xa                ; =10
100000674:     	bl	0x1000007d4 <_strtoul+0x1000007d4>
100000678:     	mov	x19, x0
10000067c:     	ldr	x0, [x20, #0x10]
100000680:     	mov	x1, #0x0                ; =0
100000684:     	mov	w2, #0xa                ; =10
100000688:     	bl	0x1000007d4 <_strtoul+0x1000007d4>
10000068c:     	mov	x20, x0
100000690:     	add	x1, sp, #0x40
100000694:     	mov	w0, #0x6                ; =6
100000698:     	bl	0x1000007bc <_strtoul+0x1000007bc>
10000069c:     	cbnz	w0, 0x100000730 <_main+0xf0>
1000006a0:     	cbz	x19, 0x10000071c <_main+0xdc>
1000006a4:     	mov	x23, #0x0               ; =0
1000006a8:     	mov	w22, #0x0               ; =0
1000006ac:     	mov	w24, #-0x1              ; =-1
1000006b0:     	mov	x25, #-0x3333333333333334 ; =-3689348814741910324
1000006b4:     	movk	x25, #0xcccd
1000006b8:     	mov	w26, #0xa               ; =10
1000006bc:     	adrp	x21, 0x100008000 <_event_hash>
1000006c0:     	add	x21, x21, #0x4
1000006c4:     	umulh	x8, x23, x25
1000006c8:     	lsr	x8, x8, #3
1000006cc:     	msub	w2, w8, w26, w24
1000006d0:     	eor	w8, w20, w20, lsl #13
1000006d4:     	eor	w8, w8, w8, lsr #17
1000006d8:     	eor	w20, w8, w8, lsl #5
1000006dc:     	mov	x0, x21
1000006e0:     	mov	x1, x20
1000006e4:     	bl	0x1000004f8 <_region_pipeline>
1000006e8:     	add	w22, w0, w22
1000006ec:     	mov	x0, x21
1000006f0:     	mov	x1, x20
1000006f4:     	mov	x2, x22
1000006f8:     	bl	0x100000570 <_region_outputs>
1000006fc:     	add	w22, w22, w0
100000700:     	add	x23, x23, #0x1
100000704:     	add	w24, w24, #0x1
100000708:     	subs	x19, x19, #0x1
10000070c:     	b.ne	0x1000006c4 <_main+0x84>
100000710:     	b	0x100000720 <_main+0xe0>
100000714:     	mov	w0, #0x2                ; =2
100000718:     	ret
10000071c:     	mov	w22, #0x0               ; =0
100000720:     	add	x1, sp, #0x30
100000724:     	mov	w0, #0x6                ; =6
100000728:     	bl	0x1000007bc <_strtoul+0x1000007bc>
10000072c:     	cbz	w0, 0x100000750 <_main+0x110>
100000730:     	mov	w0, #0x2                ; =2
100000734:     	ldp	x29, x30, [sp, #0x90]
100000738:     	ldp	x20, x19, [sp, #0x80]
10000073c:     	ldp	x22, x21, [sp, #0x70]
100000740:     	ldp	x24, x23, [sp, #0x60]
100000744:     	ldp	x26, x25, [sp, #0x50]
100000748:     	add	sp, sp, #0xa0
10000074c:     	ret
100000750:     	ldp	x8, x9, [sp, #0x30]
100000754:     	ldp	x10, x11, [sp, #0x40]
100000758:     	sub	x8, x8, x10
10000075c:     	adrp	x10, 0x100008000 <_event_hash>
100000760:     	add	x10, x10, #0x4
100000764:     	scvtf	d0, x8
100000768:     	sub	x8, x9, x11
10000076c:     	scvtf	d1, x8
100000770:     	mov	x8, #0xd695             ; =54933
100000774:     	movk	x8, #0xe826, lsl #16
100000778:     	movk	x8, #0x2e0b, lsl #32
10000077c:     	movk	x8, #0x3e11, lsl #48
100000780:     	fmov	d2, x8
100000784:     	fmadd	d0, d1, d2, d0
100000788:     	ldp	w8, w9, [x10]
10000078c:     	ldr	w10, [x10, #0x8]
100000790:     	adrp	x11, 0x100008000 <_event_hash>
100000794:     	ldr	w11, [x11]
100000798:     	stp	x10, x11, [sp, #0x20]
10000079c:     	stp	x8, x9, [sp, #0x10]
1000007a0:     	str	x22, [sp, #0x8]
1000007a4:     	str	d0, [sp]
1000007a8:     	adrp	x0, 0x100000000 <_strtoul+0x100000000>
1000007ac:     	add	x0, x0, #0x7e0
1000007b0:     	bl	0x1000007c8 <_strtoul+0x1000007c8>
1000007b4:     	mov	w0, #0x0                ; =0
1000007b8:     	b	0x100000734 <_main+0xf4>

Disassembly of section __TEXT,__stubs:

00000001000007bc <__stubs>:
1000007bc:     	adrp	x16, 0x100004000 <_strtoul+0x100004000>
1000007c0:     	ldr	x16, [x16]
1000007c4:     	br	x16
1000007c8:     	adrp	x16, 0x100004000 <_strtoul+0x100004000>
1000007cc:     	ldr	x16, [x16, #0x8]
1000007d0:     	br	x16
1000007d4:     	adrp	x16, 0x100004000 <_strtoul+0x100004000>
1000007d8:     	ldr	x16, [x16, #0x10]
1000007dc:     	br	x16
