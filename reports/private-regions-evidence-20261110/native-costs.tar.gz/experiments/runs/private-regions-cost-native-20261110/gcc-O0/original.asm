
/Users/admin/C-SRD/experiments/runs/private-regions-cost-native-20261110/gcc-O0/original:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000100000648 <_region_pipeline>:
100000648:     	stp	x29, x30, [sp, #-0x30]!
10000064c:     	mov	x29, sp
100000650:     	str	x0, [x29, #0x18]
100000654:     	str	w1, [x29, #0x14]
100000658:     	str	w2, [x29, #0x10]
10000065c:     	ldr	x0, [x29, #0x18]
100000660:     	ldr	w0, [x0]
100000664:     	str	w0, [x29, #0x2c]
100000668:     	ldr	w1, [x29, #0x14]
10000066c:     	ldr	w0, [x29, #0x2c]
100000670:     	add	w0, w1, w0
100000674:     	str	w0, [x29, #0x14]
100000678:     	ldr	w1, [x29, #0x14]
10000067c:     	mov	w0, w1
100000680:     	lsl	w0, w0, #1
100000684:     	add	w0, w0, w1
100000688:     	add	w0, w0, #0xb
10000068c:     	str	w0, [x29, #0x14]
100000690:     	ldr	w0, [x29, #0x14]
100000694:     	bl	0x1000007ac <_record_event>
100000698:     	ldr	w0, [x29, #0x10]
10000069c:     	cmp	w0, #0x0
1000006a0:     	b.ge	0x1000006f4 <_region_pipeline+0xac>
1000006a4:     	ldr	w0, [x29, #0x14]
1000006a8:     	b	0x10000070c <_region_pipeline+0xc4>
1000006ac:     	ldr	w0, [x29, #0x14]
1000006b0:     	bl	0x1000007ec <_next_value>
1000006b4:     	str	w0, [x29, #0x2c]
1000006b8:     	ldr	w1, [x29, #0x14]
1000006bc:     	ldr	w0, [x29, #0x2c]
1000006c0:     	add	w0, w1, w0
1000006c4:     	str	w0, [x29, #0x14]
1000006c8:     	ldr	w1, [x29, #0x14]
1000006cc:     	mov	w0, w1
1000006d0:     	lsl	w0, w0, #2
1000006d4:     	add	w0, w0, w1
1000006d8:     	sub	w0, w0, #0x7
1000006dc:     	str	w0, [x29, #0x14]
1000006e0:     	ldr	x0, [x29, #0x18]
1000006e4:     	ldr	w1, [x29, #0x14]
1000006e8:     	str	w1, [x0]
1000006ec:     	ldr	w0, [x29, #0x2c]
1000006f0:     	bl	0x1000007ac <_record_event>
1000006f4:     	ldr	w0, [x29, #0x10]
1000006f8:     	sub	w1, w0, #0x1
1000006fc:     	str	w1, [x29, #0x10]
100000700:     	cmp	w0, #0x0
100000704:     	b.gt	0x1000006ac <_region_pipeline+0x64>
100000708:     	ldr	w0, [x29, #0x14]
10000070c:     	ldp	x29, x30, [sp], #0x30
100000710:     	ret

0000000100000714 <_region_outputs>:
100000714:     	stp	x29, x30, [sp, #-0x30]!
100000718:     	mov	x29, sp
10000071c:     	str	x0, [x29, #0x18]
100000720:     	str	w1, [x29, #0x14]
100000724:     	str	w2, [x29, #0x10]
100000728:     	mov	w0, #0x11               ; =17
10000072c:     	str	w0, [x29, #0x2c]
100000730:     	ldr	w1, [x29, #0x2c]
100000734:     	ldr	w0, [x29, #0x14]
100000738:     	add	w0, w1, w0
10000073c:     	str	w0, [x29, #0x2c]
100000740:     	ldr	w1, [x29, #0x2c]
100000744:     	mov	w0, w1
100000748:     	lsl	w0, w0, #1
10000074c:     	add	w0, w0, w1
100000750:     	ldr	w1, [x29, #0x10]
100000754:     	add	w0, w1, w0
100000758:     	str	w0, [x29, #0x14]
10000075c:     	ldr	w1, [x29, #0x14]
100000760:     	ldr	w0, [x29, #0x2c]
100000764:     	sub	w0, w1, w0
100000768:     	str	w0, [x29, #0x10]
10000076c:     	ldr	w0, [x29, #0x14]
100000770:     	bl	0x1000007ac <_record_event>
100000774:     	ldr	x0, [x29, #0x18]
100000778:     	ldr	w1, [x29, #0x10]
10000077c:     	str	w1, [x0]
100000780:     	ldr	x0, [x29, #0x18]
100000784:     	add	x0, x0, #0x4
100000788:     	ldr	w1, [x29, #0x2c]
10000078c:     	str	w1, [x0]
100000790:     	ldr	w1, [x29, #0x14]
100000794:     	ldr	w0, [x29, #0x10]
100000798:     	cmp	w1, w0
10000079c:     	cset	w0, eq
1000007a0:     	and	w0, w0, #0xff
1000007a4:     	ldp	x29, x30, [sp], #0x30
1000007a8:     	ret

00000001000007ac <_record_event>:
1000007ac:     	sub	sp, sp, #0x10
1000007b0:     	str	w0, [sp, #0xc]
1000007b4:     	adrp	x0, 0x100008000 <_memory>
1000007b8:     	add	x0, x0, #0xc
1000007bc:     	ldr	w1, [x0]
1000007c0:     	mov	w0, w1
1000007c4:     	lsl	w0, w0, #5
1000007c8:     	add	w1, w0, w1
1000007cc:     	ldr	w0, [sp, #0xc]
1000007d0:     	eor	w1, w1, w0
1000007d4:     	adrp	x0, 0x100008000 <_memory>
1000007d8:     	add	x0, x0, #0xc
1000007dc:     	str	w1, [x0]
1000007e0:     	nop
1000007e4:     	add	sp, sp, #0x10
1000007e8:     	ret

00000001000007ec <_next_value>:
1000007ec:     	stp	x29, x30, [sp, #-0x20]!
1000007f0:     	mov	x29, sp
1000007f4:     	str	w0, [x29, #0x1c]
1000007f8:     	ldr	w0, [x29, #0x1c]
1000007fc:     	bl	0x1000007ac <_record_event>
100000800:     	adrp	x0, 0x100008000 <_memory>
100000804:     	add	x0, x0, #0x0
100000808:     	ldr	w1, [x0, #0x4]
10000080c:     	ldr	w0, [x29, #0x1c]
100000810:     	add	w1, w1, w0
100000814:     	adrp	x0, 0x100008000 <_memory>
100000818:     	add	x0, x0, #0x0
10000081c:     	str	w1, [x0, #0x4]
100000820:     	adrp	x0, 0x100008000 <_memory>
100000824:     	add	x0, x0, #0x0
100000828:     	ldr	w1, [x0, #0x4]
10000082c:     	ldr	w0, [x29, #0x1c]
100000830:     	add	w0, w1, w0
100000834:     	ldp	x29, x30, [sp], #0x20
100000838:     	ret

000000010000083c <_main>:
10000083c:     	sub	sp, sp, #0x90
100000840:     	stp	x29, x30, [sp, #0x30]
100000844:     	add	x29, sp, #0x30
100000848:     	str	w0, [x29, #0x1c]
10000084c:     	str	x1, [x29, #0x10]
100000850:     	ldr	w0, [x29, #0x1c]
100000854:     	cmp	w0, #0x3
100000858:     	b.eq	0x100000864 <_main+0x28>
10000085c:     	mov	w0, #0x2                ; =2
100000860:     	b	0x100000a58 <_main+0x21c>
100000864:     	ldr	x0, [x29, #0x10]
100000868:     	add	x0, x0, #0x8
10000086c:     	ldr	x0, [x0]
100000870:     	mov	w2, #0xa                ; =10
100000874:     	mov	x1, #0x0                ; =0
100000878:     	bl	0x100000a7c <_strtoul+0x100000a7c>
10000087c:     	str	x0, [x29, #0x48]
100000880:     	ldr	x0, [x29, #0x10]
100000884:     	add	x0, x0, #0x10
100000888:     	ldr	x0, [x0]
10000088c:     	mov	w2, #0xa                ; =10
100000890:     	mov	x1, #0x0                ; =0
100000894:     	bl	0x100000a7c <_strtoul+0x100000a7c>
100000898:     	str	w0, [x29, #0x5c]
10000089c:     	str	wzr, [x29, #0x58]
1000008a0:     	add	x0, x29, #0x30
1000008a4:     	mov	x1, x0
1000008a8:     	mov	w0, #0x6                ; =6
1000008ac:     	bl	0x100000a64 <_strtoul+0x100000a64>
1000008b0:     	cmp	w0, #0x0
1000008b4:     	b.eq	0x1000008c0 <_main+0x84>
1000008b8:     	mov	w0, #0x2                ; =2
1000008bc:     	b	0x100000a58 <_main+0x21c>
1000008c0:     	str	xzr, [x29, #0x50]
1000008c4:     	b	0x100000988 <_main+0x14c>
1000008c8:     	ldr	w0, [x29, #0x5c]
1000008cc:     	lsl	w0, w0, #13
1000008d0:     	ldr	w1, [x29, #0x5c]
1000008d4:     	eor	w0, w1, w0
1000008d8:     	str	w0, [x29, #0x5c]
1000008dc:     	ldr	w0, [x29, #0x5c]
1000008e0:     	lsr	w0, w0, #17
1000008e4:     	ldr	w1, [x29, #0x5c]
1000008e8:     	eor	w0, w1, w0
1000008ec:     	str	w0, [x29, #0x5c]
1000008f0:     	ldr	w0, [x29, #0x5c]
1000008f4:     	lsl	w0, w0, #5
1000008f8:     	ldr	w1, [x29, #0x5c]
1000008fc:     	eor	w0, w1, w0
100000900:     	str	w0, [x29, #0x5c]
100000904:     	ldr	x2, [x29, #0x50]
100000908:     	mov	x0, #-0x3333333333333334 ; =-3689348814741910324
10000090c:     	movk	x0, #0xcccd
100000910:     	umulh	x0, x2, x0
100000914:     	lsr	x1, x0, #3
100000918:     	mov	x0, x1
10000091c:     	lsl	x0, x0, #2
100000920:     	add	x0, x0, x1
100000924:     	lsl	x0, x0, #1
100000928:     	sub	x1, x2, x0
10000092c:     	mov	w0, w1
100000930:     	sub	w0, w0, #0x1
100000934:     	mov	w2, w0
100000938:     	ldr	w1, [x29, #0x5c]
10000093c:     	adrp	x0, 0x100008000 <_memory>
100000940:     	add	x0, x0, #0x0
100000944:     	bl	0x100000648 <_region_pipeline>
100000948:     	mov	w1, w0
10000094c:     	ldr	w0, [x29, #0x58]
100000950:     	add	w0, w0, w1
100000954:     	str	w0, [x29, #0x58]
100000958:     	ldr	w2, [x29, #0x58]
10000095c:     	ldr	w1, [x29, #0x5c]
100000960:     	adrp	x0, 0x100008000 <_memory>
100000964:     	add	x0, x0, #0x0
100000968:     	bl	0x100000714 <_region_outputs>
10000096c:     	mov	w1, w0
100000970:     	ldr	w0, [x29, #0x58]
100000974:     	add	w0, w0, w1
100000978:     	str	w0, [x29, #0x58]
10000097c:     	ldr	x0, [x29, #0x50]
100000980:     	add	x0, x0, #0x1
100000984:     	str	x0, [x29, #0x50]
100000988:     	ldr	x1, [x29, #0x50]
10000098c:     	ldr	x0, [x29, #0x48]
100000990:     	cmp	x1, x0
100000994:     	b.lo	0x1000008c8 <_main+0x8c>
100000998:     	add	x0, x29, #0x20
10000099c:     	mov	x1, x0
1000009a0:     	mov	w0, #0x6                ; =6
1000009a4:     	bl	0x100000a64 <_strtoul+0x100000a64>
1000009a8:     	cmp	w0, #0x0
1000009ac:     	b.eq	0x1000009b8 <_main+0x17c>
1000009b0:     	mov	w0, #0x2                ; =2
1000009b4:     	b	0x100000a58 <_main+0x21c>
1000009b8:     	ldr	x1, [x29, #0x20]
1000009bc:     	ldr	x0, [x29, #0x30]
1000009c0:     	sub	x0, x1, x0
1000009c4:     	fmov	d31, x0
1000009c8:     	scvtf	d30, d31
1000009cc:     	ldr	x1, [x29, #0x28]
1000009d0:     	ldr	x0, [x29, #0x38]
1000009d4:     	sub	x0, x1, x0
1000009d8:     	fmov	d31, x0
1000009dc:     	scvtf	d29, d31
1000009e0:     	adrp	x0, 0x100000000 <_strtoul+0x100000000>
1000009e4:     	add	x0, x0, #0xaa0
1000009e8:     	ldr	d31, [x0]
1000009ec:     	fmul	d31, d29, d31
1000009f0:     	fadd	d31, d30, d31
1000009f4:     	str	d31, [x29, #0x40]
1000009f8:     	adrp	x0, 0x100008000 <_memory>
1000009fc:     	add	x0, x0, #0x0
100000a00:     	ldr	w1, [x0]
100000a04:     	adrp	x0, 0x100008000 <_memory>
100000a08:     	add	x0, x0, #0x0
100000a0c:     	ldr	w2, [x0, #0x4]
100000a10:     	adrp	x0, 0x100008000 <_memory>
100000a14:     	add	x0, x0, #0x0
100000a18:     	ldr	w3, [x0, #0x8]
100000a1c:     	adrp	x0, 0x100008000 <_memory>
100000a20:     	add	x0, x0, #0xc
100000a24:     	ldr	w0, [x0]
100000a28:     	str	w0, [sp, #0x28]
100000a2c:     	str	w3, [sp, #0x20]
100000a30:     	str	w2, [sp, #0x18]
100000a34:     	str	w1, [sp, #0x10]
100000a38:     	ldr	w0, [x29, #0x58]
100000a3c:     	str	w0, [sp, #0x8]
100000a40:     	ldr	d31, [x29, #0x40]
100000a44:     	str	d31, [sp]
100000a48:     	adrp	x0, 0x100000000 <_strtoul+0x100000000>
100000a4c:     	add	x0, x0, #0xa88
100000a50:     	bl	0x100000a70 <_strtoul+0x100000a70>
100000a54:     	mov	w0, #0x0                ; =0
100000a58:     	ldp	x29, x30, [sp, #0x30]
100000a5c:     	add	sp, sp, #0x90
100000a60:     	ret

Disassembly of section __TEXT,__stubs:

0000000100000a64 <__stubs>:
100000a64:     	adrp	x16, 0x100004000 <_strtoul+0x100004000>
100000a68:     	ldr	x16, [x16]
100000a6c:     	br	x16
100000a70:     	adrp	x16, 0x100004000 <_strtoul+0x100004000>
100000a74:     	ldr	x16, [x16, #0x8]
100000a78:     	br	x16
100000a7c:     	adrp	x16, 0x100004000 <_strtoul+0x100004000>
100000a80:     	ldr	x16, [x16, #0x10]
100000a84:     	br	x16
