
/Users/admin/C-SRD/experiments/runs/private-regions-cost-native-20261110/gcc-O0/affine:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000100000648 <_region_pipeline>:
100000648:     	stp	x29, x30, [sp, #-0x40]!
10000064c:     	mov	x29, sp
100000650:     	str	x0, [x29, #0x18]
100000654:     	str	w1, [x29, #0x14]
100000658:     	str	w2, [x29, #0x10]
10000065c:     	ldr	x0, [x29, #0x18]
100000660:     	ldr	w0, [x0]
100000664:     	str	w0, [x29, #0x3c]
100000668:     	ldr	w1, [x29, #0x14]
10000066c:     	mov	w0, #0xc255             ; =49749
100000670:     	movk	w0, #0xf13, lsl #16
100000674:     	mul	w1, w1, w0
100000678:     	mov	w0, #0x8950             ; =35152
10000067c:     	movk	w0, #0xf66f, lsl #16
100000680:     	add	w0, w1, w0
100000684:     	str	w0, [x29, #0x38]
100000688:     	ldr	w1, [x29, #0x3c]
10000068c:     	mov	w0, #0xc255             ; =49749
100000690:     	movk	w0, #0xf13, lsl #16
100000694:     	mul	w1, w1, w0
100000698:     	mov	w0, #0x8950             ; =35152
10000069c:     	movk	w0, #0xf66f, lsl #16
1000006a0:     	add	w0, w1, w0
1000006a4:     	str	w0, [x29, #0x34]
1000006a8:     	ldr	w1, [x29, #0x38]
1000006ac:     	ldr	w0, [x29, #0x34]
1000006b0:     	add	w1, w1, w0
1000006b4:     	mov	w0, #0x76b0             ; =30384
1000006b8:     	movk	w0, #0x990, lsl #16
1000006bc:     	add	w0, w1, w0
1000006c0:     	str	w0, [x29, #0x38]
1000006c4:     	ldr	w1, [x29, #0x38]
1000006c8:     	mov	w0, w1
1000006cc:     	lsl	w0, w0, #1
1000006d0:     	add	w1, w0, w1
1000006d4:     	mov	w0, #0x4707             ; =18183
1000006d8:     	movk	w0, #0xb8fa, lsl #16
1000006dc:     	add	w0, w1, w0
1000006e0:     	str	w0, [x29, #0x38]
1000006e4:     	ldr	w1, [x29, #0x38]
1000006e8:     	mov	w0, #0x2afd             ; =11005
1000006ec:     	movk	w0, #0xca3b, lsl #16
1000006f0:     	mul	w1, w1, w0
1000006f4:     	mov	w0, #0x2bf0             ; =11248
1000006f8:     	movk	w0, #0x61ce, lsl #16
1000006fc:     	add	w0, w1, w0
100000700:     	str	w0, [x29, #0x14]
100000704:     	ldr	w0, [x29, #0x14]
100000708:     	bl	0x10000095c <_record_event>
10000070c:     	ldr	w0, [x29, #0x10]
100000710:     	cmp	w0, #0x0
100000714:     	b.ge	0x1000007dc <_region_pipeline+0x194>
100000718:     	ldr	w0, [x29, #0x14]
10000071c:     	b	0x1000007f4 <_region_pipeline+0x1ac>
100000720:     	ldr	w0, [x29, #0x14]
100000724:     	bl	0x10000099c <_next_value>
100000728:     	str	w0, [x29, #0x3c]
10000072c:     	ldr	w1, [x29, #0x14]
100000730:     	mov	w0, #0x8b8d             ; =35725
100000734:     	movk	w0, #0xe209, lsl #16
100000738:     	mul	w1, w1, w0
10000073c:     	mov	w0, #0xb107             ; =45319
100000740:     	movk	w0, #0xaf29, lsl #16
100000744:     	add	w0, w1, w0
100000748:     	str	w0, [x29, #0x30]
10000074c:     	ldr	w1, [x29, #0x3c]
100000750:     	mov	w0, #0x8b8d             ; =35725
100000754:     	movk	w0, #0xe209, lsl #16
100000758:     	mul	w1, w1, w0
10000075c:     	mov	w0, #0xb107             ; =45319
100000760:     	movk	w0, #0xaf29, lsl #16
100000764:     	add	w0, w1, w0
100000768:     	str	w0, [x29, #0x2c]
10000076c:     	ldr	w1, [x29, #0x30]
100000770:     	ldr	w0, [x29, #0x2c]
100000774:     	add	w1, w1, w0
100000778:     	mov	w0, #0x4ef9             ; =20217
10000077c:     	movk	w0, #0x50d6, lsl #16
100000780:     	add	w0, w1, w0
100000784:     	str	w0, [x29, #0x30]
100000788:     	ldr	w1, [x29, #0x30]
10000078c:     	mov	w0, w1
100000790:     	lsl	w0, w0, #2
100000794:     	add	w1, w0, w1
100000798:     	mov	w0, #0x6b09             ; =27401
10000079c:     	movk	w0, #0x1516, lsl #16
1000007a0:     	add	w0, w1, w0
1000007a4:     	str	w0, [x29, #0x30]
1000007a8:     	ldr	w1, [x29, #0x30]
1000007ac:     	mov	w0, #0xaf45             ; =44869
1000007b0:     	movk	w0, #0x7b28, lsl #16
1000007b4:     	mul	w1, w1, w0
1000007b8:     	mov	w0, #0x801d             ; =32797
1000007bc:     	movk	w0, #0x43a7, lsl #16
1000007c0:     	add	w0, w1, w0
1000007c4:     	str	w0, [x29, #0x14]
1000007c8:     	ldr	x0, [x29, #0x18]
1000007cc:     	ldr	w1, [x29, #0x14]
1000007d0:     	str	w1, [x0]
1000007d4:     	ldr	w0, [x29, #0x3c]
1000007d8:     	bl	0x10000095c <_record_event>
1000007dc:     	ldr	w0, [x29, #0x10]
1000007e0:     	sub	w1, w0, #0x1
1000007e4:     	str	w1, [x29, #0x10]
1000007e8:     	cmp	w0, #0x0
1000007ec:     	b.gt	0x100000720 <_region_pipeline+0xd8>
1000007f0:     	ldr	w0, [x29, #0x14]
1000007f4:     	ldp	x29, x30, [sp], #0x40
1000007f8:     	ret

00000001000007fc <_region_outputs>:
1000007fc:     	stp	x29, x30, [sp, #-0x30]!
100000800:     	mov	x29, sp
100000804:     	str	x0, [x29, #0x18]
100000808:     	str	w1, [x29, #0x14]
10000080c:     	str	w2, [x29, #0x10]
100000810:     	ldr	w1, [x29, #0x14]
100000814:     	mov	w0, #0xf695             ; =63125
100000818:     	movk	w0, #0xf36a, lsl #16
10000081c:     	mul	w1, w1, w0
100000820:     	mov	w0, #0xca31             ; =51761
100000824:     	movk	w0, #0x6bbe, lsl #16
100000828:     	add	w0, w1, w0
10000082c:     	str	w0, [x29, #0x2c]
100000830:     	ldr	w1, [x29, #0x10]
100000834:     	mov	w0, #0xf695             ; =63125
100000838:     	movk	w0, #0xf36a, lsl #16
10000083c:     	mul	w1, w1, w0
100000840:     	mov	w0, #0xca31             ; =51761
100000844:     	movk	w0, #0x6bbe, lsl #16
100000848:     	add	w0, w1, w0
10000084c:     	str	w0, [x29, #0x28]
100000850:     	mov	w0, #0x2a16             ; =10774
100000854:     	movk	w0, #0x95d9, lsl #16
100000858:     	str	w0, [x29, #0x24]
10000085c:     	ldr	w1, [x29, #0x24]
100000860:     	ldr	w0, [x29, #0x2c]
100000864:     	add	w1, w1, w0
100000868:     	mov	w0, #0x35cf             ; =13775
10000086c:     	movk	w0, #0x9441, lsl #16
100000870:     	add	w0, w1, w0
100000874:     	str	w0, [x29, #0x24]
100000878:     	ldr	w1, [x29, #0x24]
10000087c:     	mov	w0, w1
100000880:     	lsl	w0, w0, #1
100000884:     	add	w1, w0, w1
100000888:     	ldr	w0, [x29, #0x28]
10000088c:     	add	w1, w1, w0
100000890:     	mov	w0, #0xa16d             ; =41325
100000894:     	movk	w0, #0xbcc3, lsl #16
100000898:     	add	w0, w1, w0
10000089c:     	str	w0, [x29, #0x2c]
1000008a0:     	ldr	w1, [x29, #0x2c]
1000008a4:     	ldr	w0, [x29, #0x24]
1000008a8:     	sub	w1, w1, w0
1000008ac:     	mov	w0, #0xca31             ; =51761
1000008b0:     	movk	w0, #0x6bbe, lsl #16
1000008b4:     	add	w0, w1, w0
1000008b8:     	str	w0, [x29, #0x28]
1000008bc:     	ldr	w1, [x29, #0x24]
1000008c0:     	mov	w0, #0x24bd             ; =9405
1000008c4:     	movk	w0, #0x922f, lsl #16
1000008c8:     	mul	w1, w1, w0
1000008cc:     	mov	w0, #0xd5d3             ; =54739
1000008d0:     	movk	w0, #0x8eb6, lsl #16
1000008d4:     	add	w0, w1, w0
1000008d8:     	str	w0, [x29, #0x20]
1000008dc:     	ldr	w1, [x29, #0x2c]
1000008e0:     	mov	w0, #0x24bd             ; =9405
1000008e4:     	movk	w0, #0x922f, lsl #16
1000008e8:     	mul	w1, w1, w0
1000008ec:     	mov	w0, #0xd5d3             ; =54739
1000008f0:     	movk	w0, #0x8eb6, lsl #16
1000008f4:     	add	w0, w1, w0
1000008f8:     	str	w0, [x29, #0x14]
1000008fc:     	ldr	w1, [x29, #0x28]
100000900:     	mov	w0, #0x24bd             ; =9405
100000904:     	movk	w0, #0x922f, lsl #16
100000908:     	mul	w1, w1, w0
10000090c:     	mov	w0, #0xd5d3             ; =54739
100000910:     	movk	w0, #0x8eb6, lsl #16
100000914:     	add	w0, w1, w0
100000918:     	str	w0, [x29, #0x10]
10000091c:     	ldr	w0, [x29, #0x14]
100000920:     	bl	0x10000095c <_record_event>
100000924:     	ldr	x0, [x29, #0x18]
100000928:     	ldr	w1, [x29, #0x10]
10000092c:     	str	w1, [x0]
100000930:     	ldr	x0, [x29, #0x18]
100000934:     	add	x0, x0, #0x4
100000938:     	ldr	w1, [x29, #0x20]
10000093c:     	str	w1, [x0]
100000940:     	ldr	w1, [x29, #0x14]
100000944:     	ldr	w0, [x29, #0x10]
100000948:     	cmp	w1, w0
10000094c:     	cset	w0, eq
100000950:     	and	w0, w0, #0xff
100000954:     	ldp	x29, x30, [sp], #0x30
100000958:     	ret

000000010000095c <_record_event>:
10000095c:     	sub	sp, sp, #0x10
100000960:     	str	w0, [sp, #0xc]
100000964:     	adrp	x0, 0x100008000 <_memory>
100000968:     	add	x0, x0, #0xc
10000096c:     	ldr	w1, [x0]
100000970:     	mov	w0, w1
100000974:     	lsl	w0, w0, #5
100000978:     	add	w1, w0, w1
10000097c:     	ldr	w0, [sp, #0xc]
100000980:     	eor	w1, w1, w0
100000984:     	adrp	x0, 0x100008000 <_memory>
100000988:     	add	x0, x0, #0xc
10000098c:     	str	w1, [x0]
100000990:     	nop
100000994:     	add	sp, sp, #0x10
100000998:     	ret

000000010000099c <_next_value>:
10000099c:     	stp	x29, x30, [sp, #-0x20]!
1000009a0:     	mov	x29, sp
1000009a4:     	str	w0, [x29, #0x1c]
1000009a8:     	ldr	w0, [x29, #0x1c]
1000009ac:     	bl	0x10000095c <_record_event>
1000009b0:     	adrp	x0, 0x100008000 <_memory>
1000009b4:     	add	x0, x0, #0x0
1000009b8:     	ldr	w1, [x0, #0x4]
1000009bc:     	ldr	w0, [x29, #0x1c]
1000009c0:     	add	w1, w1, w0
1000009c4:     	adrp	x0, 0x100008000 <_memory>
1000009c8:     	add	x0, x0, #0x0
1000009cc:     	str	w1, [x0, #0x4]
1000009d0:     	adrp	x0, 0x100008000 <_memory>
1000009d4:     	add	x0, x0, #0x0
1000009d8:     	ldr	w1, [x0, #0x4]
1000009dc:     	ldr	w0, [x29, #0x1c]
1000009e0:     	add	w0, w1, w0
1000009e4:     	ldp	x29, x30, [sp], #0x20
1000009e8:     	ret

00000001000009ec <_main>:
1000009ec:     	sub	sp, sp, #0x90
1000009f0:     	stp	x29, x30, [sp, #0x30]
1000009f4:     	add	x29, sp, #0x30
1000009f8:     	str	w0, [x29, #0x1c]
1000009fc:     	str	x1, [x29, #0x10]
100000a00:     	ldr	w0, [x29, #0x1c]
100000a04:     	cmp	w0, #0x3
100000a08:     	b.eq	0x100000a14 <_main+0x28>
100000a0c:     	mov	w0, #0x2                ; =2
100000a10:     	b	0x100000c08 <_main+0x21c>
100000a14:     	ldr	x0, [x29, #0x10]
100000a18:     	add	x0, x0, #0x8
100000a1c:     	ldr	x0, [x0]
100000a20:     	mov	w2, #0xa                ; =10
100000a24:     	mov	x1, #0x0                ; =0
100000a28:     	bl	0x100000c2c <_strtoul+0x100000c2c>
100000a2c:     	str	x0, [x29, #0x48]
100000a30:     	ldr	x0, [x29, #0x10]
100000a34:     	add	x0, x0, #0x10
100000a38:     	ldr	x0, [x0]
100000a3c:     	mov	w2, #0xa                ; =10
100000a40:     	mov	x1, #0x0                ; =0
100000a44:     	bl	0x100000c2c <_strtoul+0x100000c2c>
100000a48:     	str	w0, [x29, #0x5c]
100000a4c:     	str	wzr, [x29, #0x58]
100000a50:     	add	x0, x29, #0x30
100000a54:     	mov	x1, x0
100000a58:     	mov	w0, #0x6                ; =6
100000a5c:     	bl	0x100000c14 <_strtoul+0x100000c14>
100000a60:     	cmp	w0, #0x0
100000a64:     	b.eq	0x100000a70 <_main+0x84>
100000a68:     	mov	w0, #0x2                ; =2
100000a6c:     	b	0x100000c08 <_main+0x21c>
100000a70:     	str	xzr, [x29, #0x50]
100000a74:     	b	0x100000b38 <_main+0x14c>
100000a78:     	ldr	w0, [x29, #0x5c]
100000a7c:     	lsl	w0, w0, #13
100000a80:     	ldr	w1, [x29, #0x5c]
100000a84:     	eor	w0, w1, w0
100000a88:     	str	w0, [x29, #0x5c]
100000a8c:     	ldr	w0, [x29, #0x5c]
100000a90:     	lsr	w0, w0, #17
100000a94:     	ldr	w1, [x29, #0x5c]
100000a98:     	eor	w0, w1, w0
100000a9c:     	str	w0, [x29, #0x5c]
100000aa0:     	ldr	w0, [x29, #0x5c]
100000aa4:     	lsl	w0, w0, #5
100000aa8:     	ldr	w1, [x29, #0x5c]
100000aac:     	eor	w0, w1, w0
100000ab0:     	str	w0, [x29, #0x5c]
100000ab4:     	ldr	x2, [x29, #0x50]
100000ab8:     	mov	x0, #-0x3333333333333334 ; =-3689348814741910324
100000abc:     	movk	x0, #0xcccd
100000ac0:     	umulh	x0, x2, x0
100000ac4:     	lsr	x1, x0, #3
100000ac8:     	mov	x0, x1
100000acc:     	lsl	x0, x0, #2
100000ad0:     	add	x0, x0, x1
100000ad4:     	lsl	x0, x0, #1
100000ad8:     	sub	x1, x2, x0
100000adc:     	mov	w0, w1
100000ae0:     	sub	w0, w0, #0x1
100000ae4:     	mov	w2, w0
100000ae8:     	ldr	w1, [x29, #0x5c]
100000aec:     	adrp	x0, 0x100008000 <_memory>
100000af0:     	add	x0, x0, #0x0
100000af4:     	bl	0x100000648 <_region_pipeline>
100000af8:     	mov	w1, w0
100000afc:     	ldr	w0, [x29, #0x58]
100000b00:     	add	w0, w0, w1
100000b04:     	str	w0, [x29, #0x58]
100000b08:     	ldr	w2, [x29, #0x58]
100000b0c:     	ldr	w1, [x29, #0x5c]
100000b10:     	adrp	x0, 0x100008000 <_memory>
100000b14:     	add	x0, x0, #0x0
100000b18:     	bl	0x1000007fc <_region_outputs>
100000b1c:     	mov	w1, w0
100000b20:     	ldr	w0, [x29, #0x58]
100000b24:     	add	w0, w0, w1
100000b28:     	str	w0, [x29, #0x58]
100000b2c:     	ldr	x0, [x29, #0x50]
100000b30:     	add	x0, x0, #0x1
100000b34:     	str	x0, [x29, #0x50]
100000b38:     	ldr	x1, [x29, #0x50]
100000b3c:     	ldr	x0, [x29, #0x48]
100000b40:     	cmp	x1, x0
100000b44:     	b.lo	0x100000a78 <_main+0x8c>
100000b48:     	add	x0, x29, #0x20
100000b4c:     	mov	x1, x0
100000b50:     	mov	w0, #0x6                ; =6
100000b54:     	bl	0x100000c14 <_strtoul+0x100000c14>
100000b58:     	cmp	w0, #0x0
100000b5c:     	b.eq	0x100000b68 <_main+0x17c>
100000b60:     	mov	w0, #0x2                ; =2
100000b64:     	b	0x100000c08 <_main+0x21c>
100000b68:     	ldr	x1, [x29, #0x20]
100000b6c:     	ldr	x0, [x29, #0x30]
100000b70:     	sub	x0, x1, x0
100000b74:     	fmov	d31, x0
100000b78:     	scvtf	d30, d31
100000b7c:     	ldr	x1, [x29, #0x28]
100000b80:     	ldr	x0, [x29, #0x38]
100000b84:     	sub	x0, x1, x0
100000b88:     	fmov	d31, x0
100000b8c:     	scvtf	d29, d31
100000b90:     	adrp	x0, 0x100000000 <_strtoul+0x100000000>
100000b94:     	add	x0, x0, #0xc50
100000b98:     	ldr	d31, [x0]
100000b9c:     	fmul	d31, d29, d31
100000ba0:     	fadd	d31, d30, d31
100000ba4:     	str	d31, [x29, #0x40]
100000ba8:     	adrp	x0, 0x100008000 <_memory>
100000bac:     	add	x0, x0, #0x0
100000bb0:     	ldr	w1, [x0]
100000bb4:     	adrp	x0, 0x100008000 <_memory>
100000bb8:     	add	x0, x0, #0x0
100000bbc:     	ldr	w2, [x0, #0x4]
100000bc0:     	adrp	x0, 0x100008000 <_memory>
100000bc4:     	add	x0, x0, #0x0
100000bc8:     	ldr	w3, [x0, #0x8]
100000bcc:     	adrp	x0, 0x100008000 <_memory>
100000bd0:     	add	x0, x0, #0xc
100000bd4:     	ldr	w0, [x0]
100000bd8:     	str	w0, [sp, #0x28]
100000bdc:     	str	w3, [sp, #0x20]
100000be0:     	str	w2, [sp, #0x18]
100000be4:     	str	w1, [sp, #0x10]
100000be8:     	ldr	w0, [x29, #0x58]
100000bec:     	str	w0, [sp, #0x8]
100000bf0:     	ldr	d31, [x29, #0x40]
100000bf4:     	str	d31, [sp]
100000bf8:     	adrp	x0, 0x100000000 <_strtoul+0x100000000>
100000bfc:     	add	x0, x0, #0xc38
100000c00:     	bl	0x100000c20 <_strtoul+0x100000c20>
100000c04:     	mov	w0, #0x0                ; =0
100000c08:     	ldp	x29, x30, [sp, #0x30]
100000c0c:     	add	sp, sp, #0x90
100000c10:     	ret

Disassembly of section __TEXT,__stubs:

0000000100000c14 <__stubs>:
100000c14:     	adrp	x16, 0x100004000 <_strtoul+0x100004000>
100000c18:     	ldr	x16, [x16]
100000c1c:     	br	x16
100000c20:     	adrp	x16, 0x100004000 <_strtoul+0x100004000>
100000c24:     	ldr	x16, [x16, #0x8]
100000c28:     	br	x16
100000c2c:     	adrp	x16, 0x100004000 <_strtoul+0x100004000>
100000c30:     	ldr	x16, [x16, #0x10]
100000c34:     	br	x16
