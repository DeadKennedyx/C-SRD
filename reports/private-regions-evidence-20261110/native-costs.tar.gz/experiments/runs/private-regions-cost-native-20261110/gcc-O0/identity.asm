
/Users/admin/C-SRD/experiments/runs/private-regions-cost-native-20261110/gcc-O0/identity:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000100000648 <_region_pipeline>:
100000648:     	stp	x29, x30, [sp, #-0x40]!
10000064c:     	mov	x29, sp
100000650:     	str	x0, [x29, #0x18]
100000654:     	str	w1, [x29, #0x14]
100000658:     	str	w2, [x29, #0x10]
10000065c:     	ldr	x0, [x29, #0x18]
100000660:     	ldr	w0, [x0]
100000664:     	str	w0, [x29, #0x3c]
100000668:     	ldr	w0, [x29, #0x14]
10000066c:     	str	w0, [x29, #0x38]
100000670:     	ldr	w0, [x29, #0x3c]
100000674:     	str	w0, [x29, #0x34]
100000678:     	ldr	w1, [x29, #0x38]
10000067c:     	ldr	w0, [x29, #0x34]
100000680:     	add	w0, w1, w0
100000684:     	str	w0, [x29, #0x38]
100000688:     	ldr	w1, [x29, #0x38]
10000068c:     	mov	w0, w1
100000690:     	lsl	w0, w0, #1
100000694:     	add	w0, w0, w1
100000698:     	add	w0, w0, #0xb
10000069c:     	str	w0, [x29, #0x38]
1000006a0:     	ldr	w0, [x29, #0x38]
1000006a4:     	str	w0, [x29, #0x14]
1000006a8:     	ldr	w0, [x29, #0x14]
1000006ac:     	bl	0x100000804 <_record_event>
1000006b0:     	ldr	w0, [x29, #0x10]
1000006b4:     	cmp	w0, #0x0
1000006b8:     	b.ge	0x100000724 <_region_pipeline+0xdc>
1000006bc:     	ldr	w0, [x29, #0x14]
1000006c0:     	b	0x10000073c <_region_pipeline+0xf4>
1000006c4:     	ldr	w0, [x29, #0x14]
1000006c8:     	bl	0x100000844 <_next_value>
1000006cc:     	str	w0, [x29, #0x3c]
1000006d0:     	ldr	w0, [x29, #0x14]
1000006d4:     	str	w0, [x29, #0x30]
1000006d8:     	ldr	w0, [x29, #0x3c]
1000006dc:     	str	w0, [x29, #0x2c]
1000006e0:     	ldr	w1, [x29, #0x30]
1000006e4:     	ldr	w0, [x29, #0x2c]
1000006e8:     	add	w0, w1, w0
1000006ec:     	str	w0, [x29, #0x30]
1000006f0:     	ldr	w1, [x29, #0x30]
1000006f4:     	mov	w0, w1
1000006f8:     	lsl	w0, w0, #2
1000006fc:     	add	w0, w0, w1
100000700:     	sub	w0, w0, #0x7
100000704:     	str	w0, [x29, #0x30]
100000708:     	ldr	w0, [x29, #0x30]
10000070c:     	str	w0, [x29, #0x14]
100000710:     	ldr	x0, [x29, #0x18]
100000714:     	ldr	w1, [x29, #0x14]
100000718:     	str	w1, [x0]
10000071c:     	ldr	w0, [x29, #0x3c]
100000720:     	bl	0x100000804 <_record_event>
100000724:     	ldr	w0, [x29, #0x10]
100000728:     	sub	w1, w0, #0x1
10000072c:     	str	w1, [x29, #0x10]
100000730:     	cmp	w0, #0x0
100000734:     	b.gt	0x1000006c4 <_region_pipeline+0x7c>
100000738:     	ldr	w0, [x29, #0x14]
10000073c:     	ldp	x29, x30, [sp], #0x40
100000740:     	ret

0000000100000744 <_region_outputs>:
100000744:     	stp	x29, x30, [sp, #-0x30]!
100000748:     	mov	x29, sp
10000074c:     	str	x0, [x29, #0x18]
100000750:     	str	w1, [x29, #0x14]
100000754:     	str	w2, [x29, #0x10]
100000758:     	ldr	w0, [x29, #0x14]
10000075c:     	str	w0, [x29, #0x2c]
100000760:     	ldr	w0, [x29, #0x10]
100000764:     	str	w0, [x29, #0x28]
100000768:     	mov	w0, #0x11               ; =17
10000076c:     	str	w0, [x29, #0x24]
100000770:     	ldr	w1, [x29, #0x24]
100000774:     	ldr	w0, [x29, #0x2c]
100000778:     	add	w0, w1, w0
10000077c:     	str	w0, [x29, #0x24]
100000780:     	ldr	w1, [x29, #0x24]
100000784:     	mov	w0, w1
100000788:     	lsl	w0, w0, #1
10000078c:     	add	w0, w0, w1
100000790:     	ldr	w1, [x29, #0x28]
100000794:     	add	w0, w1, w0
100000798:     	str	w0, [x29, #0x2c]
10000079c:     	ldr	w1, [x29, #0x2c]
1000007a0:     	ldr	w0, [x29, #0x24]
1000007a4:     	sub	w0, w1, w0
1000007a8:     	str	w0, [x29, #0x28]
1000007ac:     	ldr	w0, [x29, #0x24]
1000007b0:     	str	w0, [x29, #0x20]
1000007b4:     	ldr	w0, [x29, #0x2c]
1000007b8:     	str	w0, [x29, #0x14]
1000007bc:     	ldr	w0, [x29, #0x28]
1000007c0:     	str	w0, [x29, #0x10]
1000007c4:     	ldr	w0, [x29, #0x14]
1000007c8:     	bl	0x100000804 <_record_event>
1000007cc:     	ldr	x0, [x29, #0x18]
1000007d0:     	ldr	w1, [x29, #0x10]
1000007d4:     	str	w1, [x0]
1000007d8:     	ldr	x0, [x29, #0x18]
1000007dc:     	add	x0, x0, #0x4
1000007e0:     	ldr	w1, [x29, #0x20]
1000007e4:     	str	w1, [x0]
1000007e8:     	ldr	w1, [x29, #0x14]
1000007ec:     	ldr	w0, [x29, #0x10]
1000007f0:     	cmp	w1, w0
1000007f4:     	cset	w0, eq
1000007f8:     	and	w0, w0, #0xff
1000007fc:     	ldp	x29, x30, [sp], #0x30
100000800:     	ret

0000000100000804 <_record_event>:
100000804:     	sub	sp, sp, #0x10
100000808:     	str	w0, [sp, #0xc]
10000080c:     	adrp	x0, 0x100008000 <_memory>
100000810:     	add	x0, x0, #0xc
100000814:     	ldr	w1, [x0]
100000818:     	mov	w0, w1
10000081c:     	lsl	w0, w0, #5
100000820:     	add	w1, w0, w1
100000824:     	ldr	w0, [sp, #0xc]
100000828:     	eor	w1, w1, w0
10000082c:     	adrp	x0, 0x100008000 <_memory>
100000830:     	add	x0, x0, #0xc
100000834:     	str	w1, [x0]
100000838:     	nop
10000083c:     	add	sp, sp, #0x10
100000840:     	ret

0000000100000844 <_next_value>:
100000844:     	stp	x29, x30, [sp, #-0x20]!
100000848:     	mov	x29, sp
10000084c:     	str	w0, [x29, #0x1c]
100000850:     	ldr	w0, [x29, #0x1c]
100000854:     	bl	0x100000804 <_record_event>
100000858:     	adrp	x0, 0x100008000 <_memory>
10000085c:     	add	x0, x0, #0x0
100000860:     	ldr	w1, [x0, #0x4]
100000864:     	ldr	w0, [x29, #0x1c]
100000868:     	add	w1, w1, w0
10000086c:     	adrp	x0, 0x100008000 <_memory>
100000870:     	add	x0, x0, #0x0
100000874:     	str	w1, [x0, #0x4]
100000878:     	adrp	x0, 0x100008000 <_memory>
10000087c:     	add	x0, x0, #0x0
100000880:     	ldr	w1, [x0, #0x4]
100000884:     	ldr	w0, [x29, #0x1c]
100000888:     	add	w0, w1, w0
10000088c:     	ldp	x29, x30, [sp], #0x20
100000890:     	ret

0000000100000894 <_main>:
100000894:     	sub	sp, sp, #0x90
100000898:     	stp	x29, x30, [sp, #0x30]
10000089c:     	add	x29, sp, #0x30
1000008a0:     	str	w0, [x29, #0x1c]
1000008a4:     	str	x1, [x29, #0x10]
1000008a8:     	ldr	w0, [x29, #0x1c]
1000008ac:     	cmp	w0, #0x3
1000008b0:     	b.eq	0x1000008bc <_main+0x28>
1000008b4:     	mov	w0, #0x2                ; =2
1000008b8:     	b	0x100000ab0 <_main+0x21c>
1000008bc:     	ldr	x0, [x29, #0x10]
1000008c0:     	add	x0, x0, #0x8
1000008c4:     	ldr	x0, [x0]
1000008c8:     	mov	w2, #0xa                ; =10
1000008cc:     	mov	x1, #0x0                ; =0
1000008d0:     	bl	0x100000ad4 <_strtoul+0x100000ad4>
1000008d4:     	str	x0, [x29, #0x48]
1000008d8:     	ldr	x0, [x29, #0x10]
1000008dc:     	add	x0, x0, #0x10
1000008e0:     	ldr	x0, [x0]
1000008e4:     	mov	w2, #0xa                ; =10
1000008e8:     	mov	x1, #0x0                ; =0
1000008ec:     	bl	0x100000ad4 <_strtoul+0x100000ad4>
1000008f0:     	str	w0, [x29, #0x5c]
1000008f4:     	str	wzr, [x29, #0x58]
1000008f8:     	add	x0, x29, #0x30
1000008fc:     	mov	x1, x0
100000900:     	mov	w0, #0x6                ; =6
100000904:     	bl	0x100000abc <_strtoul+0x100000abc>
100000908:     	cmp	w0, #0x0
10000090c:     	b.eq	0x100000918 <_main+0x84>
100000910:     	mov	w0, #0x2                ; =2
100000914:     	b	0x100000ab0 <_main+0x21c>
100000918:     	str	xzr, [x29, #0x50]
10000091c:     	b	0x1000009e0 <_main+0x14c>
100000920:     	ldr	w0, [x29, #0x5c]
100000924:     	lsl	w0, w0, #13
100000928:     	ldr	w1, [x29, #0x5c]
10000092c:     	eor	w0, w1, w0
100000930:     	str	w0, [x29, #0x5c]
100000934:     	ldr	w0, [x29, #0x5c]
100000938:     	lsr	w0, w0, #17
10000093c:     	ldr	w1, [x29, #0x5c]
100000940:     	eor	w0, w1, w0
100000944:     	str	w0, [x29, #0x5c]
100000948:     	ldr	w0, [x29, #0x5c]
10000094c:     	lsl	w0, w0, #5
100000950:     	ldr	w1, [x29, #0x5c]
100000954:     	eor	w0, w1, w0
100000958:     	str	w0, [x29, #0x5c]
10000095c:     	ldr	x2, [x29, #0x50]
100000960:     	mov	x0, #-0x3333333333333334 ; =-3689348814741910324
100000964:     	movk	x0, #0xcccd
100000968:     	umulh	x0, x2, x0
10000096c:     	lsr	x1, x0, #3
100000970:     	mov	x0, x1
100000974:     	lsl	x0, x0, #2
100000978:     	add	x0, x0, x1
10000097c:     	lsl	x0, x0, #1
100000980:     	sub	x1, x2, x0
100000984:     	mov	w0, w1
100000988:     	sub	w0, w0, #0x1
10000098c:     	mov	w2, w0
100000990:     	ldr	w1, [x29, #0x5c]
100000994:     	adrp	x0, 0x100008000 <_memory>
100000998:     	add	x0, x0, #0x0
10000099c:     	bl	0x100000648 <_region_pipeline>
1000009a0:     	mov	w1, w0
1000009a4:     	ldr	w0, [x29, #0x58]
1000009a8:     	add	w0, w0, w1
1000009ac:     	str	w0, [x29, #0x58]
1000009b0:     	ldr	w2, [x29, #0x58]
1000009b4:     	ldr	w1, [x29, #0x5c]
1000009b8:     	adrp	x0, 0x100008000 <_memory>
1000009bc:     	add	x0, x0, #0x0
1000009c0:     	bl	0x100000744 <_region_outputs>
1000009c4:     	mov	w1, w0
1000009c8:     	ldr	w0, [x29, #0x58]
1000009cc:     	add	w0, w0, w1
1000009d0:     	str	w0, [x29, #0x58]
1000009d4:     	ldr	x0, [x29, #0x50]
1000009d8:     	add	x0, x0, #0x1
1000009dc:     	str	x0, [x29, #0x50]
1000009e0:     	ldr	x1, [x29, #0x50]
1000009e4:     	ldr	x0, [x29, #0x48]
1000009e8:     	cmp	x1, x0
1000009ec:     	b.lo	0x100000920 <_main+0x8c>
1000009f0:     	add	x0, x29, #0x20
1000009f4:     	mov	x1, x0
1000009f8:     	mov	w0, #0x6                ; =6
1000009fc:     	bl	0x100000abc <_strtoul+0x100000abc>
100000a00:     	cmp	w0, #0x0
100000a04:     	b.eq	0x100000a10 <_main+0x17c>
100000a08:     	mov	w0, #0x2                ; =2
100000a0c:     	b	0x100000ab0 <_main+0x21c>
100000a10:     	ldr	x1, [x29, #0x20]
100000a14:     	ldr	x0, [x29, #0x30]
100000a18:     	sub	x0, x1, x0
100000a1c:     	fmov	d31, x0
100000a20:     	scvtf	d30, d31
100000a24:     	ldr	x1, [x29, #0x28]
100000a28:     	ldr	x0, [x29, #0x38]
100000a2c:     	sub	x0, x1, x0
100000a30:     	fmov	d31, x0
100000a34:     	scvtf	d29, d31
100000a38:     	adrp	x0, 0x100000000 <_strtoul+0x100000000>
100000a3c:     	add	x0, x0, #0xaf8
100000a40:     	ldr	d31, [x0]
100000a44:     	fmul	d31, d29, d31
100000a48:     	fadd	d31, d30, d31
100000a4c:     	str	d31, [x29, #0x40]
100000a50:     	adrp	x0, 0x100008000 <_memory>
100000a54:     	add	x0, x0, #0x0
100000a58:     	ldr	w1, [x0]
100000a5c:     	adrp	x0, 0x100008000 <_memory>
100000a60:     	add	x0, x0, #0x0
100000a64:     	ldr	w2, [x0, #0x4]
100000a68:     	adrp	x0, 0x100008000 <_memory>
100000a6c:     	add	x0, x0, #0x0
100000a70:     	ldr	w3, [x0, #0x8]
100000a74:     	adrp	x0, 0x100008000 <_memory>
100000a78:     	add	x0, x0, #0xc
100000a7c:     	ldr	w0, [x0]
100000a80:     	str	w0, [sp, #0x28]
100000a84:     	str	w3, [sp, #0x20]
100000a88:     	str	w2, [sp, #0x18]
100000a8c:     	str	w1, [sp, #0x10]
100000a90:     	ldr	w0, [x29, #0x58]
100000a94:     	str	w0, [sp, #0x8]
100000a98:     	ldr	d31, [x29, #0x40]
100000a9c:     	str	d31, [sp]
100000aa0:     	adrp	x0, 0x100000000 <_strtoul+0x100000000>
100000aa4:     	add	x0, x0, #0xae0
100000aa8:     	bl	0x100000ac8 <_strtoul+0x100000ac8>
100000aac:     	mov	w0, #0x0                ; =0
100000ab0:     	ldp	x29, x30, [sp, #0x30]
100000ab4:     	add	sp, sp, #0x90
100000ab8:     	ret

Disassembly of section __TEXT,__stubs:

0000000100000abc <__stubs>:
100000abc:     	adrp	x16, 0x100004000 <_strtoul+0x100004000>
100000ac0:     	ldr	x16, [x16]
100000ac4:     	br	x16
100000ac8:     	adrp	x16, 0x100004000 <_strtoul+0x100004000>
100000acc:     	ldr	x16, [x16, #0x8]
100000ad0:     	br	x16
100000ad4:     	adrp	x16, 0x100004000 <_strtoul+0x100004000>
100000ad8:     	ldr	x16, [x16, #0x10]
100000adc:     	br	x16
