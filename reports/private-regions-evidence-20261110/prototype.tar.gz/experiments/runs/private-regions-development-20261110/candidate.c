#include <stdint.h>

extern uint32_t next_value(uint32_t value);
extern void record_event(uint32_t value);

uint32_t region_pipeline(uint32_t *buffer, uint32_t x, int limit)
{
    uint32_t y = buffer[0];
    { unsigned int csrd_frame_208_0 = ((428335287u * (x)) + 2542628964u); unsigned int csrd_frame_208_1 = ((428335287u * (y)) + 2542628964u); csrd_frame_208_0 = (((csrd_frame_208_0) + (csrd_frame_208_1)) - 2542628964u); csrd_frame_208_0 = (((((3u * (csrd_frame_208_0)) + 3504676664u)) + (2959349825u)) - 2542628964u); x = (2171403527u * ((csrd_frame_208_0) - 2542628964u));
}
    record_event(x);
    if (limit < 0) return x;
    while (limit-- > 0) {
        y = next_value(x);
        { unsigned int csrd_frame_352_0 = ((1367317615u * (x)) + 1250390762u); unsigned int csrd_frame_352_1 = ((1367317615u * (y)) + 1250390762u); csrd_frame_352_0 = (((csrd_frame_352_0) + (csrd_frame_352_1)) - 1250390762u); csrd_frame_352_0 = (((((5u * (csrd_frame_352_0)) + 3588371544u)) - (2231679475u)) + 1250390762u); x = (3662496399u * ((csrd_frame_352_0) - 1250390762u));
}
        buffer[0] = x;
        record_event(y);
    }
    return x;
}

int region_outputs(uint32_t *buffer, uint32_t x, uint32_t y)
{
    uint32_t pending;
    { unsigned int csrd_frame_548_0 = ((530885835u * (x)) + 1388492207u); unsigned int csrd_frame_548_1 = ((530885835u * (y)) + 1388492207u); unsigned int csrd_frame_548_2 = 1823616810u; csrd_frame_548_2 = (((csrd_frame_548_2) + (csrd_frame_548_0)) - 1388492207u); csrd_frame_548_0 = (((((3u * (csrd_frame_548_2)) + 1517982882u)) + (csrd_frame_548_1)) - 1388492207u); csrd_frame_548_1 = (((csrd_frame_548_0) - (csrd_frame_548_2)) + 1388492207u); pending = (455039203u * ((csrd_frame_548_2) - 1388492207u)); x = (455039203u * ((csrd_frame_548_0) - 1388492207u)); y = (455039203u * ((csrd_frame_548_1) - 1388492207u));


}
    record_event(x);
    buffer[0] = y;
    buffer[1] = pending;
    return x == y;
}
