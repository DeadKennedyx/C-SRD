
/work/experiments/runs/private-regions-cost-linux-20261110/clang-O2-lto/original:	file format elf64-littleaarch64

Disassembly of section .init:

0000000000000638 <_init>:
     638:      	nop
     63c:      	stp	x29, x30, [sp, #-0x10]!
     640:      	mov	x29, sp
     644:      	bl	0x734 <call_weak_fn>
     648:      	ldp	x29, x30, [sp], #0x10
     64c:      	ret

Disassembly of section .plt:

0000000000000650 <.plt>:
     650:      	stp	x16, x30, [sp, #-0x10]!
     654:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e4b8>
     658:      	ldr	x17, [x16, #0xff8]
     65c:      	add	x16, x16, #0xff8
     660:      	br	x17
     664:      	nop
     668:      	nop
     66c:      	nop

0000000000000670 <strtoul@plt>:
     670:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     674:      	ldr	x17, [x16]
     678:      	add	x16, x16, #0x0
     67c:      	br	x17

0000000000000680 <__libc_start_main@plt>:
     680:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     684:      	ldr	x17, [x16, #0x8]
     688:      	add	x16, x16, #0x8
     68c:      	br	x17

0000000000000690 <__cxa_finalize@plt>:
     690:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     694:      	ldr	x17, [x16, #0x10]
     698:      	add	x16, x16, #0x10
     69c:      	br	x17

00000000000006a0 <clock_gettime@plt>:
     6a0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6a4:      	ldr	x17, [x16, #0x18]
     6a8:      	add	x16, x16, #0x18
     6ac:      	br	x17

00000000000006b0 <__gmon_start__@plt>:
     6b0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6b4:      	ldr	x17, [x16, #0x20]
     6b8:      	add	x16, x16, #0x20
     6bc:      	br	x17

00000000000006c0 <abort@plt>:
     6c0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6c4:      	ldr	x17, [x16, #0x28]
     6c8:      	add	x16, x16, #0x28
     6cc:      	br	x17

00000000000006d0 <printf@plt>:
     6d0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6d4:      	ldr	x17, [x16, #0x30]
     6d8:      	add	x16, x16, #0x30
     6dc:      	br	x17

Disassembly of section .text:

0000000000000700 <_start>:
     700:      	nop
     704:      	mov	x29, #0x0               // =0
     708:      	mov	x30, #0x0               // =0
     70c:      	mov	x5, x0
     710:      	ldr	x1, [sp]
     714:      	add	x2, sp, #0x8
     718:      	mov	x6, sp
     71c:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e4b8>
     720:      	ldr	x0, [x0, #0xfd8]
     724:      	mov	x3, #0x0                // =0
     728:      	mov	x4, #0x0                // =0
     72c:      	bl	0x680 <__libc_start_main@plt>
     730:      	bl	0x6c0 <abort@plt>

0000000000000734 <call_weak_fn>:
     734:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e4b8>
     738:      	ldr	x0, [x0, #0xfd0]
     73c:      	cbz	x0, 0x744 <call_weak_fn+0x10>
     740:      	b	0x6b0 <__gmon_start__@plt>
     744:      	ret
     748:      	nop
     74c:      	nop

0000000000000750 <deregister_tm_clones>:
     750:      	adrp	x0, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     754:      	add	x0, x0, #0x48
     758:      	adrp	x1, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     75c:      	add	x1, x1, #0x48
     760:      	cmp	x1, x0
     764:      	b.eq	0x77c <deregister_tm_clones+0x2c>
     768:      	adrp	x1, 0x1f000 <__FRAME_END__+0x1e4b8>
     76c:      	ldr	x1, [x1, #0xfc0]
     770:      	cbz	x1, 0x77c <deregister_tm_clones+0x2c>
     774:      	mov	x16, x1
     778:      	br	x16
     77c:      	ret

0000000000000780 <register_tm_clones>:
     780:      	adrp	x0, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     784:      	add	x0, x0, #0x48
     788:      	adrp	x1, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     78c:      	add	x1, x1, #0x48
     790:      	sub	x1, x1, x0
     794:      	lsr	x2, x1, #63
     798:      	add	x1, x2, x1, asr #3
     79c:      	asr	x1, x1, #1
     7a0:      	cbz	x1, 0x7b8 <register_tm_clones+0x38>
     7a4:      	adrp	x2, 0x1f000 <__FRAME_END__+0x1e4b8>
     7a8:      	ldr	x2, [x2, #0xfe0]
     7ac:      	cbz	x2, 0x7b8 <register_tm_clones+0x38>
     7b0:      	mov	x16, x2
     7b4:      	br	x16
     7b8:      	ret
     7bc:      	nop

00000000000007c0 <__do_global_dtors_aux>:
     7c0:      	paciasp
     7c4:      	stp	x29, x30, [sp, #-0x20]!
     7c8:      	mov	x29, sp
     7cc:      	str	x19, [sp, #0x10]
     7d0:      	adrp	x19, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     7d4:      	ldrb	w0, [x19, #0x48]
     7d8:      	tbnz	w0, #0x0, 0x800 <__do_global_dtors_aux+0x40>
     7dc:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e4b8>
     7e0:      	ldr	x0, [x0, #0xfc8]
     7e4:      	cbz	x0, 0x7f4 <__do_global_dtors_aux+0x34>
     7e8:      	adrp	x0, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     7ec:      	ldr	x0, [x0, #0x40]
     7f0:      	bl	0x690 <__cxa_finalize@plt>
     7f4:      	bl	0x750 <deregister_tm_clones>
     7f8:      	mov	w0, #0x1                // =1
     7fc:      	strb	w0, [x19, #0x48]
     800:      	ldr	x19, [sp, #0x10]
     804:      	ldp	x29, x30, [sp], #0x20
     808:      	autiasp
     80c:      	ret

0000000000000810 <frame_dummy>:
     810:      	bti	c
     814:      	b	0x780 <register_tm_clones>

0000000000000818 <main>:
     818:      	cmp	w0, #0x3
     81c:      	b.ne	0x940 <main+0x128>
     820:      	sub	sp, sp, #0x60
     824:      	stp	x29, x30, [sp, #0x20]
     828:      	stp	x24, x23, [sp, #0x30]
     82c:      	stp	x22, x21, [sp, #0x40]
     830:      	stp	x20, x19, [sp, #0x50]
     834:      	add	x29, sp, #0x20
     838:      	ldr	x0, [x1, #0x8]
     83c:      	mov	x19, x1
     840:      	mov	x1, xzr
     844:      	mov	w2, #0xa                // =10
     848:      	bl	0x670 <strtoul@plt>
     84c:      	ldr	x8, [x19, #0x10]
     850:      	mov	x20, x0
     854:      	mov	x1, xzr
     858:      	mov	w2, #0xa                // =10
     85c:      	mov	x0, x8
     860:      	bl	0x670 <strtoul@plt>
     864:      	mov	x21, x0
     868:      	add	x1, sp, #0x10
     86c:      	mov	w0, #0x1                // =1
     870:      	bl	0x6a0 <clock_gettime@plt>
     874:      	cbnz	w0, 0x96c <main+0x154>
     878:      	adrp	x22, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     87c:      	adrp	x23, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     880:      	adrp	x24, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     884:      	cbz	x20, 0x958 <main+0x140>
     888:      	ldr	w14, [x22, #0x50]
     88c:      	ldr	w12, [x24, #0x4c]
     890:      	mov	x9, #-0x3333333333333334 // =-3689348814741910324
     894:      	ldr	w10, [x23, #0x54]
     898:      	mov	x8, xzr
     89c:      	mov	w19, wzr
     8a0:      	movk	x9, #0xcccd
     8a4:      	mov	w11, #0xa               // =10
     8a8:      	b	0x8d8 <main+0xc0>
     8ac:      	adds	w10, w21, #0x11
     8b0:      	add	w12, w12, w19
     8b4:      	add	w15, w14, w14, lsl #5
     8b8:      	add	w13, w10, w10, lsl #1
     8bc:      	add	x8, x8, #0x1
     8c0:      	cinc	w19, w12, eq
     8c4:      	cmp	x8, x20
     8c8:      	add	w13, w13, w12
     8cc:      	sub	w14, w13, w10
     8d0:      	eor	w12, w15, w13
     8d4:      	b.eq	0x948 <main+0x130>
     8d8:      	umulh	x13, x8, x9
     8dc:      	eor	w15, w21, w21, lsl #13
     8e0:      	eor	w15, w15, w15, lsr #17
     8e4:      	eor	w21, w15, w15, lsl #5
     8e8:      	add	w15, w12, w12, lsl #5
     8ec:      	lsr	x13, x13, #3
     8f0:      	add	w14, w14, w21
     8f4:      	msub	w13, w13, w11, w8
     8f8:      	add	w14, w14, w14, lsl #1
     8fc:      	add	w12, w14, #0xb
     900:      	cmp	w13, #0x2
     904:      	eor	w14, w15, w12
     908:      	b.lo	0x8ac <main+0x94>
     90c:      	add	w14, w14, w14, lsl #5
     910:      	add	w10, w10, w12
     914:      	sub	w13, w13, #0x1
     918:      	add	w15, w10, w12
     91c:      	cmp	w13, #0x1
     920:      	eor	w14, w14, w12
     924:      	add	w12, w15, w12
     928:      	add	w12, w12, w12, lsl #2
     92c:      	add	w14, w14, w14, lsl #5
     930:      	sub	w12, w12, #0x7
     934:      	eor	w14, w14, w15
     938:      	b.hi	0x90c <main+0xf4>
     93c:      	b	0x8ac <main+0x94>
     940:      	mov	w0, #0x2                // =2
     944:      	ret
     948:      	str	w14, [x22, #0x50]
     94c:      	str	w12, [x24, #0x4c]
     950:      	str	w10, [x23, #0x54]
     954:      	b	0x95c <main+0x144>
     958:      	mov	w19, wzr
     95c:      	mov	x1, sp
     960:      	mov	w0, #0x1                // =1
     964:      	bl	0x6a0 <clock_gettime@plt>
     968:      	cbz	w0, 0x988 <main+0x170>
     96c:      	mov	w0, #0x2                // =2
     970:      	ldp	x20, x19, [sp, #0x50]
     974:      	ldp	x22, x21, [sp, #0x40]
     978:      	ldp	x24, x23, [sp, #0x30]
     97c:      	ldp	x29, x30, [sp, #0x20]
     980:      	add	sp, sp, #0x60
     984:      	ret
     988:      	ldp	x8, x9, [sp]
     98c:      	adrp	x0, 0x0 <strtoul@GLIBC_2.17>
     990:      	add	x0, x0, #0x9f8
     994:      	ldp	x10, x11, [sp, #0x10]
     998:      	ldr	w2, [x22, #0x50]
     99c:      	ldr	w3, [x23, #0x54]
     9a0:      	mov	w1, w19
     9a4:      	ldr	w5, [x24, #0x4c]
     9a8:      	mov	w4, wzr
     9ac:      	sub	x8, x8, x10
     9b0:      	sub	x9, x9, x11
     9b4:      	scvtf	d0, x8
     9b8:      	scvtf	d1, x9
     9bc:      	adrp	x8, 0x0 <strtoul@GLIBC_2.17>
     9c0:      	ldr	d2, [x8, #0x9f0]
     9c4:      	fmadd	d0, d1, d2, d0
     9c8:      	bl	0x6d0 <printf@plt>
     9cc:      	mov	w0, wzr
     9d0:      	b	0x970 <main+0x158>

Disassembly of section .fini:

00000000000009d4 <_fini>:
     9d4:      	nop
     9d8:      	stp	x29, x30, [sp, #-0x10]!
     9dc:      	mov	x29, sp
     9e0:      	ldp	x29, x30, [sp], #0x10
     9e4:      	ret
