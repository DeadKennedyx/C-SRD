
/work/experiments/runs/private-regions-cost-linux-20261110/clang-O2-lto/affine:	file format elf64-littleaarch64

Disassembly of section .init:

0000000000000638 <_init>:
     638:      	nop
     63c:      	stp	x29, x30, [sp, #-0x10]!
     640:      	mov	x29, sp
     644:      	bl	0x734 <call_weak_fn>
     648:      	ldp	x29, x30, [sp], #0x10
     64c:      	ret

Disassembly of section .plt:

0000000000000650 <.plt>:
     650:      	stp	x16, x30, [sp, #-0x10]!
     654:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e468>
     658:      	ldr	x17, [x16, #0xff8]
     65c:      	add	x16, x16, #0xff8
     660:      	br	x17
     664:      	nop
     668:      	nop
     66c:      	nop

0000000000000670 <strtoul@plt>:
     670:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     674:      	ldr	x17, [x16]
     678:      	add	x16, x16, #0x0
     67c:      	br	x17

0000000000000680 <__libc_start_main@plt>:
     680:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     684:      	ldr	x17, [x16, #0x8]
     688:      	add	x16, x16, #0x8
     68c:      	br	x17

0000000000000690 <__cxa_finalize@plt>:
     690:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     694:      	ldr	x17, [x16, #0x10]
     698:      	add	x16, x16, #0x10
     69c:      	br	x17

00000000000006a0 <clock_gettime@plt>:
     6a0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6a4:      	ldr	x17, [x16, #0x18]
     6a8:      	add	x16, x16, #0x18
     6ac:      	br	x17

00000000000006b0 <__gmon_start__@plt>:
     6b0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6b4:      	ldr	x17, [x16, #0x20]
     6b8:      	add	x16, x16, #0x20
     6bc:      	br	x17

00000000000006c0 <abort@plt>:
     6c0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6c4:      	ldr	x17, [x16, #0x28]
     6c8:      	add	x16, x16, #0x28
     6cc:      	br	x17

00000000000006d0 <printf@plt>:
     6d0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6d4:      	ldr	x17, [x16, #0x30]
     6d8:      	add	x16, x16, #0x30
     6dc:      	br	x17

Disassembly of section .text:

0000000000000700 <_start>:
     700:      	nop
     704:      	mov	x29, #0x0               // =0
     708:      	mov	x30, #0x0               // =0
     70c:      	mov	x5, x0
     710:      	ldr	x1, [sp]
     714:      	add	x2, sp, #0x8
     718:      	mov	x6, sp
     71c:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e468>
     720:      	ldr	x0, [x0, #0xfd8]
     724:      	mov	x3, #0x0                // =0
     728:      	mov	x4, #0x0                // =0
     72c:      	bl	0x680 <__libc_start_main@plt>
     730:      	bl	0x6c0 <abort@plt>

0000000000000734 <call_weak_fn>:
     734:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e468>
     738:      	ldr	x0, [x0, #0xfd0]
     73c:      	cbz	x0, 0x744 <call_weak_fn+0x10>
     740:      	b	0x6b0 <__gmon_start__@plt>
     744:      	ret
     748:      	nop
     74c:      	nop

0000000000000750 <deregister_tm_clones>:
     750:      	adrp	x0, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     754:      	add	x0, x0, #0x48
     758:      	adrp	x1, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     75c:      	add	x1, x1, #0x48
     760:      	cmp	x1, x0
     764:      	b.eq	0x77c <deregister_tm_clones+0x2c>
     768:      	adrp	x1, 0x1f000 <__FRAME_END__+0x1e468>
     76c:      	ldr	x1, [x1, #0xfc0]
     770:      	cbz	x1, 0x77c <deregister_tm_clones+0x2c>
     774:      	mov	x16, x1
     778:      	br	x16
     77c:      	ret

0000000000000780 <register_tm_clones>:
     780:      	adrp	x0, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     784:      	add	x0, x0, #0x48
     788:      	adrp	x1, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     78c:      	add	x1, x1, #0x48
     790:      	sub	x1, x1, x0
     794:      	lsr	x2, x1, #63
     798:      	add	x1, x2, x1, asr #3
     79c:      	asr	x1, x1, #1
     7a0:      	cbz	x1, 0x7b8 <register_tm_clones+0x38>
     7a4:      	adrp	x2, 0x1f000 <__FRAME_END__+0x1e468>
     7a8:      	ldr	x2, [x2, #0xfe0]
     7ac:      	cbz	x2, 0x7b8 <register_tm_clones+0x38>
     7b0:      	mov	x16, x2
     7b4:      	br	x16
     7b8:      	ret
     7bc:      	nop

00000000000007c0 <__do_global_dtors_aux>:
     7c0:      	paciasp
     7c4:      	stp	x29, x30, [sp, #-0x20]!
     7c8:      	mov	x29, sp
     7cc:      	str	x19, [sp, #0x10]
     7d0:      	adrp	x19, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     7d4:      	ldrb	w0, [x19, #0x48]
     7d8:      	tbnz	w0, #0x0, 0x800 <__do_global_dtors_aux+0x40>
     7dc:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e468>
     7e0:      	ldr	x0, [x0, #0xfc8]
     7e4:      	cbz	x0, 0x7f4 <__do_global_dtors_aux+0x34>
     7e8:      	adrp	x0, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     7ec:      	ldr	x0, [x0, #0x40]
     7f0:      	bl	0x690 <__cxa_finalize@plt>
     7f4:      	bl	0x750 <deregister_tm_clones>
     7f8:      	mov	w0, #0x1                // =1
     7fc:      	strb	w0, [x19, #0x48]
     800:      	ldr	x19, [sp, #0x10]
     804:      	ldp	x29, x30, [sp], #0x20
     808:      	autiasp
     80c:      	ret

0000000000000810 <frame_dummy>:
     810:      	bti	c
     814:      	b	0x780 <register_tm_clones>

0000000000000818 <main>:
     818:      	cmp	w0, #0x3
     81c:      	b.ne	0x98c <main+0x174>
     820:      	sub	sp, sp, #0x60
     824:      	stp	x29, x30, [sp, #0x20]
     828:      	stp	x24, x23, [sp, #0x30]
     82c:      	stp	x22, x21, [sp, #0x40]
     830:      	stp	x20, x19, [sp, #0x50]
     834:      	add	x29, sp, #0x20
     838:      	ldr	x0, [x1, #0x8]
     83c:      	mov	x19, x1
     840:      	mov	x1, xzr
     844:      	mov	w2, #0xa                // =10
     848:      	bl	0x670 <strtoul@plt>
     84c:      	ldr	x8, [x19, #0x10]
     850:      	mov	x19, x0
     854:      	mov	x1, xzr
     858:      	mov	w2, #0xa                // =10
     85c:      	mov	x0, x8
     860:      	bl	0x670 <strtoul@plt>
     864:      	mov	x21, x0
     868:      	add	x1, sp, #0x10
     86c:      	mov	w0, #0x1                // =1
     870:      	bl	0x6a0 <clock_gettime@plt>
     874:      	cbnz	w0, 0x9b8 <main+0x1a0>
     878:      	adrp	x22, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     87c:      	adrp	x23, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     880:      	adrp	x24, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     884:      	cbz	x19, 0x9a4 <main+0x18c>
     888:      	mov	w9, #0x57d7             // =22487
     88c:      	ldr	w0, [x22, #0x50]
     890:      	ldr	w1, [x24, #0x4c]
     894:      	ldr	w18, [x23, #0x54]
     898:      	mov	x10, #-0x3333333333333334 // =-3689348814741910324
     89c:      	mov	w12, #0x7419            // =29721
     8a0:      	mov	w13, #0x8be7            // =35815
     8a4:      	mov	w14, #0xa3b5            // =41909
     8a8:      	mov	w15, #0x602f            // =24623
     8ac:      	mov	w16, #0x347f            // =13439
     8b0:      	mov	w17, #0x3fba            // =16314
     8b4:      	mov	x8, xzr
     8b8:      	mov	w20, wzr
     8bc:      	movk	w9, #0xd9e3, lsl #16
     8c0:      	movk	x10, #0xcccd
     8c4:      	mov	w11, #0xa               // =10
     8c8:      	movk	w12, #0xc719, lsl #16
     8cc:      	movk	w13, #0x38e6, lsl #16
     8d0:      	movk	w14, #0xaab3, lsl #16
     8d4:      	movk	w15, #0x27b3, lsl #16
     8d8:      	movk	w16, #0x66eb, lsl #16
     8dc:      	movk	w17, #0x91fd, lsl #16
     8e0:      	b	0x924 <main+0x10c>
     8e4:      	add	w18, w0, w20
     8e8:      	add	w1, w1, w1, lsl #5
     8ec:      	add	x8, x8, #0x1
     8f0:      	mul	w0, w18, w13
     8f4:      	madd	w0, w21, w14, w0
     8f8:      	add	w0, w0, w15
     8fc:      	madd	w2, w21, w12, w0
     900:      	madd	w3, w0, w9, w17
     904:      	add	w0, w2, w16
     908:      	mul	w0, w0, w9
     90c:      	eor	w1, w1, w3
     910:      	cmp	w3, w0
     914:      	cinc	w20, w18, eq
     918:      	cmp	x8, x19
     91c:      	add	w18, w21, #0x11
     920:      	b.eq	0x994 <main+0x17c>
     924:      	umulh	x2, x8, x10
     928:      	eor	w3, w21, w21, lsl #13
     92c:      	add	w1, w1, w1, lsl #5
     930:      	eor	w3, w3, w3, lsr #17
     934:      	eor	w21, w3, w3, lsl #5
     938:      	lsr	x2, x2, #3
     93c:      	add	w0, w0, w21
     940:      	msub	w2, w2, w11, w8
     944:      	add	w0, w0, w0, lsl #1
     948:      	add	w0, w0, #0xb
     94c:      	cmp	w2, #0x2
     950:      	eor	w1, w1, w0
     954:      	b.lo	0x8e4 <main+0xcc>
     958:      	add	w1, w1, w1, lsl #5
     95c:      	add	w18, w18, w0
     960:      	sub	w2, w2, #0x1
     964:      	add	w3, w18, w0
     968:      	cmp	w2, #0x1
     96c:      	eor	w1, w1, w0
     970:      	add	w0, w3, w0
     974:      	add	w0, w0, w0, lsl #2
     978:      	add	w1, w1, w1, lsl #5
     97c:      	sub	w0, w0, #0x7
     980:      	eor	w1, w1, w3
     984:      	b.hi	0x958 <main+0x140>
     988:      	b	0x8e4 <main+0xcc>
     98c:      	mov	w0, #0x2                // =2
     990:      	ret
     994:      	str	w0, [x22, #0x50]
     998:      	str	w1, [x24, #0x4c]
     99c:      	str	w18, [x23, #0x54]
     9a0:      	b	0x9a8 <main+0x190>
     9a4:      	mov	w20, wzr
     9a8:      	mov	x1, sp
     9ac:      	mov	w0, #0x1                // =1
     9b0:      	bl	0x6a0 <clock_gettime@plt>
     9b4:      	cbz	w0, 0x9d4 <main+0x1bc>
     9b8:      	mov	w0, #0x2                // =2
     9bc:      	ldp	x20, x19, [sp, #0x50]
     9c0:      	ldp	x22, x21, [sp, #0x40]
     9c4:      	ldp	x24, x23, [sp, #0x30]
     9c8:      	ldp	x29, x30, [sp, #0x20]
     9cc:      	add	sp, sp, #0x60
     9d0:      	ret
     9d4:      	ldp	x8, x9, [sp]
     9d8:      	adrp	x0, 0x0 <strtoul@GLIBC_2.17>
     9dc:      	add	x0, x0, #0xa48
     9e0:      	ldp	x10, x11, [sp, #0x10]
     9e4:      	ldr	w2, [x22, #0x50]
     9e8:      	ldr	w3, [x23, #0x54]
     9ec:      	mov	w1, w20
     9f0:      	ldr	w5, [x24, #0x4c]
     9f4:      	mov	w4, wzr
     9f8:      	sub	x8, x8, x10
     9fc:      	sub	x9, x9, x11
     a00:      	scvtf	d0, x8
     a04:      	scvtf	d1, x9
     a08:      	adrp	x8, 0x0 <strtoul@GLIBC_2.17>
     a0c:      	ldr	d2, [x8, #0xa40]
     a10:      	fmadd	d0, d1, d2, d0
     a14:      	bl	0x6d0 <printf@plt>
     a18:      	mov	w0, wzr
     a1c:      	b	0x9bc <main+0x1a4>

Disassembly of section .fini:

0000000000000a20 <_fini>:
     a20:      	nop
     a24:      	stp	x29, x30, [sp, #-0x10]!
     a28:      	mov	x29, sp
     a2c:      	ldp	x29, x30, [sp], #0x10
     a30:      	ret
