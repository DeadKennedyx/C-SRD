
/work/experiments/runs/private-regions-cost-linux-20261110/gcc-O0/identity:	file format elf64-littleaarch64

Disassembly of section .init:

00000000000006f0 <_init>:
     6f0:      	nop
     6f4:      	stp	x29, x30, [sp, #-0x10]!
     6f8:      	mov	x29, sp
     6fc:      	bl	0x7f4 <call_weak_fn>
     700:      	ldp	x29, x30, [sp], #0x10
     704:      	ret

Disassembly of section .plt:

0000000000000710 <.plt>:
     710:      	stp	x16, x30, [sp, #-0x10]!
     714:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e0c0>
     718:      	ldr	x17, [x16, #0xf80]
     71c:      	add	x16, x16, #0xf80
     720:      	br	x17
     724:      	nop
     728:      	nop
     72c:      	nop

0000000000000730 <strtoul@plt>:
     730:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e0c0>
     734:      	ldr	x17, [x16, #0xf88]
     738:      	add	x16, x16, #0xf88
     73c:      	br	x17

0000000000000740 <__libc_start_main@plt>:
     740:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e0c0>
     744:      	ldr	x17, [x16, #0xf90]
     748:      	add	x16, x16, #0xf90
     74c:      	br	x17

0000000000000750 <__cxa_finalize@plt>:
     750:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e0c0>
     754:      	ldr	x17, [x16, #0xf98]
     758:      	add	x16, x16, #0xf98
     75c:      	br	x17

0000000000000760 <clock_gettime@plt>:
     760:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e0c0>
     764:      	ldr	x17, [x16, #0xfa0]
     768:      	add	x16, x16, #0xfa0
     76c:      	br	x17

0000000000000770 <__stack_chk_fail@plt>:
     770:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e0c0>
     774:      	ldr	x17, [x16, #0xfa8]
     778:      	add	x16, x16, #0xfa8
     77c:      	br	x17

0000000000000780 <__gmon_start__@plt>:
     780:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e0c0>
     784:      	ldr	x17, [x16, #0xfb0]
     788:      	add	x16, x16, #0xfb0
     78c:      	br	x17

0000000000000790 <abort@plt>:
     790:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e0c0>
     794:      	ldr	x17, [x16, #0xfb8]
     798:      	add	x16, x16, #0xfb8
     79c:      	br	x17

00000000000007a0 <printf@plt>:
     7a0:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e0c0>
     7a4:      	ldr	x17, [x16, #0xfc0]
     7a8:      	add	x16, x16, #0xfc0
     7ac:      	br	x17

Disassembly of section .text:

00000000000007c0 <_start>:
     7c0:      	nop
     7c4:      	mov	x29, #0x0               // =0
     7c8:      	mov	x30, #0x0               // =0
     7cc:      	mov	x5, x0
     7d0:      	ldr	x1, [sp]
     7d4:      	add	x2, sp, #0x8
     7d8:      	mov	x6, sp
     7dc:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e0c0>
     7e0:      	ldr	x0, [x0, #0xff0]
     7e4:      	mov	x3, #0x0                // =0
     7e8:      	mov	x4, #0x0                // =0
     7ec:      	bl	0x740 <__libc_start_main@plt>
     7f0:      	bl	0x790 <abort@plt>

00000000000007f4 <call_weak_fn>:
     7f4:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e0c0>
     7f8:      	ldr	x0, [x0, #0xfe0]
     7fc:      	cbz	x0, 0x804 <call_weak_fn+0x10>
     800:      	b	0x780 <__gmon_start__@plt>
     804:      	ret
     808:      	nop
     80c:      	nop

0000000000000810 <deregister_tm_clones>:
     810:      	adrp	x0, 0x20000 <data_start>
     814:      	add	x0, x0, #0x10
     818:      	adrp	x1, 0x20000 <data_start>
     81c:      	add	x1, x1, #0x10
     820:      	cmp	x1, x0
     824:      	b.eq	0x83c <deregister_tm_clones+0x2c>
     828:      	adrp	x1, 0x1f000 <__FRAME_END__+0x1e0c0>
     82c:      	ldr	x1, [x1, #0xfd0]
     830:      	cbz	x1, 0x83c <deregister_tm_clones+0x2c>
     834:      	mov	x16, x1
     838:      	br	x16
     83c:      	ret

0000000000000840 <register_tm_clones>:
     840:      	adrp	x0, 0x20000 <data_start>
     844:      	add	x0, x0, #0x10
     848:      	adrp	x1, 0x20000 <data_start>
     84c:      	add	x1, x1, #0x10
     850:      	sub	x1, x1, x0
     854:      	lsr	x2, x1, #63
     858:      	add	x1, x2, x1, asr #3
     85c:      	asr	x1, x1, #1
     860:      	cbz	x1, 0x878 <register_tm_clones+0x38>
     864:      	adrp	x2, 0x1f000 <__FRAME_END__+0x1e0c0>
     868:      	ldr	x2, [x2, #0xff8]
     86c:      	cbz	x2, 0x878 <register_tm_clones+0x38>
     870:      	mov	x16, x2
     874:      	br	x16
     878:      	ret
     87c:      	nop

0000000000000880 <__do_global_dtors_aux>:
     880:      	paciasp
     884:      	stp	x29, x30, [sp, #-0x20]!
     888:      	mov	x29, sp
     88c:      	str	x19, [sp, #0x10]
     890:      	adrp	x19, 0x20000 <data_start>
     894:      	ldrb	w0, [x19, #0x10]
     898:      	tbnz	w0, #0x0, 0x8c0 <__do_global_dtors_aux+0x40>
     89c:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e0c0>
     8a0:      	ldr	x0, [x0, #0xfd8]
     8a4:      	cbz	x0, 0x8b4 <__do_global_dtors_aux+0x34>
     8a8:      	adrp	x0, 0x20000 <data_start>
     8ac:      	ldr	x0, [x0, #0x8]
     8b0:      	bl	0x750 <__cxa_finalize@plt>
     8b4:      	bl	0x810 <deregister_tm_clones>
     8b8:      	mov	w0, #0x1                // =1
     8bc:      	strb	w0, [x19, #0x10]
     8c0:      	ldr	x19, [sp, #0x10]
     8c4:      	ldp	x29, x30, [sp], #0x20
     8c8:      	autiasp
     8cc:      	ret

00000000000008d0 <frame_dummy>:
     8d0:      	bti	c
     8d4:      	b	0x840 <register_tm_clones>

00000000000008d8 <region_pipeline>:
     8d8:      	stp	x29, x30, [sp, #-0x40]!
     8dc:      	mov	x29, sp
     8e0:      	str	x0, [sp, #0x18]
     8e4:      	str	w1, [sp, #0x14]
     8e8:      	str	w2, [sp, #0x10]
     8ec:      	ldr	x0, [sp, #0x18]
     8f0:      	ldr	w0, [x0]
     8f4:      	str	w0, [sp, #0x2c]
     8f8:      	ldr	w0, [sp, #0x14]
     8fc:      	str	w0, [sp, #0x30]
     900:      	ldr	w0, [sp, #0x2c]
     904:      	str	w0, [sp, #0x34]
     908:      	ldr	w1, [sp, #0x30]
     90c:      	ldr	w0, [sp, #0x34]
     910:      	add	w0, w1, w0
     914:      	str	w0, [sp, #0x30]
     918:      	ldr	w1, [sp, #0x30]
     91c:      	mov	w0, w1
     920:      	lsl	w0, w0, #1
     924:      	add	w0, w0, w1
     928:      	add	w0, w0, #0xb
     92c:      	str	w0, [sp, #0x30]
     930:      	ldr	w0, [sp, #0x30]
     934:      	str	w0, [sp, #0x14]
     938:      	ldr	w0, [sp, #0x14]
     93c:      	bl	0xa94 <record_event>
     940:      	ldr	w0, [sp, #0x10]
     944:      	cmp	w0, #0x0
     948:      	b.ge	0x9b4 <region_pipeline+0xdc>
     94c:      	ldr	w0, [sp, #0x14]
     950:      	b	0x9cc <region_pipeline+0xf4>
     954:      	ldr	w0, [sp, #0x14]
     958:      	bl	0xad4 <next_value>
     95c:      	str	w0, [sp, #0x2c]
     960:      	ldr	w0, [sp, #0x14]
     964:      	str	w0, [sp, #0x38]
     968:      	ldr	w0, [sp, #0x2c]
     96c:      	str	w0, [sp, #0x3c]
     970:      	ldr	w1, [sp, #0x38]
     974:      	ldr	w0, [sp, #0x3c]
     978:      	add	w0, w1, w0
     97c:      	str	w0, [sp, #0x38]
     980:      	ldr	w1, [sp, #0x38]
     984:      	mov	w0, w1
     988:      	lsl	w0, w0, #2
     98c:      	add	w0, w0, w1
     990:      	sub	w0, w0, #0x7
     994:      	str	w0, [sp, #0x38]
     998:      	ldr	w0, [sp, #0x38]
     99c:      	str	w0, [sp, #0x14]
     9a0:      	ldr	x0, [sp, #0x18]
     9a4:      	ldr	w1, [sp, #0x14]
     9a8:      	str	w1, [x0]
     9ac:      	ldr	w0, [sp, #0x2c]
     9b0:      	bl	0xa94 <record_event>
     9b4:      	ldr	w0, [sp, #0x10]
     9b8:      	sub	w1, w0, #0x1
     9bc:      	str	w1, [sp, #0x10]
     9c0:      	cmp	w0, #0x0
     9c4:      	b.gt	0x954 <region_pipeline+0x7c>
     9c8:      	ldr	w0, [sp, #0x14]
     9cc:      	ldp	x29, x30, [sp], #0x40
     9d0:      	ret

00000000000009d4 <region_outputs>:
     9d4:      	stp	x29, x30, [sp, #-0x30]!
     9d8:      	mov	x29, sp
     9dc:      	str	x0, [sp, #0x18]
     9e0:      	str	w1, [sp, #0x14]
     9e4:      	str	w2, [sp, #0x10]
     9e8:      	ldr	w0, [sp, #0x14]
     9ec:      	str	w0, [sp, #0x20]
     9f0:      	ldr	w0, [sp, #0x10]
     9f4:      	str	w0, [sp, #0x24]
     9f8:      	mov	w0, #0x11               // =17
     9fc:      	str	w0, [sp, #0x28]
     a00:      	ldr	w1, [sp, #0x28]
     a04:      	ldr	w0, [sp, #0x20]
     a08:      	add	w0, w1, w0
     a0c:      	str	w0, [sp, #0x28]
     a10:      	ldr	w1, [sp, #0x28]
     a14:      	mov	w0, w1
     a18:      	lsl	w0, w0, #1
     a1c:      	add	w0, w0, w1
     a20:      	ldr	w1, [sp, #0x24]
     a24:      	add	w0, w1, w0
     a28:      	str	w0, [sp, #0x20]
     a2c:      	ldr	w1, [sp, #0x20]
     a30:      	ldr	w0, [sp, #0x28]
     a34:      	sub	w0, w1, w0
     a38:      	str	w0, [sp, #0x24]
     a3c:      	ldr	w0, [sp, #0x28]
     a40:      	str	w0, [sp, #0x2c]
     a44:      	ldr	w0, [sp, #0x20]
     a48:      	str	w0, [sp, #0x14]
     a4c:      	ldr	w0, [sp, #0x24]
     a50:      	str	w0, [sp, #0x10]
     a54:      	ldr	w0, [sp, #0x14]
     a58:      	bl	0xa94 <record_event>
     a5c:      	ldr	x0, [sp, #0x18]
     a60:      	ldr	w1, [sp, #0x10]
     a64:      	str	w1, [x0]
     a68:      	ldr	x0, [sp, #0x18]
     a6c:      	add	x0, x0, #0x4
     a70:      	ldr	w1, [sp, #0x2c]
     a74:      	str	w1, [x0]
     a78:      	ldr	w1, [sp, #0x14]
     a7c:      	ldr	w0, [sp, #0x10]
     a80:      	cmp	w1, w0
     a84:      	cset	w0, eq
     a88:      	and	w0, w0, #0xff
     a8c:      	ldp	x29, x30, [sp], #0x30
     a90:      	ret

0000000000000a94 <record_event>:
     a94:      	sub	sp, sp, #0x10
     a98:      	str	w0, [sp, #0xc]
     a9c:      	adrp	x0, 0x20000 <data_start>
     aa0:      	add	x0, x0, #0x24
     aa4:      	ldr	w1, [x0]
     aa8:      	mov	w0, w1
     aac:      	lsl	w0, w0, #5
     ab0:      	add	w1, w0, w1
     ab4:      	ldr	w0, [sp, #0xc]
     ab8:      	eor	w1, w1, w0
     abc:      	adrp	x0, 0x20000 <data_start>
     ac0:      	add	x0, x0, #0x24
     ac4:      	str	w1, [x0]
     ac8:      	nop
     acc:      	add	sp, sp, #0x10
     ad0:      	ret

0000000000000ad4 <next_value>:
     ad4:      	stp	x29, x30, [sp, #-0x20]!
     ad8:      	mov	x29, sp
     adc:      	str	w0, [sp, #0x1c]
     ae0:      	ldr	w0, [sp, #0x1c]
     ae4:      	bl	0xa94 <record_event>
     ae8:      	adrp	x0, 0x20000 <data_start>
     aec:      	add	x0, x0, #0x18
     af0:      	ldr	w1, [x0, #0x4]
     af4:      	ldr	w0, [sp, #0x1c]
     af8:      	add	w1, w1, w0
     afc:      	adrp	x0, 0x20000 <data_start>
     b00:      	add	x0, x0, #0x18
     b04:      	str	w1, [x0, #0x4]
     b08:      	adrp	x0, 0x20000 <data_start>
     b0c:      	add	x0, x0, #0x18
     b10:      	ldr	w1, [x0, #0x4]
     b14:      	ldr	w0, [sp, #0x1c]
     b18:      	add	w0, w1, w0
     b1c:      	ldp	x29, x30, [sp], #0x20
     b20:      	ret

0000000000000b24 <main>:
     b24:      	sub	sp, sp, #0x70
     b28:      	stp	x29, x30, [sp, #0x60]
     b2c:      	add	x29, sp, #0x60
     b30:      	str	w0, [sp, #0xc]
     b34:      	str	x1, [sp]
     b38:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e0c0>
     b3c:      	ldr	x0, [x0, #0xfe8]
     b40:      	ldr	x1, [x0]
     b44:      	str	x1, [sp, #0x58]
     b48:      	mov	x1, #0x0                // =0
     b4c:      	ldr	w0, [sp, #0xc]
     b50:      	cmp	w0, #0x3
     b54:      	b.eq	0xb60 <main+0x3c>
     b58:      	mov	w0, #0x2                // =2
     b5c:      	b	0xd48 <main+0x224>
     b60:      	ldr	x0, [sp]
     b64:      	add	x0, x0, #0x8
     b68:      	ldr	x0, [x0]
     b6c:      	mov	w2, #0xa                // =10
     b70:      	mov	x1, #0x0                // =0
     b74:      	bl	0x730 <strtoul@plt>
     b78:      	str	x0, [sp, #0x28]
     b7c:      	ldr	x0, [sp]
     b80:      	add	x0, x0, #0x10
     b84:      	ldr	x0, [x0]
     b88:      	mov	w2, #0xa                // =10
     b8c:      	mov	x1, #0x0                // =0
     b90:      	bl	0x730 <strtoul@plt>
     b94:      	str	w0, [sp, #0x18]
     b98:      	str	wzr, [sp, #0x1c]
     b9c:      	add	x0, sp, #0x38
     ba0:      	mov	x1, x0
     ba4:      	mov	w0, #0x1                // =1
     ba8:      	bl	0x760 <clock_gettime@plt>
     bac:      	cmp	w0, #0x0
     bb0:      	b.eq	0xbbc <main+0x98>
     bb4:      	mov	w0, #0x2                // =2
     bb8:      	b	0xd48 <main+0x224>
     bbc:      	str	xzr, [sp, #0x20]
     bc0:      	b	0xc84 <main+0x160>
     bc4:      	ldr	w0, [sp, #0x18]
     bc8:      	lsl	w0, w0, #13
     bcc:      	ldr	w1, [sp, #0x18]
     bd0:      	eor	w0, w1, w0
     bd4:      	str	w0, [sp, #0x18]
     bd8:      	ldr	w0, [sp, #0x18]
     bdc:      	lsr	w0, w0, #17
     be0:      	ldr	w1, [sp, #0x18]
     be4:      	eor	w0, w1, w0
     be8:      	str	w0, [sp, #0x18]
     bec:      	ldr	w0, [sp, #0x18]
     bf0:      	lsl	w0, w0, #5
     bf4:      	ldr	w1, [sp, #0x18]
     bf8:      	eor	w0, w1, w0
     bfc:      	str	w0, [sp, #0x18]
     c00:      	ldr	x2, [sp, #0x20]
     c04:      	mov	x0, #-0x3333333333333334 // =-3689348814741910324
     c08:      	movk	x0, #0xcccd
     c0c:      	umulh	x0, x2, x0
     c10:      	lsr	x1, x0, #3
     c14:      	mov	x0, x1
     c18:      	lsl	x0, x0, #2
     c1c:      	add	x0, x0, x1
     c20:      	lsl	x0, x0, #1
     c24:      	sub	x1, x2, x0
     c28:      	mov	w0, w1
     c2c:      	sub	w0, w0, #0x1
     c30:      	mov	w2, w0
     c34:      	ldr	w1, [sp, #0x18]
     c38:      	adrp	x0, 0x20000 <data_start>
     c3c:      	add	x0, x0, #0x18
     c40:      	bl	0x8d8 <region_pipeline>
     c44:      	mov	w1, w0
     c48:      	ldr	w0, [sp, #0x1c]
     c4c:      	add	w0, w0, w1
     c50:      	str	w0, [sp, #0x1c]
     c54:      	ldr	w2, [sp, #0x1c]
     c58:      	ldr	w1, [sp, #0x18]
     c5c:      	adrp	x0, 0x20000 <data_start>
     c60:      	add	x0, x0, #0x18
     c64:      	bl	0x9d4 <region_outputs>
     c68:      	mov	w1, w0
     c6c:      	ldr	w0, [sp, #0x1c]
     c70:      	add	w0, w0, w1
     c74:      	str	w0, [sp, #0x1c]
     c78:      	ldr	x0, [sp, #0x20]
     c7c:      	add	x0, x0, #0x1
     c80:      	str	x0, [sp, #0x20]
     c84:      	ldr	x1, [sp, #0x20]
     c88:      	ldr	x0, [sp, #0x28]
     c8c:      	cmp	x1, x0
     c90:      	b.lo	0xbc4 <main+0xa0>
     c94:      	add	x0, sp, #0x48
     c98:      	mov	x1, x0
     c9c:      	mov	w0, #0x1                // =1
     ca0:      	bl	0x760 <clock_gettime@plt>
     ca4:      	cmp	w0, #0x0
     ca8:      	b.eq	0xcb4 <main+0x190>
     cac:      	mov	w0, #0x2                // =2
     cb0:      	b	0xd48 <main+0x224>
     cb4:      	ldr	x1, [sp, #0x48]
     cb8:      	ldr	x0, [sp, #0x38]
     cbc:      	sub	x0, x1, x0
     cc0:      	fmov	d0, x0
     cc4:      	scvtf	d1, d0
     cc8:      	ldr	x1, [sp, #0x50]
     ccc:      	ldr	x0, [sp, #0x40]
     cd0:      	sub	x0, x1, x0
     cd4:      	fmov	d0, x0
     cd8:      	scvtf	d0, d0
     cdc:      	adrp	x0, 0x0 <strtoul@GLIBC_2.17>
     ce0:      	ldr	d2, [x0, #0xdb0]
     ce4:      	fmul	d0, d0, d2
     ce8:      	fadd	d0, d1, d0
     cec:      	str	d0, [sp, #0x30]
     cf0:      	adrp	x0, 0x20000 <data_start>
     cf4:      	add	x0, x0, #0x18
     cf8:      	ldr	w1, [x0]
     cfc:      	adrp	x0, 0x20000 <data_start>
     d00:      	add	x0, x0, #0x18
     d04:      	ldr	w2, [x0, #0x4]
     d08:      	adrp	x0, 0x20000 <data_start>
     d0c:      	add	x0, x0, #0x18
     d10:      	ldr	w3, [x0, #0x8]
     d14:      	adrp	x0, 0x20000 <data_start>
     d18:      	add	x0, x0, #0x24
     d1c:      	ldr	w0, [x0]
     d20:      	mov	w5, w0
     d24:      	mov	w4, w3
     d28:      	mov	w3, w2
     d2c:      	mov	w2, w1
     d30:      	ldr	w1, [sp, #0x1c]
     d34:      	ldr	d0, [sp, #0x30]
     d38:      	adrp	x0, 0x0 <strtoul@GLIBC_2.17>
     d3c:      	add	x0, x0, #0xd98
     d40:      	bl	0x7a0 <printf@plt>
     d44:      	mov	w0, #0x0                // =0
     d48:      	mov	w1, w0
     d4c:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e0c0>
     d50:      	ldr	x0, [x0, #0xfe8]
     d54:      	ldr	x3, [sp, #0x58]
     d58:      	ldr	x2, [x0]
     d5c:      	subs	x3, x3, x2
     d60:      	mov	x2, #0x0                // =0
     d64:      	b.eq	0xd6c <main+0x248>
     d68:      	bl	0x770 <__stack_chk_fail@plt>
     d6c:      	mov	w0, w1
     d70:      	ldp	x29, x30, [sp, #0x60]
     d74:      	add	sp, sp, #0x70
     d78:      	ret

Disassembly of section .fini:

0000000000000d7c <_fini>:
     d7c:      	nop
     d80:      	stp	x29, x30, [sp, #-0x10]!
     d84:      	mov	x29, sp
     d88:      	ldp	x29, x30, [sp], #0x10
     d8c:      	ret
