
/work/experiments/runs/private-regions-cost-linux-20261110/gcc-O0/affine:	file format elf64-littleaarch64

Disassembly of section .init:

00000000000006f0 <_init>:
     6f0:      	nop
     6f4:      	stp	x29, x30, [sp, #-0x10]!
     6f8:      	mov	x29, sp
     6fc:      	bl	0x7f4 <call_weak_fn>
     700:      	ldp	x29, x30, [sp], #0x10
     704:      	ret

Disassembly of section .plt:

0000000000000710 <.plt>:
     710:      	stp	x16, x30, [sp, #-0x10]!
     714:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1df68>
     718:      	ldr	x17, [x16, #0xf80]
     71c:      	add	x16, x16, #0xf80
     720:      	br	x17
     724:      	nop
     728:      	nop
     72c:      	nop

0000000000000730 <strtoul@plt>:
     730:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1df68>
     734:      	ldr	x17, [x16, #0xf88]
     738:      	add	x16, x16, #0xf88
     73c:      	br	x17

0000000000000740 <__libc_start_main@plt>:
     740:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1df68>
     744:      	ldr	x17, [x16, #0xf90]
     748:      	add	x16, x16, #0xf90
     74c:      	br	x17

0000000000000750 <__cxa_finalize@plt>:
     750:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1df68>
     754:      	ldr	x17, [x16, #0xf98]
     758:      	add	x16, x16, #0xf98
     75c:      	br	x17

0000000000000760 <clock_gettime@plt>:
     760:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1df68>
     764:      	ldr	x17, [x16, #0xfa0]
     768:      	add	x16, x16, #0xfa0
     76c:      	br	x17

0000000000000770 <__stack_chk_fail@plt>:
     770:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1df68>
     774:      	ldr	x17, [x16, #0xfa8]
     778:      	add	x16, x16, #0xfa8
     77c:      	br	x17

0000000000000780 <__gmon_start__@plt>:
     780:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1df68>
     784:      	ldr	x17, [x16, #0xfb0]
     788:      	add	x16, x16, #0xfb0
     78c:      	br	x17

0000000000000790 <abort@plt>:
     790:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1df68>
     794:      	ldr	x17, [x16, #0xfb8]
     798:      	add	x16, x16, #0xfb8
     79c:      	br	x17

00000000000007a0 <printf@plt>:
     7a0:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1df68>
     7a4:      	ldr	x17, [x16, #0xfc0]
     7a8:      	add	x16, x16, #0xfc0
     7ac:      	br	x17

Disassembly of section .text:

00000000000007c0 <_start>:
     7c0:      	nop
     7c4:      	mov	x29, #0x0               // =0
     7c8:      	mov	x30, #0x0               // =0
     7cc:      	mov	x5, x0
     7d0:      	ldr	x1, [sp]
     7d4:      	add	x2, sp, #0x8
     7d8:      	mov	x6, sp
     7dc:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1df68>
     7e0:      	ldr	x0, [x0, #0xff0]
     7e4:      	mov	x3, #0x0                // =0
     7e8:      	mov	x4, #0x0                // =0
     7ec:      	bl	0x740 <__libc_start_main@plt>
     7f0:      	bl	0x790 <abort@plt>

00000000000007f4 <call_weak_fn>:
     7f4:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1df68>
     7f8:      	ldr	x0, [x0, #0xfe0]
     7fc:      	cbz	x0, 0x804 <call_weak_fn+0x10>
     800:      	b	0x780 <__gmon_start__@plt>
     804:      	ret
     808:      	nop
     80c:      	nop

0000000000000810 <deregister_tm_clones>:
     810:      	adrp	x0, 0x20000 <data_start>
     814:      	add	x0, x0, #0x10
     818:      	adrp	x1, 0x20000 <data_start>
     81c:      	add	x1, x1, #0x10
     820:      	cmp	x1, x0
     824:      	b.eq	0x83c <deregister_tm_clones+0x2c>
     828:      	adrp	x1, 0x1f000 <__FRAME_END__+0x1df68>
     82c:      	ldr	x1, [x1, #0xfd0]
     830:      	cbz	x1, 0x83c <deregister_tm_clones+0x2c>
     834:      	mov	x16, x1
     838:      	br	x16
     83c:      	ret

0000000000000840 <register_tm_clones>:
     840:      	adrp	x0, 0x20000 <data_start>
     844:      	add	x0, x0, #0x10
     848:      	adrp	x1, 0x20000 <data_start>
     84c:      	add	x1, x1, #0x10
     850:      	sub	x1, x1, x0
     854:      	lsr	x2, x1, #63
     858:      	add	x1, x2, x1, asr #3
     85c:      	asr	x1, x1, #1
     860:      	cbz	x1, 0x878 <register_tm_clones+0x38>
     864:      	adrp	x2, 0x1f000 <__FRAME_END__+0x1df68>
     868:      	ldr	x2, [x2, #0xff8]
     86c:      	cbz	x2, 0x878 <register_tm_clones+0x38>
     870:      	mov	x16, x2
     874:      	br	x16
     878:      	ret
     87c:      	nop

0000000000000880 <__do_global_dtors_aux>:
     880:      	paciasp
     884:      	stp	x29, x30, [sp, #-0x20]!
     888:      	mov	x29, sp
     88c:      	str	x19, [sp, #0x10]
     890:      	adrp	x19, 0x20000 <data_start>
     894:      	ldrb	w0, [x19, #0x10]
     898:      	tbnz	w0, #0x0, 0x8c0 <__do_global_dtors_aux+0x40>
     89c:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1df68>
     8a0:      	ldr	x0, [x0, #0xfd8]
     8a4:      	cbz	x0, 0x8b4 <__do_global_dtors_aux+0x34>
     8a8:      	adrp	x0, 0x20000 <data_start>
     8ac:      	ldr	x0, [x0, #0x8]
     8b0:      	bl	0x750 <__cxa_finalize@plt>
     8b4:      	bl	0x810 <deregister_tm_clones>
     8b8:      	mov	w0, #0x1                // =1
     8bc:      	strb	w0, [x19, #0x10]
     8c0:      	ldr	x19, [sp, #0x10]
     8c4:      	ldp	x29, x30, [sp], #0x20
     8c8:      	autiasp
     8cc:      	ret

00000000000008d0 <frame_dummy>:
     8d0:      	bti	c
     8d4:      	b	0x840 <register_tm_clones>

00000000000008d8 <region_pipeline>:
     8d8:      	stp	x29, x30, [sp, #-0x40]!
     8dc:      	mov	x29, sp
     8e0:      	str	x0, [sp, #0x18]
     8e4:      	str	w1, [sp, #0x14]
     8e8:      	str	w2, [sp, #0x10]
     8ec:      	ldr	x0, [sp, #0x18]
     8f0:      	ldr	w0, [x0]
     8f4:      	str	w0, [sp, #0x2c]
     8f8:      	ldr	w1, [sp, #0x14]
     8fc:      	mov	w0, #0x86a1             // =34465
     900:      	movk	w0, #0x487e, lsl #16
     904:      	mul	w1, w1, w0
     908:      	mov	w0, #0x6ab4             // =27316
     90c:      	movk	w0, #0x72f8, lsl #16
     910:      	add	w0, w1, w0
     914:      	str	w0, [sp, #0x30]
     918:      	ldr	w1, [sp, #0x2c]
     91c:      	mov	w0, #0x86a1             // =34465
     920:      	movk	w0, #0x487e, lsl #16
     924:      	mul	w1, w1, w0
     928:      	mov	w0, #0x6ab4             // =27316
     92c:      	movk	w0, #0x72f8, lsl #16
     930:      	add	w0, w1, w0
     934:      	str	w0, [sp, #0x34]
     938:      	ldr	w1, [sp, #0x30]
     93c:      	ldr	w0, [sp, #0x34]
     940:      	add	w1, w1, w0
     944:      	mov	w0, #0x954c             // =38220
     948:      	movk	w0, #0x8d07, lsl #16
     94c:      	add	w0, w1, w0
     950:      	str	w0, [sp, #0x30]
     954:      	ldr	w1, [sp, #0x30]
     958:      	mov	w0, w1
     95c:      	lsl	w0, w0, #1
     960:      	add	w1, w0, w1
     964:      	mov	w0, #0xf383             // =62339
     968:      	movk	w0, #0x377e, lsl #16
     96c:      	add	w0, w1, w0
     970:      	str	w0, [sp, #0x30]
     974:      	ldr	w1, [sp, #0x30]
     978:      	mov	w0, #0xdd61             // =56673
     97c:      	movk	w0, #0x3c16, lsl #16
     980:      	mul	w1, w1, w0
     984:      	mov	w0, #0x2dcc             // =11724
     988:      	movk	w0, #0xa04a, lsl #16
     98c:      	add	w0, w1, w0
     990:      	str	w0, [sp, #0x14]
     994:      	ldr	w0, [sp, #0x14]
     998:      	bl	0xbec <record_event>
     99c:      	ldr	w0, [sp, #0x10]
     9a0:      	cmp	w0, #0x0
     9a4:      	b.ge	0xa6c <region_pipeline+0x194>
     9a8:      	ldr	w0, [sp, #0x14]
     9ac:      	b	0xa84 <region_pipeline+0x1ac>
     9b0:      	ldr	w0, [sp, #0x14]
     9b4:      	bl	0xc2c <next_value>
     9b8:      	str	w0, [sp, #0x2c]
     9bc:      	ldr	w1, [sp, #0x14]
     9c0:      	mov	w0, #0x7ae3             // =31459
     9c4:      	movk	w0, #0xa12f, lsl #16
     9c8:      	mul	w1, w1, w0
     9cc:      	mov	w0, #0x8acb             // =35531
     9d0:      	movk	w0, #0x34e4, lsl #16
     9d4:      	add	w0, w1, w0
     9d8:      	str	w0, [sp, #0x38]
     9dc:      	ldr	w1, [sp, #0x2c]
     9e0:      	mov	w0, #0x7ae3             // =31459
     9e4:      	movk	w0, #0xa12f, lsl #16
     9e8:      	mul	w1, w1, w0
     9ec:      	mov	w0, #0x8acb             // =35531
     9f0:      	movk	w0, #0x34e4, lsl #16
     9f4:      	add	w0, w1, w0
     9f8:      	str	w0, [sp, #0x3c]
     9fc:      	ldr	w1, [sp, #0x38]
     a00:      	ldr	w0, [sp, #0x3c]
     a04:      	add	w1, w1, w0
     a08:      	mov	w0, #0x7535             // =30005
     a0c:      	movk	w0, #0xcb1b, lsl #16
     a10:      	add	w0, w1, w0
     a14:      	str	w0, [sp, #0x38]
     a18:      	ldr	w1, [sp, #0x38]
     a1c:      	mov	w0, w1
     a20:      	lsl	w0, w0, #2
     a24:      	add	w1, w0, w1
     a28:      	mov	w0, #0x789f             // =30879
     a2c:      	movk	w0, #0xc421, lsl #16
     a30:      	add	w0, w1, w0
     a34:      	str	w0, [sp, #0x38]
     a38:      	ldr	w1, [sp, #0x38]
     a3c:      	mov	w0, #0x9acb             // =39627
     a40:      	movk	w0, #0xfd6f, lsl #16
     a44:      	mul	w1, w1, w0
     a48:      	mov	w0, #0xd307             // =54023
     a4c:      	movk	w0, #0xc642, lsl #16
     a50:      	add	w0, w1, w0
     a54:      	str	w0, [sp, #0x14]
     a58:      	ldr	x0, [sp, #0x18]
     a5c:      	ldr	w1, [sp, #0x14]
     a60:      	str	w1, [x0]
     a64:      	ldr	w0, [sp, #0x2c]
     a68:      	bl	0xbec <record_event>
     a6c:      	ldr	w0, [sp, #0x10]
     a70:      	sub	w1, w0, #0x1
     a74:      	str	w1, [sp, #0x10]
     a78:      	cmp	w0, #0x0
     a7c:      	b.gt	0x9b0 <region_pipeline+0xd8>
     a80:      	ldr	w0, [sp, #0x14]
     a84:      	ldp	x29, x30, [sp], #0x40
     a88:      	ret

0000000000000a8c <region_outputs>:
     a8c:      	stp	x29, x30, [sp, #-0x30]!
     a90:      	mov	x29, sp
     a94:      	str	x0, [sp, #0x18]
     a98:      	str	w1, [sp, #0x14]
     a9c:      	str	w2, [sp, #0x10]
     aa0:      	ldr	w1, [sp, #0x14]
     aa4:      	mov	w0, #0xbc0f             // =48143
     aa8:      	movk	w0, #0x5604, lsl #16
     aac:      	mul	w1, w1, w0
     ab0:      	mov	w0, #0x75de             // =30174
     ab4:      	movk	w0, #0x59b6, lsl #16
     ab8:      	add	w0, w1, w0
     abc:      	str	w0, [sp, #0x20]
     ac0:      	ldr	w1, [sp, #0x10]
     ac4:      	mov	w0, #0xbc0f             // =48143
     ac8:      	movk	w0, #0x5604, lsl #16
     acc:      	mul	w1, w1, w0
     ad0:      	mov	w0, #0x75de             // =30174
     ad4:      	movk	w0, #0x59b6, lsl #16
     ad8:      	add	w0, w1, w0
     adc:      	str	w0, [sp, #0x24]
     ae0:      	mov	w0, #0xf2dd             // =62173
     ae4:      	movk	w0, #0x1006, lsl #16
     ae8:      	str	w0, [sp, #0x28]
     aec:      	ldr	w1, [sp, #0x28]
     af0:      	ldr	w0, [sp, #0x20]
     af4:      	add	w1, w1, w0
     af8:      	mov	w0, #0x8a22             // =35362
     afc:      	movk	w0, #0xa649, lsl #16
     b00:      	add	w0, w1, w0
     b04:      	str	w0, [sp, #0x28]
     b08:      	ldr	w1, [sp, #0x28]
     b0c:      	mov	w0, w1
     b10:      	lsl	w0, w0, #1
     b14:      	add	w1, w0, w1
     b18:      	ldr	w0, [sp, #0x24]
     b1c:      	add	w1, w1, w0
     b20:      	mov	w0, #0x9e66             // =40550
     b24:      	movk	w0, #0xf2dc, lsl #16
     b28:      	add	w0, w1, w0
     b2c:      	str	w0, [sp, #0x20]
     b30:      	ldr	w1, [sp, #0x20]
     b34:      	ldr	w0, [sp, #0x28]
     b38:      	sub	w1, w1, w0
     b3c:      	mov	w0, #0x75de             // =30174
     b40:      	movk	w0, #0x59b6, lsl #16
     b44:      	add	w0, w1, w0
     b48:      	str	w0, [sp, #0x24]
     b4c:      	ldr	w1, [sp, #0x28]
     b50:      	mov	w0, #0xb2ef             // =45807
     b54:      	movk	w0, #0x20e, lsl #16
     b58:      	mul	w1, w1, w0
     b5c:      	mov	w0, #0x99be             // =39358
     b60:      	movk	w0, #0x328f, lsl #16
     b64:      	add	w0, w1, w0
     b68:      	str	w0, [sp, #0x2c]
     b6c:      	ldr	w1, [sp, #0x20]
     b70:      	mov	w0, #0xb2ef             // =45807
     b74:      	movk	w0, #0x20e, lsl #16
     b78:      	mul	w1, w1, w0
     b7c:      	mov	w0, #0x99be             // =39358
     b80:      	movk	w0, #0x328f, lsl #16
     b84:      	add	w0, w1, w0
     b88:      	str	w0, [sp, #0x14]
     b8c:      	ldr	w1, [sp, #0x24]
     b90:      	mov	w0, #0xb2ef             // =45807
     b94:      	movk	w0, #0x20e, lsl #16
     b98:      	mul	w1, w1, w0
     b9c:      	mov	w0, #0x99be             // =39358
     ba0:      	movk	w0, #0x328f, lsl #16
     ba4:      	add	w0, w1, w0
     ba8:      	str	w0, [sp, #0x10]
     bac:      	ldr	w0, [sp, #0x14]
     bb0:      	bl	0xbec <record_event>
     bb4:      	ldr	x0, [sp, #0x18]
     bb8:      	ldr	w1, [sp, #0x10]
     bbc:      	str	w1, [x0]
     bc0:      	ldr	x0, [sp, #0x18]
     bc4:      	add	x0, x0, #0x4
     bc8:      	ldr	w1, [sp, #0x2c]
     bcc:      	str	w1, [x0]
     bd0:      	ldr	w1, [sp, #0x14]
     bd4:      	ldr	w0, [sp, #0x10]
     bd8:      	cmp	w1, w0
     bdc:      	cset	w0, eq
     be0:      	and	w0, w0, #0xff
     be4:      	ldp	x29, x30, [sp], #0x30
     be8:      	ret

0000000000000bec <record_event>:
     bec:      	sub	sp, sp, #0x10
     bf0:      	str	w0, [sp, #0xc]
     bf4:      	adrp	x0, 0x20000 <data_start>
     bf8:      	add	x0, x0, #0x24
     bfc:      	ldr	w1, [x0]
     c00:      	mov	w0, w1
     c04:      	lsl	w0, w0, #5
     c08:      	add	w1, w0, w1
     c0c:      	ldr	w0, [sp, #0xc]
     c10:      	eor	w1, w1, w0
     c14:      	adrp	x0, 0x20000 <data_start>
     c18:      	add	x0, x0, #0x24
     c1c:      	str	w1, [x0]
     c20:      	nop
     c24:      	add	sp, sp, #0x10
     c28:      	ret

0000000000000c2c <next_value>:
     c2c:      	stp	x29, x30, [sp, #-0x20]!
     c30:      	mov	x29, sp
     c34:      	str	w0, [sp, #0x1c]
     c38:      	ldr	w0, [sp, #0x1c]
     c3c:      	bl	0xbec <record_event>
     c40:      	adrp	x0, 0x20000 <data_start>
     c44:      	add	x0, x0, #0x18
     c48:      	ldr	w1, [x0, #0x4]
     c4c:      	ldr	w0, [sp, #0x1c]
     c50:      	add	w1, w1, w0
     c54:      	adrp	x0, 0x20000 <data_start>
     c58:      	add	x0, x0, #0x18
     c5c:      	str	w1, [x0, #0x4]
     c60:      	adrp	x0, 0x20000 <data_start>
     c64:      	add	x0, x0, #0x18
     c68:      	ldr	w1, [x0, #0x4]
     c6c:      	ldr	w0, [sp, #0x1c]
     c70:      	add	w0, w1, w0
     c74:      	ldp	x29, x30, [sp], #0x20
     c78:      	ret

0000000000000c7c <main>:
     c7c:      	sub	sp, sp, #0x70
     c80:      	stp	x29, x30, [sp, #0x60]
     c84:      	add	x29, sp, #0x60
     c88:      	str	w0, [sp, #0xc]
     c8c:      	str	x1, [sp]
     c90:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1df68>
     c94:      	ldr	x0, [x0, #0xfe8]
     c98:      	ldr	x1, [x0]
     c9c:      	str	x1, [sp, #0x58]
     ca0:      	mov	x1, #0x0                // =0
     ca4:      	ldr	w0, [sp, #0xc]
     ca8:      	cmp	w0, #0x3
     cac:      	b.eq	0xcb8 <main+0x3c>
     cb0:      	mov	w0, #0x2                // =2
     cb4:      	b	0xea0 <main+0x224>
     cb8:      	ldr	x0, [sp]
     cbc:      	add	x0, x0, #0x8
     cc0:      	ldr	x0, [x0]
     cc4:      	mov	w2, #0xa                // =10
     cc8:      	mov	x1, #0x0                // =0
     ccc:      	bl	0x730 <strtoul@plt>
     cd0:      	str	x0, [sp, #0x28]
     cd4:      	ldr	x0, [sp]
     cd8:      	add	x0, x0, #0x10
     cdc:      	ldr	x0, [x0]
     ce0:      	mov	w2, #0xa                // =10
     ce4:      	mov	x1, #0x0                // =0
     ce8:      	bl	0x730 <strtoul@plt>
     cec:      	str	w0, [sp, #0x18]
     cf0:      	str	wzr, [sp, #0x1c]
     cf4:      	add	x0, sp, #0x38
     cf8:      	mov	x1, x0
     cfc:      	mov	w0, #0x1                // =1
     d00:      	bl	0x760 <clock_gettime@plt>
     d04:      	cmp	w0, #0x0
     d08:      	b.eq	0xd14 <main+0x98>
     d0c:      	mov	w0, #0x2                // =2
     d10:      	b	0xea0 <main+0x224>
     d14:      	str	xzr, [sp, #0x20]
     d18:      	b	0xddc <main+0x160>
     d1c:      	ldr	w0, [sp, #0x18]
     d20:      	lsl	w0, w0, #13
     d24:      	ldr	w1, [sp, #0x18]
     d28:      	eor	w0, w1, w0
     d2c:      	str	w0, [sp, #0x18]
     d30:      	ldr	w0, [sp, #0x18]
     d34:      	lsr	w0, w0, #17
     d38:      	ldr	w1, [sp, #0x18]
     d3c:      	eor	w0, w1, w0
     d40:      	str	w0, [sp, #0x18]
     d44:      	ldr	w0, [sp, #0x18]
     d48:      	lsl	w0, w0, #5
     d4c:      	ldr	w1, [sp, #0x18]
     d50:      	eor	w0, w1, w0
     d54:      	str	w0, [sp, #0x18]
     d58:      	ldr	x2, [sp, #0x20]
     d5c:      	mov	x0, #-0x3333333333333334 // =-3689348814741910324
     d60:      	movk	x0, #0xcccd
     d64:      	umulh	x0, x2, x0
     d68:      	lsr	x1, x0, #3
     d6c:      	mov	x0, x1
     d70:      	lsl	x0, x0, #2
     d74:      	add	x0, x0, x1
     d78:      	lsl	x0, x0, #1
     d7c:      	sub	x1, x2, x0
     d80:      	mov	w0, w1
     d84:      	sub	w0, w0, #0x1
     d88:      	mov	w2, w0
     d8c:      	ldr	w1, [sp, #0x18]
     d90:      	adrp	x0, 0x20000 <data_start>
     d94:      	add	x0, x0, #0x18
     d98:      	bl	0x8d8 <region_pipeline>
     d9c:      	mov	w1, w0
     da0:      	ldr	w0, [sp, #0x1c]
     da4:      	add	w0, w0, w1
     da8:      	str	w0, [sp, #0x1c]
     dac:      	ldr	w2, [sp, #0x1c]
     db0:      	ldr	w1, [sp, #0x18]
     db4:      	adrp	x0, 0x20000 <data_start>
     db8:      	add	x0, x0, #0x18
     dbc:      	bl	0xa8c <region_outputs>
     dc0:      	mov	w1, w0
     dc4:      	ldr	w0, [sp, #0x1c]
     dc8:      	add	w0, w0, w1
     dcc:      	str	w0, [sp, #0x1c]
     dd0:      	ldr	x0, [sp, #0x20]
     dd4:      	add	x0, x0, #0x1
     dd8:      	str	x0, [sp, #0x20]
     ddc:      	ldr	x1, [sp, #0x20]
     de0:      	ldr	x0, [sp, #0x28]
     de4:      	cmp	x1, x0
     de8:      	b.lo	0xd1c <main+0xa0>
     dec:      	add	x0, sp, #0x48
     df0:      	mov	x1, x0
     df4:      	mov	w0, #0x1                // =1
     df8:      	bl	0x760 <clock_gettime@plt>
     dfc:      	cmp	w0, #0x0
     e00:      	b.eq	0xe0c <main+0x190>
     e04:      	mov	w0, #0x2                // =2
     e08:      	b	0xea0 <main+0x224>
     e0c:      	ldr	x1, [sp, #0x48]
     e10:      	ldr	x0, [sp, #0x38]
     e14:      	sub	x0, x1, x0
     e18:      	fmov	d0, x0
     e1c:      	scvtf	d1, d0
     e20:      	ldr	x1, [sp, #0x50]
     e24:      	ldr	x0, [sp, #0x40]
     e28:      	sub	x0, x1, x0
     e2c:      	fmov	d0, x0
     e30:      	scvtf	d0, d0
     e34:      	adrp	x0, 0x0 <strtoul@GLIBC_2.17>
     e38:      	ldr	d2, [x0, #0xf08]
     e3c:      	fmul	d0, d0, d2
     e40:      	fadd	d0, d1, d0
     e44:      	str	d0, [sp, #0x30]
     e48:      	adrp	x0, 0x20000 <data_start>
     e4c:      	add	x0, x0, #0x18
     e50:      	ldr	w1, [x0]
     e54:      	adrp	x0, 0x20000 <data_start>
     e58:      	add	x0, x0, #0x18
     e5c:      	ldr	w2, [x0, #0x4]
     e60:      	adrp	x0, 0x20000 <data_start>
     e64:      	add	x0, x0, #0x18
     e68:      	ldr	w3, [x0, #0x8]
     e6c:      	adrp	x0, 0x20000 <data_start>
     e70:      	add	x0, x0, #0x24
     e74:      	ldr	w0, [x0]
     e78:      	mov	w5, w0
     e7c:      	mov	w4, w3
     e80:      	mov	w3, w2
     e84:      	mov	w2, w1
     e88:      	ldr	w1, [sp, #0x1c]
     e8c:      	ldr	d0, [sp, #0x30]
     e90:      	adrp	x0, 0x0 <strtoul@GLIBC_2.17>
     e94:      	add	x0, x0, #0xef0
     e98:      	bl	0x7a0 <printf@plt>
     e9c:      	mov	w0, #0x0                // =0
     ea0:      	mov	w1, w0
     ea4:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1df68>
     ea8:      	ldr	x0, [x0, #0xfe8]
     eac:      	ldr	x3, [sp, #0x58]
     eb0:      	ldr	x2, [x0]
     eb4:      	subs	x3, x3, x2
     eb8:      	mov	x2, #0x0                // =0
     ebc:      	b.eq	0xec4 <main+0x248>
     ec0:      	bl	0x770 <__stack_chk_fail@plt>
     ec4:      	mov	w0, w1
     ec8:      	ldp	x29, x30, [sp, #0x60]
     ecc:      	add	sp, sp, #0x70
     ed0:      	ret

Disassembly of section .fini:

0000000000000ed4 <_fini>:
     ed4:      	nop
     ed8:      	stp	x29, x30, [sp, #-0x10]!
     edc:      	mov	x29, sp
     ee0:      	ldp	x29, x30, [sp], #0x10
     ee4:      	ret
