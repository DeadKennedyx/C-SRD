
/work/experiments/runs/private-regions-cost-linux-20261110/gcc-O0/original:	file format elf64-littleaarch64

Disassembly of section .init:

00000000000006f0 <_init>:
     6f0:      	nop
     6f4:      	stp	x29, x30, [sp, #-0x10]!
     6f8:      	mov	x29, sp
     6fc:      	bl	0x7f4 <call_weak_fn>
     700:      	ldp	x29, x30, [sp], #0x10
     704:      	ret

Disassembly of section .plt:

0000000000000710 <.plt>:
     710:      	stp	x16, x30, [sp, #-0x10]!
     714:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e118>
     718:      	ldr	x17, [x16, #0xf80]
     71c:      	add	x16, x16, #0xf80
     720:      	br	x17
     724:      	nop
     728:      	nop
     72c:      	nop

0000000000000730 <strtoul@plt>:
     730:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e118>
     734:      	ldr	x17, [x16, #0xf88]
     738:      	add	x16, x16, #0xf88
     73c:      	br	x17

0000000000000740 <__libc_start_main@plt>:
     740:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e118>
     744:      	ldr	x17, [x16, #0xf90]
     748:      	add	x16, x16, #0xf90
     74c:      	br	x17

0000000000000750 <__cxa_finalize@plt>:
     750:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e118>
     754:      	ldr	x17, [x16, #0xf98]
     758:      	add	x16, x16, #0xf98
     75c:      	br	x17

0000000000000760 <clock_gettime@plt>:
     760:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e118>
     764:      	ldr	x17, [x16, #0xfa0]
     768:      	add	x16, x16, #0xfa0
     76c:      	br	x17

0000000000000770 <__stack_chk_fail@plt>:
     770:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e118>
     774:      	ldr	x17, [x16, #0xfa8]
     778:      	add	x16, x16, #0xfa8
     77c:      	br	x17

0000000000000780 <__gmon_start__@plt>:
     780:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e118>
     784:      	ldr	x17, [x16, #0xfb0]
     788:      	add	x16, x16, #0xfb0
     78c:      	br	x17

0000000000000790 <abort@plt>:
     790:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e118>
     794:      	ldr	x17, [x16, #0xfb8]
     798:      	add	x16, x16, #0xfb8
     79c:      	br	x17

00000000000007a0 <printf@plt>:
     7a0:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e118>
     7a4:      	ldr	x17, [x16, #0xfc0]
     7a8:      	add	x16, x16, #0xfc0
     7ac:      	br	x17

Disassembly of section .text:

00000000000007c0 <_start>:
     7c0:      	nop
     7c4:      	mov	x29, #0x0               // =0
     7c8:      	mov	x30, #0x0               // =0
     7cc:      	mov	x5, x0
     7d0:      	ldr	x1, [sp]
     7d4:      	add	x2, sp, #0x8
     7d8:      	mov	x6, sp
     7dc:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e118>
     7e0:      	ldr	x0, [x0, #0xff0]
     7e4:      	mov	x3, #0x0                // =0
     7e8:      	mov	x4, #0x0                // =0
     7ec:      	bl	0x740 <__libc_start_main@plt>
     7f0:      	bl	0x790 <abort@plt>

00000000000007f4 <call_weak_fn>:
     7f4:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e118>
     7f8:      	ldr	x0, [x0, #0xfe0]
     7fc:      	cbz	x0, 0x804 <call_weak_fn+0x10>
     800:      	b	0x780 <__gmon_start__@plt>
     804:      	ret
     808:      	nop
     80c:      	nop

0000000000000810 <deregister_tm_clones>:
     810:      	adrp	x0, 0x20000 <data_start>
     814:      	add	x0, x0, #0x10
     818:      	adrp	x1, 0x20000 <data_start>
     81c:      	add	x1, x1, #0x10
     820:      	cmp	x1, x0
     824:      	b.eq	0x83c <deregister_tm_clones+0x2c>
     828:      	adrp	x1, 0x1f000 <__FRAME_END__+0x1e118>
     82c:      	ldr	x1, [x1, #0xfd0]
     830:      	cbz	x1, 0x83c <deregister_tm_clones+0x2c>
     834:      	mov	x16, x1
     838:      	br	x16
     83c:      	ret

0000000000000840 <register_tm_clones>:
     840:      	adrp	x0, 0x20000 <data_start>
     844:      	add	x0, x0, #0x10
     848:      	adrp	x1, 0x20000 <data_start>
     84c:      	add	x1, x1, #0x10
     850:      	sub	x1, x1, x0
     854:      	lsr	x2, x1, #63
     858:      	add	x1, x2, x1, asr #3
     85c:      	asr	x1, x1, #1
     860:      	cbz	x1, 0x878 <register_tm_clones+0x38>
     864:      	adrp	x2, 0x1f000 <__FRAME_END__+0x1e118>
     868:      	ldr	x2, [x2, #0xff8]
     86c:      	cbz	x2, 0x878 <register_tm_clones+0x38>
     870:      	mov	x16, x2
     874:      	br	x16
     878:      	ret
     87c:      	nop

0000000000000880 <__do_global_dtors_aux>:
     880:      	paciasp
     884:      	stp	x29, x30, [sp, #-0x20]!
     888:      	mov	x29, sp
     88c:      	str	x19, [sp, #0x10]
     890:      	adrp	x19, 0x20000 <data_start>
     894:      	ldrb	w0, [x19, #0x10]
     898:      	tbnz	w0, #0x0, 0x8c0 <__do_global_dtors_aux+0x40>
     89c:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e118>
     8a0:      	ldr	x0, [x0, #0xfd8]
     8a4:      	cbz	x0, 0x8b4 <__do_global_dtors_aux+0x34>
     8a8:      	adrp	x0, 0x20000 <data_start>
     8ac:      	ldr	x0, [x0, #0x8]
     8b0:      	bl	0x750 <__cxa_finalize@plt>
     8b4:      	bl	0x810 <deregister_tm_clones>
     8b8:      	mov	w0, #0x1                // =1
     8bc:      	strb	w0, [x19, #0x10]
     8c0:      	ldr	x19, [sp, #0x10]
     8c4:      	ldp	x29, x30, [sp], #0x20
     8c8:      	autiasp
     8cc:      	ret

00000000000008d0 <frame_dummy>:
     8d0:      	bti	c
     8d4:      	b	0x840 <register_tm_clones>

00000000000008d8 <region_pipeline>:
     8d8:      	stp	x29, x30, [sp, #-0x30]!
     8dc:      	mov	x29, sp
     8e0:      	str	x0, [sp, #0x18]
     8e4:      	str	w1, [sp, #0x14]
     8e8:      	str	w2, [sp, #0x10]
     8ec:      	ldr	x0, [sp, #0x18]
     8f0:      	ldr	w0, [x0]
     8f4:      	str	w0, [sp, #0x2c]
     8f8:      	ldr	w1, [sp, #0x14]
     8fc:      	ldr	w0, [sp, #0x2c]
     900:      	add	w0, w1, w0
     904:      	str	w0, [sp, #0x14]
     908:      	ldr	w1, [sp, #0x14]
     90c:      	mov	w0, w1
     910:      	lsl	w0, w0, #1
     914:      	add	w0, w0, w1
     918:      	add	w0, w0, #0xb
     91c:      	str	w0, [sp, #0x14]
     920:      	ldr	w0, [sp, #0x14]
     924:      	bl	0xa3c <record_event>
     928:      	ldr	w0, [sp, #0x10]
     92c:      	cmp	w0, #0x0
     930:      	b.ge	0x984 <region_pipeline+0xac>
     934:      	ldr	w0, [sp, #0x14]
     938:      	b	0x99c <region_pipeline+0xc4>
     93c:      	ldr	w0, [sp, #0x14]
     940:      	bl	0xa7c <next_value>
     944:      	str	w0, [sp, #0x2c]
     948:      	ldr	w1, [sp, #0x14]
     94c:      	ldr	w0, [sp, #0x2c]
     950:      	add	w0, w1, w0
     954:      	str	w0, [sp, #0x14]
     958:      	ldr	w1, [sp, #0x14]
     95c:      	mov	w0, w1
     960:      	lsl	w0, w0, #2
     964:      	add	w0, w0, w1
     968:      	sub	w0, w0, #0x7
     96c:      	str	w0, [sp, #0x14]
     970:      	ldr	x0, [sp, #0x18]
     974:      	ldr	w1, [sp, #0x14]
     978:      	str	w1, [x0]
     97c:      	ldr	w0, [sp, #0x2c]
     980:      	bl	0xa3c <record_event>
     984:      	ldr	w0, [sp, #0x10]
     988:      	sub	w1, w0, #0x1
     98c:      	str	w1, [sp, #0x10]
     990:      	cmp	w0, #0x0
     994:      	b.gt	0x93c <region_pipeline+0x64>
     998:      	ldr	w0, [sp, #0x14]
     99c:      	ldp	x29, x30, [sp], #0x30
     9a0:      	ret

00000000000009a4 <region_outputs>:
     9a4:      	stp	x29, x30, [sp, #-0x30]!
     9a8:      	mov	x29, sp
     9ac:      	str	x0, [sp, #0x18]
     9b0:      	str	w1, [sp, #0x14]
     9b4:      	str	w2, [sp, #0x10]
     9b8:      	mov	w0, #0x11               // =17
     9bc:      	str	w0, [sp, #0x2c]
     9c0:      	ldr	w1, [sp, #0x2c]
     9c4:      	ldr	w0, [sp, #0x14]
     9c8:      	add	w0, w1, w0
     9cc:      	str	w0, [sp, #0x2c]
     9d0:      	ldr	w1, [sp, #0x2c]
     9d4:      	mov	w0, w1
     9d8:      	lsl	w0, w0, #1
     9dc:      	add	w0, w0, w1
     9e0:      	ldr	w1, [sp, #0x10]
     9e4:      	add	w0, w1, w0
     9e8:      	str	w0, [sp, #0x14]
     9ec:      	ldr	w1, [sp, #0x14]
     9f0:      	ldr	w0, [sp, #0x2c]
     9f4:      	sub	w0, w1, w0
     9f8:      	str	w0, [sp, #0x10]
     9fc:      	ldr	w0, [sp, #0x14]
     a00:      	bl	0xa3c <record_event>
     a04:      	ldr	x0, [sp, #0x18]
     a08:      	ldr	w1, [sp, #0x10]
     a0c:      	str	w1, [x0]
     a10:      	ldr	x0, [sp, #0x18]
     a14:      	add	x0, x0, #0x4
     a18:      	ldr	w1, [sp, #0x2c]
     a1c:      	str	w1, [x0]
     a20:      	ldr	w1, [sp, #0x14]
     a24:      	ldr	w0, [sp, #0x10]
     a28:      	cmp	w1, w0
     a2c:      	cset	w0, eq
     a30:      	and	w0, w0, #0xff
     a34:      	ldp	x29, x30, [sp], #0x30
     a38:      	ret

0000000000000a3c <record_event>:
     a3c:      	sub	sp, sp, #0x10
     a40:      	str	w0, [sp, #0xc]
     a44:      	adrp	x0, 0x20000 <data_start>
     a48:      	add	x0, x0, #0x24
     a4c:      	ldr	w1, [x0]
     a50:      	mov	w0, w1
     a54:      	lsl	w0, w0, #5
     a58:      	add	w1, w0, w1
     a5c:      	ldr	w0, [sp, #0xc]
     a60:      	eor	w1, w1, w0
     a64:      	adrp	x0, 0x20000 <data_start>
     a68:      	add	x0, x0, #0x24
     a6c:      	str	w1, [x0]
     a70:      	nop
     a74:      	add	sp, sp, #0x10
     a78:      	ret

0000000000000a7c <next_value>:
     a7c:      	stp	x29, x30, [sp, #-0x20]!
     a80:      	mov	x29, sp
     a84:      	str	w0, [sp, #0x1c]
     a88:      	ldr	w0, [sp, #0x1c]
     a8c:      	bl	0xa3c <record_event>
     a90:      	adrp	x0, 0x20000 <data_start>
     a94:      	add	x0, x0, #0x18
     a98:      	ldr	w1, [x0, #0x4]
     a9c:      	ldr	w0, [sp, #0x1c]
     aa0:      	add	w1, w1, w0
     aa4:      	adrp	x0, 0x20000 <data_start>
     aa8:      	add	x0, x0, #0x18
     aac:      	str	w1, [x0, #0x4]
     ab0:      	adrp	x0, 0x20000 <data_start>
     ab4:      	add	x0, x0, #0x18
     ab8:      	ldr	w1, [x0, #0x4]
     abc:      	ldr	w0, [sp, #0x1c]
     ac0:      	add	w0, w1, w0
     ac4:      	ldp	x29, x30, [sp], #0x20
     ac8:      	ret

0000000000000acc <main>:
     acc:      	sub	sp, sp, #0x70
     ad0:      	stp	x29, x30, [sp, #0x60]
     ad4:      	add	x29, sp, #0x60
     ad8:      	str	w0, [sp, #0xc]
     adc:      	str	x1, [sp]
     ae0:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e118>
     ae4:      	ldr	x0, [x0, #0xfe8]
     ae8:      	ldr	x1, [x0]
     aec:      	str	x1, [sp, #0x58]
     af0:      	mov	x1, #0x0                // =0
     af4:      	ldr	w0, [sp, #0xc]
     af8:      	cmp	w0, #0x3
     afc:      	b.eq	0xb08 <main+0x3c>
     b00:      	mov	w0, #0x2                // =2
     b04:      	b	0xcf0 <main+0x224>
     b08:      	ldr	x0, [sp]
     b0c:      	add	x0, x0, #0x8
     b10:      	ldr	x0, [x0]
     b14:      	mov	w2, #0xa                // =10
     b18:      	mov	x1, #0x0                // =0
     b1c:      	bl	0x730 <strtoul@plt>
     b20:      	str	x0, [sp, #0x28]
     b24:      	ldr	x0, [sp]
     b28:      	add	x0, x0, #0x10
     b2c:      	ldr	x0, [x0]
     b30:      	mov	w2, #0xa                // =10
     b34:      	mov	x1, #0x0                // =0
     b38:      	bl	0x730 <strtoul@plt>
     b3c:      	str	w0, [sp, #0x18]
     b40:      	str	wzr, [sp, #0x1c]
     b44:      	add	x0, sp, #0x38
     b48:      	mov	x1, x0
     b4c:      	mov	w0, #0x1                // =1
     b50:      	bl	0x760 <clock_gettime@plt>
     b54:      	cmp	w0, #0x0
     b58:      	b.eq	0xb64 <main+0x98>
     b5c:      	mov	w0, #0x2                // =2
     b60:      	b	0xcf0 <main+0x224>
     b64:      	str	xzr, [sp, #0x20]
     b68:      	b	0xc2c <main+0x160>
     b6c:      	ldr	w0, [sp, #0x18]
     b70:      	lsl	w0, w0, #13
     b74:      	ldr	w1, [sp, #0x18]
     b78:      	eor	w0, w1, w0
     b7c:      	str	w0, [sp, #0x18]
     b80:      	ldr	w0, [sp, #0x18]
     b84:      	lsr	w0, w0, #17
     b88:      	ldr	w1, [sp, #0x18]
     b8c:      	eor	w0, w1, w0
     b90:      	str	w0, [sp, #0x18]
     b94:      	ldr	w0, [sp, #0x18]
     b98:      	lsl	w0, w0, #5
     b9c:      	ldr	w1, [sp, #0x18]
     ba0:      	eor	w0, w1, w0
     ba4:      	str	w0, [sp, #0x18]
     ba8:      	ldr	x2, [sp, #0x20]
     bac:      	mov	x0, #-0x3333333333333334 // =-3689348814741910324
     bb0:      	movk	x0, #0xcccd
     bb4:      	umulh	x0, x2, x0
     bb8:      	lsr	x1, x0, #3
     bbc:      	mov	x0, x1
     bc0:      	lsl	x0, x0, #2
     bc4:      	add	x0, x0, x1
     bc8:      	lsl	x0, x0, #1
     bcc:      	sub	x1, x2, x0
     bd0:      	mov	w0, w1
     bd4:      	sub	w0, w0, #0x1
     bd8:      	mov	w2, w0
     bdc:      	ldr	w1, [sp, #0x18]
     be0:      	adrp	x0, 0x20000 <data_start>
     be4:      	add	x0, x0, #0x18
     be8:      	bl	0x8d8 <region_pipeline>
     bec:      	mov	w1, w0
     bf0:      	ldr	w0, [sp, #0x1c]
     bf4:      	add	w0, w0, w1
     bf8:      	str	w0, [sp, #0x1c]
     bfc:      	ldr	w2, [sp, #0x1c]
     c00:      	ldr	w1, [sp, #0x18]
     c04:      	adrp	x0, 0x20000 <data_start>
     c08:      	add	x0, x0, #0x18
     c0c:      	bl	0x9a4 <region_outputs>
     c10:      	mov	w1, w0
     c14:      	ldr	w0, [sp, #0x1c]
     c18:      	add	w0, w0, w1
     c1c:      	str	w0, [sp, #0x1c]
     c20:      	ldr	x0, [sp, #0x20]
     c24:      	add	x0, x0, #0x1
     c28:      	str	x0, [sp, #0x20]
     c2c:      	ldr	x1, [sp, #0x20]
     c30:      	ldr	x0, [sp, #0x28]
     c34:      	cmp	x1, x0
     c38:      	b.lo	0xb6c <main+0xa0>
     c3c:      	add	x0, sp, #0x48
     c40:      	mov	x1, x0
     c44:      	mov	w0, #0x1                // =1
     c48:      	bl	0x760 <clock_gettime@plt>
     c4c:      	cmp	w0, #0x0
     c50:      	b.eq	0xc5c <main+0x190>
     c54:      	mov	w0, #0x2                // =2
     c58:      	b	0xcf0 <main+0x224>
     c5c:      	ldr	x1, [sp, #0x48]
     c60:      	ldr	x0, [sp, #0x38]
     c64:      	sub	x0, x1, x0
     c68:      	fmov	d0, x0
     c6c:      	scvtf	d1, d0
     c70:      	ldr	x1, [sp, #0x50]
     c74:      	ldr	x0, [sp, #0x40]
     c78:      	sub	x0, x1, x0
     c7c:      	fmov	d0, x0
     c80:      	scvtf	d0, d0
     c84:      	adrp	x0, 0x0 <strtoul@GLIBC_2.17>
     c88:      	ldr	d2, [x0, #0xd58]
     c8c:      	fmul	d0, d0, d2
     c90:      	fadd	d0, d1, d0
     c94:      	str	d0, [sp, #0x30]
     c98:      	adrp	x0, 0x20000 <data_start>
     c9c:      	add	x0, x0, #0x18
     ca0:      	ldr	w1, [x0]
     ca4:      	adrp	x0, 0x20000 <data_start>
     ca8:      	add	x0, x0, #0x18
     cac:      	ldr	w2, [x0, #0x4]
     cb0:      	adrp	x0, 0x20000 <data_start>
     cb4:      	add	x0, x0, #0x18
     cb8:      	ldr	w3, [x0, #0x8]
     cbc:      	adrp	x0, 0x20000 <data_start>
     cc0:      	add	x0, x0, #0x24
     cc4:      	ldr	w0, [x0]
     cc8:      	mov	w5, w0
     ccc:      	mov	w4, w3
     cd0:      	mov	w3, w2
     cd4:      	mov	w2, w1
     cd8:      	ldr	w1, [sp, #0x1c]
     cdc:      	ldr	d0, [sp, #0x30]
     ce0:      	adrp	x0, 0x0 <strtoul@GLIBC_2.17>
     ce4:      	add	x0, x0, #0xd40
     ce8:      	bl	0x7a0 <printf@plt>
     cec:      	mov	w0, #0x0                // =0
     cf0:      	mov	w1, w0
     cf4:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e118>
     cf8:      	ldr	x0, [x0, #0xfe8]
     cfc:      	ldr	x3, [sp, #0x58]
     d00:      	ldr	x2, [x0]
     d04:      	subs	x3, x3, x2
     d08:      	mov	x2, #0x0                // =0
     d0c:      	b.eq	0xd14 <main+0x248>
     d10:      	bl	0x770 <__stack_chk_fail@plt>
     d14:      	mov	w0, w1
     d18:      	ldp	x29, x30, [sp, #0x60]
     d1c:      	add	sp, sp, #0x70
     d20:      	ret

Disassembly of section .fini:

0000000000000d24 <_fini>:
     d24:      	nop
     d28:      	stp	x29, x30, [sp, #-0x10]!
     d2c:      	mov	x29, sp
     d30:      	ldp	x29, x30, [sp], #0x10
     d34:      	ret
