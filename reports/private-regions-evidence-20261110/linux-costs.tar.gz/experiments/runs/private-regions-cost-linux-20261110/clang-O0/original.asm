
/work/experiments/runs/private-regions-cost-linux-20261110/clang-O0/original:	file format elf64-littleaarch64

Disassembly of section .init:

0000000000000638 <_init>:
     638:      	nop
     63c:      	stp	x29, x30, [sp, #-0x10]!
     640:      	mov	x29, sp
     644:      	bl	0x734 <call_weak_fn>
     648:      	ldp	x29, x30, [sp], #0x10
     64c:      	ret

Disassembly of section .plt:

0000000000000650 <.plt>:
     650:      	stp	x16, x30, [sp, #-0x10]!
     654:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e20c>
     658:      	ldr	x17, [x16, #0xff8]
     65c:      	add	x16, x16, #0xff8
     660:      	br	x17
     664:      	nop
     668:      	nop
     66c:      	nop

0000000000000670 <strtoul@plt>:
     670:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     674:      	ldr	x17, [x16]
     678:      	add	x16, x16, #0x0
     67c:      	br	x17

0000000000000680 <__libc_start_main@plt>:
     680:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     684:      	ldr	x17, [x16, #0x8]
     688:      	add	x16, x16, #0x8
     68c:      	br	x17

0000000000000690 <__cxa_finalize@plt>:
     690:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     694:      	ldr	x17, [x16, #0x10]
     698:      	add	x16, x16, #0x10
     69c:      	br	x17

00000000000006a0 <clock_gettime@plt>:
     6a0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6a4:      	ldr	x17, [x16, #0x18]
     6a8:      	add	x16, x16, #0x18
     6ac:      	br	x17

00000000000006b0 <__gmon_start__@plt>:
     6b0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6b4:      	ldr	x17, [x16, #0x20]
     6b8:      	add	x16, x16, #0x20
     6bc:      	br	x17

00000000000006c0 <abort@plt>:
     6c0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6c4:      	ldr	x17, [x16, #0x28]
     6c8:      	add	x16, x16, #0x28
     6cc:      	br	x17

00000000000006d0 <printf@plt>:
     6d0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6d4:      	ldr	x17, [x16, #0x30]
     6d8:      	add	x16, x16, #0x30
     6dc:      	br	x17

Disassembly of section .text:

0000000000000700 <_start>:
     700:      	nop
     704:      	mov	x29, #0x0               // =0
     708:      	mov	x30, #0x0               // =0
     70c:      	mov	x5, x0
     710:      	ldr	x1, [sp]
     714:      	add	x2, sp, #0x8
     718:      	mov	x6, sp
     71c:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e20c>
     720:      	ldr	x0, [x0, #0xfd8]
     724:      	mov	x3, #0x0                // =0
     728:      	mov	x4, #0x0                // =0
     72c:      	bl	0x680 <__libc_start_main@plt>
     730:      	bl	0x6c0 <abort@plt>

0000000000000734 <call_weak_fn>:
     734:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e20c>
     738:      	ldr	x0, [x0, #0xfd0]
     73c:      	cbz	x0, 0x744 <call_weak_fn+0x10>
     740:      	b	0x6b0 <__gmon_start__@plt>
     744:      	ret
     748:      	nop
     74c:      	nop

0000000000000750 <deregister_tm_clones>:
     750:      	adrp	x0, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     754:      	add	x0, x0, #0x48
     758:      	adrp	x1, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     75c:      	add	x1, x1, #0x48
     760:      	cmp	x1, x0
     764:      	b.eq	0x77c <deregister_tm_clones+0x2c>
     768:      	adrp	x1, 0x1f000 <__FRAME_END__+0x1e20c>
     76c:      	ldr	x1, [x1, #0xfc0]
     770:      	cbz	x1, 0x77c <deregister_tm_clones+0x2c>
     774:      	mov	x16, x1
     778:      	br	x16
     77c:      	ret

0000000000000780 <register_tm_clones>:
     780:      	adrp	x0, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     784:      	add	x0, x0, #0x48
     788:      	adrp	x1, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     78c:      	add	x1, x1, #0x48
     790:      	sub	x1, x1, x0
     794:      	lsr	x2, x1, #63
     798:      	add	x1, x2, x1, asr #3
     79c:      	asr	x1, x1, #1
     7a0:      	cbz	x1, 0x7b8 <register_tm_clones+0x38>
     7a4:      	adrp	x2, 0x1f000 <__FRAME_END__+0x1e20c>
     7a8:      	ldr	x2, [x2, #0xfe0]
     7ac:      	cbz	x2, 0x7b8 <register_tm_clones+0x38>
     7b0:      	mov	x16, x2
     7b4:      	br	x16
     7b8:      	ret
     7bc:      	nop

00000000000007c0 <__do_global_dtors_aux>:
     7c0:      	paciasp
     7c4:      	stp	x29, x30, [sp, #-0x20]!
     7c8:      	mov	x29, sp
     7cc:      	str	x19, [sp, #0x10]
     7d0:      	adrp	x19, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     7d4:      	ldrb	w0, [x19, #0x48]
     7d8:      	tbnz	w0, #0x0, 0x800 <__do_global_dtors_aux+0x40>
     7dc:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e20c>
     7e0:      	ldr	x0, [x0, #0xfc8]
     7e4:      	cbz	x0, 0x7f4 <__do_global_dtors_aux+0x34>
     7e8:      	adrp	x0, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     7ec:      	ldr	x0, [x0, #0x40]
     7f0:      	bl	0x690 <__cxa_finalize@plt>
     7f4:      	bl	0x750 <deregister_tm_clones>
     7f8:      	mov	w0, #0x1                // =1
     7fc:      	strb	w0, [x19, #0x48]
     800:      	ldr	x19, [sp, #0x10]
     804:      	ldp	x29, x30, [sp], #0x20
     808:      	autiasp
     80c:      	ret

0000000000000810 <frame_dummy>:
     810:      	bti	c
     814:      	b	0x780 <register_tm_clones>

0000000000000818 <region_pipeline>:
     818:      	sub	sp, sp, #0x30
     81c:      	stp	x29, x30, [sp, #0x20]
     820:      	add	x29, sp, #0x20
     824:      	str	x0, [sp, #0x10]
     828:      	str	w1, [sp, #0xc]
     82c:      	str	w2, [sp, #0x8]
     830:      	ldr	x8, [sp, #0x10]
     834:      	ldr	w8, [x8]
     838:      	str	w8, [sp, #0x4]
     83c:      	ldr	w8, [sp, #0xc]
     840:      	ldr	w9, [sp, #0x4]
     844:      	add	w8, w8, w9
     848:      	str	w8, [sp, #0xc]
     84c:      	ldr	w9, [sp, #0xc]
     850:      	mov	w8, #0x3                // =3
     854:      	mul	w8, w8, w9
     858:      	add	w8, w8, #0xb
     85c:      	str	w8, [sp, #0xc]
     860:      	ldr	w0, [sp, #0xc]
     864:      	bl	0x994 <record_event>
     868:      	ldr	w8, [sp, #0x8]
     86c:      	tbz	w8, #0x1f, 0x880 <region_pipeline+0x68>
     870:      	b	0x874 <region_pipeline+0x5c>
     874:      	ldr	w8, [sp, #0xc]
     878:      	stur	w8, [x29, #-0x4]
     87c:      	b	0x8f0 <region_pipeline+0xd8>
     880:      	b	0x884 <region_pipeline+0x6c>
     884:      	ldr	w8, [sp, #0x8]
     888:      	subs	w9, w8, #0x1
     88c:      	str	w9, [sp, #0x8]
     890:      	subs	w8, w8, #0x0
     894:      	b.le	0x8e4 <region_pipeline+0xcc>
     898:      	b	0x89c <region_pipeline+0x84>
     89c:      	ldr	w0, [sp, #0xc]
     8a0:      	bl	0x9c0 <next_value>
     8a4:      	str	w0, [sp, #0x4]
     8a8:      	ldr	w8, [sp, #0xc]
     8ac:      	ldr	w9, [sp, #0x4]
     8b0:      	add	w8, w8, w9
     8b4:      	str	w8, [sp, #0xc]
     8b8:      	ldr	w9, [sp, #0xc]
     8bc:      	mov	w8, #0x5                // =5
     8c0:      	mul	w8, w8, w9
     8c4:      	subs	w8, w8, #0x7
     8c8:      	str	w8, [sp, #0xc]
     8cc:      	ldr	w8, [sp, #0xc]
     8d0:      	ldr	x9, [sp, #0x10]
     8d4:      	str	w8, [x9]
     8d8:      	ldr	w0, [sp, #0x4]
     8dc:      	bl	0x994 <record_event>
     8e0:      	b	0x884 <region_pipeline+0x6c>
     8e4:      	ldr	w8, [sp, #0xc]
     8e8:      	stur	w8, [x29, #-0x4]
     8ec:      	b	0x8f0 <region_pipeline+0xd8>
     8f0:      	ldur	w0, [x29, #-0x4]
     8f4:      	ldp	x29, x30, [sp, #0x20]
     8f8:      	add	sp, sp, #0x30
     8fc:      	ret

0000000000000900 <region_outputs>:
     900:      	sub	sp, sp, #0x30
     904:      	stp	x29, x30, [sp, #0x20]
     908:      	add	x29, sp, #0x20
     90c:      	stur	x0, [x29, #-0x8]
     910:      	stur	w1, [x29, #-0xc]
     914:      	str	w2, [sp, #0x10]
     918:      	mov	w8, #0x11               // =17
     91c:      	str	w8, [sp, #0xc]
     920:      	ldr	w8, [sp, #0xc]
     924:      	ldur	w9, [x29, #-0xc]
     928:      	add	w8, w8, w9
     92c:      	str	w8, [sp, #0xc]
     930:      	ldr	w9, [sp, #0xc]
     934:      	mov	w8, #0x3                // =3
     938:      	mul	w8, w8, w9
     93c:      	ldr	w9, [sp, #0x10]
     940:      	add	w8, w8, w9
     944:      	stur	w8, [x29, #-0xc]
     948:      	ldur	w8, [x29, #-0xc]
     94c:      	ldr	w9, [sp, #0xc]
     950:      	subs	w8, w8, w9
     954:      	str	w8, [sp, #0x10]
     958:      	ldur	w0, [x29, #-0xc]
     95c:      	bl	0x994 <record_event>
     960:      	ldr	w8, [sp, #0x10]
     964:      	ldur	x9, [x29, #-0x8]
     968:      	str	w8, [x9]
     96c:      	ldr	w8, [sp, #0xc]
     970:      	ldur	x9, [x29, #-0x8]
     974:      	str	w8, [x9, #0x4]
     978:      	ldur	w8, [x29, #-0xc]
     97c:      	ldr	w9, [sp, #0x10]
     980:      	subs	w8, w8, w9
     984:      	cset	w0, eq
     988:      	ldp	x29, x30, [sp, #0x20]
     98c:      	add	sp, sp, #0x30
     990:      	ret

0000000000000994 <record_event>:
     994:      	sub	sp, sp, #0x10
     998:      	str	w0, [sp, #0xc]
     99c:      	adrp	x9, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     9a0:      	ldr	w8, [x9, #0x4c]
     9a4:      	mov	w10, #0x21              // =33
     9a8:      	mul	w8, w8, w10
     9ac:      	ldr	w10, [sp, #0xc]
     9b0:      	eor	w8, w8, w10
     9b4:      	str	w8, [x9, #0x4c]
     9b8:      	add	sp, sp, #0x10
     9bc:      	ret

00000000000009c0 <next_value>:
     9c0:      	sub	sp, sp, #0x20
     9c4:      	stp	x29, x30, [sp, #0x10]
     9c8:      	add	x29, sp, #0x10
     9cc:      	stur	w0, [x29, #-0x4]
     9d0:      	ldur	w0, [x29, #-0x4]
     9d4:      	bl	0x994 <record_event>
     9d8:      	ldur	w10, [x29, #-0x4]
     9dc:      	adrp	x9, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     9e0:      	add	x9, x9, #0x50
     9e4:      	ldr	w8, [x9, #0x4]
     9e8:      	add	w8, w8, w10
     9ec:      	str	w8, [x9, #0x4]
     9f0:      	ldur	w8, [x29, #-0x4]
     9f4:      	ldr	w9, [x9, #0x4]
     9f8:      	add	w0, w8, w9
     9fc:      	ldp	x29, x30, [sp, #0x10]
     a00:      	add	sp, sp, #0x20
     a04:      	ret

0000000000000a08 <main>:
     a08:      	sub	sp, sp, #0x80
     a0c:      	stp	x29, x30, [sp, #0x70]
     a10:      	add	x29, sp, #0x70
     a14:      	stur	wzr, [x29, #-0x4]
     a18:      	stur	w0, [x29, #-0x8]
     a1c:      	stur	x1, [x29, #-0x10]
     a20:      	ldur	w8, [x29, #-0x8]
     a24:      	subs	w8, w8, #0x3
     a28:      	b.eq	0xa3c <main+0x34>
     a2c:      	b	0xa30 <main+0x28>
     a30:      	mov	w8, #0x2                // =2
     a34:      	stur	w8, [x29, #-0x4]
     a38:      	b	0xbe0 <main+0x1d8>
     a3c:      	ldur	x8, [x29, #-0x10]
     a40:      	ldr	x0, [x8, #0x8]
     a44:      	mov	x1, xzr
     a48:      	str	x1, [sp, #0x10]
     a4c:      	mov	w2, #0xa                // =10
     a50:      	str	w2, [sp, #0x1c]
     a54:      	bl	0x670 <strtoul@plt>
     a58:      	ldr	x1, [sp, #0x10]
     a5c:      	ldr	w2, [sp, #0x1c]
     a60:      	stur	x0, [x29, #-0x18]
     a64:      	ldur	x8, [x29, #-0x10]
     a68:      	ldr	x0, [x8, #0x10]
     a6c:      	bl	0x670 <strtoul@plt>
     a70:      	mov	w8, w0
     a74:      	stur	w8, [x29, #-0x1c]
     a78:      	stur	wzr, [x29, #-0x20]
     a7c:      	mov	w0, #0x1                // =1
     a80:      	sub	x1, x29, #0x30
     a84:      	bl	0x6a0 <clock_gettime@plt>
     a88:      	cbz	w0, 0xa9c <main+0x94>
     a8c:      	b	0xa90 <main+0x88>
     a90:      	mov	w8, #0x2                // =2
     a94:      	stur	w8, [x29, #-0x4]
     a98:      	b	0xbe0 <main+0x1d8>
     a9c:      	str	xzr, [sp, #0x28]
     aa0:      	b	0xaa4 <main+0x9c>
     aa4:      	ldr	x8, [sp, #0x28]
     aa8:      	ldur	x9, [x29, #-0x18]
     aac:      	subs	x8, x8, x9
     ab0:      	b.hs	0xb54 <main+0x14c>
     ab4:      	b	0xab8 <main+0xb0>
     ab8:      	ldur	w9, [x29, #-0x1c]
     abc:      	ldur	w8, [x29, #-0x1c]
     ac0:      	eor	w8, w8, w9, lsl #13
     ac4:      	stur	w8, [x29, #-0x1c]
     ac8:      	ldur	w9, [x29, #-0x1c]
     acc:      	ldur	w8, [x29, #-0x1c]
     ad0:      	eor	w8, w8, w9, lsr #17
     ad4:      	stur	w8, [x29, #-0x1c]
     ad8:      	ldur	w9, [x29, #-0x1c]
     adc:      	ldur	w8, [x29, #-0x1c]
     ae0:      	eor	w8, w8, w9, lsl #5
     ae4:      	stur	w8, [x29, #-0x1c]
     ae8:      	ldur	w1, [x29, #-0x1c]
     aec:      	ldr	x8, [sp, #0x28]
     af0:      	mov	x10, #0xa               // =10
     af4:      	udiv	x9, x8, x10
     af8:      	mul	x9, x9, x10
     afc:      	subs	x8, x8, x9
     b00:      	subs	w2, w8, #0x1
     b04:      	adrp	x0, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     b08:      	add	x0, x0, #0x50
     b0c:      	str	x0, [sp, #0x8]
     b10:      	bl	0x818 <region_pipeline>
     b14:      	mov	w9, w0
     b18:      	ldr	x0, [sp, #0x8]
     b1c:      	ldur	w8, [x29, #-0x20]
     b20:      	add	w8, w8, w9
     b24:      	stur	w8, [x29, #-0x20]
     b28:      	ldur	w1, [x29, #-0x1c]
     b2c:      	ldur	w2, [x29, #-0x20]
     b30:      	bl	0x900 <region_outputs>
     b34:      	ldur	w8, [x29, #-0x20]
     b38:      	add	w8, w8, w0
     b3c:      	stur	w8, [x29, #-0x20]
     b40:      	b	0xb44 <main+0x13c>
     b44:      	ldr	x8, [sp, #0x28]
     b48:      	add	x8, x8, #0x1
     b4c:      	str	x8, [sp, #0x28]
     b50:      	b	0xaa4 <main+0x9c>
     b54:      	mov	w0, #0x1                // =1
     b58:      	add	x1, sp, #0x30
     b5c:      	bl	0x6a0 <clock_gettime@plt>
     b60:      	cbz	w0, 0xb74 <main+0x16c>
     b64:      	b	0xb68 <main+0x160>
     b68:      	mov	w8, #0x2                // =2
     b6c:      	stur	w8, [x29, #-0x4]
     b70:      	b	0xbe0 <main+0x1d8>
     b74:      	ldr	x8, [sp, #0x30]
     b78:      	ldur	x9, [x29, #-0x30]
     b7c:      	subs	x8, x8, x9
     b80:      	scvtf	d2, x8
     b84:      	ldr	x8, [sp, #0x38]
     b88:      	ldur	x9, [x29, #-0x28]
     b8c:      	subs	x8, x8, x9
     b90:      	scvtf	d0, x8
     b94:      	adrp	x8, 0x0 <strtoul@GLIBC_2.17>
     b98:      	ldr	d1, [x8, #0xc10]
     b9c:      	fmadd	d0, d0, d1, d2
     ba0:      	str	d0, [sp, #0x20]
     ba4:      	ldr	d0, [sp, #0x20]
     ba8:      	ldur	w1, [x29, #-0x20]
     bac:      	adrp	x9, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     bb0:      	adrp	x8, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     bb4:      	add	x8, x8, #0x50
     bb8:      	ldr	w2, [x9, #0x50]
     bbc:      	ldr	w3, [x8, #0x4]
     bc0:      	ldr	w4, [x8, #0x8]
     bc4:      	adrp	x8, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     bc8:      	ldr	w5, [x8, #0x4c]
     bcc:      	adrp	x0, 0x0 <strtoul@GLIBC_2.17>
     bd0:      	add	x0, x0, #0xc18
     bd4:      	bl	0x6d0 <printf@plt>
     bd8:      	stur	wzr, [x29, #-0x4]
     bdc:      	b	0xbe0 <main+0x1d8>
     be0:      	ldur	w0, [x29, #-0x4]
     be4:      	ldp	x29, x30, [sp, #0x70]
     be8:      	add	sp, sp, #0x80
     bec:      	ret

Disassembly of section .fini:

0000000000000bf0 <_fini>:
     bf0:      	nop
     bf4:      	stp	x29, x30, [sp, #-0x10]!
     bf8:      	mov	x29, sp
     bfc:      	ldp	x29, x30, [sp], #0x10
     c00:      	ret
