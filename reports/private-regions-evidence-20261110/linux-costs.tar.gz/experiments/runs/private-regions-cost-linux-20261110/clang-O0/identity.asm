
/work/experiments/runs/private-regions-cost-linux-20261110/clang-O0/identity:	file format elf64-littleaarch64

Disassembly of section .init:

0000000000000638 <_init>:
     638:      	nop
     63c:      	stp	x29, x30, [sp, #-0x10]!
     640:      	mov	x29, sp
     644:      	bl	0x734 <call_weak_fn>
     648:      	ldp	x29, x30, [sp], #0x10
     64c:      	ret

Disassembly of section .plt:

0000000000000650 <.plt>:
     650:      	stp	x16, x30, [sp, #-0x10]!
     654:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e1b4>
     658:      	ldr	x17, [x16, #0xff8]
     65c:      	add	x16, x16, #0xff8
     660:      	br	x17
     664:      	nop
     668:      	nop
     66c:      	nop

0000000000000670 <strtoul@plt>:
     670:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     674:      	ldr	x17, [x16]
     678:      	add	x16, x16, #0x0
     67c:      	br	x17

0000000000000680 <__libc_start_main@plt>:
     680:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     684:      	ldr	x17, [x16, #0x8]
     688:      	add	x16, x16, #0x8
     68c:      	br	x17

0000000000000690 <__cxa_finalize@plt>:
     690:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     694:      	ldr	x17, [x16, #0x10]
     698:      	add	x16, x16, #0x10
     69c:      	br	x17

00000000000006a0 <clock_gettime@plt>:
     6a0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6a4:      	ldr	x17, [x16, #0x18]
     6a8:      	add	x16, x16, #0x18
     6ac:      	br	x17

00000000000006b0 <__gmon_start__@plt>:
     6b0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6b4:      	ldr	x17, [x16, #0x20]
     6b8:      	add	x16, x16, #0x20
     6bc:      	br	x17

00000000000006c0 <abort@plt>:
     6c0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6c4:      	ldr	x17, [x16, #0x28]
     6c8:      	add	x16, x16, #0x28
     6cc:      	br	x17

00000000000006d0 <printf@plt>:
     6d0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6d4:      	ldr	x17, [x16, #0x30]
     6d8:      	add	x16, x16, #0x30
     6dc:      	br	x17

Disassembly of section .text:

0000000000000700 <_start>:
     700:      	nop
     704:      	mov	x29, #0x0               // =0
     708:      	mov	x30, #0x0               // =0
     70c:      	mov	x5, x0
     710:      	ldr	x1, [sp]
     714:      	add	x2, sp, #0x8
     718:      	mov	x6, sp
     71c:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e1b4>
     720:      	ldr	x0, [x0, #0xfd8]
     724:      	mov	x3, #0x0                // =0
     728:      	mov	x4, #0x0                // =0
     72c:      	bl	0x680 <__libc_start_main@plt>
     730:      	bl	0x6c0 <abort@plt>

0000000000000734 <call_weak_fn>:
     734:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e1b4>
     738:      	ldr	x0, [x0, #0xfd0]
     73c:      	cbz	x0, 0x744 <call_weak_fn+0x10>
     740:      	b	0x6b0 <__gmon_start__@plt>
     744:      	ret
     748:      	nop
     74c:      	nop

0000000000000750 <deregister_tm_clones>:
     750:      	adrp	x0, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     754:      	add	x0, x0, #0x48
     758:      	adrp	x1, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     75c:      	add	x1, x1, #0x48
     760:      	cmp	x1, x0
     764:      	b.eq	0x77c <deregister_tm_clones+0x2c>
     768:      	adrp	x1, 0x1f000 <__FRAME_END__+0x1e1b4>
     76c:      	ldr	x1, [x1, #0xfc0]
     770:      	cbz	x1, 0x77c <deregister_tm_clones+0x2c>
     774:      	mov	x16, x1
     778:      	br	x16
     77c:      	ret

0000000000000780 <register_tm_clones>:
     780:      	adrp	x0, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     784:      	add	x0, x0, #0x48
     788:      	adrp	x1, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     78c:      	add	x1, x1, #0x48
     790:      	sub	x1, x1, x0
     794:      	lsr	x2, x1, #63
     798:      	add	x1, x2, x1, asr #3
     79c:      	asr	x1, x1, #1
     7a0:      	cbz	x1, 0x7b8 <register_tm_clones+0x38>
     7a4:      	adrp	x2, 0x1f000 <__FRAME_END__+0x1e1b4>
     7a8:      	ldr	x2, [x2, #0xfe0]
     7ac:      	cbz	x2, 0x7b8 <register_tm_clones+0x38>
     7b0:      	mov	x16, x2
     7b4:      	br	x16
     7b8:      	ret
     7bc:      	nop

00000000000007c0 <__do_global_dtors_aux>:
     7c0:      	paciasp
     7c4:      	stp	x29, x30, [sp, #-0x20]!
     7c8:      	mov	x29, sp
     7cc:      	str	x19, [sp, #0x10]
     7d0:      	adrp	x19, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     7d4:      	ldrb	w0, [x19, #0x48]
     7d8:      	tbnz	w0, #0x0, 0x800 <__do_global_dtors_aux+0x40>
     7dc:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e1b4>
     7e0:      	ldr	x0, [x0, #0xfc8]
     7e4:      	cbz	x0, 0x7f4 <__do_global_dtors_aux+0x34>
     7e8:      	adrp	x0, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     7ec:      	ldr	x0, [x0, #0x40]
     7f0:      	bl	0x690 <__cxa_finalize@plt>
     7f4:      	bl	0x750 <deregister_tm_clones>
     7f8:      	mov	w0, #0x1                // =1
     7fc:      	strb	w0, [x19, #0x48]
     800:      	ldr	x19, [sp, #0x10]
     804:      	ldp	x29, x30, [sp], #0x20
     808:      	autiasp
     80c:      	ret

0000000000000810 <frame_dummy>:
     810:      	bti	c
     814:      	b	0x780 <register_tm_clones>

0000000000000818 <region_pipeline>:
     818:      	sub	sp, sp, #0x40
     81c:      	stp	x29, x30, [sp, #0x30]
     820:      	add	x29, sp, #0x30
     824:      	stur	x0, [x29, #-0x10]
     828:      	stur	w1, [x29, #-0x14]
     82c:      	str	w2, [sp, #0x18]
     830:      	ldur	x8, [x29, #-0x10]
     834:      	ldr	w8, [x8]
     838:      	str	w8, [sp, #0x14]
     83c:      	ldur	w8, [x29, #-0x14]
     840:      	str	w8, [sp, #0x10]
     844:      	ldr	w8, [sp, #0x14]
     848:      	str	w8, [sp, #0xc]
     84c:      	ldr	w8, [sp, #0x10]
     850:      	ldr	w9, [sp, #0xc]
     854:      	add	w8, w8, w9
     858:      	str	w8, [sp, #0x10]
     85c:      	ldr	w9, [sp, #0x10]
     860:      	mov	w8, #0x3                // =3
     864:      	mul	w8, w8, w9
     868:      	add	w8, w8, #0xb
     86c:      	str	w8, [sp, #0x10]
     870:      	ldr	w8, [sp, #0x10]
     874:      	stur	w8, [x29, #-0x14]
     878:      	ldur	w0, [x29, #-0x14]
     87c:      	bl	0x9ec <record_event>
     880:      	ldr	w8, [sp, #0x18]
     884:      	tbz	w8, #0x1f, 0x898 <region_pipeline+0x80>
     888:      	b	0x88c <region_pipeline+0x74>
     88c:      	ldur	w8, [x29, #-0x14]
     890:      	stur	w8, [x29, #-0x4]
     894:      	b	0x920 <region_pipeline+0x108>
     898:      	b	0x89c <region_pipeline+0x84>
     89c:      	ldr	w8, [sp, #0x18]
     8a0:      	subs	w9, w8, #0x1
     8a4:      	str	w9, [sp, #0x18]
     8a8:      	subs	w8, w8, #0x0
     8ac:      	b.le	0x914 <region_pipeline+0xfc>
     8b0:      	b	0x8b4 <region_pipeline+0x9c>
     8b4:      	ldur	w0, [x29, #-0x14]
     8b8:      	bl	0xa18 <next_value>
     8bc:      	str	w0, [sp, #0x14]
     8c0:      	ldur	w8, [x29, #-0x14]
     8c4:      	str	w8, [sp, #0x8]
     8c8:      	ldr	w8, [sp, #0x14]
     8cc:      	str	w8, [sp, #0x4]
     8d0:      	ldr	w8, [sp, #0x8]
     8d4:      	ldr	w9, [sp, #0x4]
     8d8:      	add	w8, w8, w9
     8dc:      	str	w8, [sp, #0x8]
     8e0:      	ldr	w9, [sp, #0x8]
     8e4:      	mov	w8, #0x5                // =5
     8e8:      	mul	w8, w8, w9
     8ec:      	subs	w8, w8, #0x7
     8f0:      	str	w8, [sp, #0x8]
     8f4:      	ldr	w8, [sp, #0x8]
     8f8:      	stur	w8, [x29, #-0x14]
     8fc:      	ldur	w8, [x29, #-0x14]
     900:      	ldur	x9, [x29, #-0x10]
     904:      	str	w8, [x9]
     908:      	ldr	w0, [sp, #0x14]
     90c:      	bl	0x9ec <record_event>
     910:      	b	0x89c <region_pipeline+0x84>
     914:      	ldur	w8, [x29, #-0x14]
     918:      	stur	w8, [x29, #-0x4]
     91c:      	b	0x920 <region_pipeline+0x108>
     920:      	ldur	w0, [x29, #-0x4]
     924:      	ldp	x29, x30, [sp, #0x30]
     928:      	add	sp, sp, #0x40
     92c:      	ret

0000000000000930 <region_outputs>:
     930:      	sub	sp, sp, #0x30
     934:      	stp	x29, x30, [sp, #0x20]
     938:      	add	x29, sp, #0x20
     93c:      	stur	x0, [x29, #-0x8]
     940:      	stur	w1, [x29, #-0xc]
     944:      	str	w2, [sp, #0x10]
     948:      	ldur	w8, [x29, #-0xc]
     94c:      	str	w8, [sp, #0x8]
     950:      	ldr	w8, [sp, #0x10]
     954:      	str	w8, [sp, #0x4]
     958:      	mov	w8, #0x11               // =17
     95c:      	str	w8, [sp]
     960:      	ldr	w8, [sp]
     964:      	ldr	w9, [sp, #0x8]
     968:      	add	w8, w8, w9
     96c:      	str	w8, [sp]
     970:      	ldr	w9, [sp]
     974:      	mov	w8, #0x3                // =3
     978:      	mul	w8, w8, w9
     97c:      	ldr	w9, [sp, #0x4]
     980:      	add	w8, w8, w9
     984:      	str	w8, [sp, #0x8]
     988:      	ldr	w8, [sp, #0x8]
     98c:      	ldr	w9, [sp]
     990:      	subs	w8, w8, w9
     994:      	str	w8, [sp, #0x4]
     998:      	ldr	w8, [sp]
     99c:      	str	w8, [sp, #0xc]
     9a0:      	ldr	w8, [sp, #0x8]
     9a4:      	stur	w8, [x29, #-0xc]
     9a8:      	ldr	w8, [sp, #0x4]
     9ac:      	str	w8, [sp, #0x10]
     9b0:      	ldur	w0, [x29, #-0xc]
     9b4:      	bl	0x9ec <record_event>
     9b8:      	ldr	w8, [sp, #0x10]
     9bc:      	ldur	x9, [x29, #-0x8]
     9c0:      	str	w8, [x9]
     9c4:      	ldr	w8, [sp, #0xc]
     9c8:      	ldur	x9, [x29, #-0x8]
     9cc:      	str	w8, [x9, #0x4]
     9d0:      	ldur	w8, [x29, #-0xc]
     9d4:      	ldr	w9, [sp, #0x10]
     9d8:      	subs	w8, w8, w9
     9dc:      	cset	w0, eq
     9e0:      	ldp	x29, x30, [sp, #0x20]
     9e4:      	add	sp, sp, #0x30
     9e8:      	ret

00000000000009ec <record_event>:
     9ec:      	sub	sp, sp, #0x10
     9f0:      	str	w0, [sp, #0xc]
     9f4:      	adrp	x9, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     9f8:      	ldr	w8, [x9, #0x4c]
     9fc:      	mov	w10, #0x21              // =33
     a00:      	mul	w8, w8, w10
     a04:      	ldr	w10, [sp, #0xc]
     a08:      	eor	w8, w8, w10
     a0c:      	str	w8, [x9, #0x4c]
     a10:      	add	sp, sp, #0x10
     a14:      	ret

0000000000000a18 <next_value>:
     a18:      	sub	sp, sp, #0x20
     a1c:      	stp	x29, x30, [sp, #0x10]
     a20:      	add	x29, sp, #0x10
     a24:      	stur	w0, [x29, #-0x4]
     a28:      	ldur	w0, [x29, #-0x4]
     a2c:      	bl	0x9ec <record_event>
     a30:      	ldur	w10, [x29, #-0x4]
     a34:      	adrp	x9, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     a38:      	add	x9, x9, #0x50
     a3c:      	ldr	w8, [x9, #0x4]
     a40:      	add	w8, w8, w10
     a44:      	str	w8, [x9, #0x4]
     a48:      	ldur	w8, [x29, #-0x4]
     a4c:      	ldr	w9, [x9, #0x4]
     a50:      	add	w0, w8, w9
     a54:      	ldp	x29, x30, [sp, #0x10]
     a58:      	add	sp, sp, #0x20
     a5c:      	ret

0000000000000a60 <main>:
     a60:      	sub	sp, sp, #0x80
     a64:      	stp	x29, x30, [sp, #0x70]
     a68:      	add	x29, sp, #0x70
     a6c:      	stur	wzr, [x29, #-0x4]
     a70:      	stur	w0, [x29, #-0x8]
     a74:      	stur	x1, [x29, #-0x10]
     a78:      	ldur	w8, [x29, #-0x8]
     a7c:      	subs	w8, w8, #0x3
     a80:      	b.eq	0xa94 <main+0x34>
     a84:      	b	0xa88 <main+0x28>
     a88:      	mov	w8, #0x2                // =2
     a8c:      	stur	w8, [x29, #-0x4]
     a90:      	b	0xc38 <main+0x1d8>
     a94:      	ldur	x8, [x29, #-0x10]
     a98:      	ldr	x0, [x8, #0x8]
     a9c:      	mov	x1, xzr
     aa0:      	str	x1, [sp, #0x10]
     aa4:      	mov	w2, #0xa                // =10
     aa8:      	str	w2, [sp, #0x1c]
     aac:      	bl	0x670 <strtoul@plt>
     ab0:      	ldr	x1, [sp, #0x10]
     ab4:      	ldr	w2, [sp, #0x1c]
     ab8:      	stur	x0, [x29, #-0x18]
     abc:      	ldur	x8, [x29, #-0x10]
     ac0:      	ldr	x0, [x8, #0x10]
     ac4:      	bl	0x670 <strtoul@plt>
     ac8:      	mov	w8, w0
     acc:      	stur	w8, [x29, #-0x1c]
     ad0:      	stur	wzr, [x29, #-0x20]
     ad4:      	mov	w0, #0x1                // =1
     ad8:      	sub	x1, x29, #0x30
     adc:      	bl	0x6a0 <clock_gettime@plt>
     ae0:      	cbz	w0, 0xaf4 <main+0x94>
     ae4:      	b	0xae8 <main+0x88>
     ae8:      	mov	w8, #0x2                // =2
     aec:      	stur	w8, [x29, #-0x4]
     af0:      	b	0xc38 <main+0x1d8>
     af4:      	str	xzr, [sp, #0x28]
     af8:      	b	0xafc <main+0x9c>
     afc:      	ldr	x8, [sp, #0x28]
     b00:      	ldur	x9, [x29, #-0x18]
     b04:      	subs	x8, x8, x9
     b08:      	b.hs	0xbac <main+0x14c>
     b0c:      	b	0xb10 <main+0xb0>
     b10:      	ldur	w9, [x29, #-0x1c]
     b14:      	ldur	w8, [x29, #-0x1c]
     b18:      	eor	w8, w8, w9, lsl #13
     b1c:      	stur	w8, [x29, #-0x1c]
     b20:      	ldur	w9, [x29, #-0x1c]
     b24:      	ldur	w8, [x29, #-0x1c]
     b28:      	eor	w8, w8, w9, lsr #17
     b2c:      	stur	w8, [x29, #-0x1c]
     b30:      	ldur	w9, [x29, #-0x1c]
     b34:      	ldur	w8, [x29, #-0x1c]
     b38:      	eor	w8, w8, w9, lsl #5
     b3c:      	stur	w8, [x29, #-0x1c]
     b40:      	ldur	w1, [x29, #-0x1c]
     b44:      	ldr	x8, [sp, #0x28]
     b48:      	mov	x10, #0xa               // =10
     b4c:      	udiv	x9, x8, x10
     b50:      	mul	x9, x9, x10
     b54:      	subs	x8, x8, x9
     b58:      	subs	w2, w8, #0x1
     b5c:      	adrp	x0, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     b60:      	add	x0, x0, #0x50
     b64:      	str	x0, [sp, #0x8]
     b68:      	bl	0x818 <region_pipeline>
     b6c:      	mov	w9, w0
     b70:      	ldr	x0, [sp, #0x8]
     b74:      	ldur	w8, [x29, #-0x20]
     b78:      	add	w8, w8, w9
     b7c:      	stur	w8, [x29, #-0x20]
     b80:      	ldur	w1, [x29, #-0x1c]
     b84:      	ldur	w2, [x29, #-0x20]
     b88:      	bl	0x930 <region_outputs>
     b8c:      	ldur	w8, [x29, #-0x20]
     b90:      	add	w8, w8, w0
     b94:      	stur	w8, [x29, #-0x20]
     b98:      	b	0xb9c <main+0x13c>
     b9c:      	ldr	x8, [sp, #0x28]
     ba0:      	add	x8, x8, #0x1
     ba4:      	str	x8, [sp, #0x28]
     ba8:      	b	0xafc <main+0x9c>
     bac:      	mov	w0, #0x1                // =1
     bb0:      	add	x1, sp, #0x30
     bb4:      	bl	0x6a0 <clock_gettime@plt>
     bb8:      	cbz	w0, 0xbcc <main+0x16c>
     bbc:      	b	0xbc0 <main+0x160>
     bc0:      	mov	w8, #0x2                // =2
     bc4:      	stur	w8, [x29, #-0x4]
     bc8:      	b	0xc38 <main+0x1d8>
     bcc:      	ldr	x8, [sp, #0x30]
     bd0:      	ldur	x9, [x29, #-0x30]
     bd4:      	subs	x8, x8, x9
     bd8:      	scvtf	d2, x8
     bdc:      	ldr	x8, [sp, #0x38]
     be0:      	ldur	x9, [x29, #-0x28]
     be4:      	subs	x8, x8, x9
     be8:      	scvtf	d0, x8
     bec:      	adrp	x8, 0x0 <strtoul@GLIBC_2.17>
     bf0:      	ldr	d1, [x8, #0xc68]
     bf4:      	fmadd	d0, d0, d1, d2
     bf8:      	str	d0, [sp, #0x20]
     bfc:      	ldr	d0, [sp, #0x20]
     c00:      	ldur	w1, [x29, #-0x20]
     c04:      	adrp	x9, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     c08:      	adrp	x8, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     c0c:      	add	x8, x8, #0x50
     c10:      	ldr	w2, [x9, #0x50]
     c14:      	ldr	w3, [x8, #0x4]
     c18:      	ldr	w4, [x8, #0x8]
     c1c:      	adrp	x8, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     c20:      	ldr	w5, [x8, #0x4c]
     c24:      	adrp	x0, 0x0 <strtoul@GLIBC_2.17>
     c28:      	add	x0, x0, #0xc70
     c2c:      	bl	0x6d0 <printf@plt>
     c30:      	stur	wzr, [x29, #-0x4]
     c34:      	b	0xc38 <main+0x1d8>
     c38:      	ldur	w0, [x29, #-0x4]
     c3c:      	ldp	x29, x30, [sp, #0x70]
     c40:      	add	sp, sp, #0x80
     c44:      	ret

Disassembly of section .fini:

0000000000000c48 <_fini>:
     c48:      	nop
     c4c:      	stp	x29, x30, [sp, #-0x10]!
     c50:      	mov	x29, sp
     c54:      	ldp	x29, x30, [sp], #0x10
     c58:      	ret
