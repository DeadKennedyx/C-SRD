
/work/experiments/runs/private-regions-cost-linux-20261110/clang-O0/affine:	file format elf64-littleaarch64

Disassembly of section .init:

0000000000000638 <_init>:
     638:      	nop
     63c:      	stp	x29, x30, [sp, #-0x10]!
     640:      	mov	x29, sp
     644:      	bl	0x734 <call_weak_fn>
     648:      	ldp	x29, x30, [sp], #0x10
     64c:      	ret

Disassembly of section .plt:

0000000000000650 <.plt>:
     650:      	stp	x16, x30, [sp, #-0x10]!
     654:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e0bc>
     658:      	ldr	x17, [x16, #0xff8]
     65c:      	add	x16, x16, #0xff8
     660:      	br	x17
     664:      	nop
     668:      	nop
     66c:      	nop

0000000000000670 <strtoul@plt>:
     670:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     674:      	ldr	x17, [x16]
     678:      	add	x16, x16, #0x0
     67c:      	br	x17

0000000000000680 <__libc_start_main@plt>:
     680:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     684:      	ldr	x17, [x16, #0x8]
     688:      	add	x16, x16, #0x8
     68c:      	br	x17

0000000000000690 <__cxa_finalize@plt>:
     690:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     694:      	ldr	x17, [x16, #0x10]
     698:      	add	x16, x16, #0x10
     69c:      	br	x17

00000000000006a0 <clock_gettime@plt>:
     6a0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6a4:      	ldr	x17, [x16, #0x18]
     6a8:      	add	x16, x16, #0x18
     6ac:      	br	x17

00000000000006b0 <__gmon_start__@plt>:
     6b0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6b4:      	ldr	x17, [x16, #0x20]
     6b8:      	add	x16, x16, #0x20
     6bc:      	br	x17

00000000000006c0 <abort@plt>:
     6c0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6c4:      	ldr	x17, [x16, #0x28]
     6c8:      	add	x16, x16, #0x28
     6cc:      	br	x17

00000000000006d0 <printf@plt>:
     6d0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6d4:      	ldr	x17, [x16, #0x30]
     6d8:      	add	x16, x16, #0x30
     6dc:      	br	x17

Disassembly of section .text:

0000000000000700 <_start>:
     700:      	nop
     704:      	mov	x29, #0x0               // =0
     708:      	mov	x30, #0x0               // =0
     70c:      	mov	x5, x0
     710:      	ldr	x1, [sp]
     714:      	add	x2, sp, #0x8
     718:      	mov	x6, sp
     71c:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e0bc>
     720:      	ldr	x0, [x0, #0xfd8]
     724:      	mov	x3, #0x0                // =0
     728:      	mov	x4, #0x0                // =0
     72c:      	bl	0x680 <__libc_start_main@plt>
     730:      	bl	0x6c0 <abort@plt>

0000000000000734 <call_weak_fn>:
     734:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e0bc>
     738:      	ldr	x0, [x0, #0xfd0]
     73c:      	cbz	x0, 0x744 <call_weak_fn+0x10>
     740:      	b	0x6b0 <__gmon_start__@plt>
     744:      	ret
     748:      	nop
     74c:      	nop

0000000000000750 <deregister_tm_clones>:
     750:      	adrp	x0, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     754:      	add	x0, x0, #0x48
     758:      	adrp	x1, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     75c:      	add	x1, x1, #0x48
     760:      	cmp	x1, x0
     764:      	b.eq	0x77c <deregister_tm_clones+0x2c>
     768:      	adrp	x1, 0x1f000 <__FRAME_END__+0x1e0bc>
     76c:      	ldr	x1, [x1, #0xfc0]
     770:      	cbz	x1, 0x77c <deregister_tm_clones+0x2c>
     774:      	mov	x16, x1
     778:      	br	x16
     77c:      	ret

0000000000000780 <register_tm_clones>:
     780:      	adrp	x0, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     784:      	add	x0, x0, #0x48
     788:      	adrp	x1, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     78c:      	add	x1, x1, #0x48
     790:      	sub	x1, x1, x0
     794:      	lsr	x2, x1, #63
     798:      	add	x1, x2, x1, asr #3
     79c:      	asr	x1, x1, #1
     7a0:      	cbz	x1, 0x7b8 <register_tm_clones+0x38>
     7a4:      	adrp	x2, 0x1f000 <__FRAME_END__+0x1e0bc>
     7a8:      	ldr	x2, [x2, #0xfe0]
     7ac:      	cbz	x2, 0x7b8 <register_tm_clones+0x38>
     7b0:      	mov	x16, x2
     7b4:      	br	x16
     7b8:      	ret
     7bc:      	nop

00000000000007c0 <__do_global_dtors_aux>:
     7c0:      	paciasp
     7c4:      	stp	x29, x30, [sp, #-0x20]!
     7c8:      	mov	x29, sp
     7cc:      	str	x19, [sp, #0x10]
     7d0:      	adrp	x19, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     7d4:      	ldrb	w0, [x19, #0x48]
     7d8:      	tbnz	w0, #0x0, 0x800 <__do_global_dtors_aux+0x40>
     7dc:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e0bc>
     7e0:      	ldr	x0, [x0, #0xfc8]
     7e4:      	cbz	x0, 0x7f4 <__do_global_dtors_aux+0x34>
     7e8:      	adrp	x0, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     7ec:      	ldr	x0, [x0, #0x40]
     7f0:      	bl	0x690 <__cxa_finalize@plt>
     7f4:      	bl	0x750 <deregister_tm_clones>
     7f8:      	mov	w0, #0x1                // =1
     7fc:      	strb	w0, [x19, #0x48]
     800:      	ldr	x19, [sp, #0x10]
     804:      	ldp	x29, x30, [sp], #0x20
     808:      	autiasp
     80c:      	ret

0000000000000810 <frame_dummy>:
     810:      	bti	c
     814:      	b	0x780 <register_tm_clones>

0000000000000818 <region_pipeline>:
     818:      	sub	sp, sp, #0x40
     81c:      	stp	x29, x30, [sp, #0x30]
     820:      	add	x29, sp, #0x30
     824:      	mov	w9, #0xa4f5             // =42229
     828:      	movk	w9, #0x3d0d, lsl #16
     82c:      	mov	w8, #0xeefa             // =61178
     830:      	movk	w8, #0x67e9, lsl #16
     834:      	str	w8, [sp]
     838:      	stur	x0, [x29, #-0x10]
     83c:      	stur	w1, [x29, #-0x14]
     840:      	str	w2, [sp, #0x18]
     844:      	ldur	x8, [x29, #-0x10]
     848:      	ldr	w8, [x8]
     84c:      	str	w8, [sp, #0x14]
     850:      	ldur	w10, [x29, #-0x14]
     854:      	mov	w8, #0x23c7             // =9159
     858:      	movk	w8, #0xf25f, lsl #16
     85c:      	mul	w10, w8, w10
     860:      	add	w10, w10, w9
     864:      	str	w10, [sp, #0x10]
     868:      	ldr	w10, [sp, #0x14]
     86c:      	mul	w8, w8, w10
     870:      	add	w8, w8, w9
     874:      	str	w8, [sp, #0xc]
     878:      	ldr	w8, [sp, #0x10]
     87c:      	ldr	w10, [sp, #0xc]
     880:      	add	w8, w8, w10
     884:      	subs	w8, w8, w9
     888:      	str	w8, [sp, #0x10]
     88c:      	ldr	w10, [sp, #0x10]
     890:      	mov	w8, #0x3                // =3
     894:      	mul	w8, w8, w10
     898:      	mov	w10, #0xb616            // =46614
     89c:      	movk	w10, #0x85e4, lsl #16
     8a0:      	add	w8, w8, w10
     8a4:      	mov	w10, #0x2e82            // =11906
     8a8:      	movk	w10, #0xa724, lsl #16
     8ac:      	add	w8, w8, w10
     8b0:      	subs	w8, w8, w9
     8b4:      	str	w8, [sp, #0x10]
     8b8:      	ldr	w8, [sp, #0x10]
     8bc:      	subs	w9, w8, w9
     8c0:      	mov	w8, #0xadf7             // =44535
     8c4:      	movk	w8, #0xec1, lsl #16
     8c8:      	mul	w8, w8, w9
     8cc:      	stur	w8, [x29, #-0x14]
     8d0:      	ldur	w0, [x29, #-0x14]
     8d4:      	bl	0xae8 <record_event>
     8d8:      	ldr	w8, [sp, #0x18]
     8dc:      	tbz	w8, #0x1f, 0x8f0 <region_pipeline+0xd8>
     8e0:      	b	0x8e4 <region_pipeline+0xcc>
     8e4:      	ldur	w8, [x29, #-0x14]
     8e8:      	stur	w8, [x29, #-0x4]
     8ec:      	b	0x9c0 <region_pipeline+0x1a8>
     8f0:      	b	0x8f4 <region_pipeline+0xdc>
     8f4:      	ldr	w8, [sp, #0x18]
     8f8:      	subs	w9, w8, #0x1
     8fc:      	str	w9, [sp, #0x18]
     900:      	subs	w8, w8, #0x0
     904:      	b.le	0x9b4 <region_pipeline+0x19c>
     908:      	b	0x90c <region_pipeline+0xf4>
     90c:      	ldur	w0, [x29, #-0x14]
     910:      	bl	0xb14 <next_value>
     914:      	ldr	w9, [sp]
     918:      	str	w0, [sp, #0x14]
     91c:      	ldur	w10, [x29, #-0x14]
     920:      	mov	w8, #0xf01d             // =61469
     924:      	movk	w8, #0x48aa, lsl #16
     928:      	mul	w10, w8, w10
     92c:      	add	w10, w10, w9
     930:      	str	w10, [sp, #0x8]
     934:      	ldr	w10, [sp, #0x14]
     938:      	mul	w8, w8, w10
     93c:      	add	w8, w8, w9
     940:      	str	w8, [sp, #0x4]
     944:      	ldr	w8, [sp, #0x8]
     948:      	ldr	w10, [sp, #0x4]
     94c:      	add	w8, w8, w10
     950:      	subs	w8, w8, w9
     954:      	str	w8, [sp, #0x8]
     958:      	ldr	w10, [sp, #0x8]
     95c:      	mov	w8, #0x5                // =5
     960:      	mul	w8, w8, w10
     964:      	mov	w10, #0x4418            // =17432
     968:      	movk	w10, #0x6058, lsl #16
     96c:      	add	w8, w8, w10
     970:      	mov	w10, #0x7fc5            // =32709
     974:      	movk	w10, #0x6496, lsl #16
     978:      	subs	w8, w8, w10
     97c:      	add	w8, w8, w9
     980:      	str	w8, [sp, #0x8]
     984:      	ldr	w8, [sp, #0x8]
     988:      	subs	w9, w8, w9
     98c:      	mov	w8, #0x5235             // =21045
     990:      	movk	w8, #0xa0f, lsl #16
     994:      	mul	w8, w8, w9
     998:      	stur	w8, [x29, #-0x14]
     99c:      	ldur	w8, [x29, #-0x14]
     9a0:      	ldur	x9, [x29, #-0x10]
     9a4:      	str	w8, [x9]
     9a8:      	ldr	w0, [sp, #0x14]
     9ac:      	bl	0xae8 <record_event>
     9b0:      	b	0x8f4 <region_pipeline+0xdc>
     9b4:      	ldur	w8, [x29, #-0x14]
     9b8:      	stur	w8, [x29, #-0x4]
     9bc:      	b	0x9c0 <region_pipeline+0x1a8>
     9c0:      	ldur	w0, [x29, #-0x4]
     9c4:      	ldp	x29, x30, [sp, #0x30]
     9c8:      	add	sp, sp, #0x40
     9cc:      	ret

00000000000009d0 <region_outputs>:
     9d0:      	sub	sp, sp, #0x30
     9d4:      	stp	x29, x30, [sp, #0x20]
     9d8:      	add	x29, sp, #0x20
     9dc:      	mov	w10, #0x2b0e            // =11022
     9e0:      	movk	w10, #0xf097, lsl #16
     9e4:      	mov	w8, #0x57d7             // =22487
     9e8:      	movk	w8, #0xd9e3, lsl #16
     9ec:      	stur	x0, [x29, #-0x8]
     9f0:      	stur	w1, [x29, #-0xc]
     9f4:      	str	w2, [sp, #0x10]
     9f8:      	ldur	w11, [x29, #-0xc]
     9fc:      	mov	w9, #0x8be7             // =35815
     a00:      	movk	w9, #0x38e6, lsl #16
     a04:      	mul	w11, w9, w11
     a08:      	add	w11, w11, w10
     a0c:      	str	w11, [sp, #0x8]
     a10:      	ldr	w11, [sp, #0x10]
     a14:      	mul	w9, w9, w11
     a18:      	add	w9, w9, w10
     a1c:      	str	w9, [sp, #0x4]
     a20:      	mov	w9, #0x7565             // =30053
     a24:      	movk	w9, #0xb7e6, lsl #16
     a28:      	str	w9, [sp]
     a2c:      	ldr	w9, [sp]
     a30:      	ldr	w11, [sp, #0x8]
     a34:      	add	w9, w9, w11
     a38:      	subs	w9, w9, w10
     a3c:      	str	w9, [sp]
     a40:      	ldr	w11, [sp]
     a44:      	mov	w9, #0x3                // =3
     a48:      	mul	w9, w9, w11
     a4c:      	mov	w11, #0xa9e4            // =43492
     a50:      	movk	w11, #0x1ed1, lsl #16
     a54:      	add	w9, w9, w11
     a58:      	ldr	w11, [sp, #0x4]
     a5c:      	add	w9, w9, w11
     a60:      	subs	w9, w9, w10
     a64:      	str	w9, [sp, #0x8]
     a68:      	ldr	w9, [sp, #0x8]
     a6c:      	ldr	w11, [sp]
     a70:      	subs	w9, w9, w11
     a74:      	add	w9, w9, w10
     a78:      	str	w9, [sp, #0x4]
     a7c:      	ldr	w9, [sp]
     a80:      	subs	w9, w9, w10
     a84:      	mul	w9, w8, w9
     a88:      	str	w9, [sp, #0xc]
     a8c:      	ldr	w9, [sp, #0x8]
     a90:      	subs	w9, w9, w10
     a94:      	mul	w9, w8, w9
     a98:      	stur	w9, [x29, #-0xc]
     a9c:      	ldr	w9, [sp, #0x4]
     aa0:      	subs	w9, w9, w10
     aa4:      	mul	w8, w8, w9
     aa8:      	str	w8, [sp, #0x10]
     aac:      	ldur	w0, [x29, #-0xc]
     ab0:      	bl	0xae8 <record_event>
     ab4:      	ldr	w8, [sp, #0x10]
     ab8:      	ldur	x9, [x29, #-0x8]
     abc:      	str	w8, [x9]
     ac0:      	ldr	w8, [sp, #0xc]
     ac4:      	ldur	x9, [x29, #-0x8]
     ac8:      	str	w8, [x9, #0x4]
     acc:      	ldur	w8, [x29, #-0xc]
     ad0:      	ldr	w9, [sp, #0x10]
     ad4:      	subs	w8, w8, w9
     ad8:      	cset	w0, eq
     adc:      	ldp	x29, x30, [sp, #0x20]
     ae0:      	add	sp, sp, #0x30
     ae4:      	ret

0000000000000ae8 <record_event>:
     ae8:      	sub	sp, sp, #0x10
     aec:      	str	w0, [sp, #0xc]
     af0:      	adrp	x9, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     af4:      	ldr	w8, [x9, #0x4c]
     af8:      	mov	w10, #0x21              // =33
     afc:      	mul	w8, w8, w10
     b00:      	ldr	w10, [sp, #0xc]
     b04:      	eor	w8, w8, w10
     b08:      	str	w8, [x9, #0x4c]
     b0c:      	add	sp, sp, #0x10
     b10:      	ret

0000000000000b14 <next_value>:
     b14:      	sub	sp, sp, #0x20
     b18:      	stp	x29, x30, [sp, #0x10]
     b1c:      	add	x29, sp, #0x10
     b20:      	stur	w0, [x29, #-0x4]
     b24:      	ldur	w0, [x29, #-0x4]
     b28:      	bl	0xae8 <record_event>
     b2c:      	ldur	w10, [x29, #-0x4]
     b30:      	adrp	x9, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     b34:      	add	x9, x9, #0x50
     b38:      	ldr	w8, [x9, #0x4]
     b3c:      	add	w8, w8, w10
     b40:      	str	w8, [x9, #0x4]
     b44:      	ldur	w8, [x29, #-0x4]
     b48:      	ldr	w9, [x9, #0x4]
     b4c:      	add	w0, w8, w9
     b50:      	ldp	x29, x30, [sp, #0x10]
     b54:      	add	sp, sp, #0x20
     b58:      	ret

0000000000000b5c <main>:
     b5c:      	sub	sp, sp, #0x80
     b60:      	stp	x29, x30, [sp, #0x70]
     b64:      	add	x29, sp, #0x70
     b68:      	stur	wzr, [x29, #-0x4]
     b6c:      	stur	w0, [x29, #-0x8]
     b70:      	stur	x1, [x29, #-0x10]
     b74:      	ldur	w8, [x29, #-0x8]
     b78:      	subs	w8, w8, #0x3
     b7c:      	b.eq	0xb90 <main+0x34>
     b80:      	b	0xb84 <main+0x28>
     b84:      	mov	w8, #0x2                // =2
     b88:      	stur	w8, [x29, #-0x4]
     b8c:      	b	0xd34 <main+0x1d8>
     b90:      	ldur	x8, [x29, #-0x10]
     b94:      	ldr	x0, [x8, #0x8]
     b98:      	mov	x1, xzr
     b9c:      	str	x1, [sp, #0x10]
     ba0:      	mov	w2, #0xa                // =10
     ba4:      	str	w2, [sp, #0x1c]
     ba8:      	bl	0x670 <strtoul@plt>
     bac:      	ldr	x1, [sp, #0x10]
     bb0:      	ldr	w2, [sp, #0x1c]
     bb4:      	stur	x0, [x29, #-0x18]
     bb8:      	ldur	x8, [x29, #-0x10]
     bbc:      	ldr	x0, [x8, #0x10]
     bc0:      	bl	0x670 <strtoul@plt>
     bc4:      	mov	w8, w0
     bc8:      	stur	w8, [x29, #-0x1c]
     bcc:      	stur	wzr, [x29, #-0x20]
     bd0:      	mov	w0, #0x1                // =1
     bd4:      	sub	x1, x29, #0x30
     bd8:      	bl	0x6a0 <clock_gettime@plt>
     bdc:      	cbz	w0, 0xbf0 <main+0x94>
     be0:      	b	0xbe4 <main+0x88>
     be4:      	mov	w8, #0x2                // =2
     be8:      	stur	w8, [x29, #-0x4]
     bec:      	b	0xd34 <main+0x1d8>
     bf0:      	str	xzr, [sp, #0x28]
     bf4:      	b	0xbf8 <main+0x9c>
     bf8:      	ldr	x8, [sp, #0x28]
     bfc:      	ldur	x9, [x29, #-0x18]
     c00:      	subs	x8, x8, x9
     c04:      	b.hs	0xca8 <main+0x14c>
     c08:      	b	0xc0c <main+0xb0>
     c0c:      	ldur	w9, [x29, #-0x1c]
     c10:      	ldur	w8, [x29, #-0x1c]
     c14:      	eor	w8, w8, w9, lsl #13
     c18:      	stur	w8, [x29, #-0x1c]
     c1c:      	ldur	w9, [x29, #-0x1c]
     c20:      	ldur	w8, [x29, #-0x1c]
     c24:      	eor	w8, w8, w9, lsr #17
     c28:      	stur	w8, [x29, #-0x1c]
     c2c:      	ldur	w9, [x29, #-0x1c]
     c30:      	ldur	w8, [x29, #-0x1c]
     c34:      	eor	w8, w8, w9, lsl #5
     c38:      	stur	w8, [x29, #-0x1c]
     c3c:      	ldur	w1, [x29, #-0x1c]
     c40:      	ldr	x8, [sp, #0x28]
     c44:      	mov	x10, #0xa               // =10
     c48:      	udiv	x9, x8, x10
     c4c:      	mul	x9, x9, x10
     c50:      	subs	x8, x8, x9
     c54:      	subs	w2, w8, #0x1
     c58:      	adrp	x0, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     c5c:      	add	x0, x0, #0x50
     c60:      	str	x0, [sp, #0x8]
     c64:      	bl	0x818 <region_pipeline>
     c68:      	mov	w9, w0
     c6c:      	ldr	x0, [sp, #0x8]
     c70:      	ldur	w8, [x29, #-0x20]
     c74:      	add	w8, w8, w9
     c78:      	stur	w8, [x29, #-0x20]
     c7c:      	ldur	w1, [x29, #-0x1c]
     c80:      	ldur	w2, [x29, #-0x20]
     c84:      	bl	0x9d0 <region_outputs>
     c88:      	ldur	w8, [x29, #-0x20]
     c8c:      	add	w8, w8, w0
     c90:      	stur	w8, [x29, #-0x20]
     c94:      	b	0xc98 <main+0x13c>
     c98:      	ldr	x8, [sp, #0x28]
     c9c:      	add	x8, x8, #0x1
     ca0:      	str	x8, [sp, #0x28]
     ca4:      	b	0xbf8 <main+0x9c>
     ca8:      	mov	w0, #0x1                // =1
     cac:      	add	x1, sp, #0x30
     cb0:      	bl	0x6a0 <clock_gettime@plt>
     cb4:      	cbz	w0, 0xcc8 <main+0x16c>
     cb8:      	b	0xcbc <main+0x160>
     cbc:      	mov	w8, #0x2                // =2
     cc0:      	stur	w8, [x29, #-0x4]
     cc4:      	b	0xd34 <main+0x1d8>
     cc8:      	ldr	x8, [sp, #0x30]
     ccc:      	ldur	x9, [x29, #-0x30]
     cd0:      	subs	x8, x8, x9
     cd4:      	scvtf	d2, x8
     cd8:      	ldr	x8, [sp, #0x38]
     cdc:      	ldur	x9, [x29, #-0x28]
     ce0:      	subs	x8, x8, x9
     ce4:      	scvtf	d0, x8
     ce8:      	adrp	x8, 0x0 <strtoul@GLIBC_2.17>
     cec:      	ldr	d1, [x8, #0xd60]
     cf0:      	fmadd	d0, d0, d1, d2
     cf4:      	str	d0, [sp, #0x20]
     cf8:      	ldr	d0, [sp, #0x20]
     cfc:      	ldur	w1, [x29, #-0x20]
     d00:      	adrp	x9, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     d04:      	adrp	x8, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     d08:      	add	x8, x8, #0x50
     d0c:      	ldr	w2, [x9, #0x50]
     d10:      	ldr	w3, [x8, #0x4]
     d14:      	ldr	w4, [x8, #0x8]
     d18:      	adrp	x8, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     d1c:      	ldr	w5, [x8, #0x4c]
     d20:      	adrp	x0, 0x0 <strtoul@GLIBC_2.17>
     d24:      	add	x0, x0, #0xd68
     d28:      	bl	0x6d0 <printf@plt>
     d2c:      	stur	wzr, [x29, #-0x4]
     d30:      	b	0xd34 <main+0x1d8>
     d34:      	ldur	w0, [x29, #-0x4]
     d38:      	ldp	x29, x30, [sp, #0x70]
     d3c:      	add	sp, sp, #0x80
     d40:      	ret

Disassembly of section .fini:

0000000000000d44 <_fini>:
     d44:      	nop
     d48:      	stp	x29, x30, [sp, #-0x10]!
     d4c:      	mov	x29, sp
     d50:      	ldp	x29, x30, [sp], #0x10
     d54:      	ret
