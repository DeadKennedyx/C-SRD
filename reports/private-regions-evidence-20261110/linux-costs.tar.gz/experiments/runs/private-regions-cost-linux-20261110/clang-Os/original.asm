
/work/experiments/runs/private-regions-cost-linux-20261110/clang-Os/original:	file format elf64-littleaarch64

Disassembly of section .init:

0000000000000638 <_init>:
     638:      	nop
     63c:      	stp	x29, x30, [sp, #-0x10]!
     640:      	mov	x29, sp
     644:      	bl	0x734 <call_weak_fn>
     648:      	ldp	x29, x30, [sp], #0x10
     64c:      	ret

Disassembly of section .plt:

0000000000000650 <.plt>:
     650:      	stp	x16, x30, [sp, #-0x10]!
     654:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e354>
     658:      	ldr	x17, [x16, #0xff8]
     65c:      	add	x16, x16, #0xff8
     660:      	br	x17
     664:      	nop
     668:      	nop
     66c:      	nop

0000000000000670 <strtoul@plt>:
     670:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     674:      	ldr	x17, [x16]
     678:      	add	x16, x16, #0x0
     67c:      	br	x17

0000000000000680 <__libc_start_main@plt>:
     680:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     684:      	ldr	x17, [x16, #0x8]
     688:      	add	x16, x16, #0x8
     68c:      	br	x17

0000000000000690 <__cxa_finalize@plt>:
     690:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     694:      	ldr	x17, [x16, #0x10]
     698:      	add	x16, x16, #0x10
     69c:      	br	x17

00000000000006a0 <clock_gettime@plt>:
     6a0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6a4:      	ldr	x17, [x16, #0x18]
     6a8:      	add	x16, x16, #0x18
     6ac:      	br	x17

00000000000006b0 <__gmon_start__@plt>:
     6b0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6b4:      	ldr	x17, [x16, #0x20]
     6b8:      	add	x16, x16, #0x20
     6bc:      	br	x17

00000000000006c0 <abort@plt>:
     6c0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6c4:      	ldr	x17, [x16, #0x28]
     6c8:      	add	x16, x16, #0x28
     6cc:      	br	x17

00000000000006d0 <printf@plt>:
     6d0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6d4:      	ldr	x17, [x16, #0x30]
     6d8:      	add	x16, x16, #0x30
     6dc:      	br	x17

Disassembly of section .text:

0000000000000700 <_start>:
     700:      	nop
     704:      	mov	x29, #0x0               // =0
     708:      	mov	x30, #0x0               // =0
     70c:      	mov	x5, x0
     710:      	ldr	x1, [sp]
     714:      	add	x2, sp, #0x8
     718:      	mov	x6, sp
     71c:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e354>
     720:      	ldr	x0, [x0, #0xfd8]
     724:      	mov	x3, #0x0                // =0
     728:      	mov	x4, #0x0                // =0
     72c:      	bl	0x680 <__libc_start_main@plt>
     730:      	bl	0x6c0 <abort@plt>

0000000000000734 <call_weak_fn>:
     734:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e354>
     738:      	ldr	x0, [x0, #0xfd0]
     73c:      	cbz	x0, 0x744 <call_weak_fn+0x10>
     740:      	b	0x6b0 <__gmon_start__@plt>
     744:      	ret
     748:      	nop
     74c:      	nop

0000000000000750 <deregister_tm_clones>:
     750:      	adrp	x0, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     754:      	add	x0, x0, #0x48
     758:      	adrp	x1, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     75c:      	add	x1, x1, #0x48
     760:      	cmp	x1, x0
     764:      	b.eq	0x77c <deregister_tm_clones+0x2c>
     768:      	adrp	x1, 0x1f000 <__FRAME_END__+0x1e354>
     76c:      	ldr	x1, [x1, #0xfc0]
     770:      	cbz	x1, 0x77c <deregister_tm_clones+0x2c>
     774:      	mov	x16, x1
     778:      	br	x16
     77c:      	ret

0000000000000780 <register_tm_clones>:
     780:      	adrp	x0, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     784:      	add	x0, x0, #0x48
     788:      	adrp	x1, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     78c:      	add	x1, x1, #0x48
     790:      	sub	x1, x1, x0
     794:      	lsr	x2, x1, #63
     798:      	add	x1, x2, x1, asr #3
     79c:      	asr	x1, x1, #1
     7a0:      	cbz	x1, 0x7b8 <register_tm_clones+0x38>
     7a4:      	adrp	x2, 0x1f000 <__FRAME_END__+0x1e354>
     7a8:      	ldr	x2, [x2, #0xfe0]
     7ac:      	cbz	x2, 0x7b8 <register_tm_clones+0x38>
     7b0:      	mov	x16, x2
     7b4:      	br	x16
     7b8:      	ret
     7bc:      	nop

00000000000007c0 <__do_global_dtors_aux>:
     7c0:      	paciasp
     7c4:      	stp	x29, x30, [sp, #-0x20]!
     7c8:      	mov	x29, sp
     7cc:      	str	x19, [sp, #0x10]
     7d0:      	adrp	x19, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     7d4:      	ldrb	w0, [x19, #0x48]
     7d8:      	tbnz	w0, #0x0, 0x800 <__do_global_dtors_aux+0x40>
     7dc:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e354>
     7e0:      	ldr	x0, [x0, #0xfc8]
     7e4:      	cbz	x0, 0x7f4 <__do_global_dtors_aux+0x34>
     7e8:      	adrp	x0, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     7ec:      	ldr	x0, [x0, #0x40]
     7f0:      	bl	0x690 <__cxa_finalize@plt>
     7f4:      	bl	0x750 <deregister_tm_clones>
     7f8:      	mov	w0, #0x1                // =1
     7fc:      	strb	w0, [x19, #0x48]
     800:      	ldr	x19, [sp, #0x10]
     804:      	ldp	x29, x30, [sp], #0x20
     808:      	autiasp
     80c:      	ret

0000000000000810 <frame_dummy>:
     810:      	bti	c
     814:      	b	0x780 <register_tm_clones>

0000000000000818 <region_pipeline>:
     818:      	stp	x29, x30, [sp, #-0x30]!
     81c:      	str	x21, [sp, #0x10]
     820:      	stp	x20, x19, [sp, #0x20]
     824:      	mov	x29, sp
     828:      	ldr	w8, [x0]
     82c:      	mov	x19, x0
     830:      	mov	w21, w2
     834:      	add	w8, w8, w1
     838:      	add	w8, w8, w8, lsl #1
     83c:      	add	w20, w8, #0xb
     840:      	mov	w0, w20
     844:      	bl	0x8d4 <record_event>
     848:      	cmp	w21, #0x1
     84c:      	b.lt	0x87c <region_pipeline+0x64>
     850:      	add	w21, w21, #0x1
     854:      	mov	w0, w20
     858:      	bl	0x8ec <next_value>
     85c:      	add	w8, w0, w20
     860:      	add	w8, w8, w8, lsl #2
     864:      	sub	w20, w8, #0x7
     868:      	str	w20, [x19]
     86c:      	bl	0x8d4 <record_event>
     870:      	sub	w21, w21, #0x1
     874:      	cmp	w21, #0x1
     878:      	b.hi	0x854 <region_pipeline+0x3c>
     87c:      	mov	w0, w20
     880:      	ldp	x20, x19, [sp, #0x20]
     884:      	ldr	x21, [sp, #0x10]
     888:      	ldp	x29, x30, [sp], #0x30
     88c:      	ret

0000000000000890 <region_outputs>:
     890:      	stp	x29, x30, [sp, #-0x30]!
     894:      	str	x21, [sp, #0x10]
     898:      	stp	x20, x19, [sp, #0x20]
     89c:      	mov	x29, sp
     8a0:      	add	w20, w1, #0x11
     8a4:      	mov	x19, x0
     8a8:      	add	w8, w20, w20, lsl #1
     8ac:      	add	w0, w8, w2
     8b0:      	sub	w21, w0, w20
     8b4:      	bl	0x8d4 <record_event>
     8b8:      	cmp	w20, #0x0
     8bc:      	cset	w0, eq
     8c0:      	stp	w21, w20, [x19]
     8c4:      	ldp	x20, x19, [sp, #0x20]
     8c8:      	ldr	x21, [sp, #0x10]
     8cc:      	ldp	x29, x30, [sp], #0x30
     8d0:      	ret

00000000000008d4 <record_event>:
     8d4:      	adrp	x8, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     8d8:      	ldr	w9, [x8, #0x4c]
     8dc:      	add	w9, w9, w9, lsl #5
     8e0:      	eor	w9, w9, w0
     8e4:      	str	w9, [x8, #0x4c]
     8e8:      	ret

00000000000008ec <next_value>:
     8ec:      	adrp	x8, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     8f0:      	adrp	x10, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     8f4:      	ldr	w9, [x8, #0x4c]
     8f8:      	ldr	w11, [x10, #0x54]
     8fc:      	add	w9, w9, w9, lsl #5
     900:      	add	w11, w11, w0
     904:      	str	w11, [x10, #0x54]
     908:      	eor	w9, w9, w0
     90c:      	add	w0, w11, w0
     910:      	str	w9, [x8, #0x4c]
     914:      	ret

0000000000000918 <main>:
     918:      	cmp	w0, #0x3
     91c:      	b.ne	0x9f0 <main+0xd8>
     920:      	sub	sp, sp, #0x70
     924:      	stp	x29, x30, [sp, #0x20]
     928:      	stp	x26, x25, [sp, #0x30]
     92c:      	stp	x24, x23, [sp, #0x40]
     930:      	stp	x22, x21, [sp, #0x50]
     934:      	stp	x20, x19, [sp, #0x60]
     938:      	add	x29, sp, #0x20
     93c:      	ldr	x0, [x1, #0x8]
     940:      	mov	x19, x1
     944:      	mov	x1, xzr
     948:      	mov	w2, #0xa                // =10
     94c:      	bl	0x670 <strtoul@plt>
     950:      	ldr	x8, [x19, #0x10]
     954:      	mov	x20, x0
     958:      	mov	x1, xzr
     95c:      	mov	w2, #0xa                // =10
     960:      	mov	x0, x8
     964:      	bl	0x670 <strtoul@plt>
     968:      	mov	x21, x0
     96c:      	add	x1, sp, #0x10
     970:      	mov	w0, #0x1                // =1
     974:      	bl	0x6a0 <clock_gettime@plt>
     978:      	cbnz	w0, 0xa0c <main+0xf4>
     97c:      	cbz	x20, 0x9f8 <main+0xe0>
     980:      	mov	x25, #-0x3333333333333334 // =-3689348814741910324
     984:      	mov	x23, xzr
     988:      	mov	w19, wzr
     98c:      	mov	w24, #-0x1              // =-1
     990:      	movk	x25, #0xcccd
     994:      	mov	w26, #0xa               // =10
     998:      	adrp	x22, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     99c:      	add	x22, x22, #0x50
     9a0:      	umulh	x8, x23, x25
     9a4:      	eor	w9, w21, w21, lsl #13
     9a8:      	mov	x0, x22
     9ac:      	eor	w9, w9, w9, lsr #17
     9b0:      	eor	w21, w9, w9, lsl #5
     9b4:      	lsr	x8, x8, #3
     9b8:      	mov	w1, w21
     9bc:      	msub	w2, w8, w26, w24
     9c0:      	bl	0x818 <region_pipeline>
     9c4:      	add	w19, w0, w19
     9c8:      	mov	x0, x22
     9cc:      	mov	w1, w21
     9d0:      	mov	w2, w19
     9d4:      	bl	0x890 <region_outputs>
     9d8:      	subs	x20, x20, #0x1
     9dc:      	add	w19, w19, w0
     9e0:      	add	x23, x23, #0x1
     9e4:      	add	w24, w24, #0x1
     9e8:      	b.ne	0x9a0 <main+0x88>
     9ec:      	b	0x9fc <main+0xe4>
     9f0:      	mov	w0, #0x2                // =2
     9f4:      	ret
     9f8:      	mov	w19, wzr
     9fc:      	mov	x1, sp
     a00:      	mov	w0, #0x1                // =1
     a04:      	bl	0x6a0 <clock_gettime@plt>
     a08:      	cbz	w0, 0xa2c <main+0x114>
     a0c:      	mov	w0, #0x2                // =2
     a10:      	ldp	x20, x19, [sp, #0x60]
     a14:      	ldp	x22, x21, [sp, #0x50]
     a18:      	ldp	x24, x23, [sp, #0x40]
     a1c:      	ldp	x26, x25, [sp, #0x30]
     a20:      	ldp	x29, x30, [sp, #0x20]
     a24:      	add	sp, sp, #0x70
     a28:      	ret
     a2c:      	ldp	x8, x9, [sp]
     a30:      	adrp	x0, 0x0 <strtoul@GLIBC_2.17>
     a34:      	add	x0, x0, #0xaa8
     a38:      	ldp	x10, x11, [sp, #0x10]
     a3c:      	mov	w1, w19
     a40:      	sub	x8, x8, x10
     a44:      	sub	x9, x9, x11
     a48:      	scvtf	d0, x8
     a4c:      	scvtf	d1, x9
     a50:      	adrp	x8, 0x0 <strtoul@GLIBC_2.17>
     a54:      	ldr	d2, [x8, #0xaa0]
     a58:      	adrp	x8, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     a5c:      	add	x8, x8, #0x50
     a60:      	adrp	x9, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     a64:      	ldr	w4, [x8, #0x8]
     a68:      	ldp	w2, w3, [x8]
     a6c:      	fmadd	d0, d1, d2, d0
     a70:      	ldr	w5, [x9, #0x4c]
     a74:      	bl	0x6d0 <printf@plt>
     a78:      	mov	w0, wzr
     a7c:      	b	0xa10 <main+0xf8>

Disassembly of section .fini:

0000000000000a80 <_fini>:
     a80:      	nop
     a84:      	stp	x29, x30, [sp, #-0x10]!
     a88:      	mov	x29, sp
     a8c:      	ldp	x29, x30, [sp], #0x10
     a90:      	ret
