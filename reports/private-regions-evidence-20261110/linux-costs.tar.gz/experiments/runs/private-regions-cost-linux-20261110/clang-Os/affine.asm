
/work/experiments/runs/private-regions-cost-linux-20261110/clang-Os/affine:	file format elf64-littleaarch64

Disassembly of section .init:

0000000000000638 <_init>:
     638:      	nop
     63c:      	stp	x29, x30, [sp, #-0x10]!
     640:      	mov	x29, sp
     644:      	bl	0x734 <call_weak_fn>
     648:      	ldp	x29, x30, [sp], #0x10
     64c:      	ret

Disassembly of section .plt:

0000000000000650 <.plt>:
     650:      	stp	x16, x30, [sp, #-0x10]!
     654:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e30c>
     658:      	ldr	x17, [x16, #0xff8]
     65c:      	add	x16, x16, #0xff8
     660:      	br	x17
     664:      	nop
     668:      	nop
     66c:      	nop

0000000000000670 <strtoul@plt>:
     670:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     674:      	ldr	x17, [x16]
     678:      	add	x16, x16, #0x0
     67c:      	br	x17

0000000000000680 <__libc_start_main@plt>:
     680:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     684:      	ldr	x17, [x16, #0x8]
     688:      	add	x16, x16, #0x8
     68c:      	br	x17

0000000000000690 <__cxa_finalize@plt>:
     690:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     694:      	ldr	x17, [x16, #0x10]
     698:      	add	x16, x16, #0x10
     69c:      	br	x17

00000000000006a0 <clock_gettime@plt>:
     6a0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6a4:      	ldr	x17, [x16, #0x18]
     6a8:      	add	x16, x16, #0x18
     6ac:      	br	x17

00000000000006b0 <__gmon_start__@plt>:
     6b0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6b4:      	ldr	x17, [x16, #0x20]
     6b8:      	add	x16, x16, #0x20
     6bc:      	br	x17

00000000000006c0 <abort@plt>:
     6c0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6c4:      	ldr	x17, [x16, #0x28]
     6c8:      	add	x16, x16, #0x28
     6cc:      	br	x17

00000000000006d0 <printf@plt>:
     6d0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6d4:      	ldr	x17, [x16, #0x30]
     6d8:      	add	x16, x16, #0x30
     6dc:      	br	x17

Disassembly of section .text:

0000000000000700 <_start>:
     700:      	nop
     704:      	mov	x29, #0x0               // =0
     708:      	mov	x30, #0x0               // =0
     70c:      	mov	x5, x0
     710:      	ldr	x1, [sp]
     714:      	add	x2, sp, #0x8
     718:      	mov	x6, sp
     71c:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e30c>
     720:      	ldr	x0, [x0, #0xfd8]
     724:      	mov	x3, #0x0                // =0
     728:      	mov	x4, #0x0                // =0
     72c:      	bl	0x680 <__libc_start_main@plt>
     730:      	bl	0x6c0 <abort@plt>

0000000000000734 <call_weak_fn>:
     734:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e30c>
     738:      	ldr	x0, [x0, #0xfd0]
     73c:      	cbz	x0, 0x744 <call_weak_fn+0x10>
     740:      	b	0x6b0 <__gmon_start__@plt>
     744:      	ret
     748:      	nop
     74c:      	nop

0000000000000750 <deregister_tm_clones>:
     750:      	adrp	x0, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     754:      	add	x0, x0, #0x48
     758:      	adrp	x1, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     75c:      	add	x1, x1, #0x48
     760:      	cmp	x1, x0
     764:      	b.eq	0x77c <deregister_tm_clones+0x2c>
     768:      	adrp	x1, 0x1f000 <__FRAME_END__+0x1e30c>
     76c:      	ldr	x1, [x1, #0xfc0]
     770:      	cbz	x1, 0x77c <deregister_tm_clones+0x2c>
     774:      	mov	x16, x1
     778:      	br	x16
     77c:      	ret

0000000000000780 <register_tm_clones>:
     780:      	adrp	x0, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     784:      	add	x0, x0, #0x48
     788:      	adrp	x1, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     78c:      	add	x1, x1, #0x48
     790:      	sub	x1, x1, x0
     794:      	lsr	x2, x1, #63
     798:      	add	x1, x2, x1, asr #3
     79c:      	asr	x1, x1, #1
     7a0:      	cbz	x1, 0x7b8 <register_tm_clones+0x38>
     7a4:      	adrp	x2, 0x1f000 <__FRAME_END__+0x1e30c>
     7a8:      	ldr	x2, [x2, #0xfe0]
     7ac:      	cbz	x2, 0x7b8 <register_tm_clones+0x38>
     7b0:      	mov	x16, x2
     7b4:      	br	x16
     7b8:      	ret
     7bc:      	nop

00000000000007c0 <__do_global_dtors_aux>:
     7c0:      	paciasp
     7c4:      	stp	x29, x30, [sp, #-0x20]!
     7c8:      	mov	x29, sp
     7cc:      	str	x19, [sp, #0x10]
     7d0:      	adrp	x19, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     7d4:      	ldrb	w0, [x19, #0x48]
     7d8:      	tbnz	w0, #0x0, 0x800 <__do_global_dtors_aux+0x40>
     7dc:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e30c>
     7e0:      	ldr	x0, [x0, #0xfc8]
     7e4:      	cbz	x0, 0x7f4 <__do_global_dtors_aux+0x34>
     7e8:      	adrp	x0, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     7ec:      	ldr	x0, [x0, #0x40]
     7f0:      	bl	0x690 <__cxa_finalize@plt>
     7f4:      	bl	0x750 <deregister_tm_clones>
     7f8:      	mov	w0, #0x1                // =1
     7fc:      	strb	w0, [x19, #0x48]
     800:      	ldr	x19, [sp, #0x10]
     804:      	ldp	x29, x30, [sp], #0x20
     808:      	autiasp
     80c:      	ret

0000000000000810 <frame_dummy>:
     810:      	bti	c
     814:      	b	0x780 <register_tm_clones>

0000000000000818 <region_pipeline>:
     818:      	stp	x29, x30, [sp, #-0x30]!
     81c:      	str	x21, [sp, #0x10]
     820:      	stp	x20, x19, [sp, #0x20]
     824:      	mov	x29, sp
     828:      	ldr	w8, [x0]
     82c:      	mov	x19, x0
     830:      	mov	w21, w2
     834:      	add	w8, w8, w1
     838:      	add	w8, w8, w8, lsl #1
     83c:      	add	w20, w8, #0xb
     840:      	mov	w0, w20
     844:      	bl	0x920 <record_event>
     848:      	cmp	w21, #0x1
     84c:      	b.lt	0x87c <region_pipeline+0x64>
     850:      	add	w21, w21, #0x1
     854:      	mov	w0, w20
     858:      	bl	0x938 <next_value>
     85c:      	add	w8, w0, w20
     860:      	add	w8, w8, w8, lsl #2
     864:      	sub	w20, w8, #0x7
     868:      	str	w20, [x19]
     86c:      	bl	0x920 <record_event>
     870:      	sub	w21, w21, #0x1
     874:      	cmp	w21, #0x1
     878:      	b.hi	0x854 <region_pipeline+0x3c>
     87c:      	mov	w0, w20
     880:      	ldp	x20, x19, [sp, #0x20]
     884:      	ldr	x21, [sp, #0x10]
     888:      	ldp	x29, x30, [sp], #0x30
     88c:      	ret

0000000000000890 <region_outputs>:
     890:      	stp	x29, x30, [sp, #-0x30]!
     894:      	stp	x22, x21, [sp, #0x10]
     898:      	stp	x20, x19, [sp, #0x20]
     89c:      	mov	x29, sp
     8a0:      	mov	w8, #0x8be7             // =35815
     8a4:      	mov	w9, #0xa3b5             // =41909
     8a8:      	mov	w10, #0x602f            // =24623
     8ac:      	movk	w8, #0x38e6, lsl #16
     8b0:      	movk	w9, #0xaab3, lsl #16
     8b4:      	movk	w10, #0x27b3, lsl #16
     8b8:      	mul	w8, w2, w8
     8bc:      	mov	w11, #0x3fba            // =16314
     8c0:      	mov	x19, x0
     8c4:      	madd	w8, w1, w9, w8
     8c8:      	mov	w9, #0x7419             // =29721
     8cc:      	movk	w11, #0x91fd, lsl #16
     8d0:      	movk	w9, #0xc719, lsl #16
     8d4:      	add	w22, w1, #0x11
     8d8:      	add	w8, w8, w10
     8dc:      	mov	w10, #0x57d7            // =22487
     8e0:      	madd	w9, w1, w9, w8
     8e4:      	movk	w10, #0xd9e3, lsl #16
     8e8:      	madd	w20, w8, w10, w11
     8ec:      	mov	w8, #0x347f             // =13439
     8f0:      	movk	w8, #0x66eb, lsl #16
     8f4:      	mul	w8, w8, w10
     8f8:      	mov	w0, w20
     8fc:      	madd	w21, w9, w10, w8
     900:      	bl	0x920 <record_event>
     904:      	cmp	w20, w21
     908:      	cset	w0, eq
     90c:      	stp	w21, w22, [x19]
     910:      	ldp	x20, x19, [sp, #0x20]
     914:      	ldp	x22, x21, [sp, #0x10]
     918:      	ldp	x29, x30, [sp], #0x30
     91c:      	ret

0000000000000920 <record_event>:
     920:      	adrp	x8, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     924:      	ldr	w9, [x8, #0x4c]
     928:      	add	w9, w9, w9, lsl #5
     92c:      	eor	w9, w9, w0
     930:      	str	w9, [x8, #0x4c]
     934:      	ret

0000000000000938 <next_value>:
     938:      	adrp	x8, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     93c:      	adrp	x10, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     940:      	ldr	w9, [x8, #0x4c]
     944:      	ldr	w11, [x10, #0x54]
     948:      	add	w9, w9, w9, lsl #5
     94c:      	add	w11, w11, w0
     950:      	str	w11, [x10, #0x54]
     954:      	eor	w9, w9, w0
     958:      	add	w0, w11, w0
     95c:      	str	w9, [x8, #0x4c]
     960:      	ret

0000000000000964 <main>:
     964:      	cmp	w0, #0x3
     968:      	b.ne	0xa3c <main+0xd8>
     96c:      	sub	sp, sp, #0x70
     970:      	stp	x29, x30, [sp, #0x20]
     974:      	stp	x26, x25, [sp, #0x30]
     978:      	stp	x24, x23, [sp, #0x40]
     97c:      	stp	x22, x21, [sp, #0x50]
     980:      	stp	x20, x19, [sp, #0x60]
     984:      	add	x29, sp, #0x20
     988:      	ldr	x0, [x1, #0x8]
     98c:      	mov	x19, x1
     990:      	mov	x1, xzr
     994:      	mov	w2, #0xa                // =10
     998:      	bl	0x670 <strtoul@plt>
     99c:      	ldr	x8, [x19, #0x10]
     9a0:      	mov	x20, x0
     9a4:      	mov	x1, xzr
     9a8:      	mov	w2, #0xa                // =10
     9ac:      	mov	x0, x8
     9b0:      	bl	0x670 <strtoul@plt>
     9b4:      	mov	x21, x0
     9b8:      	add	x1, sp, #0x10
     9bc:      	mov	w0, #0x1                // =1
     9c0:      	bl	0x6a0 <clock_gettime@plt>
     9c4:      	cbnz	w0, 0xa58 <main+0xf4>
     9c8:      	cbz	x20, 0xa44 <main+0xe0>
     9cc:      	mov	x25, #-0x3333333333333334 // =-3689348814741910324
     9d0:      	mov	x23, xzr
     9d4:      	mov	w19, wzr
     9d8:      	mov	w24, #-0x1              // =-1
     9dc:      	movk	x25, #0xcccd
     9e0:      	mov	w26, #0xa               // =10
     9e4:      	adrp	x22, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     9e8:      	add	x22, x22, #0x50
     9ec:      	umulh	x8, x23, x25
     9f0:      	eor	w9, w21, w21, lsl #13
     9f4:      	mov	x0, x22
     9f8:      	eor	w9, w9, w9, lsr #17
     9fc:      	eor	w21, w9, w9, lsl #5
     a00:      	lsr	x8, x8, #3
     a04:      	mov	w1, w21
     a08:      	msub	w2, w8, w26, w24
     a0c:      	bl	0x818 <region_pipeline>
     a10:      	add	w19, w0, w19
     a14:      	mov	x0, x22
     a18:      	mov	w1, w21
     a1c:      	mov	w2, w19
     a20:      	bl	0x890 <region_outputs>
     a24:      	subs	x20, x20, #0x1
     a28:      	add	w19, w19, w0
     a2c:      	add	x23, x23, #0x1
     a30:      	add	w24, w24, #0x1
     a34:      	b.ne	0x9ec <main+0x88>
     a38:      	b	0xa48 <main+0xe4>
     a3c:      	mov	w0, #0x2                // =2
     a40:      	ret
     a44:      	mov	w19, wzr
     a48:      	mov	x1, sp
     a4c:      	mov	w0, #0x1                // =1
     a50:      	bl	0x6a0 <clock_gettime@plt>
     a54:      	cbz	w0, 0xa78 <main+0x114>
     a58:      	mov	w0, #0x2                // =2
     a5c:      	ldp	x20, x19, [sp, #0x60]
     a60:      	ldp	x22, x21, [sp, #0x50]
     a64:      	ldp	x24, x23, [sp, #0x40]
     a68:      	ldp	x26, x25, [sp, #0x30]
     a6c:      	ldp	x29, x30, [sp, #0x20]
     a70:      	add	sp, sp, #0x70
     a74:      	ret
     a78:      	ldp	x8, x9, [sp]
     a7c:      	adrp	x0, 0x0 <strtoul@GLIBC_2.17>
     a80:      	add	x0, x0, #0xaf0
     a84:      	ldp	x10, x11, [sp, #0x10]
     a88:      	mov	w1, w19
     a8c:      	sub	x8, x8, x10
     a90:      	sub	x9, x9, x11
     a94:      	scvtf	d0, x8
     a98:      	scvtf	d1, x9
     a9c:      	adrp	x8, 0x0 <strtoul@GLIBC_2.17>
     aa0:      	ldr	d2, [x8, #0xae8]
     aa4:      	adrp	x8, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     aa8:      	add	x8, x8, #0x50
     aac:      	adrp	x9, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     ab0:      	ldr	w4, [x8, #0x8]
     ab4:      	ldp	w2, w3, [x8]
     ab8:      	fmadd	d0, d1, d2, d0
     abc:      	ldr	w5, [x9, #0x4c]
     ac0:      	bl	0x6d0 <printf@plt>
     ac4:      	mov	w0, wzr
     ac8:      	b	0xa5c <main+0xf8>

Disassembly of section .fini:

0000000000000acc <_fini>:
     acc:      	nop
     ad0:      	stp	x29, x30, [sp, #-0x10]!
     ad4:      	mov	x29, sp
     ad8:      	ldp	x29, x30, [sp], #0x10
     adc:      	ret
