
/work/experiments/runs/private-regions-cost-linux-20261110/gcc-O2-lto/identity:	file format elf64-littleaarch64

Disassembly of section .init:

00000000000006f8 <_init>:
     6f8:      	nop
     6fc:      	stp	x29, x30, [sp, #-0x10]!
     700:      	mov	x29, sp
     704:      	bl	0x9f4 <call_weak_fn>
     708:      	ldp	x29, x30, [sp], #0x10
     70c:      	ret

Disassembly of section .plt:

0000000000000710 <.plt>:
     710:      	stp	x16, x30, [sp, #-0x10]!
     714:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e3f0>
     718:      	ldr	x17, [x16, #0xf80]
     71c:      	add	x16, x16, #0xf80
     720:      	br	x17
     724:      	nop
     728:      	nop
     72c:      	nop

0000000000000730 <strtoul@plt>:
     730:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e3f0>
     734:      	ldr	x17, [x16, #0xf88]
     738:      	add	x16, x16, #0xf88
     73c:      	br	x17

0000000000000740 <__libc_start_main@plt>:
     740:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e3f0>
     744:      	ldr	x17, [x16, #0xf90]
     748:      	add	x16, x16, #0xf90
     74c:      	br	x17

0000000000000750 <__cxa_finalize@plt>:
     750:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e3f0>
     754:      	ldr	x17, [x16, #0xf98]
     758:      	add	x16, x16, #0xf98
     75c:      	br	x17

0000000000000760 <clock_gettime@plt>:
     760:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e3f0>
     764:      	ldr	x17, [x16, #0xfa0]
     768:      	add	x16, x16, #0xfa0
     76c:      	br	x17

0000000000000770 <__printf_chk@plt>:
     770:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e3f0>
     774:      	ldr	x17, [x16, #0xfa8]
     778:      	add	x16, x16, #0xfa8
     77c:      	br	x17

0000000000000780 <__stack_chk_fail@plt>:
     780:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e3f0>
     784:      	ldr	x17, [x16, #0xfb0]
     788:      	add	x16, x16, #0xfb0
     78c:      	br	x17

0000000000000790 <__gmon_start__@plt>:
     790:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e3f0>
     794:      	ldr	x17, [x16, #0xfb8]
     798:      	add	x16, x16, #0xfb8
     79c:      	br	x17

00000000000007a0 <abort@plt>:
     7a0:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e3f0>
     7a4:      	ldr	x17, [x16, #0xfc0]
     7a8:      	add	x16, x16, #0xfc0
     7ac:      	br	x17

Disassembly of section .text:

00000000000007c0 <main>:
     7c0:      	sub	sp, sp, #0x50
     7c4:      	adrp	x2, 0x1f000 <__FRAME_END__+0x1e3f0>
     7c8:      	ldr	x2, [x2, #0xfe8]
     7cc:      	stp	x29, x30, [sp, #0x30]
     7d0:      	add	x29, sp, #0x30
     7d4:      	stp	x19, x20, [sp, #0x40]
     7d8:      	mov	x20, x1
     7dc:      	ldr	x1, [x2]
     7e0:      	str	x1, [sp, #0x28]
     7e4:      	mov	x1, #0x0                // =0
     7e8:      	cmp	w0, #0x3
     7ec:      	b.eq	0x824 <main+0x64>
     7f0:      	mov	w19, #0x2               // =2
     7f4:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e3f0>
     7f8:      	ldr	x0, [x0, #0xfe8]
     7fc:      	ldr	x2, [sp, #0x28]
     800:      	ldr	x1, [x0]
     804:      	subs	x2, x2, x1
     808:      	mov	x1, #0x0                // =0
     80c:      	b.ne	0x9a8 <main+0x1e8>
     810:      	ldp	x29, x30, [sp, #0x30]
     814:      	mov	w0, w19
     818:      	ldp	x19, x20, [sp, #0x40]
     81c:      	add	sp, sp, #0x50
     820:      	ret
     824:      	ldr	x0, [x20, #0x8]
     828:      	mov	w2, #0xa                // =10
     82c:      	mov	x1, #0x0                // =0
     830:      	bl	0x730 <strtoul@plt>
     834:      	mov	x19, x0
     838:      	ldr	x0, [x20, #0x10]
     83c:      	mov	w2, #0xa                // =10
     840:      	mov	x1, #0x0                // =0
     844:      	bl	0x730 <strtoul@plt>
     848:      	mov	x20, x0
     84c:      	add	x1, sp, #0x18
     850:      	mov	w0, #0x1                // =1
     854:      	bl	0x760 <clock_gettime@plt>
     858:      	cbnz	w0, 0x7f0 <main+0x30>
     85c:      	cbz	x19, 0x9a0 <main+0x1e0>
     860:      	adrp	x8, 0x20000 <data_start>
     864:      	add	x3, x8, #0x18
     868:      	mov	x9, #-0x3333333333333334 // =-3689348814741910324
     86c:      	mov	w7, w20
     870:      	ldr	w1, [x8, #0x18]
     874:      	mov	x2, #0x0                // =0
     878:      	ldp	w0, w5, [x3, #0x8]
     87c:      	mov	w20, #0x0               // =0
     880:      	movk	x9, #0xcccd
     884:      	nop
     888:      	eor	w7, w7, w7, lsl #13
     88c:      	umulh	x4, x2, x9
     890:      	add	w1, w1, w1, lsl #5
     894:      	eor	w7, w7, w7, lsr #17
     898:      	lsr	x4, x4, #3
     89c:      	eor	w7, w7, w7, lsl #5
     8a0:      	add	w0, w7, w0
     8a4:      	add	x4, x4, x4, lsl #2
     8a8:      	add	w0, w0, w0, lsl #1
     8ac:      	sub	x4, x2, x4, lsl #1
     8b0:      	add	w3, w0, #0xb
     8b4:      	sub	w0, w4, #0x1
     8b8:      	eor	w1, w1, w3
     8bc:      	cbz	w4, 0x8f8 <main+0x138>
     8c0:      	sub	w4, w4, #0x2
     8c4:      	cbz	w0, 0x8f8 <main+0x138>
     8c8:      	add	w5, w5, w3
     8cc:      	add	w1, w1, w1, lsl #5
     8d0:      	add	w6, w5, w3
     8d4:      	eor	w1, w1, w3
     8d8:      	add	w3, w6, w3
     8dc:      	sub	w4, w4, #0x1
     8e0:      	add	w1, w1, w1, lsl #5
     8e4:      	add	w3, w3, w3, lsl #2
     8e8:      	eor	w1, w1, w6
     8ec:      	sub	w3, w3, #0x7
     8f0:      	cmn	w4, #0x1
     8f4:      	b.ne	0x8c8 <main+0x108>
     8f8:      	add	w5, w7, #0x11
     8fc:      	add	w3, w3, w20
     900:      	add	w1, w1, w1, lsl #5
     904:      	add	x2, x2, #0x1
     908:      	add	w4, w5, w5, lsl #1
     90c:      	add	w4, w4, w3
     910:      	sub	w0, w4, w5
     914:      	eor	w1, w1, w4
     918:      	cmp	w4, w0
     91c:      	cinc	w20, w3, eq
     920:      	cmp	x19, x2
     924:      	b.ne	0x888 <main+0xc8>
     928:      	add	x2, x8, #0x18
     92c:      	str	w1, [x8, #0x18]
     930:      	stp	w0, w5, [x2, #0x8]
     934:      	add	x1, sp, #0x8
     938:      	mov	w0, #0x1                // =1
     93c:      	bl	0x760 <clock_gettime@plt>
     940:      	mov	w19, w0
     944:      	cbnz	w0, 0x7f0 <main+0x30>
     948:      	adrp	x1, 0x0 <strtoul@GLIBC_2.17>
     94c:      	adrp	x3, 0x20000 <data_start>
     950:      	ldp	x4, x2, [sp, #0x18]
     954:      	ldr	d1, [x1, #0xb10]
     958:      	ldp	x1, x0, [sp, #0x8]
     95c:      	ldr	w6, [x3, #0x18]
     960:      	sub	x0, x0, x2
     964:      	add	x2, x3, #0x18
     968:      	add	x5, x2, #0x8
     96c:      	scvtf	d0, x0
     970:      	sub	x0, x1, x4
     974:      	ldr	w3, [x2, #0x8]
     978:      	adrp	x1, 0x0 <strtoul@GLIBC_2.17>
     97c:      	ldp	w4, w5, [x5, #0x4]
     980:      	add	x1, x1, #0xaf8
     984:      	fmul	d0, d0, d1
     988:      	scvtf	d1, x0
     98c:      	mov	w2, w20
     990:      	mov	w0, #0x2                // =2
     994:      	fadd	d0, d0, d1
     998:      	bl	0x770 <__printf_chk@plt>
     99c:      	b	0x7f4 <main+0x34>
     9a0:      	mov	w20, #0x0               // =0
     9a4:      	b	0x934 <main+0x174>
     9a8:      	bl	0x780 <__stack_chk_fail@plt>
     9ac:      	nop
     9b0:      	nop
     9b4:      	nop
     9b8:      	nop
     9bc:      	nop

00000000000009c0 <_start>:
     9c0:      	nop
     9c4:      	mov	x29, #0x0               // =0
     9c8:      	mov	x30, #0x0               // =0
     9cc:      	mov	x5, x0
     9d0:      	ldr	x1, [sp]
     9d4:      	add	x2, sp, #0x8
     9d8:      	mov	x6, sp
     9dc:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e3f0>
     9e0:      	ldr	x0, [x0, #0xff0]
     9e4:      	mov	x3, #0x0                // =0
     9e8:      	mov	x4, #0x0                // =0
     9ec:      	bl	0x740 <__libc_start_main@plt>
     9f0:      	bl	0x7a0 <abort@plt>

00000000000009f4 <call_weak_fn>:
     9f4:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e3f0>
     9f8:      	ldr	x0, [x0, #0xfe0]
     9fc:      	cbz	x0, 0xa04 <call_weak_fn+0x10>
     a00:      	b	0x790 <__gmon_start__@plt>
     a04:      	ret
     a08:      	nop
     a0c:      	nop

0000000000000a10 <deregister_tm_clones>:
     a10:      	adrp	x0, 0x20000 <data_start>
     a14:      	add	x0, x0, #0x10
     a18:      	adrp	x1, 0x20000 <data_start>
     a1c:      	add	x1, x1, #0x10
     a20:      	cmp	x1, x0
     a24:      	b.eq	0xa3c <deregister_tm_clones+0x2c>
     a28:      	adrp	x1, 0x1f000 <__FRAME_END__+0x1e3f0>
     a2c:      	ldr	x1, [x1, #0xfd0]
     a30:      	cbz	x1, 0xa3c <deregister_tm_clones+0x2c>
     a34:      	mov	x16, x1
     a38:      	br	x16
     a3c:      	ret

0000000000000a40 <register_tm_clones>:
     a40:      	adrp	x0, 0x20000 <data_start>
     a44:      	add	x0, x0, #0x10
     a48:      	adrp	x1, 0x20000 <data_start>
     a4c:      	add	x1, x1, #0x10
     a50:      	sub	x1, x1, x0
     a54:      	lsr	x2, x1, #63
     a58:      	add	x1, x2, x1, asr #3
     a5c:      	asr	x1, x1, #1
     a60:      	cbz	x1, 0xa78 <register_tm_clones+0x38>
     a64:      	adrp	x2, 0x1f000 <__FRAME_END__+0x1e3f0>
     a68:      	ldr	x2, [x2, #0xff8]
     a6c:      	cbz	x2, 0xa78 <register_tm_clones+0x38>
     a70:      	mov	x16, x2
     a74:      	br	x16
     a78:      	ret
     a7c:      	nop

0000000000000a80 <__do_global_dtors_aux>:
     a80:      	paciasp
     a84:      	stp	x29, x30, [sp, #-0x20]!
     a88:      	mov	x29, sp
     a8c:      	str	x19, [sp, #0x10]
     a90:      	adrp	x19, 0x20000 <data_start>
     a94:      	ldrb	w0, [x19, #0x10]
     a98:      	tbnz	w0, #0x0, 0xac0 <__do_global_dtors_aux+0x40>
     a9c:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e3f0>
     aa0:      	ldr	x0, [x0, #0xfd8]
     aa4:      	cbz	x0, 0xab4 <__do_global_dtors_aux+0x34>
     aa8:      	adrp	x0, 0x20000 <data_start>
     aac:      	ldr	x0, [x0, #0x8]
     ab0:      	bl	0x750 <__cxa_finalize@plt>
     ab4:      	bl	0xa10 <deregister_tm_clones>
     ab8:      	mov	w0, #0x1                // =1
     abc:      	strb	w0, [x19, #0x10]
     ac0:      	ldr	x19, [sp, #0x10]
     ac4:      	ldp	x29, x30, [sp], #0x20
     ac8:      	autiasp
     acc:      	ret

0000000000000ad0 <frame_dummy>:
     ad0:      	bti	c
     ad4:      	b	0xa40 <register_tm_clones>

Disassembly of section .fini:

0000000000000ad8 <_fini>:
     ad8:      	nop
     adc:      	stp	x29, x30, [sp, #-0x10]!
     ae0:      	mov	x29, sp
     ae4:      	ldp	x29, x30, [sp], #0x10
     ae8:      	ret
