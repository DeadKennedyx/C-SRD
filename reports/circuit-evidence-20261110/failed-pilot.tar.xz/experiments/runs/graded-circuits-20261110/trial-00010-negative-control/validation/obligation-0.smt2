; 
(set-info :status unknown)
(assert
 (let (($x99 (or false true)))
(and (distinct true $x99) true)))
(check-sat)
