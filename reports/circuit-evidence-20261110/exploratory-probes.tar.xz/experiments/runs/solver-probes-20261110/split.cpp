// Exploratory formula decomposition, not yet part of the verification gate.
#include <z3++.h>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <map>
#include <stdexcept>

struct Pair { z3::expr low,high; };
class Split {
  z3::context &c;
  z3::params params;
  std::map<unsigned,Pair> cache;
  z3::expr zero() { return c.bv_val(0,16); }
  z3::expr wide(const z3::expr &x) { return z3::zext(x,16); }
  z3::expr high(const z3::expr &x) { return x.extract(31,16); }
  Pair operation(const z3::expr &e) {
    const auto kind=e.decl().decl_kind();
    if (e.is_numeral()) {
      const auto n=e.get_numeral_uint64();
      return {c.bv_val(n&65535u,16),c.bv_val(n>>16,16)};
    }
    if (kind==Z3_OP_UNINTERPRETED && !e.num_args()) return {e.extract(15,0),e.extract(31,16)};
    if (kind==Z3_OP_ZERO_EXT && e.arg(0).get_sort().bv_size()==16) return {e.arg(0),zero()};
    if (kind==Z3_OP_CONCAT && e.arg(0).get_sort().bv_size()==16 && e.arg(1).get_sort().bv_size()==16)
      return {e.arg(1),e.arg(0)};
    if (kind==Z3_OP_ITE) {
      auto a=pair(e.arg(1)),b=pair(e.arg(2));
      return {z3::ite(e.arg(0),a.low,b.low),z3::ite(e.arg(0),a.high,b.high)};
    }
    if (kind==Z3_OP_BMUL) {
      auto factor=e.arg(0).is_numeral()?e.arg(0):e.arg(1);
      auto input=e.arg(0).is_numeral()?e.arg(1):e.arg(0);
      if (!factor.is_numeral()) throw std::runtime_error("nonconstant multiply");
      auto a=pair(input);
      auto k=c.bv_val(factor.get_numeral_uint64()&65535u,16);
      auto product=wide(a.low)*factor;
      return {a.low*k,a.high*k+high(product)};
    }
    auto a=pair(e.arg(0));
    if (kind==Z3_OP_BNOT) return {~a.low,~a.high};
    if (kind==Z3_OP_BLSHR || kind==Z3_OP_BSHL) {
      if (!e.arg(1).is_numeral()) throw std::runtime_error("nonconstant shift");
      const auto n=e.arg(1).get_numeral_uint64();
      if (!n) return a;
      if (n>=32) return {zero(),zero()};
      auto count=c.bv_val(n>=16?n-16:n,16);
      if (kind==Z3_OP_BLSHR) {
        if (n>=16) return {z3::lshr(a.high,count),zero()};
        return {z3::lshr(a.low,count)|z3::shl(a.high,c.bv_val(16-n,16)),z3::lshr(a.high,count)};
      }
      if (n>=16) return {zero(),z3::shl(a.low,count)};
      return {z3::shl(a.low,count),z3::shl(a.high,count)|z3::lshr(a.low,c.bv_val(16-n,16))};
    }
    if (e.num_args()!=2) throw std::runtime_error("arity "+e.to_string());
    auto b=pair(e.arg(1));
    switch(kind) {
    case Z3_OP_BADD: return {a.low+b.low,a.high+b.high+high(wide(a.low)+wide(b.low))};
    case Z3_OP_BSUB: return {a.low-b.low,a.high-b.high-z3::ite(z3::ult(a.low,b.low),c.bv_val(1,16),zero())};
    case Z3_OP_BAND: return {a.low&b.low,a.high&b.high};
    case Z3_OP_BOR: return {a.low|b.low,a.high|b.high};
    case Z3_OP_BXOR: return {a.low^b.low,a.high^b.high};
    default: throw std::runtime_error("unsupported "+e.decl().name().str());
    }
  }
public:
  Split(z3::context &ctx):c(ctx),params(ctx) {
    params.set("som",true);params.set("mul2concat",true);params.set("bv_extract_prop",true);params.set("sort_sums",true);
  }
  Pair pair(const z3::expr &e) {
    if (!e.is_bv() || e.get_sort().bv_size()!=32) throw std::runtime_error("requires u32");
    const auto found=cache.find(e.id());if(found!=cache.end())return found->second;
    auto p=operation(e);p.low=p.low.simplify(params);p.high=p.high.simplify(params);
    cache.emplace(e.id(),p);return p;
  }
  z3::expr run(const z3::expr &e) {
    if (e.is_bv() && e.get_sort().bv_size()==32) {auto p=pair(e);return z3::concat(p.high,p.low);}
    if (!e.is_app() || !e.num_args()) return e;
    z3::expr_vector args(c);for(unsigned i=0;i<e.num_args();++i)args.push_back(run(e.arg(i)));
    return e.decl()(args).simplify(params);
  }
};
int main(int argc,char **argv) {
  try {
    if(argc!=3)throw std::runtime_error("input.smt2 output.smt2 required");
    z3::context c;auto assertions=c.parse_file(argv[1]);
    Split split(c);z3::solver solver(c);
    for(unsigned i=0;i<assertions.size();++i)solver.add(split.run(assertions[i]));
    std::ofstream out(argv[2]);out<<solver.to_smt2();
    if(!out)throw std::runtime_error("write failed");
    std::cout<<"normalized "<<assertions.size()<<" assertions (exploratory, rules not yet certified)\n";
  }catch(const std::exception &e){std::cerr<<e.what()<<'\n';return 1;}
}
