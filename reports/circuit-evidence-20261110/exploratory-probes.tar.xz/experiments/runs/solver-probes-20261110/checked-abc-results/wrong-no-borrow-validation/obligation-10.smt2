; 
(set-info :status unknown)
(declare-fun local_0 () Bool)
(assert
 (let (($x1952 (and true local_0)))
(let (($x1898 (or false $x1952)))
(and (distinct local_0 $x1898) true))))
(check-sat)
