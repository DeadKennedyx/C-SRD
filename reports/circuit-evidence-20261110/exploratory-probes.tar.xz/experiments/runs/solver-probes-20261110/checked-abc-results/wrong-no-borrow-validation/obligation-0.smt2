; 
(set-info :status unknown)
(assert
 (let (($x1853 (or false true)))
(and (distinct true $x1853) true)))
(check-sat)
