; 
(set-info :status unknown)
(declare-fun local_0 () Bool)
(assert
 (let (($x1962 (not local_0)))
(and (distinct $x1962 (or false (and true $x1962))) true)))
(check-sat)
