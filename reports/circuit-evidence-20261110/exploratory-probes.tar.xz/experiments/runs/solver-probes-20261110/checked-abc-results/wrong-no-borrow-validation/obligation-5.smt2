; 
(set-info :status unknown)
(declare-fun local_2 () Bool)
(declare-fun local_1 () Bool)
(declare-fun local_0 () Bool)
(assert
 (let (($x1951 (and true local_1)))
(let (($x1953 (or (or false (and true local_0)) $x1951)))
(let (($x2019 (or local_0 local_1 local_2)))
(and (distinct $x2019 (or $x1953 (and true local_2))) true)))))
(check-sat)
