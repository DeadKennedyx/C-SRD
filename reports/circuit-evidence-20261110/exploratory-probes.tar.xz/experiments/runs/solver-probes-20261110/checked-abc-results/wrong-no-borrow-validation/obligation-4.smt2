; 
(set-info :status unknown)
(declare-fun local_0 () Bool)
(declare-fun local_1 () Bool)
(assert
 (let (($x1979 (or (or false (and (and true (not local_1)) (not local_0))) (and (and true local_1) local_0))))
(let (($x1980 (= local_1 local_0)))
(and (distinct $x1980 $x1979) true))))
(check-sat)
