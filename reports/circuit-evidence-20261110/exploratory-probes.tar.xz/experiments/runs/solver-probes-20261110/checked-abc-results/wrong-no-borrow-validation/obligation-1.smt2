; 
(set-info :status unknown)
(declare-fun local_1 () Bool)
(declare-fun local_0 () Bool)
(assert
 (let (($x1954 (or local_0 local_1)))
(and (distinct $x1954 (or (or false (and true local_0)) (and true local_1))) true)))
(check-sat)
