; 
(set-info :status unknown)
(declare-fun local_1 () Bool)
(declare-fun local_0 () Bool)
(assert
 (let (($x15121 (and true local_0)))
(let (($x17142 (and $x15121 local_1)))
(let (($x22124 (or false $x17142)))
(let (($x24145 (and local_0 local_1)))
(and (distinct $x24145 $x22124) true))))))
(check-sat)
