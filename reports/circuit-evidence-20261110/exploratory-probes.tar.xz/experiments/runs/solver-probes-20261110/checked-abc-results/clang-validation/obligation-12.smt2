; 
(set-info :status unknown)
(declare-fun local_0 () Bool)
(assert
 (let (($x15121 (and true local_0)))
(let (($x15122 (or false $x15121)))
(and (distinct local_0 $x15122) true))))
(check-sat)
