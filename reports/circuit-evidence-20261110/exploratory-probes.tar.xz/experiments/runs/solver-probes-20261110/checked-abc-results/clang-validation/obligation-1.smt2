; 
(set-info :status unknown)
(declare-fun local_0 () Bool)
(assert
 (let (($x15107 (not local_0)))
(and (distinct $x15107 (or false (and true $x15107))) true)))
(check-sat)
