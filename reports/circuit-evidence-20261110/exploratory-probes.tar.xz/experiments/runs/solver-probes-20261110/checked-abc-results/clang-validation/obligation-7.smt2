; 
(set-info :status unknown)
(declare-fun local_2 () Bool)
(declare-fun local_1 () Bool)
(declare-fun local_0 () Bool)
(assert
 (let (($x17331 (and true local_2)))
(let (($x15120 (and true local_1)))
(let (($x15123 (or (or false (and true local_0)) $x15120)))
(and (distinct (or local_0 local_1 local_2) (or $x15123 $x17331)) true)))))
(check-sat)
