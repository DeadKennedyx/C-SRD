; 
(set-info :status unknown)
(declare-fun local_0 () Bool)
(declare-fun local_1 () Bool)
(assert
 (and (distinct (or local_1 local_0) (or (or false (and true local_1)) (and true local_0))) true))
(check-sat)
