; 
(set-info :status unknown)
(assert
 (let (($x15068 (or false true)))
(and (distinct true $x15068) true)))
(check-sat)
