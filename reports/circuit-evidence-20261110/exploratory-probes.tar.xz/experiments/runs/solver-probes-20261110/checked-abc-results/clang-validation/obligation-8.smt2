; 
(set-info :status unknown)
(declare-fun local_1 () Bool)
(declare-fun local_2 () Bool)
(declare-fun local_0 () Bool)
(assert
 (let (($x15120 (and true local_1)))
(let (($x20077 (or (or (or false (and true local_0)) (and true local_2)) $x15120)))
(and (distinct (or local_0 local_2 local_1) $x20077) true))))
(check-sat)
