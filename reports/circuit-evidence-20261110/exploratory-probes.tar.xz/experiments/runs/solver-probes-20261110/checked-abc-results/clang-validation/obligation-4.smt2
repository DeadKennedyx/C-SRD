; 
(set-info :status unknown)
(declare-fun local_1 () Bool)
(declare-fun local_0 () Bool)
(declare-fun local_2 () Bool)
(assert
 (let (($x15120 (and true local_1)))
(let (($x17334 (or (or (or false (and true local_2)) (and true local_0)) $x15120)))
(and (distinct (or local_2 local_0 local_1) $x17334) true))))
(check-sat)
