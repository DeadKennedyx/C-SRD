; 
(set-info :status unknown)
(declare-fun local_0 () Bool)
(assert
 (let (($x1207 (and true local_0)))
(let (($x1119 (or false $x1207)))
(and (distinct local_0 $x1119) true))))
(check-sat)
