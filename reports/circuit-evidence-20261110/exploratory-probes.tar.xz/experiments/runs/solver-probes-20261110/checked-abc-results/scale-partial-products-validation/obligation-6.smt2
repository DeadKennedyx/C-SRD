; 
(set-info :status unknown)
(declare-fun local_2 () Bool)
(declare-fun local_1 () Bool)
(declare-fun local_0 () Bool)
(assert
 (let (($x1218 (and true local_1)))
(let (($x1120 (or (or false (and true local_0)) $x1218)))
(and (distinct (or local_0 local_1 local_2) (or $x1120 (and true local_2))) true))))
(check-sat)
