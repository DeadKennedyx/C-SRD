; 
(set-info :status unknown)
(declare-fun wire_0 () Bool)
(declare-fun wire_2 () Bool)
(declare-fun wire_1 () Bool)
(declare-fun wire_3 () Bool)
(declare-fun wire_4 () Bool)
(declare-fun wire_5 () Bool)
(declare-fun wire_6 () Bool)
(declare-fun wire_9 () Bool)
(declare-fun wire_10 () Bool)
(declare-fun wire_11 () Bool)
(declare-fun wire_8 () Bool)
(declare-fun wire_12 () Bool)
(declare-fun wire_7 () Bool)
(declare-fun wire_13 () Bool)
(declare-fun wire_14 () Bool)
(declare-fun wire_15 () Bool)
(declare-fun wire_16 () Bool)
(declare-fun wire_17 () Bool)
(declare-fun wire_20 () Bool)
(declare-fun wire_21 () Bool)
(declare-fun wire_22 () Bool)
(declare-fun wire_23 () Bool)
(declare-fun wire_24 () Bool)
(declare-fun wire_25 () Bool)
(declare-fun wire_26 () Bool)
(declare-fun wire_27 () Bool)
(declare-fun wire_28 () Bool)
(declare-fun wire_29 () Bool)
(declare-fun wire_30 () Bool)
(declare-fun wire_31 () Bool)
(declare-fun wire_32 () Bool)
(declare-fun wire_33 () Bool)
(declare-fun wire_34 () Bool)
(declare-fun wire_35 () Bool)
(declare-fun wire_36 () Bool)
(declare-fun wire_37 () Bool)
(declare-fun wire_38 () Bool)
(declare-fun wire_39 () Bool)
(declare-fun wire_40 () Bool)
(declare-fun wire_41 () Bool)
(declare-fun wire_42 () Bool)
(declare-fun wire_43 () Bool)
(declare-fun wire_44 () Bool)
(declare-fun wire_45 () Bool)
(declare-fun wire_46 () Bool)
(declare-fun wire_47 () Bool)
(declare-fun wire_48 () Bool)
(declare-fun wire_49 () Bool)
(declare-fun wire_50 () Bool)
(declare-fun wire_51 () Bool)
(declare-fun wire_52 () Bool)
(declare-fun wire_53 () Bool)
(declare-fun wire_54 () Bool)
(declare-fun wire_55 () Bool)
(declare-fun wire_56 () Bool)
(declare-fun wire_57 () Bool)
(declare-fun wire_58 () Bool)
(declare-fun wire_59 () Bool)
(declare-fun wire_60 () Bool)
(declare-fun wire_61 () Bool)
(declare-fun wire_62 () Bool)
(declare-fun wire_63 () Bool)
(declare-fun wire_64 () Bool)
(declare-fun wire_65 () Bool)
(declare-fun wire_66 () Bool)
(declare-fun wire_67 () Bool)
(declare-fun wire_68 () Bool)
(declare-fun wire_69 () Bool)
(declare-fun wire_70 () Bool)
(declare-fun wire_71 () Bool)
(declare-fun wire_72 () Bool)
(declare-fun wire_73 () Bool)
(declare-fun wire_74 () Bool)
(declare-fun wire_75 () Bool)
(declare-fun wire_76 () Bool)
(declare-fun wire_77 () Bool)
(declare-fun wire_78 () Bool)
(declare-fun wire_79 () Bool)
(declare-fun wire_80 () Bool)
(declare-fun wire_81 () Bool)
(declare-fun wire_82 () Bool)
(declare-fun wire_83 () Bool)
(declare-fun wire_84 () Bool)
(declare-fun wire_85 () Bool)
(declare-fun wire_86 () Bool)
(declare-fun wire_87 () Bool)
(declare-fun wire_88 () Bool)
(declare-fun wire_89 () Bool)
(declare-fun wire_90 () Bool)
(declare-fun wire_91 () Bool)
(declare-fun wire_92 () Bool)
(declare-fun wire_93 () Bool)
(declare-fun wire_94 () Bool)
(declare-fun wire_95 () Bool)
(declare-fun wire_96 () Bool)
(declare-fun wire_97 () Bool)
(declare-fun wire_98 () Bool)
(declare-fun wire_99 () Bool)
(declare-fun wire_100 () Bool)
(declare-fun wire_101 () Bool)
(declare-fun wire_102 () Bool)
(declare-fun wire_103 () Bool)
(declare-fun wire_104 () Bool)
(declare-fun wire_105 () Bool)
(declare-fun wire_106 () Bool)
(declare-fun wire_107 () Bool)
(declare-fun wire_108 () Bool)
(declare-fun wire_109 () Bool)
(declare-fun wire_110 () Bool)
(declare-fun wire_111 () Bool)
(declare-fun wire_112 () Bool)
(declare-fun wire_113 () Bool)
(declare-fun wire_114 () Bool)
(declare-fun wire_115 () Bool)
(declare-fun wire_116 () Bool)
(declare-fun wire_117 () Bool)
(declare-fun wire_118 () Bool)
(declare-fun wire_119 () Bool)
(declare-fun wire_120 () Bool)
(declare-fun wire_121 () Bool)
(declare-fun wire_122 () Bool)
(declare-fun wire_123 () Bool)
(declare-fun wire_124 () Bool)
(declare-fun wire_125 () Bool)
(declare-fun wire_126 () Bool)
(declare-fun wire_127 () Bool)
(declare-fun wire_128 () Bool)
(declare-fun wire_129 () Bool)
(declare-fun wire_130 () Bool)
(declare-fun wire_131 () Bool)
(declare-fun wire_132 () Bool)
(declare-fun wire_133 () Bool)
(declare-fun wire_134 () Bool)
(declare-fun wire_135 () Bool)
(declare-fun wire_136 () Bool)
(declare-fun wire_137 () Bool)
(declare-fun wire_138 () Bool)
(declare-fun wire_139 () Bool)
(declare-fun wire_140 () Bool)
(declare-fun wire_141 () Bool)
(declare-fun wire_142 () Bool)
(declare-fun wire_143 () Bool)
(declare-fun wire_144 () Bool)
(declare-fun wire_145 () Bool)
(declare-fun wire_146 () Bool)
(declare-fun wire_147 () Bool)
(declare-fun wire_148 () Bool)
(declare-fun wire_149 () Bool)
(declare-fun wire_150 () Bool)
(declare-fun wire_151 () Bool)
(declare-fun wire_152 () Bool)
(declare-fun wire_153 () Bool)
(declare-fun wire_154 () Bool)
(declare-fun wire_155 () Bool)
(declare-fun wire_156 () Bool)
(declare-fun wire_157 () Bool)
(declare-fun wire_158 () Bool)
(declare-fun wire_159 () Bool)
(declare-fun wire_160 () Bool)
(declare-fun wire_161 () Bool)
(declare-fun wire_162 () Bool)
(declare-fun wire_163 () Bool)
(declare-fun wire_164 () Bool)
(declare-fun wire_165 () Bool)
(declare-fun wire_166 () Bool)
(declare-fun wire_167 () Bool)
(declare-fun wire_168 () Bool)
(declare-fun wire_169 () Bool)
(declare-fun wire_170 () Bool)
(declare-fun wire_171 () Bool)
(declare-fun wire_172 () Bool)
(declare-fun wire_173 () Bool)
(declare-fun wire_174 () Bool)
(declare-fun wire_175 () Bool)
(declare-fun wire_176 () Bool)
(declare-fun wire_177 () Bool)
(declare-fun wire_178 () Bool)
(declare-fun wire_179 () Bool)
(declare-fun wire_180 () Bool)
(declare-fun wire_181 () Bool)
(declare-fun wire_182 () Bool)
(declare-fun wire_183 () Bool)
(declare-fun wire_184 () Bool)
(declare-fun wire_19 () Bool)
(declare-fun wire_185 () Bool)
(declare-fun wire_18 () Bool)
(declare-fun wire_186 () Bool)
(declare-fun wire_187 () Bool)
(declare-fun wire_188 () Bool)
(declare-fun wire_189 () Bool)
(declare-fun wire_190 () Bool)
(declare-fun wire_191 () Bool)
(declare-fun wire_192 () Bool)
(declare-fun wire_193 () Bool)
(declare-fun wire_194 () Bool)
(declare-fun wire_195 () Bool)
(declare-fun wire_196 () Bool)
(declare-fun wire_197 () Bool)
(declare-fun wire_198 () Bool)
(declare-fun wire_199 () Bool)
(declare-fun wire_200 () Bool)
(declare-fun wire_201 () Bool)
(declare-fun wire_202 () Bool)
(declare-fun wire_203 () Bool)
(declare-fun wire_204 () Bool)
(declare-fun wire_205 () Bool)
(declare-fun wire_206 () Bool)
(declare-fun wire_207 () Bool)
(declare-fun wire_208 () Bool)
(declare-fun wire_209 () Bool)
(declare-fun wire_210 () Bool)
(declare-fun wire_211 () Bool)
(declare-fun wire_212 () Bool)
(declare-fun wire_213 () Bool)
(declare-fun wire_214 () Bool)
(declare-fun wire_215 () Bool)
(declare-fun wire_216 () Bool)
(declare-fun wire_217 () Bool)
(declare-fun wire_218 () Bool)
(declare-fun wire_219 () Bool)
(declare-fun wire_220 () Bool)
(declare-fun wire_221 () Bool)
(declare-fun wire_222 () Bool)
(declare-fun wire_223 () Bool)
(declare-fun wire_224 () Bool)
(declare-fun wire_225 () Bool)
(declare-fun wire_226 () Bool)
(declare-fun wire_227 () Bool)
(declare-fun wire_228 () Bool)
(declare-fun wire_229 () Bool)
(declare-fun wire_230 () Bool)
(declare-fun wire_231 () Bool)
(declare-fun wire_232 () Bool)
(declare-fun wire_233 () Bool)
(declare-fun wire_234 () Bool)
(declare-fun wire_235 () Bool)
(declare-fun wire_236 () Bool)
(declare-fun wire_237 () Bool)
(declare-fun wire_238 () Bool)
(declare-fun wire_239 () Bool)
(declare-fun wire_240 () Bool)
(declare-fun wire_241 () Bool)
(declare-fun wire_242 () Bool)
(declare-fun wire_243 () Bool)
(declare-fun wire_244 () Bool)
(declare-fun wire_245 () Bool)
(declare-fun wire_246 () Bool)
(declare-fun wire_247 () Bool)
(declare-fun wire_248 () Bool)
(declare-fun wire_249 () Bool)
(declare-fun wire_250 () Bool)
(declare-fun wire_251 () Bool)
(declare-fun wire_252 () Bool)
(declare-fun wire_253 () Bool)
(declare-fun wire_254 () Bool)
(declare-fun wire_255 () Bool)
(declare-fun wire_256 () Bool)
(declare-fun wire_257 () Bool)
(declare-fun wire_258 () Bool)
(declare-fun wire_259 () Bool)
(declare-fun wire_260 () Bool)
(declare-fun wire_261 () Bool)
(declare-fun wire_262 () Bool)
(declare-fun wire_263 () Bool)
(declare-fun wire_264 () Bool)
(declare-fun wire_265 () Bool)
(declare-fun wire_266 () Bool)
(declare-fun wire_267 () Bool)
(declare-fun wire_268 () Bool)
(declare-fun wire_269 () Bool)
(declare-fun wire_270 () Bool)
(declare-fun wire_271 () Bool)
(declare-fun wire_272 () Bool)
(declare-fun wire_273 () Bool)
(declare-fun wire_274 () Bool)
(declare-fun wire_275 () Bool)
(declare-fun wire_276 () Bool)
(declare-fun wire_277 () Bool)
(declare-fun wire_278 () Bool)
(declare-fun wire_279 () Bool)
(declare-fun wire_280 () Bool)
(declare-fun wire_281 () Bool)
(declare-fun wire_282 () Bool)
(declare-fun wire_283 () Bool)
(declare-fun wire_284 () Bool)
(declare-fun wire_285 () Bool)
(declare-fun wire_286 () Bool)
(declare-fun wire_287 () Bool)
(declare-fun wire_288 () Bool)
(declare-fun wire_289 () Bool)
(declare-fun wire_290 () Bool)
(declare-fun wire_291 () Bool)
(declare-fun wire_292 () Bool)
(declare-fun wire_293 () Bool)
(declare-fun wire_294 () Bool)
(declare-fun wire_295 () Bool)
(declare-fun wire_296 () Bool)
(declare-fun wire_297 () Bool)
(declare-fun wire_298 () Bool)
(declare-fun wire_299 () Bool)
(declare-fun wire_300 () Bool)
(declare-fun wire_301 () Bool)
(declare-fun wire_302 () Bool)
(declare-fun wire_303 () Bool)
(declare-fun wire_304 () Bool)
(declare-fun wire_305 () Bool)
(declare-fun wire_306 () Bool)
(declare-fun wire_307 () Bool)
(declare-fun wire_308 () Bool)
(declare-fun wire_309 () Bool)
(declare-fun wire_310 () Bool)
(declare-fun wire_311 () Bool)
(declare-fun wire_312 () Bool)
(declare-fun wire_313 () Bool)
(declare-fun wire_314 () Bool)
(declare-fun wire_315 () Bool)
(declare-fun wire_316 () Bool)
(declare-fun wire_317 () Bool)
(declare-fun wire_318 () Bool)
(declare-fun wire_319 () Bool)
(declare-fun wire_320 () Bool)
(declare-fun wire_321 () Bool)
(declare-fun wire_322 () Bool)
(declare-fun wire_323 () Bool)
(declare-fun wire_324 () Bool)
(declare-fun wire_325 () Bool)
(declare-fun wire_326 () Bool)
(declare-fun wire_327 () Bool)
(declare-fun wire_328 () Bool)
(declare-fun wire_329 () Bool)
(declare-fun wire_330 () Bool)
(declare-fun wire_331 () Bool)
(declare-fun wire_332 () Bool)
(declare-fun wire_333 () Bool)
(declare-fun wire_334 () Bool)
(declare-fun wire_335 () Bool)
(declare-fun wire_336 () Bool)
(declare-fun wire_337 () Bool)
(declare-fun wire_338 () Bool)
(declare-fun wire_339 () Bool)
(declare-fun wire_340 () Bool)
(declare-fun wire_341 () Bool)
(declare-fun wire_342 () Bool)
(declare-fun wire_343 () Bool)
(declare-fun wire_344 () Bool)
(declare-fun wire_345 () Bool)
(declare-fun wire_346 () Bool)
(declare-fun wire_347 () Bool)
(declare-fun wire_348 () Bool)
(declare-fun wire_349 () Bool)
(declare-fun wire_350 () Bool)
(declare-fun wire_351 () Bool)
(declare-fun wire_352 () Bool)
(declare-fun wire_353 () Bool)
(declare-fun wire_354 () Bool)
(declare-fun wire_355 () Bool)
(declare-fun wire_356 () Bool)
(declare-fun wire_357 () Bool)
(declare-fun wire_358 () Bool)
(declare-fun wire_359 () Bool)
(declare-fun wire_360 () Bool)
(declare-fun wire_361 () Bool)
(declare-fun wire_362 () Bool)
(declare-fun wire_363 () Bool)
(declare-fun wire_364 () Bool)
(declare-fun wire_365 () Bool)
(declare-fun wire_366 () Bool)
(declare-fun wire_367 () Bool)
(declare-fun wire_368 () Bool)
(declare-fun wire_369 () Bool)
(declare-fun wire_370 () Bool)
(declare-fun wire_371 () Bool)
(declare-fun output () Bool)
(assert
 (= wire_0 true))
(assert
 (let (($x66 (= wire_1 wire_2)))
 (= wire_3 $x66)))
(assert
 (let (($x68 (= wire_2 wire_1)))
 (= wire_4 $x68)))
(assert
 (let (($x70 (= wire_3 wire_4)))
 (= wire_5 $x70)))
(assert
 (let (($x72 (not wire_5)))
 (= wire_6 $x72)))
(assert
 (let (($x76 (not wire_1)))
 (= wire_9 $x76)))
(assert
 (let (($x78 (not wire_2)))
 (= wire_10 $x78)))
(assert
 (let (($x55 (or wire_9 wire_10)))
 (= wire_11 $x55)))
(assert
 (let (($x28 (= wire_8 wire_11)))
 (= wire_12 $x28)))
(assert
 (let (($x20 (= wire_7 wire_12)))
 (= wire_13 $x20)))
(assert
 (let (($x27 (= wire_7 wire_11)))
 (= wire_14 $x27)))
(assert
 (let (($x22 (= wire_8 wire_14)))
 (= wire_15 $x22)))
(assert
 (let (($x51 (= wire_13 wire_15)))
 (= wire_16 $x51)))
(assert
 (let (($x43 (not wire_16)))
 (= wire_17 $x43)))
(assert
 (let (($x5 (not wire_20)))
 (= wire_21 $x5)))
(assert
 (let (($x8 (not wire_22)))
 (= wire_23 $x8)))
(assert
 (let (($x10 (or wire_21 wire_23)))
 (= wire_24 $x10)))
(assert
 (let (($x12 (not wire_24)))
 (= wire_25 $x12)))
(assert
 (let (($x15 (not wire_26)))
 (= wire_27 $x15)))
(assert
 (let (($x18 (not wire_28)))
 (= wire_29 $x18)))
(assert
 (let (($x46 (or wire_27 wire_29)))
 (= wire_30 $x46)))
(assert
 (let (($x49 (not wire_30)))
 (= wire_31 $x49)))
(assert
 (let (($x62 (not wire_32)))
 (= wire_33 $x62)))
(assert
 (let (($x65 (not wire_34)))
 (= wire_35 $x65)))
(assert
 (let (($x277 (or wire_33 wire_35)))
 (= wire_36 $x277)))
(assert
 (let (($x52 (not wire_36)))
 (= wire_37 $x52)))
(assert
 (let (($x440 (not wire_38)))
 (= wire_39 $x440)))
(assert
 (let (($x443 (not wire_40)))
 (= wire_41 $x443)))
(assert
 (let (($x445 (or wire_39 wire_41)))
 (= wire_42 $x445)))
(assert
 (let (($x447 (not wire_42)))
 (= wire_43 $x447)))
(assert
 (let (($x450 (not wire_44)))
 (= wire_45 $x450)))
(assert
 (let (($x453 (not wire_46)))
 (= wire_47 $x453)))
(assert
 (let (($x455 (or wire_45 wire_47)))
 (= wire_48 $x455)))
(assert
 (let (($x457 (not wire_48)))
 (= wire_49 $x457)))
(assert
 (let (($x460 (not wire_50)))
 (= wire_51 $x460)))
(assert
 (let (($x463 (not wire_52)))
 (= wire_53 $x463)))
(assert
 (let (($x465 (or wire_51 wire_53)))
 (= wire_54 $x465)))
(assert
 (let (($x467 (not wire_54)))
 (= wire_55 $x467)))
(assert
 (let (($x470 (not wire_56)))
 (= wire_57 $x470)))
(assert
 (let (($x473 (not wire_58)))
 (= wire_59 $x473)))
(assert
 (let (($x475 (or wire_57 wire_59)))
 (= wire_60 $x475)))
(assert
 (let (($x477 (not wire_60)))
 (= wire_61 $x477)))
(assert
 (let (($x480 (not wire_62)))
 (= wire_63 $x480)))
(assert
 (let (($x483 (not wire_64)))
 (= wire_65 $x483)))
(assert
 (let (($x485 (or wire_63 wire_65)))
 (= wire_66 $x485)))
(assert
 (let (($x487 (not wire_66)))
 (= wire_67 $x487)))
(assert
 (let (($x490 (not wire_68)))
 (= wire_69 $x490)))
(assert
 (let (($x493 (not wire_70)))
 (= wire_71 $x493)))
(assert
 (let (($x495 (or wire_69 wire_71)))
 (= wire_72 $x495)))
(assert
 (let (($x497 (not wire_72)))
 (= wire_73 $x497)))
(assert
 (let (($x500 (not wire_74)))
 (= wire_75 $x500)))
(assert
 (let (($x503 (not wire_76)))
 (= wire_77 $x503)))
(assert
 (let (($x505 (or wire_75 wire_77)))
 (= wire_78 $x505)))
(assert
 (let (($x507 (not wire_78)))
 (= wire_79 $x507)))
(assert
 (let (($x510 (not wire_80)))
 (= wire_81 $x510)))
(assert
 (let (($x513 (not wire_82)))
 (= wire_83 $x513)))
(assert
 (let (($x515 (or wire_81 wire_83)))
 (= wire_84 $x515)))
(assert
 (let (($x517 (not wire_84)))
 (= wire_85 $x517)))
(assert
 (let (($x520 (not wire_86)))
 (= wire_87 $x520)))
(assert
 (let (($x523 (not wire_88)))
 (= wire_89 $x523)))
(assert
 (let (($x525 (or wire_87 wire_89)))
 (= wire_90 $x525)))
(assert
 (let (($x527 (not wire_90)))
 (= wire_91 $x527)))
(assert
 (let (($x530 (not wire_92)))
 (= wire_93 $x530)))
(assert
 (let (($x533 (not wire_94)))
 (= wire_95 $x533)))
(assert
 (let (($x535 (or wire_93 wire_95)))
 (= wire_96 $x535)))
(assert
 (let (($x537 (not wire_96)))
 (= wire_97 $x537)))
(assert
 (let (($x539 (not wire_7)))
 (= wire_98 $x539)))
(assert
 (let (($x541 (not wire_8)))
 (= wire_99 $x541)))
(assert
 (let (($x543 (or wire_98 wire_99)))
 (= wire_100 $x543)))
(assert
 (let (($x545 (not wire_100)))
 (= wire_101 $x545)))
(assert
 (let (($x547 (or wire_98 wire_11)))
 (= wire_102 $x547)))
(assert
 (let (($x549 (not wire_102)))
 (= wire_103 $x549)))
(assert
 (let (($x551 (or wire_99 wire_11)))
 (= wire_104 $x551)))
(assert
 (let (($x553 (not wire_104)))
 (= wire_105 $x553)))
(assert
 (let (($x555 (or wire_101 wire_103 wire_105)))
 (= wire_106 $x555)))
(assert
 (let (($x557 (not wire_106)))
 (= wire_107 $x557)))
(assert
 (let (($x559 (or wire_93 wire_107)))
 (= wire_108 $x559)))
(assert
 (let (($x561 (not wire_108)))
 (= wire_109 $x561)))
(assert
 (let (($x563 (or wire_95 wire_107)))
 (= wire_110 $x563)))
(assert
 (let (($x565 (not wire_110)))
 (= wire_111 $x565)))
(assert
 (let (($x567 (or wire_97 wire_109 wire_111)))
 (= wire_112 $x567)))
(assert
 (let (($x569 (not wire_112)))
 (= wire_113 $x569)))
(assert
 (let (($x571 (or wire_87 wire_113)))
 (= wire_114 $x571)))
(assert
 (let (($x573 (not wire_114)))
 (= wire_115 $x573)))
(assert
 (let (($x575 (or wire_89 wire_113)))
 (= wire_116 $x575)))
(assert
 (let (($x577 (not wire_116)))
 (= wire_117 $x577)))
(assert
 (let (($x579 (or wire_91 wire_115 wire_117)))
 (= wire_118 $x579)))
(assert
 (let (($x581 (not wire_118)))
 (= wire_119 $x581)))
(assert
 (let (($x583 (or wire_81 wire_119)))
 (= wire_120 $x583)))
(assert
 (let (($x585 (not wire_120)))
 (= wire_121 $x585)))
(assert
 (let (($x587 (or wire_83 wire_119)))
 (= wire_122 $x587)))
(assert
 (let (($x589 (not wire_122)))
 (= wire_123 $x589)))
(assert
 (let (($x591 (or wire_85 wire_121 wire_123)))
 (= wire_124 $x591)))
(assert
 (let (($x593 (not wire_124)))
 (= wire_125 $x593)))
(assert
 (let (($x595 (or wire_75 wire_125)))
 (= wire_126 $x595)))
(assert
 (let (($x597 (not wire_126)))
 (= wire_127 $x597)))
(assert
 (let (($x599 (or wire_77 wire_125)))
 (= wire_128 $x599)))
(assert
 (let (($x601 (not wire_128)))
 (= wire_129 $x601)))
(assert
 (let (($x603 (or wire_79 wire_127 wire_129)))
 (= wire_130 $x603)))
(assert
 (let (($x605 (not wire_130)))
 (= wire_131 $x605)))
(assert
 (let (($x607 (or wire_69 wire_131)))
 (= wire_132 $x607)))
(assert
 (let (($x609 (not wire_132)))
 (= wire_133 $x609)))
(assert
 (let (($x611 (or wire_71 wire_131)))
 (= wire_134 $x611)))
(assert
 (let (($x613 (not wire_134)))
 (= wire_135 $x613)))
(assert
 (let (($x615 (or wire_73 wire_133 wire_135)))
 (= wire_136 $x615)))
(assert
 (let (($x617 (not wire_136)))
 (= wire_137 $x617)))
(assert
 (let (($x619 (or wire_63 wire_137)))
 (= wire_138 $x619)))
(assert
 (let (($x621 (not wire_138)))
 (= wire_139 $x621)))
(assert
 (let (($x623 (or wire_65 wire_137)))
 (= wire_140 $x623)))
(assert
 (let (($x625 (not wire_140)))
 (= wire_141 $x625)))
(assert
 (let (($x627 (or wire_67 wire_139 wire_141)))
 (= wire_142 $x627)))
(assert
 (let (($x629 (not wire_142)))
 (= wire_143 $x629)))
(assert
 (let (($x631 (or wire_57 wire_143)))
 (= wire_144 $x631)))
(assert
 (let (($x633 (not wire_144)))
 (= wire_145 $x633)))
(assert
 (let (($x635 (or wire_59 wire_143)))
 (= wire_146 $x635)))
(assert
 (let (($x637 (not wire_146)))
 (= wire_147 $x637)))
(assert
 (let (($x639 (or wire_61 wire_145 wire_147)))
 (= wire_148 $x639)))
(assert
 (let (($x641 (not wire_148)))
 (= wire_149 $x641)))
(assert
 (let (($x643 (or wire_51 wire_149)))
 (= wire_150 $x643)))
(assert
 (let (($x645 (not wire_150)))
 (= wire_151 $x645)))
(assert
 (let (($x647 (or wire_53 wire_149)))
 (= wire_152 $x647)))
(assert
 (let (($x649 (not wire_152)))
 (= wire_153 $x649)))
(assert
 (let (($x651 (or wire_55 wire_151 wire_153)))
 (= wire_154 $x651)))
(assert
 (let (($x653 (not wire_154)))
 (= wire_155 $x653)))
(assert
 (let (($x655 (or wire_45 wire_155)))
 (= wire_156 $x655)))
(assert
 (let (($x657 (not wire_156)))
 (= wire_157 $x657)))
(assert
 (let (($x659 (or wire_47 wire_155)))
 (= wire_158 $x659)))
(assert
 (let (($x661 (not wire_158)))
 (= wire_159 $x661)))
(assert
 (let (($x663 (or wire_49 wire_157 wire_159)))
 (= wire_160 $x663)))
(assert
 (let (($x665 (not wire_160)))
 (= wire_161 $x665)))
(assert
 (let (($x667 (or wire_39 wire_161)))
 (= wire_162 $x667)))
(assert
 (let (($x669 (not wire_162)))
 (= wire_163 $x669)))
(assert
 (let (($x671 (or wire_41 wire_161)))
 (= wire_164 $x671)))
(assert
 (let (($x673 (not wire_164)))
 (= wire_165 $x673)))
(assert
 (let (($x675 (or wire_43 wire_163 wire_165)))
 (= wire_166 $x675)))
(assert
 (let (($x677 (not wire_166)))
 (= wire_167 $x677)))
(assert
 (let (($x679 (or wire_33 wire_167)))
 (= wire_168 $x679)))
(assert
 (let (($x681 (not wire_168)))
 (= wire_169 $x681)))
(assert
 (let (($x683 (or wire_35 wire_167)))
 (= wire_170 $x683)))
(assert
 (let (($x685 (not wire_170)))
 (= wire_171 $x685)))
(assert
 (let (($x687 (or wire_37 wire_169 wire_171)))
 (= wire_172 $x687)))
(assert
 (let (($x689 (not wire_172)))
 (= wire_173 $x689)))
(assert
 (let (($x691 (or wire_27 wire_173)))
 (= wire_174 $x691)))
(assert
 (let (($x693 (not wire_174)))
 (= wire_175 $x693)))
(assert
 (let (($x695 (or wire_29 wire_173)))
 (= wire_176 $x695)))
(assert
 (let (($x697 (not wire_176)))
 (= wire_177 $x697)))
(assert
 (let (($x699 (or wire_31 wire_175 wire_177)))
 (= wire_178 $x699)))
(assert
 (let (($x701 (not wire_178)))
 (= wire_179 $x701)))
(assert
 (let (($x703 (or wire_21 wire_179)))
 (= wire_180 $x703)))
(assert
 (let (($x705 (not wire_180)))
 (= wire_181 $x705)))
(assert
 (let (($x707 (or wire_23 wire_179)))
 (= wire_182 $x707)))
(assert
 (let (($x709 (not wire_182)))
 (= wire_183 $x709)))
(assert
 (let (($x711 (or wire_25 wire_181 wire_183)))
 (= wire_184 $x711)))
(assert
 (let (($x713 (= wire_19 wire_184)))
 (= wire_185 $x713)))
(assert
 (let (($x715 (= wire_18 wire_185)))
 (= wire_186 $x715)))
(assert
 (let (($x717 (or wire_23 wire_21)))
 (= wire_187 $x717)))
(assert
 (let (($x719 (not wire_187)))
 (= wire_188 $x719)))
(assert
 (let (($x721 (or wire_29 wire_27)))
 (= wire_189 $x721)))
(assert
 (let (($x723 (not wire_189)))
 (= wire_190 $x723)))
(assert
 (let (($x725 (or wire_35 wire_33)))
 (= wire_191 $x725)))
(assert
 (let (($x727 (not wire_191)))
 (= wire_192 $x727)))
(assert
 (let (($x729 (or wire_41 wire_39)))
 (= wire_193 $x729)))
(assert
 (let (($x731 (not wire_193)))
 (= wire_194 $x731)))
(assert
 (let (($x733 (or wire_47 wire_45)))
 (= wire_195 $x733)))
(assert
 (let (($x735 (not wire_195)))
 (= wire_196 $x735)))
(assert
 (let (($x737 (or wire_53 wire_51)))
 (= wire_197 $x737)))
(assert
 (let (($x739 (not wire_197)))
 (= wire_198 $x739)))
(assert
 (let (($x741 (or wire_59 wire_57)))
 (= wire_199 $x741)))
(assert
 (let (($x743 (not wire_199)))
 (= wire_200 $x743)))
(assert
 (let (($x745 (or wire_65 wire_63)))
 (= wire_201 $x745)))
(assert
 (let (($x747 (not wire_201)))
 (= wire_202 $x747)))
(assert
 (let (($x749 (or wire_71 wire_69)))
 (= wire_203 $x749)))
(assert
 (let (($x751 (not wire_203)))
 (= wire_204 $x751)))
(assert
 (let (($x753 (or wire_77 wire_75)))
 (= wire_205 $x753)))
(assert
 (let (($x755 (not wire_205)))
 (= wire_206 $x755)))
(assert
 (let (($x757 (or wire_83 wire_81)))
 (= wire_207 $x757)))
(assert
 (let (($x759 (not wire_207)))
 (= wire_208 $x759)))
(assert
 (let (($x761 (or wire_89 wire_87)))
 (= wire_209 $x761)))
(assert
 (let (($x763 (not wire_209)))
 (= wire_210 $x763)))
(assert
 (let (($x765 (or wire_95 wire_93)))
 (= wire_211 $x765)))
(assert
 (let (($x767 (not wire_211)))
 (= wire_212 $x767)))
(assert
 (let (($x769 (or wire_109 wire_111 wire_212)))
 (= wire_213 $x769)))
(assert
 (let (($x771 (not wire_213)))
 (= wire_214 $x771)))
(assert
 (let (($x773 (or wire_89 wire_214)))
 (= wire_215 $x773)))
(assert
 (let (($x775 (not wire_215)))
 (= wire_216 $x775)))
(assert
 (let (($x777 (or wire_87 wire_214)))
 (= wire_217 $x777)))
(assert
 (let (($x779 (not wire_217)))
 (= wire_218 $x779)))
(assert
 (let (($x781 (or wire_210 wire_216 wire_218)))
 (= wire_219 $x781)))
(assert
 (let (($x783 (not wire_219)))
 (= wire_220 $x783)))
(assert
 (let (($x785 (or wire_83 wire_220)))
 (= wire_221 $x785)))
(assert
 (let (($x787 (not wire_221)))
 (= wire_222 $x787)))
(assert
 (let (($x789 (or wire_81 wire_220)))
 (= wire_223 $x789)))
(assert
 (let (($x791 (not wire_223)))
 (= wire_224 $x791)))
(assert
 (let (($x793 (or wire_208 wire_222 wire_224)))
 (= wire_225 $x793)))
(assert
 (let (($x795 (not wire_225)))
 (= wire_226 $x795)))
(assert
 (let (($x797 (or wire_77 wire_226)))
 (= wire_227 $x797)))
(assert
 (let (($x799 (not wire_227)))
 (= wire_228 $x799)))
(assert
 (let (($x801 (or wire_75 wire_226)))
 (= wire_229 $x801)))
(assert
 (let (($x803 (not wire_229)))
 (= wire_230 $x803)))
(assert
 (let (($x805 (or wire_206 wire_228 wire_230)))
 (= wire_231 $x805)))
(assert
 (let (($x807 (not wire_231)))
 (= wire_232 $x807)))
(assert
 (let (($x809 (or wire_71 wire_232)))
 (= wire_233 $x809)))
(assert
 (let (($x811 (not wire_233)))
 (= wire_234 $x811)))
(assert
 (let (($x813 (or wire_69 wire_232)))
 (= wire_235 $x813)))
(assert
 (let (($x815 (not wire_235)))
 (= wire_236 $x815)))
(assert
 (let (($x817 (or wire_204 wire_234 wire_236)))
 (= wire_237 $x817)))
(assert
 (let (($x819 (not wire_237)))
 (= wire_238 $x819)))
(assert
 (let (($x821 (or wire_65 wire_238)))
 (= wire_239 $x821)))
(assert
 (let (($x823 (not wire_239)))
 (= wire_240 $x823)))
(assert
 (let (($x825 (or wire_63 wire_238)))
 (= wire_241 $x825)))
(assert
 (let (($x827 (not wire_241)))
 (= wire_242 $x827)))
(assert
 (let (($x829 (or wire_202 wire_240 wire_242)))
 (= wire_243 $x829)))
(assert
 (let (($x831 (not wire_243)))
 (= wire_244 $x831)))
(assert
 (let (($x833 (or wire_59 wire_244)))
 (= wire_245 $x833)))
(assert
 (let (($x835 (not wire_245)))
 (= wire_246 $x835)))
(assert
 (let (($x837 (or wire_57 wire_244)))
 (= wire_247 $x837)))
(assert
 (let (($x839 (not wire_247)))
 (= wire_248 $x839)))
(assert
 (let (($x841 (or wire_200 wire_246 wire_248)))
 (= wire_249 $x841)))
(assert
 (let (($x843 (not wire_249)))
 (= wire_250 $x843)))
(assert
 (let (($x845 (or wire_53 wire_250)))
 (= wire_251 $x845)))
(assert
 (let (($x847 (not wire_251)))
 (= wire_252 $x847)))
(assert
 (let (($x849 (or wire_51 wire_250)))
 (= wire_253 $x849)))
(assert
 (let (($x851 (not wire_253)))
 (= wire_254 $x851)))
(assert
 (let (($x853 (or wire_198 wire_252 wire_254)))
 (= wire_255 $x853)))
(assert
 (let (($x855 (not wire_255)))
 (= wire_256 $x855)))
(assert
 (let (($x857 (or wire_47 wire_256)))
 (= wire_257 $x857)))
(assert
 (let (($x859 (not wire_257)))
 (= wire_258 $x859)))
(assert
 (let (($x861 (or wire_45 wire_256)))
 (= wire_259 $x861)))
(assert
 (let (($x863 (not wire_259)))
 (= wire_260 $x863)))
(assert
 (let (($x865 (or wire_196 wire_258 wire_260)))
 (= wire_261 $x865)))
(assert
 (let (($x867 (not wire_261)))
 (= wire_262 $x867)))
(assert
 (let (($x869 (or wire_41 wire_262)))
 (= wire_263 $x869)))
(assert
 (let (($x871 (not wire_263)))
 (= wire_264 $x871)))
(assert
 (let (($x873 (or wire_39 wire_262)))
 (= wire_265 $x873)))
(assert
 (let (($x875 (not wire_265)))
 (= wire_266 $x875)))
(assert
 (let (($x877 (or wire_194 wire_264 wire_266)))
 (= wire_267 $x877)))
(assert
 (let (($x879 (not wire_267)))
 (= wire_268 $x879)))
(assert
 (let (($x881 (or wire_35 wire_268)))
 (= wire_269 $x881)))
(assert
 (let (($x883 (not wire_269)))
 (= wire_270 $x883)))
(assert
 (let (($x885 (or wire_33 wire_268)))
 (= wire_271 $x885)))
(assert
 (let (($x887 (not wire_271)))
 (= wire_272 $x887)))
(assert
 (let (($x889 (or wire_192 wire_270 wire_272)))
 (= wire_273 $x889)))
(assert
 (let (($x891 (not wire_273)))
 (= wire_274 $x891)))
(assert
 (let (($x893 (or wire_29 wire_274)))
 (= wire_275 $x893)))
(assert
 (let (($x895 (not wire_275)))
 (= wire_276 $x895)))
(assert
 (let (($x897 (or wire_27 wire_274)))
 (= wire_277 $x897)))
(assert
 (let (($x899 (not wire_277)))
 (= wire_278 $x899)))
(assert
 (let (($x901 (or wire_190 wire_276 wire_278)))
 (= wire_279 $x901)))
(assert
 (let (($x903 (not wire_279)))
 (= wire_280 $x903)))
(assert
 (let (($x905 (or wire_23 wire_280)))
 (= wire_281 $x905)))
(assert
 (let (($x907 (not wire_281)))
 (= wire_282 $x907)))
(assert
 (let (($x909 (or wire_21 wire_280)))
 (= wire_283 $x909)))
(assert
 (let (($x911 (not wire_283)))
 (= wire_284 $x911)))
(assert
 (let (($x913 (or wire_188 wire_282 wire_284)))
 (= wire_285 $x913)))
(assert
 (let (($x915 (= wire_18 wire_285)))
 (= wire_286 $x915)))
(assert
 (let (($x917 (= wire_19 wire_286)))
 (= wire_287 $x917)))
(assert
 (let (($x919 (= wire_186 wire_287)))
 (= wire_288 $x919)))
(assert
 (let (($x921 (not wire_288)))
 (= wire_289 $x921)))
(assert
 (let (($x923 (= wire_94 wire_106)))
 (= wire_290 $x923)))
(assert
 (let (($x925 (= wire_92 wire_290)))
 (= wire_291 $x925)))
(assert
 (let (($x927 (= wire_92 wire_106)))
 (= wire_292 $x927)))
(assert
 (let (($x929 (= wire_94 wire_292)))
 (= wire_293 $x929)))
(assert
 (let (($x931 (= wire_291 wire_293)))
 (= wire_294 $x931)))
(assert
 (let (($x933 (not wire_294)))
 (= wire_295 $x933)))
(assert
 (let (($x935 (= wire_88 wire_112)))
 (= wire_296 $x935)))
(assert
 (let (($x937 (= wire_86 wire_296)))
 (= wire_297 $x937)))
(assert
 (let (($x939 (= wire_86 wire_213)))
 (= wire_298 $x939)))
(assert
 (let (($x941 (= wire_88 wire_298)))
 (= wire_299 $x941)))
(assert
 (let (($x943 (= wire_297 wire_299)))
 (= wire_300 $x943)))
(assert
 (let (($x945 (not wire_300)))
 (= wire_301 $x945)))
(assert
 (let (($x947 (= wire_82 wire_118)))
 (= wire_302 $x947)))
(assert
 (let (($x949 (= wire_80 wire_302)))
 (= wire_303 $x949)))
(assert
 (let (($x951 (= wire_80 wire_219)))
 (= wire_304 $x951)))
(assert
 (let (($x953 (= wire_82 wire_304)))
 (= wire_305 $x953)))
(assert
 (let (($x955 (= wire_303 wire_305)))
 (= wire_306 $x955)))
(assert
 (let (($x957 (not wire_306)))
 (= wire_307 $x957)))
(assert
 (let (($x959 (= wire_76 wire_124)))
 (= wire_308 $x959)))
(assert
 (let (($x961 (= wire_74 wire_308)))
 (= wire_309 $x961)))
(assert
 (let (($x963 (= wire_74 wire_225)))
 (= wire_310 $x963)))
(assert
 (let (($x965 (= wire_76 wire_310)))
 (= wire_311 $x965)))
(assert
 (let (($x967 (= wire_309 wire_311)))
 (= wire_312 $x967)))
(assert
 (let (($x969 (not wire_312)))
 (= wire_313 $x969)))
(assert
 (let (($x971 (= wire_70 wire_130)))
 (= wire_314 $x971)))
(assert
 (let (($x973 (= wire_68 wire_314)))
 (= wire_315 $x973)))
(assert
 (let (($x975 (= wire_68 wire_231)))
 (= wire_316 $x975)))
(assert
 (let (($x977 (= wire_70 wire_316)))
 (= wire_317 $x977)))
(assert
 (let (($x979 (= wire_315 wire_317)))
 (= wire_318 $x979)))
(assert
 (let (($x981 (not wire_318)))
 (= wire_319 $x981)))
(assert
 (let (($x983 (= wire_64 wire_136)))
 (= wire_320 $x983)))
(assert
 (let (($x985 (= wire_62 wire_320)))
 (= wire_321 $x985)))
(assert
 (let (($x987 (= wire_62 wire_237)))
 (= wire_322 $x987)))
(assert
 (let (($x989 (= wire_64 wire_322)))
 (= wire_323 $x989)))
(assert
 (let (($x991 (= wire_321 wire_323)))
 (= wire_324 $x991)))
(assert
 (let (($x993 (not wire_324)))
 (= wire_325 $x993)))
(assert
 (let (($x995 (= wire_58 wire_142)))
 (= wire_326 $x995)))
(assert
 (let (($x997 (= wire_56 wire_326)))
 (= wire_327 $x997)))
(assert
 (let (($x999 (= wire_56 wire_243)))
 (= wire_328 $x999)))
(assert
 (let (($x1001 (= wire_58 wire_328)))
 (= wire_329 $x1001)))
(assert
 (let (($x1003 (= wire_327 wire_329)))
 (= wire_330 $x1003)))
(assert
 (let (($x1005 (not wire_330)))
 (= wire_331 $x1005)))
(assert
 (let (($x1007 (= wire_52 wire_148)))
 (= wire_332 $x1007)))
(assert
 (let (($x1009 (= wire_50 wire_332)))
 (= wire_333 $x1009)))
(assert
 (let (($x1011 (= wire_50 wire_249)))
 (= wire_334 $x1011)))
(assert
 (let (($x1013 (= wire_52 wire_334)))
 (= wire_335 $x1013)))
(assert
 (let (($x1015 (= wire_333 wire_335)))
 (= wire_336 $x1015)))
(assert
 (let (($x1017 (not wire_336)))
 (= wire_337 $x1017)))
(assert
 (let (($x1019 (= wire_46 wire_154)))
 (= wire_338 $x1019)))
(assert
 (let (($x1021 (= wire_44 wire_338)))
 (= wire_339 $x1021)))
(assert
 (let (($x1023 (= wire_44 wire_255)))
 (= wire_340 $x1023)))
(assert
 (let (($x1025 (= wire_46 wire_340)))
 (= wire_341 $x1025)))
(assert
 (let (($x1027 (= wire_339 wire_341)))
 (= wire_342 $x1027)))
(assert
 (let (($x1029 (not wire_342)))
 (= wire_343 $x1029)))
(assert
 (let (($x1031 (= wire_40 wire_160)))
 (= wire_344 $x1031)))
(assert
 (let (($x1033 (= wire_38 wire_344)))
 (= wire_345 $x1033)))
(assert
 (let (($x1035 (= wire_38 wire_261)))
 (= wire_346 $x1035)))
(assert
 (let (($x1037 (= wire_40 wire_346)))
 (= wire_347 $x1037)))
(assert
 (let (($x1039 (= wire_345 wire_347)))
 (= wire_348 $x1039)))
(assert
 (let (($x1041 (not wire_348)))
 (= wire_349 $x1041)))
(assert
 (let (($x1043 (= wire_34 wire_166)))
 (= wire_350 $x1043)))
(assert
 (let (($x1045 (= wire_32 wire_350)))
 (= wire_351 $x1045)))
(assert
 (let (($x1047 (= wire_32 wire_267)))
 (= wire_352 $x1047)))
(assert
 (let (($x1049 (= wire_34 wire_352)))
 (= wire_353 $x1049)))
(assert
 (let (($x1051 (= wire_351 wire_353)))
 (= wire_354 $x1051)))
(assert
 (let (($x1053 (not wire_354)))
 (= wire_355 $x1053)))
(assert
 (let (($x1055 (= wire_28 wire_172)))
 (= wire_356 $x1055)))
(assert
 (let (($x1057 (= wire_26 wire_356)))
 (= wire_357 $x1057)))
(assert
 (let (($x1059 (= wire_26 wire_273)))
 (= wire_358 $x1059)))
(assert
 (let (($x1061 (= wire_28 wire_358)))
 (= wire_359 $x1061)))
(assert
 (let (($x1063 (= wire_357 wire_359)))
 (= wire_360 $x1063)))
(assert
 (let (($x1065 (not wire_360)))
 (= wire_361 $x1065)))
(assert
 (let (($x1067 (= wire_22 wire_178)))
 (= wire_362 $x1067)))
(assert
 (let (($x1069 (= wire_20 wire_362)))
 (= wire_363 $x1069)))
(assert
 (let (($x1071 (= wire_20 wire_279)))
 (= wire_364 $x1071)))
(assert
 (let (($x1073 (= wire_22 wire_364)))
 (= wire_365 $x1073)))
(assert
 (let (($x1075 (= wire_363 wire_365)))
 (= wire_366 $x1075)))
(assert
 (let (($x1077 (not wire_366)))
 (= wire_367 $x1077)))
(assert
 (let (($x1079 (or wire_6 wire_17 wire_289 wire_295 wire_301 wire_307 wire_313 wire_319 wire_325 wire_331 wire_337 wire_343 wire_349 wire_355 wire_361 wire_367)))
 (= wire_368 $x1079)))
(assert
 (let (($x1081 (not wire_368)))
 (= wire_369 $x1081)))
(assert
 (let (($x1083 (not wire_369)))
 (= wire_370 $x1083)))
(assert
 (let (($x1085 (and wire_0 wire_370)))
 (= wire_371 $x1085)))
(assert
 (= output wire_371))
(check-sat)
