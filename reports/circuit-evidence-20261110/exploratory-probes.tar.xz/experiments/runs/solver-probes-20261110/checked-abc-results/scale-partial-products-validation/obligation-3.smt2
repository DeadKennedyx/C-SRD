; 
(set-info :status unknown)
(declare-fun local_0 () Bool)
(assert
 (let (($x1210 (not local_0)))
(and (distinct $x1210 (or false (and true $x1210))) true)))
(check-sat)
