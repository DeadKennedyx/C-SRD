; 
(set-info :status unknown)
(assert
 (let (($x1087 (or false true)))
(and (distinct true $x1087) true)))
(check-sat)
