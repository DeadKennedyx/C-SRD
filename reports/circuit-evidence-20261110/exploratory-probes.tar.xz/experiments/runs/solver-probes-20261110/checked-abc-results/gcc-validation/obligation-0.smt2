; 
(set-info :status unknown)
(assert
 (let (($x17489 (or false true)))
(and (distinct true $x17489) true)))
(check-sat)
