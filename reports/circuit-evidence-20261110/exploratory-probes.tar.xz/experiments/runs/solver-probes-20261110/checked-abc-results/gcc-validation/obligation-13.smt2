; 
(set-info :status unknown)
(declare-fun local_0 () Bool)
(assert
 (let (($x20092 (and true local_0)))
(let (($x20093 (or false $x20092)))
(and (distinct local_0 $x20093) true))))
(check-sat)
