; 
(set-info :status unknown)
(declare-fun local_2 () Bool)
(declare-fun local_0 () Bool)
(declare-fun local_1 () Bool)
(assert
 (let (($x25991 (or (or false (and (and true local_0) local_1)) (and (and true (not local_0)) local_2))))
(let (($x25992 (ite local_0 local_1 local_2)))
(and (distinct $x25992 $x25991) true))))
(check-sat)
