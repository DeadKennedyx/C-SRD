; 
(set-info :status unknown)
(declare-fun local_1 () Bool)
(declare-fun local_2 () Bool)
(declare-fun local_0 () Bool)
(assert
 (let (($x20074 (and true local_1)))
(let (($x23402 (or (or (or false (and true local_0)) (and true local_2)) $x20074)))
(and (distinct (or local_0 local_2 local_1) $x23402) true))))
(check-sat)
