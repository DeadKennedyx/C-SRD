; 
(set-info :status unknown)
(declare-fun local_0 () Bool)
(declare-fun local_2 () Bool)
(declare-fun local_1 () Bool)
(assert
 (let (($x20092 (and true local_0)))
(let (($x17515 (or (or (or false (and true local_1)) (and true local_2)) $x20092)))
(and (distinct (or local_1 local_2 local_0) $x17515) true))))
(check-sat)
