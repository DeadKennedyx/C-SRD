; 
(set-info :status unknown)
(declare-fun local_1 () Bool)
(declare-fun local_0 () Bool)
(assert
 (let (($x20092 (and true local_0)))
(let (($x20277 (and $x20092 local_1)))
(let (($x25990 (or false $x20277)))
(let (($x28106 (and local_0 local_1)))
(and (distinct $x28106 $x25990) true))))))
(check-sat)
