; 
(set-info :status unknown)
(declare-fun local_0 () Bool)
(assert
 (let (($x20063 (not local_0)))
(and (distinct $x20063 (or false (and true $x20063))) true)))
(check-sat)
