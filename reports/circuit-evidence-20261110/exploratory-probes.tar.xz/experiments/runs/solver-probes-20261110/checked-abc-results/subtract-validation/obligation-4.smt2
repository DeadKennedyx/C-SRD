; 
(set-info :status unknown)
(declare-fun local_0 () Bool)
(assert
 (let (($x3039 (not local_0)))
(and (distinct $x3039 (or false (and true $x3039))) true)))
(check-sat)
