; 
(set-info :status unknown)
(assert
 (let (($x2606 (or false true)))
(and (distinct true $x2606) true)))
(check-sat)
