; 
(set-info :status unknown)
(declare-fun local_2 () Bool)
(declare-fun local_1 () Bool)
(declare-fun local_0 () Bool)
(assert
 (let (($x2938 (and true local_1)))
(let (($x2941 (or (or false (and true local_0)) $x2938)))
(let (($x2838 (or local_0 local_1 local_2)))
(and (distinct $x2838 (or $x2941 (and true local_2))) true)))))
(check-sat)
