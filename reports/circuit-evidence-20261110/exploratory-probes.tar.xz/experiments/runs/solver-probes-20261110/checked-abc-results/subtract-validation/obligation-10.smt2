; 
(set-info :status unknown)
(declare-fun local_0 () Bool)
(assert
 (let (($x2939 (and true local_0)))
(let (($x2940 (or false $x2939)))
(and (distinct local_0 $x2940) true))))
(check-sat)
