; 
(set-info :status unknown)
(declare-fun cut!34849 () (_ BitVec 32))
(declare-fun cut!34856 () (_ BitVec 16))
(declare-fun cut!34817 () (_ BitVec 16))
(declare-fun cut!34850 () (_ BitVec 16))
(assert
 (let ((?x10569 ((_ extract 31 16) cut!34849)))
(let ((?x2858 (concat (_ bv0 16) ((_ extract 15 10) (bvadd (bvmul (_ bv1024 16) cut!34817) (bvmul (_ bv1024 16) cut!34856))) (_ bv0 10))))
(let ((?x3162 (bvadd (concat (_ bv0 16) ((_ extract 31 16) (bvadd (concat (_ bv0 16) cut!34850) ?x2858))) cut!34849)))
(let ((?x8407 ((_ extract 31 16) ?x3162)))
(and (distinct ?x8407 ?x10569) true))))))
(check-sat)
