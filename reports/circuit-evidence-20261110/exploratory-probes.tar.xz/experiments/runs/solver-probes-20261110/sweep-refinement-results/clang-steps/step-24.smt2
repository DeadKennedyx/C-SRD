; 
(set-info :status unknown)
(declare-fun cut!1624 () (_ BitVec 16))
(assert
 (let ((?x958 (concat ((_ extract 15 10) cut!1624) (_ bv0 10))))
(and (distinct ?x958 cut!1624) true)))
(check-sat)
