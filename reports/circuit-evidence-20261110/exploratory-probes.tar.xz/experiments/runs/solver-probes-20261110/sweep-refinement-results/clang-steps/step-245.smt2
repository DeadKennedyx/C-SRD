; 
(set-info :status unknown)
(declare-fun cut!31986 () (_ BitVec 32))
(declare-fun input_0_low () (_ BitVec 16))
(declare-fun input_0_high () (_ BitVec 16))
(declare-fun cut!31981 () (_ BitVec 32))
(assert
 (let ((?x2177 (concat ((_ extract 31 16) cut!31986) ((_ extract 31 16) (bvadd cut!31981 (concat input_0_high input_0_low))))))
(and (distinct ?x2177 cut!31986) true)))
(check-sat)
