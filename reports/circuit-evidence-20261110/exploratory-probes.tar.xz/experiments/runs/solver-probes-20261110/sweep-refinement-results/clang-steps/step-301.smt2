; 
(set-info :status unknown)
(declare-fun cut!37379 () (_ BitVec 32))
(declare-fun cut!37360 () (_ BitVec 10))
(declare-fun cut!37380 () (_ BitVec 16))
(declare-fun cut!37409 () (_ BitVec 10))
(declare-fun cut!37347 () (_ BitVec 6))
(assert
 (let ((?x8407 (bvadd (bvmul (_ bv1025 16) (concat cut!37347 cut!37409)) (bvmul (_ bv1025 16) cut!37380) (concat (_ bv0 6) cut!37360))))
(let ((?x3162 (concat ((_ extract 31 16) cut!37379) ?x8407)))
(and (distinct ?x3162 cut!37379) true))))
(check-sat)
