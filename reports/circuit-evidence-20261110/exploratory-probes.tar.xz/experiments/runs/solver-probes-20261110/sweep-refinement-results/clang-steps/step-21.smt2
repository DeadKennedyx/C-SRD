; 
(set-info :status unknown)
(declare-fun cut!1478 () (_ BitVec 16))
(declare-fun input_0_low () (_ BitVec 16))
(assert
 (let ((?x228 (bvmul (_ bv1025 16) input_0_low)))
(let ((?x902 (bvadd ?x228 (bvmul (_ bv1025 16) cut!1478))))
(let ((?x963 (bvadd input_0_low cut!1478 (bvadd (bvmul (_ bv1024 16) input_0_low) (bvmul (_ bv1024 16) cut!1478)))))
(and (distinct ?x963 ?x902) true)))))
(check-sat)
