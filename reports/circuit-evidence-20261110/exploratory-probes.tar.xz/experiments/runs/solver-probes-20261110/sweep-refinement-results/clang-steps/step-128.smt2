; 
(set-info :status unknown)
(declare-fun cut!10314 () (_ BitVec 10))
(declare-fun cut!10317 () (_ BitVec 6))
(declare-fun cut!10300 () (_ BitVec 8))
(assert
 (let ((?x1203 (bvadd (concat (_ bv0 24) cut!10300) (concat (_ bv0 16) cut!10317 cut!10314))))
(let ((?x2683 (concat (_ bv0 16) (bvadd (concat (_ bv0 8) cut!10300) (concat cut!10317 cut!10314)))))
(and (distinct ?x2683 ?x1203) true))))
(check-sat)
