; 
(set-info :status unknown)
(declare-fun cut!32508 () (_ BitVec 32))
(declare-fun cut!32504 () (_ BitVec 8))
(declare-fun input_0_low () (_ BitVec 16))
(assert
 (let ((?x1692 ((_ extract 31 16) cut!32508)))
(let ((?x2048 (bvadd (concat (_ bv0 22) ((_ extract 15 6) (bvadd input_0_low (concat (_ bv0 8) cut!32504)))) cut!32508)))
(let ((?x229 (bvmul (_ bv1024 16) input_0_low)))
(let ((?x3654 (concat (_ bv0 16) ((_ extract 15 10) (bvadd ?x229 (bvmul (_ bv1024 16) (concat (_ bv0 8) cut!32504)))) (_ bv0 10))))
(let ((?x2505 (bvadd (concat (_ bv0 16) (bvadd input_0_low (concat (_ bv0 8) cut!32504))) ?x3654)))
(let ((?x13236 ((_ extract 31 16) (bvadd (concat (_ bv0 16) ((_ extract 31 16) ?x2505)) ?x2048))))
(and (distinct ?x13236 ?x1692) true))))))))
(check-sat)
