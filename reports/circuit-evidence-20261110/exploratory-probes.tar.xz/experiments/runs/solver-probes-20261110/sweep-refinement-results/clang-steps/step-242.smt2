; 
(set-info :status unknown)
(declare-fun cut!31832 () (_ BitVec 16))
(declare-fun input_0_high () (_ BitVec 16))
(assert
 (let ((?x2208 ((_ extract 31 16) (bvadd (concat (_ bv0 16) input_0_high) (concat (_ bv0 16) cut!31832)))))
(and (distinct ?x2208 cut!31832) true)))
(check-sat)
