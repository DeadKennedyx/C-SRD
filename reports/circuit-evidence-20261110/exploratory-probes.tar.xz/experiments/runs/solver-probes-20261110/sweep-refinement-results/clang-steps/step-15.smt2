; 
(set-info :status unknown)
(declare-fun cut!1089 () (_ BitVec 32))
(declare-fun cut!1090 () (_ BitVec 10))
(declare-fun cut!1087 () (_ BitVec 6))
(declare-fun cut!1046 () (_ BitVec 8))
(assert
 (let ((?x954 (bvadd (bvmul (_ bv1024 16) (concat (_ bv0 8) cut!1046)) (bvmul (_ bv1024 16) (concat cut!1087 cut!1090)))))
(let ((?x960 (concat ((_ extract 31 16) cut!1089) ?x954)))
(and (distinct ?x960 cut!1089) true))))
(check-sat)
