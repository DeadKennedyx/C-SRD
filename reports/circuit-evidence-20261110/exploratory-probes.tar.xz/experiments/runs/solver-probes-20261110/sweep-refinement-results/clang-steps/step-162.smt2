; 
(set-info :status unknown)
(declare-fun cut!16670 () (_ BitVec 16))
(assert
 (let ((?x13325 (bvmul (_ bv1025 16) cut!16670)))
(and (distinct ?x13325 cut!16670) true)))
(check-sat)
