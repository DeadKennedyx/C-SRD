; 
(set-info :status unknown)
(declare-fun cut!34179 () (_ BitVec 32))
(declare-fun cut!34176 () (_ BitVec 16))
(declare-fun cut!34193 () (_ BitVec 10))
(declare-fun cut!34188 () (_ BitVec 6))
(assert
 (let ((?x1959 (bvadd (bvmul (_ bv1025 16) (concat cut!34188 cut!34193)) (bvmul (_ bv1025 16) cut!34176))))
(let ((?x13365 (concat ((_ extract 31 16) cut!34179) ?x1959)))
(and (distinct ?x13365 cut!34179) true))))
(check-sat)
