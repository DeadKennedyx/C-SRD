; 
(set-info :status unknown)
(declare-fun cut!32138 () (_ BitVec 32))
(declare-fun cut!32137 () (_ BitVec 16))
(declare-fun input_0_high () (_ BitVec 16))
(assert
 (let ((?x2208 (concat ((_ extract 31 16) cut!32138) (bvadd (bvmul (_ bv1025 16) input_0_high) (bvmul (_ bv1025 16) cut!32137)))))
(and (distinct ?x2208 cut!32138) true)))
(check-sat)
