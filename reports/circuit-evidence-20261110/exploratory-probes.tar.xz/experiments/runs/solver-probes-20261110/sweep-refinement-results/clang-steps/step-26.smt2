; 
(set-info :status unknown)
(declare-fun cut!1709 () (_ BitVec 16))
(declare-fun cut!1696 () (_ BitVec 16))
(assert
 (let ((?x1058 (bvadd (bvmul (_ bv1025 16) cut!1696) (bvmul (_ bv1025 16) cut!1709))))
(let ((?x1112 (bvadd cut!1696 cut!1709 (bvadd (bvmul (_ bv1024 16) cut!1696) (bvmul (_ bv1024 16) cut!1709)))))
(and (distinct ?x1112 ?x1058) true))))
(check-sat)
