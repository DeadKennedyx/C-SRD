; 
(set-info :status unknown)
(declare-fun cut!41184 () (_ BitVec 32))
(declare-fun cut!41237 () (_ BitVec 10))
(declare-fun cut!41189 () (_ BitVec 6))
(declare-fun cut!41160 () (_ BitVec 8))
(assert
 (let ((?x14960 ((_ extract 31 16) cut!41184)))
(let ((?x1073 ((_ extract 15 6) (bvadd (concat (_ bv0 8) cut!41160) (concat cut!41189 cut!41237)))))
(let ((?x4396 ((_ extract 31 16) (bvadd (concat (_ bv0 22) ?x1073) cut!41184))))
(and (distinct ?x4396 ?x14960) true)))))
(check-sat)
