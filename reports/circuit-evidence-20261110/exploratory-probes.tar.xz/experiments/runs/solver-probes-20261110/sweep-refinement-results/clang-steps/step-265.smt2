; 
(set-info :status unknown)
(declare-fun cut!33520 () (_ BitVec 10))
(declare-fun cut!33529 () (_ BitVec 6))
(declare-fun cut!33526 () (_ BitVec 10))
(declare-fun cut!33532 () (_ BitVec 6))
(declare-fun cut!33522 () (_ BitVec 32))
(assert
 (let ((?x2678 (bvadd cut!33522 (concat cut!33532 cut!33526 cut!33529 cut!33520))))
(let ((?x981 ((_ extract 31 16) ?x2678)))
(let ((?x1464 (bvadd ((_ extract 31 16) (bvadd cut!33522 (concat (_ bv0 16) cut!33529 cut!33520))) (concat cut!33532 cut!33526))))
(and (distinct ?x1464 ?x981) true)))))
(check-sat)
