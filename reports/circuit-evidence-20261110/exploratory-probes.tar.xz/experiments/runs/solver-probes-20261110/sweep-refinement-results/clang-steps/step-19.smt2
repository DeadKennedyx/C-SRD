; 
(set-info :status unknown)
(declare-fun cut!1425 () (_ BitVec 16))
(assert
 (let ((?x974 (concat ((_ extract 15 10) cut!1425) (_ bv0 10))))
(and (distinct ?x974 cut!1425) true)))
(check-sat)
