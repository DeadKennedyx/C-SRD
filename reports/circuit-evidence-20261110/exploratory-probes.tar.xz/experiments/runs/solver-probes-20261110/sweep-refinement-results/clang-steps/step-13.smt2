; 
(set-info :status unknown)
(declare-fun cut!865 () (_ BitVec 32))
(declare-fun cut!901 () (_ BitVec 10))
(declare-fun cut!882 () (_ BitVec 6))
(declare-fun cut!854 () (_ BitVec 8))
(assert
 (let ((?x998 (concat ((_ extract 31 16) cut!865) (bvadd (concat (_ bv0 8) cut!854) (concat cut!882 cut!901)))))
(and (distinct ?x998 cut!865) true)))
(check-sat)
