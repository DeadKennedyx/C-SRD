; 
(set-info :status unknown)
(declare-fun cut!19 () (_ BitVec 32))
(declare-fun cut!17 () (_ BitVec 8))
(declare-fun input_0_low () (_ BitVec 16))
(assert
 (let ((?x951 (concat ((_ extract 31 16) cut!19) (bvadd input_0_low (concat (_ bv0 8) cut!17)))))
(and (distinct ?x951 cut!19) true)))
(check-sat)
