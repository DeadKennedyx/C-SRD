; 
(set-info :status unknown)
(declare-fun cut!42319 () (_ BitVec 32))
(declare-fun cut!42402 () (_ BitVec 10))
(declare-fun cut!42337 () (_ BitVec 6))
(assert
 (let ((?x3771 (concat ((_ extract 31 16) cut!42319) (bvmul (_ bv9 16) (concat cut!42337 cut!42402)))))
(and (distinct ?x3771 cut!42319) true)))
(check-sat)
