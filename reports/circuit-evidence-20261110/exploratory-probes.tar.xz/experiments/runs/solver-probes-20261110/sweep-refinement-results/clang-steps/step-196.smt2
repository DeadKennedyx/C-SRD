; 
(set-info :status unknown)
(declare-fun cut!20935 () (_ BitVec 32))
(declare-fun cut!20882 () (_ BitVec 10))
(declare-fun cut!20952 () (_ BitVec 3))
(assert
 (let ((?x13428 (concat ((_ extract 31 16) cut!20935) (bvmul (_ bv8 16) (concat (_ bv0 3) cut!20952 cut!20882)))))
(and (distinct ?x13428 cut!20935) true)))
(check-sat)
