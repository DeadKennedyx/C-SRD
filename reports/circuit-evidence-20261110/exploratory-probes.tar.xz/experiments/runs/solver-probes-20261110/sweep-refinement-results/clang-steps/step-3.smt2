; 
(set-info :status unknown)
(declare-fun cut!126 () (_ BitVec 32))
(declare-fun cut!125 () (_ BitVec 8))
(declare-fun input_0_low () (_ BitVec 16))
(assert
 (let ((?x954 (concat ((_ extract 31 16) cut!126) (bvadd (bvmul (_ bv1024 16) input_0_low) (bvmul (_ bv1024 16) (concat (_ bv0 8) cut!125))))))
(and (distinct ?x954 cut!126) true)))
(check-sat)
