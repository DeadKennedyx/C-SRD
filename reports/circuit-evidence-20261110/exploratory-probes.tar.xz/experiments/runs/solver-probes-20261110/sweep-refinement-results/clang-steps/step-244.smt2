; 
(set-info :status unknown)
(declare-fun input_0_low () (_ BitVec 16))
(declare-fun input_0_high () (_ BitVec 16))
(declare-fun cut!31913 () (_ BitVec 32))
(assert
 (let ((?x2208 ((_ extract 31 16) (bvadd cut!31913 (concat input_0_high input_0_low)))))
(let ((?x12937 (bvadd input_0_high ((_ extract 31 16) (bvadd (concat (_ bv0 16) input_0_low) cut!31913)))))
(and (distinct ?x12937 ?x2208) true))))
(check-sat)
