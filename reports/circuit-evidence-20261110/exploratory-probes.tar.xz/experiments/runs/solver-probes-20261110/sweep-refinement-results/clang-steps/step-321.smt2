; 
(set-info :status unknown)
(declare-fun cut!40451 () (_ BitVec 32))
(declare-fun cut!40391 () (_ BitVec 10))
(declare-fun cut!40373 () (_ BitVec 6))
(declare-fun cut!40413 () (_ BitVec 16))
(assert
 (let ((?x12977 (concat ((_ extract 31 16) cut!40451) (bvadd cut!40413 (concat cut!40373 cut!40391)))))
(and (distinct ?x12977 cut!40451) true)))
(check-sat)
