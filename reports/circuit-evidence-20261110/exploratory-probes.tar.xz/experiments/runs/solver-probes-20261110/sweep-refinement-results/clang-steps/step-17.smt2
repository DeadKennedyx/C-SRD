; 
(set-info :status unknown)
(declare-fun cut!1278 () (_ BitVec 32))
(declare-fun cut!1270 () (_ BitVec 10))
(declare-fun cut!1294 () (_ BitVec 6))
(assert
 (let ((?x1460 (concat ((_ extract 31 16) cut!1278) (bvmul (_ bv8 16) (concat cut!1294 cut!1270)))))
(and (distinct ?x1460 cut!1278) true)))
(check-sat)
