; 
(set-info :status unknown)
(declare-fun cut!42020 () (_ BitVec 32))
(declare-fun cut!42076 () (_ BitVec 16))
(declare-fun cut!41989 () (_ BitVec 16))
(declare-fun cut!42046 () (_ BitVec 16))
(assert
 (let ((?x8779 ((_ extract 31 16) cut!42020)))
(let ((?x2246 (concat (_ bv0 16) ((_ extract 15 10) (bvadd (bvmul (_ bv1024 16) cut!41989) (bvmul (_ bv1024 16) cut!42076))) (_ bv0 10))))
(let ((?x2543 (bvadd (concat (_ bv0 16) ((_ extract 31 16) (bvadd (concat (_ bv0 16) cut!42046) ?x2246))) cut!42020)))
(let ((?x11040 ((_ extract 31 16) ?x2543)))
(and (distinct ?x11040 ?x8779) true))))))
(check-sat)
