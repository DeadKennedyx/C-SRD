; 
(set-info :status unknown)
(declare-fun cut!14719 () (_ BitVec 1))
(declare-fun input_1_low () (_ BitVec 16))
(declare-fun input_0_low () (_ BitVec 16))
(declare-fun cut!14709 () (_ BitVec 16))
(assert
 (let ((?x823 ((_ extract 0 0) input_1_low)))
(let ((?x842 ((_ extract 0 0) input_0_low)))
(let ((?x903 (bvadd ?x842 ?x823)))
(let ((?x863 ((_ extract 8 8) input_1_low)))
(let ((?x2383 (bvxor cut!14719 (bvadd ?x863 (bvxor ((_ extract 6 6) cut!14709) ?x903)))))
(and (distinct ?x2383 cut!14719) true)))))))
(check-sat)
