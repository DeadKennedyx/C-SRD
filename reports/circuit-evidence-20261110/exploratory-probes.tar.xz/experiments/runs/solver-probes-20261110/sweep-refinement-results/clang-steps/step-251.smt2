; 
(set-info :status unknown)
(declare-fun cut!32377 () (_ BitVec 32))
(declare-fun cut!32374 () (_ BitVec 10))
(declare-fun cut!32373 () (_ BitVec 16))
(declare-fun input_0_high () (_ BitVec 16))
(assert
 (let ((?x2189 (bvmul (_ bv1025 16) input_0_high)))
(let ((?x3344 (concat ((_ extract 31 16) cut!32377) (bvadd ?x2189 (bvmul (_ bv1025 16) cut!32373) (concat (_ bv0 6) cut!32374)))))
(and (distinct ?x3344 cut!32377) true))))
(check-sat)
