; 
(set-info :status unknown)
(declare-fun cut!36490 () (_ BitVec 32))
(declare-fun cut!36528 () (_ BitVec 10))
(declare-fun cut!36523 () (_ BitVec 6))
(declare-fun cut!36485 () (_ BitVec 10))
(declare-fun cut!36501 () (_ BitVec 6))
(declare-fun cut!36459 () (_ BitVec 32))
(assert
 (let ((?x4256 (bvadd cut!36459 (concat cut!36501 cut!36485 cut!36523 cut!36528))))
(let ((?x3879 (concat ((_ extract 31 16) cut!36490) ((_ extract 31 16) ?x4256))))
(and (distinct ?x3879 cut!36490) true))))
(check-sat)
