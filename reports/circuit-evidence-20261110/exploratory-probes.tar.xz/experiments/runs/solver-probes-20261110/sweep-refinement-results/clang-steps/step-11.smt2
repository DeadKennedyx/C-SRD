; 
(set-info :status unknown)
(declare-fun cut!700 () (_ BitVec 32))
(declare-fun cut!694 () (_ BitVec 10))
(declare-fun cut!709 () (_ BitVec 6))
(declare-fun cut!673 () (_ BitVec 8))
(assert
 (let ((?x1145 (bvadd (bvmul (_ bv1024 16) (concat (_ bv0 8) cut!673)) (bvmul (_ bv1024 16) (concat cut!709 cut!694)))))
(let ((?x1097 (concat ((_ extract 31 16) cut!700) ?x1145)))
(and (distinct ?x1097 cut!700) true))))
(check-sat)
