; 
(set-info :status unknown)
(declare-fun cut!37857 () (_ BitVec 32))
(declare-fun cut!37856 () (_ BitVec 16))
(declare-fun cut!37796 () (_ BitVec 16))
(declare-fun cut!37837 () (_ BitVec 16))
(assert
 (let ((?x10991 ((_ extract 31 16) cut!37857)))
(let ((?x1859 (concat (_ bv0 16) ((_ extract 15 10) (bvadd (bvmul (_ bv1024 16) cut!37796) (bvmul (_ bv1024 16) cut!37856))) (_ bv0 10))))
(let ((?x1857 (bvadd (concat (_ bv0 16) ((_ extract 31 16) (bvadd (concat (_ bv0 16) cut!37837) ?x1859))) cut!37857)))
(let ((?x5254 ((_ extract 31 16) ?x1857)))
(and (distinct ?x5254 ?x10991) true))))))
(check-sat)
