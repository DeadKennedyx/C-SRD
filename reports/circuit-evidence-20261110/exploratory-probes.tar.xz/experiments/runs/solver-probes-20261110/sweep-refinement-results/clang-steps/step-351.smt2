; 
(set-info :status unknown)
(declare-fun cut!44989 () (_ BitVec 16))
(declare-fun cut!44982 () (_ BitVec 16))
(assert
 (let ((?x10316 ((_ extract 10 6) (bvadd (bvmul (_ bv1025 16) cut!44982) (bvmul (_ bv1025 16) cut!44989)))))
(let ((?x1769 ((_ extract 10 6) (bvadd cut!44982 cut!44989))))
(and (distinct ?x1769 ?x10316) true))))
(check-sat)
