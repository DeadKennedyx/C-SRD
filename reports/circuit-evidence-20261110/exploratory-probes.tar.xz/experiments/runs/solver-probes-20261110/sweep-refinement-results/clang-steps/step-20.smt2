; 
(set-info :status unknown)
(declare-fun input_1_low () (_ BitVec 16))
(declare-fun input_0_low () (_ BitVec 16))
(assert
 (let ((?x215 ((_ extract 7 0) input_1_low)))
(let ((?x232 (concat (_ bv0 8) ?x215)))
(let ((?x230 (bvmul (_ bv1024 16) ?x232)))
(let ((?x229 (bvmul (_ bv1024 16) input_0_low)))
(let ((?x225 (bvadd ?x229 ?x230)))
(let ((?x413 ((_ extract 15 10) ?x225)))
(let ((?x428 (concat ?x413 (_ bv0 10))))
(and (distinct ?x428 ?x225) true)))))))))
(check-sat)
