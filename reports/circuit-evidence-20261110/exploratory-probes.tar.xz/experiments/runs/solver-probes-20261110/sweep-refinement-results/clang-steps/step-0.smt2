; 
(set-info :status unknown)
(declare-fun input_0_high () (_ BitVec 16))
(assert
 (let ((?x198 (concat (_ bv0 16) input_0_high)))
(let ((?x199 (bvmul (_ bv65536 32) ?x198)))
(let ((?x200 ((_ extract 31 16) ?x199)))
(and (distinct ?x200 input_0_high) true)))))
(check-sat)
