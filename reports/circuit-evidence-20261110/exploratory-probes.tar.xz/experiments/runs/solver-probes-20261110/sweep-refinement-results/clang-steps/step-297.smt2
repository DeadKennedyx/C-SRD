; 
(set-info :status unknown)
(declare-fun cut!36940 () (_ BitVec 32))
(declare-fun cut!36906 () (_ BitVec 16))
(declare-fun cut!36954 () (_ BitVec 10))
(declare-fun cut!36932 () (_ BitVec 6))
(assert
 (let ((?x12808 (bvadd (bvmul (_ bv1025 16) (concat cut!36932 cut!36954)) (bvmul (_ bv1025 16) cut!36906))))
(let ((?x11536 (concat ((_ extract 31 16) cut!36940) ?x12808)))
(and (distinct ?x11536 cut!36940) true))))
(check-sat)
