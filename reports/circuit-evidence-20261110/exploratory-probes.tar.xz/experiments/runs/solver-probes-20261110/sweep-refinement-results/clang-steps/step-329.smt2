; 
(set-info :status unknown)
(declare-fun cut!41552 () (_ BitVec 32))
(declare-fun cut!41495 () (_ BitVec 10))
(declare-fun cut!41500 () (_ BitVec 16))
(declare-fun cut!41536 () (_ BitVec 10))
(declare-fun cut!41537 () (_ BitVec 6))
(assert
 (let ((?x15534 (bvadd (bvmul (_ bv1025 16) (concat cut!41537 cut!41536)) (bvmul (_ bv1025 16) cut!41500) (concat (_ bv0 6) cut!41495))))
(let ((?x11174 (concat ((_ extract 31 16) cut!41552) ?x15534)))
(and (distinct ?x11174 cut!41552) true))))
(check-sat)
