; 
(set-info :status unknown)
(declare-fun cut!42982 () (_ BitVec 32))
(declare-fun cut!43038 () (_ BitVec 3))
(declare-fun cut!42993 () (_ BitVec 10))
(declare-fun cut!42992 () (_ BitVec 6))
(assert
 (let ((?x11049 (bvadd (bvmul (_ bv9 16) (concat cut!42992 cut!42993)) (concat (_ bv0 13) cut!43038))))
(let ((?x2193 (concat ((_ extract 31 16) cut!42982) ?x11049)))
(and (distinct ?x2193 cut!42982) true))))
(check-sat)
