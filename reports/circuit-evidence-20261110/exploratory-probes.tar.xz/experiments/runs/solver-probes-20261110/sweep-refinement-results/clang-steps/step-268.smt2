; 
(set-info :status unknown)
(declare-fun cut!33859 () (_ BitVec 32))
(declare-fun cut!33832 () (_ BitVec 10))
(declare-fun cut!33850 () (_ BitVec 6))
(declare-fun cut!33856 () (_ BitVec 10))
(declare-fun cut!33865 () (_ BitVec 6))
(declare-fun cut!33834 () (_ BitVec 32))
(assert
 (let ((?x976 (bvadd cut!33834 (concat cut!33865 cut!33856 cut!33850 cut!33832))))
(let ((?x3529 (concat ((_ extract 31 16) cut!33859) ((_ extract 31 16) ?x976))))
(and (distinct ?x3529 cut!33859) true))))
(check-sat)
