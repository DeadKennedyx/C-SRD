; 
(set-info :status unknown)
(declare-fun input_1_high () (_ BitVec 16))
(declare-fun input_1_low () (_ BitVec 16))
(assert
 (let ((?x201 (concat (_ bv0 16) input_1_high)))
(let ((?x203 (bvmul (_ bv65536 32) ?x201)))
(let ((?x869 ((_ extract 16 16) ?x203)))
(let ((?x823 ((_ extract 0 0) input_1_low)))
(and (distinct ?x823 ?x869) true))))))
(check-sat)
