; 
(set-info :status unknown)
(declare-fun cut!37184 () (_ BitVec 32))
(declare-fun cut!37167 () (_ BitVec 10))
(declare-fun cut!37151 () (_ BitVec 6))
(declare-fun cut!37102 () (_ BitVec 8))
(assert
 (let ((?x3744 ((_ extract 31 16) cut!37184)))
(let ((?x13074 ((_ extract 15 6) (bvadd (concat (_ bv0 8) cut!37102) (concat cut!37151 cut!37167)))))
(let ((?x2869 ((_ extract 31 16) (bvadd (concat (_ bv0 22) ?x13074) cut!37184))))
(and (distinct ?x2869 ?x3744) true)))))
(check-sat)
