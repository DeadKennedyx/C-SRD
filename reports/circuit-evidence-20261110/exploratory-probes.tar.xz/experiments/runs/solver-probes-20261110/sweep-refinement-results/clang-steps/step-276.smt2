; 
(set-info :status unknown)
(declare-fun cut!34506 () (_ BitVec 32))
(declare-fun cut!34523 () (_ BitVec 10))
(declare-fun cut!34514 () (_ BitVec 16))
(declare-fun cut!34510 () (_ BitVec 10))
(declare-fun cut!34521 () (_ BitVec 6))
(assert
 (let ((?x1493 (bvadd (bvmul (_ bv1025 16) (concat cut!34521 cut!34510)) (bvmul (_ bv1025 16) cut!34514) (concat (_ bv0 6) cut!34523))))
(let ((?x10860 (concat ((_ extract 31 16) cut!34506) ?x1493)))
(and (distinct ?x10860 cut!34506) true))))
(check-sat)
