; 
(set-info :status unknown)
(declare-fun cut!40976 () (_ BitVec 32))
(declare-fun cut!40995 () (_ BitVec 16))
(declare-fun cut!40953 () (_ BitVec 10))
(declare-fun cut!40912 () (_ BitVec 6))
(assert
 (let ((?x2244 (bvadd (bvmul (_ bv1025 16) (concat cut!40912 cut!40953)) (bvmul (_ bv1025 16) cut!40995))))
(let ((?x11616 (concat ((_ extract 31 16) cut!40976) ?x2244)))
(and (distinct ?x11616 cut!40976) true))))
(check-sat)
