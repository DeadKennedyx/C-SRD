; 
(set-info :status unknown)
(declare-fun cut!10192 () (_ BitVec 16))
(assert
 (let ((?x2824 (bvmul (_ bv1024 16) cut!10192)))
(and (distinct ?x2824 cut!10192) true)))
(check-sat)
