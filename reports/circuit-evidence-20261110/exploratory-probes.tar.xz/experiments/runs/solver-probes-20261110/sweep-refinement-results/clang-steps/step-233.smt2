; 
(set-info :status unknown)
(declare-fun cut!30865 () (_ BitVec 1))
(declare-fun cut!30851 () (_ BitVec 10))
(declare-fun cut!30840 () (_ BitVec 3))
(assert
 (let ((?x13326 (bvmul (_ bv32768 32) (concat (_ bv0 31) cut!30865))))
(let ((?x1011 (concat ((_ extract 31 16) (bvmul (_ bv8 32) (concat (_ bv0 19) cut!30840 cut!30851))) (bvmul (_ bv32768 16) (concat (_ bv0 15) cut!30865)))))
(and (distinct ?x1011 ?x13326) true))))
(check-sat)
