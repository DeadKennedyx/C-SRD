; 
(set-info :status unknown)
(declare-fun cut!32627 () (_ BitVec 32))
(declare-fun cut!32619 () (_ BitVec 16))
(declare-fun input_0_low () (_ BitVec 16))
(declare-fun cut!32618 () (_ BitVec 16))
(assert
 (let ((?x1692 ((_ extract 31 16) cut!32627)))
(let ((?x2949 (concat (_ bv0 16) ((_ extract 15 10) (bvadd (bvmul (_ bv1024 16) input_0_low) (bvmul (_ bv1024 16) cut!32619))) (_ bv0 10))))
(let ((?x2189 (bvadd (concat (_ bv0 16) ((_ extract 31 16) (bvadd (concat (_ bv0 16) cut!32618) ?x2949))) cut!32627)))
(let ((?x13236 ((_ extract 31 16) ?x2189)))
(and (distinct ?x13236 ?x1692) true))))))
(check-sat)
