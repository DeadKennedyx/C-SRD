; 
(set-info :status unknown)
(declare-fun cut!32259 () (_ BitVec 32))
(declare-fun cut!32255 () (_ BitVec 8))
(declare-fun input_0_low () (_ BitVec 16))
(assert
 (let ((?x2208 ((_ extract 31 16) cut!32259)))
(let ((?x2976 (bvadd (concat (_ bv0 22) ((_ extract 15 6) (bvadd input_0_low (concat (_ bv0 8) cut!32255)))) cut!32259)))
(let ((?x3789 ((_ extract 31 16) ?x2976)))
(and (distinct ?x3789 ?x2208) true)))))
(check-sat)
