; 
(set-info :status unknown)
(declare-fun cut!36077 () (_ BitVec 10))
(declare-fun cut!36071 () (_ BitVec 6))
(declare-fun cut!36058 () (_ BitVec 10))
(declare-fun cut!36052 () (_ BitVec 6))
(declare-fun cut!36051 () (_ BitVec 32))
(assert
 (let ((?x5628 (bvadd cut!36051 (concat cut!36052 cut!36058 cut!36071 cut!36077))))
(let ((?x10685 ((_ extract 31 16) ?x5628)))
(let ((?x2375 (bvadd ((_ extract 31 16) (bvadd cut!36051 (concat (_ bv0 16) cut!36071 cut!36077))) (concat cut!36052 cut!36058))))
(and (distinct ?x2375 ?x10685) true)))))
(check-sat)
