; 
(set-info :status unknown)
(declare-fun cut!16819 () (_ BitVec 16))
(assert
 (let ((?x13163 (bvmul (_ bv1024 16) cut!16819)))
(let ((?x13325 (bvmul (_ bv1025 16) cut!16819)))
(and (distinct ?x13325 ?x13163) true))))
(check-sat)
