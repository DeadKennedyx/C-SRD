; 
(set-info :status unknown)
(declare-fun cut!34343 () (_ BitVec 32))
(declare-fun cut!34325 () (_ BitVec 10))
(declare-fun cut!34358 () (_ BitVec 6))
(declare-fun cut!34328 () (_ BitVec 8))
(assert
 (let ((?x5629 ((_ extract 31 16) cut!34343)))
(let ((?x10468 ((_ extract 15 6) (bvadd (concat (_ bv0 8) cut!34328) (concat cut!34358 cut!34325)))))
(let ((?x11117 ((_ extract 31 16) (bvadd (concat (_ bv0 22) ?x10468) cut!34343))))
(and (distinct ?x11117 ?x5629) true)))))
(check-sat)
