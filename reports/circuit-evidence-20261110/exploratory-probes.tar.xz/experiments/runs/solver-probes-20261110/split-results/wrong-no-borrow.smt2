; 
(set-info :status unknown)
(declare-fun x () (_ BitVec 32))
(declare-fun y () (_ BitVec 32))
(assert
 (let ((?x22 ((_ extract 15 0) x)))
(let ((?x27 ((_ extract 15 0) y)))
(let (($x29 (bvule ?x27 ?x22)))
(not $x29)))))
(check-sat)
