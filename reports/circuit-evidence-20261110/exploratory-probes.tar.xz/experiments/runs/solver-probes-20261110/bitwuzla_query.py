import bitwuzla
import importlib.metadata
import json
from pathlib import Path
import sys

options=bitwuzla.Options()
options.set(bitwuzla.Option.TIME_LIMIT_PER,5000)
options.set(bitwuzla.Option.PRODUCE_MODELS,True)
manager=bitwuzla.TermManager()
parser=bitwuzla.Parser(manager,options)
parser.parse(str(Path(sys.argv[1]).resolve()),parse_only=True)
solver=parser.bitwuzla()
assert len(solver.get_assertions())==1
answer=solver.check_sat()
result={'version':importlib.metadata.version('bitwuzla'),'status':str(answer),
        'assertions':len(solver.get_assertions()),'statistics':solver.statistics()}
if answer==bitwuzla.Result.SAT:
    result['model']={str(t):str(solver.get_value(t)) for t in parser.get_declared_funs()}
print(json.dumps(result))
