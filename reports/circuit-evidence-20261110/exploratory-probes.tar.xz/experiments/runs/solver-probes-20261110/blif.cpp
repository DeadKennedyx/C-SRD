// Exploratory exact Boolean export of a single SMT mismatch query.
#include <z3++.h>
#include <fstream>
#include <iostream>
#include <map>
#include <set>
#include <stdexcept>
#include <vector>
struct Export {
  std::set<unsigned> seen;
  std::vector<z3::expr> nodes,inputs;
  std::map<unsigned,std::string> names;
  void collect(const z3::expr &e){
    if(!seen.insert(e.id()).second)return;
    if(!e.is_app()||!e.is_bool())throw std::runtime_error("not a Boolean DAG");
    for(unsigned i=0;i<e.num_args();++i)collect(e.arg(i));
    if(e.is_const()&&!e.is_true()&&!e.is_false())inputs.push_back(e);else nodes.push_back(e);
    names.emplace(e.id(),"n"+std::to_string(e.id()));
  }
  void write(const z3::expr &root,std::ostream &out){
    collect(root);out<<".model query\n.inputs";for(auto &e:inputs)out<<' '<<names.at(e.id());out<<"\n.outputs output\n";
    for(auto &e:nodes){
      auto kind=e.decl().decl_kind();unsigned n=e.num_args();
      out<<".names";for(unsigned i=0;i<n;++i)out<<' '<<names.at(e.arg(i).id());out<<' '<<names.at(e.id())<<'\n';
      switch(kind){
        case Z3_OP_TRUE:out<<"1\n";break;
        case Z3_OP_FALSE:break;
        case Z3_OP_NOT:if(n!=1)throw std::runtime_error("not arity");out<<"0 1\n";break;
        case Z3_OP_AND:out<<std::string(n,'1')<<" 1\n";break;
        case Z3_OP_OR:for(unsigned i=0;i<n;++i){std::string pattern(n,'-');pattern[i]='1';out<<pattern<<" 1\n";}break;
        case Z3_OP_XOR:if(n!=2)throw std::runtime_error("xor arity");out<<"01 1\n10 1\n";break;
        case Z3_OP_EQ:if(n!=2)throw std::runtime_error("eq arity");out<<"00 1\n11 1\n";break;
        case Z3_OP_ITE:if(n!=3)throw std::runtime_error("ite arity");out<<"11- 1\n0-1 1\n";break;
        default:throw std::runtime_error("unsupported Boolean op "+e.decl().name().str());
      }
    }
    out<<".names "<<names.at(root.id())<<" output\n1 1\n.end\n";
    if(!out)throw std::runtime_error("output failure");
  }
};
int main(int argc,char**argv){
  try{
    if(argc!=3)throw std::runtime_error("input.smt2 output.blif required");
    z3::context c;auto input=c.parse_file(argv[1]);if(input.size()!=1)throw std::runtime_error("one assertion required");
    z3::goal g(c);g.add(input[0]);z3::params p(c);p.set("som",true);
    auto tactic=z3::with(z3::tactic(c,"simplify"),p)&z3::tactic(c,"bit-blast");auto result=tactic(g);
    if(result.size()!=1)throw std::runtime_error("one subgoal required");
    auto root=c.bool_val(true);for(unsigned i=0;i<result[0].size();++i)root=root&&result[0][i];
    std::ofstream out(argv[2]);Export e;e.write(root,out);
    z3::expr_vector from(c),to(c);for(auto &v:e.inputs){from.push_back(v);to.push_back(c.bool_const(e.names.at(v.id()).c_str()));}root=root.substitute(from,to);
    z3::solver s(c);s.add(root);std::ofstream smt(std::string(argv[2])+".smt2");smt<<s.to_smt2();
    std::cout<<e.inputs.size()<<" inputs "<<e.nodes.size()<<" gates\n";
  }catch(const std::exception &e){std::cerr<<e.what()<<'\n';return 1;}
}
