// Separate parser for the restricted BLIF actually written by the exporter.
#include <z3++.h>
#include <fstream>
#include <iostream>
#include <map>
#include <sstream>
#include <stdexcept>
#include <vector>
std::vector<std::string> words(const std::string &line){
  std::istringstream in(line);std::vector<std::string> v;std::string s;while(in>>s)v.push_back(s);return v;
}
z3::expr parse(z3::context &c,const std::string &path){
  std::ifstream in(path);if(!in)throw std::runtime_error("missing BLIF");
  std::map<std::string,z3::expr> values;std::vector<std::string> args;
  std::string line,output,pending;auto table=c.bool_val(false);
  bool model=false,inputs=false,outputs=false,ended=false;
  auto finish=[&](){if(!pending.empty()){if(!values.emplace(pending,table).second)throw std::runtime_error("duplicate wire");pending.clear();}};
  while(std::getline(in,line)){
    auto v=words(line);if(v.empty())continue;
    if(ended)throw std::runtime_error("trailing data");
    if(v[0][0]=='.'){
      finish();
      if(v[0]==".model"){
        if(model||v.size()!=2)throw std::runtime_error("model header");model=true;
      }else if(v[0]==".inputs"){
        if(!model||inputs||outputs)throw std::runtime_error("inputs header");inputs=true;
        for(unsigned i=1;i<v.size();++i)if(!values.emplace(v[i],c.bool_const(v[i].c_str())).second)throw std::runtime_error("duplicate input");
      }else if(v[0]==".outputs"){
        if(!inputs||outputs||v.size()!=2)throw std::runtime_error("one output required");outputs=true;output=v[1];
      }else if(v[0]==".names"){
        if(!outputs||v.size()<2)throw std::runtime_error("names header");
        pending=v.back();if(values.count(pending))throw std::runtime_error("multiple drivers");
        args.assign(v.begin()+1,v.end()-1);for(auto &s:args)if(!values.count(s))throw std::runtime_error("forward or missing wire");table=c.bool_val(false);
      }else if(v[0]==".end"){
        if(!outputs||v.size()!=1)throw std::runtime_error("end header");ended=true;
      }else throw std::runtime_error("unsupported directive");
    }else{
      if(pending.empty())throw std::runtime_error("row outside table");
      if(args.empty()){
        if(v.size()!=1||v[0]!="1")throw std::runtime_error("constant row");table=c.bool_val(true);
      }else{
        if(v.size()!=2||v[1]!="1"||v[0].size()!=args.size())throw std::runtime_error("cube row");
        auto cube=c.bool_val(true);
        for(unsigned i=0;i<args.size();++i){
          auto bit=v[0][i];if(bit=='1')cube=cube&&values.at(args[i]);else if(bit=='0')cube=cube&&!values.at(args[i]);else if(bit!='-')throw std::runtime_error("cube symbol");
        }
        table=table||cube;
      }
    }
  }
  if(!ended||!values.count(output))throw std::runtime_error("incomplete network");return values.at(output);
}
int main(int argc,char **argv){
  try{
    if(argc!=4)throw std::runtime_error("boolean.smt2 query.blif proof.smt2 required");
    z3::context c;auto a=c.parse_file(argv[1]);if(a.size()!=1)throw std::runtime_error("one assertion required");auto b=parse(c,argv[2]);
    auto s=(z3::tactic(c,"simplify")&z3::tactic(c,"sat")).mk_solver();s.set("timeout",5000u);s.add(a[0]!=b);
    std::ofstream out(argv[3]);out<<s.to_smt2();out.close();auto answer=s.check();std::cout<<answer<<'\n';return answer==z3::unsat?0:2;
  }catch(const std::exception &e){std::cerr<<e.what()<<'\n';return 1;}
}
