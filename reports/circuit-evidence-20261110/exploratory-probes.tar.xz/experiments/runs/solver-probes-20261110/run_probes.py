from pathlib import Path
import hashlib
import json
import shutil
import subprocess
import sys

sys.path.insert(0,str(Path('tools').resolve()))
from effort_resources import measure,save,environment
from verify_limbs import obligations

root=Path(__file__).resolve().parent
out=root/'results'
out.mkdir(exist_ok=False)
z3=shutil.which('z3')
python=root/'venv/bin/python'
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
tactics={
    'default':None,
    'qfbv':'qfbv',
    'aig':'(then (using-params simplify :som true) bit-blast aig sat)',
    'slices':'(then simplify bv-slice simplify bit-blast sat)',
    'sharing':'(then (using-params simplify :som true :mul2concat true :bv_extract_prop true) solve-eqs reduce-bv-size max-bv-sharing bit-blast sat)',
    'context':'(then (using-params simplify :som true) ctx-solver-simplify bit-blast sat)',
}
cases=[]
for trial,profile in [('00008','clang'),('00010','gcc')]:
    p=Path('experiments/runs/jenkins-composition-ghidra-linux-20261110')/('trial-'+trial)/'grade/proof.json'
    report=json.loads(p.read_text())
    text='(set-logic QF_BV)\n'+report['functions'][0]['proof']['smtlib']
    cases.append({'name':profile,'text':text,'expected':None,'original_proof_sha256':sha(p),
                  'reference_sha256':report['source_sha256'],'candidate_sha256':report['candidate_sha256']})
for name,actual,expected,status in obligations():
    if name not in ('subtract','scale-partial-products','wrong-no-borrow'): continue
    text='(set-logic QF_BV)\n'+''.join(f'(declare-const {x} (_ BitVec 32))\n' for x in ('x','y','k'))
    text+=f'(assert (not (= {actual} {expected})))\n(check-sat)\n'
    cases.append({'name':name,'text':text,'expected':status})
for case in cases:
    p=out/(case['name']+'.smt2'); p.write_text(case.pop('text'))
    case['query']=str(p);case['sha256']=sha(p)
version=subprocess.check_output([z3,'-version'],text=True).strip()
module=subprocess.check_output([python,'-c','import bitwuzla;print(bitwuzla.__file__)'],text=True).strip()
protocol={'scope':'native development-only solver probes; no source/assertion changes',
          'environment':environment(),'solver_ms':5000,'process_wall_seconds':8,
          'z3':{'version':version,'path':z3,'sha256':sha(z3)},
          'bitwuzla':{'version':'0.9.1','module_sha256':sha(module)},'tactics':tactics,'cases':cases,
          'driver_sha256':sha(__file__),'bitwuzla_driver_sha256':sha(root/'bitwuzla_query.py')}
save(out/'protocol.json',protocol)
rows=[]
for case in cases:
    for backend in [*tactics,'bitwuzla']:
        name=case['name']+'-'+backend
        query=Path(case['query'])
        if backend!='bitwuzla':
            text=query.read_text()
            tactic=tactics[backend]
            if tactic: text=text.replace('(check-sat)',f'(check-sat-using {tactic})')
            text='(set-option :timeout 5000)\n'+text
            query=out/(name+'.smt2');query.write_text(text)
            argv=[z3,'-smt2',query]
        else: argv=[python,root/'bitwuzla_query.py',query]
        directory=out/name
        resources=measure(argv,directory,wall_seconds=8)
        stdout=(directory/'stdout.txt').read_text().strip()
        if resources['status']!='completed': status=resources['status']
        elif backend=='bitwuzla': status=json.loads(stdout)['status']
        else: status=stdout if stdout in ('sat','unsat','unknown') else 'invalid-response'
        row={'case':case['name'],'backend':backend,'status':status,'expected':case['expected'],
             'query_sha256':sha(query),'resources':resources}
        rows.append(row);save(out/'summary.json',rows)
        print(name,status,round(resources['wall_seconds'],3),flush=True)
        if case['expected'] and status in ('sat','unsat') and status!=case['expected']:
            raise RuntimeError('known contract contradicted; do not trust backend')
print('COMPLETE',flush=True)
