#include <stdint.h>
#include <stdlib.h>
#include <limits.h>
_Static_assert(sizeof(int)==4, "32-bit int ABI required");
extern uint32_t next_value(uint32_t);
extern void record_event(uint32_t);
uint32_t region_pipeline(uint32_t *p0,uint32_t p1,int32_t p2){
    unsigned steps=0, incoming=0;
    (void)p0;(void)p1;(void)p2;(void)incoming;
    uint64_t v0=0; (void)v0;
    uint64_t v3=0; (void)v3;
    uint64_t v5=0; (void)v5;
    uint64_t v7=0; (void)v7;
    uint64_t v10=0; (void)v10;
    uint64_t v13=0; (void)v13;
    uint64_t v15=0; (void)v15;
    uint64_t v17=0; (void)v17;
    uint64_t v19=0; (void)v19;
    uint64_t v21=0; (void)v21;
    uint64_t v24=0; (void)v24;
    uint64_t v26=0; (void)v26;
    uint64_t v27=0; (void)v27;
    uint64_t v16=0; (void)v16;
    uint64_t v18=0; (void)v18;
    uint64_t v33=0; (void)v33;
    uint64_t v35=0; (void)v35;
    uint64_t v37=0; (void)v37;
    uint64_t v38=0; (void)v38;
    uint64_t phi15=0;
    uint64_t phi17=0;
    uint64_t phi37=0;
    goto b0;
b0:
    if(++steps>10000u)exit(71);
    v0=(p0[0]) & UINT64_C(4294967295);
    v3=((((uint64_t)(uint32_t)p1) + v0)) & UINT64_C(4294967295);
    v5=((v3 * UINT64_C(3))) & UINT64_C(4294967295);
    v7=((v5 + UINT64_C(11))) & UINT64_C(4294967295);
    record_event((uint32_t)(v7));
    v10=(((((uint64_t)(uint32_t)p2) ^ UINT64_C(2147483648)) < (UINT64_C(0) ^ UINT64_C(2147483648)))) & UINT64_C(255);
    v13=(((uint64_t)(uint32_t)p2)) & UINT64_C(4294967295);
    if(v10){incoming=0;goto b4;}else{incoming=1;goto b1;}
b1:
    if(++steps>10000u)exit(71);
    switch(incoming){
    case 0:phi15=v16;break;
    case 1:phi15=v7;break;
    default:exit(72);}
    switch(incoming){
    case 0:phi17=v18;break;
    case 1:phi17=v13;break;
    default:exit(72);}
    v15=phi15;
    v17=phi17;
    v19=((v17 + UINT64_C(4294967295))) & UINT64_C(4294967295);
    v21=(((UINT64_C(0) ^ UINT64_C(2147483648)) < (v17 ^ UINT64_C(2147483648)))) & UINT64_C(255);
    if(v21){incoming=0;goto b2;}else{incoming=0;goto b3;}
b2:
    if(++steps>10000u)exit(71);
    v24=(next_value((uint32_t)(v15))) & UINT64_C(4294967295);
    v26=((v15 + v24)) & UINT64_C(4294967295);
    v27=((v26 * UINT64_C(5))) & UINT64_C(4294967295);
    v16=((v27 - UINT64_C(7))) & UINT64_C(4294967295);
    p0[0]=(uint32_t)(v16);
    record_event((uint32_t)(v24));
    v18=(v19) & UINT64_C(4294967295);
    incoming=0;goto b1;
b3:
    if(++steps>10000u)exit(71);
    v33=(v15) & UINT64_C(4294967295);
    incoming=1;goto b5;
b4:
    if(++steps>10000u)exit(71);
    v35=(v7) & UINT64_C(4294967295);
    incoming=0;goto b5;
b5:
    if(++steps>10000u)exit(71);
    switch(incoming){
    case 0:phi37=v35;break;
    case 1:phi37=v33;break;
    default:exit(72);}
    v37=phi37;
    v38=(v37) & UINT64_C(4294967295);
    return (uint32_t)(v38);
}
