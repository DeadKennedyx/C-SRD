
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

uint region_pipeline(uint *p0,uint p1,int p2)

{
  uint value;
  int local_28;
  uint local_24;
  uint local_14;
  
  local_24 = (p1 + *p0) * 3 + 0xb;
  record_event(local_24);
  local_28 = p2;
  if (p2 < 0) {
    local_14 = local_24;
  }
  else {
    while (0 < local_28) {
      value = next_value(local_24);
      local_24 = (local_24 + value) * 5 - 7;
      *p0 = local_24;
      record_event(value);
      local_28 = local_28 + -1;
    }
    local_14 = local_24;
  }
  return local_14;
}

