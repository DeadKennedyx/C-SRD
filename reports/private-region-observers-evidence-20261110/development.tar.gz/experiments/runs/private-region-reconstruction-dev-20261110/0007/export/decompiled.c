
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

uint region_pipeline(uint *p0,uint p1,int p2)

{
  int iVar1;
  int iVar2;
  uint value;
  uint value_00;
  uint value_01;
  int iVar3;
  
  iVar1 = *p0 * 0x487e86a1 + 0x72f86ab4;
  iVar2 = iVar1 + p1 * 0x487e86a1;
  iVar3 = iVar2 * 3 + 0x377ef383;
  value = iVar2 * 0x3c16dd61 + 0xa04a2dcc;
  value_01 = (iVar3 - iVar1) * 0x3c16dd61;
  record_event(value);
  if (0 < p2) {
    iVar3 = iVar3 * 0x3c16dd61 + -0x5fb5d234;
    do {
      value_00 = next_value(value_01);
      iVar1 = value_00 * -0x7db1611 + -0x3c766687;
      iVar3 = iVar1 * 5 + -0xe2665e4 + iVar3 * -0x7db1611;
      iVar2 = iVar3 * 0x4a25650f;
      iVar3 = (((value * -0x7db1611 + -0x78eccd0e) - iVar1) + iVar3) * 0x4a25650f + 0x31cc89d2;
      record_event(iVar2 + 0x18e644e9);
      *p0 = iVar2 + 0x18e644f0;
      value_01 = ((value_01 * -0x7db1611 + -0x3c766687 + iVar1) * -0x65db867b + 0x73a3b5b4 +
                 iVar3 * 0x95b802b) * 0x32e93e83 + 0xd630f6b6;
      record_event(value_00);
      p2 = p2 + -1;
    } while (p2 != 0);
  }
  return value_01;
}

