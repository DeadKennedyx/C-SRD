#include <stdint.h>
#include <stdlib.h>
#include <limits.h>
_Static_assert(sizeof(int)==4, "32-bit int ABI required");
extern uint32_t next_value(uint32_t);
extern void record_event(uint32_t);
uint32_t region_pipeline(uint32_t *p0,uint32_t p1,int32_t p2){
    unsigned steps=0, incoming=0;
    (void)p0;(void)p1;(void)p2;(void)incoming;
    uint64_t v0=0; (void)v0;
    uint64_t v3=0; (void)v3;
    uint64_t v5=0; (void)v5;
    uint64_t v7=0; (void)v7;
    uint64_t v10=0; (void)v10;
    uint64_t v11=0; (void)v11;
    uint64_t v13=0; (void)v13;
    uint64_t v15=0; (void)v15;
    uint64_t v17=0; (void)v17;
    uint64_t v19=0; (void)v19;
    uint64_t v20=0; (void)v20;
    uint64_t v23=0; (void)v23;
    uint64_t v27=0; (void)v27;
    uint64_t v29=0; (void)v29;
    uint64_t v31=0; (void)v31;
    uint64_t v33=0; (void)v33;
    uint64_t v35=0; (void)v35;
    uint64_t v37=0; (void)v37;
    uint64_t v39=0; (void)v39;
    uint64_t v41=0; (void)v41;
    uint64_t v43=0; (void)v43;
    uint64_t v45=0; (void)v45;
    uint64_t v47=0; (void)v47;
    uint64_t v49=0; (void)v49;
    uint64_t v51=0; (void)v51;
    uint64_t v52=0; (void)v52;
    uint64_t v53=0; (void)v53;
    uint64_t v55=0; (void)v55;
    uint64_t v57=0; (void)v57;
    uint64_t v59=0; (void)v59;
    uint64_t v60=0; (void)v60;
    uint64_t v61=0; (void)v61;
    uint64_t v63=0; (void)v63;
    uint64_t v36=0; (void)v36;
    uint64_t v66=0; (void)v66;
    uint64_t v69=0; (void)v69;
    uint64_t v71=0; (void)v71;
    uint64_t v73=0; (void)v73;
    uint64_t v75=0; (void)v75;
    uint64_t v76=0; (void)v76;
    uint64_t v79=0; (void)v79;
    uint64_t v40=0; (void)v40;
    uint64_t v38=0; (void)v38;
    uint64_t v84=0; (void)v84;
    uint64_t v87=0; (void)v87;
    uint64_t v88=0; (void)v88;
    uint64_t phi35=0;
    uint64_t phi37=0;
    uint64_t phi39=0;
    uint64_t phi87=0;
    goto b0;
b0:
    if(++steps>10000u)exit(71);
    v0=(p0[0]) & UINT64_C(4294967295);
    v3=((v0 * UINT64_C(1216251553))) & UINT64_C(4294967295);
    v5=((v3 + UINT64_C(1928882868))) & UINT64_C(4294967295);
    v7=((((uint64_t)(uint32_t)p1) * UINT64_C(1216251553))) & UINT64_C(4294967295);
    v10=((v5 + v7)) & UINT64_C(4294967295);
    v11=((v10 * UINT64_C(3))) & UINT64_C(4294967295);
    v13=((v11 + UINT64_C(931066755))) & UINT64_C(4294967295);
    v15=((v10 * UINT64_C(1008131425))) & UINT64_C(4294967295);
    v17=((v15 + UINT64_C(2689215948))) & UINT64_C(4294967295);
    v19=((v13 - v5)) & UINT64_C(4294967295);
    v20=((v19 * UINT64_C(1008131425))) & UINT64_C(4294967295);
    record_event((uint32_t)(v17));
    v23=(((UINT64_C(0) ^ UINT64_C(2147483648)) < (((uint64_t)(uint32_t)p2) ^ UINT64_C(2147483648)))) & UINT64_C(255);
    if(v23){incoming=0;goto b1;}else{incoming=0;goto b3;}
b1:
    if(++steps>10000u)exit(71);
    v27=((v13 * UINT64_C(1008131425))) & UINT64_C(4294967295);
    v29=((v27 + UINT64_C(2689215948))) & UINT64_C(4294967295);
    v31=((v17 * UINT64_C(4163168751))) & UINT64_C(4294967295);
    v33=((v31 + UINT64_C(2266182386))) & UINT64_C(4294967295);
    incoming=0;goto b2;
b2:
    if(++steps>10000u)exit(71);
    switch(incoming){
    case 0:phi35=v29;break;
    case 1:phi35=v36;break;
    default:exit(72);}
    switch(incoming){
    case 0:phi37=((uint64_t)(uint32_t)p2);break;
    case 1:phi37=v38;break;
    default:exit(72);}
    switch(incoming){
    case 0:phi39=v20;break;
    case 1:phi39=v40;break;
    default:exit(72);}
    v35=phi35;
    v37=phi37;
    v39=phi39;
    v41=(next_value((uint32_t)(v39))) & UINT64_C(4294967295);
    v43=((v41 * UINT64_C(4163168751))) & UINT64_C(4294967295);
    v45=((v43 + UINT64_C(3280574841))) & UINT64_C(4294967295);
    v47=((v39 * UINT64_C(4163168751))) & UINT64_C(4294967295);
    v49=((v47 + UINT64_C(3280574841))) & UINT64_C(4294967295);
    v51=((v33 - v45)) & UINT64_C(4294967295);
    v52=((v49 + v45)) & UINT64_C(4294967295);
    v53=((v45 * UINT64_C(5))) & UINT64_C(4294967295);
    v55=((v53 + UINT64_C(4057569820))) & UINT64_C(4294967295);
    v57=((v35 * UINT64_C(4163168751))) & UINT64_C(4294967295);
    v59=((v55 + v57)) & UINT64_C(4294967295);
    v60=((v51 + v59)) & UINT64_C(4294967295);
    v61=((v59 * UINT64_C(1243964687))) & UINT64_C(4294967295);
    v63=((v60 * UINT64_C(1243964687))) & UINT64_C(4294967295);
    v36=((v63 + UINT64_C(835488210))) & UINT64_C(4294967295);
    v66=((v61 + UINT64_C(417744105))) & UINT64_C(4294967295);
    record_event((uint32_t)(v66));
    v69=((v52 * UINT64_C(2586081669))) & UINT64_C(4294967295);
    v71=((v69 + UINT64_C(1940108724))) & UINT64_C(4294967295);
    v73=((v36 * UINT64_C(156991531))) & UINT64_C(4294967295);
    v75=((v71 + v73)) & UINT64_C(4294967295);
    v76=((v61 + UINT64_C(417744112))) & UINT64_C(4294967295);
    p0[0]=(uint32_t)(v76);
    v79=((v75 * UINT64_C(854146691))) & UINT64_C(4294967295);
    v40=((v79 + UINT64_C(3593533110))) & UINT64_C(4294967295);
    record_event((uint32_t)(v41));
    v38=((v37 + UINT64_C(4294967295))) & UINT64_C(4294967295);
    v84=((v38 != UINT64_C(0))) & UINT64_C(255);
    if(v84){incoming=1;goto b2;}else{incoming=1;goto b3;}
b3:
    if(++steps>10000u)exit(71);
    switch(incoming){
    case 0:phi87=v20;break;
    case 1:phi87=v40;break;
    default:exit(72);}
    v87=phi87;
    v88=(v87) & UINT64_C(4294967295);
    return (uint32_t)(v88);
}
