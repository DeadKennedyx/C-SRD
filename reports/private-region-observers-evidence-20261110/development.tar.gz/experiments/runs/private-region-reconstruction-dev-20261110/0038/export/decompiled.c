
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

uint region_pipeline(uint *p0,uint p1,int p2)

{
  uint uVar1;
  int iVar2;
  uint value;
  uint value_00;
  int iVar3;
  uint uVar4;
  
  uVar1 = *p0;
  iVar3 = uVar1 * -0xda0dc39 + p1 * -0xda0dc39 + 0x3d0da4f5;
  value_00 = (iVar3 * 3 + uVar1 * 0xda0dc39) * 0xec1adf7 + 0x55f5d3e2;
  record_event(uVar1 + p1);
  if (0 < p2) {
    iVar3 = iVar3 * 0x6c4d73e9 + -0x7e4eaf36;
    uVar4 = p2 + 1;
    do {
      value = next_value(value_00);
      iVar3 = iVar3 + value * 0x14dd9889 + 0x3357fd48;
      iVar2 = iVar3 * 0x2188d49d;
      iVar3 = (uVar1 + p1) * 0x42c51b5 + value * -0x42c51b5 + -0x3357fd48 + iVar3;
      record_event(iVar2 + 0xcf0a0ad8);
      value_00 = ((value + value_00) * -0x1a0dfb95 + iVar3 * -0x6b12ae61) * 0x11f08843;
      *p0 = iVar2 + 0xcf0a0adf;
      record_event(value);
      uVar4 = uVar4 - 1;
    } while (1 < uVar4);
  }
  return value_00;
}

