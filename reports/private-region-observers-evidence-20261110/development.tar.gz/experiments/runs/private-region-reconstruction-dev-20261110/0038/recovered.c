#include <stdint.h>
#include <stdlib.h>
#include <limits.h>
_Static_assert(sizeof(int)==4, "32-bit int ABI required");
extern uint32_t next_value(uint32_t);
extern void record_event(uint32_t);
uint32_t region_pipeline(uint32_t *p0,uint32_t p1,int32_t p2){
    unsigned steps=0, incoming=0;
    (void)p0;(void)p1;(void)p2;(void)incoming;
    uint64_t v0=0; (void)v0;
    uint64_t v3=0; (void)v3;
    uint64_t v5=0; (void)v5;
    uint64_t v7=0; (void)v7;
    uint64_t v9=0; (void)v9;
    uint64_t v10=0; (void)v10;
    uint64_t v12=0; (void)v12;
    uint64_t v14=0; (void)v14;
    uint64_t v16=0; (void)v16;
    uint64_t v17=0; (void)v17;
    uint64_t v19=0; (void)v19;
    uint64_t v22=0; (void)v22;
    uint64_t v26=0; (void)v26;
    uint64_t v28=0; (void)v28;
    uint64_t v30=0; (void)v30;
    uint64_t v32=0; (void)v32;
    uint64_t v34=0; (void)v34;
    uint64_t v36=0; (void)v36;
    uint64_t v38=0; (void)v38;
    uint64_t v40=0; (void)v40;
    uint64_t v42=0; (void)v42;
    uint64_t v44=0; (void)v44;
    uint64_t v45=0; (void)v45;
    uint64_t v47=0; (void)v47;
    uint64_t v48=0; (void)v48;
    uint64_t v49=0; (void)v49;
    uint64_t v51=0; (void)v51;
    uint64_t v53=0; (void)v53;
    uint64_t v55=0; (void)v55;
    uint64_t v37=0; (void)v37;
    uint64_t v58=0; (void)v58;
    uint64_t v60=0; (void)v60;
    uint64_t v62=0; (void)v62;
    uint64_t v39=0; (void)v39;
    uint64_t v64=0; (void)v64;
    uint64_t v35=0; (void)v35;
    uint64_t v69=0; (void)v69;
    uint64_t v72=0; (void)v72;
    uint64_t v73=0; (void)v73;
    uint64_t phi34=0;
    uint64_t phi36=0;
    uint64_t phi38=0;
    uint64_t phi72=0;
    goto b0;
b0:
    if(++steps>10000u)exit(71);
    v0=(p0[0]) & UINT64_C(4294967295);
    v3=((v0 * UINT64_C(4066321351))) & UINT64_C(4294967295);
    v5=((v0 + ((uint64_t)(uint32_t)p1))) & UINT64_C(4294967295);
    v7=((((uint64_t)(uint32_t)p1) * UINT64_C(4066321351))) & UINT64_C(4294967295);
    v9=((v3 + v7)) & UINT64_C(4294967295);
    v10=((v9 + UINT64_C(1024304373))) & UINT64_C(4294967295);
    v12=((v10 * UINT64_C(3))) & UINT64_C(4294967295);
    v14=((v0 * UINT64_C(228645945))) & UINT64_C(4294967295);
    v16=((v12 + v14)) & UINT64_C(4294967295);
    v17=((v16 * UINT64_C(247574007))) & UINT64_C(4294967295);
    v19=((v17 + UINT64_C(1442173922))) & UINT64_C(4294967295);
    record_event((uint32_t)(v5));
    v22=(((UINT64_C(0) ^ UINT64_C(2147483648)) < (((uint64_t)(uint32_t)p2) ^ UINT64_C(2147483648)))) & UINT64_C(255);
    if(v22){incoming=0;goto b1;}else{incoming=0;goto b3;}
b1:
    if(++steps>10000u)exit(71);
    v26=((v5 * UINT64_C(70013365))) & UINT64_C(4294967295);
    v28=((v10 * UINT64_C(1817015273))) & UINT64_C(4294967295);
    v30=((v28 + UINT64_C(2175881418))) & UINT64_C(4294967295);
    v32=((((uint64_t)(uint32_t)p2) + UINT64_C(1))) & UINT64_C(4294967295);
    incoming=0;goto b2;
b2:
    if(++steps>10000u)exit(71);
    switch(incoming){
    case 0:phi34=v32;break;
    case 1:phi34=v35;break;
    default:exit(72);}
    switch(incoming){
    case 0:phi36=v30;break;
    case 1:phi36=v37;break;
    default:exit(72);}
    switch(incoming){
    case 0:phi38=v19;break;
    case 1:phi38=v39;break;
    default:exit(72);}
    v34=phi34;
    v36=phi36;
    v38=phi38;
    v40=(next_value((uint32_t)(v38))) & UINT64_C(4294967295);
    v42=((v40 * UINT64_C(350066825))) & UINT64_C(4294967295);
    v44=((v36 + v42)) & UINT64_C(4294967295);
    v45=((v40 * UINT64_C(4224953931))) & UINT64_C(4294967295);
    v47=((v26 + v45)) & UINT64_C(4294967295);
    v48=((v40 + v38)) & UINT64_C(4294967295);
    v49=((v44 + UINT64_C(861404488))) & UINT64_C(4294967295);
    v51=((v49 * UINT64_C(562615453))) & UINT64_C(4294967295);
    v53=((v51 + UINT64_C(3473541848))) & UINT64_C(4294967295);
    v55=((v47 + UINT64_C(3433562808))) & UINT64_C(4294967295);
    v37=((v55 + v49)) & UINT64_C(4294967295);
    record_event((uint32_t)(v53));
    v58=((v48 * UINT64_C(3857843307))) & UINT64_C(4294967295);
    v60=((v37 * UINT64_C(2498580895))) & UINT64_C(4294967295);
    v62=((v58 + v60)) & UINT64_C(4294967295);
    v39=((v62 * UINT64_C(300976195))) & UINT64_C(4294967295);
    v64=((v51 + UINT64_C(3473541855))) & UINT64_C(4294967295);
    p0[0]=(uint32_t)(v64);
    record_event((uint32_t)(v40));
    v35=((v34 - UINT64_C(1))) & UINT64_C(4294967295);
    v69=((UINT64_C(1) < v35)) & UINT64_C(255);
    if(v69){incoming=1;goto b2;}else{incoming=1;goto b3;}
b3:
    if(++steps>10000u)exit(71);
    switch(incoming){
    case 0:phi72=v19;break;
    case 1:phi72=v39;break;
    default:exit(72);}
    v72=phi72;
    v73=(v72) & UINT64_C(4294967295);
    return (uint32_t)(v73);
}
