
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

uint region_pipeline(uint *p0,uint p1,int p2)

{
  uint value;
  int local_28;
  uint local_24;
  uint local_14;
  
  local_24 = ((p1 * -0xda0dc39 + *p0 * -0xda0dc39 + 0x3d0da4f5) * 3 + -0x4d126552) * 0xec1adf7;
  record_event(local_24);
  local_28 = p2;
  if (p2 < 0) {
    local_14 = local_24;
  }
  else {
    while (0 < local_28) {
      value = next_value(local_24);
      local_24 = ((local_24 * 0x48aaf01d + 0x67e9eefa + value * 0x48aaf01d) * 5 + -0x43e3bad) *
                 0xa0f5235;
      *p0 = local_24;
      record_event(value);
      local_28 = local_28 + -1;
    }
    local_14 = local_24;
  }
  return local_14;
}

