#include <stdint.h>
#include <stdlib.h>
#include <limits.h>
_Static_assert(sizeof(int)==4, "32-bit int ABI required");
extern uint32_t next_value(uint32_t);
extern void record_event(uint32_t);
uint32_t region_pipeline(uint32_t *p0,uint32_t p1,int32_t p2){
    unsigned steps=0, incoming=0;
    (void)p0;(void)p1;(void)p2;(void)incoming;
    uint64_t v0=0; (void)v0;
    uint64_t v3=0; (void)v3;
    uint64_t v6=0; (void)v6;
    uint64_t v8=0; (void)v8;
    uint64_t v10=0; (void)v10;
    uint64_t v11=0; (void)v11;
    uint64_t v13=0; (void)v13;
    uint64_t v15=0; (void)v15;
    uint64_t v18=0; (void)v18;
    uint64_t v21=0; (void)v21;
    uint64_t v23=0; (void)v23;
    uint64_t v25=0; (void)v25;
    uint64_t v27=0; (void)v27;
    uint64_t v29=0; (void)v29;
    uint64_t v32=0; (void)v32;
    uint64_t v34=0; (void)v34;
    uint64_t v36=0; (void)v36;
    uint64_t v38=0; (void)v38;
    uint64_t v40=0; (void)v40;
    uint64_t v41=0; (void)v41;
    uint64_t v43=0; (void)v43;
    uint64_t v24=0; (void)v24;
    uint64_t v26=0; (void)v26;
    uint64_t v49=0; (void)v49;
    uint64_t v51=0; (void)v51;
    uint64_t v53=0; (void)v53;
    uint64_t v54=0; (void)v54;
    uint64_t phi23=0;
    uint64_t phi25=0;
    uint64_t phi53=0;
    goto b0;
b0:
    if(++steps>10000u)exit(71);
    v0=(p0[0]) & UINT64_C(4294967295);
    v3=((((uint64_t)(uint32_t)p1) * UINT64_C(4066321351))) & UINT64_C(4294967295);
    v6=((v0 * UINT64_C(4066321351))) & UINT64_C(4294967295);
    v8=((v6 + UINT64_C(1024304373))) & UINT64_C(4294967295);
    v10=((v3 + v8)) & UINT64_C(4294967295);
    v11=((v10 * UINT64_C(3))) & UINT64_C(4294967295);
    v13=((v11 + UINT64_C(3001916078))) & UINT64_C(4294967295);
    v15=((v13 * UINT64_C(247574007))) & UINT64_C(4294967295);
    record_event((uint32_t)(v15));
    v18=(((((uint64_t)(uint32_t)p2) ^ UINT64_C(2147483648)) < (UINT64_C(0) ^ UINT64_C(2147483648)))) & UINT64_C(255);
    v21=(((uint64_t)(uint32_t)p2)) & UINT64_C(4294967295);
    if(v18){incoming=0;goto b4;}else{incoming=1;goto b1;}
b1:
    if(++steps>10000u)exit(71);
    switch(incoming){
    case 0:phi23=v24;break;
    case 1:phi23=v15;break;
    default:exit(72);}
    switch(incoming){
    case 0:phi25=v26;break;
    case 1:phi25=v21;break;
    default:exit(72);}
    v23=phi23;
    v25=phi25;
    v27=((v25 + UINT64_C(4294967295))) & UINT64_C(4294967295);
    v29=(((UINT64_C(0) ^ UINT64_C(2147483648)) < (v25 ^ UINT64_C(2147483648)))) & UINT64_C(255);
    if(v29){incoming=0;goto b2;}else{incoming=0;goto b3;}
b2:
    if(++steps>10000u)exit(71);
    v32=(next_value((uint32_t)(v23))) & UINT64_C(4294967295);
    v34=((v23 * UINT64_C(1219162141))) & UINT64_C(4294967295);
    v36=((v34 + UINT64_C(1743384314))) & UINT64_C(4294967295);
    v38=((v32 * UINT64_C(1219162141))) & UINT64_C(4294967295);
    v40=((v36 + v38)) & UINT64_C(4294967295);
    v41=((v40 * UINT64_C(5))) & UINT64_C(4294967295);
    v43=((v41 + UINT64_C(4223779923))) & UINT64_C(4294967295);
    v24=((v43 * UINT64_C(168776245))) & UINT64_C(4294967295);
    p0[0]=(uint32_t)(v24);
    record_event((uint32_t)(v32));
    v26=(v27) & UINT64_C(4294967295);
    incoming=0;goto b1;
b3:
    if(++steps>10000u)exit(71);
    v49=(v23) & UINT64_C(4294967295);
    incoming=1;goto b5;
b4:
    if(++steps>10000u)exit(71);
    v51=(v15) & UINT64_C(4294967295);
    incoming=0;goto b5;
b5:
    if(++steps>10000u)exit(71);
    switch(incoming){
    case 0:phi53=v51;break;
    case 1:phi53=v49;break;
    default:exit(72);}
    v53=phi53;
    v54=(v53) & UINT64_C(4294967295);
    return (uint32_t)(v54);
}
