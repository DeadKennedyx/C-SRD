#include <stdint.h>
#include <stdlib.h>
#include <limits.h>
_Static_assert(sizeof(int)==4, "32-bit int ABI required");
extern uint32_t next_value(uint32_t);
extern void record_event(uint32_t);
int32_t region_outputs(uint32_t *p0,uint32_t p1,uint32_t p2){
    unsigned steps=0, incoming=0;
    (void)p0;(void)p1;(void)p2;(void)incoming;
    uint64_t v0=0; (void)v0;
    uint64_t v3=0; (void)v3;
    uint64_t v6=0; (void)v6;
    uint64_t v8=0; (void)v8;
    uint64_t v10=0; (void)v10;
    uint64_t v12=0; (void)v12;
    uint64_t v13=0; (void)v13;
    uint64_t v15=0; (void)v15;
    uint64_t v17=0; (void)v17;
    uint64_t v19=0; (void)v19;
    uint64_t v22=0; (void)v22;
    uint64_t v24=0; (void)v24;
    uint64_t v26=0; (void)v26;
    uint64_t v39=0; (void)v39;
    uint64_t v40=0; (void)v40;
    goto b0;
b0:
    if(++steps>10000u)exit(71);
    v0=((((uint64_t)(uint32_t)p1) * UINT64_C(2124566435))) & UINT64_C(4294967295);
    v3=((((uint64_t)(uint32_t)p2) * UINT64_C(2124566435))) & UINT64_C(4294967295);
    v6=((v3 + UINT64_C(3852111484))) & UINT64_C(4294967295);
    v8=((v0 + UINT64_C(1315035215))) & UINT64_C(4294967295);
    v10=((v8 * UINT64_C(3))) & UINT64_C(4294967295);
    v12=((v10 + v6)) & UINT64_C(4294967295);
    v13=((v12 + UINT64_C(1771423248))) & UINT64_C(4294967295);
    v15=((v13 * UINT64_C(3799538699))) & UINT64_C(4294967295);
    v17=((v12 + UINT64_C(13532221))) & UINT64_C(4294967295);
    v19=((v17 * UINT64_C(3799538699))) & UINT64_C(4294967295);
    record_event((uint32_t)(v15));
    v22=((v13 * UINT64_C(3030673565))) & UINT64_C(4294967295);
    v24=((v22 + UINT64_C(2553768129))) & UINT64_C(4294967295);
    v26=((v24 * UINT64_C(2609910471))) & UINT64_C(4294967295);
    p0[2]=(uint32_t)(v26);
    p0[0]=(uint32_t)(v19);
    p0[1]=(uint32_t)(UINT64_C(17));
    v39=((v15 == v19)) & UINT64_C(255);
    v40=(v39) & UINT64_C(4294967295);
    {uint32_t r=(uint32_t)(v40);
    return r<=INT32_MAX?(int32_t)r:INT32_MIN+(int32_t)(r-UINT32_C(2147483648));}
}
