
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int region_outputs(uint *p0,uint p1,uint p2)

{
  int iVar1;
  uint value;
  uint uVar2;
  int iVar3;
  
  iVar1 = (p1 * 0x7ea24fa3 + 0x4e61d84f) * 3 + p2 * 0x7ea24fa3 + -0x1a657184;
  iVar3 = iVar1 + 0x6995c610;
  value = iVar3 * -0x1d87a3f5;
  uVar2 = (iVar1 + 0xce7c3d) * -0x1d87a3f5;
  record_event(value);
  p0[2] = (iVar3 * -0x4b5b9763 + -0x67c8973f) * -0x646fed39;
  *p0 = uVar2;
  p0[1] = 0x11;
  return (int)(value == uVar2);
}

