#include <stdint.h>
#include <stdlib.h>
#include <limits.h>
_Static_assert(sizeof(int)==4, "32-bit int ABI required");
extern uint32_t next_value(uint32_t);
extern void record_event(uint32_t);
int32_t region_outputs(uint32_t *p0,uint32_t p1,uint32_t p2){
    unsigned steps=0, incoming=0;
    (void)p0;(void)p1;(void)p2;(void)incoming;
    uint64_t v0=0; (void)v0;
    uint64_t v3=0; (void)v3;
    uint64_t v6=0; (void)v6;
    uint64_t v8=0; (void)v8;
    uint64_t v10=0; (void)v10;
    uint64_t v12=0; (void)v12;
    uint64_t v13=0; (void)v13;
    uint64_t v15=0; (void)v15;
    uint64_t v16=0; (void)v16;
    uint64_t v18=0; (void)v18;
    uint64_t v20=0; (void)v20;
    uint64_t v22=0; (void)v22;
    uint64_t v24=0; (void)v24;
    uint64_t v33=0; (void)v33;
    uint64_t v34=0; (void)v34;
    goto b0;
b0:
    if(++steps>10000u)exit(71);
    v0=((((uint64_t)(uint32_t)p1) * UINT64_C(954633191))) & UINT64_C(4294967295);
    v3=((((uint64_t)(uint32_t)p2) * UINT64_C(954633191))) & UINT64_C(4294967295);
    v6=((v3 + UINT64_C(4036438798))) & UINT64_C(4294967295);
    v8=((v0 + UINT64_C(3085333861))) & UINT64_C(4294967295);
    v10=((v8 * UINT64_C(3))) & UINT64_C(4294967295);
    v12=((v10 + v6)) & UINT64_C(4294967295);
    v13=((v12 + UINT64_C(775585494))) & UINT64_C(4294967295);
    v15=((v13 - v8)) & UINT64_C(4294967295);
    v16=((v0 + UINT64_C(3343862359))) & UINT64_C(4294967295);
    v18=((v16 * UINT64_C(3655555031))) & UINT64_C(4294967295);
    v20=((v12 + UINT64_C(1034113992))) & UINT64_C(4294967295);
    v22=((v20 * UINT64_C(3655555031))) & UINT64_C(4294967295);
    v24=((v15 * UINT64_C(3655555031))) & UINT64_C(4294967295);
    record_event((uint32_t)(v22));
    p0[0]=(uint32_t)(v24);
    p0[1]=(uint32_t)(v18);
    v33=((v22 == v24)) & UINT64_C(255);
    v34=(v33) & UINT64_C(4294967295);
    {uint32_t r=(uint32_t)(v34);
    return r<=INT32_MAX?(int32_t)r:INT32_MIN+(int32_t)(r-UINT32_C(2147483648));}
}
