
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int region_outputs(uint *p0,uint p1,uint p2)

{
  int iVar1;
  uint value;
  uint uVar2;
  int iVar3;
  
  iVar3 = p1 * 0x38e68be7 + -0x48198a9b;
  iVar1 = iVar3 * 3 + p2 * 0x38e68be7 + -0xf68d4f2;
  value = (iVar1 + 0x3da353c8) * -0x261ca829;
  uVar2 = ((iVar1 + 0x2e3a7ed6) - iVar3) * -0x261ca829;
  record_event(value);
  *p0 = uVar2;
  p0[1] = (p1 * 0x38e68be7 + -0x38b0b5a9) * -0x261ca829;
  return (int)(value == uVar2);
}

