#include <stdint.h>
#include <stdlib.h>
#include <limits.h>
_Static_assert(sizeof(int)==4, "32-bit int ABI required");
extern uint32_t next_value(uint32_t);
extern void record_event(uint32_t);
int32_t region_outputs(uint32_t *p0,uint32_t p1,uint32_t p2){
    unsigned steps=0, incoming=0;
    (void)p0;(void)p1;(void)p2;(void)incoming;
    uint64_t v0=0; (void)v0;
    uint64_t v3=0; (void)v3;
    uint64_t v6=0; (void)v6;
    uint64_t v7=0; (void)v7;
    uint64_t v9=0; (void)v9;
    uint64_t v11=0; (void)v11;
    uint64_t v13=0; (void)v13;
    uint64_t v14=0; (void)v14;
    uint64_t v16=0; (void)v16;
    uint64_t v18=0; (void)v18;
    uint64_t v20=0; (void)v20;
    uint64_t v23=0; (void)v23;
    uint64_t v30=0; (void)v30;
    goto b0;
b0:
    if(++steps>10000u)exit(71);
    v0=((((uint64_t)(uint32_t)p2) * UINT64_C(954633191))) & UINT64_C(4294967295);
    v3=((((uint64_t)(uint32_t)p1) * UINT64_C(2863899573))) & UINT64_C(4294967295);
    v6=((v0 + v3)) & UINT64_C(4294967295);
    v7=((((uint64_t)(uint32_t)p1) + UINT64_C(17))) & UINT64_C(4294967295);
    v9=((v6 + UINT64_C(666066991))) & UINT64_C(4294967295);
    v11=((((uint64_t)(uint32_t)p1) * UINT64_C(3340334105))) & UINT64_C(4294967295);
    v13=((v9 + v11)) & UINT64_C(4294967295);
    v14=((v9 * UINT64_C(3655555031))) & UINT64_C(4294967295);
    v16=((v14 + UINT64_C(2449293242))) & UINT64_C(4294967295);
    v18=((v13 * UINT64_C(3655555031))) & UINT64_C(4294967295);
    v20=((v18 + UINT64_C(2449293225))) & UINT64_C(4294967295);
    record_event((uint32_t)(v16));
    v23=((v16 == v20)) & UINT64_C(255);
    p0[0]=(uint32_t)(v20);
    p0[1]=(uint32_t)(v7);
    v30=(v23) & UINT64_C(4294967295);
    {uint32_t r=(uint32_t)(v30);
    return r<=INT32_MAX?(int32_t)r:INT32_MIN+(int32_t)(r-UINT32_C(2147483648));}
}
