
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int region_outputs(uint *p0,uint p1,uint p2)

{
  int iVar1;
  uint value;
  uint uVar2;
  
  iVar1 = p2 * 0x38e68be7 + p1 * -0x554c5c4b + 0x27b3602f;
  value = iVar1 * -0x261ca829 + 0x91fd3fba;
  uVar2 = (iVar1 + p1 * -0x38e68be7) * -0x261ca829 + 0x91fd3fa9;
  record_event(value);
  *p0 = uVar2;
  p0[1] = p1 + 0x11;
  return (int)(value == uVar2);
}

