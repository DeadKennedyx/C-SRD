#define _POSIX_C_SOURCE 200809L
#include <stdint.h>
#include <stdio.h>
#include <inttypes.h>
#include <stdlib.h>
#include <time.h>
#include <sys/resource.h>
uint32_t region_pipeline(uint32_t*,uint32_t,int);
int region_outputs(uint32_t*,uint32_t,uint32_t);
static uint32_t memory[3],events[128],count;
void record_event(uint32_t value){if(count>=128u)exit(70);events[count++]=value;}
uint32_t next_value(uint32_t value){record_event(value);memory[1]+=value;return value+memory[1];}
static uint32_t next(uint32_t *s){*s^=*s<<13;*s^=*s>>17;*s^=*s<<5;return *s;}
static double elapsed(struct timespec a,struct timespec b){return (double)(b.tv_sec-a.tv_sec)+(double)(b.tv_nsec-a.tv_nsec)*1e-9;}
int main(int argc,char **argv){
 if(argc!=3)return 2;
 unsigned long n=strtoul(argv[1],0,10);uint32_t state=(uint32_t)strtoul(argv[2],0,10);uint64_t checksum=0;
 struct timespec a,b,c,d;
 if(clock_gettime(CLOCK_MONOTONIC,&a)||clock_gettime(CLOCK_PROCESS_CPUTIME_ID,&c))return 3;
 for(unsigned long i=0;i<n;++i){
  uint32_t x=next(&state),y=next(&state);memory[0]=next(&state);memory[1]=next(&state);memory[2]=next(&state);count=0;
  checksum+=(uint64_t)region_pipeline(memory,x,(i&1u)?2:0);
  checksum+=(uint32_t)region_outputs(memory,x,y);
  for(uint32_t j=0;j<count;++j)checksum=checksum*33u^events[j];
  for(unsigned j=0;j<3;++j)checksum=checksum*33u^memory[j];
 }
 if(clock_gettime(CLOCK_MONOTONIC,&b)||clock_gettime(CLOCK_PROCESS_CPUTIME_ID,&d))return 3;
 struct rusage usage;if(getrusage(RUSAGE_SELF,&usage))return 3;
 printf("%.9f %.9f %lu %" PRIu64 "\n",elapsed(a,b),elapsed(c,d),(unsigned long)usage.ru_maxrss*1024ul,checksum);
 return 0;
}
