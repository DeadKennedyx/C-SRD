
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

uint region_pipeline(uint *p0,uint p1,int p2)

{
  uint value;
  int local_20;
  uint local_1c;
  
  local_1c = (p1 + *p0) * 3 + 0xb;
  record_event(local_1c);
  local_20 = p2;
  if (-1 < p2) {
    for (; 0 < local_20; local_20 = local_20 + -1) {
      value = next_value(local_1c);
      local_1c = (local_1c + value) * 5 - 7;
      *p0 = local_1c;
      record_event(value);
    }
  }
  return local_1c;
}

