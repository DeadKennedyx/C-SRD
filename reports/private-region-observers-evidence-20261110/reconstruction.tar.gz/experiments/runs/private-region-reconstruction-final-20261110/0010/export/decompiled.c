
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

uint region_pipeline(uint *p0,uint p1,int p2)

{
  uint value;
  uint value_00;
  uint value_01;
  uint value_02;
  int iVar1;
  
  value = *p0 + p1;
  iVar1 = value * 3 + 0xb;
  value_02 = iVar1 - *p0;
  record_event(value);
  if (0 < p2) {
    do {
      value_01 = next_value(value_02);
      value_00 = value_01 * 5 + iVar1;
      iVar1 = (value - value_01) + value_00;
      record_event(value_00);
      *p0 = value_00 + 7;
      value_02 = value_01 + value_02 + iVar1;
      record_event(value_01);
      p2 = p2 + -1;
    } while (p2 != 0);
  }
  return value_02;
}

