
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int region_outputs(uint *p0,uint p1,uint p2)

{
  int iVar1;
  int iVar2;
  uint value;
  uint uVar3;
  
  iVar1 = p1 * 0x5604bc0f + 0x1006f2dd;
  iVar2 = iVar1 * 3 + p2 * 0x5604bc0f + 0x4c931444;
  value = iVar2 * 0x20eb2ef + 0x328f99be;
  uVar3 = ((iVar2 - iVar1) + 0x59b675de) * 0x20eb2ef + 0x328f99be;
  record_event(value);
  *p0 = uVar3;
  p0[1] = iVar1 * 0x20eb2ef + 0x328f99be;
  return (uint)(value == uVar3);
}

