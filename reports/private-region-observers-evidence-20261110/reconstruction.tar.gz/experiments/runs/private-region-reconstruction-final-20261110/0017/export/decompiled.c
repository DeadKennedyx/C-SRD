
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

uint region_pipeline(uint *p0,uint p1,int p2)

{
  uint value;
  uint value_00;
  uint value_01;
  uint value_02;
  int iVar1;
  uint uVar2;
  
  value = *p0 + p1;
  iVar1 = value * 3 + 0xb;
  value_02 = iVar1 - *p0;
  record_event(value);
  if (0 < p2) {
    uVar2 = p2 + 1;
    do {
      value_01 = next_value(value_02);
      value_00 = value_01 * 5 + iVar1;
      iVar1 = (value_00 - value_01) + value;
      record_event(value_00);
      value_02 = value_01 + value_02 + iVar1;
      *p0 = value_00 + 7;
      record_event(value_01);
      uVar2 = uVar2 - 1;
    } while (1 < uVar2);
  }
  return value_02;
}

