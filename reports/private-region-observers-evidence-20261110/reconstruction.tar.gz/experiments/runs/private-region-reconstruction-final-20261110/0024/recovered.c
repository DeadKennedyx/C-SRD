#include <stdint.h>
#include <stdlib.h>
#include <limits.h>
_Static_assert(sizeof(int)==4, "32-bit int ABI required");
extern uint32_t next_value(uint32_t);
extern void record_event(uint32_t);
int32_t region_outputs(uint32_t *p0,uint32_t p1,uint32_t p2){
    unsigned steps=0, incoming=0;
    (void)p0;(void)p1;(void)p2;(void)incoming;
    uint64_t v0=0; (void)v0;
    uint64_t v3=0; (void)v3;
    uint64_t v5=0; (void)v5;
    uint64_t v8=0; (void)v8;
    uint64_t v9=0; (void)v9;
    uint64_t v11=0; (void)v11;
    uint64_t v14=0; (void)v14;
    uint64_t v16=0; (void)v16;
    uint64_t v29=0; (void)v29;
    goto b0;
b0:
    if(++steps>10000u)exit(71);
    v0=((((uint64_t)(uint32_t)p2) * UINT64_C(2622762737))) & UINT64_C(4294967295);
    v3=((v0 + UINT64_C(1662417987))) & UINT64_C(4294967295);
    v5=((((uint64_t)(uint32_t)p1) * UINT64_C(3573320915))) & UINT64_C(4294967295);
    v8=((v3 + v5)) & UINT64_C(4294967295);
    v9=((v8 * UINT64_C(1824195089))) & UINT64_C(4294967295);
    v11=((v9 + UINT64_C(899168704))) & UINT64_C(4294967295);
    record_event((uint32_t)(v11));
    v14=((v9 + UINT64_C(899168711))) & UINT64_C(4294967295);
    v16=((v9 + UINT64_C(899168687))) & UINT64_C(4294967295);
    p0[0]=(uint32_t)(v16);
    p0[1]=(uint32_t)(UINT64_C(17));
    p0[2]=(uint32_t)(v14);
    v29=(UINT64_C(0)) & UINT64_C(4294967295);
    {uint32_t r=(uint32_t)(v29);
    return r<=INT32_MAX?(int32_t)r:INT32_MIN+(int32_t)(r-UINT32_C(2147483648));}
}
