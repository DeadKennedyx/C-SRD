
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int region_outputs(uint *p0,uint p1,uint p2)

{
  int iVar1;
  
  iVar1 = (p2 * -0x63abd10f + 0x63167c43 + p1 * -0x2b03732d) * 0x6cbb0211;
  record_event(iVar1 + 0x359839c0);
  *p0 = iVar1 + 0x359839af;
  p0[1] = 0x11;
  p0[2] = iVar1 + 0x359839c7;
  return 0;
}

