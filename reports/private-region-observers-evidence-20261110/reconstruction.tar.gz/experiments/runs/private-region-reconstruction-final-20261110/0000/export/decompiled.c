
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int region_outputs(uint *p0,uint p1,uint p2)

{
  uint uVar1;
  uint value;
  
  uVar1 = p1 + 0x11;
  value = p2 + uVar1 * 3;
  record_event(value);
  *p0 = value - uVar1;
  p0[1] = uVar1;
  return (uint)(value == value - uVar1);
}

