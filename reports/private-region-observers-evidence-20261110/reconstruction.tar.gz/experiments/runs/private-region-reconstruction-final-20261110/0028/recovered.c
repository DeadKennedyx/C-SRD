#include <stdint.h>
#include <stdlib.h>
#include <limits.h>
_Static_assert(sizeof(int)==4, "32-bit int ABI required");
extern uint32_t next_value(uint32_t);
extern void record_event(uint32_t);
int32_t region_outputs(uint32_t *p0,uint32_t p1,uint32_t p2){
    unsigned steps=0, incoming=0;
    (void)p0;(void)p1;(void)p2;(void)incoming;
    uint64_t v0=0; (void)v0;
    uint64_t v3=0; (void)v3;
    uint64_t v5=0; (void)v5;
    uint64_t v8=0; (void)v8;
    uint64_t v10=0; (void)v10;
    uint64_t v12=0; (void)v12;
    uint64_t v13=0; (void)v13;
    uint64_t v14=0; (void)v14;
    uint64_t v16=0; (void)v16;
    uint64_t v18=0; (void)v18;
    uint64_t v20=0; (void)v20;
    uint64_t v29=0; (void)v29;
    uint64_t v30=0; (void)v30;
    goto b0;
b0:
    if(++steps>10000u)exit(71);
    v0=((((uint64_t)(uint32_t)p1) * UINT64_C(1443150863))) & UINT64_C(4294967295);
    v3=((v0 + UINT64_C(268890845))) & UINT64_C(4294967295);
    v5=((((uint64_t)(uint32_t)p2) * UINT64_C(1443150863))) & UINT64_C(4294967295);
    v8=((v5 + UINT64_C(1284707396))) & UINT64_C(4294967295);
    v10=((v3 * UINT64_C(3))) & UINT64_C(4294967295);
    v12=((v8 + v10)) & UINT64_C(4294967295);
    v13=((v12 - v3)) & UINT64_C(4294967295);
    v14=((((uint64_t)(uint32_t)p1) + UINT64_C(17))) & UINT64_C(4294967295);
    v16=((v12 * UINT64_C(34517743))) & UINT64_C(4294967295);
    v18=((v16 + UINT64_C(848271806))) & UINT64_C(4294967295);
    v20=((v13 * UINT64_C(34517743))) & UINT64_C(4294967295);
    record_event((uint32_t)(v18));
    p0[0]=(uint32_t)(v20);
    p0[1]=(uint32_t)(v14);
    v29=((v20 == v18)) & UINT64_C(255);
    v30=(v29) & UINT64_C(4294967295);
    {uint32_t r=(uint32_t)(v30);
    return r<=INT32_MAX?(int32_t)r:INT32_MIN+(int32_t)(r-UINT32_C(2147483648));}
}
