
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int region_outputs(uint *p0,uint p1,uint p2)

{
  int iVar1;
  int iVar2;
  uint value;
  uint uVar3;
  
  iVar2 = p1 * 0x5604bc0f + 0x1006f2dd;
  iVar1 = p2 * 0x5604bc0f + 0x4c931444 + iVar2 * 3;
  value = iVar1 * 0x20eb2ef + 0x328f99be;
  uVar3 = (iVar1 - iVar2) * 0x20eb2ef;
  record_event(value);
  *p0 = uVar3;
  p0[1] = p1 + 0x11;
  return (int)(uVar3 == value);
}

