
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

uint region_pipeline(uint *p0,uint p1,int p2)

{
  uint value;
  int local_30;
  uint local_2c;
  
  local_2c = ((p1 * 0x487e86a1 + *p0 * 0x487e86a1 + 0x72f86ab4) * 3 + 0x377ef383) * 0x3c16dd61 +
             0xa04a2dcc;
  record_event(local_2c);
  local_30 = p2;
  if (-1 < p2) {
    for (; 0 < local_30; local_30 = local_30 + -1) {
      value = next_value(local_2c);
      local_2c = ((local_2c * -0x5ed0851d + value * -0x5ed0851d + 0x34e48acb) * 5 + -0x3bde8761) *
                 -0x2906535 + 0xc642d307;
      *p0 = local_2c;
      record_event(value);
    }
  }
  return local_2c;
}

