#include <stdint.h>
#include <stdlib.h>
#include <limits.h>
_Static_assert(sizeof(int)==4, "32-bit int ABI required");
extern uint32_t next_value(uint32_t);
extern void record_event(uint32_t);
uint32_t region_pipeline(uint32_t *p0,uint32_t p1,int32_t p2){
    unsigned steps=0, incoming=0;
    (void)p0;(void)p1;(void)p2;(void)incoming;
    uint64_t v0=0; (void)v0;
    uint64_t v3=0; (void)v3;
    uint64_t v6=0; (void)v6;
    uint64_t v8=0; (void)v8;
    uint64_t v9=0; (void)v9;
    uint64_t v11=0; (void)v11;
    uint64_t v13=0; (void)v13;
    uint64_t v15=0; (void)v15;
    uint64_t v17=0; (void)v17;
    uint64_t v20=0; (void)v20;
    uint64_t v23=0; (void)v23;
    uint64_t v24=0; (void)v24;
    uint64_t v26=0; (void)v26;
    uint64_t v28=0; (void)v28;
    uint64_t v30=0; (void)v30;
    uint64_t v32=0; (void)v32;
    uint64_t v35=0; (void)v35;
    uint64_t v37=0; (void)v37;
    uint64_t v39=0; (void)v39;
    uint64_t v41=0; (void)v41;
    uint64_t v42=0; (void)v42;
    uint64_t v44=0; (void)v44;
    uint64_t v46=0; (void)v46;
    uint64_t v48=0; (void)v48;
    uint64_t v27=0; (void)v27;
    uint64_t v29=0; (void)v29;
    uint64_t v53=0; (void)v53;
    uint64_t v54=0; (void)v54;
    uint64_t phi26=0;
    uint64_t phi28=0;
    uint64_t phi53=0;
    goto b0;
b0:
    if(++steps>10000u)exit(71);
    v0=(p0[0]) & UINT64_C(4294967295);
    v3=((((uint64_t)(uint32_t)p1) * UINT64_C(1216251553))) & UINT64_C(4294967295);
    v6=((v0 * UINT64_C(1216251553))) & UINT64_C(4294967295);
    v8=((v3 + v6)) & UINT64_C(4294967295);
    v9=((v8 + UINT64_C(1928882868))) & UINT64_C(4294967295);
    v11=((v9 * UINT64_C(3))) & UINT64_C(4294967295);
    v13=((v11 + UINT64_C(931066755))) & UINT64_C(4294967295);
    v15=((v13 * UINT64_C(1008131425))) & UINT64_C(4294967295);
    v17=((v15 + UINT64_C(2689215948))) & UINT64_C(4294967295);
    record_event((uint32_t)(v17));
    v20=(((UINT64_C(4294967295) ^ UINT64_C(2147483648)) < (((uint64_t)(uint32_t)p2) ^ UINT64_C(2147483648)))) & UINT64_C(255);
    v23=(((uint64_t)(uint32_t)p2)) & UINT64_C(4294967295);
    v24=(v23) & UINT64_C(4294967295);
    if(v20){incoming=0;goto b1;}else{incoming=1;goto b3;}
b1:
    if(++steps>10000u)exit(71);
    switch(incoming){
    case 0:phi26=v17;break;
    case 1:phi26=v27;break;
    default:exit(72);}
    switch(incoming){
    case 0:phi28=v24;break;
    case 1:phi28=v29;break;
    default:exit(72);}
    v26=phi26;
    v28=phi28;
    v30=((v28 + UINT64_C(4294967295))) & UINT64_C(4294967295);
    v32=(((UINT64_C(0) ^ UINT64_C(2147483648)) < (v28 ^ UINT64_C(2147483648)))) & UINT64_C(255);
    if(v32){incoming=0;goto b2;}else{incoming=0;goto b3;}
b2:
    if(++steps>10000u)exit(71);
    v35=(next_value((uint32_t)(v26))) & UINT64_C(4294967295);
    v37=((v26 * UINT64_C(2704243427))) & UINT64_C(4294967295);
    v39=((v35 * UINT64_C(2704243427))) & UINT64_C(4294967295);
    v41=((v37 + v39)) & UINT64_C(4294967295);
    v42=((v41 + UINT64_C(887392971))) & UINT64_C(4294967295);
    v44=((v42 * UINT64_C(5))) & UINT64_C(4294967295);
    v46=((v44 + UINT64_C(3290527903))) & UINT64_C(4294967295);
    v48=((v46 * UINT64_C(4251949771))) & UINT64_C(4294967295);
    v27=((v48 + UINT64_C(3326268167))) & UINT64_C(4294967295);
    p0[0]=(uint32_t)(v27);
    record_event((uint32_t)(v35));
    v29=(v30) & UINT64_C(4294967295);
    incoming=1;goto b1;
b3:
    if(++steps>10000u)exit(71);
    switch(incoming){
    case 0:phi53=v26;break;
    case 1:phi53=v17;break;
    default:exit(72);}
    v53=phi53;
    v54=(v53) & UINT64_C(4294967295);
    return (uint32_t)(v54);
}
