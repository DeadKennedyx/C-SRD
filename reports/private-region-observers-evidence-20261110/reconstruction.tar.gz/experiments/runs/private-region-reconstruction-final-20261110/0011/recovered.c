#include <stdint.h>
#include <stdlib.h>
#include <limits.h>
_Static_assert(sizeof(int)==4, "32-bit int ABI required");
extern uint32_t next_value(uint32_t);
extern void record_event(uint32_t);
uint32_t region_pipeline(uint32_t *p0,uint32_t p1,int32_t p2){
    unsigned steps=0, incoming=0;
    (void)p0;(void)p1;(void)p2;(void)incoming;
    uint64_t v0=0; (void)v0;
    uint64_t v3=0; (void)v3;
    uint64_t v6=0; (void)v6;
    uint64_t v8=0; (void)v8;
    uint64_t v10=0; (void)v10;
    uint64_t v11=0; (void)v11;
    uint64_t v13=0; (void)v13;
    uint64_t v15=0; (void)v15;
    uint64_t v16=0; (void)v16;
    uint64_t v18=0; (void)v18;
    uint64_t v20=0; (void)v20;
    uint64_t v22=0; (void)v22;
    uint64_t v24=0; (void)v24;
    uint64_t v26=0; (void)v26;
    uint64_t v28=0; (void)v28;
    uint64_t v31=0; (void)v31;
    uint64_t v34=0; (void)v34;
    uint64_t v35=0; (void)v35;
    uint64_t v37=0; (void)v37;
    uint64_t v39=0; (void)v39;
    uint64_t v41=0; (void)v41;
    uint64_t v43=0; (void)v43;
    uint64_t v45=0; (void)v45;
    uint64_t v48=0; (void)v48;
    uint64_t v50=0; (void)v50;
    uint64_t v52=0; (void)v52;
    uint64_t v54=0; (void)v54;
    uint64_t v56=0; (void)v56;
    uint64_t v58=0; (void)v58;
    uint64_t v60=0; (void)v60;
    uint64_t v61=0; (void)v61;
    uint64_t v63=0; (void)v63;
    uint64_t v64=0; (void)v64;
    uint64_t v66=0; (void)v66;
    uint64_t v67=0; (void)v67;
    uint64_t v69=0; (void)v69;
    uint64_t v70=0; (void)v70;
    uint64_t v72=0; (void)v72;
    uint64_t v74=0; (void)v74;
    uint64_t v38=0; (void)v38;
    uint64_t v77=0; (void)v77;
    uint64_t v79=0; (void)v79;
    uint64_t v82=0; (void)v82;
    uint64_t v84=0; (void)v84;
    uint64_t v86=0; (void)v86;
    uint64_t v88=0; (void)v88;
    uint64_t v91=0; (void)v91;
    uint64_t v93=0; (void)v93;
    uint64_t v95=0; (void)v95;
    uint64_t v96=0; (void)v96;
    uint64_t v98=0; (void)v98;
    uint64_t v40=0; (void)v40;
    uint64_t v42=0; (void)v42;
    uint64_t v102=0; (void)v102;
    uint64_t v103=0; (void)v103;
    uint64_t phi37=0;
    uint64_t phi39=0;
    uint64_t phi41=0;
    uint64_t phi102=0;
    goto b0;
b0:
    if(++steps>10000u)exit(71);
    v0=(p0[0]) & UINT64_C(4294967295);
    v3=((((uint64_t)(uint32_t)p1) * UINT64_C(1216251553))) & UINT64_C(4294967295);
    v6=((v0 * UINT64_C(1216251553))) & UINT64_C(4294967295);
    v8=((v6 + UINT64_C(1928882868))) & UINT64_C(4294967295);
    v10=((v3 + v8)) & UINT64_C(4294967295);
    v11=((v10 * UINT64_C(3))) & UINT64_C(4294967295);
    v13=((v11 + UINT64_C(931066755))) & UINT64_C(4294967295);
    v15=((v13 - v8)) & UINT64_C(4294967295);
    v16=((v15 + UINT64_C(1928882868))) & UINT64_C(4294967295);
    v18=((v16 * UINT64_C(1008131425))) & UINT64_C(4294967295);
    v20=((v18 + UINT64_C(2689215948))) & UINT64_C(4294967295);
    v22=((v10 * UINT64_C(1008131425))) & UINT64_C(4294967295);
    v24=((v22 + UINT64_C(2689215948))) & UINT64_C(4294967295);
    v26=((v13 * UINT64_C(1008131425))) & UINT64_C(4294967295);
    v28=((v26 + UINT64_C(2689215948))) & UINT64_C(4294967295);
    record_event((uint32_t)(v24));
    v31=(((UINT64_C(4294967295) ^ UINT64_C(2147483648)) < (((uint64_t)(uint32_t)p2) ^ UINT64_C(2147483648)))) & UINT64_C(255);
    v34=(((uint64_t)(uint32_t)p2)) & UINT64_C(4294967295);
    v35=(v34) & UINT64_C(4294967295);
    if(v31){incoming=0;goto b1;}else{incoming=1;goto b3;}
b1:
    if(++steps>10000u)exit(71);
    switch(incoming){
    case 0:phi37=v28;break;
    case 1:phi37=v38;break;
    default:exit(72);}
    switch(incoming){
    case 0:phi39=v20;break;
    case 1:phi39=v40;break;
    default:exit(72);}
    switch(incoming){
    case 0:phi41=v35;break;
    case 1:phi41=v42;break;
    default:exit(72);}
    v37=phi37;
    v39=phi39;
    v41=phi41;
    v43=((v41 + UINT64_C(4294967295))) & UINT64_C(4294967295);
    v45=(((UINT64_C(0) ^ UINT64_C(2147483648)) < (v41 ^ UINT64_C(2147483648)))) & UINT64_C(255);
    if(v45){incoming=0;goto b2;}else{incoming=0;goto b3;}
b2:
    if(++steps>10000u)exit(71);
    v48=(next_value((uint32_t)(v39))) & UINT64_C(4294967295);
    v50=((v39 * UINT64_C(4163168751))) & UINT64_C(4294967295);
    v52=((v48 * UINT64_C(4163168751))) & UINT64_C(4294967295);
    v54=((v52 + UINT64_C(3280574841))) & UINT64_C(4294967295);
    v56=((v37 * UINT64_C(4163168751))) & UINT64_C(4294967295);
    v58=((v24 * UINT64_C(4163168751))) & UINT64_C(4294967295);
    v60=((v50 + v54)) & UINT64_C(4294967295);
    v61=((v54 * UINT64_C(5))) & UINT64_C(4294967295);
    v63=((v61 + v56)) & UINT64_C(4294967295);
    v64=((v63 + UINT64_C(4057569820))) & UINT64_C(4294967295);
    v66=((v64 - v54)) & UINT64_C(4294967295);
    v67=((v66 + UINT64_C(3280574841))) & UINT64_C(4294967295);
    v69=((v67 + v58)) & UINT64_C(4294967295);
    v70=((v60 * UINT64_C(1243964687))) & UINT64_C(4294967295);
    v72=((v70 + UINT64_C(417744105))) & UINT64_C(4294967295);
    v74=((v69 * UINT64_C(1243964687))) & UINT64_C(4294967295);
    v38=((v74 + UINT64_C(417744105))) & UINT64_C(4294967295);
    v77=((v64 * UINT64_C(1243964687))) & UINT64_C(4294967295);
    v79=((v77 + UINT64_C(417744105))) & UINT64_C(4294967295);
    record_event((uint32_t)(v79));
    v82=((v79 * UINT64_C(1549162689))) & UINT64_C(4294967295);
    v84=((v82 + UINT64_C(2303051425))) & UINT64_C(4294967295);
    v86=((v84 * UINT64_C(2944546625))) & UINT64_C(4294967295);
    v88=((v86 + UINT64_C(987363878))) & UINT64_C(4294967295);
    p0[0]=(uint32_t)(v88);
    v91=((v72 * UINT64_C(156991531))) & UINT64_C(4294967295);
    v93=((v38 * UINT64_C(156991531))) & UINT64_C(4294967295);
    v95=((v91 + v93)) & UINT64_C(4294967295);
    v96=((v95 + UINT64_C(953993143))) & UINT64_C(4294967295);
    v98=((v96 * UINT64_C(854146691))) & UINT64_C(4294967295);
    v40=((v98 + UINT64_C(3944250203))) & UINT64_C(4294967295);
    record_event((uint32_t)(v48));
    v42=(v43) & UINT64_C(4294967295);
    incoming=1;goto b1;
b3:
    if(++steps>10000u)exit(71);
    switch(incoming){
    case 0:phi102=v39;break;
    case 1:phi102=v20;break;
    default:exit(72);}
    v102=phi102;
    v103=(v102) & UINT64_C(4294967295);
    return (uint32_t)(v103);
}
