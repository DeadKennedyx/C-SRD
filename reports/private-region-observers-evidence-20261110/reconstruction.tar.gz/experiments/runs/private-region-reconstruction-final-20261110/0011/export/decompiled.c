
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

uint region_pipeline(uint *p0,uint p1,int p2)

{
  int iVar1;
  int iVar2;
  int iVar3;
  uint value;
  uint value_00;
  uint value_01;
  int local_60;
  uint local_5c;
  int local_44;
  
  iVar1 = *p0 * 0x487e86a1 + 0x72f86ab4;
  iVar2 = p1 * 0x487e86a1 + iVar1;
  iVar3 = iVar2 * 3 + 0x377ef383;
  local_5c = ((iVar3 - iVar1) + 0x72f86ab4) * 0x3c16dd61 + 0xa04a2dcc;
  value = iVar2 * 0x3c16dd61 + 0xa04a2dcc;
  local_44 = iVar3 * 0x3c16dd61 + -0x5fb5d234;
  record_event(value);
  local_60 = p2;
  if (-1 < p2) {
    for (; 0 < local_60; local_60 = local_60 + -1) {
      value_01 = next_value(local_5c);
      iVar1 = value_01 * -0x7db1611 + -0x3c766687;
      iVar2 = iVar1 * 5 + local_44 * -0x7db1611 + -0xe2665e4;
      local_44 = ((iVar2 - iVar1) + -0x3c766687 + value * -0x7db1611) * 0x4a25650f + 0x18e644e9;
      value_00 = iVar2 * 0x4a25650f + 0x18e644e9;
      record_event(value_00);
      *p0 = (value_00 * 0x5c5658c1 + -0x76ba395f) * -0x507dc8bf + 0x3ad9fa26;
      local_5c = (((local_5c * -0x7db1611 + iVar1) * 0x4a25650f + 0x18e644e9) * 0x95b802b +
                  local_44 * 0x95b802b + 0x38dcc7b7) * 0x32e93e83 + 0xeb187b5b;
      record_event(value_01);
    }
  }
  return local_5c;
}

