
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

uint region_pipeline(uint *p0,uint p1,int p2)

{
  uint value;
  uint value_00;
  uint uVar1;
  
  value_00 = (*p0 + p1) * 3 + 0xb;
  record_event(value_00);
  if (0 < p2) {
    uVar1 = p2 + 1;
    do {
      value = next_value(value_00);
      value_00 = (value + value_00) * 5 - 7;
      *p0 = value_00;
      record_event(value);
      uVar1 = uVar1 - 1;
    } while (1 < uVar1);
  }
  return value_00;
}

