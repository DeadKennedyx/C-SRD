
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int region_outputs(uint *p0,uint p1,uint p2)

{
  uint value;
  
  value = (p1 + 0x11) * 3 + p2;
  record_event(value);
  p0[2] = value + 7;
  *p0 = value - 0x11;
  p0[1] = 0x11;
  return (int)(value == value - 0x11);
}

