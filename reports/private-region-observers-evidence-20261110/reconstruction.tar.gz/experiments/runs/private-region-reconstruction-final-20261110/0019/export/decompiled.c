
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

uint region_pipeline(uint *p0,uint p1,int p2)

{
  uint value;
  int local_30;
  uint local_2c;
  
  local_2c = (p1 + *p0) * 3 + 0xb;
  record_event(local_2c);
  local_30 = p2;
  if (-1 < p2) {
    for (; 0 < local_30; local_30 = local_30 + -1) {
      value = next_value(local_2c);
      local_2c = (local_2c + value) * 5 - 7;
      *p0 = local_2c;
      record_event(value);
    }
  }
  return local_2c;
}

