
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

uint region_pipeline(uint *p0,uint p1,int p2)

{
  uint value;
  uint value_00;
  uint value_01;
  int local_60;
  uint local_5c;
  int local_44;
  
  value = p1 + *p0;
  local_44 = value * 3 + 0xb;
  local_5c = local_44 - *p0;
  record_event(value);
  local_60 = p2;
  if (-1 < p2) {
    for (; 0 < local_60; local_60 = local_60 + -1) {
      value_01 = next_value(local_5c);
      value_00 = local_44 + value_01 * 5;
      local_44 = (value_00 - value_01) + value;
      record_event(value_00);
      *p0 = value_00 + 7;
      local_5c = local_5c + value_01 + local_44;
      record_event(value_01);
    }
  }
  return local_5c;
}

