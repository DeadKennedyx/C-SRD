#include <stdint.h>
#include <stdlib.h>
#include <limits.h>
_Static_assert(sizeof(int)==4, "32-bit int ABI required");
extern uint32_t next_value(uint32_t);
extern void record_event(uint32_t);
uint32_t region_pipeline(uint32_t *p0,uint32_t p1,int32_t p2){
    unsigned steps=0, incoming=0;
    (void)p0;(void)p1;(void)p2;(void)incoming;
    uint64_t v0=0; (void)v0;
    uint64_t v3=0; (void)v3;
    uint64_t v5=0; (void)v5;
    uint64_t v7=0; (void)v7;
    uint64_t v9=0; (void)v9;
    uint64_t v11=0; (void)v11;
    uint64_t v14=0; (void)v14;
    uint64_t v15=0; (void)v15;
    uint64_t v17=0; (void)v17;
    uint64_t v19=0; (void)v19;
    uint64_t v21=0; (void)v21;
    uint64_t v23=0; (void)v23;
    uint64_t v25=0; (void)v25;
    uint64_t v28=0; (void)v28;
    uint64_t v30=0; (void)v30;
    uint64_t v31=0; (void)v31;
    uint64_t v33=0; (void)v33;
    uint64_t v34=0; (void)v34;
    uint64_t v18=0; (void)v18;
    uint64_t v36=0; (void)v36;
    uint64_t v20=0; (void)v20;
    uint64_t v22=0; (void)v22;
    uint64_t v40=0; (void)v40;
    uint64_t v41=0; (void)v41;
    uint64_t phi17=0;
    uint64_t phi19=0;
    uint64_t phi21=0;
    uint64_t phi40=0;
    goto b0;
b0:
    if(++steps>10000u)exit(71);
    v0=(p0[0]) & UINT64_C(4294967295);
    v3=((((uint64_t)(uint32_t)p1) + v0)) & UINT64_C(4294967295);
    v5=((v3 * UINT64_C(3))) & UINT64_C(4294967295);
    v7=((v5 + UINT64_C(11))) & UINT64_C(4294967295);
    v9=((v7 - v0)) & UINT64_C(4294967295);
    record_event((uint32_t)(v3));
    v11=(((UINT64_C(4294967295) ^ UINT64_C(2147483648)) < (((uint64_t)(uint32_t)p2) ^ UINT64_C(2147483648)))) & UINT64_C(255);
    v14=(((uint64_t)(uint32_t)p2)) & UINT64_C(4294967295);
    v15=(v14) & UINT64_C(4294967295);
    if(v11){incoming=0;goto b1;}else{incoming=1;goto b3;}
b1:
    if(++steps>10000u)exit(71);
    switch(incoming){
    case 0:phi17=v7;break;
    case 1:phi17=v18;break;
    default:exit(72);}
    switch(incoming){
    case 0:phi19=v9;break;
    case 1:phi19=v20;break;
    default:exit(72);}
    switch(incoming){
    case 0:phi21=v15;break;
    case 1:phi21=v22;break;
    default:exit(72);}
    v17=phi17;
    v19=phi19;
    v21=phi21;
    v23=((v21 + UINT64_C(4294967295))) & UINT64_C(4294967295);
    v25=(((UINT64_C(0) ^ UINT64_C(2147483648)) < (v21 ^ UINT64_C(2147483648)))) & UINT64_C(255);
    if(v25){incoming=0;goto b2;}else{incoming=0;goto b3;}
b2:
    if(++steps>10000u)exit(71);
    v28=(next_value((uint32_t)(v19))) & UINT64_C(4294967295);
    v30=((v19 + v28)) & UINT64_C(4294967295);
    v31=((v28 * UINT64_C(5))) & UINT64_C(4294967295);
    v33=((v17 + v31)) & UINT64_C(4294967295);
    v34=((v33 - v28)) & UINT64_C(4294967295);
    v18=((v34 + v3)) & UINT64_C(4294967295);
    record_event((uint32_t)(v33));
    v36=((v33 + UINT64_C(7))) & UINT64_C(4294967295);
    p0[0]=(uint32_t)(v36);
    v20=((v30 + v18)) & UINT64_C(4294967295);
    record_event((uint32_t)(v28));
    v22=(v23) & UINT64_C(4294967295);
    incoming=1;goto b1;
b3:
    if(++steps>10000u)exit(71);
    switch(incoming){
    case 0:phi40=v19;break;
    case 1:phi40=v9;break;
    default:exit(72);}
    v40=phi40;
    v41=(v40) & UINT64_C(4294967295);
    return (uint32_t)(v41);
}
