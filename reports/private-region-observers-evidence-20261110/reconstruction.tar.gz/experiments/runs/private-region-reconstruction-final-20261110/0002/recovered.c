#include <stdint.h>
#include <stdlib.h>
#include <limits.h>
_Static_assert(sizeof(int)==4, "32-bit int ABI required");
extern uint32_t next_value(uint32_t);
extern void record_event(uint32_t);
uint32_t region_pipeline(uint32_t *p0,uint32_t p1,int32_t p2){
    unsigned steps=0, incoming=0;
    (void)p0;(void)p1;(void)p2;(void)incoming;
    uint64_t v0=0; (void)v0;
    uint64_t v3=0; (void)v3;
    uint64_t v5=0; (void)v5;
    uint64_t v7=0; (void)v7;
    uint64_t v10=0; (void)v10;
    uint64_t v14=0; (void)v14;
    uint64_t v16=0; (void)v16;
    uint64_t v18=0; (void)v18;
    uint64_t v20=0; (void)v20;
    uint64_t v21=0; (void)v21;
    uint64_t v17=0; (void)v17;
    uint64_t v15=0; (void)v15;
    uint64_t v27=0; (void)v27;
    uint64_t v30=0; (void)v30;
    uint64_t v31=0; (void)v31;
    uint64_t phi14=0;
    uint64_t phi16=0;
    uint64_t phi30=0;
    goto b0;
b0:
    if(++steps>10000u)exit(71);
    v0=(p0[0]) & UINT64_C(4294967295);
    v3=((((uint64_t)(uint32_t)p1) + v0)) & UINT64_C(4294967295);
    v5=((v3 * UINT64_C(3))) & UINT64_C(4294967295);
    v7=((v5 + UINT64_C(11))) & UINT64_C(4294967295);
    record_event((uint32_t)(v7));
    v10=(((UINT64_C(0) ^ UINT64_C(2147483648)) < (((uint64_t)(uint32_t)p2) ^ UINT64_C(2147483648)))) & UINT64_C(255);
    if(v10){incoming=0;goto b1;}else{incoming=0;goto b2;}
b1:
    if(++steps>10000u)exit(71);
    switch(incoming){
    case 0:phi14=((uint64_t)(uint32_t)p2);break;
    case 1:phi14=v15;break;
    default:exit(72);}
    switch(incoming){
    case 0:phi16=v7;break;
    case 1:phi16=v17;break;
    default:exit(72);}
    v14=phi14;
    v16=phi16;
    v18=(next_value((uint32_t)(v16))) & UINT64_C(4294967295);
    v20=((v18 + v16)) & UINT64_C(4294967295);
    v21=((v20 * UINT64_C(5))) & UINT64_C(4294967295);
    v17=((v21 - UINT64_C(7))) & UINT64_C(4294967295);
    p0[0]=(uint32_t)(v17);
    record_event((uint32_t)(v18));
    v15=((v14 + UINT64_C(4294967295))) & UINT64_C(4294967295);
    v27=((v15 != UINT64_C(0))) & UINT64_C(255);
    if(v27){incoming=1;goto b1;}else{incoming=1;goto b2;}
b2:
    if(++steps>10000u)exit(71);
    switch(incoming){
    case 0:phi30=v7;break;
    case 1:phi30=v17;break;
    default:exit(72);}
    v30=phi30;
    v31=(v30) & UINT64_C(4294967295);
    return (uint32_t)(v31);
}
