#include <stdint.h>
#include <stdlib.h>
#include <limits.h>
_Static_assert(sizeof(int)==4, "32-bit int ABI required");
extern uint32_t next_value(uint32_t);
extern void record_event(uint32_t);
int32_t region_outputs(uint32_t *p0,uint32_t p1,uint32_t p2){
    unsigned steps=0, incoming=0;
    (void)p0;(void)p1;(void)p2;(void)incoming;
    uint64_t v0=0; (void)v0;
    uint64_t v3=0; (void)v3;
    uint64_t v5=0; (void)v5;
    uint64_t v8=0; (void)v8;
    uint64_t v10=0; (void)v10;
    uint64_t v23=0; (void)v23;
    goto b0;
b0:
    if(++steps>10000u)exit(71);
    v0=((((uint64_t)(uint32_t)p1) + UINT64_C(17))) & UINT64_C(4294967295);
    v3=((v0 * UINT64_C(3))) & UINT64_C(4294967295);
    v5=((v3 + ((uint64_t)(uint32_t)p2))) & UINT64_C(4294967295);
    record_event((uint32_t)(v5));
    v8=((v5 + UINT64_C(7))) & UINT64_C(4294967295);
    v10=((v5 - UINT64_C(17))) & UINT64_C(4294967295);
    p0[0]=(uint32_t)(v10);
    p0[1]=(uint32_t)(UINT64_C(17));
    p0[2]=(uint32_t)(v8);
    v23=(UINT64_C(0)) & UINT64_C(4294967295);
    {uint32_t r=(uint32_t)(v23);
    return r<=INT32_MAX?(int32_t)r:INT32_MIN+(int32_t)(r-UINT32_C(2147483648));}
}
