
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int region_outputs(uint *p0,uint p1,uint p2)

{
  int iVar1;
  
  iVar1 = p1 * 3 + p2;
  record_event(iVar1 + 0x33);
  *p0 = iVar1 + 0x22;
  p0[1] = 0x11;
  p0[2] = iVar1 + 0x3a;
  return 0;
}

