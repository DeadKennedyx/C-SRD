#include <stdint.h>
#include <stdlib.h>
#include <limits.h>
_Static_assert(sizeof(int)==4, "32-bit int ABI required");
extern uint32_t next_value(uint32_t);
extern void record_event(uint32_t);
int32_t region_outputs(uint32_t *p0,uint32_t p1,uint32_t p2){
    unsigned steps=0, incoming=0;
    (void)p0;(void)p1;(void)p2;(void)incoming;
    uint64_t v0=0; (void)v0;
    uint64_t v3=0; (void)v3;
    uint64_t v6=0; (void)v6;
    uint64_t v8=0; (void)v8;
    uint64_t v10=0; (void)v10;
    uint64_t v11=0; (void)v11;
    uint64_t v13=0; (void)v13;
    uint64_t v15=0; (void)v15;
    uint64_t v17=0; (void)v17;
    uint64_t v19=0; (void)v19;
    uint64_t v21=0; (void)v21;
    uint64_t v24=0; (void)v24;
    uint64_t v26=0; (void)v26;
    uint64_t v28=0; (void)v28;
    uint64_t v30=0; (void)v30;
    uint64_t v43=0; (void)v43;
    uint64_t v44=0; (void)v44;
    goto b0;
b0:
    if(++steps>10000u)exit(71);
    v0=((((uint64_t)(uint32_t)p1) * UINT64_C(2622762737))) & UINT64_C(4294967295);
    v3=((((uint64_t)(uint32_t)p2) * UINT64_C(2622762737))) & UINT64_C(4294967295);
    v6=((v0 + UINT64_C(824927889))) & UINT64_C(4294967295);
    v8=((v6 * UINT64_C(3))) & UINT64_C(4294967295);
    v10=((v8 + v3)) & UINT64_C(4294967295);
    v11=((v10 + UINT64_C(1624731360))) & UINT64_C(4294967295);
    v13=((v10 + UINT64_C(4282405087))) & UINT64_C(4294967295);
    v15=((v11 * UINT64_C(1824195089))) & UINT64_C(4294967295);
    v17=((v15 + UINT64_C(1298534000))) & UINT64_C(4294967295);
    v19=((v13 * UINT64_C(1824195089))) & UINT64_C(4294967295);
    v21=((v19 + UINT64_C(1298534000))) & UINT64_C(4294967295);
    record_event((uint32_t)(v17));
    v24=((v17 * UINT64_C(126215511))) & UINT64_C(4294967295);
    v26=((v24 + UINT64_C(2319976105))) & UINT64_C(4294967295);
    v28=((v26 * UINT64_C(866571879))) & UINT64_C(4294967295);
    v30=((v28 + UINT64_C(719195144))) & UINT64_C(4294967295);
    p0[2]=(uint32_t)(v30);
    p0[0]=(uint32_t)(v21);
    p0[1]=(uint32_t)(UINT64_C(17));
    v43=((v17 == v21)) & UINT64_C(255);
    v44=(v43) & UINT64_C(4294967295);
    {uint32_t r=(uint32_t)(v44);
    return r<=INT32_MAX?(int32_t)r:INT32_MIN+(int32_t)(r-UINT32_C(2147483648));}
}
