
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int region_outputs(uint *p0,uint p1,uint p2)

{
  int iVar1;
  uint value;
  uint uVar2;
  
  iVar1 = (p1 * -0x63abd10f + 0x312b6691) * 3 + p2 * -0x63abd10f;
  value = (iVar1 + 0x60d76ee0) * 0x6cbb0211 + 0x4d660e70;
  uVar2 = (iVar1 + -0xbfaf21) * 0x6cbb0211 + 0x4d660e70;
  record_event(value);
  p0[2] = (value * 0x785e557 + -0x75b7f957) * 0x33a6d667 + 0x2ade0c08;
  *p0 = uVar2;
  p0[1] = 0x11;
  return (uint)(value == uVar2);
}

