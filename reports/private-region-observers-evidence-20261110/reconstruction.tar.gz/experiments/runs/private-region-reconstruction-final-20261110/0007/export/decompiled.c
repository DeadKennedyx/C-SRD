
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

uint region_pipeline(uint *p0,uint p1,int p2)

{
  int iVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  uint value;
  int local_44;
  int local_28;
  uint local_24;
  uint local_14;
  
  iVar1 = *p0 * -0xda0dc39 + 0x3d0da4f5;
  iVar2 = p1 * -0xda0dc39 + 0x3d0da4f5 + iVar1;
  iVar4 = (iVar2 + -0x3d0da4f5) * 3;
  local_24 = ((iVar4 + -0x1004c05d) - iVar1) * 0xec1adf7;
  iVar2 = iVar2 + -0x7a1b49ea;
  local_44 = (iVar4 + -0x4d126552) * 0xec1adf7;
  record_event(iVar2 * 0xec1adf7);
  local_28 = p2;
  if (p2 < 0) {
    local_14 = local_24;
  }
  else {
    while (0 < local_28) {
      value = next_value(local_24);
      iVar1 = value * 0x42c51b5 + 0x70ab32a8;
      iVar4 = local_44 * 0x42c51b5 + iVar1 * 5 + 0x3d533560;
      iVar3 = (iVar4 - iVar1) + iVar2 * 0x796f26a3;
      local_44 = iVar3 * 0x2188d49d;
      iVar4 = iVar4 + -0x70ab32a8;
      record_event(iVar4 * 0x2188d49d);
      *p0 = (iVar4 * -0x3c37995d + 0x2442fdb9) * 0x3aebcbbf;
      local_24 = ((local_24 * 0x42c51b5 + iVar1 + -0x70ab32a8) * -0x6b12ae61 + iVar3 * -0x6b12ae61)
                 * 0x11f08843;
      record_event(value);
      local_28 = local_28 + -1;
    }
    local_14 = local_24;
  }
  return local_14;
}

