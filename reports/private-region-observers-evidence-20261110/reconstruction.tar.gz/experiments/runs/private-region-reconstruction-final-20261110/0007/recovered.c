#include <stdint.h>
#include <stdlib.h>
#include <limits.h>
_Static_assert(sizeof(int)==4, "32-bit int ABI required");
extern uint32_t next_value(uint32_t);
extern void record_event(uint32_t);
uint32_t region_pipeline(uint32_t *p0,uint32_t p1,int32_t p2){
    unsigned steps=0, incoming=0;
    (void)p0;(void)p1;(void)p2;(void)incoming;
    uint64_t v0=0; (void)v0;
    uint64_t v3=0; (void)v3;
    uint64_t v6=0; (void)v6;
    uint64_t v8=0; (void)v8;
    uint64_t v10=0; (void)v10;
    uint64_t v12=0; (void)v12;
    uint64_t v13=0; (void)v13;
    uint64_t v15=0; (void)v15;
    uint64_t v17=0; (void)v17;
    uint64_t v19=0; (void)v19;
    uint64_t v20=0; (void)v20;
    uint64_t v22=0; (void)v22;
    uint64_t v24=0; (void)v24;
    uint64_t v26=0; (void)v26;
    uint64_t v28=0; (void)v28;
    uint64_t v31=0; (void)v31;
    uint64_t v34=0; (void)v34;
    uint64_t v36=0; (void)v36;
    uint64_t v38=0; (void)v38;
    uint64_t v40=0; (void)v40;
    uint64_t v42=0; (void)v42;
    uint64_t v44=0; (void)v44;
    uint64_t v47=0; (void)v47;
    uint64_t v49=0; (void)v49;
    uint64_t v51=0; (void)v51;
    uint64_t v53=0; (void)v53;
    uint64_t v55=0; (void)v55;
    uint64_t v57=0; (void)v57;
    uint64_t v59=0; (void)v59;
    uint64_t v60=0; (void)v60;
    uint64_t v62=0; (void)v62;
    uint64_t v64=0; (void)v64;
    uint64_t v65=0; (void)v65;
    uint64_t v66=0; (void)v66;
    uint64_t v67=0; (void)v67;
    uint64_t v41=0; (void)v41;
    uint64_t v70=0; (void)v70;
    uint64_t v72=0; (void)v72;
    uint64_t v75=0; (void)v75;
    uint64_t v77=0; (void)v77;
    uint64_t v79=0; (void)v79;
    uint64_t v82=0; (void)v82;
    uint64_t v84=0; (void)v84;
    uint64_t v86=0; (void)v86;
    uint64_t v37=0; (void)v37;
    uint64_t v39=0; (void)v39;
    uint64_t v90=0; (void)v90;
    uint64_t v92=0; (void)v92;
    uint64_t v94=0; (void)v94;
    uint64_t v95=0; (void)v95;
    uint64_t phi36=0;
    uint64_t phi38=0;
    uint64_t phi40=0;
    uint64_t phi94=0;
    goto b0;
b0:
    if(++steps>10000u)exit(71);
    v0=(p0[0]) & UINT64_C(4294967295);
    v3=((((uint64_t)(uint32_t)p1) * UINT64_C(4066321351))) & UINT64_C(4294967295);
    v6=((v3 + UINT64_C(1024304373))) & UINT64_C(4294967295);
    v8=((v0 * UINT64_C(4066321351))) & UINT64_C(4294967295);
    v10=((v8 + UINT64_C(1024304373))) & UINT64_C(4294967295);
    v12=((v6 + v10)) & UINT64_C(4294967295);
    v13=((v12 + UINT64_C(3270662923))) & UINT64_C(4294967295);
    v15=((v13 * UINT64_C(3))) & UINT64_C(4294967295);
    v17=((v15 + UINT64_C(4026220451))) & UINT64_C(4294967295);
    v19=((v17 - v10)) & UINT64_C(4294967295);
    v20=((v19 * UINT64_C(247574007))) & UINT64_C(4294967295);
    v22=((v12 + UINT64_C(2246358550))) & UINT64_C(4294967295);
    v24=((v22 * UINT64_C(247574007))) & UINT64_C(4294967295);
    v26=((v15 + UINT64_C(3001916078))) & UINT64_C(4294967295);
    v28=((v26 * UINT64_C(247574007))) & UINT64_C(4294967295);
    record_event((uint32_t)(v24));
    v31=(((((uint64_t)(uint32_t)p2) ^ UINT64_C(2147483648)) < (UINT64_C(0) ^ UINT64_C(2147483648)))) & UINT64_C(255);
    v34=(((uint64_t)(uint32_t)p2)) & UINT64_C(4294967295);
    if(v31){incoming=0;goto b4;}else{incoming=1;goto b1;}
b1:
    if(++steps>10000u)exit(71);
    switch(incoming){
    case 0:phi36=v37;break;
    case 1:phi36=v20;break;
    default:exit(72);}
    switch(incoming){
    case 0:phi38=v39;break;
    case 1:phi38=v34;break;
    default:exit(72);}
    switch(incoming){
    case 0:phi40=v41;break;
    case 1:phi40=v28;break;
    default:exit(72);}
    v36=phi36;
    v38=phi38;
    v40=phi40;
    v42=((v38 + UINT64_C(4294967295))) & UINT64_C(4294967295);
    v44=(((UINT64_C(0) ^ UINT64_C(2147483648)) < (v38 ^ UINT64_C(2147483648)))) & UINT64_C(255);
    if(v44){incoming=0;goto b2;}else{incoming=0;goto b3;}
b2:
    if(++steps>10000u)exit(71);
    v47=(next_value((uint32_t)(v36))) & UINT64_C(4294967295);
    v49=((v36 * UINT64_C(70013365))) & UINT64_C(4294967295);
    v51=((v47 * UINT64_C(70013365))) & UINT64_C(4294967295);
    v53=((v51 + UINT64_C(1890267816))) & UINT64_C(4294967295);
    v55=((v40 * UINT64_C(70013365))) & UINT64_C(4294967295);
    v57=((v22 * UINT64_C(2037327523))) & UINT64_C(4294967295);
    v59=((v49 + v53)) & UINT64_C(4294967295);
    v60=((v53 * UINT64_C(5))) & UINT64_C(4294967295);
    v62=((v60 + UINT64_C(1028863328))) & UINT64_C(4294967295);
    v64=((v55 + v62)) & UINT64_C(4294967295);
    v65=((v64 - v53)) & UINT64_C(4294967295);
    v66=((v65 + v57)) & UINT64_C(4294967295);
    v67=((v59 + UINT64_C(2404699480))) & UINT64_C(4294967295);
    v41=((v66 * UINT64_C(562615453))) & UINT64_C(4294967295);
    v70=((v64 + UINT64_C(2404699480))) & UINT64_C(4294967295);
    v72=((v70 * UINT64_C(562615453))) & UINT64_C(4294967295);
    record_event((uint32_t)(v72));
    v75=((v70 * UINT64_C(3284690595))) & UINT64_C(4294967295);
    v77=((v75 + UINT64_C(608370105))) & UINT64_C(4294967295);
    v79=((v77 * UINT64_C(988531647))) & UINT64_C(4294967295);
    p0[0]=(uint32_t)(v79);
    v82=((v67 * UINT64_C(2498580895))) & UINT64_C(4294967295);
    v84=((v66 * UINT64_C(2498580895))) & UINT64_C(4294967295);
    v86=((v82 + v84)) & UINT64_C(4294967295);
    v37=((v86 * UINT64_C(300976195))) & UINT64_C(4294967295);
    record_event((uint32_t)(v47));
    v39=(v42) & UINT64_C(4294967295);
    incoming=0;goto b1;
b3:
    if(++steps>10000u)exit(71);
    v90=(v36) & UINT64_C(4294967295);
    incoming=1;goto b5;
b4:
    if(++steps>10000u)exit(71);
    v92=(v20) & UINT64_C(4294967295);
    incoming=0;goto b5;
b5:
    if(++steps>10000u)exit(71);
    switch(incoming){
    case 0:phi94=v92;break;
    case 1:phi94=v90;break;
    default:exit(72);}
    v94=phi94;
    v95=(v94) & UINT64_C(4294967295);
    return (uint32_t)(v95);
}
