
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

uint region_pipeline(uint *p0,uint p1,int p2)

{
  uint value;
  uint value_00;
  uint value_01;
  int local_20;
  uint local_1c;
  int local_10;
  
  value = p1 + *p0;
  local_10 = value * 3 + 0xb;
  local_1c = local_10 - *p0;
  record_event(value);
  local_20 = p2;
  if (-1 < p2) {
    for (; 0 < local_20; local_20 = local_20 + -1) {
      value_01 = next_value(local_1c);
      value_00 = local_10 + value_01 * 5;
      local_10 = (value_00 - value_01) + value;
      record_event(value_00);
      *p0 = value_00 + 7;
      local_1c = local_1c + value_01 + local_10;
      record_event(value_01);
    }
  }
  return local_1c;
}

