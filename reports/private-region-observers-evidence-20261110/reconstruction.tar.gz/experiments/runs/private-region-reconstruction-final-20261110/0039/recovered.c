#include <stdint.h>
#include <stdlib.h>
#include <limits.h>
_Static_assert(sizeof(int)==4, "32-bit int ABI required");
extern uint32_t next_value(uint32_t);
extern void record_event(uint32_t);
uint32_t region_pipeline(uint32_t *p0,uint32_t p1,int32_t p2){
    unsigned steps=0, incoming=0;
    (void)p0;(void)p1;(void)p2;(void)incoming;
    uint64_t v0=0; (void)v0;
    uint64_t v3=0; (void)v3;
    uint64_t v5=0; (void)v5;
    uint64_t v7=0; (void)v7;
    uint64_t v9=0; (void)v9;
    uint64_t v11=0; (void)v11;
    uint64_t v14=0; (void)v14;
    uint64_t v16=0; (void)v16;
    uint64_t v18=0; (void)v18;
    uint64_t v20=0; (void)v20;
    uint64_t v22=0; (void)v22;
    uint64_t v24=0; (void)v24;
    uint64_t v27=0; (void)v27;
    uint64_t v29=0; (void)v29;
    uint64_t v30=0; (void)v30;
    uint64_t v32=0; (void)v32;
    uint64_t v33=0; (void)v33;
    uint64_t v21=0; (void)v21;
    uint64_t v35=0; (void)v35;
    uint64_t v17=0; (void)v17;
    uint64_t v19=0; (void)v19;
    uint64_t v40=0; (void)v40;
    uint64_t v42=0; (void)v42;
    uint64_t v44=0; (void)v44;
    uint64_t v45=0; (void)v45;
    uint64_t phi16=0;
    uint64_t phi18=0;
    uint64_t phi20=0;
    uint64_t phi44=0;
    goto b0;
b0:
    if(++steps>10000u)exit(71);
    v0=(p0[0]) & UINT64_C(4294967295);
    v3=((((uint64_t)(uint32_t)p1) + v0)) & UINT64_C(4294967295);
    v5=((v3 * UINT64_C(3))) & UINT64_C(4294967295);
    v7=((v5 + UINT64_C(11))) & UINT64_C(4294967295);
    v9=((v7 - v0)) & UINT64_C(4294967295);
    record_event((uint32_t)(v3));
    v11=(((((uint64_t)(uint32_t)p2) ^ UINT64_C(2147483648)) < (UINT64_C(0) ^ UINT64_C(2147483648)))) & UINT64_C(255);
    v14=(((uint64_t)(uint32_t)p2)) & UINT64_C(4294967295);
    if(v11){incoming=0;goto b4;}else{incoming=1;goto b1;}
b1:
    if(++steps>10000u)exit(71);
    switch(incoming){
    case 0:phi16=v17;break;
    case 1:phi16=v9;break;
    default:exit(72);}
    switch(incoming){
    case 0:phi18=v19;break;
    case 1:phi18=v14;break;
    default:exit(72);}
    switch(incoming){
    case 0:phi20=v21;break;
    case 1:phi20=v7;break;
    default:exit(72);}
    v16=phi16;
    v18=phi18;
    v20=phi20;
    v22=((v18 + UINT64_C(4294967295))) & UINT64_C(4294967295);
    v24=(((UINT64_C(0) ^ UINT64_C(2147483648)) < (v18 ^ UINT64_C(2147483648)))) & UINT64_C(255);
    if(v24){incoming=0;goto b2;}else{incoming=0;goto b3;}
b2:
    if(++steps>10000u)exit(71);
    v27=(next_value((uint32_t)(v16))) & UINT64_C(4294967295);
    v29=((v16 + v27)) & UINT64_C(4294967295);
    v30=((v27 * UINT64_C(5))) & UINT64_C(4294967295);
    v32=((v20 + v30)) & UINT64_C(4294967295);
    v33=((v32 - v27)) & UINT64_C(4294967295);
    v21=((v33 + v3)) & UINT64_C(4294967295);
    record_event((uint32_t)(v32));
    v35=((v32 + UINT64_C(7))) & UINT64_C(4294967295);
    p0[0]=(uint32_t)(v35);
    v17=((v29 + v21)) & UINT64_C(4294967295);
    record_event((uint32_t)(v27));
    v19=(v22) & UINT64_C(4294967295);
    incoming=0;goto b1;
b3:
    if(++steps>10000u)exit(71);
    v40=(v16) & UINT64_C(4294967295);
    incoming=1;goto b5;
b4:
    if(++steps>10000u)exit(71);
    v42=(v9) & UINT64_C(4294967295);
    incoming=0;goto b5;
b5:
    if(++steps>10000u)exit(71);
    switch(incoming){
    case 0:phi44=v42;break;
    case 1:phi44=v40;break;
    default:exit(72);}
    v44=phi44;
    v45=(v44) & UINT64_C(4294967295);
    return (uint32_t)(v45);
}
