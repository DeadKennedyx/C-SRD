
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

uint region_pipeline(uint *p0,uint p1,int p2)

{
  uint value;
  uint value_00;
  uint value_01;
  int local_34;
  int local_28;
  uint local_24;
  uint local_14;
  
  value = p1 + *p0;
  local_34 = value * 3 + 0xb;
  local_24 = local_34 - *p0;
  record_event(value);
  local_28 = p2;
  if (p2 < 0) {
    local_14 = local_24;
  }
  else {
    while (0 < local_28) {
      value_01 = next_value(local_24);
      value_00 = local_34 + value_01 * 5;
      local_34 = (value_00 - value_01) + value;
      record_event(value_00);
      *p0 = value_00 + 7;
      local_24 = local_24 + value_01 + local_34;
      record_event(value_01);
      local_28 = local_28 + -1;
    }
    local_14 = local_24;
  }
  return local_14;
}

