#include "symbolic.hpp"
#include <set>
#include <stdexcept>

namespace csrd {
namespace {
using verification_detail::Environment;
z3::expr value(z3::context &ctx, const Expr &e, const Environment &scalars,
               const Environment &bases, const z3::expr &memory) {
  switch (e.kind) {
  case Expr::Kind::Constant: return ctx.bv_val(e.value, 32);
  case Expr::Kind::Reference: return scalars.at(e.name);
  case Expr::Kind::Load: return z3::select(memory, bases.at(e.name) + ctx.int_val(e.value));
  case Expr::Kind::Add: return value(ctx, *e.left, scalars, bases, memory) + value(ctx, *e.right, scalars, bases, memory);
  case Expr::Kind::Subtract: return value(ctx, *e.left, scalars, bases, memory) - value(ctx, *e.right, scalars, bases, memory);
  case Expr::Kind::Scale: return value(ctx, *e.left, scalars, bases, memory) * ctx.bv_val(e.value, 32);
  default: throw std::invalid_argument("unmodeled expression in buffer verification");
  }
}
std::pair<z3::expr, z3::expr> execute(z3::context &ctx, const Region &r,
                                     Environment scalars, const Environment &bases, z3::expr memory) {
  for (const auto &s : r.statements) {
    if (!s.expression) throw std::invalid_argument("unmodeled memory statement");
    const auto result = value(ctx, *s.expression, scalars, bases, memory);
    switch (s.kind) {
    case Statement::Kind::Declare:
    case Statement::Kind::Assign: scalars.insert_or_assign(s.name, result); break;
    case Statement::Kind::Store: memory = z3::store(memory, bases.at(s.name) + ctx.int_val(s.index), result); break;
    case Statement::Kind::Return: return {result, memory};
    default: throw std::invalid_argument("unmodeled control flow in buffer verification");
    }
  }
  throw std::invalid_argument("buffer region lacks final return");
}
}
Verification verifyMemory(const Region &original, const Region &candidate, unsigned timeoutMs) {
  Verification proof;
  proof.strategy = "shared-word-memory/simplify/smt";
  try {
    if (original.parameters.size() != candidate.parameters.size()) throw std::invalid_argument("parameter arity mismatch");
    z3::context ctx;
    Environment leftScalars, rightScalars, leftBases, rightBases;
    std::vector<z3::expr> inputs;
    for (unsigned i = 0; i < original.parameters.size(); ++i) {
      const auto &left = original.parameters[i], &right = candidate.parameters[i];
      const auto a = original.buffers.find(left), b = candidate.buffers.find(right);
      if ((a == original.buffers.end()) != (b == candidate.buffers.end()))
        throw std::invalid_argument("scalar/pointer parameter kind mismatch");
      if (a == original.buffers.end()) {
        const auto input = ctx.bv_const(("input_" + std::to_string(i)).c_str(), 32);
        leftScalars.emplace(left, input); rightScalars.emplace(right, input); inputs.push_back(input);
      } else {
        if (a->second.readOnly != b->second.readOnly) throw std::invalid_argument("pointer constness mismatch");
        if (b->second.minimumElements > a->second.minimumElements)
          throw std::invalid_argument("candidate requires a larger buffer footprint than the original contract");
        const auto base = ctx.int_const(("base_" + std::to_string(i)).c_str());
        leftBases.emplace(left, base); rightBases.emplace(right, base);
      }
    }
    const auto memory = ctx.constant("initial_memory", ctx.array_sort(ctx.int_sort(), ctx.bv_sort(32)));
    const auto left = execute(ctx, original, leftScalars, leftBases, memory);
    const auto right = execute(ctx, candidate, rightScalars, rightBases, memory);
    z3::params params(ctx); params.set("som", true);
    auto solver = (z3::with(z3::tactic(ctx, "simplify"), params) & z3::tactic(ctx, "smt")).mk_solver();
    solver.set("timeout", timeoutMs);
    solver.add(left.first != right.first || left.second != right.second);
    proof.obligation = solver.to_smt2();
    const auto answer = solver.check();
    if (answer == z3::unsat) proof.status = "proved-under-model";
    else if (answer == z3::unknown) { proof.status = "inconclusive"; proof.reason = solver.reason_unknown(); }
    else {
      proof.status = "counterexample";
      const auto model = solver.get_model();
      auto word = [&](const z3::expr &e) { return uint32_t(model.eval(e, true).get_numeral_uint64()); };
      for (const auto &input : inputs) proof.inputs.push_back(word(input));
      proof.originalOutput = word(left.first); proof.candidateOutput = word(right.first);
      std::set<std::string> seen;
      for (const auto &[name, buffer] : original.buffers) {
        proof.pointerBases.emplace_back(name, model.eval(leftBases.at(name), true).to_string());
        for (unsigned i = 0; i < buffer.minimumElements; ++i) {
          const auto address = model.eval(leftBases.at(name) + ctx.int_val(i), true);
          if (seen.insert(address.to_string()).second)
            proof.memoryCells.push_back({address.to_string(), word(z3::select(memory, address)),
              word(z3::select(left.second, address)), word(z3::select(right.second, address))});
        }
      }
    }
  } catch (const z3::exception &e) { proof.status = "inconclusive"; proof.reason = e.msg(); }
    catch (const std::exception &e) { proof.status = "unsupported"; proof.reason = e.what(); }
  return proof;
}
}
