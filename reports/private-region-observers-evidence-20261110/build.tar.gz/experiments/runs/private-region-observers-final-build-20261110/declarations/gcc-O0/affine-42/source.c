typedef unsigned char __u_char;
typedef unsigned short int __u_short;
typedef unsigned int __u_int;
typedef unsigned long int __u_long;
typedef signed char __int8_t;
typedef unsigned char __uint8_t;
typedef signed short int __int16_t;
typedef unsigned short int __uint16_t;
typedef signed int __int32_t;
typedef unsigned int __uint32_t;
typedef signed long int __int64_t;
typedef unsigned long int __uint64_t;
typedef __int8_t __int_least8_t;
typedef __uint8_t __uint_least8_t;
typedef __int16_t __int_least16_t;
typedef __uint16_t __uint_least16_t;
typedef __int32_t __int_least32_t;
typedef __uint32_t __uint_least32_t;
typedef __int64_t __int_least64_t;
typedef __uint64_t __uint_least64_t;
typedef long int __quad_t;
typedef unsigned long int __u_quad_t;
typedef long int __intmax_t;
typedef unsigned long int __uintmax_t;
typedef unsigned long int __dev_t;
typedef unsigned int __uid_t;
typedef unsigned int __gid_t;
typedef unsigned long int __ino_t;
typedef unsigned long int __ino64_t;
typedef unsigned int __mode_t;
typedef unsigned int __nlink_t;
typedef long int __off_t;
typedef long int __off64_t;
typedef int __pid_t;
typedef struct { int __val[2]; } __fsid_t;
typedef long int __clock_t;
typedef unsigned long int __rlim_t;
typedef unsigned long int __rlim64_t;
typedef unsigned int __id_t;
typedef long int __time_t;
typedef unsigned int __useconds_t;
typedef long int __suseconds_t;
typedef long int __suseconds64_t;
typedef int __daddr_t;
typedef int __key_t;
typedef int __clockid_t;
typedef void * __timer_t;
typedef int __blksize_t;
typedef long int __blkcnt_t;
typedef long int __blkcnt64_t;
typedef unsigned long int __fsblkcnt_t;
typedef unsigned long int __fsblkcnt64_t;
typedef unsigned long int __fsfilcnt_t;
typedef unsigned long int __fsfilcnt64_t;
typedef long int __fsword_t;
typedef long int __ssize_t;
typedef long int __syscall_slong_t;
typedef unsigned long int __syscall_ulong_t;
typedef __off64_t __loff_t;
typedef char *__caddr_t;
typedef long int __intptr_t;
typedef unsigned int __socklen_t;
typedef int __sig_atomic_t;
typedef __int8_t int8_t;
typedef __int16_t int16_t;
typedef __int32_t int32_t;
typedef __int64_t int64_t;
typedef __uint8_t uint8_t;
typedef __uint16_t uint16_t;
typedef __uint32_t uint32_t;
typedef __uint64_t uint64_t;
typedef __int_least8_t int_least8_t;
typedef __int_least16_t int_least16_t;
typedef __int_least32_t int_least32_t;
typedef __int_least64_t int_least64_t;
typedef __uint_least8_t uint_least8_t;
typedef __uint_least16_t uint_least16_t;
typedef __uint_least32_t uint_least32_t;
typedef __uint_least64_t uint_least64_t;
typedef signed char int_fast8_t;
typedef long int int_fast16_t;
typedef long int int_fast32_t;
typedef long int int_fast64_t;
typedef unsigned char uint_fast8_t;
typedef unsigned long int uint_fast16_t;
typedef unsigned long int uint_fast32_t;
typedef unsigned long int uint_fast64_t;
typedef long int intptr_t;
typedef unsigned long int uintptr_t;
typedef __intmax_t intmax_t;
typedef __uintmax_t uintmax_t;
extern uint32_t next_value(uint32_t value);
extern void record_event(uint32_t value);
uint32_t region_pipeline(uint32_t *buffer, uint32_t x, int limit)
{
    uint32_t y = buffer[0];
    unsigned int csrd_frame_3191_0 = ((1216251553u * (x)) + 1928882868u); unsigned int csrd_frame_3191_1 = ((1216251553u * (y)) + 1928882868u); unsigned int csrd_frame_3191_2 = (((csrd_frame_3191_0) + (csrd_frame_3191_1)) - 1928882868u); unsigned int csrd_frame_3191_3 = (((((3u * (csrd_frame_3191_2)) + 437201560u)) + (2422748063u)) - 1928882868u); csrd_frame_3191_0 = (((csrd_frame_3191_3) - (csrd_frame_3191_1)) + 1928882868u); x = (1008131425u * ((csrd_frame_3191_0) - 1928882868u)); register unsigned int sum = (1008131425u * ((csrd_frame_3191_2) - 1928882868u)); (void)sum; unsigned int bias = (1008131425u * ((csrd_frame_3191_3) - 1928882868u)); (void)bias

;
    record_event(sum);
    if (limit < 0) return x;
    while (limit-- > 0) {
        y = next_value(x);
        {
            unsigned int csrd_frame_3403_0 = ((4163168751u * (x)) + 3280574841u); unsigned int csrd_frame_3403_1 = ((4163168751u * (y)) + 3280574841u); unsigned int csrd_frame_3403_2 = ((4163168751u * (bias)) + 3280574841u); unsigned int csrd_frame_3403_3 = ((4163168751u * (sum)) + 3280574841u); csrd_frame_3403_0 = (((csrd_frame_3403_0) + (csrd_frame_3403_1)) - 3280574841u); unsigned int csrd_frame_3403_4 = (((csrd_frame_3403_2) + (((5u * (csrd_frame_3403_1)) + 4057569820u))) - 3280574841u); unsigned int csrd_frame_3403_5 = (((csrd_frame_3403_4) - (csrd_frame_3403_1)) + 3280574841u); csrd_frame_3403_2 = (((csrd_frame_3403_5) + (csrd_frame_3403_3)) - 3280574841u); x = (1243964687u * ((csrd_frame_3403_0) - 3280574841u)); bias = (1243964687u * ((csrd_frame_3403_2) - 3280574841u)); unsigned int x = (1243964687u * ((csrd_frame_3403_4) - 3280574841u)); (void)x; unsigned int local = (1243964687u * ((csrd_frame_3403_5) - 3280574841u)); (void)local


;
            record_event(x);
            { unsigned int csrd_frame_3563_0 = ((1549162689u * (x)) + 48847194u); csrd_frame_3563_0 = (((csrd_frame_3563_0) + (2303051425u)) - 48847194u); x = (2944546625u * ((csrd_frame_3563_0) - 48847194u));}
            buffer[0] = x;
        }
        { unsigned int csrd_frame_3620_0 = ((156991531u * (x)) + 953993143u); unsigned int csrd_frame_3620_1 = ((156991531u * (bias)) + 953993143u); csrd_frame_3620_0 = (((csrd_frame_3620_0) + (csrd_frame_3620_1)) - 953993143u); x = (854146691u * ((csrd_frame_3620_0) - 953993143u));}
        record_event(y);
    }
    return x;
}
int region_outputs(uint32_t *buffer, uint32_t x, uint32_t y)
{
    unsigned int csrd_frame_3748_0 = ((2622762737u * (x)) + 3482601616u); unsigned int csrd_frame_3748_1 = ((2622762737u * (y)) + 3482601616u); unsigned int csrd_frame_3748_2 = 824927889u; unsigned int csrd_frame_3748_3 = (((csrd_frame_3748_2) + (csrd_frame_3748_0)) - 3482601616u); csrd_frame_3748_0 = (((((3u * (csrd_frame_3748_3)) + 1624731360u)) + (csrd_frame_3748_1)) - 3482601616u); csrd_frame_3748_1 = (((csrd_frame_3748_0) - (csrd_frame_3748_2)) + 3482601616u); x = (1824195089u * ((csrd_frame_3748_0) - 3482601616u)); y = (1824195089u * ((csrd_frame_3748_1) - 3482601616u)); register unsigned int pending = (1824195089u * ((csrd_frame_3748_2) - 3482601616u)); (void)pending; unsigned int mix = (1824195089u * ((csrd_frame_3748_3) - 3482601616u)); (void)mix


;
    record_event(x);
    {
        unsigned int csrd_frame_3891_0 = ((126215511u * (x)) + 1436467528u); unsigned int csrd_frame_3891_1 = (((csrd_frame_3891_0) + (2319976105u)) - 1436467528u); unsigned int y = (866571879u * ((csrd_frame_3891_1) - 1436467528u)); (void)y;
        buffer[2] = y;
    }
    buffer[0] = y;
    buffer[1] = pending;
    return x == y;
}
