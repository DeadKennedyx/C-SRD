typedef unsigned char __u_char;
typedef unsigned short int __u_short;
typedef unsigned int __u_int;
typedef unsigned long int __u_long;
typedef signed char __int8_t;
typedef unsigned char __uint8_t;
typedef signed short int __int16_t;
typedef unsigned short int __uint16_t;
typedef signed int __int32_t;
typedef unsigned int __uint32_t;
typedef signed long int __int64_t;
typedef unsigned long int __uint64_t;
typedef __int8_t __int_least8_t;
typedef __uint8_t __uint_least8_t;
typedef __int16_t __int_least16_t;
typedef __uint16_t __uint_least16_t;
typedef __int32_t __int_least32_t;
typedef __uint32_t __uint_least32_t;
typedef __int64_t __int_least64_t;
typedef __uint64_t __uint_least64_t;
typedef long int __quad_t;
typedef unsigned long int __u_quad_t;
typedef long int __intmax_t;
typedef unsigned long int __uintmax_t;
typedef unsigned long int __dev_t;
typedef unsigned int __uid_t;
typedef unsigned int __gid_t;
typedef unsigned long int __ino_t;
typedef unsigned long int __ino64_t;
typedef unsigned int __mode_t;
typedef unsigned int __nlink_t;
typedef long int __off_t;
typedef long int __off64_t;
typedef int __pid_t;
typedef struct { int __val[2]; } __fsid_t;
typedef long int __clock_t;
typedef unsigned long int __rlim_t;
typedef unsigned long int __rlim64_t;
typedef unsigned int __id_t;
typedef long int __time_t;
typedef unsigned int __useconds_t;
typedef long int __suseconds_t;
typedef long int __suseconds64_t;
typedef int __daddr_t;
typedef int __key_t;
typedef int __clockid_t;
typedef void * __timer_t;
typedef int __blksize_t;
typedef long int __blkcnt_t;
typedef long int __blkcnt64_t;
typedef unsigned long int __fsblkcnt_t;
typedef unsigned long int __fsblkcnt64_t;
typedef unsigned long int __fsfilcnt_t;
typedef unsigned long int __fsfilcnt64_t;
typedef long int __fsword_t;
typedef long int __ssize_t;
typedef long int __syscall_slong_t;
typedef unsigned long int __syscall_ulong_t;
typedef __off64_t __loff_t;
typedef char *__caddr_t;
typedef long int __intptr_t;
typedef unsigned int __socklen_t;
typedef int __sig_atomic_t;
typedef __int8_t int8_t;
typedef __int16_t int16_t;
typedef __int32_t int32_t;
typedef __int64_t int64_t;
typedef __uint8_t uint8_t;
typedef __uint16_t uint16_t;
typedef __uint32_t uint32_t;
typedef __uint64_t uint64_t;
typedef __int_least8_t int_least8_t;
typedef __int_least16_t int_least16_t;
typedef __int_least32_t int_least32_t;
typedef __int_least64_t int_least64_t;
typedef __uint_least8_t uint_least8_t;
typedef __uint_least16_t uint_least16_t;
typedef __uint_least32_t uint_least32_t;
typedef __uint_least64_t uint_least64_t;
typedef signed char int_fast8_t;
typedef long int int_fast16_t;
typedef long int int_fast32_t;
typedef long int int_fast64_t;
typedef unsigned char uint_fast8_t;
typedef unsigned long int uint_fast16_t;
typedef unsigned long int uint_fast32_t;
typedef unsigned long int uint_fast64_t;
typedef long int intptr_t;
typedef unsigned long int uintptr_t;
typedef __intmax_t intmax_t;
typedef __uintmax_t uintmax_t;

extern uint32_t next_value(uint32_t value);
extern void record_event(uint32_t value);
uint32_t region_pipeline(uint32_t *buffer, uint32_t x, int limit)
{
    uint32_t y = buffer[0];
    unsigned int csrd_frame_3192_0 = ((4066321351u * (x)) + 1024304373u); unsigned int csrd_frame_3192_1 = ((4066321351u * (y)) + 1024304373u); unsigned int csrd_frame_3192_2 = (((csrd_frame_3192_0) + (csrd_frame_3192_1)) - 1024304373u); unsigned int csrd_frame_3192_3 = (((((3u * (csrd_frame_3192_2)) + 2246358550u)) + (2804166274u)) - 1024304373u); csrd_frame_3192_0 = (((csrd_frame_3192_3) - (csrd_frame_3192_1)) + 1024304373u); x = (247574007u * ((csrd_frame_3192_0) - 1024304373u)); register unsigned int sum = (247574007u * ((csrd_frame_3192_2) - 1024304373u)); (void)sum; unsigned int bias = (247574007u * ((csrd_frame_3192_3) - 1024304373u)); (void)bias

;
    record_event(sum);
    if (limit < 0) return x;
    while (limit-- > 0) {
        y = next_value(x);
        {
            unsigned int csrd_frame_3404_0 = ((70013365u * (x)) + 1890267816u); unsigned int csrd_frame_3404_1 = ((70013365u * (y)) + 1890267816u); unsigned int csrd_frame_3404_2 = ((70013365u * (bias)) + 1890267816u); unsigned int csrd_frame_3404_3 = ((70013365u * (sum)) + 1890267816u); csrd_frame_3404_0 = (((csrd_frame_3404_0) + (csrd_frame_3404_1)) - 1890267816u); unsigned int csrd_frame_3404_4 = (((csrd_frame_3404_2) + (((5u * (csrd_frame_3404_1)) + 1028863328u))) - 1890267816u); unsigned int csrd_frame_3404_5 = (((csrd_frame_3404_4) - (csrd_frame_3404_1)) + 1890267816u); csrd_frame_3404_2 = (((csrd_frame_3404_5) + (csrd_frame_3404_3)) - 1890267816u); x = (562615453u * ((csrd_frame_3404_0) - 1890267816u)); bias = (562615453u * ((csrd_frame_3404_2) - 1890267816u)); unsigned int x = (562615453u * ((csrd_frame_3404_4) - 1890267816u)); (void)x; unsigned int local = (562615453u * ((csrd_frame_3404_5) - 1890267816u)); (void)local


;
            record_event(x);
            { unsigned int csrd_frame_3564_0 = ((86910015u * (x)) + 312683391u); csrd_frame_3564_0 = (((csrd_frame_3564_0) + (921053496u)) - 312683391u); x = (988531647u * ((csrd_frame_3564_0) - 312683391u));}
            buffer[0] = x;
        }
        { unsigned int csrd_frame_3621_0 = ((3857843307u * (x)) + 3673637244u); unsigned int csrd_frame_3621_1 = ((3857843307u * (bias)) + 3673637244u); csrd_frame_3621_0 = (((csrd_frame_3621_0) + (csrd_frame_3621_1)) - 3673637244u); x = (300976195u * ((csrd_frame_3621_0) - 3673637244u));}
        record_event(y);
    }
    return x;
}
int region_outputs(uint32_t *buffer, uint32_t x, uint32_t y)
{
    unsigned int csrd_frame_3749_0 = ((2124566435u * (x)) + 3852111484u); unsigned int csrd_frame_3749_1 = ((2124566435u * (y)) + 3852111484u); unsigned int csrd_frame_3749_2 = 1315035215u; unsigned int csrd_frame_3749_3 = (((csrd_frame_3749_2) + (csrd_frame_3749_0)) - 3852111484u); csrd_frame_3749_0 = (((((3u * (csrd_frame_3749_3)) + 885711624u)) + (csrd_frame_3749_1)) - 3852111484u); csrd_frame_3749_1 = (((csrd_frame_3749_0) - (csrd_frame_3749_2)) + 3852111484u); x = (3799538699u * ((csrd_frame_3749_0) - 3852111484u)); y = (3799538699u * ((csrd_frame_3749_1) - 3852111484u)); register unsigned int pending = (3799538699u * ((csrd_frame_3749_2) - 3852111484u)); (void)pending; unsigned int mix = (3799538699u * ((csrd_frame_3749_3) - 3852111484u)); (void)mix


;
    record_event(x);
    {
        unsigned int csrd_frame_3892_0 = ((978390775u * (x)) + 3821281250u); unsigned int csrd_frame_3892_1 = (((csrd_frame_3892_0) + (2080082083u)) - 3821281250u); unsigned int y = (2609910471u * ((csrd_frame_3892_1) - 3821281250u)); (void)y;
        buffer[2] = y;
    }
    buffer[0] = y;
    buffer[1] = pending;
    return x == y;
}
