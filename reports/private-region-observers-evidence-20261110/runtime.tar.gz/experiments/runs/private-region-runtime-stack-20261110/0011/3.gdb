python
import sys
sys.path.insert(0,'/work/tools')
import gdb_region_trace
gdb_region_trace.main('/work/experiments/runs/private-region-runtime-stack-20261110/0011/3.config.json')
end
