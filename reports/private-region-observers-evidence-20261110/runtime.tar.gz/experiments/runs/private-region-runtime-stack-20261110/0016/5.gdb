python
import sys
sys.path.insert(0,'/work/tools')
import gdb_region_trace
gdb_region_trace.main('/work/experiments/runs/private-region-runtime-stack-20261110/0016/5.config.json')
end
