; 
(set-info :status unknown)
(declare-fun input_1 () (_ BitVec 32))
(declare-fun input_0 () (_ BitVec 32))
(declare-fun base_2 () Int)
(declare-fun initial_memory () (Array Int (_ BitVec 32)))
(assert
 (let ((?x24 (bvadd (bvadd (bvmul input_0 (_ bv4066321351 32)) (_ bv1024304373 32)) (bvadd (bvmul input_1 (_ bv4066321351 32)) (_ bv1024304373 32)))))
 (let ((?x32 (bvsub (bvsub (bvadd (bvadd (bvmul (bvsub ?x24 (_ bv1024304373 32)) (_ bv3 32)) (_ bv2246358550 32)) (_ bv2804166274 32)) (_ bv1024304373 32)) (_ bv1024304373 32))))
 (let ((?x15 (+ base_2 0)))
 (let ((?x35 (store initial_memory ?x15 (bvmul ?x32 (_ bv247574007 32)))))
 (let ((?x16 (store initial_memory ?x15 (bvadd (bvmul (bvadd input_0 input_1) (_ bv3 32)) (_ bv11 32)))))
 (or (and (distinct (_ bv0 32) (_ bv0 32)) true) (and (distinct ?x16 ?x35) true))))))))
(check-sat)
