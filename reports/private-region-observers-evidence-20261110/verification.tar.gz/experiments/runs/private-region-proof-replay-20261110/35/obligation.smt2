; 
(set-info :status unknown)
(declare-fun input_0 () (_ BitVec 32))
(declare-fun base_1 () Int)
(declare-fun initial_memory () (Array Int (_ BitVec 32)))
(assert
 (let ((?x21 (bvsub (bvsub (bvadd (bvadd (bvmul input_0 (_ bv978390775 32)) (_ bv3821281250 32)) (_ bv2080082083 32)) (_ bv3821281250 32)) (_ bv3821281250 32))))
 (let ((?x11 (+ base_1 0)))
 (let ((?x24 (store initial_memory ?x11 (bvmul ?x21 (_ bv2609910471 32)))))
 (let ((?x12 (store initial_memory ?x11 (bvadd input_0 (_ bv7 32)))))
 (or (and (distinct (_ bv0 32) (_ bv0 32)) true) (and (distinct ?x12 ?x24) true)))))))
(check-sat)
