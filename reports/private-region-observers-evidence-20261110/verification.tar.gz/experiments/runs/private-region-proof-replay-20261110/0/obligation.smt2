; 
(set-info :status unknown)
(declare-fun input_1 () (_ BitVec 32))
(declare-fun input_0 () (_ BitVec 32))
(declare-fun base_2 () Int)
(declare-fun initial_memory () (Array Int (_ BitVec 32)))
(assert
 (let ((?x16 (store initial_memory (+ base_2 0) (bvadd (bvmul (bvadd input_0 input_1) (_ bv3 32)) (_ bv11 32)))))
 (or (and (distinct (_ bv0 32) (_ bv0 32)) true) (and (distinct ?x16 ?x16) true))))
(check-sat)
