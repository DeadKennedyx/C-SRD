; 
(set-info :status unknown)
(declare-fun input_0 () (_ BitVec 32))
(declare-fun input_1 () (_ BitVec 32))
(declare-fun base_2 () Int)
(declare-fun initial_memory () (Array Int (_ BitVec 32)))
(assert
 (let ((?x10 (bvadd (_ bv17 32) input_0)))
 (let ((?x13 (bvadd (bvmul ?x10 (_ bv3 32)) input_1)))
 (let ((?x17 (store initial_memory (+ base_2 0) ?x10)))
 (let ((?x20 (store ?x17 (+ base_2 1) ?x13)))
 (let ((?x23 (store ?x20 (+ base_2 2) (bvsub ?x13 ?x10))))
 (or (and (distinct (_ bv0 32) (_ bv0 32)) true) (and (distinct ?x23 ?x23) true))))))))
(check-sat)
