; 
(set-info :status unknown)
(declare-fun input_1 () (_ BitVec 32))
(declare-fun input_0 () (_ BitVec 32))
(declare-fun base_2 () Int)
(declare-fun initial_memory () (Array Int (_ BitVec 32)))
(assert
 (let ((?x24 (bvadd (bvadd (bvmul input_0 (_ bv2704243427 32)) (_ bv887392971 32)) (bvadd (bvmul input_1 (_ bv2704243427 32)) (_ bv887392971 32)))))
 (let ((?x32 (bvsub (bvadd (bvsub (bvadd (bvmul (bvsub ?x24 (_ bv887392971 32)) (_ bv5 32)) (_ bv745395412 32)) (_ bv2637227776 32)) (_ bv887392971 32)) (_ bv887392971 32))))
 (let ((?x15 (+ base_2 0)))
 (let ((?x35 (store initial_memory ?x15 (bvmul ?x32 (_ bv4251949771 32)))))
 (let ((?x16 (store initial_memory ?x15 (bvsub (bvmul (bvadd input_0 input_1) (_ bv5 32)) (_ bv7 32)))))
 (or (and (distinct (_ bv0 32) (_ bv0 32)) true) (and (distinct ?x16 ?x35) true))))))))
(check-sat)
