; 
(set-info :status unknown)
(declare-fun input_1 () (_ BitVec 32))
(declare-fun input_0 () (_ BitVec 32))
(declare-fun base_2 () Int)
(declare-fun initial_memory () (Array Int (_ BitVec 32)))
(assert
 (let ((?x12 (store initial_memory (+ base_2 0) (bvadd input_0 input_1))))
 (or (and (distinct (_ bv0 32) (_ bv0 32)) true) (and (distinct ?x12 ?x12) true))))
(check-sat)
