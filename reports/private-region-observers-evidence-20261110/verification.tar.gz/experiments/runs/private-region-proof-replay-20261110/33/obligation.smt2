; 
(set-info :status unknown)
(declare-fun input_1 () (_ BitVec 32))
(declare-fun input_0 () (_ BitVec 32))
(declare-fun base_2 () Int)
(declare-fun initial_memory () (Array Int (_ BitVec 32)))
(assert
 (let ((?x20 (bvadd (bvadd (bvmul input_0 (_ bv3857843307 32)) (_ bv3673637244 32)) (bvadd (bvmul input_1 (_ bv3857843307 32)) (_ bv3673637244 32)))))
 (let ((?x11 (+ base_2 0)))
 (let ((?x25 (store initial_memory ?x11 (bvmul (bvsub (bvsub ?x20 (_ bv3673637244 32)) (_ bv3673637244 32)) (_ bv300976195 32)))))
 (let ((?x12 (store initial_memory ?x11 (bvadd input_0 input_1))))
 (or (and (distinct (_ bv0 32) (_ bv0 32)) true) (and (distinct ?x12 ?x25) true)))))))
(check-sat)
