#include <stdint.h>

uint32_t buffer_mix(uint32_t *p, uint32_t *q, uint32_t x)
{ (void)p; (void)q; unsigned int csrd_mem_0 = x; (void)csrd_mem_0; unsigned int csrd_mem_1 = ((p[0u]) + (csrd_mem_0)); (void)csrd_mem_1; unsigned int csrd_mem_2 = (((3u * (csrd_mem_1))) + (11u)); (void)csrd_mem_2; p[1u] = csrd_mem_2; unsigned int csrd_mem_3 = ((q[0u]) - (p[1u])); (void)csrd_mem_3; q[1u] = ((csrd_mem_3) + (csrd_mem_0)); return ((p[0u]) + (q[1u]));






}

uint32_t buffer_store(uint32_t *p, uint32_t *q, uint32_t x)
{ (void)p; (void)q; unsigned int csrd_mem_0 = x; (void)csrd_mem_0; p[0u] = ((csrd_mem_0) + (1u)); q[0u] = (((7u * (p[0u]))) - (3u)); return 19u;



}

uint32_t buffer_snapshot(uint32_t *p, uint32_t *q, uint32_t x)
{ (void)p; (void)q; unsigned int csrd_mem_0 = x; (void)csrd_mem_0; unsigned int csrd_mem_1 = p[0u]; (void)csrd_mem_1; q[0u] = csrd_mem_0; csrd_mem_0 = (3u * (csrd_mem_1)); return ((csrd_mem_0) + (p[0u]));




}

uint32_t buffer_boundary(uint32_t *p, uint32_t *q, uint32_t x)
{ (void)p; (void)q; unsigned int csrd_mem_0 = x; (void)csrd_mem_0; unsigned int csrd_mem_1 = ((p[15u]) + (csrd_mem_0)); (void)csrd_mem_1; q[15u] = (((4294967295u * (csrd_mem_1))) - (1u)); return ((q[15u]) + (p[15u]));



}

uint32_t buffer_unused(uint32_t *p, uint32_t *q, uint32_t x)
{ (void)p; (void)q; unsigned int csrd_mem_0 = x; (void)csrd_mem_0; return (((3u * (csrd_mem_0))) + (11u));



}

uint32_t buffer_const(const uint32_t *p, uint32_t *q, uint32_t x)
{ (void)p; (void)q; unsigned int csrd_mem_0 = x; (void)csrd_mem_0; unsigned int csrd_mem_1 = ((p[0u]) + (csrd_mem_0)); (void)csrd_mem_1; q[0u] = (17u * (csrd_mem_1)); return ((csrd_mem_1) + (p[0u]));



}
