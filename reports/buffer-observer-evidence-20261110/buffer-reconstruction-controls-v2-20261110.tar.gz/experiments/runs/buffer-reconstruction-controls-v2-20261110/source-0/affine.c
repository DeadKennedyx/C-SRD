#include <stdint.h>

uint32_t buffer_mix(uint32_t *p, uint32_t *q, uint32_t x)
{ (void)p; (void)q; unsigned int csrd_mem_0 = ((1920393167u * (x)) + 168565557u); (void)csrd_mem_0; unsigned int csrd_mem_1 = (((((1920393167u * (p[0u])) + 168565557u)) + (csrd_mem_0)) - 168565557u); (void)csrd_mem_1; unsigned int csrd_mem_2 = (((((3u * (csrd_mem_1)) + 3957836182u)) + (4113021210u)) - 168565557u); (void)csrd_mem_2; p[1u] = (3663578927u * ((csrd_mem_2) - 168565557u)); unsigned int csrd_mem_3 = (((((1920393167u * (q[0u])) + 168565557u)) - (((1920393167u * (p[1u])) + 168565557u))) + 168565557u); (void)csrd_mem_3; q[1u] = (3663578927u * (((((csrd_mem_3) + (csrd_mem_0)) - 168565557u)) - 168565557u)); return (3663578927u * (((((((1920393167u * (p[0u])) + 168565557u)) + (((1920393167u * (q[1u])) + 168565557u))) - 168565557u)) - 168565557u));






}

uint32_t buffer_store(uint32_t *p, uint32_t *q, uint32_t x)
{ (void)p; (void)q; unsigned int csrd_mem_0 = ((4089183019u * (x)) + 223872566u); (void)csrd_mem_0; p[0u] = (2931485571u * (((((csrd_mem_0) + (18088289u)) - 223872566u)) - 223872566u)); q[0u] = (2931485571u * (((((((7u * (((4089183019u * (p[0u])) + 223872566u))) + 2951731900u)) - (3901487031u)) + 223872566u)) - 223872566u)); return (2931485571u * ((608938599u) - 223872566u));



}

uint32_t buffer_snapshot(uint32_t *p, uint32_t *q, uint32_t x)
{ (void)p; (void)q; unsigned int csrd_mem_0 = ((655646763u * (x)) + 1333563453u); (void)csrd_mem_0; unsigned int csrd_mem_1 = ((655646763u * (p[0u])) + 1333563453u); (void)csrd_mem_1; q[0u] = (3410583171u * ((csrd_mem_0) - 1333563453u)); csrd_mem_0 = ((3u * (csrd_mem_1)) + 1627840390u); return (3410583171u * (((((csrd_mem_0) + (((655646763u * (p[0u])) + 1333563453u))) - 1333563453u)) - 1333563453u));




}

uint32_t buffer_boundary(uint32_t *p, uint32_t *q, uint32_t x)
{ (void)p; (void)q; unsigned int csrd_mem_0 = ((2104507413u * (x)) + 309397068u); (void)csrd_mem_0; unsigned int csrd_mem_1 = (((((2104507413u * (p[15u])) + 309397068u)) + (csrd_mem_0)) - 309397068u); (void)csrd_mem_1; q[15u] = (3053695805u * (((((((4294967295u * (csrd_mem_1)) + 618794136u)) - (2413904481u)) + 309397068u)) - 309397068u)); return (3053695805u * (((((((2104507413u * (q[15u])) + 309397068u)) + (((2104507413u * (p[15u])) + 309397068u))) - 309397068u)) - 309397068u));



}

uint32_t buffer_unused(uint32_t *p, uint32_t *q, uint32_t x)
{ (void)p; (void)q; unsigned int csrd_mem_0 = ((313952967u * (x)) + 2463217479u); (void)csrd_mem_0; return (2205488887u * (((((((3u * (csrd_mem_0)) + 3663499634u)) + (1621732820u)) - 2463217479u)) - 2463217479u));



}

uint32_t buffer_const(const uint32_t *p, uint32_t *q, uint32_t x)
{ (void)p; (void)q; unsigned int csrd_mem_0 = ((3688431955u * (x)) + 3512099262u); (void)csrd_mem_0; unsigned int csrd_mem_1 = (((((3688431955u * (p[0u])) + 3512099262u)) + (csrd_mem_0)) - 3512099262u); (void)csrd_mem_1; q[0u] = (3263359707u * ((((17u * (csrd_mem_1)) + 3935953952u)) - 3512099262u)); return (3263359707u * (((((csrd_mem_1) + (((3688431955u * (p[0u])) + 3512099262u))) - 3512099262u)) - 3512099262u));



}
