unsigned int buffer_store(unsigned int *p0, unsigned int *p1, unsigned int p2) {
    unsigned int v0 = (p2 * 4089183019u);
    unsigned int v1 = (v0 + 4089183019u);
    unsigned int v2 = (v1 * 2931485571u);
    p0[0] = v2;
    unsigned int v3 = p0[0];
    unsigned int v4 = (v3 * 4089183019u);
    unsigned int v5 = (v4 + 223872566u);
    unsigned int v6 = (v5 * 7u);
    unsigned int v7 = (v6 + 3345212165u);
    unsigned int v8 = (v7 * 2931485571u);
    p1[0] = (v8 + 1u);
    (void)p0;
    (void)p1;
    (void)p2;
    return 19u;
}
