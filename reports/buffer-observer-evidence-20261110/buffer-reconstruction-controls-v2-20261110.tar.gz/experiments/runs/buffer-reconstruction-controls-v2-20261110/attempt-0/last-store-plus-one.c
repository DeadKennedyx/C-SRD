unsigned int buffer_store(unsigned int *p0, unsigned int *p1, unsigned int p2) {
    unsigned int v0 = (p2 + 1u);
    p0[0] = v0;
    unsigned int v1 = p0[0];
    unsigned int v2 = (v1 * 7u);
    unsigned int v3 = (v2 - 3u);
    p1[0] = (v3 + 1u);
    (void)p0;
    (void)p1;
    (void)p2;
    return 19u;
}
