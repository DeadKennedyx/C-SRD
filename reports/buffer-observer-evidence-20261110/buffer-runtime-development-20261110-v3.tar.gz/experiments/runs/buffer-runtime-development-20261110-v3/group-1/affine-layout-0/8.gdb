python
import sys
sys.path.insert(0, '/work/tools')
import gdb_buffer_trace
gdb_buffer_trace.main('/work/experiments/runs/buffer-runtime-development-20261110-v3/group-1/affine-layout-0/8.json')
end
