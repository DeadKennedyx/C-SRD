unsigned int buffer_update(unsigned int *p0, const unsigned int *p1, unsigned int p2) {
    unsigned int v0 = (p2 * 2954399347u);
    unsigned int v1 = (v0 + 4177587874u);
    unsigned int v2 = p1[0];
    unsigned int v3 = (v2 * 2954399347u);
    unsigned int v4 = (v1 + v3);
    unsigned int v5 = (v4 * 3u);
    unsigned int v6 = (v5 + 2668380589u);
    unsigned int v7 = (v6 * 2630993595u);
    unsigned int v8 = (v7 + 3648938922u);
    p0[1] = v8;
    unsigned int v9 = p0[0];
    unsigned int v10 = (v9 * 2954399347u);
    unsigned int v11 = (v10 + v6);
    unsigned int v12 = (v11 * 2630993595u);
    unsigned int v13 = (v12 + 3648938922u);
    (void)p0;
    (void)p1;
    (void)p2;
    return v13;
}
