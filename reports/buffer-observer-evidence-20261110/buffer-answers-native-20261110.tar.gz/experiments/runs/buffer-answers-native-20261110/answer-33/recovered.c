unsigned int buffer_unused(unsigned int *p0, unsigned int *p1, unsigned int p2) {
    unsigned int v0 = (p2 * 313952967u);
    unsigned int v1 = (v0 + 2463217479u);
    unsigned int v2 = (v1 * 2321499365u);
    unsigned int v3 = (v2 + 2891919752u);
    (void)p0;
    (void)p1;
    (void)p2;
    return v3;
}
