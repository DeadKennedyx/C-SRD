unsigned int buffer_mix(unsigned int *p0, unsigned int *p1, unsigned int p2) {
    unsigned int v0 = p0[0];
    unsigned int v1 = (v0 + p2);
    unsigned int v2 = (v1 * 3u);
    unsigned int v3 = (v2 + 11u);
    p0[1] = v3;
    unsigned int v4 = p1[0];
    unsigned int v5 = (v4 - v3);
    unsigned int v6 = (v5 + p2);
    p1[1] = v6;
    unsigned int v7 = p0[0];
    unsigned int v8 = (v6 + v7);
    (void)p0;
    (void)p1;
    (void)p2;
    return v8;
}
