unsigned int buffer_mix(unsigned int *p0, unsigned int *p1, unsigned int p2) {
    unsigned int v0 = (p2 * 1920393167u);
    unsigned int v1 = (v0 + 168565557u);
    unsigned int v2 = p0[0];
    unsigned int v3 = (v2 * 1920393167u);
    unsigned int v4 = (v1 + v3);
    unsigned int v5 = (v4 * 3u);
    unsigned int v6 = (v5 + 3607324539u);
    unsigned int v7 = (v6 * 3663578927u);
    unsigned int v8 = (v7 + 3126840901u);
    p0[1] = v8;
    unsigned int v9 = p1[0];
    unsigned int v10 = p0[1];
    unsigned int v11 = (v9 - v10);
    unsigned int v12 = (v11 * 1920393167u);
    unsigned int v13 = (v12 + 168565557u);
    unsigned int v14 = (v13 + v1);
    unsigned int v15 = (v14 * 3663578927u);
    unsigned int v16 = (v15 + 1958714506u);
    p1[1] = v16;
    unsigned int v17 = p0[0];
    unsigned int v18 = p1[1];
    unsigned int v19 = (v17 + v18);
    (void)p0;
    (void)p1;
    (void)p2;
    return v19;
}
