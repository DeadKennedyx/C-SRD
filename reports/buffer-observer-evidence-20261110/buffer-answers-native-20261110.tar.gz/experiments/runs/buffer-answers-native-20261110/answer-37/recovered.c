unsigned int buffer_boundary(unsigned int *p0, unsigned int *p1, unsigned int p2) {
    unsigned int v0 = p0[15];
    unsigned int v1 = (v0 + p2);
    unsigned int v2 = (4294967295u - v1);
    p1[15] = v2;
    unsigned int v3 = p0[15];
    unsigned int v4 = (v3 + v2);
    (void)p0;
    (void)p1;
    (void)p2;
    return v4;
}
