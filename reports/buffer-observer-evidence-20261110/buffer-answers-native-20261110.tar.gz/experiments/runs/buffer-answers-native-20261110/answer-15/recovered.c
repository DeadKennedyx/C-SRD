unsigned int buffer_snapshot(unsigned int *p0, unsigned int *p1, unsigned int p2) {
    unsigned int v0 = p0[0];
    unsigned int v1 = (v0 * 655646763u);
    unsigned int v2 = (v1 + 1333563453u);
    p1[0] = p2;
    unsigned int v3 = (v2 * 3u);
    unsigned int v4 = p0[0];
    unsigned int v5 = (v4 * 655646763u);
    unsigned int v6 = (v3 + v5);
    unsigned int v7 = (v6 + 294276937u);
    unsigned int v8 = (v7 * 3410583171u);
    (void)p0;
    (void)p1;
    (void)p2;
    return v8;
}
