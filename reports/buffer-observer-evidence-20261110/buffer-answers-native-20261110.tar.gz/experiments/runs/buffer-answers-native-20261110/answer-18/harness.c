#include <limits.h>
#include <stdint.h>
_Static_assert(sizeof(int) * CHAR_BIT == 32, "C-SRD requires 32-bit int");
_Static_assert(sizeof(unsigned int) * CHAR_BIT == 32, "C-SRD requires 32-bit unsigned int");
_Static_assert(_Generic((uint32_t)0, unsigned int: 1, default: 0),
               "C-SRD requires uint32_t to be unsigned int");
#include <stdint.h>
#include <inttypes.h>
#include <stdio.h>
uint32_t csrd_observation_memory[64];
uint32_t buffer_mix(uint32_t*,uint32_t*,uint32_t);

int main(void){
    unsigned int p,q; uint32_t x;
    if(scanf("%u %u %" SCNu32,&p,&q,&x)!=3 || p>48u || q>48u)return 2;
    for(unsigned int i=0;i<64u;++i)if(scanf("%" SCNu32,&csrd_observation_memory[i])!=1)return 3;
    uint32_t result=buffer_mix(csrd_observation_memory+p,csrd_observation_memory+q,x);

    printf("%" PRIu32 "\n",result);
    for(unsigned int i=0;i<64u;++i)printf("%" PRIu32 "\n",csrd_observation_memory[i]);
    return 0;
}
