unsigned int buffer_mix(unsigned int *p0, unsigned int *p1, unsigned int p2) {
    unsigned int v0 = p0[0];
    unsigned int v1 = (v0 * 1920393167u);
    unsigned int v2 = (p2 * 1920393167u);
    unsigned int v3 = (v1 + v2);
    unsigned int v4 = (v3 + 168565557u);
    unsigned int v5 = (v4 * 2400802189u);
    unsigned int v6 = (v5 + 790588122u);
    unsigned int v7 = (v4 * 4294967293u);
    p0[1] = v6;
    unsigned int v8 = p1[0];
    unsigned int v9 = (v8 + p2);
    unsigned int v10 = (v9 * 1920393167u);
    unsigned int v11 = (v7 + v10);
    unsigned int v12 = (v11 * 3663578927u);
    unsigned int v13 = (v12 + 3504379174u);
    p1[1] = v13;
    unsigned int v14 = p0[0];
    unsigned int v15 = (v14 * 1920393167u);
    unsigned int v16 = (v11 + v15);
    unsigned int v17 = (v16 * 3663578927u);
    unsigned int v18 = (v17 + 3504379174u);
    (void)p0;
    (void)p1;
    (void)p2;
    return v18;
}
