unsigned int buffer_mix(unsigned int *p0, unsigned int *p1, unsigned int p2) {
    unsigned int v0 = p0[0];
    unsigned int v1 = (p2 * 1920393167u);
    unsigned int v2 = (v0 * 1920393167u);
    unsigned int v3 = (v2 + 168565557u);
    unsigned int v4 = (v3 + v1);
    unsigned int v5 = (v1 + 337131114u);
    unsigned int v6 = (v4 * 2400802189u);
    unsigned int v7 = (v6 + 790588122u);
    p0[1] = v7;
    unsigned int v8 = p1[0];
    unsigned int v9 = (v8 - v7);
    unsigned int v10 = (v9 * 1920393167u);
    unsigned int v11 = (v5 + v10);
    unsigned int v12 = (v11 * 3663578927u);
    unsigned int v13 = (v12 + 1958714506u);
    p1[1] = v13;
    unsigned int v14 = p0[0];
    unsigned int v15 = (v13 + v14);
    (void)p0;
    (void)p1;
    (void)p2;
    return v15;
}
