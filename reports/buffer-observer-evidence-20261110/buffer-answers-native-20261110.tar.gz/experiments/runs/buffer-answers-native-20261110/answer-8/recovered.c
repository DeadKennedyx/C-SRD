unsigned int buffer_boundary(unsigned int *p0, unsigned int *p1, unsigned int p2) {
    unsigned int v0 = (p2 * 2104507413u);
    unsigned int v1 = (v0 + 309397068u);
    unsigned int v2 = p0[15];
    unsigned int v3 = (v2 * 2104507413u);
    unsigned int v4 = (v3 + v1);
    unsigned int v5 = (2499856951u - v4);
    unsigned int v6 = (v5 * 3053695805u);
    p1[15] = v6;
    unsigned int v7 = p1[15];
    unsigned int v8 = (v7 * 2104507413u);
    unsigned int v9 = p0[15];
    unsigned int v10 = (v9 * 2104507413u);
    unsigned int v11 = (v8 + v10);
    unsigned int v12 = (v11 * 3053695805u);
    (void)p0;
    (void)p1;
    (void)p2;
    return v12;
}
