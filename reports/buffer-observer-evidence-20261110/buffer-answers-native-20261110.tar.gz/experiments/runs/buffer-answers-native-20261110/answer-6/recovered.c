unsigned int buffer_unused(unsigned int *p0, unsigned int *p1, unsigned int p2) {
    unsigned int v0 = (p2 * 3u);
    unsigned int v1 = (v0 + 11u);
    (void)p0;
    (void)p1;
    (void)p2;
    return v1;
}
