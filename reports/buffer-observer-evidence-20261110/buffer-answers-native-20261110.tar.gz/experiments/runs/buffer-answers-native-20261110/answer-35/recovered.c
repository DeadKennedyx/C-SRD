unsigned int buffer_const(const unsigned int *p0, unsigned int *p1, unsigned int p2) {
    unsigned int v0 = (p2 * 3688431955u);
    unsigned int v1 = (v0 + 3512099262u);
    unsigned int v2 = p0[0];
    unsigned int v3 = (v2 * 3688431955u);
    unsigned int v4 = (v1 + v3);
    unsigned int v5 = (v4 * 3937507467u);
    unsigned int v6 = (v5 + 3417447894u);
    p1[0] = v6;
    unsigned int v7 = p0[0];
    unsigned int v8 = (v7 * 3688431955u);
    unsigned int v9 = (v8 + v4);
    unsigned int v10 = (v9 * 3263359707u);
    unsigned int v11 = (v10 + 1464252022u);
    (void)p0;
    (void)p1;
    (void)p2;
    return v11;
}
