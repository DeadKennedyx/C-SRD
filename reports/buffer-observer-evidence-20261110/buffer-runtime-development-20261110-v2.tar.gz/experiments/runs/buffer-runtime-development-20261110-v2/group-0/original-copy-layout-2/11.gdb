python
import sys
sys.path.insert(0, '/work/tools')
import gdb_buffer_trace
gdb_buffer_trace.main('/work/experiments/runs/buffer-runtime-development-20261110-v2/group-0/original-copy-layout-2/11.json')
end
