unsigned int buffer_update(unsigned int *p0, const unsigned int *p1, unsigned int p2) {
    unsigned int v0 = p1[0];
    unsigned int v1 = p0[0];
    unsigned int v2 = (v0 + p2);
    unsigned int v3 = (v2 * 3u);
    unsigned int v4 = (v3 + 11u);
    unsigned int v5 = (v4 + v1);
    p0[1] = v4;
    (void)p0;
    (void)p1;
    (void)p2;
    return (v5 + 1u);
}
