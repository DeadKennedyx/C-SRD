#include <stdint.h>

uint32_t buffer_update(uint32_t *p, const uint32_t *q, uint32_t x)
{ (void)p; (void)q; unsigned int csrd_mem_0 = ((2954399347u * (x)) + 4177587874u); (void)csrd_mem_0; unsigned int csrd_mem_1 = (((((2954399347u * (q[0u])) + 4177587874u)) + (csrd_mem_0)) - 4177587874u); (void)csrd_mem_1; unsigned int csrd_mem_2 = (((((3u * (csrd_mem_1)) + 234758844u)) + (2316242323u)) - 4177587874u); (void)csrd_mem_2; p[1u] = (2630993595u * ((csrd_mem_2) - 4177587874u)); return (2630993595u * (((((((2954399347u * (p[0u])) + 4177587874u)) + (csrd_mem_2)) - 4177587874u)) - 4177587874u));




}
