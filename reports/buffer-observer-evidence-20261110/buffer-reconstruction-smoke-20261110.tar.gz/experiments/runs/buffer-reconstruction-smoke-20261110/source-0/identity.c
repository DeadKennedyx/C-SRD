#include <stdint.h>

uint32_t buffer_update(uint32_t *p, const uint32_t *q, uint32_t x)
{ (void)p; (void)q; unsigned int csrd_mem_0 = x; (void)csrd_mem_0; unsigned int csrd_mem_1 = ((q[0u]) + (csrd_mem_0)); (void)csrd_mem_1; unsigned int csrd_mem_2 = (((3u * (csrd_mem_1))) + (11u)); (void)csrd_mem_2; p[1u] = csrd_mem_2; return ((p[0u]) + (csrd_mem_2));




}
