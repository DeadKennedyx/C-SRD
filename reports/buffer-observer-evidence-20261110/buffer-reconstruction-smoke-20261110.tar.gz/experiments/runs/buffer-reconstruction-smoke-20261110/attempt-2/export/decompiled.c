
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

uint buffer_update(uint *p0,uint *p1,uint p2)

{
  uint uVar1;
  
  uVar1 = *p1;
  p0[1] = (uVar1 + p2) * 3 + 0xb;
  return ((uVar1 + p2) * 0x1049ab59 + *p0 * -0x4fe7718d) * -0x632e3945 + 0xb;
}

