unsigned int buffer_update(unsigned int *p0, const unsigned int *p1, unsigned int p2) {
    unsigned int v0 = p1[0];
    unsigned int v1 = p0[0];
    unsigned int v2 = (v0 + p2);
    unsigned int v3 = (v2 * 273263449u);
    unsigned int v4 = (v2 * 3u);
    unsigned int v5 = (v1 * 2954399347u);
    unsigned int v6 = (v3 + v5);
    unsigned int v7 = (v4 + 11u);
    p0[1] = v7;
    unsigned int v8 = (v6 * 2630993595u);
    unsigned int v9 = (v8 + 11u);
    (void)p0;
    (void)p1;
    (void)p2;
    return (v9 + 1u);
}
