
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

uint buffer_update(uint *p0,uint *p1,uint p2)

{
  int iVar1;
  
  iVar1 = (p2 + *p1) * 0x1049ab59 + -0x75f0f26d;
  p0[1] = iVar1 * -0x632e3945 + 0xd97e63aa;
  return (iVar1 + *p0 * -0x4fe7718d) * -0x632e3945 + 0xd97e63aa;
}

