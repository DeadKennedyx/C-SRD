unsigned int buffer_update(unsigned int *p0, const unsigned int *p1, unsigned int p2) {
    unsigned int v0 = p1[0];
    unsigned int v1 = (p2 + v0);
    unsigned int v2 = p0[0];
    unsigned int v3 = (v1 * 273263449u);
    unsigned int v4 = (v3 + 2316242323u);
    unsigned int v5 = (v2 * 2954399347u);
    unsigned int v6 = (v4 + v5);
    unsigned int v7 = (v4 * 2630993595u);
    unsigned int v8 = (v7 + 3648938922u);
    p0[1] = v8;
    unsigned int v9 = (v6 * 2630993595u);
    unsigned int v10 = (v9 + 3648938922u);
    (void)p0;
    (void)p1;
    (void)p2;
    return (v10 + 1u);
}
