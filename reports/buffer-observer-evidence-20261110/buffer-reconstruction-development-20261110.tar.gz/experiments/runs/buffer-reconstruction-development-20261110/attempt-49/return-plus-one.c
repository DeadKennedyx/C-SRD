unsigned int buffer_snapshot(unsigned int *p0, unsigned int *p1, unsigned int p2) {
    unsigned int v0 = (p2 * 655646763u);
    unsigned int v1 = (v0 + 1333563453u);
    unsigned int v2 = p0[0];
    unsigned int v3 = (v2 * 655646763u);
    unsigned int v4 = (v3 + 1333563453u);
    unsigned int v5 = (v1 * 3410583171u);
    unsigned int v6 = (v5 + 367446729u);
    p1[0] = v6;
    unsigned int v7 = (v4 * 3u);
    unsigned int v8 = (v7 + 1627840390u);
    unsigned int v9 = p0[0];
    unsigned int v10 = (v9 * 655646763u);
    unsigned int v11 = (v10 + v8);
    unsigned int v12 = (v11 * 3410583171u);
    unsigned int v13 = (v12 + 367446729u);
    (void)p0;
    (void)p1;
    (void)p2;
    return (v13 + 1u);
}
