
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

uint buffer_snapshot(uint *p0,uint *p1,uint p2)

{
  uint uVar1;
  
  uVar1 = *p0;
  *p1 = (p2 * 0x2714602b + 0x4f7c903d) * -0x34b6a17d + 0x15e6cac9;
  return (*p0 * 0x2714602b + (uVar1 * 0x2714602b + 0x4f7c903d) * 3 + 0x6106df86) * -0x34b6a17d +
         0x15e6cac9;
}

