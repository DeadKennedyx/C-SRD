
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

uint buffer_boundary(uint *p0,uint *p1,uint p2)

{
  p1[0xf] = ~(p2 + p0[0xf]);
  return p1[0xf] + p0[0xf];
}

