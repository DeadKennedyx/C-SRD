unsigned int buffer_mix(unsigned int *p0, unsigned int *p1, unsigned int p2) {
    unsigned int v0 = p0[0];
    unsigned int v1 = (v0 + p2);
    unsigned int v2 = (v1 * 3u);
    unsigned int v3 = (v2 + 11u);
    p0[1] = (v3 + 1u);
    unsigned int v4 = p1[0];
    unsigned int v5 = p0[1];
    unsigned int v6 = (v4 - v5);
    unsigned int v7 = (v6 + p2);
    p1[1] = (v7 + 1u);
    unsigned int v8 = p0[0];
    unsigned int v9 = p1[1];
    unsigned int v10 = (v8 + v9);
    (void)p0;
    (void)p1;
    (void)p2;
    return v10;
}
