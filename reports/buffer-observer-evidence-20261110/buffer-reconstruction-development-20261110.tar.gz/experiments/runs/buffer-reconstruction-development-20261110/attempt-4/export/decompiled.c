
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

uint buffer_mix(uint *p0,uint *p1,uint p2)

{
  p0[1] = (*p0 + p2) * 3 + 0xb;
  p1[1] = (*p1 - p0[1]) + p2;
  return *p0 + p1[1];
}

