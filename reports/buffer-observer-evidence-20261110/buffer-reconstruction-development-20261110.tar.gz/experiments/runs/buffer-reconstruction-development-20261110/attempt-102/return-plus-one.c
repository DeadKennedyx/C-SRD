unsigned int buffer_const(const unsigned int *p0, unsigned int *p1, unsigned int p2) {
    unsigned int v0 = (p2 * 3688431955u);
    unsigned int v1 = (v0 + 3512099262u);
    unsigned int v2 = p0[0];
    unsigned int v3 = (v2 * 3688431955u);
    unsigned int v4 = (v3 + v1);
    unsigned int v5 = (v4 * 17u);
    unsigned int v6 = (v5 + 423854690u);
    unsigned int v7 = (v6 * 3263359707u);
    p1[0] = v7;
    unsigned int v8 = p0[0];
    unsigned int v9 = (v8 * 3688431955u);
    unsigned int v10 = (v4 + v9);
    unsigned int v11 = (v10 + 782868034u);
    unsigned int v12 = (v11 * 3263359707u);
    (void)p0;
    (void)p1;
    (void)p2;
    return (v12 + 1u);
}
