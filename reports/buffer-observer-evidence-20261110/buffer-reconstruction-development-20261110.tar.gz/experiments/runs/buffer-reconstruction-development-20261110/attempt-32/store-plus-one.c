unsigned int buffer_snapshot(unsigned int *p0, unsigned int *p1, unsigned int p2) {
    unsigned int v0 = p0[0];
    p1[0] = (p2 + 1u);
    unsigned int v1 = (v0 * 3u);
    unsigned int v2 = p0[0];
    unsigned int v3 = (v1 + v2);
    (void)p0;
    (void)p1;
    (void)p2;
    return v3;
}
