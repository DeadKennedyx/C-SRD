
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

uint buffer_mix(uint *p0,uint *p1,uint p2)

{
  int iVar1;
  
  iVar1 = *p0 * 0x7276dfcf + p2 * 0x7276dfcf + 0xa0c1b35;
  p0[1] = iVar1 * -0x70e6aa73 + 0x2f1f6ada;
  iVar1 = iVar1 * -3 + (*p1 + p2) * 0x7276dfcf;
  p1[1] = iVar1 * -0x25a238d1 + 0xd0e09526;
  return (iVar1 + *p0 * 0x7276dfcf) * -0x25a238d1 + 0xd0e09526;
}

