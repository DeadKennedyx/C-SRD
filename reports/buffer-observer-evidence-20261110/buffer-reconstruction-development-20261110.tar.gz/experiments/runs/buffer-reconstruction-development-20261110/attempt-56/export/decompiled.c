
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

uint buffer_mix(uint *p0,uint *p1,uint p2)

{
  uint uVar1;
  
  uVar1 = (*p0 + p2) * 3 + 0xb;
  p0[1] = uVar1;
  uVar1 = (*p1 - uVar1) + p2;
  p1[1] = uVar1;
  return uVar1 + *p0;
}

