unsigned int buffer_const(const unsigned int *p0, unsigned int *p1, unsigned int p2) {
    unsigned int v0 = p0[0];
    unsigned int v1 = (v0 + p2);
    unsigned int v2 = (v1 * 17u);
    p1[0] = (v2 + 1u);
    unsigned int v3 = p0[0];
    unsigned int v4 = (v3 + v1);
    (void)p0;
    (void)p1;
    (void)p2;
    return v4;
}
