
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

uint buffer_const(uint *p0,uint *p1,uint p2)

{
  uint uVar1;
  
  uVar1 = *p0;
  *p1 = (uVar1 + p2) * 0x11;
  return *p0 + uVar1 + p2;
}

