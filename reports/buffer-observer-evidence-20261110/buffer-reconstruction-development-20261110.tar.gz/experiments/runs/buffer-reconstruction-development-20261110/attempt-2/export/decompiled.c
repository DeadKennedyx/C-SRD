
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

uint buffer_store(uint *p0,uint *p1,uint p2)

{
  *p0 = (p2 * -0xc4404d5 + -0xc4404d5) * -0x5145147d;
  *p1 = ((*p0 * -0xc4404d5 + 0xd580636) * 7 + -0x389c1cfb) * -0x5145147d;
  return 0x13;
}

