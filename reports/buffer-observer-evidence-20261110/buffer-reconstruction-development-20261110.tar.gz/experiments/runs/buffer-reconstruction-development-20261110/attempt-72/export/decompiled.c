
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

uint buffer_update(uint *p0,uint *p1,uint p2)

{
  uint uVar1;
  
  uVar1 = (p2 + *p1) * 3 + 0xb;
  p0[1] = uVar1;
  return *p0 + uVar1;
}

