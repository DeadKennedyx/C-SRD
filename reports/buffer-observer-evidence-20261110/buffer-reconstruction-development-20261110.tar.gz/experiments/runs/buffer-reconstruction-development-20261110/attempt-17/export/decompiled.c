
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

uint buffer_boundary(uint *p0,uint *p1,uint p2)

{
  p1[0xf] = (-0x6aff35c9 - (p0[0xf] * 0x7d703c15 + p2 * 0x7d703c15 + 0x1271064c)) * -0x49fc4cc3;
  return (p1[0xf] * 0x7d703c15 + p0[0xf] * 0x7d703c15) * -0x49fc4cc3;
}

