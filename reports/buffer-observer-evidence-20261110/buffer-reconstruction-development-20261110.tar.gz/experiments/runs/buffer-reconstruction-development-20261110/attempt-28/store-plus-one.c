unsigned int buffer_store(unsigned int *p0, unsigned int *p1, unsigned int p2) {
    unsigned int v0 = (p2 + 1u);
    p0[0] = (v0 + 1u);
    unsigned int v1 = (v0 * 7u);
    unsigned int v2 = (v1 - 3u);
    p1[0] = (v2 + 1u);
    (void)p0;
    (void)p1;
    (void)p2;
    return 19u;
}
