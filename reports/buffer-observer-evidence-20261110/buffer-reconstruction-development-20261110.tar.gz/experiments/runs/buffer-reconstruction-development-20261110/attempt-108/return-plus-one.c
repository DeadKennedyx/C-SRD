unsigned int buffer_boundary(unsigned int *p0, unsigned int *p1, unsigned int p2) {
    unsigned int v0 = (p2 * 2104507413u);
    unsigned int v1 = (v0 + 309397068u);
    unsigned int v2 = p0[15];
    unsigned int v3 = (v2 * 2104507413u);
    unsigned int v4 = (v1 + v3);
    unsigned int v5 = (v4 * 1241271491u);
    unsigned int v6 = (v5 + 2268701723u);
    p1[15] = v6;
    unsigned int v7 = p1[15];
    unsigned int v8 = p0[15];
    unsigned int v9 = (v7 + v8);
    (void)p0;
    (void)p1;
    (void)p2;
    return (v9 + 1u);
}
