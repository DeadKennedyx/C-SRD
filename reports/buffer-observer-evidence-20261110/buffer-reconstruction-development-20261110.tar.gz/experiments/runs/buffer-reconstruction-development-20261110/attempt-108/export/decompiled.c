
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

uint buffer_boundary(uint *p0,uint *p1,uint p2)

{
  p1[0xf] = (p2 * 0x7d703c15 + 0x1271064c + p0[0xf] * 0x7d703c15) * 0x49fc4cc3 + 0x8739a41b;
  return p1[0xf] + p0[0xf];
}

