
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

uint buffer_mix(uint *p0,uint *p1,uint p2)

{
  int iVar1;
  
  iVar1 = p2 * 0x7276dfcf + 0xa0c1b35;
  p0[1] = ((*p0 * 0x7276dfcf + iVar1) * 3 + -0x3308b3ba) * -0x25a238d1;
  p1[1] = ((*p1 * 0x7276dfcf - (p0[1] * 0x7276dfcf + 0xa0c1b35)) + iVar1) * -0x25a238d1;
  return (*p0 * 0x7276dfcf + p1[1] * 0x7276dfcf) * -0x25a238d1;
}

