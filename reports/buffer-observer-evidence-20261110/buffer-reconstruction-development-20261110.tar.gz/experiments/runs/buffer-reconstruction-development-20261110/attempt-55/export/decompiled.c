
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

uint buffer_update(uint *p0,uint *p1,uint p2)

{
  int iVar1;
  
  iVar1 = (*p1 * -0x4fe7718d + p2 * -0x4fe7718d + -0x6ff115e) * 3;
  p0[1] = (iVar1 + -0x59f4acf5) * -0x632e3945;
  return (*p0 * -0x4fe7718d + iVar1 + -0x59f4acf5) * -0x632e3945;
}

