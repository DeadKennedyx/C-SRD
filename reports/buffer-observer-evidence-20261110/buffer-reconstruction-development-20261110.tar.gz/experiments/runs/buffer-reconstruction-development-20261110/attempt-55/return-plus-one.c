unsigned int buffer_update(unsigned int *p0, const unsigned int *p1, unsigned int p2) {
    unsigned int v0 = (p2 * 2954399347u);
    unsigned int v1 = (v0 + 4177587874u);
    unsigned int v2 = p1[0];
    unsigned int v3 = (v2 * 2954399347u);
    unsigned int v4 = (v3 + v1);
    unsigned int v5 = (v4 * 3u);
    unsigned int v6 = (v5 + 2785760011u);
    unsigned int v7 = (v6 * 2630993595u);
    p0[1] = v7;
    unsigned int v8 = p0[0];
    unsigned int v9 = (v8 * 2954399347u);
    unsigned int v10 = (v9 + v5);
    unsigned int v11 = (v10 + 2785760011u);
    unsigned int v12 = (v11 * 2630993595u);
    (void)p0;
    (void)p1;
    (void)p2;
    return (v12 + 1u);
}
