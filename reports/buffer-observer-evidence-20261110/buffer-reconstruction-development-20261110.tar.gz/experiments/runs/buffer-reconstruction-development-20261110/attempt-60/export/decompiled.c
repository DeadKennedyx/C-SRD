
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

uint buffer_store(uint *p0,uint *p1,uint p2)

{
  *p0 = (p2 * -0xc4404d5 + 0xd580636) * -0x5145147d + 0x2705405f;
  *p1 = *p0 * 7 - 3;
  return 0x13;
}

