unsigned int buffer_store(unsigned int *p0, unsigned int *p1, unsigned int p2) {
    unsigned int v0 = (p2 * 4089183019u);
    unsigned int v1 = (v0 + 223872566u);
    unsigned int v2 = (v1 * 2931485571u);
    unsigned int v3 = (v2 + 654655583u);
    p0[0] = v3;
    unsigned int v4 = p0[0];
    unsigned int v5 = (v4 * 7u);
    unsigned int v6 = (v5 - 3u);
    p1[0] = v6;
    (void)p0;
    (void)p1;
    (void)p2;
    return (19u + 1u);
}
