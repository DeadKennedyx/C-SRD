
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

uint buffer_unused(uint *p0,uint *p1,uint p2)

{
  return p2 * 3 + 0xb;
}

