
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

uint buffer_store(uint *p0,uint *p1,uint p2)

{
  *p0 = p2 + 1;
  *p1 = *p0 * 7 - 3;
  return 0x13;
}

