
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

uint buffer_snapshot(uint *p0,uint *p1,uint p2)

{
  uint uVar1;
  
  uVar1 = *p0;
  *p1 = p2;
  return ((uVar1 * 0x2714602b + 0x4f7c903d) * 3 + *p0 * 0x2714602b + 0x118a4f49) * -0x34b6a17d;
}

