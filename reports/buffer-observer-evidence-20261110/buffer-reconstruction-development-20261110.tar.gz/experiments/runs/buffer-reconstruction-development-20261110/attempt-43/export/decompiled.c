
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

uint buffer_mix(uint *p0,uint *p1,uint p2)

{
  int iVar1;
  
  iVar1 = p2 * 0x7276dfcf + 0xa0c1b35;
  p0[1] = ((iVar1 + *p0 * 0x7276dfcf) * 3 + -0x28fc9885) * -0x25a238d1 + 0xba5fce45;
  p1[1] = ((*p1 - p0[1]) * 0x7276dfcf + 0xa0c1b35 + iVar1) * -0x25a238d1 + 0x74bf9c8a;
  return *p0 + p1[1];
}

