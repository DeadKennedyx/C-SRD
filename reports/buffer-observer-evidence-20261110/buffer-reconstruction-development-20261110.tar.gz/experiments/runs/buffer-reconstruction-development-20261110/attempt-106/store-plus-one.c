unsigned int buffer_snapshot(unsigned int *p0, unsigned int *p1, unsigned int p2) {
    unsigned int v0 = p0[0];
    p1[0] = (p2 + 1u);
    unsigned int v1 = p0[0];
    unsigned int v2 = (v0 * 1966940289u);
    unsigned int v3 = (v1 * 655646763u);
    unsigned int v4 = (v2 + v3);
    unsigned int v5 = (v4 * 3410583171u);
    (void)p0;
    (void)p1;
    (void)p2;
    return v5;
}
