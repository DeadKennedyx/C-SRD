
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

uint buffer_const(uint *p0,uint *p1,uint p2)

{
  int iVar1;
  
  iVar1 = (p2 + *p0) * -0x2426fead + -0x2ea99e42;
  *p1 = iVar1 * -0x154e6775 + 0xcbb21dd6;
  return (iVar1 + *p0 * -0x2426fead) * -0x3d7d1525 + 0x5746b676;
}

