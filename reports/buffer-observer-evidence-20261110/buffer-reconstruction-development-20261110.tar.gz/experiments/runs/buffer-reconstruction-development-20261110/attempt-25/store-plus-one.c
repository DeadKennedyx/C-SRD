unsigned int buffer_const(const unsigned int *p0, unsigned int *p1, unsigned int p2) {
    unsigned int v0 = p0[0];
    unsigned int v1 = (p2 + v0);
    unsigned int v2 = (v1 * 3688431955u);
    unsigned int v3 = (v2 + 3512099262u);
    unsigned int v4 = (v3 * 3937507467u);
    unsigned int v5 = (v4 + 3417447894u);
    p1[0] = (v5 + 1u);
    unsigned int v6 = p0[0];
    unsigned int v7 = (v6 * 3688431955u);
    unsigned int v8 = (v3 + v7);
    unsigned int v9 = (v8 * 3263359707u);
    unsigned int v10 = (v9 + 1464252022u);
    (void)p0;
    (void)p1;
    (void)p2;
    return v10;
}
