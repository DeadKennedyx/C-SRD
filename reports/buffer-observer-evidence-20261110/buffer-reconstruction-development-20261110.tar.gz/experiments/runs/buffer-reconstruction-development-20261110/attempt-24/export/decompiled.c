
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

uint buffer_const(uint *p0,uint *p1,uint p2)

{
  uint uVar1;
  
  uVar1 = *p0;
  *p1 = (p2 + uVar1) * 0x11;
  return p2 + uVar1 + *p0;
}

