
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

uint buffer_unused(uint *p0,uint *p1,uint p2)

{
  return ((p2 * 0x12b68ac7 + -0x6d2e48b9) * 3 + 0x1562d0b8) * -0x7c8ae909;
}

