"""Package completed data without changing the original trials or summaries."""
from pathlib import Path
import datetime
import hashlib
import json
import shutil
import statistics
import tarfile

root = Path(__file__).resolve().parent
out = Path('reports/composition-evidence-20261110')
out.mkdir(exist_ok=False)
matrix_dir = Path('experiments/runs/jenkins-composition-matrix-linux-20261110')
prototype = Path('experiments/runs/compositional-prototype-20261110')

def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()

def save(p, data):
    p.write_text(json.dumps(data,indent=2)+'\n')

protocol = json.loads((root/'protocol.json').read_text())
for name,expected in protocol['bindings'].items():
    assert sha(name)==expected,name
matrix = json.loads((matrix_dir/'matrix.json').read_text())
assert matrix['status'] in ('completed','completed-with-gaps')
assert matrix['summary']=={'completed':100,'failed':0,'unavailable_profiles':1}
observers = {name:Path(f'experiments/runs/jenkins-composition-{name}-linux-20261110') for name in ('bitlinear','ghidra')}
for path in observers.values():
    assert json.loads((path/'effort.json').read_text())['status']=='completed'
save(root/'completion-integrity.json',{'checked_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'bindings_unchanged':True,'matrix_status':matrix['status'],'matrix_summary':matrix['summary'],
    'observer_statuses':{name:'completed' for name in observers}})

for source,name in ((root/'protocol.json','protocol.json'),(root/'environment.json','environment.json'),
                    (root/'run.py','run.py'),(root/'probe-grading.py','probe-grading.py'),
                    (root/'linked-sizes/sizes.json','linked-sizes.json'),
                    (prototype/'candidate-identity.json','candidate-identity.json'),
                    (prototype/'native-final-ctest.log','native-ctest.log'),
                    (prototype/'linux-final-ctest.log','linux-ctest.log')):
    shutil.copyfile(source,out/name)
for label,path in observers.items():
    for file in ('summary.json','trials.csv','protocol.json'):
        shutil.copyfile(path/file,out/(label+'-'+file))
    shutil.copyfile(root/(label+'.log'),out/(label+'.log'))

summary={k:v for k,v in matrix.items() if k not in ('commands','records')}
summary['records']=[]
for r in matrix['records']:
    item={k:v for k,v in r.items() if k not in ('linked','llvm_ir')}
    item['linked']={k:v for k,v in r.get('linked',{}).items() if k!='functions'}
    item['llvm_ir']={k:v for k,v in r.get('llvm_ir',{}).items() if k not in ('instructions','functions')}
    summary['records'].append(item)
save(out/'matrix-summary.json',summary)
proofs=json.loads((root/'proof-resources.json').read_text())
compact=[{**r,'resources':{k:v for k,v in r['resources'].items() if k!='samples'}} for r in proofs]
save(out/'proof-resources-summary.json',compact)
chain=json.loads((root/'grading-chain-probe/results.json').read_text())
for row in chain:
    for key in ('bridge','answer','negative_control'):
        if key in row:
            row[key]['resources'].pop('samples',None)
save(out/'grading-chain-summary.json',chain)

for name,directory in (('prototype',prototype),('followup',root),('matrix',matrix_dir),*observers.items()):
    dest=out/(name+'.tar.xz')
    with tarfile.open(dest,'w:xz',preset=6) as archive:
        archive.add(directory,arcname=directory.name)
    print('ARCHIVE',name,dest.stat().st_size,flush=True)
# Check that the published large archive actually contains the exact raw matrix.
with tarfile.open(out/'matrix.tar.xz','r:xz') as archive:
    raw=archive.extractfile(matrix_dir.name+'/matrix.json').read()
    assert hashlib.sha256(raw).hexdigest()==sha(matrix_dir/'matrix.json')
entries={p.name:{'sha256':sha(p),'bytes':p.stat().st_size} for p in sorted(out.iterdir()) if p.is_file()}
save(out/'sha256.json',{'schema_version':1,'implementation_commit':'fc5174c',
    'scope':'raw prototypes, unchanged observer rounds, proof-chain probe and complete validated build artifacts',
    'files':entries})
print('PUBLISHED',len(entries),'files',sum(x['bytes'] for x in entries.values()),'bytes',flush=True)
