; ModuleID = '/work/experiments/runs/jenkins-composition-matrix-linux-20261110/jenkins_word/build-clang-O3-thinlto-affine-42/validation/compiler-0-O3/candidate.i'
source_filename = "/work/experiments/runs/jenkins-composition-matrix-linux-20261110/jenkins_word/build-clang-O3-thinlto-affine-42/validation/compiler-0-O3/candidate.i"
target datalayout = "e-m:e-i8:8:32-i16:16:32-i64:64-i128:128-n32:64-S128"
target triple = "aarch64-unknown-linux-gnu"

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local i32 @kernel(i32 noundef %0, i32 noundef %1) local_unnamed_addr #0 {
  %3 = and i32 %1, 255
  %4 = add i32 %3, %0
  %5 = mul i32 %4, 1025
  %6 = lshr i32 %5, 6
  %7 = xor i32 %6, %5
  %8 = lshr i32 %1, 8
  %9 = and i32 %8, 255
  %10 = add i32 %7, %9
  %11 = mul i32 %10, 1025
  %12 = lshr i32 %11, 6
  %13 = xor i32 %12, %11
  %14 = lshr i32 %1, 16
  %15 = and i32 %14, 255
  %16 = add i32 %13, %15
  %17 = mul i32 %16, 1025
  %18 = lshr i32 %17, 6
  %19 = xor i32 %18, %17
  %20 = lshr i32 %1, 24
  %21 = add i32 %19, %20
  %22 = mul i32 %21, 1025
  %23 = lshr i32 %22, 6
  %24 = xor i32 %23, %22
  %25 = mul i32 %24, 9
  %26 = lshr i32 %25, 11
  %27 = xor i32 %26, %25
  %28 = mul i32 %27, 32769
  ret i32 %28
}

attributes #0 = { mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable "frame-pointer"="non-leaf" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+fp-armv8,+neon,+outline-atomics,+v8a,-fmv" }

!llvm.module.flags = !{!0, !1, !2, !3, !4, !5}
!llvm.ident = !{!6}

!0 = !{i32 1, !"wchar_size", i32 4}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 1}
!5 = !{i32 1, !"EnableSplitLTOUnit", i32 0}
!6 = !{!"Ubuntu clang version 18.1.3 (1ubuntu1)"}

^0 = module: (path: "[Regular LTO]", hash: (0, 0, 0, 0, 0))
^1 = gv: (name: "kernel", summaries: (function: (module: ^0, flags: (linkage: external, visibility: default, notEligibleToImport: 0, live: 0, dsoLocal: 1, canAutoHide: 0), insts: 27, funcFlags: (readNone: 1, readOnly: 0, noRecurse: 1, returnDoesNotAlias: 0, noInline: 0, alwaysInline: 0, noUnwind: 1, mayThrow: 0, hasUnknownCall: 0, mustBeUnreachable: 0)))) ; guid = 17571550346185820240
^2 = blockcount: 0
