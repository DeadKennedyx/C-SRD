
/work/experiments/runs/jenkins-composition-matrix-linux-20261110/jenkins_word/build-clang-Oz-original/program:	file format elf64-littleaarch64

Disassembly of section .init:

0000000000000678 <_init>:
     678:      	nop
     67c:      	stp	x29, x30, [sp, #-0x10]!
     680:      	mov	x29, sp
     684:      	bl	0x774 <call_weak_fn>
     688:      	ldp	x29, x30, [sp], #0x10
     68c:      	ret

Disassembly of section .plt:

0000000000000690 <.plt>:
     690:      	stp	x16, x30, [sp, #-0x10]!
     694:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e4b4>
     698:      	ldr	x17, [x16, #0xff8]
     69c:      	add	x16, x16, #0xff8
     6a0:      	br	x17
     6a4:      	nop
     6a8:      	nop
     6ac:      	nop

00000000000006b0 <strtoul@plt>:
     6b0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6b4:      	ldr	x17, [x16]
     6b8:      	add	x16, x16, #0x0
     6bc:      	br	x17

00000000000006c0 <__libc_start_main@plt>:
     6c0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6c4:      	ldr	x17, [x16, #0x8]
     6c8:      	add	x16, x16, #0x8
     6cc:      	br	x17

00000000000006d0 <__cxa_finalize@plt>:
     6d0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6d4:      	ldr	x17, [x16, #0x10]
     6d8:      	add	x16, x16, #0x10
     6dc:      	br	x17

00000000000006e0 <clock_gettime@plt>:
     6e0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6e4:      	ldr	x17, [x16, #0x18]
     6e8:      	add	x16, x16, #0x18
     6ec:      	br	x17

00000000000006f0 <__gmon_start__@plt>:
     6f0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6f4:      	ldr	x17, [x16, #0x20]
     6f8:      	add	x16, x16, #0x20
     6fc:      	br	x17

0000000000000700 <abort@plt>:
     700:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     704:      	ldr	x17, [x16, #0x28]
     708:      	add	x16, x16, #0x28
     70c:      	br	x17

0000000000000710 <__isoc99_scanf@plt>:
     710:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     714:      	ldr	x17, [x16, #0x30]
     718:      	add	x16, x16, #0x30
     71c:      	br	x17

0000000000000720 <printf@plt>:
     720:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     724:      	ldr	x17, [x16, #0x38]
     728:      	add	x16, x16, #0x38
     72c:      	br	x17

Disassembly of section .text:

0000000000000740 <_start>:
     740:      	nop
     744:      	mov	x29, #0x0               // =0
     748:      	mov	x30, #0x0               // =0
     74c:      	mov	x5, x0
     750:      	ldr	x1, [sp]
     754:      	add	x2, sp, #0x8
     758:      	mov	x6, sp
     75c:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e4b4>
     760:      	ldr	x0, [x0, #0xfd8]
     764:      	mov	x3, #0x0                // =0
     768:      	mov	x4, #0x0                // =0
     76c:      	bl	0x6c0 <__libc_start_main@plt>
     770:      	bl	0x700 <abort@plt>

0000000000000774 <call_weak_fn>:
     774:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e4b4>
     778:      	ldr	x0, [x0, #0xfd0]
     77c:      	cbz	x0, 0x784 <call_weak_fn+0x10>
     780:      	b	0x6f0 <__gmon_start__@plt>
     784:      	ret
     788:      	nop
     78c:      	nop

0000000000000790 <deregister_tm_clones>:
     790:      	adrp	x0, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     794:      	add	x0, x0, #0x50
     798:      	adrp	x1, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     79c:      	add	x1, x1, #0x50
     7a0:      	cmp	x1, x0
     7a4:      	b.eq	0x7bc <deregister_tm_clones+0x2c>
     7a8:      	adrp	x1, 0x1f000 <__FRAME_END__+0x1e4b4>
     7ac:      	ldr	x1, [x1, #0xfc0]
     7b0:      	cbz	x1, 0x7bc <deregister_tm_clones+0x2c>
     7b4:      	mov	x16, x1
     7b8:      	br	x16
     7bc:      	ret

00000000000007c0 <register_tm_clones>:
     7c0:      	adrp	x0, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     7c4:      	add	x0, x0, #0x50
     7c8:      	adrp	x1, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     7cc:      	add	x1, x1, #0x50
     7d0:      	sub	x1, x1, x0
     7d4:      	lsr	x2, x1, #63
     7d8:      	add	x1, x2, x1, asr #3
     7dc:      	asr	x1, x1, #1
     7e0:      	cbz	x1, 0x7f8 <register_tm_clones+0x38>
     7e4:      	adrp	x2, 0x1f000 <__FRAME_END__+0x1e4b4>
     7e8:      	ldr	x2, [x2, #0xfe0]
     7ec:      	cbz	x2, 0x7f8 <register_tm_clones+0x38>
     7f0:      	mov	x16, x2
     7f4:      	br	x16
     7f8:      	ret
     7fc:      	nop

0000000000000800 <__do_global_dtors_aux>:
     800:      	paciasp
     804:      	stp	x29, x30, [sp, #-0x20]!
     808:      	mov	x29, sp
     80c:      	str	x19, [sp, #0x10]
     810:      	adrp	x19, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     814:      	ldrb	w0, [x19, #0x50]
     818:      	tbnz	w0, #0x0, 0x840 <__do_global_dtors_aux+0x40>
     81c:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e4b4>
     820:      	ldr	x0, [x0, #0xfc8]
     824:      	cbz	x0, 0x834 <__do_global_dtors_aux+0x34>
     828:      	adrp	x0, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     82c:      	ldr	x0, [x0, #0x48]
     830:      	bl	0x6d0 <__cxa_finalize@plt>
     834:      	bl	0x790 <deregister_tm_clones>
     838:      	mov	w0, #0x1                // =1
     83c:      	strb	w0, [x19, #0x50]
     840:      	ldr	x19, [sp, #0x10]
     844:      	ldp	x29, x30, [sp], #0x20
     848:      	autiasp
     84c:      	ret

0000000000000850 <frame_dummy>:
     850:      	bti	c
     854:      	b	0x7c0 <register_tm_clones>

0000000000000858 <kernel>:
     858:      	mov	w8, #0x4                // =4
     85c:      	cbz	w8, 0x878 <kernel+0x20>
     860:      	add	w9, w0, w1, uxtb
     864:      	lsr	w1, w1, #8
     868:      	sub	w8, w8, #0x1
     86c:      	add	w9, w9, w9, lsl #10
     870:      	eor	w0, w9, w9, lsr #6
     874:      	cbnz	w8, 0x860 <kernel+0x8>
     878:      	add	w8, w0, w0, lsl #3
     87c:      	eor	w8, w8, w8, lsr #11
     880:      	add	w0, w8, w8, lsl #15
     884:      	ret

0000000000000888 <main>:
     888:      	sub	sp, sp, #0x60
     88c:      	stp	x29, x30, [sp, #0x20]
     890:      	str	x23, [sp, #0x30]
     894:      	stp	x22, x21, [sp, #0x40]
     898:      	stp	x20, x19, [sp, #0x50]
     89c:      	add	x29, sp, #0x20
     8a0:      	cmp	w0, #0x3
     8a4:      	b.eq	0x8f4 <main+0x6c>
     8a8:      	cmp	w0, #0x1
     8ac:      	b.ne	0x980 <main+0xf8>
     8b0:      	adrp	x19, 0x0 <strtoul@GLIBC_2.17>
     8b4:      	add	x19, x19, #0xa18
     8b8:      	add	x21, x29, #0x18
     8bc:      	adrp	x20, 0x0 <strtoul@GLIBC_2.17>
     8c0:      	add	x20, x20, #0xa1d
     8c4:      	add	x1, x29, #0x18
     8c8:      	add	x2, x21, #0x4
     8cc:      	mov	x0, x19
     8d0:      	bl	0x710 <__isoc99_scanf@plt>
     8d4:      	cmp	w0, #0x2
     8d8:      	b.ne	0x9d4 <main+0x14c>
     8dc:      	ldp	w0, w1, [x29, #0x18]
     8e0:      	bl	0x858 <kernel>
     8e4:      	mov	w1, w0
     8e8:      	mov	x0, x20
     8ec:      	bl	0x720 <printf@plt>
     8f0:      	b	0x8c4 <main+0x3c>
     8f4:      	ldr	x0, [x1, #0x8]
     8f8:      	mov	x19, x1
     8fc:      	mov	x1, xzr
     900:      	mov	w2, #0xa                // =10
     904:      	bl	0x6b0 <strtoul@plt>
     908:      	ldr	x8, [x19, #0x10]
     90c:      	mov	x20, x0
     910:      	mov	x1, xzr
     914:      	mov	w2, #0xa                // =10
     918:      	mov	x0, x8
     91c:      	bl	0x6b0 <strtoul@plt>
     920:      	mov	x21, x0
     924:      	add	x1, sp, #0x10
     928:      	mov	w0, #0x1                // =1
     92c:      	bl	0x6e0 <clock_gettime@plt>
     930:      	cbnz	w0, 0x998 <main+0x110>
     934:      	mov	x19, xzr
     938:      	mov	x22, xzr
     93c:      	add	x23, x29, #0x18
     940:      	cmp	x22, x20
     944:      	b.eq	0x988 <main+0x100>
     948:      	mov	x8, xzr
     94c:      	cmp	x8, #0x8
     950:      	b.eq	0x96c <main+0xe4>
     954:      	eor	w9, w21, w21, lsl #13
     958:      	eor	w9, w9, w9, lsr #17
     95c:      	eor	w21, w9, w9, lsl #5
     960:      	str	w21, [x23, x8]
     964:      	add	x8, x8, #0x4
     968:      	b	0x94c <main+0xc4>
     96c:      	ldp	w0, w1, [x29, #0x18]
     970:      	bl	0x858 <kernel>
     974:      	add	x19, x19, w0, uxtw
     978:      	add	x22, x22, #0x1
     97c:      	b	0x940 <main+0xb8>
     980:      	mov	w0, #0x3                // =3
     984:      	b	0x9d8 <main+0x150>
     988:      	mov	x1, sp
     98c:      	mov	w0, #0x1                // =1
     990:      	bl	0x6e0 <clock_gettime@plt>
     994:      	cbz	w0, 0x9a0 <main+0x118>
     998:      	mov	w0, #0x2                // =2
     99c:      	b	0x9d8 <main+0x150>
     9a0:      	ldp	x8, x9, [sp]
     9a4:      	adrp	x0, 0x0 <strtoul@GLIBC_2.17>
     9a8:      	add	x0, x0, #0xa21
     9ac:      	ldp	x10, x11, [sp, #0x10]
     9b0:      	mov	x1, x19
     9b4:      	sub	x8, x8, x10
     9b8:      	sub	x9, x9, x11
     9bc:      	scvtf	d0, x8
     9c0:      	scvtf	d1, x9
     9c4:      	adrp	x8, 0x0 <strtoul@GLIBC_2.17>
     9c8:      	ldr	d2, [x8, #0xa10]
     9cc:      	fmadd	d0, d1, d2, d0
     9d0:      	bl	0x720 <printf@plt>
     9d4:      	mov	w0, wzr
     9d8:      	ldp	x20, x19, [sp, #0x50]
     9dc:      	ldr	x23, [sp, #0x30]
     9e0:      	ldp	x22, x21, [sp, #0x40]
     9e4:      	ldp	x29, x30, [sp, #0x20]
     9e8:      	add	sp, sp, #0x60
     9ec:      	ret

Disassembly of section .fini:

00000000000009f0 <_fini>:
     9f0:      	nop
     9f4:      	stp	x29, x30, [sp, #-0x10]!
     9f8:      	mov	x29, sp
     9fc:      	ldp	x29, x30, [sp], #0x10
     a00:      	ret
