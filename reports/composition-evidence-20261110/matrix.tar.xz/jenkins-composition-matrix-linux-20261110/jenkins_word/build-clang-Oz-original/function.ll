; ModuleID = '/work/experiments/runs/jenkins-composition-matrix-linux-20261110/jenkins_word/build-clang-Oz-original/validation/compiler-0-Oz/candidate.i'
source_filename = "/work/experiments/runs/jenkins-composition-matrix-linux-20261110/jenkins_word/build-clang-Oz-original/validation/compiler-0-Oz/candidate.i"
target datalayout = "e-m:e-i8:8:32-i16:16:32-i64:64-i128:128-n32:64-S128"
target triple = "aarch64-unknown-linux-gnu"

; Function Attrs: minsize nofree norecurse nosync nounwind optsize memory(none) uwtable
define dso_local i32 @kernel(i32 noundef %0, i32 noundef %1) local_unnamed_addr #0 {
  br label %3

3:                                                ; preds = %13, %2
  %4 = phi i32 [ %0, %2 ], [ %18, %13 ]
  %5 = phi i32 [ %1, %2 ], [ %19, %13 ]
  %6 = phi i32 [ 0, %2 ], [ %20, %13 ]
  %7 = icmp eq i32 %6, 4
  br i1 %7, label %8, label %13

8:                                                ; preds = %3
  %9 = mul i32 %4, 9
  %10 = lshr i32 %9, 11
  %11 = xor i32 %10, %9
  %12 = mul i32 %11, 32769
  ret i32 %12

13:                                               ; preds = %3
  %14 = and i32 %5, 255
  %15 = add i32 %14, %4
  %16 = mul i32 %15, 1025
  %17 = lshr i32 %16, 6
  %18 = xor i32 %17, %16
  %19 = lshr i32 %5, 8
  %20 = add nuw nsw i32 %6, 1
  br label %3, !llvm.loop !6
}

attributes #0 = { minsize nofree norecurse nosync nounwind optsize memory(none) uwtable "frame-pointer"="non-leaf" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+fp-armv8,+neon,+outline-atomics,+v8a,-fmv" }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 1, !"wchar_size", i32 4}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 1}
!5 = !{!"Ubuntu clang version 18.1.3 (1ubuntu1)"}
!6 = distinct !{!6, !7}
!7 = !{!"llvm.loop.mustprogress"}
