; ModuleID = '/work/experiments/runs/jenkins-composition-matrix-linux-20261110/jenkins_word/build-clang-O0-identity/validation/compiler-0-O0/candidate.i'
source_filename = "/work/experiments/runs/jenkins-composition-matrix-linux-20261110/jenkins_word/build-clang-O0-identity/validation/compiler-0-O0/candidate.i"
target datalayout = "e-m:e-i8:8:32-i16:16:32-i64:64-i128:128-n32:64-S128"
target triple = "aarch64-unknown-linux-gnu"

; Function Attrs: noinline nounwind optnone uwtable
define dso_local i32 @kernel(i32 noundef %0, i32 noundef %1) #0 {
  %3 = alloca i32, align 4
  %4 = alloca i32, align 4
  %5 = alloca i32, align 4
  %6 = alloca i32, align 4
  %7 = alloca i32, align 4
  %8 = alloca i32, align 4
  %9 = alloca i32, align 4
  %10 = alloca i32, align 4
  %11 = alloca i32, align 4
  %12 = alloca i32, align 4
  %13 = alloca i32, align 4
  %14 = alloca i32, align 4
  %15 = alloca i32, align 4
  %16 = alloca i32, align 4
  %17 = alloca i32, align 4
  %18 = alloca i32, align 4
  %19 = alloca i32, align 4
  %20 = alloca i32, align 4
  %21 = alloca i32, align 4
  %22 = alloca i32, align 4
  %23 = alloca i32, align 4
  %24 = alloca i32, align 4
  %25 = alloca i32, align 4
  %26 = alloca i32, align 4
  %27 = alloca i32, align 4
  %28 = alloca i32, align 4
  %29 = alloca i32, align 4
  %30 = alloca i32, align 4
  %31 = alloca i32, align 4
  %32 = alloca i32, align 4
  %33 = alloca i32, align 4
  %34 = alloca i32, align 4
  %35 = alloca i32, align 4
  %36 = alloca i32, align 4
  %37 = alloca i32, align 4
  store i32 %0, ptr %3, align 4
  store i32 %1, ptr %4, align 4
  %38 = load i32, ptr %4, align 4
  %39 = and i32 %38, 255
  store i32 %39, ptr %5, align 4
  %40 = load i32, ptr %3, align 4
  %41 = load i32, ptr %5, align 4
  %42 = add i32 %40, %41
  store i32 %42, ptr %6, align 4
  %43 = load i32, ptr %6, align 4
  %44 = shl i32 %43, 10
  store i32 %44, ptr %7, align 4
  %45 = load i32, ptr %6, align 4
  %46 = load i32, ptr %7, align 4
  %47 = add i32 %45, %46
  store i32 %47, ptr %8, align 4
  %48 = load i32, ptr %8, align 4
  %49 = lshr i32 %48, 6
  store i32 %49, ptr %9, align 4
  %50 = load i32, ptr %8, align 4
  %51 = load i32, ptr %9, align 4
  %52 = xor i32 %50, %51
  store i32 %52, ptr %10, align 4
  %53 = load i32, ptr %4, align 4
  %54 = lshr i32 %53, 8
  store i32 %54, ptr %11, align 4
  %55 = load i32, ptr %11, align 4
  %56 = and i32 %55, 255
  store i32 %56, ptr %12, align 4
  %57 = load i32, ptr %10, align 4
  %58 = load i32, ptr %12, align 4
  %59 = add i32 %57, %58
  store i32 %59, ptr %13, align 4
  %60 = load i32, ptr %13, align 4
  %61 = shl i32 %60, 10
  store i32 %61, ptr %14, align 4
  %62 = load i32, ptr %13, align 4
  %63 = load i32, ptr %14, align 4
  %64 = add i32 %62, %63
  store i32 %64, ptr %15, align 4
  %65 = load i32, ptr %15, align 4
  %66 = lshr i32 %65, 6
  store i32 %66, ptr %16, align 4
  %67 = load i32, ptr %15, align 4
  %68 = load i32, ptr %16, align 4
  %69 = xor i32 %67, %68
  store i32 %69, ptr %17, align 4
  %70 = load i32, ptr %11, align 4
  %71 = lshr i32 %70, 8
  store i32 %71, ptr %18, align 4
  %72 = load i32, ptr %18, align 4
  %73 = and i32 %72, 255
  store i32 %73, ptr %19, align 4
  %74 = load i32, ptr %17, align 4
  %75 = load i32, ptr %19, align 4
  %76 = add i32 %74, %75
  store i32 %76, ptr %20, align 4
  %77 = load i32, ptr %20, align 4
  %78 = shl i32 %77, 10
  store i32 %78, ptr %21, align 4
  %79 = load i32, ptr %20, align 4
  %80 = load i32, ptr %21, align 4
  %81 = add i32 %79, %80
  store i32 %81, ptr %22, align 4
  %82 = load i32, ptr %22, align 4
  %83 = lshr i32 %82, 6
  store i32 %83, ptr %23, align 4
  %84 = load i32, ptr %22, align 4
  %85 = load i32, ptr %23, align 4
  %86 = xor i32 %84, %85
  store i32 %86, ptr %24, align 4
  %87 = load i32, ptr %18, align 4
  %88 = lshr i32 %87, 8
  store i32 %88, ptr %25, align 4
  %89 = load i32, ptr %25, align 4
  %90 = and i32 %89, 255
  store i32 %90, ptr %26, align 4
  %91 = load i32, ptr %24, align 4
  %92 = load i32, ptr %26, align 4
  %93 = add i32 %91, %92
  store i32 %93, ptr %27, align 4
  %94 = load i32, ptr %27, align 4
  %95 = shl i32 %94, 10
  store i32 %95, ptr %28, align 4
  %96 = load i32, ptr %27, align 4
  %97 = load i32, ptr %28, align 4
  %98 = add i32 %96, %97
  store i32 %98, ptr %29, align 4
  %99 = load i32, ptr %29, align 4
  %100 = lshr i32 %99, 6
  store i32 %100, ptr %30, align 4
  %101 = load i32, ptr %29, align 4
  %102 = load i32, ptr %30, align 4
  %103 = xor i32 %101, %102
  store i32 %103, ptr %31, align 4
  %104 = load i32, ptr %31, align 4
  %105 = shl i32 %104, 3
  store i32 %105, ptr %32, align 4
  %106 = load i32, ptr %31, align 4
  %107 = load i32, ptr %32, align 4
  %108 = add i32 %106, %107
  store i32 %108, ptr %33, align 4
  %109 = load i32, ptr %33, align 4
  %110 = lshr i32 %109, 11
  store i32 %110, ptr %34, align 4
  %111 = load i32, ptr %33, align 4
  %112 = load i32, ptr %34, align 4
  %113 = xor i32 %111, %112
  store i32 %113, ptr %35, align 4
  %114 = load i32, ptr %35, align 4
  %115 = shl i32 %114, 15
  store i32 %115, ptr %36, align 4
  %116 = load i32, ptr %35, align 4
  %117 = load i32, ptr %36, align 4
  %118 = add i32 %116, %117
  store i32 %118, ptr %37, align 4
  %119 = load i32, ptr %37, align 4
  ret i32 %119
}

attributes #0 = { noinline nounwind optnone uwtable "frame-pointer"="non-leaf" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+fp-armv8,+neon,+outline-atomics,+v8a,-fmv" }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 1, !"wchar_size", i32 4}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 1}
!5 = !{!"Ubuntu clang version 18.1.3 (1ubuntu1)"}
