
/work/experiments/runs/jenkins-composition-matrix-linux-20261110/jenkins_word/build-clang-O0-identity/program:	file format elf64-littleaarch64

Disassembly of section .init:

0000000000000678 <_init>:
     678:      	nop
     67c:      	stp	x29, x30, [sp, #-0x10]!
     680:      	mov	x29, sp
     684:      	bl	0x774 <call_weak_fn>
     688:      	ldp	x29, x30, [sp], #0x10
     68c:      	ret

Disassembly of section .plt:

0000000000000690 <.plt>:
     690:      	stp	x16, x30, [sp, #-0x10]!
     694:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e1f4>
     698:      	ldr	x17, [x16, #0xff8]
     69c:      	add	x16, x16, #0xff8
     6a0:      	br	x17
     6a4:      	nop
     6a8:      	nop
     6ac:      	nop

00000000000006b0 <strtoul@plt>:
     6b0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6b4:      	ldr	x17, [x16]
     6b8:      	add	x16, x16, #0x0
     6bc:      	br	x17

00000000000006c0 <__libc_start_main@plt>:
     6c0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6c4:      	ldr	x17, [x16, #0x8]
     6c8:      	add	x16, x16, #0x8
     6cc:      	br	x17

00000000000006d0 <__cxa_finalize@plt>:
     6d0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6d4:      	ldr	x17, [x16, #0x10]
     6d8:      	add	x16, x16, #0x10
     6dc:      	br	x17

00000000000006e0 <clock_gettime@plt>:
     6e0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6e4:      	ldr	x17, [x16, #0x18]
     6e8:      	add	x16, x16, #0x18
     6ec:      	br	x17

00000000000006f0 <__gmon_start__@plt>:
     6f0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6f4:      	ldr	x17, [x16, #0x20]
     6f8:      	add	x16, x16, #0x20
     6fc:      	br	x17

0000000000000700 <abort@plt>:
     700:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     704:      	ldr	x17, [x16, #0x28]
     708:      	add	x16, x16, #0x28
     70c:      	br	x17

0000000000000710 <__isoc99_scanf@plt>:
     710:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     714:      	ldr	x17, [x16, #0x30]
     718:      	add	x16, x16, #0x30
     71c:      	br	x17

0000000000000720 <printf@plt>:
     720:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     724:      	ldr	x17, [x16, #0x38]
     728:      	add	x16, x16, #0x38
     72c:      	br	x17

Disassembly of section .text:

0000000000000740 <_start>:
     740:      	nop
     744:      	mov	x29, #0x0               // =0
     748:      	mov	x30, #0x0               // =0
     74c:      	mov	x5, x0
     750:      	ldr	x1, [sp]
     754:      	add	x2, sp, #0x8
     758:      	mov	x6, sp
     75c:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e1f4>
     760:      	ldr	x0, [x0, #0xfd8]
     764:      	mov	x3, #0x0                // =0
     768:      	mov	x4, #0x0                // =0
     76c:      	bl	0x6c0 <__libc_start_main@plt>
     770:      	bl	0x700 <abort@plt>

0000000000000774 <call_weak_fn>:
     774:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e1f4>
     778:      	ldr	x0, [x0, #0xfd0]
     77c:      	cbz	x0, 0x784 <call_weak_fn+0x10>
     780:      	b	0x6f0 <__gmon_start__@plt>
     784:      	ret
     788:      	nop
     78c:      	nop

0000000000000790 <deregister_tm_clones>:
     790:      	adrp	x0, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     794:      	add	x0, x0, #0x50
     798:      	adrp	x1, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     79c:      	add	x1, x1, #0x50
     7a0:      	cmp	x1, x0
     7a4:      	b.eq	0x7bc <deregister_tm_clones+0x2c>
     7a8:      	adrp	x1, 0x1f000 <__FRAME_END__+0x1e1f4>
     7ac:      	ldr	x1, [x1, #0xfc0]
     7b0:      	cbz	x1, 0x7bc <deregister_tm_clones+0x2c>
     7b4:      	mov	x16, x1
     7b8:      	br	x16
     7bc:      	ret

00000000000007c0 <register_tm_clones>:
     7c0:      	adrp	x0, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     7c4:      	add	x0, x0, #0x50
     7c8:      	adrp	x1, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     7cc:      	add	x1, x1, #0x50
     7d0:      	sub	x1, x1, x0
     7d4:      	lsr	x2, x1, #63
     7d8:      	add	x1, x2, x1, asr #3
     7dc:      	asr	x1, x1, #1
     7e0:      	cbz	x1, 0x7f8 <register_tm_clones+0x38>
     7e4:      	adrp	x2, 0x1f000 <__FRAME_END__+0x1e1f4>
     7e8:      	ldr	x2, [x2, #0xfe0]
     7ec:      	cbz	x2, 0x7f8 <register_tm_clones+0x38>
     7f0:      	mov	x16, x2
     7f4:      	br	x16
     7f8:      	ret
     7fc:      	nop

0000000000000800 <__do_global_dtors_aux>:
     800:      	paciasp
     804:      	stp	x29, x30, [sp, #-0x20]!
     808:      	mov	x29, sp
     80c:      	str	x19, [sp, #0x10]
     810:      	adrp	x19, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     814:      	ldrb	w0, [x19, #0x50]
     818:      	tbnz	w0, #0x0, 0x840 <__do_global_dtors_aux+0x40>
     81c:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e1f4>
     820:      	ldr	x0, [x0, #0xfc8]
     824:      	cbz	x0, 0x834 <__do_global_dtors_aux+0x34>
     828:      	adrp	x0, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     82c:      	ldr	x0, [x0, #0x48]
     830:      	bl	0x6d0 <__cxa_finalize@plt>
     834:      	bl	0x790 <deregister_tm_clones>
     838:      	mov	w0, #0x1                // =1
     83c:      	strb	w0, [x19, #0x50]
     840:      	ldr	x19, [sp, #0x10]
     844:      	ldp	x29, x30, [sp], #0x20
     848:      	autiasp
     84c:      	ret

0000000000000850 <frame_dummy>:
     850:      	bti	c
     854:      	b	0x7c0 <register_tm_clones>

0000000000000858 <kernel>:
     858:      	sub	sp, sp, #0x90
     85c:      	str	w0, [sp, #0x8c]
     860:      	str	w1, [sp, #0x88]
     864:      	ldrb	w8, [sp, #0x88]
     868:      	str	w8, [sp, #0x84]
     86c:      	ldr	w8, [sp, #0x8c]
     870:      	ldr	w9, [sp, #0x84]
     874:      	add	w8, w8, w9
     878:      	str	w8, [sp, #0x80]
     87c:      	ldr	w8, [sp, #0x80]
     880:      	lsl	w8, w8, #10
     884:      	str	w8, [sp, #0x7c]
     888:      	ldr	w8, [sp, #0x80]
     88c:      	ldr	w9, [sp, #0x7c]
     890:      	add	w8, w8, w9
     894:      	str	w8, [sp, #0x78]
     898:      	ldr	w8, [sp, #0x78]
     89c:      	lsr	w8, w8, #6
     8a0:      	str	w8, [sp, #0x74]
     8a4:      	ldr	w8, [sp, #0x78]
     8a8:      	ldr	w9, [sp, #0x74]
     8ac:      	eor	w8, w8, w9
     8b0:      	str	w8, [sp, #0x70]
     8b4:      	ldr	w8, [sp, #0x88]
     8b8:      	lsr	w8, w8, #8
     8bc:      	str	w8, [sp, #0x6c]
     8c0:      	ldrb	w8, [sp, #0x6c]
     8c4:      	str	w8, [sp, #0x68]
     8c8:      	ldr	w8, [sp, #0x70]
     8cc:      	ldr	w9, [sp, #0x68]
     8d0:      	add	w8, w8, w9
     8d4:      	str	w8, [sp, #0x64]
     8d8:      	ldr	w8, [sp, #0x64]
     8dc:      	lsl	w8, w8, #10
     8e0:      	str	w8, [sp, #0x60]
     8e4:      	ldr	w8, [sp, #0x64]
     8e8:      	ldr	w9, [sp, #0x60]
     8ec:      	add	w8, w8, w9
     8f0:      	str	w8, [sp, #0x5c]
     8f4:      	ldr	w8, [sp, #0x5c]
     8f8:      	lsr	w8, w8, #6
     8fc:      	str	w8, [sp, #0x58]
     900:      	ldr	w8, [sp, #0x5c]
     904:      	ldr	w9, [sp, #0x58]
     908:      	eor	w8, w8, w9
     90c:      	str	w8, [sp, #0x54]
     910:      	ldr	w8, [sp, #0x6c]
     914:      	lsr	w8, w8, #8
     918:      	str	w8, [sp, #0x50]
     91c:      	ldrb	w8, [sp, #0x50]
     920:      	str	w8, [sp, #0x4c]
     924:      	ldr	w8, [sp, #0x54]
     928:      	ldr	w9, [sp, #0x4c]
     92c:      	add	w8, w8, w9
     930:      	str	w8, [sp, #0x48]
     934:      	ldr	w8, [sp, #0x48]
     938:      	lsl	w8, w8, #10
     93c:      	str	w8, [sp, #0x44]
     940:      	ldr	w8, [sp, #0x48]
     944:      	ldr	w9, [sp, #0x44]
     948:      	add	w8, w8, w9
     94c:      	str	w8, [sp, #0x40]
     950:      	ldr	w8, [sp, #0x40]
     954:      	lsr	w8, w8, #6
     958:      	str	w8, [sp, #0x3c]
     95c:      	ldr	w8, [sp, #0x40]
     960:      	ldr	w9, [sp, #0x3c]
     964:      	eor	w8, w8, w9
     968:      	str	w8, [sp, #0x38]
     96c:      	ldr	w8, [sp, #0x50]
     970:      	lsr	w8, w8, #8
     974:      	str	w8, [sp, #0x34]
     978:      	ldrb	w8, [sp, #0x34]
     97c:      	str	w8, [sp, #0x30]
     980:      	ldr	w8, [sp, #0x38]
     984:      	ldr	w9, [sp, #0x30]
     988:      	add	w8, w8, w9
     98c:      	str	w8, [sp, #0x2c]
     990:      	ldr	w8, [sp, #0x2c]
     994:      	lsl	w8, w8, #10
     998:      	str	w8, [sp, #0x28]
     99c:      	ldr	w8, [sp, #0x2c]
     9a0:      	ldr	w9, [sp, #0x28]
     9a4:      	add	w8, w8, w9
     9a8:      	str	w8, [sp, #0x24]
     9ac:      	ldr	w8, [sp, #0x24]
     9b0:      	lsr	w8, w8, #6
     9b4:      	str	w8, [sp, #0x20]
     9b8:      	ldr	w8, [sp, #0x24]
     9bc:      	ldr	w9, [sp, #0x20]
     9c0:      	eor	w8, w8, w9
     9c4:      	str	w8, [sp, #0x1c]
     9c8:      	ldr	w8, [sp, #0x1c]
     9cc:      	lsl	w8, w8, #3
     9d0:      	str	w8, [sp, #0x18]
     9d4:      	ldr	w8, [sp, #0x1c]
     9d8:      	ldr	w9, [sp, #0x18]
     9dc:      	add	w8, w8, w9
     9e0:      	str	w8, [sp, #0x14]
     9e4:      	ldr	w8, [sp, #0x14]
     9e8:      	lsr	w8, w8, #11
     9ec:      	str	w8, [sp, #0x10]
     9f0:      	ldr	w8, [sp, #0x14]
     9f4:      	ldr	w9, [sp, #0x10]
     9f8:      	eor	w8, w8, w9
     9fc:      	str	w8, [sp, #0xc]
     a00:      	ldr	w8, [sp, #0xc]
     a04:      	lsl	w8, w8, #15
     a08:      	str	w8, [sp, #0x8]
     a0c:      	ldr	w8, [sp, #0xc]
     a10:      	ldr	w9, [sp, #0x8]
     a14:      	add	w8, w8, w9
     a18:      	str	w8, [sp, #0x4]
     a1c:      	ldr	w0, [sp, #0x4]
     a20:      	add	sp, sp, #0x90
     a24:      	ret

0000000000000a28 <main>:
     a28:      	sub	sp, sp, #0x90
     a2c:      	stp	x29, x30, [sp, #0x80]
     a30:      	add	x29, sp, #0x80
     a34:      	stur	wzr, [x29, #-0x4]
     a38:      	stur	w0, [x29, #-0x8]
     a3c:      	stur	x1, [x29, #-0x10]
     a40:      	ldur	w8, [x29, #-0x8]
     a44:      	subs	w8, w8, #0x1
     a48:      	b.ne	0xa9c <main+0x74>
     a4c:      	b	0xa50 <main+0x28>
     a50:      	b	0xa54 <main+0x2c>
     a54:      	sub	x1, x29, #0x18
     a58:      	add	x2, x1, #0x4
     a5c:      	adrp	x0, 0x0 <strtoul@GLIBC_2.17>
     a60:      	add	x0, x0, #0xca8
     a64:      	bl	0x710 <__isoc99_scanf@plt>
     a68:      	subs	w8, w0, #0x2
     a6c:      	b.ne	0xa94 <main+0x6c>
     a70:      	b	0xa74 <main+0x4c>
     a74:      	ldur	w0, [x29, #-0x18]
     a78:      	ldur	w1, [x29, #-0x14]
     a7c:      	bl	0x858 <kernel>
     a80:      	mov	w1, w0
     a84:      	adrp	x0, 0x0 <strtoul@GLIBC_2.17>
     a88:      	add	x0, x0, #0xcad
     a8c:      	bl	0x720 <printf@plt>
     a90:      	b	0xa54 <main+0x2c>
     a94:      	stur	wzr, [x29, #-0x4]
     a98:      	b	0xc10 <main+0x1e8>
     a9c:      	ldur	w8, [x29, #-0x8]
     aa0:      	subs	w8, w8, #0x3
     aa4:      	b.eq	0xab8 <main+0x90>
     aa8:      	b	0xaac <main+0x84>
     aac:      	mov	w8, #0x3                // =3
     ab0:      	stur	w8, [x29, #-0x4]
     ab4:      	b	0xc10 <main+0x1e8>
     ab8:      	ldur	x8, [x29, #-0x10]
     abc:      	ldr	x0, [x8, #0x8]
     ac0:      	mov	x1, xzr
     ac4:      	str	x1, [sp, #0x8]
     ac8:      	mov	w2, #0xa                // =10
     acc:      	str	w2, [sp, #0x14]
     ad0:      	bl	0x6b0 <strtoul@plt>
     ad4:      	ldr	x1, [sp, #0x8]
     ad8:      	ldr	w2, [sp, #0x14]
     adc:      	stur	x0, [x29, #-0x20]
     ae0:      	ldur	x8, [x29, #-0x10]
     ae4:      	ldr	x0, [x8, #0x10]
     ae8:      	bl	0x6b0 <strtoul@plt>
     aec:      	mov	w8, w0
     af0:      	stur	w8, [x29, #-0x24]
     af4:      	stur	xzr, [x29, #-0x30]
     af8:      	mov	w0, #0x1                // =1
     afc:      	add	x1, sp, #0x40
     b00:      	bl	0x6e0 <clock_gettime@plt>
     b04:      	cbz	w0, 0xb18 <main+0xf0>
     b08:      	b	0xb0c <main+0xe4>
     b0c:      	mov	w8, #0x2                // =2
     b10:      	stur	w8, [x29, #-0x4]
     b14:      	b	0xc10 <main+0x1e8>
     b18:      	str	xzr, [sp, #0x28]
     b1c:      	b	0xb20 <main+0xf8>
     b20:      	ldr	x8, [sp, #0x28]
     b24:      	ldur	x9, [x29, #-0x20]
     b28:      	subs	x8, x8, x9
     b2c:      	b.hs	0xba4 <main+0x17c>
     b30:      	b	0xb34 <main+0x10c>
     b34:      	str	wzr, [sp, #0x24]
     b38:      	b	0xb3c <main+0x114>
     b3c:      	ldr	w8, [sp, #0x24]
     b40:      	subs	w8, w8, #0x2
     b44:      	b.hs	0xb78 <main+0x150>
     b48:      	b	0xb4c <main+0x124>
     b4c:      	sub	x0, x29, #0x24
     b50:      	bl	0xc20 <csrd_matrix_next_value>
     b54:      	ldr	w8, [sp, #0x24]
     b58:      	mov	w9, w8
     b5c:      	sub	x8, x29, #0x18
     b60:      	str	w0, [x8, x9, lsl #2]
     b64:      	b	0xb68 <main+0x140>
     b68:      	ldr	w8, [sp, #0x24]
     b6c:      	add	w8, w8, #0x1
     b70:      	str	w8, [sp, #0x24]
     b74:      	b	0xb3c <main+0x114>
     b78:      	ldur	w0, [x29, #-0x18]
     b7c:      	ldur	w1, [x29, #-0x14]
     b80:      	bl	0x858 <kernel>
     b84:      	ldur	x8, [x29, #-0x30]
     b88:      	add	x8, x8, w0, uxtw
     b8c:      	stur	x8, [x29, #-0x30]
     b90:      	b	0xb94 <main+0x16c>
     b94:      	ldr	x8, [sp, #0x28]
     b98:      	add	x8, x8, #0x1
     b9c:      	str	x8, [sp, #0x28]
     ba0:      	b	0xb20 <main+0xf8>
     ba4:      	mov	w0, #0x1                // =1
     ba8:      	add	x1, sp, #0x30
     bac:      	bl	0x6e0 <clock_gettime@plt>
     bb0:      	cbz	w0, 0xbc4 <main+0x19c>
     bb4:      	b	0xbb8 <main+0x190>
     bb8:      	mov	w8, #0x2                // =2
     bbc:      	stur	w8, [x29, #-0x4]
     bc0:      	b	0xc10 <main+0x1e8>
     bc4:      	ldr	x8, [sp, #0x30]
     bc8:      	ldr	x9, [sp, #0x40]
     bcc:      	subs	x8, x8, x9
     bd0:      	scvtf	d2, x8
     bd4:      	ldr	x8, [sp, #0x38]
     bd8:      	ldr	x9, [sp, #0x48]
     bdc:      	subs	x8, x8, x9
     be0:      	scvtf	d0, x8
     be4:      	adrp	x8, 0x0 <strtoul@GLIBC_2.17>
     be8:      	ldr	d1, [x8, #0xca0]
     bec:      	fmadd	d0, d0, d1, d2
     bf0:      	str	d0, [sp, #0x18]
     bf4:      	ldr	d0, [sp, #0x18]
     bf8:      	ldur	x1, [x29, #-0x30]
     bfc:      	adrp	x0, 0x0 <strtoul@GLIBC_2.17>
     c00:      	add	x0, x0, #0xcb1
     c04:      	bl	0x720 <printf@plt>
     c08:      	stur	wzr, [x29, #-0x4]
     c0c:      	b	0xc10 <main+0x1e8>
     c10:      	ldur	w0, [x29, #-0x4]
     c14:      	ldp	x29, x30, [sp, #0x80]
     c18:      	add	sp, sp, #0x90
     c1c:      	ret

0000000000000c20 <csrd_matrix_next_value>:
     c20:      	sub	sp, sp, #0x10
     c24:      	str	x0, [sp, #0x8]
     c28:      	ldr	x8, [sp, #0x8]
     c2c:      	ldr	w10, [x8]
     c30:      	ldr	x9, [sp, #0x8]
     c34:      	ldr	w8, [x9]
     c38:      	eor	w8, w8, w10, lsl #13
     c3c:      	str	w8, [x9]
     c40:      	ldr	x8, [sp, #0x8]
     c44:      	ldr	w10, [x8]
     c48:      	ldr	x9, [sp, #0x8]
     c4c:      	ldr	w8, [x9]
     c50:      	eor	w8, w8, w10, lsr #17
     c54:      	str	w8, [x9]
     c58:      	ldr	x8, [sp, #0x8]
     c5c:      	ldr	w10, [x8]
     c60:      	ldr	x9, [sp, #0x8]
     c64:      	ldr	w8, [x9]
     c68:      	eor	w8, w8, w10, lsl #5
     c6c:      	str	w8, [x9]
     c70:      	ldr	x8, [sp, #0x8]
     c74:      	ldr	w0, [x8]
     c78:      	add	sp, sp, #0x10
     c7c:      	ret

Disassembly of section .fini:

0000000000000c80 <_fini>:
     c80:      	nop
     c84:      	stp	x29, x30, [sp, #-0x10]!
     c88:      	mov	x29, sp
     c8c:      	ldp	x29, x30, [sp], #0x10
     c90:      	ret
