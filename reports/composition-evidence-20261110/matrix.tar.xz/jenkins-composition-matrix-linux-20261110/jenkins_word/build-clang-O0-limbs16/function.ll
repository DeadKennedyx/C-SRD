; ModuleID = '/work/experiments/runs/jenkins-composition-matrix-linux-20261110/jenkins_word/build-clang-O0-limbs16/validation/compiler-0-O0/candidate.i'
source_filename = "/work/experiments/runs/jenkins-composition-matrix-linux-20261110/jenkins_word/build-clang-O0-limbs16/validation/compiler-0-O0/candidate.i"
target datalayout = "e-m:e-i8:8:32-i16:16:32-i64:64-i128:128-n32:64-S128"
target triple = "aarch64-unknown-linux-gnu"

; Function Attrs: noinline nounwind optnone uwtable
define dso_local i32 @kernel(i32 noundef %0, i32 noundef %1) #0 {
  %3 = alloca i32, align 4
  %4 = alloca i32, align 4
  %5 = alloca i32, align 4
  %6 = alloca i32, align 4
  %7 = alloca i32, align 4
  %8 = alloca i32, align 4
  %9 = alloca i32, align 4
  %10 = alloca i32, align 4
  %11 = alloca i32, align 4
  %12 = alloca i32, align 4
  %13 = alloca i32, align 4
  %14 = alloca i32, align 4
  %15 = alloca i32, align 4
  %16 = alloca i32, align 4
  %17 = alloca i32, align 4
  %18 = alloca i32, align 4
  %19 = alloca i32, align 4
  %20 = alloca i32, align 4
  %21 = alloca i32, align 4
  %22 = alloca i32, align 4
  %23 = alloca i32, align 4
  %24 = alloca i32, align 4
  %25 = alloca i32, align 4
  %26 = alloca i32, align 4
  %27 = alloca i32, align 4
  %28 = alloca i32, align 4
  %29 = alloca i32, align 4
  %30 = alloca i32, align 4
  %31 = alloca i32, align 4
  %32 = alloca i32, align 4
  %33 = alloca i32, align 4
  %34 = alloca i32, align 4
  %35 = alloca i32, align 4
  %36 = alloca i32, align 4
  %37 = alloca i32, align 4
  %38 = alloca i32, align 4
  %39 = alloca i32, align 4
  %40 = alloca i32, align 4
  %41 = alloca i32, align 4
  %42 = alloca i32, align 4
  %43 = alloca i32, align 4
  %44 = alloca i32, align 4
  %45 = alloca i32, align 4
  %46 = alloca i32, align 4
  %47 = alloca i32, align 4
  %48 = alloca i32, align 4
  %49 = alloca i32, align 4
  %50 = alloca i32, align 4
  %51 = alloca i32, align 4
  %52 = alloca i32, align 4
  %53 = alloca i32, align 4
  %54 = alloca i32, align 4
  %55 = alloca i32, align 4
  %56 = alloca i32, align 4
  %57 = alloca i32, align 4
  %58 = alloca i32, align 4
  %59 = alloca i32, align 4
  %60 = alloca i32, align 4
  %61 = alloca i32, align 4
  %62 = alloca i32, align 4
  %63 = alloca i32, align 4
  %64 = alloca i32, align 4
  %65 = alloca i32, align 4
  %66 = alloca i32, align 4
  %67 = alloca i32, align 4
  %68 = alloca i32, align 4
  %69 = alloca i32, align 4
  %70 = alloca i32, align 4
  %71 = alloca i32, align 4
  %72 = alloca i32, align 4
  %73 = alloca i32, align 4
  %74 = alloca i32, align 4
  %75 = alloca i32, align 4
  %76 = alloca i32, align 4
  %77 = alloca i32, align 4
  %78 = alloca i32, align 4
  %79 = alloca i32, align 4
  %80 = alloca i32, align 4
  %81 = alloca i32, align 4
  %82 = alloca i32, align 4
  %83 = alloca i32, align 4
  %84 = alloca i32, align 4
  %85 = alloca i32, align 4
  store i32 %0, ptr %3, align 4
  store i32 %1, ptr %4, align 4
  %86 = load i32, ptr %3, align 4
  %87 = and i32 %86, 65535
  store i32 %87, ptr %5, align 4
  %88 = load i32, ptr %5, align 4
  %89 = load i32, ptr %3, align 4
  %90 = lshr i32 %89, 16
  store i32 %90, ptr %6, align 4
  %91 = load i32, ptr %6, align 4
  %92 = load i32, ptr %4, align 4
  %93 = and i32 %92, 65535
  store i32 %93, ptr %7, align 4
  %94 = load i32, ptr %7, align 4
  %95 = load i32, ptr %4, align 4
  %96 = lshr i32 %95, 16
  store i32 %96, ptr %8, align 4
  %97 = load i32, ptr %8, align 4
  %98 = load i32, ptr %7, align 4
  %99 = and i32 %98, 255
  store i32 %99, ptr %9, align 4
  %100 = load i32, ptr %9, align 4
  %101 = load i32, ptr %8, align 4
  %102 = and i32 %101, 0
  store i32 %102, ptr %10, align 4
  %103 = load i32, ptr %10, align 4
  %104 = load i32, ptr %5, align 4
  %105 = load i32, ptr %9, align 4
  %106 = add i32 %104, %105
  store i32 %106, ptr %11, align 4
  %107 = load i32, ptr %11, align 4
  %108 = load i32, ptr %11, align 4
  %109 = and i32 %108, 65535
  store i32 %109, ptr %12, align 4
  %110 = load i32, ptr %12, align 4
  %111 = load i32, ptr %6, align 4
  %112 = load i32, ptr %10, align 4
  %113 = add i32 %111, %112
  %114 = load i32, ptr %11, align 4
  %115 = lshr i32 %114, 16
  %116 = add i32 %113, %115
  %117 = and i32 %116, 65535
  store i32 %117, ptr %13, align 4
  %118 = load i32, ptr %13, align 4
  %119 = load i32, ptr %12, align 4
  %120 = shl i32 %119, 10
  %121 = and i32 %120, 65535
  store i32 %121, ptr %14, align 4
  %122 = load i32, ptr %14, align 4
  %123 = load i32, ptr %13, align 4
  %124 = shl i32 %123, 10
  %125 = load i32, ptr %12, align 4
  %126 = lshr i32 %125, 6
  %127 = or i32 %124, %126
  %128 = and i32 %127, 65535
  store i32 %128, ptr %15, align 4
  %129 = load i32, ptr %15, align 4
  %130 = load i32, ptr %12, align 4
  %131 = load i32, ptr %14, align 4
  %132 = add i32 %130, %131
  store i32 %132, ptr %16, align 4
  %133 = load i32, ptr %16, align 4
  %134 = load i32, ptr %16, align 4
  %135 = and i32 %134, 65535
  store i32 %135, ptr %17, align 4
  %136 = load i32, ptr %17, align 4
  %137 = load i32, ptr %13, align 4
  %138 = load i32, ptr %15, align 4
  %139 = add i32 %137, %138
  %140 = load i32, ptr %16, align 4
  %141 = lshr i32 %140, 16
  %142 = add i32 %139, %141
  %143 = and i32 %142, 65535
  store i32 %143, ptr %18, align 4
  %144 = load i32, ptr %18, align 4
  %145 = load i32, ptr %17, align 4
  %146 = lshr i32 %145, 6
  %147 = load i32, ptr %18, align 4
  %148 = shl i32 %147, 10
  %149 = or i32 %146, %148
  %150 = and i32 %149, 65535
  store i32 %150, ptr %19, align 4
  %151 = load i32, ptr %19, align 4
  %152 = load i32, ptr %18, align 4
  %153 = lshr i32 %152, 6
  store i32 %153, ptr %20, align 4
  %154 = load i32, ptr %20, align 4
  %155 = load i32, ptr %17, align 4
  %156 = load i32, ptr %19, align 4
  %157 = xor i32 %155, %156
  store i32 %157, ptr %21, align 4
  %158 = load i32, ptr %21, align 4
  %159 = load i32, ptr %18, align 4
  %160 = load i32, ptr %20, align 4
  %161 = xor i32 %159, %160
  store i32 %161, ptr %22, align 4
  %162 = load i32, ptr %22, align 4
  %163 = load i32, ptr %7, align 4
  %164 = lshr i32 %163, 8
  %165 = load i32, ptr %8, align 4
  %166 = shl i32 %165, 8
  %167 = or i32 %164, %166
  %168 = and i32 %167, 65535
  store i32 %168, ptr %23, align 4
  %169 = load i32, ptr %23, align 4
  %170 = load i32, ptr %8, align 4
  %171 = lshr i32 %170, 8
  store i32 %171, ptr %24, align 4
  %172 = load i32, ptr %24, align 4
  %173 = load i32, ptr %23, align 4
  %174 = and i32 %173, 255
  store i32 %174, ptr %25, align 4
  %175 = load i32, ptr %25, align 4
  %176 = load i32, ptr %24, align 4
  %177 = and i32 %176, 0
  store i32 %177, ptr %26, align 4
  %178 = load i32, ptr %26, align 4
  %179 = load i32, ptr %21, align 4
  %180 = load i32, ptr %25, align 4
  %181 = add i32 %179, %180
  store i32 %181, ptr %27, align 4
  %182 = load i32, ptr %27, align 4
  %183 = load i32, ptr %27, align 4
  %184 = and i32 %183, 65535
  store i32 %184, ptr %28, align 4
  %185 = load i32, ptr %28, align 4
  %186 = load i32, ptr %22, align 4
  %187 = load i32, ptr %26, align 4
  %188 = add i32 %186, %187
  %189 = load i32, ptr %27, align 4
  %190 = lshr i32 %189, 16
  %191 = add i32 %188, %190
  %192 = and i32 %191, 65535
  store i32 %192, ptr %29, align 4
  %193 = load i32, ptr %29, align 4
  %194 = load i32, ptr %28, align 4
  %195 = shl i32 %194, 10
  %196 = and i32 %195, 65535
  store i32 %196, ptr %30, align 4
  %197 = load i32, ptr %30, align 4
  %198 = load i32, ptr %29, align 4
  %199 = shl i32 %198, 10
  %200 = load i32, ptr %28, align 4
  %201 = lshr i32 %200, 6
  %202 = or i32 %199, %201
  %203 = and i32 %202, 65535
  store i32 %203, ptr %31, align 4
  %204 = load i32, ptr %31, align 4
  %205 = load i32, ptr %28, align 4
  %206 = load i32, ptr %30, align 4
  %207 = add i32 %205, %206
  store i32 %207, ptr %32, align 4
  %208 = load i32, ptr %32, align 4
  %209 = load i32, ptr %32, align 4
  %210 = and i32 %209, 65535
  store i32 %210, ptr %33, align 4
  %211 = load i32, ptr %33, align 4
  %212 = load i32, ptr %29, align 4
  %213 = load i32, ptr %31, align 4
  %214 = add i32 %212, %213
  %215 = load i32, ptr %32, align 4
  %216 = lshr i32 %215, 16
  %217 = add i32 %214, %216
  %218 = and i32 %217, 65535
  store i32 %218, ptr %34, align 4
  %219 = load i32, ptr %34, align 4
  %220 = load i32, ptr %33, align 4
  %221 = lshr i32 %220, 6
  %222 = load i32, ptr %34, align 4
  %223 = shl i32 %222, 10
  %224 = or i32 %221, %223
  %225 = and i32 %224, 65535
  store i32 %225, ptr %35, align 4
  %226 = load i32, ptr %35, align 4
  %227 = load i32, ptr %34, align 4
  %228 = lshr i32 %227, 6
  store i32 %228, ptr %36, align 4
  %229 = load i32, ptr %36, align 4
  %230 = load i32, ptr %33, align 4
  %231 = load i32, ptr %35, align 4
  %232 = xor i32 %230, %231
  store i32 %232, ptr %37, align 4
  %233 = load i32, ptr %37, align 4
  %234 = load i32, ptr %34, align 4
  %235 = load i32, ptr %36, align 4
  %236 = xor i32 %234, %235
  store i32 %236, ptr %38, align 4
  %237 = load i32, ptr %38, align 4
  %238 = load i32, ptr %23, align 4
  %239 = lshr i32 %238, 8
  %240 = load i32, ptr %24, align 4
  %241 = shl i32 %240, 8
  %242 = or i32 %239, %241
  %243 = and i32 %242, 65535
  store i32 %243, ptr %39, align 4
  %244 = load i32, ptr %39, align 4
  %245 = load i32, ptr %24, align 4
  %246 = lshr i32 %245, 8
  store i32 %246, ptr %40, align 4
  %247 = load i32, ptr %40, align 4
  %248 = load i32, ptr %39, align 4
  %249 = and i32 %248, 255
  store i32 %249, ptr %41, align 4
  %250 = load i32, ptr %41, align 4
  %251 = load i32, ptr %40, align 4
  %252 = and i32 %251, 0
  store i32 %252, ptr %42, align 4
  %253 = load i32, ptr %42, align 4
  %254 = load i32, ptr %37, align 4
  %255 = load i32, ptr %41, align 4
  %256 = add i32 %254, %255
  store i32 %256, ptr %43, align 4
  %257 = load i32, ptr %43, align 4
  %258 = load i32, ptr %43, align 4
  %259 = and i32 %258, 65535
  store i32 %259, ptr %44, align 4
  %260 = load i32, ptr %44, align 4
  %261 = load i32, ptr %38, align 4
  %262 = load i32, ptr %42, align 4
  %263 = add i32 %261, %262
  %264 = load i32, ptr %43, align 4
  %265 = lshr i32 %264, 16
  %266 = add i32 %263, %265
  %267 = and i32 %266, 65535
  store i32 %267, ptr %45, align 4
  %268 = load i32, ptr %45, align 4
  %269 = load i32, ptr %44, align 4
  %270 = shl i32 %269, 10
  %271 = and i32 %270, 65535
  store i32 %271, ptr %46, align 4
  %272 = load i32, ptr %46, align 4
  %273 = load i32, ptr %45, align 4
  %274 = shl i32 %273, 10
  %275 = load i32, ptr %44, align 4
  %276 = lshr i32 %275, 6
  %277 = or i32 %274, %276
  %278 = and i32 %277, 65535
  store i32 %278, ptr %47, align 4
  %279 = load i32, ptr %47, align 4
  %280 = load i32, ptr %44, align 4
  %281 = load i32, ptr %46, align 4
  %282 = add i32 %280, %281
  store i32 %282, ptr %48, align 4
  %283 = load i32, ptr %48, align 4
  %284 = load i32, ptr %48, align 4
  %285 = and i32 %284, 65535
  store i32 %285, ptr %49, align 4
  %286 = load i32, ptr %49, align 4
  %287 = load i32, ptr %45, align 4
  %288 = load i32, ptr %47, align 4
  %289 = add i32 %287, %288
  %290 = load i32, ptr %48, align 4
  %291 = lshr i32 %290, 16
  %292 = add i32 %289, %291
  %293 = and i32 %292, 65535
  store i32 %293, ptr %50, align 4
  %294 = load i32, ptr %50, align 4
  %295 = load i32, ptr %49, align 4
  %296 = lshr i32 %295, 6
  %297 = load i32, ptr %50, align 4
  %298 = shl i32 %297, 10
  %299 = or i32 %296, %298
  %300 = and i32 %299, 65535
  store i32 %300, ptr %51, align 4
  %301 = load i32, ptr %51, align 4
  %302 = load i32, ptr %50, align 4
  %303 = lshr i32 %302, 6
  store i32 %303, ptr %52, align 4
  %304 = load i32, ptr %52, align 4
  %305 = load i32, ptr %49, align 4
  %306 = load i32, ptr %51, align 4
  %307 = xor i32 %305, %306
  store i32 %307, ptr %53, align 4
  %308 = load i32, ptr %53, align 4
  %309 = load i32, ptr %50, align 4
  %310 = load i32, ptr %52, align 4
  %311 = xor i32 %309, %310
  store i32 %311, ptr %54, align 4
  %312 = load i32, ptr %54, align 4
  %313 = load i32, ptr %39, align 4
  %314 = lshr i32 %313, 8
  %315 = load i32, ptr %40, align 4
  %316 = shl i32 %315, 8
  %317 = or i32 %314, %316
  %318 = and i32 %317, 65535
  store i32 %318, ptr %55, align 4
  %319 = load i32, ptr %55, align 4
  %320 = load i32, ptr %40, align 4
  %321 = lshr i32 %320, 8
  store i32 %321, ptr %56, align 4
  %322 = load i32, ptr %56, align 4
  %323 = load i32, ptr %55, align 4
  %324 = and i32 %323, 255
  store i32 %324, ptr %57, align 4
  %325 = load i32, ptr %57, align 4
  %326 = load i32, ptr %56, align 4
  %327 = and i32 %326, 0
  store i32 %327, ptr %58, align 4
  %328 = load i32, ptr %58, align 4
  %329 = load i32, ptr %53, align 4
  %330 = load i32, ptr %57, align 4
  %331 = add i32 %329, %330
  store i32 %331, ptr %59, align 4
  %332 = load i32, ptr %59, align 4
  %333 = load i32, ptr %59, align 4
  %334 = and i32 %333, 65535
  store i32 %334, ptr %60, align 4
  %335 = load i32, ptr %60, align 4
  %336 = load i32, ptr %54, align 4
  %337 = load i32, ptr %58, align 4
  %338 = add i32 %336, %337
  %339 = load i32, ptr %59, align 4
  %340 = lshr i32 %339, 16
  %341 = add i32 %338, %340
  %342 = and i32 %341, 65535
  store i32 %342, ptr %61, align 4
  %343 = load i32, ptr %61, align 4
  %344 = load i32, ptr %60, align 4
  %345 = shl i32 %344, 10
  %346 = and i32 %345, 65535
  store i32 %346, ptr %62, align 4
  %347 = load i32, ptr %62, align 4
  %348 = load i32, ptr %61, align 4
  %349 = shl i32 %348, 10
  %350 = load i32, ptr %60, align 4
  %351 = lshr i32 %350, 6
  %352 = or i32 %349, %351
  %353 = and i32 %352, 65535
  store i32 %353, ptr %63, align 4
  %354 = load i32, ptr %63, align 4
  %355 = load i32, ptr %60, align 4
  %356 = load i32, ptr %62, align 4
  %357 = add i32 %355, %356
  store i32 %357, ptr %64, align 4
  %358 = load i32, ptr %64, align 4
  %359 = load i32, ptr %64, align 4
  %360 = and i32 %359, 65535
  store i32 %360, ptr %65, align 4
  %361 = load i32, ptr %65, align 4
  %362 = load i32, ptr %61, align 4
  %363 = load i32, ptr %63, align 4
  %364 = add i32 %362, %363
  %365 = load i32, ptr %64, align 4
  %366 = lshr i32 %365, 16
  %367 = add i32 %364, %366
  %368 = and i32 %367, 65535
  store i32 %368, ptr %66, align 4
  %369 = load i32, ptr %66, align 4
  %370 = load i32, ptr %65, align 4
  %371 = lshr i32 %370, 6
  %372 = load i32, ptr %66, align 4
  %373 = shl i32 %372, 10
  %374 = or i32 %371, %373
  %375 = and i32 %374, 65535
  store i32 %375, ptr %67, align 4
  %376 = load i32, ptr %67, align 4
  %377 = load i32, ptr %66, align 4
  %378 = lshr i32 %377, 6
  store i32 %378, ptr %68, align 4
  %379 = load i32, ptr %68, align 4
  %380 = load i32, ptr %65, align 4
  %381 = load i32, ptr %67, align 4
  %382 = xor i32 %380, %381
  store i32 %382, ptr %69, align 4
  %383 = load i32, ptr %69, align 4
  %384 = load i32, ptr %66, align 4
  %385 = load i32, ptr %68, align 4
  %386 = xor i32 %384, %385
  store i32 %386, ptr %70, align 4
  %387 = load i32, ptr %70, align 4
  %388 = load i32, ptr %69, align 4
  %389 = shl i32 %388, 3
  %390 = and i32 %389, 65535
  store i32 %390, ptr %71, align 4
  %391 = load i32, ptr %71, align 4
  %392 = load i32, ptr %70, align 4
  %393 = shl i32 %392, 3
  %394 = load i32, ptr %69, align 4
  %395 = lshr i32 %394, 13
  %396 = or i32 %393, %395
  %397 = and i32 %396, 65535
  store i32 %397, ptr %72, align 4
  %398 = load i32, ptr %72, align 4
  %399 = load i32, ptr %69, align 4
  %400 = load i32, ptr %71, align 4
  %401 = add i32 %399, %400
  store i32 %401, ptr %73, align 4
  %402 = load i32, ptr %73, align 4
  %403 = load i32, ptr %73, align 4
  %404 = and i32 %403, 65535
  store i32 %404, ptr %74, align 4
  %405 = load i32, ptr %74, align 4
  %406 = load i32, ptr %70, align 4
  %407 = load i32, ptr %72, align 4
  %408 = add i32 %406, %407
  %409 = load i32, ptr %73, align 4
  %410 = lshr i32 %409, 16
  %411 = add i32 %408, %410
  %412 = and i32 %411, 65535
  store i32 %412, ptr %75, align 4
  %413 = load i32, ptr %75, align 4
  %414 = load i32, ptr %74, align 4
  %415 = lshr i32 %414, 11
  %416 = load i32, ptr %75, align 4
  %417 = shl i32 %416, 5
  %418 = or i32 %415, %417
  %419 = and i32 %418, 65535
  store i32 %419, ptr %76, align 4
  %420 = load i32, ptr %76, align 4
  %421 = load i32, ptr %75, align 4
  %422 = lshr i32 %421, 11
  store i32 %422, ptr %77, align 4
  %423 = load i32, ptr %77, align 4
  %424 = load i32, ptr %74, align 4
  %425 = load i32, ptr %76, align 4
  %426 = xor i32 %424, %425
  store i32 %426, ptr %78, align 4
  %427 = load i32, ptr %78, align 4
  %428 = load i32, ptr %75, align 4
  %429 = load i32, ptr %77, align 4
  %430 = xor i32 %428, %429
  store i32 %430, ptr %79, align 4
  %431 = load i32, ptr %79, align 4
  %432 = load i32, ptr %78, align 4
  %433 = shl i32 %432, 15
  %434 = and i32 %433, 65535
  store i32 %434, ptr %80, align 4
  %435 = load i32, ptr %80, align 4
  %436 = load i32, ptr %79, align 4
  %437 = shl i32 %436, 15
  %438 = load i32, ptr %78, align 4
  %439 = lshr i32 %438, 1
  %440 = or i32 %437, %439
  %441 = and i32 %440, 65535
  store i32 %441, ptr %81, align 4
  %442 = load i32, ptr %81, align 4
  %443 = load i32, ptr %78, align 4
  %444 = load i32, ptr %80, align 4
  %445 = add i32 %443, %444
  store i32 %445, ptr %82, align 4
  %446 = load i32, ptr %82, align 4
  %447 = load i32, ptr %82, align 4
  %448 = and i32 %447, 65535
  store i32 %448, ptr %83, align 4
  %449 = load i32, ptr %83, align 4
  %450 = load i32, ptr %79, align 4
  %451 = load i32, ptr %81, align 4
  %452 = add i32 %450, %451
  %453 = load i32, ptr %82, align 4
  %454 = lshr i32 %453, 16
  %455 = add i32 %452, %454
  %456 = and i32 %455, 65535
  store i32 %456, ptr %84, align 4
  %457 = load i32, ptr %84, align 4
  %458 = load i32, ptr %83, align 4
  %459 = load i32, ptr %84, align 4
  %460 = shl i32 %459, 16
  %461 = or i32 %458, %460
  store i32 %461, ptr %85, align 4
  %462 = load i32, ptr %85, align 4
  %463 = load i32, ptr %85, align 4
  ret i32 %463
}

attributes #0 = { noinline nounwind optnone uwtable "frame-pointer"="non-leaf" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+fp-armv8,+neon,+outline-atomics,+v8a,-fmv" }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 1, !"wchar_size", i32 4}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 1}
!5 = !{!"Ubuntu clang version 18.1.3 (1ubuntu1)"}
