
/work/experiments/runs/jenkins-composition-matrix-linux-20261110/jenkins_word/build-clang-O0-limbs16/program:	file format elf64-littleaarch64

Disassembly of section .init:

0000000000000678 <_init>:
     678:      	nop
     67c:      	stp	x29, x30, [sp, #-0x10]!
     680:      	mov	x29, sp
     684:      	bl	0x774 <call_weak_fn>
     688:      	ldp	x29, x30, [sp], #0x10
     68c:      	ret

Disassembly of section .plt:

0000000000000690 <.plt>:
     690:      	stp	x16, x30, [sp, #-0x10]!
     694:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1de5c>
     698:      	ldr	x17, [x16, #0xff8]
     69c:      	add	x16, x16, #0xff8
     6a0:      	br	x17
     6a4:      	nop
     6a8:      	nop
     6ac:      	nop

00000000000006b0 <strtoul@plt>:
     6b0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6b4:      	ldr	x17, [x16]
     6b8:      	add	x16, x16, #0x0
     6bc:      	br	x17

00000000000006c0 <__libc_start_main@plt>:
     6c0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6c4:      	ldr	x17, [x16, #0x8]
     6c8:      	add	x16, x16, #0x8
     6cc:      	br	x17

00000000000006d0 <__cxa_finalize@plt>:
     6d0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6d4:      	ldr	x17, [x16, #0x10]
     6d8:      	add	x16, x16, #0x10
     6dc:      	br	x17

00000000000006e0 <clock_gettime@plt>:
     6e0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6e4:      	ldr	x17, [x16, #0x18]
     6e8:      	add	x16, x16, #0x18
     6ec:      	br	x17

00000000000006f0 <__gmon_start__@plt>:
     6f0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6f4:      	ldr	x17, [x16, #0x20]
     6f8:      	add	x16, x16, #0x20
     6fc:      	br	x17

0000000000000700 <abort@plt>:
     700:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     704:      	ldr	x17, [x16, #0x28]
     708:      	add	x16, x16, #0x28
     70c:      	br	x17

0000000000000710 <__isoc99_scanf@plt>:
     710:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     714:      	ldr	x17, [x16, #0x30]
     718:      	add	x16, x16, #0x30
     71c:      	br	x17

0000000000000720 <printf@plt>:
     720:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     724:      	ldr	x17, [x16, #0x38]
     728:      	add	x16, x16, #0x38
     72c:      	br	x17

Disassembly of section .text:

0000000000000740 <_start>:
     740:      	nop
     744:      	mov	x29, #0x0               // =0
     748:      	mov	x30, #0x0               // =0
     74c:      	mov	x5, x0
     750:      	ldr	x1, [sp]
     754:      	add	x2, sp, #0x8
     758:      	mov	x6, sp
     75c:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1de5c>
     760:      	ldr	x0, [x0, #0xfd8]
     764:      	mov	x3, #0x0                // =0
     768:      	mov	x4, #0x0                // =0
     76c:      	bl	0x6c0 <__libc_start_main@plt>
     770:      	bl	0x700 <abort@plt>

0000000000000774 <call_weak_fn>:
     774:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1de5c>
     778:      	ldr	x0, [x0, #0xfd0]
     77c:      	cbz	x0, 0x784 <call_weak_fn+0x10>
     780:      	b	0x6f0 <__gmon_start__@plt>
     784:      	ret
     788:      	nop
     78c:      	nop

0000000000000790 <deregister_tm_clones>:
     790:      	adrp	x0, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     794:      	add	x0, x0, #0x50
     798:      	adrp	x1, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     79c:      	add	x1, x1, #0x50
     7a0:      	cmp	x1, x0
     7a4:      	b.eq	0x7bc <deregister_tm_clones+0x2c>
     7a8:      	adrp	x1, 0x1f000 <__FRAME_END__+0x1de5c>
     7ac:      	ldr	x1, [x1, #0xfc0]
     7b0:      	cbz	x1, 0x7bc <deregister_tm_clones+0x2c>
     7b4:      	mov	x16, x1
     7b8:      	br	x16
     7bc:      	ret

00000000000007c0 <register_tm_clones>:
     7c0:      	adrp	x0, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     7c4:      	add	x0, x0, #0x50
     7c8:      	adrp	x1, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     7cc:      	add	x1, x1, #0x50
     7d0:      	sub	x1, x1, x0
     7d4:      	lsr	x2, x1, #63
     7d8:      	add	x1, x2, x1, asr #3
     7dc:      	asr	x1, x1, #1
     7e0:      	cbz	x1, 0x7f8 <register_tm_clones+0x38>
     7e4:      	adrp	x2, 0x1f000 <__FRAME_END__+0x1de5c>
     7e8:      	ldr	x2, [x2, #0xfe0]
     7ec:      	cbz	x2, 0x7f8 <register_tm_clones+0x38>
     7f0:      	mov	x16, x2
     7f4:      	br	x16
     7f8:      	ret
     7fc:      	nop

0000000000000800 <__do_global_dtors_aux>:
     800:      	paciasp
     804:      	stp	x29, x30, [sp, #-0x20]!
     808:      	mov	x29, sp
     80c:      	str	x19, [sp, #0x10]
     810:      	adrp	x19, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     814:      	ldrb	w0, [x19, #0x50]
     818:      	tbnz	w0, #0x0, 0x840 <__do_global_dtors_aux+0x40>
     81c:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1de5c>
     820:      	ldr	x0, [x0, #0xfc8]
     824:      	cbz	x0, 0x834 <__do_global_dtors_aux+0x34>
     828:      	adrp	x0, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     82c:      	ldr	x0, [x0, #0x48]
     830:      	bl	0x6d0 <__cxa_finalize@plt>
     834:      	bl	0x790 <deregister_tm_clones>
     838:      	mov	w0, #0x1                // =1
     83c:      	strb	w0, [x19, #0x50]
     840:      	ldr	x19, [sp, #0x10]
     844:      	ldp	x29, x30, [sp], #0x20
     848:      	autiasp
     84c:      	ret

0000000000000850 <frame_dummy>:
     850:      	bti	c
     854:      	b	0x7c0 <register_tm_clones>

0000000000000858 <kernel>:
     858:      	sub	sp, sp, #0x160
     85c:      	str	x29, [sp, #0x150]
     860:      	str	w0, [sp, #0x14c]
     864:      	str	w1, [sp, #0x148]
     868:      	ldrh	w8, [sp, #0x14c]
     86c:      	str	w8, [sp, #0x144]
     870:      	ldr	w8, [sp, #0x14c]
     874:      	lsr	w8, w8, #16
     878:      	str	w8, [sp, #0x140]
     87c:      	ldrh	w8, [sp, #0x148]
     880:      	str	w8, [sp, #0x13c]
     884:      	ldr	w8, [sp, #0x148]
     888:      	lsr	w8, w8, #16
     88c:      	str	w8, [sp, #0x138]
     890:      	ldrb	w8, [sp, #0x13c]
     894:      	str	w8, [sp, #0x134]
     898:      	ldr	w8, [sp, #0x138]
     89c:      	mov	w9, wzr
     8a0:      	and	w8, w8, w9
     8a4:      	str	w8, [sp, #0x130]
     8a8:      	ldr	w8, [sp, #0x144]
     8ac:      	ldr	w10, [sp, #0x134]
     8b0:      	add	w8, w8, w10
     8b4:      	str	w8, [sp, #0x12c]
     8b8:      	ldrh	w8, [sp, #0x12c]
     8bc:      	str	w8, [sp, #0x128]
     8c0:      	ldr	w8, [sp, #0x140]
     8c4:      	ldr	w10, [sp, #0x130]
     8c8:      	add	w8, w8, w10
     8cc:      	ldr	w10, [sp, #0x12c]
     8d0:      	add	w8, w8, w10, lsr #16
     8d4:      	and	w8, w8, #0xffff
     8d8:      	str	w8, [sp, #0x124]
     8dc:      	ldr	w8, [sp, #0x128]
     8e0:      	lsl	w8, w8, #10
     8e4:      	and	w8, w8, #0xffff
     8e8:      	str	w8, [sp, #0x120]
     8ec:      	ldr	w10, [sp, #0x124]
     8f0:      	ldr	w8, [sp, #0x128]
     8f4:      	lsr	w8, w8, #6
     8f8:      	orr	w8, w8, w10, lsl #10
     8fc:      	and	w8, w8, #0xffff
     900:      	str	w8, [sp, #0x11c]
     904:      	ldr	w8, [sp, #0x128]
     908:      	ldr	w10, [sp, #0x120]
     90c:      	add	w8, w8, w10
     910:      	str	w8, [sp, #0x118]
     914:      	ldrh	w8, [sp, #0x118]
     918:      	str	w8, [sp, #0x114]
     91c:      	ldr	w8, [sp, #0x124]
     920:      	ldr	w10, [sp, #0x11c]
     924:      	add	w8, w8, w10
     928:      	ldr	w10, [sp, #0x118]
     92c:      	add	w8, w8, w10, lsr #16
     930:      	and	w8, w8, #0xffff
     934:      	str	w8, [sp, #0x110]
     938:      	ldr	w10, [sp, #0x114]
     93c:      	ldr	w8, [sp, #0x110]
     940:      	lsl	w8, w8, #10
     944:      	orr	w8, w8, w10, lsr #6
     948:      	and	w8, w8, #0xffff
     94c:      	str	w8, [sp, #0x10c]
     950:      	ldr	w8, [sp, #0x110]
     954:      	lsr	w8, w8, #6
     958:      	str	w8, [sp, #0x108]
     95c:      	ldr	w8, [sp, #0x114]
     960:      	ldr	w10, [sp, #0x10c]
     964:      	eor	w8, w8, w10
     968:      	str	w8, [sp, #0x104]
     96c:      	ldr	w8, [sp, #0x110]
     970:      	ldr	w10, [sp, #0x108]
     974:      	eor	w8, w8, w10
     978:      	str	w8, [sp, #0x100]
     97c:      	ldr	w10, [sp, #0x13c]
     980:      	ldr	w8, [sp, #0x138]
     984:      	lsl	w8, w8, #8
     988:      	orr	w8, w8, w10, lsr #8
     98c:      	and	w8, w8, #0xffff
     990:      	str	w8, [sp, #0xfc]
     994:      	ldr	w8, [sp, #0x138]
     998:      	lsr	w8, w8, #8
     99c:      	str	w8, [sp, #0xf8]
     9a0:      	ldrb	w8, [sp, #0xfc]
     9a4:      	str	w8, [sp, #0xf4]
     9a8:      	ldr	w8, [sp, #0xf8]
     9ac:      	and	w8, w8, w9
     9b0:      	str	w8, [sp, #0xf0]
     9b4:      	ldr	w8, [sp, #0x104]
     9b8:      	ldr	w10, [sp, #0xf4]
     9bc:      	add	w8, w8, w10
     9c0:      	str	w8, [sp, #0xec]
     9c4:      	ldrh	w8, [sp, #0xec]
     9c8:      	str	w8, [sp, #0xe8]
     9cc:      	ldr	w8, [sp, #0x100]
     9d0:      	ldr	w10, [sp, #0xf0]
     9d4:      	add	w8, w8, w10
     9d8:      	ldr	w10, [sp, #0xec]
     9dc:      	add	w8, w8, w10, lsr #16
     9e0:      	and	w8, w8, #0xffff
     9e4:      	str	w8, [sp, #0xe4]
     9e8:      	ldr	w8, [sp, #0xe8]
     9ec:      	lsl	w8, w8, #10
     9f0:      	and	w8, w8, #0xffff
     9f4:      	str	w8, [sp, #0xe0]
     9f8:      	ldr	w10, [sp, #0xe4]
     9fc:      	ldr	w8, [sp, #0xe8]
     a00:      	lsr	w8, w8, #6
     a04:      	orr	w8, w8, w10, lsl #10
     a08:      	and	w8, w8, #0xffff
     a0c:      	str	w8, [sp, #0xdc]
     a10:      	ldr	w8, [sp, #0xe8]
     a14:      	ldr	w10, [sp, #0xe0]
     a18:      	add	w8, w8, w10
     a1c:      	str	w8, [sp, #0xd8]
     a20:      	ldrh	w8, [sp, #0xd8]
     a24:      	str	w8, [sp, #0xd4]
     a28:      	ldr	w8, [sp, #0xe4]
     a2c:      	ldr	w10, [sp, #0xdc]
     a30:      	add	w8, w8, w10
     a34:      	ldr	w10, [sp, #0xd8]
     a38:      	add	w8, w8, w10, lsr #16
     a3c:      	and	w8, w8, #0xffff
     a40:      	str	w8, [sp, #0xd0]
     a44:      	ldr	w10, [sp, #0xd4]
     a48:      	ldr	w8, [sp, #0xd0]
     a4c:      	lsl	w8, w8, #10
     a50:      	orr	w8, w8, w10, lsr #6
     a54:      	and	w8, w8, #0xffff
     a58:      	str	w8, [sp, #0xcc]
     a5c:      	ldr	w8, [sp, #0xd0]
     a60:      	lsr	w8, w8, #6
     a64:      	str	w8, [sp, #0xc8]
     a68:      	ldr	w8, [sp, #0xd4]
     a6c:      	ldr	w10, [sp, #0xcc]
     a70:      	eor	w8, w8, w10
     a74:      	str	w8, [sp, #0xc4]
     a78:      	ldr	w8, [sp, #0xd0]
     a7c:      	ldr	w10, [sp, #0xc8]
     a80:      	eor	w8, w8, w10
     a84:      	str	w8, [sp, #0xc0]
     a88:      	ldr	w10, [sp, #0xfc]
     a8c:      	ldr	w8, [sp, #0xf8]
     a90:      	lsl	w8, w8, #8
     a94:      	orr	w8, w8, w10, lsr #8
     a98:      	and	w8, w8, #0xffff
     a9c:      	str	w8, [sp, #0xbc]
     aa0:      	ldr	w8, [sp, #0xf8]
     aa4:      	lsr	w8, w8, #8
     aa8:      	str	w8, [sp, #0xb8]
     aac:      	ldrb	w8, [sp, #0xbc]
     ab0:      	str	w8, [sp, #0xb4]
     ab4:      	ldr	w8, [sp, #0xb8]
     ab8:      	and	w8, w8, w9
     abc:      	str	w8, [sp, #0xb0]
     ac0:      	ldr	w8, [sp, #0xc4]
     ac4:      	ldr	w10, [sp, #0xb4]
     ac8:      	add	w8, w8, w10
     acc:      	str	w8, [sp, #0xac]
     ad0:      	ldrh	w8, [sp, #0xac]
     ad4:      	str	w8, [sp, #0xa8]
     ad8:      	ldr	w8, [sp, #0xc0]
     adc:      	ldr	w10, [sp, #0xb0]
     ae0:      	add	w8, w8, w10
     ae4:      	ldr	w10, [sp, #0xac]
     ae8:      	add	w8, w8, w10, lsr #16
     aec:      	and	w8, w8, #0xffff
     af0:      	str	w8, [sp, #0xa4]
     af4:      	ldr	w8, [sp, #0xa8]
     af8:      	lsl	w8, w8, #10
     afc:      	and	w8, w8, #0xffff
     b00:      	str	w8, [sp, #0xa0]
     b04:      	ldr	w10, [sp, #0xa4]
     b08:      	ldr	w8, [sp, #0xa8]
     b0c:      	lsr	w8, w8, #6
     b10:      	orr	w8, w8, w10, lsl #10
     b14:      	and	w8, w8, #0xffff
     b18:      	str	w8, [sp, #0x9c]
     b1c:      	ldr	w8, [sp, #0xa8]
     b20:      	ldr	w10, [sp, #0xa0]
     b24:      	add	w8, w8, w10
     b28:      	str	w8, [sp, #0x98]
     b2c:      	ldrh	w8, [sp, #0x98]
     b30:      	str	w8, [sp, #0x94]
     b34:      	ldr	w8, [sp, #0xa4]
     b38:      	ldr	w10, [sp, #0x9c]
     b3c:      	add	w8, w8, w10
     b40:      	ldr	w10, [sp, #0x98]
     b44:      	add	w8, w8, w10, lsr #16
     b48:      	and	w8, w8, #0xffff
     b4c:      	str	w8, [sp, #0x90]
     b50:      	ldr	w10, [sp, #0x94]
     b54:      	ldr	w8, [sp, #0x90]
     b58:      	lsl	w8, w8, #10
     b5c:      	orr	w8, w8, w10, lsr #6
     b60:      	and	w8, w8, #0xffff
     b64:      	str	w8, [sp, #0x8c]
     b68:      	ldr	w8, [sp, #0x90]
     b6c:      	lsr	w8, w8, #6
     b70:      	str	w8, [sp, #0x88]
     b74:      	ldr	w8, [sp, #0x94]
     b78:      	ldr	w10, [sp, #0x8c]
     b7c:      	eor	w8, w8, w10
     b80:      	str	w8, [sp, #0x84]
     b84:      	ldr	w8, [sp, #0x90]
     b88:      	ldr	w10, [sp, #0x88]
     b8c:      	eor	w8, w8, w10
     b90:      	str	w8, [sp, #0x80]
     b94:      	ldr	w10, [sp, #0xbc]
     b98:      	ldr	w8, [sp, #0xb8]
     b9c:      	lsl	w8, w8, #8
     ba0:      	orr	w8, w8, w10, lsr #8
     ba4:      	and	w8, w8, #0xffff
     ba8:      	str	w8, [sp, #0x7c]
     bac:      	ldr	w8, [sp, #0xb8]
     bb0:      	lsr	w8, w8, #8
     bb4:      	str	w8, [sp, #0x78]
     bb8:      	ldrb	w8, [sp, #0x7c]
     bbc:      	str	w8, [sp, #0x74]
     bc0:      	ldr	w8, [sp, #0x78]
     bc4:      	and	w8, w8, w9
     bc8:      	str	w8, [sp, #0x70]
     bcc:      	ldr	w8, [sp, #0x84]
     bd0:      	ldr	w9, [sp, #0x74]
     bd4:      	add	w8, w8, w9
     bd8:      	str	w8, [sp, #0x6c]
     bdc:      	ldrh	w8, [sp, #0x6c]
     be0:      	str	w8, [sp, #0x68]
     be4:      	ldr	w8, [sp, #0x80]
     be8:      	ldr	w9, [sp, #0x70]
     bec:      	add	w8, w8, w9
     bf0:      	ldr	w9, [sp, #0x6c]
     bf4:      	add	w8, w8, w9, lsr #16
     bf8:      	and	w8, w8, #0xffff
     bfc:      	str	w8, [sp, #0x64]
     c00:      	ldr	w8, [sp, #0x68]
     c04:      	lsl	w8, w8, #10
     c08:      	and	w8, w8, #0xffff
     c0c:      	str	w8, [sp, #0x60]
     c10:      	ldr	w9, [sp, #0x64]
     c14:      	ldr	w8, [sp, #0x68]
     c18:      	lsr	w8, w8, #6
     c1c:      	orr	w8, w8, w9, lsl #10
     c20:      	and	w8, w8, #0xffff
     c24:      	str	w8, [sp, #0x5c]
     c28:      	ldr	w8, [sp, #0x68]
     c2c:      	ldr	w9, [sp, #0x60]
     c30:      	add	w8, w8, w9
     c34:      	str	w8, [sp, #0x58]
     c38:      	ldrh	w8, [sp, #0x58]
     c3c:      	str	w8, [sp, #0x54]
     c40:      	ldr	w8, [sp, #0x64]
     c44:      	ldr	w9, [sp, #0x5c]
     c48:      	add	w8, w8, w9
     c4c:      	ldr	w9, [sp, #0x58]
     c50:      	add	w8, w8, w9, lsr #16
     c54:      	and	w8, w8, #0xffff
     c58:      	str	w8, [sp, #0x50]
     c5c:      	ldr	w9, [sp, #0x54]
     c60:      	ldr	w8, [sp, #0x50]
     c64:      	lsl	w8, w8, #10
     c68:      	orr	w8, w8, w9, lsr #6
     c6c:      	and	w8, w8, #0xffff
     c70:      	str	w8, [sp, #0x4c]
     c74:      	ldr	w8, [sp, #0x50]
     c78:      	lsr	w8, w8, #6
     c7c:      	str	w8, [sp, #0x48]
     c80:      	ldr	w8, [sp, #0x54]
     c84:      	ldr	w9, [sp, #0x4c]
     c88:      	eor	w8, w8, w9
     c8c:      	str	w8, [sp, #0x44]
     c90:      	ldr	w8, [sp, #0x50]
     c94:      	ldr	w9, [sp, #0x48]
     c98:      	eor	w8, w8, w9
     c9c:      	str	w8, [sp, #0x40]
     ca0:      	ldr	w8, [sp, #0x44]
     ca4:      	lsl	w8, w8, #3
     ca8:      	and	w8, w8, #0xffff
     cac:      	str	w8, [sp, #0x3c]
     cb0:      	ldr	w9, [sp, #0x40]
     cb4:      	ldr	w8, [sp, #0x44]
     cb8:      	lsr	w8, w8, #13
     cbc:      	orr	w8, w8, w9, lsl #3
     cc0:      	and	w8, w8, #0xffff
     cc4:      	str	w8, [sp, #0x38]
     cc8:      	ldr	w8, [sp, #0x44]
     ccc:      	ldr	w9, [sp, #0x3c]
     cd0:      	add	w8, w8, w9
     cd4:      	str	w8, [sp, #0x34]
     cd8:      	ldrh	w8, [sp, #0x34]
     cdc:      	str	w8, [sp, #0x30]
     ce0:      	ldr	w8, [sp, #0x40]
     ce4:      	ldr	w9, [sp, #0x38]
     ce8:      	add	w8, w8, w9
     cec:      	ldr	w9, [sp, #0x34]
     cf0:      	add	w8, w8, w9, lsr #16
     cf4:      	and	w8, w8, #0xffff
     cf8:      	str	w8, [sp, #0x2c]
     cfc:      	ldr	w9, [sp, #0x30]
     d00:      	ldr	w8, [sp, #0x2c]
     d04:      	lsl	w8, w8, #5
     d08:      	orr	w8, w8, w9, lsr #11
     d0c:      	and	w8, w8, #0xffff
     d10:      	str	w8, [sp, #0x28]
     d14:      	ldr	w8, [sp, #0x2c]
     d18:      	lsr	w8, w8, #11
     d1c:      	str	w8, [sp, #0x24]
     d20:      	ldr	w8, [sp, #0x30]
     d24:      	ldr	w9, [sp, #0x28]
     d28:      	eor	w8, w8, w9
     d2c:      	str	w8, [sp, #0x20]
     d30:      	ldr	w8, [sp, #0x2c]
     d34:      	ldr	w9, [sp, #0x24]
     d38:      	eor	w8, w8, w9
     d3c:      	str	w8, [sp, #0x1c]
     d40:      	ldr	w8, [sp, #0x20]
     d44:      	lsl	w8, w8, #15
     d48:      	and	w8, w8, #0xffff
     d4c:      	str	w8, [sp, #0x18]
     d50:      	ldr	w9, [sp, #0x1c]
     d54:      	ldr	w8, [sp, #0x20]
     d58:      	lsr	w8, w8, #1
     d5c:      	orr	w8, w8, w9, lsl #15
     d60:      	and	w8, w8, #0xffff
     d64:      	str	w8, [sp, #0x14]
     d68:      	ldr	w8, [sp, #0x20]
     d6c:      	ldr	w9, [sp, #0x18]
     d70:      	add	w8, w8, w9
     d74:      	str	w8, [sp, #0x10]
     d78:      	ldrh	w8, [sp, #0x10]
     d7c:      	str	w8, [sp, #0xc]
     d80:      	ldr	w8, [sp, #0x1c]
     d84:      	ldr	w9, [sp, #0x14]
     d88:      	add	w8, w8, w9
     d8c:      	ldr	w9, [sp, #0x10]
     d90:      	add	w8, w8, w9, lsr #16
     d94:      	and	w8, w8, #0xffff
     d98:      	str	w8, [sp, #0x8]
     d9c:      	ldr	w8, [sp, #0xc]
     da0:      	ldr	w9, [sp, #0x8]
     da4:      	orr	w8, w8, w9, lsl #16
     da8:      	str	w8, [sp, #0x4]
     dac:      	ldr	w0, [sp, #0x4]
     db0:      	ldr	x29, [sp, #0x150]
     db4:      	add	sp, sp, #0x160
     db8:      	ret

0000000000000dbc <main>:
     dbc:      	sub	sp, sp, #0x90
     dc0:      	stp	x29, x30, [sp, #0x80]
     dc4:      	add	x29, sp, #0x80
     dc8:      	stur	wzr, [x29, #-0x4]
     dcc:      	stur	w0, [x29, #-0x8]
     dd0:      	stur	x1, [x29, #-0x10]
     dd4:      	ldur	w8, [x29, #-0x8]
     dd8:      	subs	w8, w8, #0x1
     ddc:      	b.ne	0xe30 <main+0x74>
     de0:      	b	0xde4 <main+0x28>
     de4:      	b	0xde8 <main+0x2c>
     de8:      	sub	x1, x29, #0x18
     dec:      	add	x2, x1, #0x4
     df0:      	adrp	x0, 0x1000 <csrd_matrix_next_value+0x4c>
     df4:      	add	x0, x0, #0x38
     df8:      	bl	0x710 <__isoc99_scanf@plt>
     dfc:      	subs	w8, w0, #0x2
     e00:      	b.ne	0xe28 <main+0x6c>
     e04:      	b	0xe08 <main+0x4c>
     e08:      	ldur	w0, [x29, #-0x18]
     e0c:      	ldur	w1, [x29, #-0x14]
     e10:      	bl	0x858 <kernel>
     e14:      	mov	w1, w0
     e18:      	adrp	x0, 0x1000 <csrd_matrix_next_value+0x4c>
     e1c:      	add	x0, x0, #0x3d
     e20:      	bl	0x720 <printf@plt>
     e24:      	b	0xde8 <main+0x2c>
     e28:      	stur	wzr, [x29, #-0x4]
     e2c:      	b	0xfa4 <main+0x1e8>
     e30:      	ldur	w8, [x29, #-0x8]
     e34:      	subs	w8, w8, #0x3
     e38:      	b.eq	0xe4c <main+0x90>
     e3c:      	b	0xe40 <main+0x84>
     e40:      	mov	w8, #0x3                // =3
     e44:      	stur	w8, [x29, #-0x4]
     e48:      	b	0xfa4 <main+0x1e8>
     e4c:      	ldur	x8, [x29, #-0x10]
     e50:      	ldr	x0, [x8, #0x8]
     e54:      	mov	x1, xzr
     e58:      	str	x1, [sp, #0x8]
     e5c:      	mov	w2, #0xa                // =10
     e60:      	str	w2, [sp, #0x14]
     e64:      	bl	0x6b0 <strtoul@plt>
     e68:      	ldr	x1, [sp, #0x8]
     e6c:      	ldr	w2, [sp, #0x14]
     e70:      	stur	x0, [x29, #-0x20]
     e74:      	ldur	x8, [x29, #-0x10]
     e78:      	ldr	x0, [x8, #0x10]
     e7c:      	bl	0x6b0 <strtoul@plt>
     e80:      	mov	w8, w0
     e84:      	stur	w8, [x29, #-0x24]
     e88:      	stur	xzr, [x29, #-0x30]
     e8c:      	mov	w0, #0x1                // =1
     e90:      	add	x1, sp, #0x40
     e94:      	bl	0x6e0 <clock_gettime@plt>
     e98:      	cbz	w0, 0xeac <main+0xf0>
     e9c:      	b	0xea0 <main+0xe4>
     ea0:      	mov	w8, #0x2                // =2
     ea4:      	stur	w8, [x29, #-0x4]
     ea8:      	b	0xfa4 <main+0x1e8>
     eac:      	str	xzr, [sp, #0x28]
     eb0:      	b	0xeb4 <main+0xf8>
     eb4:      	ldr	x8, [sp, #0x28]
     eb8:      	ldur	x9, [x29, #-0x20]
     ebc:      	subs	x8, x8, x9
     ec0:      	b.hs	0xf38 <main+0x17c>
     ec4:      	b	0xec8 <main+0x10c>
     ec8:      	str	wzr, [sp, #0x24]
     ecc:      	b	0xed0 <main+0x114>
     ed0:      	ldr	w8, [sp, #0x24]
     ed4:      	subs	w8, w8, #0x2
     ed8:      	b.hs	0xf0c <main+0x150>
     edc:      	b	0xee0 <main+0x124>
     ee0:      	sub	x0, x29, #0x24
     ee4:      	bl	0xfb4 <csrd_matrix_next_value>
     ee8:      	ldr	w8, [sp, #0x24]
     eec:      	mov	w9, w8
     ef0:      	sub	x8, x29, #0x18
     ef4:      	str	w0, [x8, x9, lsl #2]
     ef8:      	b	0xefc <main+0x140>
     efc:      	ldr	w8, [sp, #0x24]
     f00:      	add	w8, w8, #0x1
     f04:      	str	w8, [sp, #0x24]
     f08:      	b	0xed0 <main+0x114>
     f0c:      	ldur	w0, [x29, #-0x18]
     f10:      	ldur	w1, [x29, #-0x14]
     f14:      	bl	0x858 <kernel>
     f18:      	ldur	x8, [x29, #-0x30]
     f1c:      	add	x8, x8, w0, uxtw
     f20:      	stur	x8, [x29, #-0x30]
     f24:      	b	0xf28 <main+0x16c>
     f28:      	ldr	x8, [sp, #0x28]
     f2c:      	add	x8, x8, #0x1
     f30:      	str	x8, [sp, #0x28]
     f34:      	b	0xeb4 <main+0xf8>
     f38:      	mov	w0, #0x1                // =1
     f3c:      	add	x1, sp, #0x30
     f40:      	bl	0x6e0 <clock_gettime@plt>
     f44:      	cbz	w0, 0xf58 <main+0x19c>
     f48:      	b	0xf4c <main+0x190>
     f4c:      	mov	w8, #0x2                // =2
     f50:      	stur	w8, [x29, #-0x4]
     f54:      	b	0xfa4 <main+0x1e8>
     f58:      	ldr	x8, [sp, #0x30]
     f5c:      	ldr	x9, [sp, #0x40]
     f60:      	subs	x8, x8, x9
     f64:      	scvtf	d2, x8
     f68:      	ldr	x8, [sp, #0x38]
     f6c:      	ldr	x9, [sp, #0x48]
     f70:      	subs	x8, x8, x9
     f74:      	scvtf	d0, x8
     f78:      	adrp	x8, 0x1000 <csrd_matrix_next_value+0x4c>
     f7c:      	ldr	d1, [x8, #0x30]
     f80:      	fmadd	d0, d0, d1, d2
     f84:      	str	d0, [sp, #0x18]
     f88:      	ldr	d0, [sp, #0x18]
     f8c:      	ldur	x1, [x29, #-0x30]
     f90:      	adrp	x0, 0x1000 <csrd_matrix_next_value+0x4c>
     f94:      	add	x0, x0, #0x41
     f98:      	bl	0x720 <printf@plt>
     f9c:      	stur	wzr, [x29, #-0x4]
     fa0:      	b	0xfa4 <main+0x1e8>
     fa4:      	ldur	w0, [x29, #-0x4]
     fa8:      	ldp	x29, x30, [sp, #0x80]
     fac:      	add	sp, sp, #0x90
     fb0:      	ret

0000000000000fb4 <csrd_matrix_next_value>:
     fb4:      	sub	sp, sp, #0x10
     fb8:      	str	x0, [sp, #0x8]
     fbc:      	ldr	x8, [sp, #0x8]
     fc0:      	ldr	w10, [x8]
     fc4:      	ldr	x9, [sp, #0x8]
     fc8:      	ldr	w8, [x9]
     fcc:      	eor	w8, w8, w10, lsl #13
     fd0:      	str	w8, [x9]
     fd4:      	ldr	x8, [sp, #0x8]
     fd8:      	ldr	w10, [x8]
     fdc:      	ldr	x9, [sp, #0x8]
     fe0:      	ldr	w8, [x9]
     fe4:      	eor	w8, w8, w10, lsr #17
     fe8:      	str	w8, [x9]
     fec:      	ldr	x8, [sp, #0x8]
     ff0:      	ldr	w10, [x8]
     ff4:      	ldr	x9, [sp, #0x8]
     ff8:      	ldr	w8, [x9]
     ffc:      	eor	w8, w8, w10, lsl #5
    1000:      	str	w8, [x9]
    1004:      	ldr	x8, [sp, #0x8]
    1008:      	ldr	w0, [x8]
    100c:      	add	sp, sp, #0x10
    1010:      	ret

Disassembly of section .fini:

0000000000001014 <_fini>:
    1014:      	nop
    1018:      	stp	x29, x30, [sp, #-0x10]!
    101c:      	mov	x29, sp
    1020:      	ldp	x29, x30, [sp], #0x10
    1024:      	ret
