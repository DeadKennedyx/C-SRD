
/work/experiments/runs/jenkins-composition-matrix-linux-20261110/jenkins_word/build-gcc-O1-identity/program:	file format elf64-littleaarch64

Disassembly of section .init:

0000000000000738 <_init>:
     738:      	nop
     73c:      	stp	x29, x30, [sp, #-0x10]!
     740:      	mov	x29, sp
     744:      	bl	0x834 <call_weak_fn>
     748:      	ldp	x29, x30, [sp], #0x10
     74c:      	ret

Disassembly of section .plt:

0000000000000750 <.plt>:
     750:      	stp	x16, x30, [sp, #-0x10]!
     754:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e344>
     758:      	ldr	x17, [x16, #0xf78]
     75c:      	add	x16, x16, #0xf78
     760:      	br	x17
     764:      	nop
     768:      	nop
     76c:      	nop

0000000000000770 <strtoul@plt>:
     770:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e344>
     774:      	ldr	x17, [x16, #0xf80]
     778:      	add	x16, x16, #0xf80
     77c:      	br	x17

0000000000000780 <__libc_start_main@plt>:
     780:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e344>
     784:      	ldr	x17, [x16, #0xf88]
     788:      	add	x16, x16, #0xf88
     78c:      	br	x17

0000000000000790 <__cxa_finalize@plt>:
     790:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e344>
     794:      	ldr	x17, [x16, #0xf90]
     798:      	add	x16, x16, #0xf90
     79c:      	br	x17

00000000000007a0 <clock_gettime@plt>:
     7a0:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e344>
     7a4:      	ldr	x17, [x16, #0xf98]
     7a8:      	add	x16, x16, #0xf98
     7ac:      	br	x17

00000000000007b0 <__printf_chk@plt>:
     7b0:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e344>
     7b4:      	ldr	x17, [x16, #0xfa0]
     7b8:      	add	x16, x16, #0xfa0
     7bc:      	br	x17

00000000000007c0 <__stack_chk_fail@plt>:
     7c0:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e344>
     7c4:      	ldr	x17, [x16, #0xfa8]
     7c8:      	add	x16, x16, #0xfa8
     7cc:      	br	x17

00000000000007d0 <__gmon_start__@plt>:
     7d0:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e344>
     7d4:      	ldr	x17, [x16, #0xfb0]
     7d8:      	add	x16, x16, #0xfb0
     7dc:      	br	x17

00000000000007e0 <abort@plt>:
     7e0:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e344>
     7e4:      	ldr	x17, [x16, #0xfb8]
     7e8:      	add	x16, x16, #0xfb8
     7ec:      	br	x17

00000000000007f0 <__isoc99_scanf@plt>:
     7f0:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e344>
     7f4:      	ldr	x17, [x16, #0xfc0]
     7f8:      	add	x16, x16, #0xfc0
     7fc:      	br	x17

Disassembly of section .text:

0000000000000800 <_start>:
     800:      	nop
     804:      	mov	x29, #0x0               // =0
     808:      	mov	x30, #0x0               // =0
     80c:      	mov	x5, x0
     810:      	ldr	x1, [sp]
     814:      	add	x2, sp, #0x8
     818:      	mov	x6, sp
     81c:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e344>
     820:      	ldr	x0, [x0, #0xff0]
     824:      	mov	x3, #0x0                // =0
     828:      	mov	x4, #0x0                // =0
     82c:      	bl	0x780 <__libc_start_main@plt>
     830:      	bl	0x7e0 <abort@plt>

0000000000000834 <call_weak_fn>:
     834:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e344>
     838:      	ldr	x0, [x0, #0xfe0]
     83c:      	cbz	x0, 0x844 <call_weak_fn+0x10>
     840:      	b	0x7d0 <__gmon_start__@plt>
     844:      	ret
     848:      	nop
     84c:      	nop

0000000000000850 <deregister_tm_clones>:
     850:      	adrp	x0, 0x20000 <data_start>
     854:      	add	x0, x0, #0x10
     858:      	adrp	x1, 0x20000 <data_start>
     85c:      	add	x1, x1, #0x10
     860:      	cmp	x1, x0
     864:      	b.eq	0x87c <deregister_tm_clones+0x2c>
     868:      	adrp	x1, 0x1f000 <__FRAME_END__+0x1e344>
     86c:      	ldr	x1, [x1, #0xfd0]
     870:      	cbz	x1, 0x87c <deregister_tm_clones+0x2c>
     874:      	mov	x16, x1
     878:      	br	x16
     87c:      	ret

0000000000000880 <register_tm_clones>:
     880:      	adrp	x0, 0x20000 <data_start>
     884:      	add	x0, x0, #0x10
     888:      	adrp	x1, 0x20000 <data_start>
     88c:      	add	x1, x1, #0x10
     890:      	sub	x1, x1, x0
     894:      	lsr	x2, x1, #63
     898:      	add	x1, x2, x1, asr #3
     89c:      	asr	x1, x1, #1
     8a0:      	cbz	x1, 0x8b8 <register_tm_clones+0x38>
     8a4:      	adrp	x2, 0x1f000 <__FRAME_END__+0x1e344>
     8a8:      	ldr	x2, [x2, #0xff8]
     8ac:      	cbz	x2, 0x8b8 <register_tm_clones+0x38>
     8b0:      	mov	x16, x2
     8b4:      	br	x16
     8b8:      	ret
     8bc:      	nop

00000000000008c0 <__do_global_dtors_aux>:
     8c0:      	paciasp
     8c4:      	stp	x29, x30, [sp, #-0x20]!
     8c8:      	mov	x29, sp
     8cc:      	str	x19, [sp, #0x10]
     8d0:      	adrp	x19, 0x20000 <data_start>
     8d4:      	ldrb	w0, [x19, #0x10]
     8d8:      	tbnz	w0, #0x0, 0x900 <__do_global_dtors_aux+0x40>
     8dc:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e344>
     8e0:      	ldr	x0, [x0, #0xfd8]
     8e4:      	cbz	x0, 0x8f4 <__do_global_dtors_aux+0x34>
     8e8:      	adrp	x0, 0x20000 <data_start>
     8ec:      	ldr	x0, [x0, #0x8]
     8f0:      	bl	0x790 <__cxa_finalize@plt>
     8f4:      	bl	0x850 <deregister_tm_clones>
     8f8:      	mov	w0, #0x1                // =1
     8fc:      	strb	w0, [x19, #0x10]
     900:      	ldr	x19, [sp, #0x10]
     904:      	ldp	x29, x30, [sp], #0x20
     908:      	autiasp
     90c:      	ret

0000000000000910 <frame_dummy>:
     910:      	bti	c
     914:      	b	0x880 <register_tm_clones>

0000000000000918 <kernel>:
     918:      	add	w0, w0, w1, uxtb
     91c:      	add	w0, w0, w0, lsl #10
     920:      	eor	w0, w0, w0, lsr #6
     924:      	ubfx	x2, x1, #8, #8
     928:      	add	w0, w0, w2
     92c:      	add	w0, w0, w0, lsl #10
     930:      	eor	w0, w0, w0, lsr #6
     934:      	ubfx	x2, x1, #16, #8
     938:      	add	w0, w0, w2
     93c:      	add	w0, w0, w0, lsl #10
     940:      	eor	w0, w0, w0, lsr #6
     944:      	add	w0, w0, w1, lsr #24
     948:      	add	w0, w0, w0, lsl #10
     94c:      	eor	w0, w0, w0, lsr #6
     950:      	add	w0, w0, w0, lsl #3
     954:      	eor	w0, w0, w0, lsr #11
     958:      	add	w0, w0, w0, lsl #15
     95c:      	ret

0000000000000960 <main>:
     960:      	sub	sp, sp, #0x60
     964:      	stp	x29, x30, [sp, #0x30]
     968:      	add	x29, sp, #0x30
     96c:      	stp	x19, x20, [sp, #0x40]
     970:      	mov	x19, x1
     974:      	adrp	x1, 0x1f000 <__FRAME_END__+0x1e344>
     978:      	ldr	x1, [x1, #0xfe8]
     97c:      	ldr	x2, [x1]
     980:      	str	x2, [sp, #0x28]
     984:      	mov	x2, #0x0                // =0
     988:      	cmp	w0, #0x1
     98c:      	b.eq	0x9cc <main+0x6c>
     990:      	mov	w20, #0x3               // =3
     994:      	cmp	w0, w20
     998:      	b.eq	0xa2c <main+0xcc>
     99c:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e344>
     9a0:      	ldr	x0, [x0, #0xfe8]
     9a4:      	ldr	x2, [sp, #0x28]
     9a8:      	ldr	x1, [x0]
     9ac:      	subs	x2, x2, x1
     9b0:      	mov	x1, #0x0                // =0
     9b4:      	b.ne	0xb34 <main+0x1d4>
     9b8:      	mov	w0, w20
     9bc:      	ldp	x19, x20, [sp, #0x40]
     9c0:      	ldp	x29, x30, [sp, #0x30]
     9c4:      	add	sp, sp, #0x60
     9c8:      	ret
     9cc:      	stp	x21, x22, [sp, #0x50]
     9d0:      	add	x22, sp, #0x20
     9d4:      	add	x21, sp, #0x24
     9d8:      	adrp	x19, 0x0 <strtoul@GLIBC_2.17>
     9dc:      	add	x19, x19, #0xb60
     9e0:      	adrp	x20, 0x0 <strtoul@GLIBC_2.17>
     9e4:      	add	x20, x20, #0xb58
     9e8:      	b	0xa08 <main+0xa8>
     9ec:      	ldr	w1, [sp, #0x24]
     9f0:      	ldr	w0, [sp, #0x20]
     9f4:      	bl	0x918 <kernel>
     9f8:      	mov	w2, w0
     9fc:      	mov	x1, x20
     a00:      	mov	w0, #0x2                // =2
     a04:      	bl	0x7b0 <__printf_chk@plt>
     a08:      	mov	x2, x21
     a0c:      	mov	x1, x22
     a10:      	mov	x0, x19
     a14:      	bl	0x7f0 <__isoc99_scanf@plt>
     a18:      	cmp	w0, #0x2
     a1c:      	b.eq	0x9ec <main+0x8c>
     a20:      	mov	w20, #0x0               // =0
     a24:      	ldp	x21, x22, [sp, #0x50]
     a28:      	b	0x99c <main+0x3c>
     a2c:      	stp	x21, x22, [sp, #0x50]
     a30:      	mov	w2, #0xa                // =10
     a34:      	mov	x1, #0x0                // =0
     a38:      	ldr	x0, [x19, #0x8]
     a3c:      	bl	0x770 <strtoul@plt>
     a40:      	mov	x21, x0
     a44:      	mov	w2, #0xa                // =10
     a48:      	mov	x1, #0x0                // =0
     a4c:      	ldr	x0, [x19, #0x10]
     a50:      	bl	0x770 <strtoul@plt>
     a54:      	mov	x19, x0
     a58:      	mov	x1, sp
     a5c:      	mov	w0, #0x1                // =1
     a60:      	bl	0x7a0 <clock_gettime@plt>
     a64:      	cbnz	w0, 0xb1c <main+0x1bc>
     a68:      	cbz	x21, 0xb14 <main+0x1b4>
     a6c:      	mov	x20, #0x0               // =0
     a70:      	mov	x22, #0x0               // =0
     a74:      	eor	w19, w19, w19, lsl #13
     a78:      	eor	w19, w19, w19, lsr #17
     a7c:      	eor	w0, w19, w19, lsl #5
     a80:      	str	w0, [sp, #0x20]
     a84:      	eor	w19, w0, w0, lsl #13
     a88:      	eor	w19, w19, w19, lsr #17
     a8c:      	eor	w19, w19, w19, lsl #5
     a90:      	str	w19, [sp, #0x24]
     a94:      	mov	w1, w19
     a98:      	bl	0x918 <kernel>
     a9c:      	add	x22, x22, w0, uxtw
     aa0:      	add	x20, x20, #0x1
     aa4:      	cmp	x21, x20
     aa8:      	b.ne	0xa74 <main+0x114>
     aac:      	add	x1, sp, #0x10
     ab0:      	mov	w0, #0x1                // =1
     ab4:      	bl	0x7a0 <clock_gettime@plt>
     ab8:      	mov	w20, w0
     abc:      	cbnz	w0, 0xb28 <main+0x1c8>
     ac0:      	ldr	x0, [sp, #0x18]
     ac4:      	ldr	x1, [sp, #0x8]
     ac8:      	sub	x0, x0, x1
     acc:      	fmov	d1, x0
     ad0:      	scvtf	d1, d1
     ad4:      	adrp	x0, 0x0 <strtoul@GLIBC_2.17>
     ad8:      	ldr	d0, [x0, #0xb78]
     adc:      	fmul	d1, d1, d0
     ae0:      	ldr	x0, [sp, #0x10]
     ae4:      	ldr	x1, [sp]
     ae8:      	sub	x0, x0, x1
     aec:      	fmov	d0, x0
     af0:      	scvtf	d0, d0
     af4:      	mov	x2, x22
     af8:      	fadd	d0, d1, d0
     afc:      	adrp	x1, 0x0 <strtoul@GLIBC_2.17>
     b00:      	add	x1, x1, #0xb68
     b04:      	mov	w0, #0x2                // =2
     b08:      	bl	0x7b0 <__printf_chk@plt>
     b0c:      	ldp	x21, x22, [sp, #0x50]
     b10:      	b	0x99c <main+0x3c>
     b14:      	mov	x22, x21
     b18:      	b	0xaac <main+0x14c>
     b1c:      	mov	w20, #0x2               // =2
     b20:      	ldp	x21, x22, [sp, #0x50]
     b24:      	b	0x99c <main+0x3c>
     b28:      	mov	w20, #0x2               // =2
     b2c:      	ldp	x21, x22, [sp, #0x50]
     b30:      	b	0x99c <main+0x3c>
     b34:      	stp	x21, x22, [sp, #0x50]
     b38:      	bl	0x7c0 <__stack_chk_fail@plt>

Disassembly of section .fini:

0000000000000b3c <_fini>:
     b3c:      	nop
     b40:      	stp	x29, x30, [sp, #-0x10]!
     b44:      	mov	x29, sp
     b48:      	ldp	x29, x30, [sp], #0x10
     b4c:      	ret
