
/work/experiments/runs/jenkins-composition-matrix-linux-20261110/jenkins_word/build-clang-O0-affine-42/program:	file format elf64-littleaarch64

Disassembly of section .init:

0000000000000678 <_init>:
     678:      	nop
     67c:      	stp	x29, x30, [sp, #-0x10]!
     680:      	mov	x29, sp
     684:      	bl	0x774 <call_weak_fn>
     688:      	ldp	x29, x30, [sp], #0x10
     68c:      	ret

Disassembly of section .plt:

0000000000000690 <.plt>:
     690:      	stp	x16, x30, [sp, #-0x10]!
     694:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e004>
     698:      	ldr	x17, [x16, #0xff8]
     69c:      	add	x16, x16, #0xff8
     6a0:      	br	x17
     6a4:      	nop
     6a8:      	nop
     6ac:      	nop

00000000000006b0 <strtoul@plt>:
     6b0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6b4:      	ldr	x17, [x16]
     6b8:      	add	x16, x16, #0x0
     6bc:      	br	x17

00000000000006c0 <__libc_start_main@plt>:
     6c0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6c4:      	ldr	x17, [x16, #0x8]
     6c8:      	add	x16, x16, #0x8
     6cc:      	br	x17

00000000000006d0 <__cxa_finalize@plt>:
     6d0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6d4:      	ldr	x17, [x16, #0x10]
     6d8:      	add	x16, x16, #0x10
     6dc:      	br	x17

00000000000006e0 <clock_gettime@plt>:
     6e0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6e4:      	ldr	x17, [x16, #0x18]
     6e8:      	add	x16, x16, #0x18
     6ec:      	br	x17

00000000000006f0 <__gmon_start__@plt>:
     6f0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6f4:      	ldr	x17, [x16, #0x20]
     6f8:      	add	x16, x16, #0x20
     6fc:      	br	x17

0000000000000700 <abort@plt>:
     700:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     704:      	ldr	x17, [x16, #0x28]
     708:      	add	x16, x16, #0x28
     70c:      	br	x17

0000000000000710 <__isoc99_scanf@plt>:
     710:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     714:      	ldr	x17, [x16, #0x30]
     718:      	add	x16, x16, #0x30
     71c:      	br	x17

0000000000000720 <printf@plt>:
     720:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     724:      	ldr	x17, [x16, #0x38]
     728:      	add	x16, x16, #0x38
     72c:      	br	x17

Disassembly of section .text:

0000000000000740 <_start>:
     740:      	nop
     744:      	mov	x29, #0x0               // =0
     748:      	mov	x30, #0x0               // =0
     74c:      	mov	x5, x0
     750:      	ldr	x1, [sp]
     754:      	add	x2, sp, #0x8
     758:      	mov	x6, sp
     75c:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e004>
     760:      	ldr	x0, [x0, #0xfd8]
     764:      	mov	x3, #0x0                // =0
     768:      	mov	x4, #0x0                // =0
     76c:      	bl	0x6c0 <__libc_start_main@plt>
     770:      	bl	0x700 <abort@plt>

0000000000000774 <call_weak_fn>:
     774:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e004>
     778:      	ldr	x0, [x0, #0xfd0]
     77c:      	cbz	x0, 0x784 <call_weak_fn+0x10>
     780:      	b	0x6f0 <__gmon_start__@plt>
     784:      	ret
     788:      	nop
     78c:      	nop

0000000000000790 <deregister_tm_clones>:
     790:      	adrp	x0, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     794:      	add	x0, x0, #0x50
     798:      	adrp	x1, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     79c:      	add	x1, x1, #0x50
     7a0:      	cmp	x1, x0
     7a4:      	b.eq	0x7bc <deregister_tm_clones+0x2c>
     7a8:      	adrp	x1, 0x1f000 <__FRAME_END__+0x1e004>
     7ac:      	ldr	x1, [x1, #0xfc0]
     7b0:      	cbz	x1, 0x7bc <deregister_tm_clones+0x2c>
     7b4:      	mov	x16, x1
     7b8:      	br	x16
     7bc:      	ret

00000000000007c0 <register_tm_clones>:
     7c0:      	adrp	x0, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     7c4:      	add	x0, x0, #0x50
     7c8:      	adrp	x1, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     7cc:      	add	x1, x1, #0x50
     7d0:      	sub	x1, x1, x0
     7d4:      	lsr	x2, x1, #63
     7d8:      	add	x1, x2, x1, asr #3
     7dc:      	asr	x1, x1, #1
     7e0:      	cbz	x1, 0x7f8 <register_tm_clones+0x38>
     7e4:      	adrp	x2, 0x1f000 <__FRAME_END__+0x1e004>
     7e8:      	ldr	x2, [x2, #0xfe0]
     7ec:      	cbz	x2, 0x7f8 <register_tm_clones+0x38>
     7f0:      	mov	x16, x2
     7f4:      	br	x16
     7f8:      	ret
     7fc:      	nop

0000000000000800 <__do_global_dtors_aux>:
     800:      	paciasp
     804:      	stp	x29, x30, [sp, #-0x20]!
     808:      	mov	x29, sp
     80c:      	str	x19, [sp, #0x10]
     810:      	adrp	x19, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     814:      	ldrb	w0, [x19, #0x50]
     818:      	tbnz	w0, #0x0, 0x840 <__do_global_dtors_aux+0x40>
     81c:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e004>
     820:      	ldr	x0, [x0, #0xfc8]
     824:      	cbz	x0, 0x834 <__do_global_dtors_aux+0x34>
     828:      	adrp	x0, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     82c:      	ldr	x0, [x0, #0x48]
     830:      	bl	0x6d0 <__cxa_finalize@plt>
     834:      	bl	0x790 <deregister_tm_clones>
     838:      	mov	w0, #0x1                // =1
     83c:      	strb	w0, [x19, #0x50]
     840:      	ldr	x19, [sp, #0x10]
     844:      	ldp	x29, x30, [sp], #0x20
     848:      	autiasp
     84c:      	ret

0000000000000850 <frame_dummy>:
     850:      	bti	c
     854:      	b	0x7c0 <register_tm_clones>

0000000000000858 <kernel>:
     858:      	sub	sp, sp, #0x110
     85c:      	str	x29, [sp, #0x100]
     860:      	mov	w9, #0x1e59             // =7769
     864:      	movk	w9, #0x77d7, lsl #16
     868:      	mov	w10, #0x7c47            // =31815
     86c:      	movk	w10, #0x1093, lsl #16
     870:      	mov	w8, #0x49e9             // =18921
     874:      	movk	w8, #0x9c3e, lsl #16
     878:      	str	w0, [sp, #0xfc]
     87c:      	str	w1, [sp, #0xf8]
     880:      	ldrb	w11, [sp, #0xf8]
     884:      	str	w11, [sp, #0xf4]
     888:      	ldr	w11, [sp, #0xfc]
     88c:      	mul	w11, w9, w11
     890:      	add	w11, w11, w10
     894:      	str	w11, [sp, #0xf0]
     898:      	ldr	w11, [sp, #0xf4]
     89c:      	mul	w11, w9, w11
     8a0:      	add	w11, w11, w10
     8a4:      	str	w11, [sp, #0xec]
     8a8:      	ldr	w11, [sp, #0xf0]
     8ac:      	ldr	w12, [sp, #0xec]
     8b0:      	add	w11, w11, w12
     8b4:      	subs	w11, w11, w10
     8b8:      	str	w11, [sp, #0xe8]
     8bc:      	ldr	w11, [sp, #0xe8]
     8c0:      	subs	w11, w11, w10
     8c4:      	mul	w11, w8, w11
     8c8:      	str	w11, [sp, #0xe4]
     8cc:      	ldr	w11, [sp, #0xe4]
     8d0:      	lsl	w11, w11, #10
     8d4:      	str	w11, [sp, #0xe0]
     8d8:      	ldr	w11, [sp, #0xe0]
     8dc:      	mul	w11, w9, w11
     8e0:      	add	w11, w11, w10
     8e4:      	str	w11, [sp, #0xdc]
     8e8:      	ldr	w11, [sp, #0xe8]
     8ec:      	ldr	w12, [sp, #0xdc]
     8f0:      	add	w11, w11, w12
     8f4:      	subs	w11, w11, w10
     8f8:      	str	w11, [sp, #0xd8]
     8fc:      	ldr	w11, [sp, #0xd8]
     900:      	subs	w11, w11, w10
     904:      	mul	w11, w8, w11
     908:      	str	w11, [sp, #0xd4]
     90c:      	ldr	w11, [sp, #0xd4]
     910:      	lsr	w11, w11, #6
     914:      	str	w11, [sp, #0xd0]
     918:      	ldr	w11, [sp, #0xd4]
     91c:      	ldr	w12, [sp, #0xd0]
     920:      	eor	w11, w11, w12
     924:      	str	w11, [sp, #0xcc]
     928:      	ldr	w11, [sp, #0xf8]
     92c:      	lsr	w11, w11, #8
     930:      	str	w11, [sp, #0xc8]
     934:      	ldrb	w11, [sp, #0xc8]
     938:      	str	w11, [sp, #0xc4]
     93c:      	ldr	w11, [sp, #0xcc]
     940:      	mul	w11, w9, w11
     944:      	add	w11, w11, w10
     948:      	str	w11, [sp, #0xc0]
     94c:      	ldr	w11, [sp, #0xc4]
     950:      	mul	w11, w9, w11
     954:      	add	w11, w11, w10
     958:      	str	w11, [sp, #0xbc]
     95c:      	ldr	w11, [sp, #0xc0]
     960:      	ldr	w12, [sp, #0xbc]
     964:      	add	w11, w11, w12
     968:      	subs	w11, w11, w10
     96c:      	str	w11, [sp, #0xb8]
     970:      	ldr	w11, [sp, #0xb8]
     974:      	subs	w11, w11, w10
     978:      	mul	w11, w8, w11
     97c:      	str	w11, [sp, #0xb4]
     980:      	ldr	w11, [sp, #0xb4]
     984:      	lsl	w11, w11, #10
     988:      	str	w11, [sp, #0xb0]
     98c:      	ldr	w11, [sp, #0xb0]
     990:      	mul	w11, w9, w11
     994:      	add	w11, w11, w10
     998:      	str	w11, [sp, #0xac]
     99c:      	ldr	w11, [sp, #0xb8]
     9a0:      	ldr	w12, [sp, #0xac]
     9a4:      	add	w11, w11, w12
     9a8:      	subs	w11, w11, w10
     9ac:      	str	w11, [sp, #0xa8]
     9b0:      	ldr	w11, [sp, #0xa8]
     9b4:      	subs	w11, w11, w10
     9b8:      	mul	w11, w8, w11
     9bc:      	str	w11, [sp, #0xa4]
     9c0:      	ldr	w11, [sp, #0xa4]
     9c4:      	lsr	w11, w11, #6
     9c8:      	str	w11, [sp, #0xa0]
     9cc:      	ldr	w11, [sp, #0xa4]
     9d0:      	ldr	w12, [sp, #0xa0]
     9d4:      	eor	w11, w11, w12
     9d8:      	str	w11, [sp, #0x9c]
     9dc:      	ldr	w11, [sp, #0xc8]
     9e0:      	lsr	w11, w11, #8
     9e4:      	str	w11, [sp, #0x98]
     9e8:      	ldrb	w11, [sp, #0x98]
     9ec:      	str	w11, [sp, #0x94]
     9f0:      	ldr	w11, [sp, #0x9c]
     9f4:      	mul	w11, w9, w11
     9f8:      	add	w11, w11, w10
     9fc:      	str	w11, [sp, #0x90]
     a00:      	ldr	w11, [sp, #0x94]
     a04:      	mul	w11, w9, w11
     a08:      	add	w11, w11, w10
     a0c:      	str	w11, [sp, #0x8c]
     a10:      	ldr	w11, [sp, #0x90]
     a14:      	ldr	w12, [sp, #0x8c]
     a18:      	add	w11, w11, w12
     a1c:      	subs	w11, w11, w10
     a20:      	str	w11, [sp, #0x88]
     a24:      	ldr	w11, [sp, #0x88]
     a28:      	subs	w11, w11, w10
     a2c:      	mul	w11, w8, w11
     a30:      	str	w11, [sp, #0x84]
     a34:      	ldr	w11, [sp, #0x84]
     a38:      	lsl	w11, w11, #10
     a3c:      	str	w11, [sp, #0x80]
     a40:      	ldr	w11, [sp, #0x80]
     a44:      	mul	w11, w9, w11
     a48:      	add	w11, w11, w10
     a4c:      	str	w11, [sp, #0x7c]
     a50:      	ldr	w11, [sp, #0x88]
     a54:      	ldr	w12, [sp, #0x7c]
     a58:      	add	w11, w11, w12
     a5c:      	subs	w11, w11, w10
     a60:      	str	w11, [sp, #0x78]
     a64:      	ldr	w11, [sp, #0x78]
     a68:      	subs	w11, w11, w10
     a6c:      	mul	w11, w8, w11
     a70:      	str	w11, [sp, #0x74]
     a74:      	ldr	w11, [sp, #0x74]
     a78:      	lsr	w11, w11, #6
     a7c:      	str	w11, [sp, #0x70]
     a80:      	ldr	w11, [sp, #0x74]
     a84:      	ldr	w12, [sp, #0x70]
     a88:      	eor	w11, w11, w12
     a8c:      	str	w11, [sp, #0x6c]
     a90:      	ldr	w11, [sp, #0x98]
     a94:      	lsr	w11, w11, #8
     a98:      	str	w11, [sp, #0x68]
     a9c:      	ldrb	w11, [sp, #0x68]
     aa0:      	str	w11, [sp, #0x64]
     aa4:      	ldr	w11, [sp, #0x6c]
     aa8:      	mul	w11, w9, w11
     aac:      	add	w11, w11, w10
     ab0:      	str	w11, [sp, #0x60]
     ab4:      	ldr	w11, [sp, #0x64]
     ab8:      	mul	w11, w9, w11
     abc:      	add	w11, w11, w10
     ac0:      	str	w11, [sp, #0x5c]
     ac4:      	ldr	w11, [sp, #0x60]
     ac8:      	ldr	w12, [sp, #0x5c]
     acc:      	add	w11, w11, w12
     ad0:      	subs	w11, w11, w10
     ad4:      	str	w11, [sp, #0x58]
     ad8:      	ldr	w11, [sp, #0x58]
     adc:      	subs	w11, w11, w10
     ae0:      	mul	w11, w8, w11
     ae4:      	str	w11, [sp, #0x54]
     ae8:      	ldr	w11, [sp, #0x54]
     aec:      	lsl	w11, w11, #10
     af0:      	str	w11, [sp, #0x50]
     af4:      	ldr	w11, [sp, #0x50]
     af8:      	mul	w11, w9, w11
     afc:      	add	w11, w11, w10
     b00:      	str	w11, [sp, #0x4c]
     b04:      	ldr	w11, [sp, #0x58]
     b08:      	ldr	w12, [sp, #0x4c]
     b0c:      	add	w11, w11, w12
     b10:      	subs	w11, w11, w10
     b14:      	str	w11, [sp, #0x48]
     b18:      	ldr	w11, [sp, #0x48]
     b1c:      	subs	w11, w11, w10
     b20:      	mul	w11, w8, w11
     b24:      	str	w11, [sp, #0x44]
     b28:      	ldr	w11, [sp, #0x44]
     b2c:      	lsr	w11, w11, #6
     b30:      	str	w11, [sp, #0x40]
     b34:      	ldr	w11, [sp, #0x44]
     b38:      	ldr	w12, [sp, #0x40]
     b3c:      	eor	w11, w11, w12
     b40:      	str	w11, [sp, #0x3c]
     b44:      	ldr	w11, [sp, #0x3c]
     b48:      	lsl	w11, w11, #3
     b4c:      	str	w11, [sp, #0x38]
     b50:      	ldr	w11, [sp, #0x3c]
     b54:      	mul	w11, w9, w11
     b58:      	add	w11, w11, w10
     b5c:      	str	w11, [sp, #0x34]
     b60:      	ldr	w11, [sp, #0x38]
     b64:      	mul	w11, w9, w11
     b68:      	add	w11, w11, w10
     b6c:      	str	w11, [sp, #0x30]
     b70:      	ldr	w11, [sp, #0x34]
     b74:      	ldr	w12, [sp, #0x30]
     b78:      	add	w11, w11, w12
     b7c:      	subs	w11, w11, w10
     b80:      	str	w11, [sp, #0x2c]
     b84:      	ldr	w11, [sp, #0x2c]
     b88:      	subs	w11, w11, w10
     b8c:      	mul	w11, w8, w11
     b90:      	str	w11, [sp, #0x28]
     b94:      	ldr	w11, [sp, #0x28]
     b98:      	lsr	w11, w11, #11
     b9c:      	str	w11, [sp, #0x24]
     ba0:      	ldr	w11, [sp, #0x28]
     ba4:      	ldr	w12, [sp, #0x24]
     ba8:      	eor	w11, w11, w12
     bac:      	str	w11, [sp, #0x20]
     bb0:      	ldr	w11, [sp, #0x20]
     bb4:      	lsl	w11, w11, #15
     bb8:      	str	w11, [sp, #0x1c]
     bbc:      	ldr	w11, [sp, #0x20]
     bc0:      	mul	w11, w9, w11
     bc4:      	add	w11, w11, w10
     bc8:      	str	w11, [sp, #0x18]
     bcc:      	ldr	w11, [sp, #0x1c]
     bd0:      	mul	w9, w9, w11
     bd4:      	add	w9, w9, w10
     bd8:      	str	w9, [sp, #0x14]
     bdc:      	ldr	w9, [sp, #0x18]
     be0:      	ldr	w11, [sp, #0x14]
     be4:      	add	w9, w9, w11
     be8:      	subs	w9, w9, w10
     bec:      	str	w9, [sp, #0x10]
     bf0:      	ldr	w9, [sp, #0x10]
     bf4:      	subs	w9, w9, w10
     bf8:      	mul	w8, w8, w9
     bfc:      	str	w8, [sp, #0xc]
     c00:      	ldr	w0, [sp, #0xc]
     c04:      	ldr	x29, [sp, #0x100]
     c08:      	add	sp, sp, #0x110
     c0c:      	ret

0000000000000c10 <main>:
     c10:      	sub	sp, sp, #0x90
     c14:      	stp	x29, x30, [sp, #0x80]
     c18:      	add	x29, sp, #0x80
     c1c:      	stur	wzr, [x29, #-0x4]
     c20:      	stur	w0, [x29, #-0x8]
     c24:      	stur	x1, [x29, #-0x10]
     c28:      	ldur	w8, [x29, #-0x8]
     c2c:      	subs	w8, w8, #0x1
     c30:      	b.ne	0xc84 <main+0x74>
     c34:      	b	0xc38 <main+0x28>
     c38:      	b	0xc3c <main+0x2c>
     c3c:      	sub	x1, x29, #0x18
     c40:      	add	x2, x1, #0x4
     c44:      	adrp	x0, 0x0 <strtoul@GLIBC_2.17>
     c48:      	add	x0, x0, #0xe90
     c4c:      	bl	0x710 <__isoc99_scanf@plt>
     c50:      	subs	w8, w0, #0x2
     c54:      	b.ne	0xc7c <main+0x6c>
     c58:      	b	0xc5c <main+0x4c>
     c5c:      	ldur	w0, [x29, #-0x18]
     c60:      	ldur	w1, [x29, #-0x14]
     c64:      	bl	0x858 <kernel>
     c68:      	mov	w1, w0
     c6c:      	adrp	x0, 0x0 <strtoul@GLIBC_2.17>
     c70:      	add	x0, x0, #0xe95
     c74:      	bl	0x720 <printf@plt>
     c78:      	b	0xc3c <main+0x2c>
     c7c:      	stur	wzr, [x29, #-0x4]
     c80:      	b	0xdf8 <main+0x1e8>
     c84:      	ldur	w8, [x29, #-0x8]
     c88:      	subs	w8, w8, #0x3
     c8c:      	b.eq	0xca0 <main+0x90>
     c90:      	b	0xc94 <main+0x84>
     c94:      	mov	w8, #0x3                // =3
     c98:      	stur	w8, [x29, #-0x4]
     c9c:      	b	0xdf8 <main+0x1e8>
     ca0:      	ldur	x8, [x29, #-0x10]
     ca4:      	ldr	x0, [x8, #0x8]
     ca8:      	mov	x1, xzr
     cac:      	str	x1, [sp, #0x8]
     cb0:      	mov	w2, #0xa                // =10
     cb4:      	str	w2, [sp, #0x14]
     cb8:      	bl	0x6b0 <strtoul@plt>
     cbc:      	ldr	x1, [sp, #0x8]
     cc0:      	ldr	w2, [sp, #0x14]
     cc4:      	stur	x0, [x29, #-0x20]
     cc8:      	ldur	x8, [x29, #-0x10]
     ccc:      	ldr	x0, [x8, #0x10]
     cd0:      	bl	0x6b0 <strtoul@plt>
     cd4:      	mov	w8, w0
     cd8:      	stur	w8, [x29, #-0x24]
     cdc:      	stur	xzr, [x29, #-0x30]
     ce0:      	mov	w0, #0x1                // =1
     ce4:      	add	x1, sp, #0x40
     ce8:      	bl	0x6e0 <clock_gettime@plt>
     cec:      	cbz	w0, 0xd00 <main+0xf0>
     cf0:      	b	0xcf4 <main+0xe4>
     cf4:      	mov	w8, #0x2                // =2
     cf8:      	stur	w8, [x29, #-0x4]
     cfc:      	b	0xdf8 <main+0x1e8>
     d00:      	str	xzr, [sp, #0x28]
     d04:      	b	0xd08 <main+0xf8>
     d08:      	ldr	x8, [sp, #0x28]
     d0c:      	ldur	x9, [x29, #-0x20]
     d10:      	subs	x8, x8, x9
     d14:      	b.hs	0xd8c <main+0x17c>
     d18:      	b	0xd1c <main+0x10c>
     d1c:      	str	wzr, [sp, #0x24]
     d20:      	b	0xd24 <main+0x114>
     d24:      	ldr	w8, [sp, #0x24]
     d28:      	subs	w8, w8, #0x2
     d2c:      	b.hs	0xd60 <main+0x150>
     d30:      	b	0xd34 <main+0x124>
     d34:      	sub	x0, x29, #0x24
     d38:      	bl	0xe08 <csrd_matrix_next_value>
     d3c:      	ldr	w8, [sp, #0x24]
     d40:      	mov	w9, w8
     d44:      	sub	x8, x29, #0x18
     d48:      	str	w0, [x8, x9, lsl #2]
     d4c:      	b	0xd50 <main+0x140>
     d50:      	ldr	w8, [sp, #0x24]
     d54:      	add	w8, w8, #0x1
     d58:      	str	w8, [sp, #0x24]
     d5c:      	b	0xd24 <main+0x114>
     d60:      	ldur	w0, [x29, #-0x18]
     d64:      	ldur	w1, [x29, #-0x14]
     d68:      	bl	0x858 <kernel>
     d6c:      	ldur	x8, [x29, #-0x30]
     d70:      	add	x8, x8, w0, uxtw
     d74:      	stur	x8, [x29, #-0x30]
     d78:      	b	0xd7c <main+0x16c>
     d7c:      	ldr	x8, [sp, #0x28]
     d80:      	add	x8, x8, #0x1
     d84:      	str	x8, [sp, #0x28]
     d88:      	b	0xd08 <main+0xf8>
     d8c:      	mov	w0, #0x1                // =1
     d90:      	add	x1, sp, #0x30
     d94:      	bl	0x6e0 <clock_gettime@plt>
     d98:      	cbz	w0, 0xdac <main+0x19c>
     d9c:      	b	0xda0 <main+0x190>
     da0:      	mov	w8, #0x2                // =2
     da4:      	stur	w8, [x29, #-0x4]
     da8:      	b	0xdf8 <main+0x1e8>
     dac:      	ldr	x8, [sp, #0x30]
     db0:      	ldr	x9, [sp, #0x40]
     db4:      	subs	x8, x8, x9
     db8:      	scvtf	d2, x8
     dbc:      	ldr	x8, [sp, #0x38]
     dc0:      	ldr	x9, [sp, #0x48]
     dc4:      	subs	x8, x8, x9
     dc8:      	scvtf	d0, x8
     dcc:      	adrp	x8, 0x0 <strtoul@GLIBC_2.17>
     dd0:      	ldr	d1, [x8, #0xe88]
     dd4:      	fmadd	d0, d0, d1, d2
     dd8:      	str	d0, [sp, #0x18]
     ddc:      	ldr	d0, [sp, #0x18]
     de0:      	ldur	x1, [x29, #-0x30]
     de4:      	adrp	x0, 0x0 <strtoul@GLIBC_2.17>
     de8:      	add	x0, x0, #0xe99
     dec:      	bl	0x720 <printf@plt>
     df0:      	stur	wzr, [x29, #-0x4]
     df4:      	b	0xdf8 <main+0x1e8>
     df8:      	ldur	w0, [x29, #-0x4]
     dfc:      	ldp	x29, x30, [sp, #0x80]
     e00:      	add	sp, sp, #0x90
     e04:      	ret

0000000000000e08 <csrd_matrix_next_value>:
     e08:      	sub	sp, sp, #0x10
     e0c:      	str	x0, [sp, #0x8]
     e10:      	ldr	x8, [sp, #0x8]
     e14:      	ldr	w10, [x8]
     e18:      	ldr	x9, [sp, #0x8]
     e1c:      	ldr	w8, [x9]
     e20:      	eor	w8, w8, w10, lsl #13
     e24:      	str	w8, [x9]
     e28:      	ldr	x8, [sp, #0x8]
     e2c:      	ldr	w10, [x8]
     e30:      	ldr	x9, [sp, #0x8]
     e34:      	ldr	w8, [x9]
     e38:      	eor	w8, w8, w10, lsr #17
     e3c:      	str	w8, [x9]
     e40:      	ldr	x8, [sp, #0x8]
     e44:      	ldr	w10, [x8]
     e48:      	ldr	x9, [sp, #0x8]
     e4c:      	ldr	w8, [x9]
     e50:      	eor	w8, w8, w10, lsl #5
     e54:      	str	w8, [x9]
     e58:      	ldr	x8, [sp, #0x8]
     e5c:      	ldr	w0, [x8]
     e60:      	add	sp, sp, #0x10
     e64:      	ret

Disassembly of section .fini:

0000000000000e68 <_fini>:
     e68:      	nop
     e6c:      	stp	x29, x30, [sp, #-0x10]!
     e70:      	mov	x29, sp
     e74:      	ldp	x29, x30, [sp], #0x10
     e78:      	ret
