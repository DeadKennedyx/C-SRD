; ModuleID = '/work/experiments/runs/jenkins-composition-matrix-linux-20261110/jenkins_word/build-clang-O0-affine-42/validation/compiler-0-O0/candidate.i'
source_filename = "/work/experiments/runs/jenkins-composition-matrix-linux-20261110/jenkins_word/build-clang-O0-affine-42/validation/compiler-0-O0/candidate.i"
target datalayout = "e-m:e-i8:8:32-i16:16:32-i64:64-i128:128-n32:64-S128"
target triple = "aarch64-unknown-linux-gnu"

; Function Attrs: noinline nounwind optnone uwtable
define dso_local i32 @kernel(i32 noundef %0, i32 noundef %1) #0 {
  %3 = alloca i32, align 4
  %4 = alloca i32, align 4
  %5 = alloca i32, align 4
  %6 = alloca i32, align 4
  %7 = alloca i32, align 4
  %8 = alloca i32, align 4
  %9 = alloca i32, align 4
  %10 = alloca i32, align 4
  %11 = alloca i32, align 4
  %12 = alloca i32, align 4
  %13 = alloca i32, align 4
  %14 = alloca i32, align 4
  %15 = alloca i32, align 4
  %16 = alloca i32, align 4
  %17 = alloca i32, align 4
  %18 = alloca i32, align 4
  %19 = alloca i32, align 4
  %20 = alloca i32, align 4
  %21 = alloca i32, align 4
  %22 = alloca i32, align 4
  %23 = alloca i32, align 4
  %24 = alloca i32, align 4
  %25 = alloca i32, align 4
  %26 = alloca i32, align 4
  %27 = alloca i32, align 4
  %28 = alloca i32, align 4
  %29 = alloca i32, align 4
  %30 = alloca i32, align 4
  %31 = alloca i32, align 4
  %32 = alloca i32, align 4
  %33 = alloca i32, align 4
  %34 = alloca i32, align 4
  %35 = alloca i32, align 4
  %36 = alloca i32, align 4
  %37 = alloca i32, align 4
  %38 = alloca i32, align 4
  %39 = alloca i32, align 4
  %40 = alloca i32, align 4
  %41 = alloca i32, align 4
  %42 = alloca i32, align 4
  %43 = alloca i32, align 4
  %44 = alloca i32, align 4
  %45 = alloca i32, align 4
  %46 = alloca i32, align 4
  %47 = alloca i32, align 4
  %48 = alloca i32, align 4
  %49 = alloca i32, align 4
  %50 = alloca i32, align 4
  %51 = alloca i32, align 4
  %52 = alloca i32, align 4
  %53 = alloca i32, align 4
  %54 = alloca i32, align 4
  %55 = alloca i32, align 4
  %56 = alloca i32, align 4
  %57 = alloca i32, align 4
  %58 = alloca i32, align 4
  %59 = alloca i32, align 4
  %60 = alloca i32, align 4
  %61 = alloca i32, align 4
  %62 = alloca i32, align 4
  %63 = alloca i32, align 4
  store i32 %0, ptr %3, align 4
  store i32 %1, ptr %4, align 4
  %64 = load i32, ptr %4, align 4
  %65 = and i32 %64, 255
  store i32 %65, ptr %5, align 4
  %66 = load i32, ptr %3, align 4
  %67 = mul i32 2010586713, %66
  %68 = add i32 %67, 278101063
  store i32 %68, ptr %6, align 4
  %69 = load i32, ptr %5, align 4
  %70 = mul i32 2010586713, %69
  %71 = add i32 %70, 278101063
  store i32 %71, ptr %7, align 4
  %72 = load i32, ptr %6, align 4
  %73 = load i32, ptr %7, align 4
  %74 = add i32 %72, %73
  %75 = sub i32 %74, 278101063
  store i32 %75, ptr %8, align 4
  %76 = load i32, ptr %8, align 4
  %77 = sub i32 %76, 278101063
  %78 = mul i32 -1673639447, %77
  store i32 %78, ptr %9, align 4
  %79 = load i32, ptr %9, align 4
  %80 = shl i32 %79, 10
  store i32 %80, ptr %10, align 4
  %81 = load i32, ptr %10, align 4
  %82 = mul i32 2010586713, %81
  %83 = add i32 %82, 278101063
  store i32 %83, ptr %11, align 4
  %84 = load i32, ptr %8, align 4
  %85 = load i32, ptr %11, align 4
  %86 = add i32 %84, %85
  %87 = sub i32 %86, 278101063
  store i32 %87, ptr %12, align 4
  %88 = load i32, ptr %12, align 4
  %89 = sub i32 %88, 278101063
  %90 = mul i32 -1673639447, %89
  store i32 %90, ptr %13, align 4
  %91 = load i32, ptr %13, align 4
  %92 = lshr i32 %91, 6
  store i32 %92, ptr %14, align 4
  %93 = load i32, ptr %13, align 4
  %94 = load i32, ptr %14, align 4
  %95 = xor i32 %93, %94
  store i32 %95, ptr %15, align 4
  %96 = load i32, ptr %4, align 4
  %97 = lshr i32 %96, 8
  store i32 %97, ptr %16, align 4
  %98 = load i32, ptr %16, align 4
  %99 = and i32 %98, 255
  store i32 %99, ptr %17, align 4
  %100 = load i32, ptr %15, align 4
  %101 = mul i32 2010586713, %100
  %102 = add i32 %101, 278101063
  store i32 %102, ptr %18, align 4
  %103 = load i32, ptr %17, align 4
  %104 = mul i32 2010586713, %103
  %105 = add i32 %104, 278101063
  store i32 %105, ptr %19, align 4
  %106 = load i32, ptr %18, align 4
  %107 = load i32, ptr %19, align 4
  %108 = add i32 %106, %107
  %109 = sub i32 %108, 278101063
  store i32 %109, ptr %20, align 4
  %110 = load i32, ptr %20, align 4
  %111 = sub i32 %110, 278101063
  %112 = mul i32 -1673639447, %111
  store i32 %112, ptr %21, align 4
  %113 = load i32, ptr %21, align 4
  %114 = shl i32 %113, 10
  store i32 %114, ptr %22, align 4
  %115 = load i32, ptr %22, align 4
  %116 = mul i32 2010586713, %115
  %117 = add i32 %116, 278101063
  store i32 %117, ptr %23, align 4
  %118 = load i32, ptr %20, align 4
  %119 = load i32, ptr %23, align 4
  %120 = add i32 %118, %119
  %121 = sub i32 %120, 278101063
  store i32 %121, ptr %24, align 4
  %122 = load i32, ptr %24, align 4
  %123 = sub i32 %122, 278101063
  %124 = mul i32 -1673639447, %123
  store i32 %124, ptr %25, align 4
  %125 = load i32, ptr %25, align 4
  %126 = lshr i32 %125, 6
  store i32 %126, ptr %26, align 4
  %127 = load i32, ptr %25, align 4
  %128 = load i32, ptr %26, align 4
  %129 = xor i32 %127, %128
  store i32 %129, ptr %27, align 4
  %130 = load i32, ptr %16, align 4
  %131 = lshr i32 %130, 8
  store i32 %131, ptr %28, align 4
  %132 = load i32, ptr %28, align 4
  %133 = and i32 %132, 255
  store i32 %133, ptr %29, align 4
  %134 = load i32, ptr %27, align 4
  %135 = mul i32 2010586713, %134
  %136 = add i32 %135, 278101063
  store i32 %136, ptr %30, align 4
  %137 = load i32, ptr %29, align 4
  %138 = mul i32 2010586713, %137
  %139 = add i32 %138, 278101063
  store i32 %139, ptr %31, align 4
  %140 = load i32, ptr %30, align 4
  %141 = load i32, ptr %31, align 4
  %142 = add i32 %140, %141
  %143 = sub i32 %142, 278101063
  store i32 %143, ptr %32, align 4
  %144 = load i32, ptr %32, align 4
  %145 = sub i32 %144, 278101063
  %146 = mul i32 -1673639447, %145
  store i32 %146, ptr %33, align 4
  %147 = load i32, ptr %33, align 4
  %148 = shl i32 %147, 10
  store i32 %148, ptr %34, align 4
  %149 = load i32, ptr %34, align 4
  %150 = mul i32 2010586713, %149
  %151 = add i32 %150, 278101063
  store i32 %151, ptr %35, align 4
  %152 = load i32, ptr %32, align 4
  %153 = load i32, ptr %35, align 4
  %154 = add i32 %152, %153
  %155 = sub i32 %154, 278101063
  store i32 %155, ptr %36, align 4
  %156 = load i32, ptr %36, align 4
  %157 = sub i32 %156, 278101063
  %158 = mul i32 -1673639447, %157
  store i32 %158, ptr %37, align 4
  %159 = load i32, ptr %37, align 4
  %160 = lshr i32 %159, 6
  store i32 %160, ptr %38, align 4
  %161 = load i32, ptr %37, align 4
  %162 = load i32, ptr %38, align 4
  %163 = xor i32 %161, %162
  store i32 %163, ptr %39, align 4
  %164 = load i32, ptr %28, align 4
  %165 = lshr i32 %164, 8
  store i32 %165, ptr %40, align 4
  %166 = load i32, ptr %40, align 4
  %167 = and i32 %166, 255
  store i32 %167, ptr %41, align 4
  %168 = load i32, ptr %39, align 4
  %169 = mul i32 2010586713, %168
  %170 = add i32 %169, 278101063
  store i32 %170, ptr %42, align 4
  %171 = load i32, ptr %41, align 4
  %172 = mul i32 2010586713, %171
  %173 = add i32 %172, 278101063
  store i32 %173, ptr %43, align 4
  %174 = load i32, ptr %42, align 4
  %175 = load i32, ptr %43, align 4
  %176 = add i32 %174, %175
  %177 = sub i32 %176, 278101063
  store i32 %177, ptr %44, align 4
  %178 = load i32, ptr %44, align 4
  %179 = sub i32 %178, 278101063
  %180 = mul i32 -1673639447, %179
  store i32 %180, ptr %45, align 4
  %181 = load i32, ptr %45, align 4
  %182 = shl i32 %181, 10
  store i32 %182, ptr %46, align 4
  %183 = load i32, ptr %46, align 4
  %184 = mul i32 2010586713, %183
  %185 = add i32 %184, 278101063
  store i32 %185, ptr %47, align 4
  %186 = load i32, ptr %44, align 4
  %187 = load i32, ptr %47, align 4
  %188 = add i32 %186, %187
  %189 = sub i32 %188, 278101063
  store i32 %189, ptr %48, align 4
  %190 = load i32, ptr %48, align 4
  %191 = sub i32 %190, 278101063
  %192 = mul i32 -1673639447, %191
  store i32 %192, ptr %49, align 4
  %193 = load i32, ptr %49, align 4
  %194 = lshr i32 %193, 6
  store i32 %194, ptr %50, align 4
  %195 = load i32, ptr %49, align 4
  %196 = load i32, ptr %50, align 4
  %197 = xor i32 %195, %196
  store i32 %197, ptr %51, align 4
  %198 = load i32, ptr %51, align 4
  %199 = shl i32 %198, 3
  store i32 %199, ptr %52, align 4
  %200 = load i32, ptr %51, align 4
  %201 = mul i32 2010586713, %200
  %202 = add i32 %201, 278101063
  store i32 %202, ptr %53, align 4
  %203 = load i32, ptr %52, align 4
  %204 = mul i32 2010586713, %203
  %205 = add i32 %204, 278101063
  store i32 %205, ptr %54, align 4
  %206 = load i32, ptr %53, align 4
  %207 = load i32, ptr %54, align 4
  %208 = add i32 %206, %207
  %209 = sub i32 %208, 278101063
  store i32 %209, ptr %55, align 4
  %210 = load i32, ptr %55, align 4
  %211 = sub i32 %210, 278101063
  %212 = mul i32 -1673639447, %211
  store i32 %212, ptr %56, align 4
  %213 = load i32, ptr %56, align 4
  %214 = lshr i32 %213, 11
  store i32 %214, ptr %57, align 4
  %215 = load i32, ptr %56, align 4
  %216 = load i32, ptr %57, align 4
  %217 = xor i32 %215, %216
  store i32 %217, ptr %58, align 4
  %218 = load i32, ptr %58, align 4
  %219 = shl i32 %218, 15
  store i32 %219, ptr %59, align 4
  %220 = load i32, ptr %58, align 4
  %221 = mul i32 2010586713, %220
  %222 = add i32 %221, 278101063
  store i32 %222, ptr %60, align 4
  %223 = load i32, ptr %59, align 4
  %224 = mul i32 2010586713, %223
  %225 = add i32 %224, 278101063
  store i32 %225, ptr %61, align 4
  %226 = load i32, ptr %60, align 4
  %227 = load i32, ptr %61, align 4
  %228 = add i32 %226, %227
  %229 = sub i32 %228, 278101063
  store i32 %229, ptr %62, align 4
  %230 = load i32, ptr %62, align 4
  %231 = sub i32 %230, 278101063
  %232 = mul i32 -1673639447, %231
  store i32 %232, ptr %63, align 4
  %233 = load i32, ptr %63, align 4
  ret i32 %233
}

attributes #0 = { noinline nounwind optnone uwtable "frame-pointer"="non-leaf" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+fp-armv8,+neon,+outline-atomics,+v8a,-fmv" }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 1, !"wchar_size", i32 4}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 1}
!5 = !{!"Ubuntu clang version 18.1.3 (1ubuntu1)"}
