
/work/experiments/runs/jenkins-composition-matrix-linux-20261110/jenkins_word/build-gcc-O0-limbs16/program:	file format elf64-littleaarch64

Disassembly of section .init:

0000000000000730 <_init>:
     730:      	nop
     734:      	stp	x29, x30, [sp, #-0x10]!
     738:      	mov	x29, sp
     73c:      	bl	0x834 <call_weak_fn>
     740:      	ldp	x29, x30, [sp], #0x10
     744:      	ret

Disassembly of section .plt:

0000000000000750 <.plt>:
     750:      	stp	x16, x30, [sp, #-0x10]!
     754:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1dd00>
     758:      	ldr	x17, [x16, #0xf78]
     75c:      	add	x16, x16, #0xf78
     760:      	br	x17
     764:      	nop
     768:      	nop
     76c:      	nop

0000000000000770 <strtoul@plt>:
     770:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1dd00>
     774:      	ldr	x17, [x16, #0xf80]
     778:      	add	x16, x16, #0xf80
     77c:      	br	x17

0000000000000780 <__libc_start_main@plt>:
     780:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1dd00>
     784:      	ldr	x17, [x16, #0xf88]
     788:      	add	x16, x16, #0xf88
     78c:      	br	x17

0000000000000790 <__cxa_finalize@plt>:
     790:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1dd00>
     794:      	ldr	x17, [x16, #0xf90]
     798:      	add	x16, x16, #0xf90
     79c:      	br	x17

00000000000007a0 <clock_gettime@plt>:
     7a0:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1dd00>
     7a4:      	ldr	x17, [x16, #0xf98]
     7a8:      	add	x16, x16, #0xf98
     7ac:      	br	x17

00000000000007b0 <__stack_chk_fail@plt>:
     7b0:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1dd00>
     7b4:      	ldr	x17, [x16, #0xfa0]
     7b8:      	add	x16, x16, #0xfa0
     7bc:      	br	x17

00000000000007c0 <__gmon_start__@plt>:
     7c0:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1dd00>
     7c4:      	ldr	x17, [x16, #0xfa8]
     7c8:      	add	x16, x16, #0xfa8
     7cc:      	br	x17

00000000000007d0 <abort@plt>:
     7d0:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1dd00>
     7d4:      	ldr	x17, [x16, #0xfb0]
     7d8:      	add	x16, x16, #0xfb0
     7dc:      	br	x17

00000000000007e0 <__isoc99_scanf@plt>:
     7e0:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1dd00>
     7e4:      	ldr	x17, [x16, #0xfb8]
     7e8:      	add	x16, x16, #0xfb8
     7ec:      	br	x17

00000000000007f0 <printf@plt>:
     7f0:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1dd00>
     7f4:      	ldr	x17, [x16, #0xfc0]
     7f8:      	add	x16, x16, #0xfc0
     7fc:      	br	x17

Disassembly of section .text:

0000000000000800 <_start>:
     800:      	nop
     804:      	mov	x29, #0x0               // =0
     808:      	mov	x30, #0x0               // =0
     80c:      	mov	x5, x0
     810:      	ldr	x1, [sp]
     814:      	add	x2, sp, #0x8
     818:      	mov	x6, sp
     81c:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1dd00>
     820:      	ldr	x0, [x0, #0xff0]
     824:      	mov	x3, #0x0                // =0
     828:      	mov	x4, #0x0                // =0
     82c:      	bl	0x780 <__libc_start_main@plt>
     830:      	bl	0x7d0 <abort@plt>

0000000000000834 <call_weak_fn>:
     834:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1dd00>
     838:      	ldr	x0, [x0, #0xfe0]
     83c:      	cbz	x0, 0x844 <call_weak_fn+0x10>
     840:      	b	0x7c0 <__gmon_start__@plt>
     844:      	ret
     848:      	nop
     84c:      	nop

0000000000000850 <deregister_tm_clones>:
     850:      	adrp	x0, 0x20000 <data_start>
     854:      	add	x0, x0, #0x10
     858:      	adrp	x1, 0x20000 <data_start>
     85c:      	add	x1, x1, #0x10
     860:      	cmp	x1, x0
     864:      	b.eq	0x87c <deregister_tm_clones+0x2c>
     868:      	adrp	x1, 0x1f000 <__FRAME_END__+0x1dd00>
     86c:      	ldr	x1, [x1, #0xfd0]
     870:      	cbz	x1, 0x87c <deregister_tm_clones+0x2c>
     874:      	mov	x16, x1
     878:      	br	x16
     87c:      	ret

0000000000000880 <register_tm_clones>:
     880:      	adrp	x0, 0x20000 <data_start>
     884:      	add	x0, x0, #0x10
     888:      	adrp	x1, 0x20000 <data_start>
     88c:      	add	x1, x1, #0x10
     890:      	sub	x1, x1, x0
     894:      	lsr	x2, x1, #63
     898:      	add	x1, x2, x1, asr #3
     89c:      	asr	x1, x1, #1
     8a0:      	cbz	x1, 0x8b8 <register_tm_clones+0x38>
     8a4:      	adrp	x2, 0x1f000 <__FRAME_END__+0x1dd00>
     8a8:      	ldr	x2, [x2, #0xff8]
     8ac:      	cbz	x2, 0x8b8 <register_tm_clones+0x38>
     8b0:      	mov	x16, x2
     8b4:      	br	x16
     8b8:      	ret
     8bc:      	nop

00000000000008c0 <__do_global_dtors_aux>:
     8c0:      	paciasp
     8c4:      	stp	x29, x30, [sp, #-0x20]!
     8c8:      	mov	x29, sp
     8cc:      	str	x19, [sp, #0x10]
     8d0:      	adrp	x19, 0x20000 <data_start>
     8d4:      	ldrb	w0, [x19, #0x10]
     8d8:      	tbnz	w0, #0x0, 0x900 <__do_global_dtors_aux+0x40>
     8dc:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1dd00>
     8e0:      	ldr	x0, [x0, #0xfd8]
     8e4:      	cbz	x0, 0x8f4 <__do_global_dtors_aux+0x34>
     8e8:      	adrp	x0, 0x20000 <data_start>
     8ec:      	ldr	x0, [x0, #0x8]
     8f0:      	bl	0x790 <__cxa_finalize@plt>
     8f4:      	bl	0x850 <deregister_tm_clones>
     8f8:      	mov	w0, #0x1                // =1
     8fc:      	strb	w0, [x19, #0x10]
     900:      	ldr	x19, [sp, #0x10]
     904:      	ldp	x29, x30, [sp], #0x20
     908:      	autiasp
     90c:      	ret

0000000000000910 <frame_dummy>:
     910:      	bti	c
     914:      	b	0x880 <register_tm_clones>

0000000000000918 <kernel>:
     918:      	sub	sp, sp, #0x160
     91c:      	str	w0, [sp, #0xc]
     920:      	str	w1, [sp, #0x8]
     924:      	ldr	w0, [sp, #0xc]
     928:      	and	w0, w0, #0xffff
     92c:      	str	w0, [sp, #0x1c]
     930:      	ldr	w0, [sp, #0xc]
     934:      	lsr	w0, w0, #16
     938:      	str	w0, [sp, #0x20]
     93c:      	ldr	w0, [sp, #0x8]
     940:      	and	w0, w0, #0xffff
     944:      	str	w0, [sp, #0x24]
     948:      	ldr	w0, [sp, #0x8]
     94c:      	lsr	w0, w0, #16
     950:      	str	w0, [sp, #0x28]
     954:      	ldr	w0, [sp, #0x24]
     958:      	and	w0, w0, #0xff
     95c:      	str	w0, [sp, #0x2c]
     960:      	str	wzr, [sp, #0x30]
     964:      	ldr	w1, [sp, #0x1c]
     968:      	ldr	w0, [sp, #0x2c]
     96c:      	add	w0, w1, w0
     970:      	str	w0, [sp, #0x34]
     974:      	ldr	w0, [sp, #0x34]
     978:      	and	w0, w0, #0xffff
     97c:      	str	w0, [sp, #0x38]
     980:      	ldr	w1, [sp, #0x20]
     984:      	ldr	w0, [sp, #0x30]
     988:      	add	w1, w1, w0
     98c:      	ldr	w0, [sp, #0x34]
     990:      	lsr	w0, w0, #16
     994:      	add	w0, w1, w0
     998:      	and	w0, w0, #0xffff
     99c:      	str	w0, [sp, #0x3c]
     9a0:      	ldr	w0, [sp, #0x38]
     9a4:      	lsl	w0, w0, #10
     9a8:      	and	w0, w0, #0xffff
     9ac:      	str	w0, [sp, #0x40]
     9b0:      	ldr	w0, [sp, #0x3c]
     9b4:      	lsl	w1, w0, #10
     9b8:      	ldr	w0, [sp, #0x38]
     9bc:      	lsr	w0, w0, #6
     9c0:      	orr	w0, w1, w0
     9c4:      	and	w0, w0, #0xffff
     9c8:      	str	w0, [sp, #0x44]
     9cc:      	ldr	w1, [sp, #0x38]
     9d0:      	ldr	w0, [sp, #0x40]
     9d4:      	add	w0, w1, w0
     9d8:      	str	w0, [sp, #0x48]
     9dc:      	ldr	w0, [sp, #0x48]
     9e0:      	and	w0, w0, #0xffff
     9e4:      	str	w0, [sp, #0x4c]
     9e8:      	ldr	w1, [sp, #0x3c]
     9ec:      	ldr	w0, [sp, #0x44]
     9f0:      	add	w1, w1, w0
     9f4:      	ldr	w0, [sp, #0x48]
     9f8:      	lsr	w0, w0, #16
     9fc:      	add	w0, w1, w0
     a00:      	and	w0, w0, #0xffff
     a04:      	str	w0, [sp, #0x50]
     a08:      	ldr	w0, [sp, #0x4c]
     a0c:      	lsr	w1, w0, #6
     a10:      	ldr	w0, [sp, #0x50]
     a14:      	lsl	w0, w0, #10
     a18:      	orr	w0, w1, w0
     a1c:      	and	w0, w0, #0xffff
     a20:      	str	w0, [sp, #0x54]
     a24:      	ldr	w0, [sp, #0x50]
     a28:      	lsr	w0, w0, #6
     a2c:      	str	w0, [sp, #0x58]
     a30:      	ldr	w1, [sp, #0x4c]
     a34:      	ldr	w0, [sp, #0x54]
     a38:      	eor	w0, w1, w0
     a3c:      	str	w0, [sp, #0x5c]
     a40:      	ldr	w1, [sp, #0x50]
     a44:      	ldr	w0, [sp, #0x58]
     a48:      	eor	w0, w1, w0
     a4c:      	str	w0, [sp, #0x60]
     a50:      	ldr	w0, [sp, #0x24]
     a54:      	lsr	w1, w0, #8
     a58:      	ldr	w0, [sp, #0x28]
     a5c:      	lsl	w0, w0, #8
     a60:      	orr	w0, w1, w0
     a64:      	and	w0, w0, #0xffff
     a68:      	str	w0, [sp, #0x64]
     a6c:      	ldr	w0, [sp, #0x28]
     a70:      	lsr	w0, w0, #8
     a74:      	str	w0, [sp, #0x68]
     a78:      	ldr	w0, [sp, #0x64]
     a7c:      	and	w0, w0, #0xff
     a80:      	str	w0, [sp, #0x6c]
     a84:      	str	wzr, [sp, #0x70]
     a88:      	ldr	w1, [sp, #0x5c]
     a8c:      	ldr	w0, [sp, #0x6c]
     a90:      	add	w0, w1, w0
     a94:      	str	w0, [sp, #0x74]
     a98:      	ldr	w0, [sp, #0x74]
     a9c:      	and	w0, w0, #0xffff
     aa0:      	str	w0, [sp, #0x78]
     aa4:      	ldr	w1, [sp, #0x60]
     aa8:      	ldr	w0, [sp, #0x70]
     aac:      	add	w1, w1, w0
     ab0:      	ldr	w0, [sp, #0x74]
     ab4:      	lsr	w0, w0, #16
     ab8:      	add	w0, w1, w0
     abc:      	and	w0, w0, #0xffff
     ac0:      	str	w0, [sp, #0x7c]
     ac4:      	ldr	w0, [sp, #0x78]
     ac8:      	lsl	w0, w0, #10
     acc:      	and	w0, w0, #0xffff
     ad0:      	str	w0, [sp, #0x80]
     ad4:      	ldr	w0, [sp, #0x7c]
     ad8:      	lsl	w1, w0, #10
     adc:      	ldr	w0, [sp, #0x78]
     ae0:      	lsr	w0, w0, #6
     ae4:      	orr	w0, w1, w0
     ae8:      	and	w0, w0, #0xffff
     aec:      	str	w0, [sp, #0x84]
     af0:      	ldr	w1, [sp, #0x78]
     af4:      	ldr	w0, [sp, #0x80]
     af8:      	add	w0, w1, w0
     afc:      	str	w0, [sp, #0x88]
     b00:      	ldr	w0, [sp, #0x88]
     b04:      	and	w0, w0, #0xffff
     b08:      	str	w0, [sp, #0x8c]
     b0c:      	ldr	w1, [sp, #0x7c]
     b10:      	ldr	w0, [sp, #0x84]
     b14:      	add	w1, w1, w0
     b18:      	ldr	w0, [sp, #0x88]
     b1c:      	lsr	w0, w0, #16
     b20:      	add	w0, w1, w0
     b24:      	and	w0, w0, #0xffff
     b28:      	str	w0, [sp, #0x90]
     b2c:      	ldr	w0, [sp, #0x8c]
     b30:      	lsr	w1, w0, #6
     b34:      	ldr	w0, [sp, #0x90]
     b38:      	lsl	w0, w0, #10
     b3c:      	orr	w0, w1, w0
     b40:      	and	w0, w0, #0xffff
     b44:      	str	w0, [sp, #0x94]
     b48:      	ldr	w0, [sp, #0x90]
     b4c:      	lsr	w0, w0, #6
     b50:      	str	w0, [sp, #0x98]
     b54:      	ldr	w1, [sp, #0x8c]
     b58:      	ldr	w0, [sp, #0x94]
     b5c:      	eor	w0, w1, w0
     b60:      	str	w0, [sp, #0x9c]
     b64:      	ldr	w1, [sp, #0x90]
     b68:      	ldr	w0, [sp, #0x98]
     b6c:      	eor	w0, w1, w0
     b70:      	str	w0, [sp, #0xa0]
     b74:      	ldr	w0, [sp, #0x64]
     b78:      	lsr	w1, w0, #8
     b7c:      	ldr	w0, [sp, #0x68]
     b80:      	lsl	w0, w0, #8
     b84:      	orr	w0, w1, w0
     b88:      	and	w0, w0, #0xffff
     b8c:      	str	w0, [sp, #0xa4]
     b90:      	ldr	w0, [sp, #0x68]
     b94:      	lsr	w0, w0, #8
     b98:      	str	w0, [sp, #0xa8]
     b9c:      	ldr	w0, [sp, #0xa4]
     ba0:      	and	w0, w0, #0xff
     ba4:      	str	w0, [sp, #0xac]
     ba8:      	str	wzr, [sp, #0xb0]
     bac:      	ldr	w1, [sp, #0x9c]
     bb0:      	ldr	w0, [sp, #0xac]
     bb4:      	add	w0, w1, w0
     bb8:      	str	w0, [sp, #0xb4]
     bbc:      	ldr	w0, [sp, #0xb4]
     bc0:      	and	w0, w0, #0xffff
     bc4:      	str	w0, [sp, #0xb8]
     bc8:      	ldr	w1, [sp, #0xa0]
     bcc:      	ldr	w0, [sp, #0xb0]
     bd0:      	add	w1, w1, w0
     bd4:      	ldr	w0, [sp, #0xb4]
     bd8:      	lsr	w0, w0, #16
     bdc:      	add	w0, w1, w0
     be0:      	and	w0, w0, #0xffff
     be4:      	str	w0, [sp, #0xbc]
     be8:      	ldr	w0, [sp, #0xb8]
     bec:      	lsl	w0, w0, #10
     bf0:      	and	w0, w0, #0xffff
     bf4:      	str	w0, [sp, #0xc0]
     bf8:      	ldr	w0, [sp, #0xbc]
     bfc:      	lsl	w1, w0, #10
     c00:      	ldr	w0, [sp, #0xb8]
     c04:      	lsr	w0, w0, #6
     c08:      	orr	w0, w1, w0
     c0c:      	and	w0, w0, #0xffff
     c10:      	str	w0, [sp, #0xc4]
     c14:      	ldr	w1, [sp, #0xb8]
     c18:      	ldr	w0, [sp, #0xc0]
     c1c:      	add	w0, w1, w0
     c20:      	str	w0, [sp, #0xc8]
     c24:      	ldr	w0, [sp, #0xc8]
     c28:      	and	w0, w0, #0xffff
     c2c:      	str	w0, [sp, #0xcc]
     c30:      	ldr	w1, [sp, #0xbc]
     c34:      	ldr	w0, [sp, #0xc4]
     c38:      	add	w1, w1, w0
     c3c:      	ldr	w0, [sp, #0xc8]
     c40:      	lsr	w0, w0, #16
     c44:      	add	w0, w1, w0
     c48:      	and	w0, w0, #0xffff
     c4c:      	str	w0, [sp, #0xd0]
     c50:      	ldr	w0, [sp, #0xcc]
     c54:      	lsr	w1, w0, #6
     c58:      	ldr	w0, [sp, #0xd0]
     c5c:      	lsl	w0, w0, #10
     c60:      	orr	w0, w1, w0
     c64:      	and	w0, w0, #0xffff
     c68:      	str	w0, [sp, #0xd4]
     c6c:      	ldr	w0, [sp, #0xd0]
     c70:      	lsr	w0, w0, #6
     c74:      	str	w0, [sp, #0xd8]
     c78:      	ldr	w1, [sp, #0xcc]
     c7c:      	ldr	w0, [sp, #0xd4]
     c80:      	eor	w0, w1, w0
     c84:      	str	w0, [sp, #0xdc]
     c88:      	ldr	w1, [sp, #0xd0]
     c8c:      	ldr	w0, [sp, #0xd8]
     c90:      	eor	w0, w1, w0
     c94:      	str	w0, [sp, #0xe0]
     c98:      	ldr	w0, [sp, #0xa4]
     c9c:      	lsr	w1, w0, #8
     ca0:      	ldr	w0, [sp, #0xa8]
     ca4:      	lsl	w0, w0, #8
     ca8:      	orr	w0, w1, w0
     cac:      	and	w0, w0, #0xffff
     cb0:      	str	w0, [sp, #0xe4]
     cb4:      	ldr	w0, [sp, #0xa8]
     cb8:      	lsr	w0, w0, #8
     cbc:      	str	w0, [sp, #0xe8]
     cc0:      	ldr	w0, [sp, #0xe4]
     cc4:      	and	w0, w0, #0xff
     cc8:      	str	w0, [sp, #0xec]
     ccc:      	str	wzr, [sp, #0xf0]
     cd0:      	ldr	w1, [sp, #0xdc]
     cd4:      	ldr	w0, [sp, #0xec]
     cd8:      	add	w0, w1, w0
     cdc:      	str	w0, [sp, #0xf4]
     ce0:      	ldr	w0, [sp, #0xf4]
     ce4:      	and	w0, w0, #0xffff
     ce8:      	str	w0, [sp, #0xf8]
     cec:      	ldr	w1, [sp, #0xe0]
     cf0:      	ldr	w0, [sp, #0xf0]
     cf4:      	add	w1, w1, w0
     cf8:      	ldr	w0, [sp, #0xf4]
     cfc:      	lsr	w0, w0, #16
     d00:      	add	w0, w1, w0
     d04:      	and	w0, w0, #0xffff
     d08:      	str	w0, [sp, #0xfc]
     d0c:      	ldr	w0, [sp, #0xf8]
     d10:      	lsl	w0, w0, #10
     d14:      	and	w0, w0, #0xffff
     d18:      	str	w0, [sp, #0x100]
     d1c:      	ldr	w0, [sp, #0xfc]
     d20:      	lsl	w1, w0, #10
     d24:      	ldr	w0, [sp, #0xf8]
     d28:      	lsr	w0, w0, #6
     d2c:      	orr	w0, w1, w0
     d30:      	and	w0, w0, #0xffff
     d34:      	str	w0, [sp, #0x104]
     d38:      	ldr	w1, [sp, #0xf8]
     d3c:      	ldr	w0, [sp, #0x100]
     d40:      	add	w0, w1, w0
     d44:      	str	w0, [sp, #0x108]
     d48:      	ldr	w0, [sp, #0x108]
     d4c:      	and	w0, w0, #0xffff
     d50:      	str	w0, [sp, #0x10c]
     d54:      	ldr	w1, [sp, #0xfc]
     d58:      	ldr	w0, [sp, #0x104]
     d5c:      	add	w1, w1, w0
     d60:      	ldr	w0, [sp, #0x108]
     d64:      	lsr	w0, w0, #16
     d68:      	add	w0, w1, w0
     d6c:      	and	w0, w0, #0xffff
     d70:      	str	w0, [sp, #0x110]
     d74:      	ldr	w0, [sp, #0x10c]
     d78:      	lsr	w1, w0, #6
     d7c:      	ldr	w0, [sp, #0x110]
     d80:      	lsl	w0, w0, #10
     d84:      	orr	w0, w1, w0
     d88:      	and	w0, w0, #0xffff
     d8c:      	str	w0, [sp, #0x114]
     d90:      	ldr	w0, [sp, #0x110]
     d94:      	lsr	w0, w0, #6
     d98:      	str	w0, [sp, #0x118]
     d9c:      	ldr	w1, [sp, #0x10c]
     da0:      	ldr	w0, [sp, #0x114]
     da4:      	eor	w0, w1, w0
     da8:      	str	w0, [sp, #0x11c]
     dac:      	ldr	w1, [sp, #0x110]
     db0:      	ldr	w0, [sp, #0x118]
     db4:      	eor	w0, w1, w0
     db8:      	str	w0, [sp, #0x120]
     dbc:      	ldr	w0, [sp, #0x11c]
     dc0:      	lsl	w0, w0, #3
     dc4:      	and	w0, w0, #0xffff
     dc8:      	str	w0, [sp, #0x124]
     dcc:      	ldr	w0, [sp, #0x120]
     dd0:      	lsl	w1, w0, #3
     dd4:      	ldr	w0, [sp, #0x11c]
     dd8:      	lsr	w0, w0, #13
     ddc:      	orr	w0, w1, w0
     de0:      	and	w0, w0, #0xffff
     de4:      	str	w0, [sp, #0x128]
     de8:      	ldr	w1, [sp, #0x11c]
     dec:      	ldr	w0, [sp, #0x124]
     df0:      	add	w0, w1, w0
     df4:      	str	w0, [sp, #0x12c]
     df8:      	ldr	w0, [sp, #0x12c]
     dfc:      	and	w0, w0, #0xffff
     e00:      	str	w0, [sp, #0x130]
     e04:      	ldr	w1, [sp, #0x120]
     e08:      	ldr	w0, [sp, #0x128]
     e0c:      	add	w1, w1, w0
     e10:      	ldr	w0, [sp, #0x12c]
     e14:      	lsr	w0, w0, #16
     e18:      	add	w0, w1, w0
     e1c:      	and	w0, w0, #0xffff
     e20:      	str	w0, [sp, #0x134]
     e24:      	ldr	w0, [sp, #0x130]
     e28:      	lsr	w1, w0, #11
     e2c:      	ldr	w0, [sp, #0x134]
     e30:      	lsl	w0, w0, #5
     e34:      	orr	w0, w1, w0
     e38:      	and	w0, w0, #0xffff
     e3c:      	str	w0, [sp, #0x138]
     e40:      	ldr	w0, [sp, #0x134]
     e44:      	lsr	w0, w0, #11
     e48:      	str	w0, [sp, #0x13c]
     e4c:      	ldr	w1, [sp, #0x130]
     e50:      	ldr	w0, [sp, #0x138]
     e54:      	eor	w0, w1, w0
     e58:      	str	w0, [sp, #0x140]
     e5c:      	ldr	w1, [sp, #0x134]
     e60:      	ldr	w0, [sp, #0x13c]
     e64:      	eor	w0, w1, w0
     e68:      	str	w0, [sp, #0x144]
     e6c:      	ldr	w0, [sp, #0x140]
     e70:      	lsl	w0, w0, #15
     e74:      	and	w0, w0, #0xffff
     e78:      	str	w0, [sp, #0x148]
     e7c:      	ldr	w0, [sp, #0x144]
     e80:      	lsl	w1, w0, #15
     e84:      	ldr	w0, [sp, #0x140]
     e88:      	lsr	w0, w0, #1
     e8c:      	orr	w0, w1, w0
     e90:      	and	w0, w0, #0xffff
     e94:      	str	w0, [sp, #0x14c]
     e98:      	ldr	w1, [sp, #0x140]
     e9c:      	ldr	w0, [sp, #0x148]
     ea0:      	add	w0, w1, w0
     ea4:      	str	w0, [sp, #0x150]
     ea8:      	ldr	w0, [sp, #0x150]
     eac:      	and	w0, w0, #0xffff
     eb0:      	str	w0, [sp, #0x154]
     eb4:      	ldr	w1, [sp, #0x144]
     eb8:      	ldr	w0, [sp, #0x14c]
     ebc:      	add	w1, w1, w0
     ec0:      	ldr	w0, [sp, #0x150]
     ec4:      	lsr	w0, w0, #16
     ec8:      	add	w0, w1, w0
     ecc:      	and	w0, w0, #0xffff
     ed0:      	str	w0, [sp, #0x158]
     ed4:      	ldr	w0, [sp, #0x158]
     ed8:      	lsl	w0, w0, #16
     edc:      	ldr	w1, [sp, #0x154]
     ee0:      	orr	w0, w1, w0
     ee4:      	str	w0, [sp, #0x15c]
     ee8:      	ldr	w0, [sp, #0x15c]
     eec:      	add	sp, sp, #0x160
     ef0:      	ret

0000000000000ef4 <csrd_matrix_next_value>:
     ef4:      	sub	sp, sp, #0x10
     ef8:      	str	x0, [sp, #0x8]
     efc:      	ldr	x0, [sp, #0x8]
     f00:      	ldr	w1, [x0]
     f04:      	ldr	x0, [sp, #0x8]
     f08:      	ldr	w0, [x0]
     f0c:      	lsl	w0, w0, #13
     f10:      	eor	w1, w1, w0
     f14:      	ldr	x0, [sp, #0x8]
     f18:      	str	w1, [x0]
     f1c:      	ldr	x0, [sp, #0x8]
     f20:      	ldr	w1, [x0]
     f24:      	ldr	x0, [sp, #0x8]
     f28:      	ldr	w0, [x0]
     f2c:      	lsr	w0, w0, #17
     f30:      	eor	w1, w1, w0
     f34:      	ldr	x0, [sp, #0x8]
     f38:      	str	w1, [x0]
     f3c:      	ldr	x0, [sp, #0x8]
     f40:      	ldr	w1, [x0]
     f44:      	ldr	x0, [sp, #0x8]
     f48:      	ldr	w0, [x0]
     f4c:      	lsl	w0, w0, #5
     f50:      	eor	w1, w1, w0
     f54:      	ldr	x0, [sp, #0x8]
     f58:      	str	w1, [x0]
     f5c:      	ldr	x0, [sp, #0x8]
     f60:      	ldr	w0, [x0]
     f64:      	add	sp, sp, #0x10
     f68:      	ret

0000000000000f6c <main>:
     f6c:      	sub	sp, sp, #0x80
     f70:      	stp	x29, x30, [sp, #0x70]
     f74:      	add	x29, sp, #0x70
     f78:      	str	w0, [sp, #0xc]
     f7c:      	str	x1, [sp]
     f80:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1dd00>
     f84:      	ldr	x0, [x0, #0xfe8]
     f88:      	ldr	x1, [x0]
     f8c:      	str	x1, [sp, #0x68]
     f90:      	mov	x1, #0x0                // =0
     f94:      	ldr	w0, [sp, #0xc]
     f98:      	cmp	w0, #0x1
     f9c:      	b.ne	0xff0 <main+0x84>
     fa0:      	b	0xfc0 <main+0x54>
     fa4:      	ldr	w0, [sp, #0x60]
     fa8:      	ldr	w1, [sp, #0x64]
     fac:      	bl	0x918 <kernel>
     fb0:      	mov	w1, w0
     fb4:      	adrp	x0, 0x1000 <main+0x94>
     fb8:      	add	x0, x0, #0x1a0
     fbc:      	bl	0x7f0 <printf@plt>
     fc0:      	add	x0, sp, #0x60
     fc4:      	add	x1, x0, #0x4
     fc8:      	add	x0, sp, #0x60
     fcc:      	mov	x2, x1
     fd0:      	mov	x1, x0
     fd4:      	adrp	x0, 0x1000 <main+0x94>
     fd8:      	add	x0, x0, #0x1a8
     fdc:      	bl	0x7e0 <__isoc99_scanf@plt>
     fe0:      	cmp	w0, #0x2
     fe4:      	b.eq	0xfa4 <main+0x38>
     fe8:      	mov	w0, #0x0                // =0
     fec:      	b	0x1150 <main+0x1e4>
     ff0:      	ldr	w0, [sp, #0xc]
     ff4:      	cmp	w0, #0x3
     ff8:      	b.eq	0x1004 <main+0x98>
     ffc:      	mov	w0, #0x3                // =3
    1000:      	b	0x1150 <main+0x1e4>
    1004:      	ldr	x0, [sp]
    1008:      	add	x0, x0, #0x8
    100c:      	ldr	x0, [x0]
    1010:      	mov	w2, #0xa                // =10
    1014:      	mov	x1, #0x0                // =0
    1018:      	bl	0x770 <strtoul@plt>
    101c:      	str	x0, [sp, #0x30]
    1020:      	ldr	x0, [sp]
    1024:      	add	x0, x0, #0x10
    1028:      	ldr	x0, [x0]
    102c:      	mov	w2, #0xa                // =10
    1030:      	mov	x1, #0x0                // =0
    1034:      	bl	0x770 <strtoul@plt>
    1038:      	str	w0, [sp, #0x18]
    103c:      	str	xzr, [sp, #0x20]
    1040:      	add	x0, sp, #0x40
    1044:      	mov	x1, x0
    1048:      	mov	w0, #0x1                // =1
    104c:      	bl	0x7a0 <clock_gettime@plt>
    1050:      	cmp	w0, #0x0
    1054:      	b.eq	0x1060 <main+0xf4>
    1058:      	mov	w0, #0x2                // =2
    105c:      	b	0x1150 <main+0x1e4>
    1060:      	str	xzr, [sp, #0x28]
    1064:      	b	0x10cc <main+0x160>
    1068:      	str	wzr, [sp, #0x1c]
    106c:      	b	0x1098 <main+0x12c>
    1070:      	add	x0, sp, #0x18
    1074:      	bl	0xef4 <csrd_matrix_next_value>
    1078:      	mov	w2, w0
    107c:      	ldr	w0, [sp, #0x1c]
    1080:      	lsl	x0, x0, #2
    1084:      	add	x1, sp, #0x60
    1088:      	str	w2, [x1, x0]
    108c:      	ldr	w0, [sp, #0x1c]
    1090:      	add	w0, w0, #0x1
    1094:      	str	w0, [sp, #0x1c]
    1098:      	ldr	w0, [sp, #0x1c]
    109c:      	cmp	w0, #0x1
    10a0:      	b.ls	0x1070 <main+0x104>
    10a4:      	ldr	w0, [sp, #0x60]
    10a8:      	ldr	w1, [sp, #0x64]
    10ac:      	bl	0x918 <kernel>
    10b0:      	mov	w0, w0
    10b4:      	ldr	x1, [sp, #0x20]
    10b8:      	add	x0, x1, x0
    10bc:      	str	x0, [sp, #0x20]
    10c0:      	ldr	x0, [sp, #0x28]
    10c4:      	add	x0, x0, #0x1
    10c8:      	str	x0, [sp, #0x28]
    10cc:      	ldr	x1, [sp, #0x28]
    10d0:      	ldr	x0, [sp, #0x30]
    10d4:      	cmp	x1, x0
    10d8:      	b.lo	0x1068 <main+0xfc>
    10dc:      	add	x0, sp, #0x50
    10e0:      	mov	x1, x0
    10e4:      	mov	w0, #0x1                // =1
    10e8:      	bl	0x7a0 <clock_gettime@plt>
    10ec:      	cmp	w0, #0x0
    10f0:      	b.eq	0x10fc <main+0x190>
    10f4:      	mov	w0, #0x2                // =2
    10f8:      	b	0x1150 <main+0x1e4>
    10fc:      	ldr	x1, [sp, #0x50]
    1100:      	ldr	x0, [sp, #0x40]
    1104:      	sub	x0, x1, x0
    1108:      	fmov	d0, x0
    110c:      	scvtf	d1, d0
    1110:      	ldr	x1, [sp, #0x58]
    1114:      	ldr	x0, [sp, #0x48]
    1118:      	sub	x0, x1, x0
    111c:      	fmov	d0, x0
    1120:      	scvtf	d0, d0
    1124:      	adrp	x0, 0x1000 <main+0x94>
    1128:      	ldr	d2, [x0, #0x1c0]
    112c:      	fmul	d0, d0, d2
    1130:      	fadd	d0, d1, d0
    1134:      	str	d0, [sp, #0x38]
    1138:      	ldr	x1, [sp, #0x20]
    113c:      	ldr	d0, [sp, #0x38]
    1140:      	adrp	x0, 0x1000 <main+0x94>
    1144:      	add	x0, x0, #0x1b0
    1148:      	bl	0x7f0 <printf@plt>
    114c:      	mov	w0, #0x0                // =0
    1150:      	mov	w1, w0
    1154:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1dd00>
    1158:      	ldr	x0, [x0, #0xfe8]
    115c:      	ldr	x3, [sp, #0x68]
    1160:      	ldr	x2, [x0]
    1164:      	subs	x3, x3, x2
    1168:      	mov	x2, #0x0                // =0
    116c:      	b.eq	0x1174 <main+0x208>
    1170:      	bl	0x7b0 <__stack_chk_fail@plt>
    1174:      	mov	w0, w1
    1178:      	ldp	x29, x30, [sp, #0x70]
    117c:      	add	sp, sp, #0x80
    1180:      	ret

Disassembly of section .fini:

0000000000001184 <_fini>:
    1184:      	nop
    1188:      	stp	x29, x30, [sp, #-0x10]!
    118c:      	mov	x29, sp
    1190:      	ldp	x29, x30, [sp], #0x10
    1194:      	ret
