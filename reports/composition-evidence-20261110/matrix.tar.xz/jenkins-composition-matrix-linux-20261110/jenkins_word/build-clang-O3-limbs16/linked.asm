
/work/experiments/runs/jenkins-composition-matrix-linux-20261110/jenkins_word/build-clang-O3-limbs16/program:	file format elf64-littleaarch64

Disassembly of section .init:

0000000000000678 <_init>:
     678:      	nop
     67c:      	stp	x29, x30, [sp, #-0x10]!
     680:      	mov	x29, sp
     684:      	bl	0x774 <call_weak_fn>
     688:      	ldp	x29, x30, [sp], #0x10
     68c:      	ret

Disassembly of section .plt:

0000000000000690 <.plt>:
     690:      	stp	x16, x30, [sp, #-0x10]!
     694:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e340>
     698:      	ldr	x17, [x16, #0xff8]
     69c:      	add	x16, x16, #0xff8
     6a0:      	br	x17
     6a4:      	nop
     6a8:      	nop
     6ac:      	nop

00000000000006b0 <strtoul@plt>:
     6b0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6b4:      	ldr	x17, [x16]
     6b8:      	add	x16, x16, #0x0
     6bc:      	br	x17

00000000000006c0 <__libc_start_main@plt>:
     6c0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6c4:      	ldr	x17, [x16, #0x8]
     6c8:      	add	x16, x16, #0x8
     6cc:      	br	x17

00000000000006d0 <__cxa_finalize@plt>:
     6d0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6d4:      	ldr	x17, [x16, #0x10]
     6d8:      	add	x16, x16, #0x10
     6dc:      	br	x17

00000000000006e0 <clock_gettime@plt>:
     6e0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6e4:      	ldr	x17, [x16, #0x18]
     6e8:      	add	x16, x16, #0x18
     6ec:      	br	x17

00000000000006f0 <__gmon_start__@plt>:
     6f0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6f4:      	ldr	x17, [x16, #0x20]
     6f8:      	add	x16, x16, #0x20
     6fc:      	br	x17

0000000000000700 <abort@plt>:
     700:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     704:      	ldr	x17, [x16, #0x28]
     708:      	add	x16, x16, #0x28
     70c:      	br	x17

0000000000000710 <__isoc99_scanf@plt>:
     710:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     714:      	ldr	x17, [x16, #0x30]
     718:      	add	x16, x16, #0x30
     71c:      	br	x17

0000000000000720 <printf@plt>:
     720:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     724:      	ldr	x17, [x16, #0x38]
     728:      	add	x16, x16, #0x38
     72c:      	br	x17

Disassembly of section .text:

0000000000000740 <_start>:
     740:      	nop
     744:      	mov	x29, #0x0               // =0
     748:      	mov	x30, #0x0               // =0
     74c:      	mov	x5, x0
     750:      	ldr	x1, [sp]
     754:      	add	x2, sp, #0x8
     758:      	mov	x6, sp
     75c:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e340>
     760:      	ldr	x0, [x0, #0xfd8]
     764:      	mov	x3, #0x0                // =0
     768:      	mov	x4, #0x0                // =0
     76c:      	bl	0x6c0 <__libc_start_main@plt>
     770:      	bl	0x700 <abort@plt>

0000000000000774 <call_weak_fn>:
     774:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e340>
     778:      	ldr	x0, [x0, #0xfd0]
     77c:      	cbz	x0, 0x784 <call_weak_fn+0x10>
     780:      	b	0x6f0 <__gmon_start__@plt>
     784:      	ret
     788:      	nop
     78c:      	nop

0000000000000790 <deregister_tm_clones>:
     790:      	adrp	x0, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     794:      	add	x0, x0, #0x50
     798:      	adrp	x1, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     79c:      	add	x1, x1, #0x50
     7a0:      	cmp	x1, x0
     7a4:      	b.eq	0x7bc <deregister_tm_clones+0x2c>
     7a8:      	adrp	x1, 0x1f000 <__FRAME_END__+0x1e340>
     7ac:      	ldr	x1, [x1, #0xfc0]
     7b0:      	cbz	x1, 0x7bc <deregister_tm_clones+0x2c>
     7b4:      	mov	x16, x1
     7b8:      	br	x16
     7bc:      	ret

00000000000007c0 <register_tm_clones>:
     7c0:      	adrp	x0, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     7c4:      	add	x0, x0, #0x50
     7c8:      	adrp	x1, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     7cc:      	add	x1, x1, #0x50
     7d0:      	sub	x1, x1, x0
     7d4:      	lsr	x2, x1, #63
     7d8:      	add	x1, x2, x1, asr #3
     7dc:      	asr	x1, x1, #1
     7e0:      	cbz	x1, 0x7f8 <register_tm_clones+0x38>
     7e4:      	adrp	x2, 0x1f000 <__FRAME_END__+0x1e340>
     7e8:      	ldr	x2, [x2, #0xfe0]
     7ec:      	cbz	x2, 0x7f8 <register_tm_clones+0x38>
     7f0:      	mov	x16, x2
     7f4:      	br	x16
     7f8:      	ret
     7fc:      	nop

0000000000000800 <__do_global_dtors_aux>:
     800:      	paciasp
     804:      	stp	x29, x30, [sp, #-0x20]!
     808:      	mov	x29, sp
     80c:      	str	x19, [sp, #0x10]
     810:      	adrp	x19, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     814:      	ldrb	w0, [x19, #0x50]
     818:      	tbnz	w0, #0x0, 0x840 <__do_global_dtors_aux+0x40>
     81c:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e340>
     820:      	ldr	x0, [x0, #0xfc8]
     824:      	cbz	x0, 0x834 <__do_global_dtors_aux+0x34>
     828:      	adrp	x0, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     82c:      	ldr	x0, [x0, #0x48]
     830:      	bl	0x6d0 <__cxa_finalize@plt>
     834:      	bl	0x790 <deregister_tm_clones>
     838:      	mov	w0, #0x1                // =1
     83c:      	strb	w0, [x19, #0x50]
     840:      	ldr	x19, [sp, #0x10]
     844:      	ldp	x29, x30, [sp], #0x20
     848:      	autiasp
     84c:      	ret

0000000000000850 <frame_dummy>:
     850:      	bti	c
     854:      	b	0x7c0 <register_tm_clones>

0000000000000858 <kernel>:
     858:      	and	w8, w1, #0xff
     85c:      	add	w8, w8, w0, uxth
     860:      	lsr	w9, w8, #16
     864:      	and	w10, w8, #0xffff
     868:      	ubfiz	w8, w8, #10, #6
     86c:      	add	w9, w9, w0, lsr #16
     870:      	add	w8, w8, w10
     874:      	add	w11, w9, w10, lsr #6
     878:      	ubfx	w10, w8, #6, #10
     87c:      	add	w9, w11, w9, lsl #10
     880:      	lsr	w11, w1, #8
     884:      	add	w9, w9, w8, lsr #16
     888:      	and	w8, w8, #0xffff
     88c:      	bfi	w10, w9, #10, #6
     890:      	and	w12, w9, #0xffc0
     894:      	eor	w9, w9, w12, lsr #6
     898:      	eor	w8, w10, w8
     89c:      	add	w8, w8, w11, uxtb
     8a0:      	add	w9, w9, w8, lsr #16
     8a4:      	and	w10, w8, #0xffff
     8a8:      	ubfiz	w8, w8, #10, #6
     8ac:      	add	w11, w9, w10, lsr #6
     8b0:      	add	w8, w8, w10
     8b4:      	ubfx	w10, w8, #6, #10
     8b8:      	add	w9, w11, w9, lsl #10
     8bc:      	lsr	w11, w1, #16
     8c0:      	add	w9, w9, w8, lsr #16
     8c4:      	and	w8, w8, #0xffff
     8c8:      	bfi	w10, w9, #10, #6
     8cc:      	and	w12, w9, #0xffc0
     8d0:      	eor	w9, w9, w12, lsr #6
     8d4:      	eor	w8, w10, w8
     8d8:      	add	w8, w8, w11, uxtb
     8dc:      	add	w9, w9, w8, lsr #16
     8e0:      	and	w10, w8, #0xffff
     8e4:      	ubfiz	w8, w8, #10, #6
     8e8:      	add	w11, w9, w10, lsr #6
     8ec:      	add	w8, w8, w10
     8f0:      	ubfx	w10, w8, #6, #10
     8f4:      	add	w9, w11, w9, lsl #10
     8f8:      	add	w9, w9, w8, lsr #16
     8fc:      	and	w8, w8, #0xffff
     900:      	bfi	w10, w9, #10, #6
     904:      	and	w11, w9, #0xffc0
     908:      	eor	w9, w9, w11, lsr #6
     90c:      	eor	w8, w10, w8
     910:      	add	w8, w8, w1, lsr #24
     914:      	add	w9, w9, w8, lsr #16
     918:      	and	w10, w8, #0xffff
     91c:      	ubfiz	w8, w8, #10, #6
     920:      	add	w11, w9, w10, lsr #6
     924:      	add	w8, w8, w10
     928:      	ubfx	w10, w8, #6, #10
     92c:      	add	w9, w11, w9, lsl #10
     930:      	add	w9, w9, w8, lsr #16
     934:      	and	w8, w8, #0xffff
     938:      	and	w11, w9, #0xffc0
     93c:      	bfi	w10, w9, #10, #6
     940:      	eor	w9, w9, w11, lsr #6
     944:      	eor	w8, w10, w8
     948:      	add	w9, w9, w9, lsl #3
     94c:      	ubfiz	w10, w8, #3, #13
     950:      	add	w9, w9, w8, lsr #13
     954:      	add	w8, w10, w8
     958:      	ubfx	w10, w8, #11, #5
     95c:      	add	w9, w9, w8, lsr #16
     960:      	and	w8, w8, #0xffff
     964:      	and	w11, w9, #0xf800
     968:      	bfi	w10, w9, #5, #11
     96c:      	eor	w9, w9, w11, lsr #11
     970:      	eor	w8, w10, w8
     974:      	add	w9, w9, w9, lsl #15
     978:      	ubfiz	w10, w8, #15, #1
     97c:      	add	w9, w9, w8, lsr #1
     980:      	add	w8, w10, w8
     984:      	add	w0, w8, w9, lsl #16
     988:      	ret

000000000000098c <main>:
     98c:      	sub	sp, sp, #0x50
     990:      	stp	x29, x30, [sp, #0x20]
     994:      	str	x21, [sp, #0x30]
     998:      	stp	x20, x19, [sp, #0x40]
     99c:      	add	x29, sp, #0x20
     9a0:      	cmp	w0, #0x3
     9a4:      	b.eq	0xa10 <main+0x84>
     9a8:      	cmp	w0, #0x1
     9ac:      	b.ne	0xa68 <main+0xdc>
     9b0:      	add	x21, sp, #0x10
     9b4:      	adrp	x0, 0x0 <strtoul@GLIBC_2.17>
     9b8:      	add	x0, x0, #0xb50
     9bc:      	add	x1, sp, #0x10
     9c0:      	add	x2, x21, #0x4
     9c4:      	bl	0x710 <__isoc99_scanf@plt>
     9c8:      	cmp	w0, #0x2
     9cc:      	b.ne	0xb10 <main+0x184>
     9d0:      	adrp	x19, 0x0 <strtoul@GLIBC_2.17>
     9d4:      	add	x19, x19, #0xb55
     9d8:      	adrp	x20, 0x0 <strtoul@GLIBC_2.17>
     9dc:      	add	x20, x20, #0xb50
     9e0:      	ldp	w0, w1, [sp, #0x10]
     9e4:      	bl	0x858 <kernel>
     9e8:      	mov	w1, w0
     9ec:      	mov	x0, x19
     9f0:      	bl	0x720 <printf@plt>
     9f4:      	add	x1, sp, #0x10
     9f8:      	add	x2, x21, #0x4
     9fc:      	mov	x0, x20
     a00:      	bl	0x710 <__isoc99_scanf@plt>
     a04:      	cmp	w0, #0x2
     a08:      	b.eq	0x9e0 <main+0x54>
     a0c:      	b	0xb10 <main+0x184>
     a10:      	ldr	x0, [x1, #0x8]
     a14:      	mov	x19, x1
     a18:      	mov	x1, xzr
     a1c:      	mov	w2, #0xa                // =10
     a20:      	bl	0x6b0 <strtoul@plt>
     a24:      	ldr	x8, [x19, #0x10]
     a28:      	mov	x20, x0
     a2c:      	mov	x1, xzr
     a30:      	mov	w2, #0xa                // =10
     a34:      	mov	x0, x8
     a38:      	bl	0x6b0 <strtoul@plt>
     a3c:      	mov	x21, x0
     a40:      	add	x1, sp, #0x10
     a44:      	mov	w0, #0x1                // =1
     a48:      	bl	0x6e0 <clock_gettime@plt>
     a4c:      	cbz	w0, 0xa80 <main+0xf4>
     a50:      	mov	w0, #0x2                // =2
     a54:      	ldp	x20, x19, [sp, #0x40]
     a58:      	ldr	x21, [sp, #0x30]
     a5c:      	ldp	x29, x30, [sp, #0x20]
     a60:      	add	sp, sp, #0x50
     a64:      	ret
     a68:      	mov	w0, #0x3                // =3
     a6c:      	ldp	x20, x19, [sp, #0x40]
     a70:      	ldr	x21, [sp, #0x30]
     a74:      	ldp	x29, x30, [sp, #0x20]
     a78:      	add	sp, sp, #0x50
     a7c:      	ret
     a80:      	mov	x19, xzr
     a84:      	cbz	x20, 0xab4 <main+0x128>
     a88:      	eor	w8, w21, w21, lsl #13
     a8c:      	eor	w8, w8, w8, lsr #17
     a90:      	eor	w0, w8, w8, lsl #5
     a94:      	eor	w8, w0, w0, lsl #13
     a98:      	eor	w8, w8, w8, lsr #17
     a9c:      	eor	w21, w8, w8, lsl #5
     aa0:      	mov	w1, w21
     aa4:      	bl	0x858 <kernel>
     aa8:      	add	x19, x19, w0, uxtw
     aac:      	subs	x20, x20, #0x1
     ab0:      	b.ne	0xa88 <main+0xfc>
     ab4:      	mov	x1, sp
     ab8:      	mov	w0, #0x1                // =1
     abc:      	bl	0x6e0 <clock_gettime@plt>
     ac0:      	cbz	w0, 0xadc <main+0x150>
     ac4:      	mov	w0, #0x2                // =2
     ac8:      	ldp	x20, x19, [sp, #0x40]
     acc:      	ldr	x21, [sp, #0x30]
     ad0:      	ldp	x29, x30, [sp, #0x20]
     ad4:      	add	sp, sp, #0x50
     ad8:      	ret
     adc:      	ldp	x8, x9, [sp]
     ae0:      	adrp	x0, 0x0 <strtoul@GLIBC_2.17>
     ae4:      	add	x0, x0, #0xb59
     ae8:      	ldp	x10, x11, [sp, #0x10]
     aec:      	mov	x1, x19
     af0:      	sub	x8, x8, x10
     af4:      	sub	x9, x9, x11
     af8:      	scvtf	d0, x8
     afc:      	scvtf	d1, x9
     b00:      	adrp	x8, 0x0 <strtoul@GLIBC_2.17>
     b04:      	ldr	d2, [x8, #0xb48]
     b08:      	fmadd	d0, d1, d2, d0
     b0c:      	bl	0x720 <printf@plt>
     b10:      	mov	w0, wzr
     b14:      	ldp	x20, x19, [sp, #0x40]
     b18:      	ldr	x21, [sp, #0x30]
     b1c:      	ldp	x29, x30, [sp, #0x20]
     b20:      	add	sp, sp, #0x50
     b24:      	ret

Disassembly of section .fini:

0000000000000b28 <_fini>:
     b28:      	nop
     b2c:      	stp	x29, x30, [sp, #-0x10]!
     b30:      	mov	x29, sp
     b34:      	ldp	x29, x30, [sp], #0x10
     b38:      	ret
