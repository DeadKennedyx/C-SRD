
/work/experiments/runs/jenkins-composition-matrix-linux-20261110/jenkins_word/build-gcc-O2-lto-affine-42/program:	file format elf64-littleaarch64

Disassembly of section .init:

0000000000000738 <_init>:
     738:      	nop
     73c:      	stp	x29, x30, [sp, #-0x10]!
     740:      	mov	x29, sp
     744:      	bl	0x9f4 <call_weak_fn>
     748:      	ldp	x29, x30, [sp], #0x10
     74c:      	ret

Disassembly of section .plt:

0000000000000750 <.plt>:
     750:      	stp	x16, x30, [sp, #-0x10]!
     754:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e358>
     758:      	ldr	x17, [x16, #0xf78]
     75c:      	add	x16, x16, #0xf78
     760:      	br	x17
     764:      	nop
     768:      	nop
     76c:      	nop

0000000000000770 <strtoul@plt>:
     770:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e358>
     774:      	ldr	x17, [x16, #0xf80]
     778:      	add	x16, x16, #0xf80
     77c:      	br	x17

0000000000000780 <__libc_start_main@plt>:
     780:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e358>
     784:      	ldr	x17, [x16, #0xf88]
     788:      	add	x16, x16, #0xf88
     78c:      	br	x17

0000000000000790 <__cxa_finalize@plt>:
     790:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e358>
     794:      	ldr	x17, [x16, #0xf90]
     798:      	add	x16, x16, #0xf90
     79c:      	br	x17

00000000000007a0 <clock_gettime@plt>:
     7a0:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e358>
     7a4:      	ldr	x17, [x16, #0xf98]
     7a8:      	add	x16, x16, #0xf98
     7ac:      	br	x17

00000000000007b0 <__printf_chk@plt>:
     7b0:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e358>
     7b4:      	ldr	x17, [x16, #0xfa0]
     7b8:      	add	x16, x16, #0xfa0
     7bc:      	br	x17

00000000000007c0 <__stack_chk_fail@plt>:
     7c0:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e358>
     7c4:      	ldr	x17, [x16, #0xfa8]
     7c8:      	add	x16, x16, #0xfa8
     7cc:      	br	x17

00000000000007d0 <__gmon_start__@plt>:
     7d0:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e358>
     7d4:      	ldr	x17, [x16, #0xfb0]
     7d8:      	add	x16, x16, #0xfb0
     7dc:      	br	x17

00000000000007e0 <abort@plt>:
     7e0:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e358>
     7e4:      	ldr	x17, [x16, #0xfb8]
     7e8:      	add	x16, x16, #0xfb8
     7ec:      	br	x17

00000000000007f0 <__isoc99_scanf@plt>:
     7f0:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e358>
     7f4:      	ldr	x17, [x16, #0xfc0]
     7f8:      	add	x16, x16, #0xfc0
     7fc:      	br	x17

Disassembly of section .text:

0000000000000800 <main>:
     800:      	sub	sp, sp, #0x60
     804:      	mov	w2, w0
     808:      	adrp	x3, 0x1f000 <__FRAME_END__+0x1e358>
     80c:      	ldr	x3, [x3, #0xfe8]
     810:      	stp	x29, x30, [sp, #0x30]
     814:      	add	x29, sp, #0x30
     818:      	ldr	x0, [x3]
     81c:      	str	x0, [sp, #0x28]
     820:      	mov	x0, #0x0                // =0
     824:      	cmp	w2, #0x1
     828:      	b.eq	0x938 <main+0x138>
     82c:      	mov	w0, #0x3                // =3
     830:      	cmp	w2, w0
     834:      	b.eq	0x860 <main+0x60>
     838:      	adrp	x1, 0x1f000 <__FRAME_END__+0x1e358>
     83c:      	ldr	x1, [x1, #0xfe8]
     840:      	ldr	x3, [sp, #0x28]
     844:      	ldr	x2, [x1]
     848:      	subs	x3, x3, x2
     84c:      	mov	x2, #0x0                // =0
     850:      	b.ne	0x9ac <main+0x1ac>
     854:      	ldp	x29, x30, [sp, #0x30]
     858:      	add	sp, sp, #0x60
     85c:      	ret
     860:      	stp	x19, x20, [sp, #0x40]
     864:      	mov	x19, x1
     868:      	mov	w2, #0xa                // =10
     86c:      	mov	x1, #0x0                // =0
     870:      	ldr	x0, [x19, #0x8]
     874:      	bl	0x770 <strtoul@plt>
     878:      	mov	x20, x0
     87c:      	ldr	x0, [x19, #0x10]
     880:      	mov	w2, #0xa                // =10
     884:      	mov	x1, #0x0                // =0
     888:      	bl	0x770 <strtoul@plt>
     88c:      	mov	x19, x0
     890:      	add	x1, sp, #0x10
     894:      	mov	w0, #0x1                // =1
     898:      	bl	0x7a0 <clock_gettime@plt>
     89c:      	cbnz	w0, 0x9a0 <main+0x1a0>
     8a0:      	cbz	x20, 0x8e8 <main+0xe8>
     8a4:      	mov	w1, w19
     8a8:      	mov	x5, #0x0                // =0
     8ac:      	mov	x6, #0x0                // =0
     8b0:      	eor	w1, w1, w1, lsl #13
     8b4:      	add	x5, x5, #0x1
     8b8:      	eor	w1, w1, w1, lsr #17
     8bc:      	eor	w4, w1, w1, lsl #5
     8c0:      	mov	w0, w4
     8c4:      	eor	w1, w4, w4, lsl #13
     8c8:      	eor	w1, w1, w1, lsr #17
     8cc:      	eor	w1, w1, w1, lsl #5
     8d0:      	bl	0xae0 <kernel>
     8d4:      	add	x6, x6, w0, uxtw
     8d8:      	cmp	x20, x5
     8dc:      	b.ne	0x8b0 <main+0xb0>
     8e0:      	mov	x20, x6
     8e4:      	stp	w4, w1, [sp, #0x20]
     8e8:      	mov	x1, sp
     8ec:      	mov	w0, #0x1                // =1
     8f0:      	bl	0x7a0 <clock_gettime@plt>
     8f4:      	cbnz	w0, 0x9a0 <main+0x1a0>
     8f8:      	adrp	x1, 0x0 <strtoul@GLIBC_2.17>
     8fc:      	mov	x2, x20
     900:      	ldp	x3, x0, [sp]
     904:      	ldr	d1, [x1, #0xb68]
     908:      	ldp	x4, x1, [sp, #0x10]
     90c:      	sub	x0, x0, x1
     910:      	sub	x3, x3, x4
     914:      	adrp	x1, 0x0 <strtoul@GLIBC_2.17>
     918:      	add	x1, x1, #0xb58
     91c:      	scvtf	d0, x0
     920:      	mov	w0, #0x2                // =2
     924:      	fmul	d0, d0, d1
     928:      	scvtf	d1, x3
     92c:      	fadd	d0, d0, d1
     930:      	bl	0x7b0 <__printf_chk@plt>
     934:      	b	0x994 <main+0x194>
     938:      	stp	x19, x20, [sp, #0x40]
     93c:      	adrp	x19, 0x0 <strtoul@GLIBC_2.17>
     940:      	adrp	x20, 0x0 <strtoul@GLIBC_2.17>
     944:      	add	x19, x19, #0xb50
     948:      	add	x20, x20, #0xb48
     94c:      	stp	x21, x22, [sp, #0x50]
     950:      	add	x22, sp, #0x20
     954:      	add	x21, sp, #0x24
     958:      	b	0x974 <main+0x174>
     95c:      	ldp	w0, w1, [sp, #0x20]
     960:      	bl	0xae0 <kernel>
     964:      	mov	x1, x20
     968:      	mov	w2, w0
     96c:      	mov	w0, w4
     970:      	bl	0x7b0 <__printf_chk@plt>
     974:      	mov	x2, x21
     978:      	mov	x1, x22
     97c:      	mov	x0, x19
     980:      	bl	0x7f0 <__isoc99_scanf@plt>
     984:      	mov	w4, w0
     988:      	cmp	w0, #0x2
     98c:      	b.eq	0x95c <main+0x15c>
     990:      	ldp	x21, x22, [sp, #0x50]
     994:      	mov	w0, #0x0                // =0
     998:      	ldp	x19, x20, [sp, #0x40]
     99c:      	b	0x838 <main+0x38>
     9a0:      	ldp	x19, x20, [sp, #0x40]
     9a4:      	mov	w0, #0x2                // =2
     9a8:      	b	0x838 <main+0x38>
     9ac:      	stp	x19, x20, [sp, #0x40]
     9b0:      	stp	x21, x22, [sp, #0x50]
     9b4:      	bl	0x7c0 <__stack_chk_fail@plt>
     9b8:      	nop
     9bc:      	nop

00000000000009c0 <_start>:
     9c0:      	nop
     9c4:      	mov	x29, #0x0               // =0
     9c8:      	mov	x30, #0x0               // =0
     9cc:      	mov	x5, x0
     9d0:      	ldr	x1, [sp]
     9d4:      	add	x2, sp, #0x8
     9d8:      	mov	x6, sp
     9dc:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e358>
     9e0:      	ldr	x0, [x0, #0xff0]
     9e4:      	mov	x3, #0x0                // =0
     9e8:      	mov	x4, #0x0                // =0
     9ec:      	bl	0x780 <__libc_start_main@plt>
     9f0:      	bl	0x7e0 <abort@plt>

00000000000009f4 <call_weak_fn>:
     9f4:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e358>
     9f8:      	ldr	x0, [x0, #0xfe0]
     9fc:      	cbz	x0, 0xa04 <call_weak_fn+0x10>
     a00:      	b	0x7d0 <__gmon_start__@plt>
     a04:      	ret
     a08:      	nop
     a0c:      	nop

0000000000000a10 <deregister_tm_clones>:
     a10:      	adrp	x0, 0x20000 <data_start>
     a14:      	add	x0, x0, #0x10
     a18:      	adrp	x1, 0x20000 <data_start>
     a1c:      	add	x1, x1, #0x10
     a20:      	cmp	x1, x0
     a24:      	b.eq	0xa3c <deregister_tm_clones+0x2c>
     a28:      	adrp	x1, 0x1f000 <__FRAME_END__+0x1e358>
     a2c:      	ldr	x1, [x1, #0xfd0]
     a30:      	cbz	x1, 0xa3c <deregister_tm_clones+0x2c>
     a34:      	mov	x16, x1
     a38:      	br	x16
     a3c:      	ret

0000000000000a40 <register_tm_clones>:
     a40:      	adrp	x0, 0x20000 <data_start>
     a44:      	add	x0, x0, #0x10
     a48:      	adrp	x1, 0x20000 <data_start>
     a4c:      	add	x1, x1, #0x10
     a50:      	sub	x1, x1, x0
     a54:      	lsr	x2, x1, #63
     a58:      	add	x1, x2, x1, asr #3
     a5c:      	asr	x1, x1, #1
     a60:      	cbz	x1, 0xa78 <register_tm_clones+0x38>
     a64:      	adrp	x2, 0x1f000 <__FRAME_END__+0x1e358>
     a68:      	ldr	x2, [x2, #0xff8]
     a6c:      	cbz	x2, 0xa78 <register_tm_clones+0x38>
     a70:      	mov	x16, x2
     a74:      	br	x16
     a78:      	ret
     a7c:      	nop

0000000000000a80 <__do_global_dtors_aux>:
     a80:      	paciasp
     a84:      	stp	x29, x30, [sp, #-0x20]!
     a88:      	mov	x29, sp
     a8c:      	str	x19, [sp, #0x10]
     a90:      	adrp	x19, 0x20000 <data_start>
     a94:      	ldrb	w0, [x19, #0x10]
     a98:      	tbnz	w0, #0x0, 0xac0 <__do_global_dtors_aux+0x40>
     a9c:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e358>
     aa0:      	ldr	x0, [x0, #0xfd8]
     aa4:      	cbz	x0, 0xab4 <__do_global_dtors_aux+0x34>
     aa8:      	adrp	x0, 0x20000 <data_start>
     aac:      	ldr	x0, [x0, #0x8]
     ab0:      	bl	0x790 <__cxa_finalize@plt>
     ab4:      	bl	0xa10 <deregister_tm_clones>
     ab8:      	mov	w0, #0x1                // =1
     abc:      	strb	w0, [x19, #0x10]
     ac0:      	ldr	x19, [sp, #0x10]
     ac4:      	ldp	x29, x30, [sp], #0x20
     ac8:      	autiasp
     acc:      	ret

0000000000000ad0 <frame_dummy>:
     ad0:      	bti	c
     ad4:      	b	0xa40 <register_tm_clones>
     ad8:      	nop
     adc:      	nop

0000000000000ae0 <kernel>:
     ae0:      	add	w0, w0, w1, uxtb
     ae4:      	ubfx	x3, x1, #8, #8
     ae8:      	ubfx	x2, x1, #16, #8
     aec:      	add	w0, w0, w0, lsl #10
     af0:      	eor	w0, w0, w0, lsr #6
     af4:      	add	w0, w0, w3
     af8:      	add	w0, w0, w0, lsl #10
     afc:      	eor	w0, w0, w0, lsr #6
     b00:      	add	w0, w0, w2
     b04:      	add	w0, w0, w0, lsl #10
     b08:      	eor	w0, w0, w0, lsr #6
     b0c:      	add	w0, w0, w1, lsr #24
     b10:      	add	w0, w0, w0, lsl #10
     b14:      	eor	w0, w0, w0, lsr #6
     b18:      	add	w0, w0, w0, lsl #3
     b1c:      	eor	w0, w0, w0, lsr #11
     b20:      	add	w0, w0, w0, lsl #15
     b24:      	ret

Disassembly of section .fini:

0000000000000b28 <_fini>:
     b28:      	nop
     b2c:      	stp	x29, x30, [sp, #-0x10]!
     b30:      	mov	x29, sp
     b34:      	ldp	x29, x30, [sp], #0x10
     b38:      	ret
