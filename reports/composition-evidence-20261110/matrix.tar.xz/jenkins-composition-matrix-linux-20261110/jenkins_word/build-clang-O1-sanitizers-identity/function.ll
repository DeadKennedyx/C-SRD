; ModuleID = '/work/experiments/runs/jenkins-composition-matrix-linux-20261110/jenkins_word/build-clang-O1-sanitizers-identity/validation/compiler-0-O1/candidate.i'
source_filename = "/work/experiments/runs/jenkins-composition-matrix-linux-20261110/jenkins_word/build-clang-O1-sanitizers-identity/validation/compiler-0-O1/candidate.i"
target datalayout = "e-m:e-i8:8:32-i16:16:32-i64:64-i128:128-n32:64-S128"
target triple = "aarch64-unknown-linux-gnu"

$asan.module_ctor = comdat any

@llvm.used = appending global [1 x ptr] [ptr @asan.module_ctor], section "llvm.metadata"
@___asan_globals_registered = common hidden global i64 0
@__start_asan_globals = extern_weak hidden global i64
@__stop_asan_globals = extern_weak hidden global i64
@llvm.global_ctors = appending global [1 x { i32, ptr, ptr }] [{ i32, ptr, ptr } { i32 1, ptr @asan.module_ctor, ptr @asan.module_ctor }]

; Function Attrs: mustprogress nofree norecurse nosync nounwind sanitize_address willreturn memory(none) uwtable
define dso_local i32 @kernel(i32 noundef %state, i32 noundef %word) local_unnamed_addr #0 !func_sanitize !6 {
entry:
  %and = and i32 %word, 255
  %add = add i32 %and, %state
  %add1 = mul i32 %add, 1025
  %shr = lshr i32 %add1, 6
  %xor = xor i32 %shr, %add1
  %shr6 = lshr i32 %word, 8
  %and7 = and i32 %shr6, 255
  %add8 = add i32 %xor, %and7
  %add12 = mul i32 %add8, 1025
  %shr15 = lshr i32 %add12, 6
  %xor16 = xor i32 %shr15, %add12
  %shr19 = lshr i32 %word, 16
  %and20 = and i32 %shr19, 255
  %add21 = add i32 %xor16, %and20
  %add25 = mul i32 %add21, 1025
  %shr28 = lshr i32 %add25, 6
  %xor29 = xor i32 %shr28, %add25
  %shr32 = lshr i32 %word, 24
  %add34 = add i32 %xor29, %shr32
  %add38 = mul i32 %add34, 1025
  %shr41 = lshr i32 %add38, 6
  %xor42 = xor i32 %shr41, %add38
  %add46 = mul i32 %xor42, 9
  %shr49 = lshr i32 %add46, 11
  %xor50 = xor i32 %shr49, %add46
  %add54 = mul i32 %xor50, 32769
  ret i32 %add54
}

declare void @__asan_register_elf_globals(i64, i64, i64)

declare void @__asan_init()

; Function Attrs: nounwind uwtable
define internal void @asan.module_ctor() #1 comdat {
  call void @__asan_init()
  call void @__asan_version_mismatch_check_v8()
  call void @__asan_register_elf_globals(i64 ptrtoint (ptr @___asan_globals_registered to i64), i64 ptrtoint (ptr @__start_asan_globals to i64), i64 ptrtoint (ptr @__stop_asan_globals to i64))
  ret void
}

declare void @__asan_version_mismatch_check_v8()

attributes #0 = { mustprogress nofree norecurse nosync nounwind sanitize_address willreturn memory(none) uwtable "frame-pointer"="non-leaf" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+fp-armv8,+neon,+outline-atomics,+v8a,-fmv" }
attributes #1 = { nounwind uwtable "frame-pointer"="non-leaf" }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 1, !"wchar_size", i32 4}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 1}
!5 = !{!"Ubuntu clang version 18.1.3 (1ubuntu1)"}
!6 = !{i32 -1056584962, i32 -455559067}
