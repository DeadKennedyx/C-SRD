
/work/experiments/runs/jenkins-composition-matrix-linux-20261110/jenkins_word/build-clang-O2-pgo-identity/program:	file format elf64-littleaarch64

Disassembly of section .init:

0000000000000678 <_init>:
     678:      	nop
     67c:      	stp	x29, x30, [sp, #-0x10]!
     680:      	mov	x29, sp
     684:      	bl	0x7f4 <call_weak_fn>
     688:      	ldp	x29, x30, [sp], #0x10
     68c:      	ret

Disassembly of section .plt:

0000000000000690 <.plt>:
     690:      	stp	x16, x30, [sp, #-0x10]!
     694:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e45c>
     698:      	ldr	x17, [x16, #0xff8]
     69c:      	add	x16, x16, #0xff8
     6a0:      	br	x17
     6a4:      	nop
     6a8:      	nop
     6ac:      	nop

00000000000006b0 <strtoul@plt>:
     6b0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6b4:      	ldr	x17, [x16]
     6b8:      	add	x16, x16, #0x0
     6bc:      	br	x17

00000000000006c0 <__libc_start_main@plt>:
     6c0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6c4:      	ldr	x17, [x16, #0x8]
     6c8:      	add	x16, x16, #0x8
     6cc:      	br	x17

00000000000006d0 <__cxa_finalize@plt>:
     6d0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6d4:      	ldr	x17, [x16, #0x10]
     6d8:      	add	x16, x16, #0x10
     6dc:      	br	x17

00000000000006e0 <clock_gettime@plt>:
     6e0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6e4:      	ldr	x17, [x16, #0x18]
     6e8:      	add	x16, x16, #0x18
     6ec:      	br	x17

00000000000006f0 <__gmon_start__@plt>:
     6f0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6f4:      	ldr	x17, [x16, #0x20]
     6f8:      	add	x16, x16, #0x20
     6fc:      	br	x17

0000000000000700 <abort@plt>:
     700:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     704:      	ldr	x17, [x16, #0x28]
     708:      	add	x16, x16, #0x28
     70c:      	br	x17

0000000000000710 <__isoc99_scanf@plt>:
     710:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     714:      	ldr	x17, [x16, #0x30]
     718:      	add	x16, x16, #0x30
     71c:      	br	x17

0000000000000720 <printf@plt>:
     720:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     724:      	ldr	x17, [x16, #0x38]
     728:      	add	x16, x16, #0x38
     72c:      	br	x17

Disassembly of section .text:

0000000000000740 <kernel>:
     740:      	add	w8, w0, w1, uxtb
     744:      	lsr	w9, w1, #8
     748:      	add	w8, w8, w8, lsl #10
     74c:      	eor	w8, w8, w8, lsr #6
     750:      	add	w8, w8, w9, uxtb
     754:      	lsr	w9, w1, #16
     758:      	add	w8, w8, w8, lsl #10
     75c:      	eor	w8, w8, w8, lsr #6
     760:      	add	w8, w8, w9, uxtb
     764:      	add	w8, w8, w8, lsl #10
     768:      	eor	w8, w8, w8, lsr #6
     76c:      	add	w8, w8, w1, lsr #24
     770:      	add	w8, w8, w8, lsl #10
     774:      	eor	w8, w8, w8, lsr #6
     778:      	add	w8, w8, w8, lsl #3
     77c:      	eor	w8, w8, w8, lsr #11
     780:      	add	w0, w8, w8, lsl #15
     784:      	ret
     788:      	nop
     78c:      	nop
     790:      	nop
     794:      	nop
     798:      	nop
     79c:      	nop
     7a0:      	nop
     7a4:      	nop
     7a8:      	nop
     7ac:      	nop
     7b0:      	nop
     7b4:      	nop
     7b8:      	nop
     7bc:      	nop

00000000000007c0 <_start>:
     7c0:      	nop
     7c4:      	mov	x29, #0x0               // =0
     7c8:      	mov	x30, #0x0               // =0
     7cc:      	mov	x5, x0
     7d0:      	ldr	x1, [sp]
     7d4:      	add	x2, sp, #0x8
     7d8:      	mov	x6, sp
     7dc:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e45c>
     7e0:      	ldr	x0, [x0, #0xfd8]
     7e4:      	mov	x3, #0x0                // =0
     7e8:      	mov	x4, #0x0                // =0
     7ec:      	bl	0x6c0 <__libc_start_main@plt>
     7f0:      	bl	0x700 <abort@plt>

00000000000007f4 <call_weak_fn>:
     7f4:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e45c>
     7f8:      	ldr	x0, [x0, #0xfd0]
     7fc:      	cbz	x0, 0x804 <call_weak_fn+0x10>
     800:      	b	0x6f0 <__gmon_start__@plt>
     804:      	ret
     808:      	nop
     80c:      	nop

0000000000000810 <deregister_tm_clones>:
     810:      	adrp	x0, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     814:      	add	x0, x0, #0x50
     818:      	adrp	x1, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     81c:      	add	x1, x1, #0x50
     820:      	cmp	x1, x0
     824:      	b.eq	0x83c <deregister_tm_clones+0x2c>
     828:      	adrp	x1, 0x1f000 <__FRAME_END__+0x1e45c>
     82c:      	ldr	x1, [x1, #0xfc0]
     830:      	cbz	x1, 0x83c <deregister_tm_clones+0x2c>
     834:      	mov	x16, x1
     838:      	br	x16
     83c:      	ret

0000000000000840 <register_tm_clones>:
     840:      	adrp	x0, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     844:      	add	x0, x0, #0x50
     848:      	adrp	x1, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     84c:      	add	x1, x1, #0x50
     850:      	sub	x1, x1, x0
     854:      	lsr	x2, x1, #63
     858:      	add	x1, x2, x1, asr #3
     85c:      	asr	x1, x1, #1
     860:      	cbz	x1, 0x878 <register_tm_clones+0x38>
     864:      	adrp	x2, 0x1f000 <__FRAME_END__+0x1e45c>
     868:      	ldr	x2, [x2, #0xfe0]
     86c:      	cbz	x2, 0x878 <register_tm_clones+0x38>
     870:      	mov	x16, x2
     874:      	br	x16
     878:      	ret
     87c:      	nop

0000000000000880 <__do_global_dtors_aux>:
     880:      	paciasp
     884:      	stp	x29, x30, [sp, #-0x20]!
     888:      	mov	x29, sp
     88c:      	str	x19, [sp, #0x10]
     890:      	adrp	x19, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     894:      	ldrb	w0, [x19, #0x50]
     898:      	tbnz	w0, #0x0, 0x8c0 <__do_global_dtors_aux+0x40>
     89c:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e45c>
     8a0:      	ldr	x0, [x0, #0xfc8]
     8a4:      	cbz	x0, 0x8b4 <__do_global_dtors_aux+0x34>
     8a8:      	adrp	x0, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     8ac:      	ldr	x0, [x0, #0x48]
     8b0:      	bl	0x6d0 <__cxa_finalize@plt>
     8b4:      	bl	0x810 <deregister_tm_clones>
     8b8:      	mov	w0, #0x1                // =1
     8bc:      	strb	w0, [x19, #0x50]
     8c0:      	ldr	x19, [sp, #0x10]
     8c4:      	ldp	x29, x30, [sp], #0x20
     8c8:      	autiasp
     8cc:      	ret

00000000000008d0 <frame_dummy>:
     8d0:      	bti	c
     8d4:      	b	0x840 <register_tm_clones>

00000000000008d8 <main>:
     8d8:      	sub	sp, sp, #0x50
     8dc:      	stp	x29, x30, [sp, #0x20]
     8e0:      	str	x21, [sp, #0x30]
     8e4:      	stp	x20, x19, [sp, #0x40]
     8e8:      	add	x29, sp, #0x20
     8ec:      	cmp	w0, #0x1
     8f0:      	b.ne	0x968 <main+0x90>
     8f4:      	add	x21, sp, #0x10
     8f8:      	adrp	x0, 0x0 <strtoul@GLIBC_2.17>
     8fc:      	add	x0, x0, #0xa60
     900:      	add	x1, sp, #0x10
     904:      	add	x2, x21, #0x4
     908:      	bl	0x710 <__isoc99_scanf@plt>
     90c:      	cmp	w0, #0x2
     910:      	b.ne	0x950 <main+0x78>
     914:      	adrp	x19, 0x0 <strtoul@GLIBC_2.17>
     918:      	add	x19, x19, #0xa65
     91c:      	adrp	x20, 0x0 <strtoul@GLIBC_2.17>
     920:      	add	x20, x20, #0xa60
     924:      	ldp	w0, w1, [sp, #0x10]
     928:      	bl	0x740 <kernel>
     92c:      	mov	w1, w0
     930:      	mov	x0, x19
     934:      	bl	0x720 <printf@plt>
     938:      	add	x1, sp, #0x10
     93c:      	add	x2, x21, #0x4
     940:      	mov	x0, x20
     944:      	bl	0x710 <__isoc99_scanf@plt>
     948:      	cmp	w0, #0x2
     94c:      	b.eq	0x924 <main+0x4c>
     950:      	mov	w0, wzr
     954:      	ldp	x20, x19, [sp, #0x40]
     958:      	ldr	x21, [sp, #0x30]
     95c:      	ldp	x29, x30, [sp, #0x20]
     960:      	add	sp, sp, #0x50
     964:      	ret
     968:      	cmp	w0, #0x3
     96c:      	b.ne	0x9b8 <main+0xe0>
     970:      	ldr	x0, [x1, #0x8]
     974:      	mov	x19, x1
     978:      	mov	x1, xzr
     97c:      	mov	w2, #0xa                // =10
     980:      	bl	0x6b0 <strtoul@plt>
     984:      	ldr	x8, [x19, #0x10]
     988:      	mov	x20, x0
     98c:      	mov	x1, xzr
     990:      	mov	w2, #0xa                // =10
     994:      	mov	x0, x8
     998:      	bl	0x6b0 <strtoul@plt>
     99c:      	mov	x21, x0
     9a0:      	add	x1, sp, #0x10
     9a4:      	mov	w0, #0x1                // =1
     9a8:      	bl	0x6e0 <clock_gettime@plt>
     9ac:      	cbz	w0, 0x9c0 <main+0xe8>
     9b0:      	mov	w0, #0x2                // =2
     9b4:      	b	0x954 <main+0x7c>
     9b8:      	mov	w0, #0x3                // =3
     9bc:      	b	0x954 <main+0x7c>
     9c0:      	mov	x19, xzr
     9c4:      	cbz	x20, 0x9f4 <main+0x11c>
     9c8:      	eor	w8, w21, w21, lsl #13
     9cc:      	eor	w8, w8, w8, lsr #17
     9d0:      	eor	w0, w8, w8, lsl #5
     9d4:      	eor	w8, w0, w0, lsl #13
     9d8:      	eor	w8, w8, w8, lsr #17
     9dc:      	eor	w21, w8, w8, lsl #5
     9e0:      	mov	w1, w21
     9e4:      	bl	0x740 <kernel>
     9e8:      	add	x19, x19, w0, uxtw
     9ec:      	subs	x20, x20, #0x1
     9f0:      	b.ne	0x9c8 <main+0xf0>
     9f4:      	mov	x1, sp
     9f8:      	mov	w0, #0x1                // =1
     9fc:      	bl	0x6e0 <clock_gettime@plt>
     a00:      	cbnz	w0, 0x9b0 <main+0xd8>
     a04:      	ldp	x8, x9, [sp]
     a08:      	adrp	x0, 0x0 <strtoul@GLIBC_2.17>
     a0c:      	add	x0, x0, #0xa69
     a10:      	ldp	x10, x11, [sp, #0x10]
     a14:      	mov	x1, x19
     a18:      	sub	x8, x8, x10
     a1c:      	sub	x9, x9, x11
     a20:      	scvtf	d0, x8
     a24:      	scvtf	d1, x9
     a28:      	adrp	x8, 0x0 <strtoul@GLIBC_2.17>
     a2c:      	ldr	d2, [x8, #0xa58]
     a30:      	fmadd	d0, d1, d2, d0
     a34:      	bl	0x720 <printf@plt>
     a38:      	b	0x950 <main+0x78>

Disassembly of section .fini:

0000000000000a3c <_fini>:
     a3c:      	nop
     a40:      	stp	x29, x30, [sp, #-0x10]!
     a44:      	mov	x29, sp
     a48:      	ldp	x29, x30, [sp], #0x10
     a4c:      	ret
