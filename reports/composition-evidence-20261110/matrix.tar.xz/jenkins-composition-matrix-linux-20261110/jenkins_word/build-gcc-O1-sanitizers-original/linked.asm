
/work/experiments/runs/jenkins-composition-matrix-linux-20261110/jenkins_word/build-gcc-O1-sanitizers-original/program:	file format elf64-littleaarch64

Disassembly of section .init:

00000000000011c0 <_init>:
    11c0:      	nop
    11c4:      	stp	x29, x30, [sp, #-0x10]!
    11c8:      	mov	x29, sp
    11cc:      	bl	0x13b4 <call_weak_fn>
    11d0:      	ldp	x29, x30, [sp], #0x10
    11d4:      	ret

Disassembly of section .plt:

00000000000011e0 <.plt>:
    11e0:      	stp	x16, x30, [sp, #-0x10]!
    11e4:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1d09c>
    11e8:      	ldr	x17, [x16, #0xf08]
    11ec:      	add	x16, x16, #0xf08
    11f0:      	br	x17
    11f4:      	nop
    11f8:      	nop
    11fc:      	nop

0000000000001200 <__asan_report_store4@plt>:
    1200:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1d09c>
    1204:      	ldr	x17, [x16, #0xf10]
    1208:      	add	x16, x16, #0xf10
    120c:      	br	x17

0000000000001210 <__ubsan_handle_type_mismatch_v1_abort@plt>:
    1210:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1d09c>
    1214:      	ldr	x17, [x16, #0xf18]
    1218:      	add	x16, x16, #0xf18
    121c:      	br	x17

0000000000001220 <__asan_register_globals@plt>:
    1220:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1d09c>
    1224:      	ldr	x17, [x16, #0xf20]
    1228:      	add	x16, x16, #0xf20
    122c:      	br	x17

0000000000001230 <__stack_chk_fail@plt>:
    1230:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1d09c>
    1234:      	ldr	x17, [x16, #0xf28]
    1238:      	add	x16, x16, #0xf28
    123c:      	br	x17

0000000000001240 <__ubsan_handle_nonnull_arg_abort@plt>:
    1240:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1d09c>
    1244:      	ldr	x17, [x16, #0xf30]
    1248:      	add	x16, x16, #0xf30
    124c:      	br	x17

0000000000001250 <__ubsan_handle_sub_overflow_abort@plt>:
    1250:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1d09c>
    1254:      	ldr	x17, [x16, #0xf38]
    1258:      	add	x16, x16, #0xf38
    125c:      	br	x17

0000000000001260 <__asan_report_load4@plt>:
    1260:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1d09c>
    1264:      	ldr	x17, [x16, #0xf40]
    1268:      	add	x16, x16, #0xf40
    126c:      	br	x17

0000000000001270 <__cxa_finalize@plt>:
    1270:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1d09c>
    1274:      	ldr	x17, [x16, #0xf48]
    1278:      	add	x16, x16, #0xf48
    127c:      	br	x17

0000000000001280 <__libc_start_main@plt>:
    1280:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1d09c>
    1284:      	ldr	x17, [x16, #0xf50]
    1288:      	add	x16, x16, #0xf50
    128c:      	br	x17

0000000000001290 <__asan_unregister_globals@plt>:
    1290:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1d09c>
    1294:      	ldr	x17, [x16, #0xf58]
    1298:      	add	x16, x16, #0xf58
    129c:      	br	x17

00000000000012a0 <__asan_handle_no_return@plt>:
    12a0:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1d09c>
    12a4:      	ldr	x17, [x16, #0xf60]
    12a8:      	add	x16, x16, #0xf60
    12ac:      	br	x17

00000000000012b0 <__asan_init@plt>:
    12b0:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1d09c>
    12b4:      	ldr	x17, [x16, #0xf68]
    12b8:      	add	x16, x16, #0xf68
    12bc:      	br	x17

00000000000012c0 <strtoul@plt>:
    12c0:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1d09c>
    12c4:      	ldr	x17, [x16, #0xf70]
    12c8:      	add	x16, x16, #0xf70
    12cc:      	br	x17

00000000000012d0 <clock_gettime@plt>:
    12d0:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1d09c>
    12d4:      	ldr	x17, [x16, #0xf78]
    12d8:      	add	x16, x16, #0xf78
    12dc:      	br	x17

00000000000012e0 <__asan_report_load8@plt>:
    12e0:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1d09c>
    12e4:      	ldr	x17, [x16, #0xf80]
    12e8:      	add	x16, x16, #0xf80
    12ec:      	br	x17

00000000000012f0 <abort@plt>:
    12f0:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1d09c>
    12f4:      	ldr	x17, [x16, #0xf88]
    12f8:      	add	x16, x16, #0xf88
    12fc:      	br	x17

0000000000001300 <__asan_stack_malloc_2@plt>:
    1300:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1d09c>
    1304:      	ldr	x17, [x16, #0xf90]
    1308:      	add	x16, x16, #0xf90
    130c:      	br	x17

0000000000001310 <__asan_version_mismatch_check_v8@plt>:
    1310:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1d09c>
    1314:      	ldr	x17, [x16, #0xf98]
    1318:      	add	x16, x16, #0xf98
    131c:      	br	x17

0000000000001320 <__isoc99_scanf@plt>:
    1320:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1d09c>
    1324:      	ldr	x17, [x16, #0xfa0]
    1328:      	add	x16, x16, #0xfa0
    132c:      	br	x17

0000000000001330 <__printf_chk@plt>:
    1330:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1d09c>
    1334:      	ldr	x17, [x16, #0xfa8]
    1338:      	add	x16, x16, #0xfa8
    133c:      	br	x17

0000000000001340 <__gmon_start__@plt>:
    1340:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1d09c>
    1344:      	ldr	x17, [x16, #0xfb0]
    1348:      	add	x16, x16, #0xfb0
    134c:      	br	x17

0000000000001350 <__ubsan_handle_pointer_overflow_abort@plt>:
    1350:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1d09c>
    1354:      	ldr	x17, [x16, #0xfb8]
    1358:      	add	x16, x16, #0xfb8
    135c:      	br	x17

Disassembly of section .text:

0000000000001380 <_start>:
    1380:      	nop
    1384:      	mov	x29, #0x0               // =0
    1388:      	mov	x30, #0x0               // =0
    138c:      	mov	x5, x0
    1390:      	ldr	x1, [sp]
    1394:      	add	x2, sp, #0x8
    1398:      	mov	x6, sp
    139c:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1d09c>
    13a0:      	ldr	x0, [x0, #0xfd0]
    13a4:      	mov	x3, #0x0                // =0
    13a8:      	mov	x4, #0x0                // =0
    13ac:      	bl	0x1280 <__libc_start_main@plt>
    13b0:      	bl	0x12f0 <abort@plt>

00000000000013b4 <call_weak_fn>:
    13b4:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1d09c>
    13b8:      	ldr	x0, [x0, #0xff0]
    13bc:      	cbz	x0, 0x13c4 <call_weak_fn+0x10>
    13c0:      	b	0x1340 <__gmon_start__@plt>
    13c4:      	ret
    13c8:      	nop
    13cc:      	nop

00000000000013d0 <deregister_tm_clones>:
    13d0:      	adrp	x0, 0x20000 <data_start>
    13d4:      	add	x0, x0, #0x780
    13d8:      	adrp	x1, 0x20000 <data_start>
    13dc:      	add	x1, x1, #0x780
    13e0:      	cmp	x1, x0
    13e4:      	b.eq	0x13fc <deregister_tm_clones+0x2c>
    13e8:      	adrp	x1, 0x1f000 <__FRAME_END__+0x1d09c>
    13ec:      	ldr	x1, [x1, #0xfe8]
    13f0:      	cbz	x1, 0x13fc <deregister_tm_clones+0x2c>
    13f4:      	mov	x16, x1
    13f8:      	br	x16
    13fc:      	ret

0000000000001400 <register_tm_clones>:
    1400:      	adrp	x0, 0x20000 <data_start>
    1404:      	add	x0, x0, #0x780
    1408:      	adrp	x1, 0x20000 <data_start>
    140c:      	add	x1, x1, #0x780
    1410:      	sub	x1, x1, x0
    1414:      	lsr	x2, x1, #63
    1418:      	add	x1, x2, x1, asr #3
    141c:      	asr	x1, x1, #1
    1420:      	cbz	x1, 0x1438 <register_tm_clones+0x38>
    1424:      	adrp	x2, 0x1f000 <__FRAME_END__+0x1d09c>
    1428:      	ldr	x2, [x2, #0xff8]
    142c:      	cbz	x2, 0x1438 <register_tm_clones+0x38>
    1430:      	mov	x16, x2
    1434:      	br	x16
    1438:      	ret
    143c:      	nop

0000000000001440 <__do_global_dtors_aux>:
    1440:      	paciasp
    1444:      	stp	x29, x30, [sp, #-0x20]!
    1448:      	mov	x29, sp
    144c:      	str	x19, [sp, #0x10]
    1450:      	adrp	x19, 0x20000 <data_start>
    1454:      	ldrb	w0, [x19, #0x780]
    1458:      	tbnz	w0, #0x0, 0x1480 <__do_global_dtors_aux+0x40>
    145c:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1d09c>
    1460:      	ldr	x0, [x0, #0xfd8]
    1464:      	cbz	x0, 0x1474 <__do_global_dtors_aux+0x34>
    1468:      	adrp	x0, 0x20000 <data_start>
    146c:      	ldr	x0, [x0, #0x8]
    1470:      	bl	0x1270 <__cxa_finalize@plt>
    1474:      	bl	0x13d0 <deregister_tm_clones>
    1478:      	mov	w0, #0x1                // =1
    147c:      	strb	w0, [x19, #0x780]
    1480:      	ldr	x19, [sp, #0x10]
    1484:      	ldp	x29, x30, [sp], #0x20
    1488:      	autiasp
    148c:      	ret

0000000000001490 <frame_dummy>:
    1490:      	bti	c
    1494:      	b	0x1400 <register_tm_clones>

0000000000001498 <kernel>:
    1498:      	mov	w2, #0x4                // =4
    149c:      	add	w0, w0, w1, uxtb
    14a0:      	add	w0, w0, w0, lsl #10
    14a4:      	eor	w0, w0, w0, lsr #6
    14a8:      	lsr	w1, w1, #8
    14ac:      	subs	w2, w2, #0x1
    14b0:      	b.ne	0x149c <kernel+0x4>
    14b4:      	add	w0, w0, w0, lsl #3
    14b8:      	eor	w0, w0, w0, lsr #11
    14bc:      	add	w0, w0, w0, lsl #15
    14c0:      	ret

00000000000014c4 <_sub_I_00099_0>:
    14c4:      	stp	x29, x30, [sp, #-0x10]!
    14c8:      	mov	x29, sp
    14cc:      	bl	0x12b0 <__asan_init@plt>
    14d0:      	bl	0x1310 <__asan_version_mismatch_check_v8@plt>
    14d4:      	ldp	x29, x30, [sp], #0x10
    14d8:      	ret

00000000000014dc <main>:
    14dc:      	sub	sp, sp, #0x130
    14e0:      	stp	x29, x30, [sp, #0xd0]
    14e4:      	add	x29, sp, #0xd0
    14e8:      	stp	x19, x20, [sp, #0xe0]
    14ec:      	stp	x21, x22, [sp, #0xf0]
    14f0:      	stp	x23, x24, [sp, #0x100]
    14f4:      	stp	x27, x28, [sp, #0x120]
    14f8:      	mov	w21, w0
    14fc:      	mov	x20, x1
    1500:      	add	x23, sp, #0x10
    1504:      	mov	x28, x23
    1508:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1d09c>
    150c:      	ldr	x0, [x0, #0xfe0]
    1510:      	ldr	w0, [x0]
    1514:      	cbnz	w0, 0x1820 <main+0x344>
    1518:      	mov	x19, x23
    151c:      	mov	x0, #0x8ab3             // =35507
    1520:      	movk	x0, #0x41b5, lsl #16
    1524:      	str	x0, [x19], #0xc0
    1528:      	adrp	x0, 0x1000 <strtoul@GLIBC_2.17+0x1000>
    152c:      	add	x0, x0, #0xae8
    1530:      	str	x0, [x23, #0x8]
    1534:      	adrp	x0, 0x1000 <strtoul@GLIBC_2.17+0x1000>
    1538:      	add	x0, x0, #0x4dc
    153c:      	str	x0, [x23, #0x10]
    1540:      	lsr	x24, x23, #3
    1544:      	mov	x0, #0x1000000000       // =68719476736
    1548:      	add	x1, x24, x0
    154c:      	mov	w2, #-0xe0e0e0f         // =-235802127
    1550:      	str	w2, [x24, x0]
    1554:      	add	w2, w2, #0x130, lsl #12 // =0x130000
    1558:      	str	w2, [x1, #0x4]
    155c:      	mov	w0, #-0xd0e0000         // =-219021312
    1560:      	str	w0, [x1, #0x8]
    1564:      	str	w0, [x1, #0xc]
    1568:      	mov	w0, #0xf300             // =62208
    156c:      	movk	w0, #0xf3f3, lsl #16
    1570:      	str	w0, [x1, #0x10]
    1574:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1d09c>
    1578:      	ldr	x0, [x0, #0xfc8]
    157c:      	ldr	x1, [x0]
    1580:      	str	x1, [sp, #0xc8]
    1584:      	mov	x1, #0x0                // =0
    1588:      	cmp	w21, #0x1
    158c:      	b.eq	0x1834 <main+0x358>
    1590:      	cmp	w21, #0x3
    1594:      	b.ne	0x19dc <main+0x500>
    1598:      	stp	x25, x26, [sp, #0x110]
    159c:      	add	x2, x20, #0x8
    15a0:      	cmn	x20, #0x8
    15a4:      	b.hs	0x18d8 <main+0x3fc>
    15a8:      	adds	x1, x20, #0x8
    15ac:      	b.eq	0x18e8 <main+0x40c>
    15b0:      	tst	x1, #0x7
    15b4:      	b.ne	0x18e8 <main+0x40c>
    15b8:      	add	x0, x20, #0x8
    15bc:      	lsr	x2, x0, #3
    15c0:      	mov	x1, #0x1000000000       // =68719476736
    15c4:      	ldrsb	w1, [x2, x1]
    15c8:      	cbnz	w1, 0x18f8 <main+0x41c>
    15cc:      	ldr	x0, [x20, #0x8]
    15d0:      	cbz	x0, 0x18fc <main+0x420>
    15d4:      	mov	w2, #0xa                // =10
    15d8:      	mov	x1, #0x0                // =0
    15dc:      	bl	0x12c0 <strtoul@plt>
    15e0:      	mov	x25, x0
    15e4:      	add	x2, x20, #0x10
    15e8:      	cmn	x20, #0x10
    15ec:      	b.hs	0x1910 <main+0x434>
    15f0:      	adds	x1, x20, #0x10
    15f4:      	b.eq	0x1924 <main+0x448>
    15f8:      	tst	x1, #0x7
    15fc:      	b.ne	0x1924 <main+0x448>
    1600:      	add	x0, x20, #0x10
    1604:      	lsr	x2, x0, #3
    1608:      	mov	x1, #0x1000000000       // =68719476736
    160c:      	ldrsb	w1, [x2, x1]
    1610:      	cbnz	w1, 0x1934 <main+0x458>
    1614:      	ldr	x0, [x20, #0x10]
    1618:      	cbz	x0, 0x1938 <main+0x45c>
    161c:      	mov	w2, #0xa                // =10
    1620:      	mov	x1, #0x0                // =0
    1624:      	bl	0x12c0 <strtoul@plt>
    1628:      	sub	x2, x19, #0x90
    162c:      	lsr	x3, x2, #3
    1630:      	mov	x1, #0x1000000000       // =68719476736
    1634:      	ldrsb	w1, [x3, x1]
    1638:      	cmp	w1, #0x0
    163c:      	mov	w3, #0x3                // =3
    1640:      	ccmp	w3, w1, #0x1, ne
    1644:      	b.ge	0x194c <main+0x470>
    1648:      	stur	w0, [x19, #-0x90]
    164c:      	sub	x1, x19, #0x80
    1650:      	mov	w0, #0x1                // =1
    1654:      	bl	0x12d0 <clock_gettime@plt>
    1658:      	cbnz	w0, 0x1a34 <main+0x558>
    165c:      	cbz	x25, 0x199c <main+0x4c0>
    1660:      	mov	x21, #0x0               // =0
    1664:      	mov	x22, #0x0               // =0
    1668:      	sub	x0, x19, #0x90
    166c:      	str	x0, [sp, #0x8]
    1670:      	lsr	x27, x0, #3
    1674:      	sub	x20, x19, #0x40
    1678:      	and	x26, x19, #0x7
    167c:      	add	w26, w26, #0x3
    1680:      	mov	x0, #0x1000000000       // =68719476736
    1684:      	ldrsb	w0, [x27, x0]
    1688:      	cmp	w0, #0x0
    168c:      	mov	w1, #0x3                // =3
    1690:      	ccmp	w1, w0, #0x1, ne
    1694:      	b.ge	0x1954 <main+0x478>
    1698:      	ldur	w0, [x19, #-0x90]
    169c:      	eor	w0, w0, w0, lsl #13
    16a0:      	eor	w0, w0, w0, lsr #17
    16a4:      	eor	w0, w0, w0, lsl #5
    16a8:      	stur	w0, [x19, #-0x90]
    16ac:      	lsr	x1, x20, #3
    16b0:      	mov	x2, #0x1000000000       // =68719476736
    16b4:      	ldrsb	w1, [x1, x2]
    16b8:      	cmp	w1, #0x0
    16bc:      	ccmp	w26, w1, #0x1, ne
    16c0:      	b.ge	0x195c <main+0x480>
    16c4:      	stur	w0, [x19, #-0x40]
    16c8:      	eor	w1, w0, w0, lsl #13
    16cc:      	eor	w1, w1, w1, lsr #17
    16d0:      	eor	w1, w1, w1, lsl #5
    16d4:      	stur	w1, [x19, #-0x90]
    16d8:      	sub	x2, x19, #0x38
    16dc:      	sub	x2, x2, x20
    16e0:      	cmp	x2, #0x8
    16e4:      	b.hi	0x1964 <main+0x488>
    16e8:      	sub	x3, x19, #0x3c
    16ec:      	lsr	x4, x3, #3
    16f0:      	mov	x2, #0x1000000000       // =68719476736
    16f4:      	ldrsb	w4, [x4, x2]
    16f8:      	and	x2, x3, #0x7
    16fc:      	add	w2, w2, #0x3
    1700:      	cmp	w4, #0x0
    1704:      	ccmp	w2, w4, #0x1, ne
    1708:      	b.ge	0x1984 <main+0x4a8>
    170c:      	stur	w1, [x19, #-0x3c]
    1710:      	lsr	x2, x20, #3
    1714:      	mov	x3, #0x1000000000       // =68719476736
    1718:      	ldrsb	w2, [x2, x3]
    171c:      	cmp	w2, #0x0
    1720:      	mov	w3, #0x3                // =3
    1724:      	ccmp	w3, w2, #0x1, ne
    1728:      	b.ge	0x198c <main+0x4b0>
    172c:      	sub	x3, x19, #0x3c
    1730:      	lsr	x4, x3, #3
    1734:      	mov	x2, #0x1000000000       // =68719476736
    1738:      	ldrsb	w4, [x4, x2]
    173c:      	and	x2, x3, #0x7
    1740:      	add	w2, w2, #0x3
    1744:      	cmp	w4, #0x0
    1748:      	ccmp	w2, w4, #0x1, ne
    174c:      	b.ge	0x1994 <main+0x4b8>
    1750:      	bl	0x1498 <kernel>
    1754:      	add	x22, x22, w0, uxtw
    1758:      	add	x21, x21, #0x1
    175c:      	cmp	x25, x21
    1760:      	b.ne	0x1680 <main+0x1a4>
    1764:      	sub	x1, x19, #0x60
    1768:      	mov	w0, #0x1                // =1
    176c:      	bl	0x12d0 <clock_gettime@plt>
    1770:      	mov	w20, w0
    1774:      	cbnz	w0, 0x1a40 <main+0x564>
    1778:      	sub	x0, x19, #0x60
    177c:      	lsr	x2, x0, #3
    1780:      	mov	x1, #0x1000000000       // =68719476736
    1784:      	ldrsb	w1, [x2, x1]
    1788:      	cbnz	w1, 0x19a4 <main+0x4c8>
    178c:      	ldur	x1, [x19, #-0x60]
    1790:      	sub	x0, x19, #0x80
    1794:      	lsr	x3, x0, #3
    1798:      	mov	x2, #0x1000000000       // =68719476736
    179c:      	ldrsb	w2, [x3, x2]
    17a0:      	cbnz	w2, 0x19a8 <main+0x4cc>
    17a4:      	ldur	x0, [x19, #-0x80]
    17a8:      	subs	x0, x1, x0
    17ac:      	b.vs	0x19ac <main+0x4d0>
    17b0:      	scvtf	d1, x0
    17b4:      	sub	x0, x19, #0x58
    17b8:      	lsr	x2, x0, #3
    17bc:      	mov	x1, #0x1000000000       // =68719476736
    17c0:      	ldrsb	w1, [x2, x1]
    17c4:      	cbnz	w1, 0x19c0 <main+0x4e4>
    17c8:      	ldur	x1, [x19, #-0x58]
    17cc:      	sub	x0, x19, #0x78
    17d0:      	lsr	x3, x0, #3
    17d4:      	mov	x2, #0x1000000000       // =68719476736
    17d8:      	ldrsb	w2, [x3, x2]
    17dc:      	cbnz	w2, 0x19c4 <main+0x4e8>
    17e0:      	ldur	x0, [x19, #-0x78]
    17e4:      	subs	x0, x1, x0
    17e8:      	b.vs	0x19c8 <main+0x4ec>
    17ec:      	scvtf	d0, x0
    17f0:      	adrp	x0, 0x1000 <strtoul@GLIBC_2.17+0x1000>
    17f4:      	ldr	d2, [x0, #0xc10]
    17f8:      	fmul	d0, d0, d2
    17fc:      	mov	x2, x22
    1800:      	fadd	d0, d0, d1
    1804:      	adrp	x1, 0x1000 <strtoul@GLIBC_2.17+0x1000>
    1808:      	add	x1, x1, #0xc20
    180c:      	add	x1, x1, #0x80
    1810:      	mov	w0, #0x2                // =2
    1814:      	bl	0x1330 <__printf_chk@plt>
    1818:      	ldp	x25, x26, [sp, #0x110]
    181c:      	b	0x19e0 <main+0x504>
    1820:      	mov	x0, #0xa0               // =160
    1824:      	bl	0x1300 <__asan_stack_malloc_2@plt>
    1828:      	cmp	x0, #0x0
    182c:      	csel	x23, x23, x0, eq
    1830:      	b	0x1518 <main+0x3c>
    1834:      	stp	x25, x26, [sp, #0x110]
    1838:      	sub	x20, x19, #0x3c
    183c:      	adrp	x21, 0x1000 <strtoul@GLIBC_2.17+0x1000>
    1840:      	add	x21, x21, #0xc20
    1844:      	add	x25, x21, #0x40
    1848:      	and	x22, x20, #0x7
    184c:      	add	w22, w22, #0x3
    1850:      	b	0x1870 <main+0x394>
    1854:      	bl	0x1260 <__asan_report_load4@plt>
    1858:      	ldur	w1, [x19, #-0x3c]
    185c:      	bl	0x1498 <kernel>
    1860:      	mov	w2, w0
    1864:      	mov	x1, x21
    1868:      	mov	w0, #0x2                // =2
    186c:      	bl	0x1330 <__printf_chk@plt>
    1870:      	mov	x2, x20
    1874:      	sub	x1, x19, #0x40
    1878:      	mov	x0, x25
    187c:      	bl	0x1320 <__isoc99_scanf@plt>
    1880:      	cmp	w0, #0x2
    1884:      	b.ne	0x18cc <main+0x3f0>
    1888:      	sub	x0, x19, #0x40
    188c:      	lsr	x2, x0, #3
    1890:      	mov	x1, #0x1000000000       // =68719476736
    1894:      	ldrsb	w1, [x2, x1]
    1898:      	cmp	w1, #0x0
    189c:      	mov	w2, #0x3                // =3
    18a0:      	ccmp	w2, w1, #0x1, ne
    18a4:      	b.ge	0x1854 <main+0x378>
    18a8:      	ldur	w0, [x19, #-0x40]
    18ac:      	lsr	x1, x20, #3
    18b0:      	mov	x2, #0x1000000000       // =68719476736
    18b4:      	ldrsb	w1, [x1, x2]
    18b8:      	cmp	w1, #0x0
    18bc:      	ccmp	w22, w1, #0x1, ne
    18c0:      	b.lt	0x1858 <main+0x37c>
    18c4:      	mov	x0, x20
    18c8:      	bl	0x1260 <__asan_report_load4@plt>
    18cc:      	mov	w20, #0x0               // =0
    18d0:      	ldp	x25, x26, [sp, #0x110]
    18d4:      	b	0x19e0 <main+0x504>
    18d8:      	mov	x1, x20
    18dc:      	adrp	x0, 0x20000 <data_start>
    18e0:      	add	x0, x0, #0xe0
    18e4:      	bl	0x1350 <__ubsan_handle_pointer_overflow_abort@plt>
    18e8:      	adrp	x0, 0x20000 <data_start>
    18ec:      	add	x0, x0, #0xe0
    18f0:      	add	x0, x0, #0x40
    18f4:      	bl	0x1210 <__ubsan_handle_type_mismatch_v1_abort@plt>
    18f8:      	bl	0x12e0 <__asan_report_load8@plt>
    18fc:      	bl	0x12a0 <__asan_handle_no_return@plt>
    1900:      	adrp	x0, 0x20000 <data_start>
    1904:      	add	x0, x0, #0xe0
    1908:      	add	x0, x0, #0x80
    190c:      	bl	0x1240 <__ubsan_handle_nonnull_arg_abort@plt>
    1910:      	mov	x1, x20
    1914:      	adrp	x0, 0x20000 <data_start>
    1918:      	add	x0, x0, #0xe0
    191c:      	add	x0, x0, #0xe0
    1920:      	bl	0x1350 <__ubsan_handle_pointer_overflow_abort@plt>
    1924:      	adrp	x0, 0x20000 <data_start>
    1928:      	add	x0, x0, #0xe0
    192c:      	add	x0, x0, #0x120
    1930:      	bl	0x1210 <__ubsan_handle_type_mismatch_v1_abort@plt>
    1934:      	bl	0x12e0 <__asan_report_load8@plt>
    1938:      	bl	0x12a0 <__asan_handle_no_return@plt>
    193c:      	adrp	x0, 0x20000 <data_start>
    1940:      	add	x0, x0, #0xe0
    1944:      	add	x0, x0, #0x160
    1948:      	bl	0x1240 <__ubsan_handle_nonnull_arg_abort@plt>
    194c:      	mov	x0, x2
    1950:      	bl	0x1200 <__asan_report_store4@plt>
    1954:      	ldr	x0, [sp, #0x8]
    1958:      	bl	0x1260 <__asan_report_load4@plt>
    195c:      	mov	x0, x20
    1960:      	bl	0x1200 <__asan_report_store4@plt>
    1964:      	sub	x3, x19, #0x3c
    1968:      	cmn	x3, x2
    196c:      	b.hs	0x16e8 <main+0x20c>
    1970:      	mov	x1, x3
    1974:      	adrp	x0, 0x20000 <data_start>
    1978:      	add	x0, x0, #0xe0
    197c:      	add	x0, x0, #0x1c0
    1980:      	bl	0x1210 <__ubsan_handle_type_mismatch_v1_abort@plt>
    1984:      	mov	x0, x3
    1988:      	bl	0x1200 <__asan_report_store4@plt>
    198c:      	mov	x0, x20
    1990:      	bl	0x1260 <__asan_report_load4@plt>
    1994:      	mov	x0, x3
    1998:      	bl	0x1260 <__asan_report_load4@plt>
    199c:      	mov	x22, x25
    19a0:      	b	0x1764 <main+0x288>
    19a4:      	bl	0x12e0 <__asan_report_load8@plt>
    19a8:      	bl	0x12e0 <__asan_report_load8@plt>
    19ac:      	ldur	x2, [x19, #-0x80]
    19b0:      	adrp	x0, 0x20000 <data_start>
    19b4:      	add	x0, x0, #0xe0
    19b8:      	add	x0, x0, #0x200
    19bc:      	bl	0x1250 <__ubsan_handle_sub_overflow_abort@plt>
    19c0:      	bl	0x12e0 <__asan_report_load8@plt>
    19c4:      	bl	0x12e0 <__asan_report_load8@plt>
    19c8:      	ldur	x2, [x19, #-0x78]
    19cc:      	adrp	x0, 0x20000 <data_start>
    19d0:      	add	x0, x0, #0xe0
    19d4:      	add	x0, x0, #0x240
    19d8:      	bl	0x1250 <__ubsan_handle_sub_overflow_abort@plt>
    19dc:      	mov	w20, #0x3               // =3
    19e0:      	cmp	x28, x23
    19e4:      	b.ne	0x1a4c <main+0x570>
    19e8:      	mov	x0, #0x1000000000       // =68719476736
    19ec:      	add	x24, x24, x0
    19f0:      	stp	xzr, xzr, [x24]
    19f4:      	str	wzr, [x24, #0x10]
    19f8:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1d09c>
    19fc:      	ldr	x0, [x0, #0xfc8]
    1a00:      	ldr	x2, [sp, #0xc8]
    1a04:      	ldr	x1, [x0]
    1a08:      	subs	x2, x2, x1
    1a0c:      	mov	x1, #0x0                // =0
    1a10:      	b.ne	0x1a70 <main+0x594>
    1a14:      	mov	w0, w20
    1a18:      	ldp	x19, x20, [sp, #0xe0]
    1a1c:      	ldp	x21, x22, [sp, #0xf0]
    1a20:      	ldp	x23, x24, [sp, #0x100]
    1a24:      	ldp	x27, x28, [sp, #0x120]
    1a28:      	ldp	x29, x30, [sp, #0xd0]
    1a2c:      	add	sp, sp, #0x130
    1a30:      	ret
    1a34:      	mov	w20, #0x2               // =2
    1a38:      	ldp	x25, x26, [sp, #0x110]
    1a3c:      	b	0x19e0 <main+0x504>
    1a40:      	mov	w20, #0x2               // =2
    1a44:      	ldp	x25, x26, [sp, #0x110]
    1a48:      	b	0x19e0 <main+0x504>
    1a4c:      	mov	x0, #0x360e             // =13838
    1a50:      	movk	x0, #0x45e0, lsl #16
    1a54:      	str	x0, [x23]
    1a58:      	mov	x0, #0x1000000000       // =68719476736
    1a5c:      	add	x1, x24, x0
    1a60:      	movi	v0.16b, #0xf5
    1a64:      	str	q0, [x24, x0]
    1a68:      	str	s0, [x1, #0x10]
    1a6c:      	b	0x19f8 <main+0x51c>
    1a70:      	stp	x25, x26, [sp, #0x110]
    1a74:      	bl	0x1230 <__stack_chk_fail@plt>

0000000000001a78 <_sub_D_00099_0>:
    1a78:      	stp	x29, x30, [sp, #-0x10]!
    1a7c:      	mov	x29, sp
    1a80:      	mov	x1, #0x10               // =16
    1a84:      	adrp	x0, 0x20000 <data_start>
    1a88:      	add	x0, x0, #0xe0
    1a8c:      	add	x0, x0, #0x280
    1a90:      	bl	0x1290 <__asan_unregister_globals@plt>
    1a94:      	ldp	x29, x30, [sp], #0x10
    1a98:      	ret

0000000000001a9c <_sub_I_00099_1>:
    1a9c:      	stp	x29, x30, [sp, #-0x10]!
    1aa0:      	mov	x29, sp
    1aa4:      	bl	0x12b0 <__asan_init@plt>
    1aa8:      	bl	0x1310 <__asan_version_mismatch_check_v8@plt>
    1aac:      	mov	x1, #0x10               // =16
    1ab0:      	adrp	x0, 0x20000 <data_start>
    1ab4:      	add	x0, x0, #0xe0
    1ab8:      	add	x0, x0, #0x280
    1abc:      	bl	0x1220 <__asan_register_globals@plt>
    1ac0:      	ldp	x29, x30, [sp], #0x10
    1ac4:      	ret

Disassembly of section .fini:

0000000000001ac8 <_fini>:
    1ac8:      	nop
    1acc:      	stp	x29, x30, [sp, #-0x10]!
    1ad0:      	mov	x29, sp
    1ad4:      	ldp	x29, x30, [sp], #0x10
    1ad8:      	ret
