
/work/experiments/runs/jenkins-composition-matrix-linux-20261110/jenkins_word/build-clang-O2-pgo-limbs16/program:	file format elf64-littleaarch64

Disassembly of section .init:

0000000000000678 <_init>:
     678:      	nop
     67c:      	stp	x29, x30, [sp, #-0x10]!
     680:      	mov	x29, sp
     684:      	bl	0x8b4 <call_weak_fn>
     688:      	ldp	x29, x30, [sp], #0x10
     68c:      	ret

Disassembly of section .plt:

0000000000000690 <.plt>:
     690:      	stp	x16, x30, [sp, #-0x10]!
     694:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e39c>
     698:      	ldr	x17, [x16, #0xff8]
     69c:      	add	x16, x16, #0xff8
     6a0:      	br	x17
     6a4:      	nop
     6a8:      	nop
     6ac:      	nop

00000000000006b0 <strtoul@plt>:
     6b0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6b4:      	ldr	x17, [x16]
     6b8:      	add	x16, x16, #0x0
     6bc:      	br	x17

00000000000006c0 <__libc_start_main@plt>:
     6c0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6c4:      	ldr	x17, [x16, #0x8]
     6c8:      	add	x16, x16, #0x8
     6cc:      	br	x17

00000000000006d0 <__cxa_finalize@plt>:
     6d0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6d4:      	ldr	x17, [x16, #0x10]
     6d8:      	add	x16, x16, #0x10
     6dc:      	br	x17

00000000000006e0 <clock_gettime@plt>:
     6e0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6e4:      	ldr	x17, [x16, #0x18]
     6e8:      	add	x16, x16, #0x18
     6ec:      	br	x17

00000000000006f0 <__gmon_start__@plt>:
     6f0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6f4:      	ldr	x17, [x16, #0x20]
     6f8:      	add	x16, x16, #0x20
     6fc:      	br	x17

0000000000000700 <abort@plt>:
     700:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     704:      	ldr	x17, [x16, #0x28]
     708:      	add	x16, x16, #0x28
     70c:      	br	x17

0000000000000710 <__isoc99_scanf@plt>:
     710:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     714:      	ldr	x17, [x16, #0x30]
     718:      	add	x16, x16, #0x30
     71c:      	br	x17

0000000000000720 <printf@plt>:
     720:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     724:      	ldr	x17, [x16, #0x38]
     728:      	add	x16, x16, #0x38
     72c:      	br	x17

Disassembly of section .text:

0000000000000740 <kernel>:
     740:      	and	w8, w1, #0xff
     744:      	add	w8, w8, w0, uxth
     748:      	lsr	w9, w8, #16
     74c:      	and	w10, w8, #0xffff
     750:      	ubfiz	w8, w8, #10, #6
     754:      	add	w9, w9, w0, lsr #16
     758:      	add	w8, w8, w10
     75c:      	add	w11, w9, w10, lsr #6
     760:      	ubfx	w10, w8, #6, #10
     764:      	add	w9, w11, w9, lsl #10
     768:      	lsr	w11, w1, #8
     76c:      	add	w9, w9, w8, lsr #16
     770:      	and	w8, w8, #0xffff
     774:      	bfi	w10, w9, #10, #6
     778:      	and	w12, w9, #0xffc0
     77c:      	eor	w9, w9, w12, lsr #6
     780:      	eor	w8, w10, w8
     784:      	add	w8, w8, w11, uxtb
     788:      	add	w9, w9, w8, lsr #16
     78c:      	and	w10, w8, #0xffff
     790:      	ubfiz	w8, w8, #10, #6
     794:      	add	w11, w9, w10, lsr #6
     798:      	add	w8, w8, w10
     79c:      	ubfx	w10, w8, #6, #10
     7a0:      	add	w9, w11, w9, lsl #10
     7a4:      	lsr	w11, w1, #16
     7a8:      	add	w9, w9, w8, lsr #16
     7ac:      	and	w8, w8, #0xffff
     7b0:      	bfi	w10, w9, #10, #6
     7b4:      	and	w12, w9, #0xffc0
     7b8:      	eor	w9, w9, w12, lsr #6
     7bc:      	eor	w8, w10, w8
     7c0:      	add	w8, w8, w11, uxtb
     7c4:      	add	w9, w9, w8, lsr #16
     7c8:      	and	w10, w8, #0xffff
     7cc:      	ubfiz	w8, w8, #10, #6
     7d0:      	add	w11, w9, w10, lsr #6
     7d4:      	add	w8, w8, w10
     7d8:      	ubfx	w10, w8, #6, #10
     7dc:      	add	w9, w11, w9, lsl #10
     7e0:      	add	w9, w9, w8, lsr #16
     7e4:      	and	w8, w8, #0xffff
     7e8:      	bfi	w10, w9, #10, #6
     7ec:      	and	w11, w9, #0xffc0
     7f0:      	eor	w9, w9, w11, lsr #6
     7f4:      	eor	w8, w10, w8
     7f8:      	add	w8, w8, w1, lsr #24
     7fc:      	add	w9, w9, w8, lsr #16
     800:      	and	w10, w8, #0xffff
     804:      	ubfiz	w8, w8, #10, #6
     808:      	add	w11, w9, w10, lsr #6
     80c:      	add	w8, w8, w10
     810:      	ubfx	w10, w8, #6, #10
     814:      	add	w9, w11, w9, lsl #10
     818:      	add	w9, w9, w8, lsr #16
     81c:      	and	w8, w8, #0xffff
     820:      	and	w11, w9, #0xffc0
     824:      	bfi	w10, w9, #10, #6
     828:      	eor	w9, w9, w11, lsr #6
     82c:      	eor	w8, w10, w8
     830:      	add	w9, w9, w9, lsl #3
     834:      	ubfiz	w10, w8, #3, #13
     838:      	add	w9, w9, w8, lsr #13
     83c:      	add	w8, w10, w8
     840:      	ubfx	w10, w8, #11, #5
     844:      	add	w9, w9, w8, lsr #16
     848:      	and	w8, w8, #0xffff
     84c:      	and	w11, w9, #0xf800
     850:      	bfi	w10, w9, #5, #11
     854:      	eor	w9, w9, w11, lsr #11
     858:      	eor	w8, w10, w8
     85c:      	add	w9, w9, w9, lsl #15
     860:      	ubfiz	w10, w8, #15, #1
     864:      	add	w9, w9, w8, lsr #1
     868:      	add	w8, w10, w8
     86c:      	add	w0, w8, w9, lsl #16
     870:      	ret
     874:      	nop
     878:      	nop
     87c:      	nop

0000000000000880 <_start>:
     880:      	nop
     884:      	mov	x29, #0x0               // =0
     888:      	mov	x30, #0x0               // =0
     88c:      	mov	x5, x0
     890:      	ldr	x1, [sp]
     894:      	add	x2, sp, #0x8
     898:      	mov	x6, sp
     89c:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e39c>
     8a0:      	ldr	x0, [x0, #0xfd8]
     8a4:      	mov	x3, #0x0                // =0
     8a8:      	mov	x4, #0x0                // =0
     8ac:      	bl	0x6c0 <__libc_start_main@plt>
     8b0:      	bl	0x700 <abort@plt>

00000000000008b4 <call_weak_fn>:
     8b4:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e39c>
     8b8:      	ldr	x0, [x0, #0xfd0]
     8bc:      	cbz	x0, 0x8c4 <call_weak_fn+0x10>
     8c0:      	b	0x6f0 <__gmon_start__@plt>
     8c4:      	ret
     8c8:      	nop
     8cc:      	nop

00000000000008d0 <deregister_tm_clones>:
     8d0:      	adrp	x0, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     8d4:      	add	x0, x0, #0x50
     8d8:      	adrp	x1, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     8dc:      	add	x1, x1, #0x50
     8e0:      	cmp	x1, x0
     8e4:      	b.eq	0x8fc <deregister_tm_clones+0x2c>
     8e8:      	adrp	x1, 0x1f000 <__FRAME_END__+0x1e39c>
     8ec:      	ldr	x1, [x1, #0xfc0]
     8f0:      	cbz	x1, 0x8fc <deregister_tm_clones+0x2c>
     8f4:      	mov	x16, x1
     8f8:      	br	x16
     8fc:      	ret

0000000000000900 <register_tm_clones>:
     900:      	adrp	x0, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     904:      	add	x0, x0, #0x50
     908:      	adrp	x1, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     90c:      	add	x1, x1, #0x50
     910:      	sub	x1, x1, x0
     914:      	lsr	x2, x1, #63
     918:      	add	x1, x2, x1, asr #3
     91c:      	asr	x1, x1, #1
     920:      	cbz	x1, 0x938 <register_tm_clones+0x38>
     924:      	adrp	x2, 0x1f000 <__FRAME_END__+0x1e39c>
     928:      	ldr	x2, [x2, #0xfe0]
     92c:      	cbz	x2, 0x938 <register_tm_clones+0x38>
     930:      	mov	x16, x2
     934:      	br	x16
     938:      	ret
     93c:      	nop

0000000000000940 <__do_global_dtors_aux>:
     940:      	paciasp
     944:      	stp	x29, x30, [sp, #-0x20]!
     948:      	mov	x29, sp
     94c:      	str	x19, [sp, #0x10]
     950:      	adrp	x19, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     954:      	ldrb	w0, [x19, #0x50]
     958:      	tbnz	w0, #0x0, 0x980 <__do_global_dtors_aux+0x40>
     95c:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e39c>
     960:      	ldr	x0, [x0, #0xfc8]
     964:      	cbz	x0, 0x974 <__do_global_dtors_aux+0x34>
     968:      	adrp	x0, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     96c:      	ldr	x0, [x0, #0x48]
     970:      	bl	0x6d0 <__cxa_finalize@plt>
     974:      	bl	0x8d0 <deregister_tm_clones>
     978:      	mov	w0, #0x1                // =1
     97c:      	strb	w0, [x19, #0x50]
     980:      	ldr	x19, [sp, #0x10]
     984:      	ldp	x29, x30, [sp], #0x20
     988:      	autiasp
     98c:      	ret

0000000000000990 <frame_dummy>:
     990:      	bti	c
     994:      	b	0x900 <register_tm_clones>

0000000000000998 <main>:
     998:      	sub	sp, sp, #0x50
     99c:      	stp	x29, x30, [sp, #0x20]
     9a0:      	str	x21, [sp, #0x30]
     9a4:      	stp	x20, x19, [sp, #0x40]
     9a8:      	add	x29, sp, #0x20
     9ac:      	cmp	w0, #0x1
     9b0:      	b.ne	0xa28 <main+0x90>
     9b4:      	add	x21, sp, #0x10
     9b8:      	adrp	x0, 0x0 <strtoul@GLIBC_2.17>
     9bc:      	add	x0, x0, #0xb20
     9c0:      	add	x1, sp, #0x10
     9c4:      	add	x2, x21, #0x4
     9c8:      	bl	0x710 <__isoc99_scanf@plt>
     9cc:      	cmp	w0, #0x2
     9d0:      	b.ne	0xa10 <main+0x78>
     9d4:      	adrp	x19, 0x0 <strtoul@GLIBC_2.17>
     9d8:      	add	x19, x19, #0xb25
     9dc:      	adrp	x20, 0x0 <strtoul@GLIBC_2.17>
     9e0:      	add	x20, x20, #0xb20
     9e4:      	ldp	w0, w1, [sp, #0x10]
     9e8:      	bl	0x740 <kernel>
     9ec:      	mov	w1, w0
     9f0:      	mov	x0, x19
     9f4:      	bl	0x720 <printf@plt>
     9f8:      	add	x1, sp, #0x10
     9fc:      	add	x2, x21, #0x4
     a00:      	mov	x0, x20
     a04:      	bl	0x710 <__isoc99_scanf@plt>
     a08:      	cmp	w0, #0x2
     a0c:      	b.eq	0x9e4 <main+0x4c>
     a10:      	mov	w0, wzr
     a14:      	ldp	x20, x19, [sp, #0x40]
     a18:      	ldr	x21, [sp, #0x30]
     a1c:      	ldp	x29, x30, [sp, #0x20]
     a20:      	add	sp, sp, #0x50
     a24:      	ret
     a28:      	cmp	w0, #0x3
     a2c:      	b.ne	0xa78 <main+0xe0>
     a30:      	ldr	x0, [x1, #0x8]
     a34:      	mov	x19, x1
     a38:      	mov	x1, xzr
     a3c:      	mov	w2, #0xa                // =10
     a40:      	bl	0x6b0 <strtoul@plt>
     a44:      	ldr	x8, [x19, #0x10]
     a48:      	mov	x20, x0
     a4c:      	mov	x1, xzr
     a50:      	mov	w2, #0xa                // =10
     a54:      	mov	x0, x8
     a58:      	bl	0x6b0 <strtoul@plt>
     a5c:      	mov	x21, x0
     a60:      	add	x1, sp, #0x10
     a64:      	mov	w0, #0x1                // =1
     a68:      	bl	0x6e0 <clock_gettime@plt>
     a6c:      	cbz	w0, 0xa80 <main+0xe8>
     a70:      	mov	w0, #0x2                // =2
     a74:      	b	0xa14 <main+0x7c>
     a78:      	mov	w0, #0x3                // =3
     a7c:      	b	0xa14 <main+0x7c>
     a80:      	mov	x19, xzr
     a84:      	cbz	x20, 0xab4 <main+0x11c>
     a88:      	eor	w8, w21, w21, lsl #13
     a8c:      	eor	w8, w8, w8, lsr #17
     a90:      	eor	w0, w8, w8, lsl #5
     a94:      	eor	w8, w0, w0, lsl #13
     a98:      	eor	w8, w8, w8, lsr #17
     a9c:      	eor	w21, w8, w8, lsl #5
     aa0:      	mov	w1, w21
     aa4:      	bl	0x740 <kernel>
     aa8:      	add	x19, x19, w0, uxtw
     aac:      	subs	x20, x20, #0x1
     ab0:      	b.ne	0xa88 <main+0xf0>
     ab4:      	mov	x1, sp
     ab8:      	mov	w0, #0x1                // =1
     abc:      	bl	0x6e0 <clock_gettime@plt>
     ac0:      	cbnz	w0, 0xa70 <main+0xd8>
     ac4:      	ldp	x8, x9, [sp]
     ac8:      	adrp	x0, 0x0 <strtoul@GLIBC_2.17>
     acc:      	add	x0, x0, #0xb29
     ad0:      	ldp	x10, x11, [sp, #0x10]
     ad4:      	mov	x1, x19
     ad8:      	sub	x8, x8, x10
     adc:      	sub	x9, x9, x11
     ae0:      	scvtf	d0, x8
     ae4:      	scvtf	d1, x9
     ae8:      	adrp	x8, 0x0 <strtoul@GLIBC_2.17>
     aec:      	ldr	d2, [x8, #0xb18]
     af0:      	fmadd	d0, d1, d2, d0
     af4:      	bl	0x720 <printf@plt>
     af8:      	b	0xa10 <main+0x78>

Disassembly of section .fini:

0000000000000afc <_fini>:
     afc:      	nop
     b00:      	stp	x29, x30, [sp, #-0x10]!
     b04:      	mov	x29, sp
     b08:      	ldp	x29, x30, [sp], #0x10
     b0c:      	ret
