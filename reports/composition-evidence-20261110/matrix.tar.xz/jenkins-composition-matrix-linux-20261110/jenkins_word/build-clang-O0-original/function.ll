; ModuleID = '/work/experiments/runs/jenkins-composition-matrix-linux-20261110/jenkins_word/build-clang-O0-original/validation/compiler-0-O0/candidate.i'
source_filename = "/work/experiments/runs/jenkins-composition-matrix-linux-20261110/jenkins_word/build-clang-O0-original/validation/compiler-0-O0/candidate.i"
target datalayout = "e-m:e-i8:8:32-i16:16:32-i64:64-i128:128-n32:64-S128"
target triple = "aarch64-unknown-linux-gnu"

; Function Attrs: noinline nounwind optnone uwtable
define dso_local i32 @kernel(i32 noundef %0, i32 noundef %1) #0 {
  %3 = alloca i32, align 4
  %4 = alloca i32, align 4
  %5 = alloca i32, align 4
  %6 = alloca i32, align 4
  %7 = alloca i32, align 4
  store i32 %0, ptr %3, align 4
  store i32 %1, ptr %4, align 4
  %8 = load i32, ptr %3, align 4
  store i32 %8, ptr %5, align 4
  %9 = load i32, ptr %4, align 4
  store i32 %9, ptr %6, align 4
  store i32 0, ptr %7, align 4
  br label %10

10:                                               ; preds = %28, %2
  %11 = load i32, ptr %7, align 4
  %12 = icmp ult i32 %11, 4
  br i1 %12, label %13, label %31

13:                                               ; preds = %10
  %14 = load i32, ptr %5, align 4
  %15 = load i32, ptr %6, align 4
  %16 = and i32 %15, 255
  %17 = add i32 %14, %16
  store i32 %17, ptr %5, align 4
  %18 = load i32, ptr %5, align 4
  %19 = load i32, ptr %5, align 4
  %20 = shl i32 %19, 10
  %21 = add i32 %18, %20
  store i32 %21, ptr %5, align 4
  %22 = load i32, ptr %5, align 4
  %23 = load i32, ptr %5, align 4
  %24 = lshr i32 %23, 6
  %25 = xor i32 %22, %24
  store i32 %25, ptr %5, align 4
  %26 = load i32, ptr %6, align 4
  %27 = lshr i32 %26, 8
  store i32 %27, ptr %6, align 4
  br label %28

28:                                               ; preds = %13
  %29 = load i32, ptr %7, align 4
  %30 = add i32 %29, 1
  store i32 %30, ptr %7, align 4
  br label %10, !llvm.loop !6

31:                                               ; preds = %10
  %32 = load i32, ptr %5, align 4
  %33 = load i32, ptr %5, align 4
  %34 = shl i32 %33, 3
  %35 = add i32 %32, %34
  store i32 %35, ptr %5, align 4
  %36 = load i32, ptr %5, align 4
  %37 = load i32, ptr %5, align 4
  %38 = lshr i32 %37, 11
  %39 = xor i32 %36, %38
  store i32 %39, ptr %5, align 4
  %40 = load i32, ptr %5, align 4
  %41 = load i32, ptr %5, align 4
  %42 = shl i32 %41, 15
  %43 = add i32 %40, %42
  store i32 %43, ptr %5, align 4
  %44 = load i32, ptr %5, align 4
  ret i32 %44
}

attributes #0 = { noinline nounwind optnone uwtable "frame-pointer"="non-leaf" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+fp-armv8,+neon,+outline-atomics,+v8a,-fmv" }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 1, !"wchar_size", i32 4}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 1}
!5 = !{!"Ubuntu clang version 18.1.3 (1ubuntu1)"}
!6 = distinct !{!6, !7}
!7 = !{!"llvm.loop.mustprogress"}
