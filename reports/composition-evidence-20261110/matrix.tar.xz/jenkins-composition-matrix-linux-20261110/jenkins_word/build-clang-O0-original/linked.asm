
/work/experiments/runs/jenkins-composition-matrix-linux-20261110/jenkins_word/build-clang-O0-original/program:	file format elf64-littleaarch64

Disassembly of section .init:

0000000000000678 <_init>:
     678:      	nop
     67c:      	stp	x29, x30, [sp, #-0x10]!
     680:      	mov	x29, sp
     684:      	bl	0x774 <call_weak_fn>
     688:      	ldp	x29, x30, [sp], #0x10
     68c:      	ret

Disassembly of section .plt:

0000000000000690 <.plt>:
     690:      	stp	x16, x30, [sp, #-0x10]!
     694:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e304>
     698:      	ldr	x17, [x16, #0xff8]
     69c:      	add	x16, x16, #0xff8
     6a0:      	br	x17
     6a4:      	nop
     6a8:      	nop
     6ac:      	nop

00000000000006b0 <strtoul@plt>:
     6b0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6b4:      	ldr	x17, [x16]
     6b8:      	add	x16, x16, #0x0
     6bc:      	br	x17

00000000000006c0 <__libc_start_main@plt>:
     6c0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6c4:      	ldr	x17, [x16, #0x8]
     6c8:      	add	x16, x16, #0x8
     6cc:      	br	x17

00000000000006d0 <__cxa_finalize@plt>:
     6d0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6d4:      	ldr	x17, [x16, #0x10]
     6d8:      	add	x16, x16, #0x10
     6dc:      	br	x17

00000000000006e0 <clock_gettime@plt>:
     6e0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6e4:      	ldr	x17, [x16, #0x18]
     6e8:      	add	x16, x16, #0x18
     6ec:      	br	x17

00000000000006f0 <__gmon_start__@plt>:
     6f0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6f4:      	ldr	x17, [x16, #0x20]
     6f8:      	add	x16, x16, #0x20
     6fc:      	br	x17

0000000000000700 <abort@plt>:
     700:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     704:      	ldr	x17, [x16, #0x28]
     708:      	add	x16, x16, #0x28
     70c:      	br	x17

0000000000000710 <__isoc99_scanf@plt>:
     710:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     714:      	ldr	x17, [x16, #0x30]
     718:      	add	x16, x16, #0x30
     71c:      	br	x17

0000000000000720 <printf@plt>:
     720:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     724:      	ldr	x17, [x16, #0x38]
     728:      	add	x16, x16, #0x38
     72c:      	br	x17

Disassembly of section .text:

0000000000000740 <_start>:
     740:      	nop
     744:      	mov	x29, #0x0               // =0
     748:      	mov	x30, #0x0               // =0
     74c:      	mov	x5, x0
     750:      	ldr	x1, [sp]
     754:      	add	x2, sp, #0x8
     758:      	mov	x6, sp
     75c:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e304>
     760:      	ldr	x0, [x0, #0xfd8]
     764:      	mov	x3, #0x0                // =0
     768:      	mov	x4, #0x0                // =0
     76c:      	bl	0x6c0 <__libc_start_main@plt>
     770:      	bl	0x700 <abort@plt>

0000000000000774 <call_weak_fn>:
     774:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e304>
     778:      	ldr	x0, [x0, #0xfd0]
     77c:      	cbz	x0, 0x784 <call_weak_fn+0x10>
     780:      	b	0x6f0 <__gmon_start__@plt>
     784:      	ret
     788:      	nop
     78c:      	nop

0000000000000790 <deregister_tm_clones>:
     790:      	adrp	x0, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     794:      	add	x0, x0, #0x50
     798:      	adrp	x1, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     79c:      	add	x1, x1, #0x50
     7a0:      	cmp	x1, x0
     7a4:      	b.eq	0x7bc <deregister_tm_clones+0x2c>
     7a8:      	adrp	x1, 0x1f000 <__FRAME_END__+0x1e304>
     7ac:      	ldr	x1, [x1, #0xfc0]
     7b0:      	cbz	x1, 0x7bc <deregister_tm_clones+0x2c>
     7b4:      	mov	x16, x1
     7b8:      	br	x16
     7bc:      	ret

00000000000007c0 <register_tm_clones>:
     7c0:      	adrp	x0, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     7c4:      	add	x0, x0, #0x50
     7c8:      	adrp	x1, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     7cc:      	add	x1, x1, #0x50
     7d0:      	sub	x1, x1, x0
     7d4:      	lsr	x2, x1, #63
     7d8:      	add	x1, x2, x1, asr #3
     7dc:      	asr	x1, x1, #1
     7e0:      	cbz	x1, 0x7f8 <register_tm_clones+0x38>
     7e4:      	adrp	x2, 0x1f000 <__FRAME_END__+0x1e304>
     7e8:      	ldr	x2, [x2, #0xfe0]
     7ec:      	cbz	x2, 0x7f8 <register_tm_clones+0x38>
     7f0:      	mov	x16, x2
     7f4:      	br	x16
     7f8:      	ret
     7fc:      	nop

0000000000000800 <__do_global_dtors_aux>:
     800:      	paciasp
     804:      	stp	x29, x30, [sp, #-0x20]!
     808:      	mov	x29, sp
     80c:      	str	x19, [sp, #0x10]
     810:      	adrp	x19, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     814:      	ldrb	w0, [x19, #0x50]
     818:      	tbnz	w0, #0x0, 0x840 <__do_global_dtors_aux+0x40>
     81c:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e304>
     820:      	ldr	x0, [x0, #0xfc8]
     824:      	cbz	x0, 0x834 <__do_global_dtors_aux+0x34>
     828:      	adrp	x0, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     82c:      	ldr	x0, [x0, #0x48]
     830:      	bl	0x6d0 <__cxa_finalize@plt>
     834:      	bl	0x790 <deregister_tm_clones>
     838:      	mov	w0, #0x1                // =1
     83c:      	strb	w0, [x19, #0x50]
     840:      	ldr	x19, [sp, #0x10]
     844:      	ldp	x29, x30, [sp], #0x20
     848:      	autiasp
     84c:      	ret

0000000000000850 <frame_dummy>:
     850:      	bti	c
     854:      	b	0x7c0 <register_tm_clones>

0000000000000858 <kernel>:
     858:      	sub	sp, sp, #0x20
     85c:      	str	w0, [sp, #0x1c]
     860:      	str	w1, [sp, #0x18]
     864:      	ldr	w8, [sp, #0x1c]
     868:      	str	w8, [sp, #0x14]
     86c:      	ldr	w8, [sp, #0x18]
     870:      	str	w8, [sp, #0x10]
     874:      	str	wzr, [sp, #0xc]
     878:      	b	0x87c <kernel+0x24>
     87c:      	ldr	w8, [sp, #0xc]
     880:      	subs	w8, w8, #0x4
     884:      	b.hs	0x8dc <kernel+0x84>
     888:      	b	0x88c <kernel+0x34>
     88c:      	ldr	w8, [sp, #0x14]
     890:      	ldrb	w9, [sp, #0x10]
     894:      	add	w8, w8, w9
     898:      	str	w8, [sp, #0x14]
     89c:      	ldr	w8, [sp, #0x14]
     8a0:      	ldr	w9, [sp, #0x14]
     8a4:      	add	w8, w8, w9, lsl #10
     8a8:      	str	w8, [sp, #0x14]
     8ac:      	ldr	w8, [sp, #0x14]
     8b0:      	ldr	w9, [sp, #0x14]
     8b4:      	eor	w8, w8, w9, lsr #6
     8b8:      	str	w8, [sp, #0x14]
     8bc:      	ldr	w8, [sp, #0x10]
     8c0:      	lsr	w8, w8, #8
     8c4:      	str	w8, [sp, #0x10]
     8c8:      	b	0x8cc <kernel+0x74>
     8cc:      	ldr	w8, [sp, #0xc]
     8d0:      	add	w8, w8, #0x1
     8d4:      	str	w8, [sp, #0xc]
     8d8:      	b	0x87c <kernel+0x24>
     8dc:      	ldr	w8, [sp, #0x14]
     8e0:      	ldr	w9, [sp, #0x14]
     8e4:      	add	w8, w8, w9, lsl #3
     8e8:      	str	w8, [sp, #0x14]
     8ec:      	ldr	w8, [sp, #0x14]
     8f0:      	ldr	w9, [sp, #0x14]
     8f4:      	eor	w8, w8, w9, lsr #11
     8f8:      	str	w8, [sp, #0x14]
     8fc:      	ldr	w8, [sp, #0x14]
     900:      	ldr	w9, [sp, #0x14]
     904:      	add	w8, w8, w9, lsl #15
     908:      	str	w8, [sp, #0x14]
     90c:      	ldr	w0, [sp, #0x14]
     910:      	add	sp, sp, #0x20
     914:      	ret

0000000000000918 <main>:
     918:      	sub	sp, sp, #0x90
     91c:      	stp	x29, x30, [sp, #0x80]
     920:      	add	x29, sp, #0x80
     924:      	stur	wzr, [x29, #-0x4]
     928:      	stur	w0, [x29, #-0x8]
     92c:      	stur	x1, [x29, #-0x10]
     930:      	ldur	w8, [x29, #-0x8]
     934:      	subs	w8, w8, #0x1
     938:      	b.ne	0x98c <main+0x74>
     93c:      	b	0x940 <main+0x28>
     940:      	b	0x944 <main+0x2c>
     944:      	sub	x1, x29, #0x18
     948:      	add	x2, x1, #0x4
     94c:      	adrp	x0, 0x0 <strtoul@GLIBC_2.17>
     950:      	add	x0, x0, #0xb98
     954:      	bl	0x710 <__isoc99_scanf@plt>
     958:      	subs	w8, w0, #0x2
     95c:      	b.ne	0x984 <main+0x6c>
     960:      	b	0x964 <main+0x4c>
     964:      	ldur	w0, [x29, #-0x18]
     968:      	ldur	w1, [x29, #-0x14]
     96c:      	bl	0x858 <kernel>
     970:      	mov	w1, w0
     974:      	adrp	x0, 0x0 <strtoul@GLIBC_2.17>
     978:      	add	x0, x0, #0xb9d
     97c:      	bl	0x720 <printf@plt>
     980:      	b	0x944 <main+0x2c>
     984:      	stur	wzr, [x29, #-0x4]
     988:      	b	0xb00 <main+0x1e8>
     98c:      	ldur	w8, [x29, #-0x8]
     990:      	subs	w8, w8, #0x3
     994:      	b.eq	0x9a8 <main+0x90>
     998:      	b	0x99c <main+0x84>
     99c:      	mov	w8, #0x3                // =3
     9a0:      	stur	w8, [x29, #-0x4]
     9a4:      	b	0xb00 <main+0x1e8>
     9a8:      	ldur	x8, [x29, #-0x10]
     9ac:      	ldr	x0, [x8, #0x8]
     9b0:      	mov	x1, xzr
     9b4:      	str	x1, [sp, #0x8]
     9b8:      	mov	w2, #0xa                // =10
     9bc:      	str	w2, [sp, #0x14]
     9c0:      	bl	0x6b0 <strtoul@plt>
     9c4:      	ldr	x1, [sp, #0x8]
     9c8:      	ldr	w2, [sp, #0x14]
     9cc:      	stur	x0, [x29, #-0x20]
     9d0:      	ldur	x8, [x29, #-0x10]
     9d4:      	ldr	x0, [x8, #0x10]
     9d8:      	bl	0x6b0 <strtoul@plt>
     9dc:      	mov	w8, w0
     9e0:      	stur	w8, [x29, #-0x24]
     9e4:      	stur	xzr, [x29, #-0x30]
     9e8:      	mov	w0, #0x1                // =1
     9ec:      	add	x1, sp, #0x40
     9f0:      	bl	0x6e0 <clock_gettime@plt>
     9f4:      	cbz	w0, 0xa08 <main+0xf0>
     9f8:      	b	0x9fc <main+0xe4>
     9fc:      	mov	w8, #0x2                // =2
     a00:      	stur	w8, [x29, #-0x4]
     a04:      	b	0xb00 <main+0x1e8>
     a08:      	str	xzr, [sp, #0x28]
     a0c:      	b	0xa10 <main+0xf8>
     a10:      	ldr	x8, [sp, #0x28]
     a14:      	ldur	x9, [x29, #-0x20]
     a18:      	subs	x8, x8, x9
     a1c:      	b.hs	0xa94 <main+0x17c>
     a20:      	b	0xa24 <main+0x10c>
     a24:      	str	wzr, [sp, #0x24]
     a28:      	b	0xa2c <main+0x114>
     a2c:      	ldr	w8, [sp, #0x24]
     a30:      	subs	w8, w8, #0x2
     a34:      	b.hs	0xa68 <main+0x150>
     a38:      	b	0xa3c <main+0x124>
     a3c:      	sub	x0, x29, #0x24
     a40:      	bl	0xb10 <csrd_matrix_next_value>
     a44:      	ldr	w8, [sp, #0x24]
     a48:      	mov	w9, w8
     a4c:      	sub	x8, x29, #0x18
     a50:      	str	w0, [x8, x9, lsl #2]
     a54:      	b	0xa58 <main+0x140>
     a58:      	ldr	w8, [sp, #0x24]
     a5c:      	add	w8, w8, #0x1
     a60:      	str	w8, [sp, #0x24]
     a64:      	b	0xa2c <main+0x114>
     a68:      	ldur	w0, [x29, #-0x18]
     a6c:      	ldur	w1, [x29, #-0x14]
     a70:      	bl	0x858 <kernel>
     a74:      	ldur	x8, [x29, #-0x30]
     a78:      	add	x8, x8, w0, uxtw
     a7c:      	stur	x8, [x29, #-0x30]
     a80:      	b	0xa84 <main+0x16c>
     a84:      	ldr	x8, [sp, #0x28]
     a88:      	add	x8, x8, #0x1
     a8c:      	str	x8, [sp, #0x28]
     a90:      	b	0xa10 <main+0xf8>
     a94:      	mov	w0, #0x1                // =1
     a98:      	add	x1, sp, #0x30
     a9c:      	bl	0x6e0 <clock_gettime@plt>
     aa0:      	cbz	w0, 0xab4 <main+0x19c>
     aa4:      	b	0xaa8 <main+0x190>
     aa8:      	mov	w8, #0x2                // =2
     aac:      	stur	w8, [x29, #-0x4]
     ab0:      	b	0xb00 <main+0x1e8>
     ab4:      	ldr	x8, [sp, #0x30]
     ab8:      	ldr	x9, [sp, #0x40]
     abc:      	subs	x8, x8, x9
     ac0:      	scvtf	d2, x8
     ac4:      	ldr	x8, [sp, #0x38]
     ac8:      	ldr	x9, [sp, #0x48]
     acc:      	subs	x8, x8, x9
     ad0:      	scvtf	d0, x8
     ad4:      	adrp	x8, 0x0 <strtoul@GLIBC_2.17>
     ad8:      	ldr	d1, [x8, #0xb90]
     adc:      	fmadd	d0, d0, d1, d2
     ae0:      	str	d0, [sp, #0x18]
     ae4:      	ldr	d0, [sp, #0x18]
     ae8:      	ldur	x1, [x29, #-0x30]
     aec:      	adrp	x0, 0x0 <strtoul@GLIBC_2.17>
     af0:      	add	x0, x0, #0xba1
     af4:      	bl	0x720 <printf@plt>
     af8:      	stur	wzr, [x29, #-0x4]
     afc:      	b	0xb00 <main+0x1e8>
     b00:      	ldur	w0, [x29, #-0x4]
     b04:      	ldp	x29, x30, [sp, #0x80]
     b08:      	add	sp, sp, #0x90
     b0c:      	ret

0000000000000b10 <csrd_matrix_next_value>:
     b10:      	sub	sp, sp, #0x10
     b14:      	str	x0, [sp, #0x8]
     b18:      	ldr	x8, [sp, #0x8]
     b1c:      	ldr	w10, [x8]
     b20:      	ldr	x9, [sp, #0x8]
     b24:      	ldr	w8, [x9]
     b28:      	eor	w8, w8, w10, lsl #13
     b2c:      	str	w8, [x9]
     b30:      	ldr	x8, [sp, #0x8]
     b34:      	ldr	w10, [x8]
     b38:      	ldr	x9, [sp, #0x8]
     b3c:      	ldr	w8, [x9]
     b40:      	eor	w8, w8, w10, lsr #17
     b44:      	str	w8, [x9]
     b48:      	ldr	x8, [sp, #0x8]
     b4c:      	ldr	w10, [x8]
     b50:      	ldr	x9, [sp, #0x8]
     b54:      	ldr	w8, [x9]
     b58:      	eor	w8, w8, w10, lsl #5
     b5c:      	str	w8, [x9]
     b60:      	ldr	x8, [sp, #0x8]
     b64:      	ldr	w0, [x8]
     b68:      	add	sp, sp, #0x10
     b6c:      	ret

Disassembly of section .fini:

0000000000000b70 <_fini>:
     b70:      	nop
     b74:      	stp	x29, x30, [sp, #-0x10]!
     b78:      	mov	x29, sp
     b7c:      	ldp	x29, x30, [sp], #0x10
     b80:      	ret
