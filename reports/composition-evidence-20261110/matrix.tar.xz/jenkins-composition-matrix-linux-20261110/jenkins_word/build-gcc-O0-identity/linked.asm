
/work/experiments/runs/jenkins-composition-matrix-linux-20261110/jenkins_word/build-gcc-O0-identity/program:	file format elf64-littleaarch64

Disassembly of section .init:

0000000000000730 <_init>:
     730:      	nop
     734:      	stp	x29, x30, [sp, #-0x10]!
     738:      	mov	x29, sp
     73c:      	bl	0x834 <call_weak_fn>
     740:      	ldp	x29, x30, [sp], #0x10
     744:      	ret

Disassembly of section .plt:

0000000000000750 <.plt>:
     750:      	stp	x16, x30, [sp, #-0x10]!
     754:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e0f8>
     758:      	ldr	x17, [x16, #0xf78]
     75c:      	add	x16, x16, #0xf78
     760:      	br	x17
     764:      	nop
     768:      	nop
     76c:      	nop

0000000000000770 <strtoul@plt>:
     770:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e0f8>
     774:      	ldr	x17, [x16, #0xf80]
     778:      	add	x16, x16, #0xf80
     77c:      	br	x17

0000000000000780 <__libc_start_main@plt>:
     780:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e0f8>
     784:      	ldr	x17, [x16, #0xf88]
     788:      	add	x16, x16, #0xf88
     78c:      	br	x17

0000000000000790 <__cxa_finalize@plt>:
     790:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e0f8>
     794:      	ldr	x17, [x16, #0xf90]
     798:      	add	x16, x16, #0xf90
     79c:      	br	x17

00000000000007a0 <clock_gettime@plt>:
     7a0:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e0f8>
     7a4:      	ldr	x17, [x16, #0xf98]
     7a8:      	add	x16, x16, #0xf98
     7ac:      	br	x17

00000000000007b0 <__stack_chk_fail@plt>:
     7b0:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e0f8>
     7b4:      	ldr	x17, [x16, #0xfa0]
     7b8:      	add	x16, x16, #0xfa0
     7bc:      	br	x17

00000000000007c0 <__gmon_start__@plt>:
     7c0:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e0f8>
     7c4:      	ldr	x17, [x16, #0xfa8]
     7c8:      	add	x16, x16, #0xfa8
     7cc:      	br	x17

00000000000007d0 <abort@plt>:
     7d0:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e0f8>
     7d4:      	ldr	x17, [x16, #0xfb0]
     7d8:      	add	x16, x16, #0xfb0
     7dc:      	br	x17

00000000000007e0 <__isoc99_scanf@plt>:
     7e0:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e0f8>
     7e4:      	ldr	x17, [x16, #0xfb8]
     7e8:      	add	x16, x16, #0xfb8
     7ec:      	br	x17

00000000000007f0 <printf@plt>:
     7f0:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e0f8>
     7f4:      	ldr	x17, [x16, #0xfc0]
     7f8:      	add	x16, x16, #0xfc0
     7fc:      	br	x17

Disassembly of section .text:

0000000000000800 <_start>:
     800:      	nop
     804:      	mov	x29, #0x0               // =0
     808:      	mov	x30, #0x0               // =0
     80c:      	mov	x5, x0
     810:      	ldr	x1, [sp]
     814:      	add	x2, sp, #0x8
     818:      	mov	x6, sp
     81c:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e0f8>
     820:      	ldr	x0, [x0, #0xff0]
     824:      	mov	x3, #0x0                // =0
     828:      	mov	x4, #0x0                // =0
     82c:      	bl	0x780 <__libc_start_main@plt>
     830:      	bl	0x7d0 <abort@plt>

0000000000000834 <call_weak_fn>:
     834:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e0f8>
     838:      	ldr	x0, [x0, #0xfe0]
     83c:      	cbz	x0, 0x844 <call_weak_fn+0x10>
     840:      	b	0x7c0 <__gmon_start__@plt>
     844:      	ret
     848:      	nop
     84c:      	nop

0000000000000850 <deregister_tm_clones>:
     850:      	adrp	x0, 0x20000 <data_start>
     854:      	add	x0, x0, #0x10
     858:      	adrp	x1, 0x20000 <data_start>
     85c:      	add	x1, x1, #0x10
     860:      	cmp	x1, x0
     864:      	b.eq	0x87c <deregister_tm_clones+0x2c>
     868:      	adrp	x1, 0x1f000 <__FRAME_END__+0x1e0f8>
     86c:      	ldr	x1, [x1, #0xfd0]
     870:      	cbz	x1, 0x87c <deregister_tm_clones+0x2c>
     874:      	mov	x16, x1
     878:      	br	x16
     87c:      	ret

0000000000000880 <register_tm_clones>:
     880:      	adrp	x0, 0x20000 <data_start>
     884:      	add	x0, x0, #0x10
     888:      	adrp	x1, 0x20000 <data_start>
     88c:      	add	x1, x1, #0x10
     890:      	sub	x1, x1, x0
     894:      	lsr	x2, x1, #63
     898:      	add	x1, x2, x1, asr #3
     89c:      	asr	x1, x1, #1
     8a0:      	cbz	x1, 0x8b8 <register_tm_clones+0x38>
     8a4:      	adrp	x2, 0x1f000 <__FRAME_END__+0x1e0f8>
     8a8:      	ldr	x2, [x2, #0xff8]
     8ac:      	cbz	x2, 0x8b8 <register_tm_clones+0x38>
     8b0:      	mov	x16, x2
     8b4:      	br	x16
     8b8:      	ret
     8bc:      	nop

00000000000008c0 <__do_global_dtors_aux>:
     8c0:      	paciasp
     8c4:      	stp	x29, x30, [sp, #-0x20]!
     8c8:      	mov	x29, sp
     8cc:      	str	x19, [sp, #0x10]
     8d0:      	adrp	x19, 0x20000 <data_start>
     8d4:      	ldrb	w0, [x19, #0x10]
     8d8:      	tbnz	w0, #0x0, 0x900 <__do_global_dtors_aux+0x40>
     8dc:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e0f8>
     8e0:      	ldr	x0, [x0, #0xfd8]
     8e4:      	cbz	x0, 0x8f4 <__do_global_dtors_aux+0x34>
     8e8:      	adrp	x0, 0x20000 <data_start>
     8ec:      	ldr	x0, [x0, #0x8]
     8f0:      	bl	0x790 <__cxa_finalize@plt>
     8f4:      	bl	0x850 <deregister_tm_clones>
     8f8:      	mov	w0, #0x1                // =1
     8fc:      	strb	w0, [x19, #0x10]
     900:      	ldr	x19, [sp, #0x10]
     904:      	ldp	x29, x30, [sp], #0x20
     908:      	autiasp
     90c:      	ret

0000000000000910 <frame_dummy>:
     910:      	bti	c
     914:      	b	0x880 <register_tm_clones>

0000000000000918 <kernel>:
     918:      	sub	sp, sp, #0xa0
     91c:      	str	w0, [sp, #0xc]
     920:      	str	w1, [sp, #0x8]
     924:      	ldr	w0, [sp, #0x8]
     928:      	and	w0, w0, #0xff
     92c:      	str	w0, [sp, #0x1c]
     930:      	ldr	w1, [sp, #0xc]
     934:      	ldr	w0, [sp, #0x1c]
     938:      	add	w0, w1, w0
     93c:      	str	w0, [sp, #0x20]
     940:      	ldr	w0, [sp, #0x20]
     944:      	lsl	w0, w0, #10
     948:      	str	w0, [sp, #0x24]
     94c:      	ldr	w1, [sp, #0x20]
     950:      	ldr	w0, [sp, #0x24]
     954:      	add	w0, w1, w0
     958:      	str	w0, [sp, #0x28]
     95c:      	ldr	w0, [sp, #0x28]
     960:      	lsr	w0, w0, #6
     964:      	str	w0, [sp, #0x2c]
     968:      	ldr	w1, [sp, #0x28]
     96c:      	ldr	w0, [sp, #0x2c]
     970:      	eor	w0, w1, w0
     974:      	str	w0, [sp, #0x30]
     978:      	ldr	w0, [sp, #0x8]
     97c:      	lsr	w0, w0, #8
     980:      	str	w0, [sp, #0x34]
     984:      	ldr	w0, [sp, #0x34]
     988:      	and	w0, w0, #0xff
     98c:      	str	w0, [sp, #0x38]
     990:      	ldr	w1, [sp, #0x30]
     994:      	ldr	w0, [sp, #0x38]
     998:      	add	w0, w1, w0
     99c:      	str	w0, [sp, #0x3c]
     9a0:      	ldr	w0, [sp, #0x3c]
     9a4:      	lsl	w0, w0, #10
     9a8:      	str	w0, [sp, #0x40]
     9ac:      	ldr	w1, [sp, #0x3c]
     9b0:      	ldr	w0, [sp, #0x40]
     9b4:      	add	w0, w1, w0
     9b8:      	str	w0, [sp, #0x44]
     9bc:      	ldr	w0, [sp, #0x44]
     9c0:      	lsr	w0, w0, #6
     9c4:      	str	w0, [sp, #0x48]
     9c8:      	ldr	w1, [sp, #0x44]
     9cc:      	ldr	w0, [sp, #0x48]
     9d0:      	eor	w0, w1, w0
     9d4:      	str	w0, [sp, #0x4c]
     9d8:      	ldr	w0, [sp, #0x34]
     9dc:      	lsr	w0, w0, #8
     9e0:      	str	w0, [sp, #0x50]
     9e4:      	ldr	w0, [sp, #0x50]
     9e8:      	and	w0, w0, #0xff
     9ec:      	str	w0, [sp, #0x54]
     9f0:      	ldr	w1, [sp, #0x4c]
     9f4:      	ldr	w0, [sp, #0x54]
     9f8:      	add	w0, w1, w0
     9fc:      	str	w0, [sp, #0x58]
     a00:      	ldr	w0, [sp, #0x58]
     a04:      	lsl	w0, w0, #10
     a08:      	str	w0, [sp, #0x5c]
     a0c:      	ldr	w1, [sp, #0x58]
     a10:      	ldr	w0, [sp, #0x5c]
     a14:      	add	w0, w1, w0
     a18:      	str	w0, [sp, #0x60]
     a1c:      	ldr	w0, [sp, #0x60]
     a20:      	lsr	w0, w0, #6
     a24:      	str	w0, [sp, #0x64]
     a28:      	ldr	w1, [sp, #0x60]
     a2c:      	ldr	w0, [sp, #0x64]
     a30:      	eor	w0, w1, w0
     a34:      	str	w0, [sp, #0x68]
     a38:      	ldr	w0, [sp, #0x50]
     a3c:      	lsr	w0, w0, #8
     a40:      	str	w0, [sp, #0x6c]
     a44:      	ldr	w0, [sp, #0x6c]
     a48:      	and	w0, w0, #0xff
     a4c:      	str	w0, [sp, #0x70]
     a50:      	ldr	w1, [sp, #0x68]
     a54:      	ldr	w0, [sp, #0x70]
     a58:      	add	w0, w1, w0
     a5c:      	str	w0, [sp, #0x74]
     a60:      	ldr	w0, [sp, #0x74]
     a64:      	lsl	w0, w0, #10
     a68:      	str	w0, [sp, #0x78]
     a6c:      	ldr	w1, [sp, #0x74]
     a70:      	ldr	w0, [sp, #0x78]
     a74:      	add	w0, w1, w0
     a78:      	str	w0, [sp, #0x7c]
     a7c:      	ldr	w0, [sp, #0x7c]
     a80:      	lsr	w0, w0, #6
     a84:      	str	w0, [sp, #0x80]
     a88:      	ldr	w1, [sp, #0x7c]
     a8c:      	ldr	w0, [sp, #0x80]
     a90:      	eor	w0, w1, w0
     a94:      	str	w0, [sp, #0x84]
     a98:      	ldr	w0, [sp, #0x84]
     a9c:      	lsl	w0, w0, #3
     aa0:      	str	w0, [sp, #0x88]
     aa4:      	ldr	w1, [sp, #0x84]
     aa8:      	ldr	w0, [sp, #0x88]
     aac:      	add	w0, w1, w0
     ab0:      	str	w0, [sp, #0x8c]
     ab4:      	ldr	w0, [sp, #0x8c]
     ab8:      	lsr	w0, w0, #11
     abc:      	str	w0, [sp, #0x90]
     ac0:      	ldr	w1, [sp, #0x8c]
     ac4:      	ldr	w0, [sp, #0x90]
     ac8:      	eor	w0, w1, w0
     acc:      	str	w0, [sp, #0x94]
     ad0:      	ldr	w0, [sp, #0x94]
     ad4:      	lsl	w0, w0, #15
     ad8:      	str	w0, [sp, #0x98]
     adc:      	ldr	w1, [sp, #0x94]
     ae0:      	ldr	w0, [sp, #0x98]
     ae4:      	add	w0, w1, w0
     ae8:      	str	w0, [sp, #0x9c]
     aec:      	ldr	w0, [sp, #0x9c]
     af0:      	add	sp, sp, #0xa0
     af4:      	ret

0000000000000af8 <csrd_matrix_next_value>:
     af8:      	sub	sp, sp, #0x10
     afc:      	str	x0, [sp, #0x8]
     b00:      	ldr	x0, [sp, #0x8]
     b04:      	ldr	w1, [x0]
     b08:      	ldr	x0, [sp, #0x8]
     b0c:      	ldr	w0, [x0]
     b10:      	lsl	w0, w0, #13
     b14:      	eor	w1, w1, w0
     b18:      	ldr	x0, [sp, #0x8]
     b1c:      	str	w1, [x0]
     b20:      	ldr	x0, [sp, #0x8]
     b24:      	ldr	w1, [x0]
     b28:      	ldr	x0, [sp, #0x8]
     b2c:      	ldr	w0, [x0]
     b30:      	lsr	w0, w0, #17
     b34:      	eor	w1, w1, w0
     b38:      	ldr	x0, [sp, #0x8]
     b3c:      	str	w1, [x0]
     b40:      	ldr	x0, [sp, #0x8]
     b44:      	ldr	w1, [x0]
     b48:      	ldr	x0, [sp, #0x8]
     b4c:      	ldr	w0, [x0]
     b50:      	lsl	w0, w0, #5
     b54:      	eor	w1, w1, w0
     b58:      	ldr	x0, [sp, #0x8]
     b5c:      	str	w1, [x0]
     b60:      	ldr	x0, [sp, #0x8]
     b64:      	ldr	w0, [x0]
     b68:      	add	sp, sp, #0x10
     b6c:      	ret

0000000000000b70 <main>:
     b70:      	sub	sp, sp, #0x80
     b74:      	stp	x29, x30, [sp, #0x70]
     b78:      	add	x29, sp, #0x70
     b7c:      	str	w0, [sp, #0xc]
     b80:      	str	x1, [sp]
     b84:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e0f8>
     b88:      	ldr	x0, [x0, #0xfe8]
     b8c:      	ldr	x1, [x0]
     b90:      	str	x1, [sp, #0x68]
     b94:      	mov	x1, #0x0                // =0
     b98:      	ldr	w0, [sp, #0xc]
     b9c:      	cmp	w0, #0x1
     ba0:      	b.ne	0xbf4 <main+0x84>
     ba4:      	b	0xbc4 <main+0x54>
     ba8:      	ldr	w0, [sp, #0x60]
     bac:      	ldr	w1, [sp, #0x64]
     bb0:      	bl	0x918 <kernel>
     bb4:      	mov	w1, w0
     bb8:      	adrp	x0, 0x0 <strtoul@GLIBC_2.17>
     bbc:      	add	x0, x0, #0xda8
     bc0:      	bl	0x7f0 <printf@plt>
     bc4:      	add	x0, sp, #0x60
     bc8:      	add	x1, x0, #0x4
     bcc:      	add	x0, sp, #0x60
     bd0:      	mov	x2, x1
     bd4:      	mov	x1, x0
     bd8:      	adrp	x0, 0x0 <strtoul@GLIBC_2.17>
     bdc:      	add	x0, x0, #0xdb0
     be0:      	bl	0x7e0 <__isoc99_scanf@plt>
     be4:      	cmp	w0, #0x2
     be8:      	b.eq	0xba8 <main+0x38>
     bec:      	mov	w0, #0x0                // =0
     bf0:      	b	0xd54 <main+0x1e4>
     bf4:      	ldr	w0, [sp, #0xc]
     bf8:      	cmp	w0, #0x3
     bfc:      	b.eq	0xc08 <main+0x98>
     c00:      	mov	w0, #0x3                // =3
     c04:      	b	0xd54 <main+0x1e4>
     c08:      	ldr	x0, [sp]
     c0c:      	add	x0, x0, #0x8
     c10:      	ldr	x0, [x0]
     c14:      	mov	w2, #0xa                // =10
     c18:      	mov	x1, #0x0                // =0
     c1c:      	bl	0x770 <strtoul@plt>
     c20:      	str	x0, [sp, #0x30]
     c24:      	ldr	x0, [sp]
     c28:      	add	x0, x0, #0x10
     c2c:      	ldr	x0, [x0]
     c30:      	mov	w2, #0xa                // =10
     c34:      	mov	x1, #0x0                // =0
     c38:      	bl	0x770 <strtoul@plt>
     c3c:      	str	w0, [sp, #0x18]
     c40:      	str	xzr, [sp, #0x20]
     c44:      	add	x0, sp, #0x40
     c48:      	mov	x1, x0
     c4c:      	mov	w0, #0x1                // =1
     c50:      	bl	0x7a0 <clock_gettime@plt>
     c54:      	cmp	w0, #0x0
     c58:      	b.eq	0xc64 <main+0xf4>
     c5c:      	mov	w0, #0x2                // =2
     c60:      	b	0xd54 <main+0x1e4>
     c64:      	str	xzr, [sp, #0x28]
     c68:      	b	0xcd0 <main+0x160>
     c6c:      	str	wzr, [sp, #0x1c]
     c70:      	b	0xc9c <main+0x12c>
     c74:      	add	x0, sp, #0x18
     c78:      	bl	0xaf8 <csrd_matrix_next_value>
     c7c:      	mov	w2, w0
     c80:      	ldr	w0, [sp, #0x1c]
     c84:      	lsl	x0, x0, #2
     c88:      	add	x1, sp, #0x60
     c8c:      	str	w2, [x1, x0]
     c90:      	ldr	w0, [sp, #0x1c]
     c94:      	add	w0, w0, #0x1
     c98:      	str	w0, [sp, #0x1c]
     c9c:      	ldr	w0, [sp, #0x1c]
     ca0:      	cmp	w0, #0x1
     ca4:      	b.ls	0xc74 <main+0x104>
     ca8:      	ldr	w0, [sp, #0x60]
     cac:      	ldr	w1, [sp, #0x64]
     cb0:      	bl	0x918 <kernel>
     cb4:      	mov	w0, w0
     cb8:      	ldr	x1, [sp, #0x20]
     cbc:      	add	x0, x1, x0
     cc0:      	str	x0, [sp, #0x20]
     cc4:      	ldr	x0, [sp, #0x28]
     cc8:      	add	x0, x0, #0x1
     ccc:      	str	x0, [sp, #0x28]
     cd0:      	ldr	x1, [sp, #0x28]
     cd4:      	ldr	x0, [sp, #0x30]
     cd8:      	cmp	x1, x0
     cdc:      	b.lo	0xc6c <main+0xfc>
     ce0:      	add	x0, sp, #0x50
     ce4:      	mov	x1, x0
     ce8:      	mov	w0, #0x1                // =1
     cec:      	bl	0x7a0 <clock_gettime@plt>
     cf0:      	cmp	w0, #0x0
     cf4:      	b.eq	0xd00 <main+0x190>
     cf8:      	mov	w0, #0x2                // =2
     cfc:      	b	0xd54 <main+0x1e4>
     d00:      	ldr	x1, [sp, #0x50]
     d04:      	ldr	x0, [sp, #0x40]
     d08:      	sub	x0, x1, x0
     d0c:      	fmov	d0, x0
     d10:      	scvtf	d1, d0
     d14:      	ldr	x1, [sp, #0x58]
     d18:      	ldr	x0, [sp, #0x48]
     d1c:      	sub	x0, x1, x0
     d20:      	fmov	d0, x0
     d24:      	scvtf	d0, d0
     d28:      	adrp	x0, 0x0 <strtoul@GLIBC_2.17>
     d2c:      	ldr	d2, [x0, #0xdc8]
     d30:      	fmul	d0, d0, d2
     d34:      	fadd	d0, d1, d0
     d38:      	str	d0, [sp, #0x38]
     d3c:      	ldr	x1, [sp, #0x20]
     d40:      	ldr	d0, [sp, #0x38]
     d44:      	adrp	x0, 0x0 <strtoul@GLIBC_2.17>
     d48:      	add	x0, x0, #0xdb8
     d4c:      	bl	0x7f0 <printf@plt>
     d50:      	mov	w0, #0x0                // =0
     d54:      	mov	w1, w0
     d58:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e0f8>
     d5c:      	ldr	x0, [x0, #0xfe8]
     d60:      	ldr	x3, [sp, #0x68]
     d64:      	ldr	x2, [x0]
     d68:      	subs	x3, x3, x2
     d6c:      	mov	x2, #0x0                // =0
     d70:      	b.eq	0xd78 <main+0x208>
     d74:      	bl	0x7b0 <__stack_chk_fail@plt>
     d78:      	mov	w0, w1
     d7c:      	ldp	x29, x30, [sp, #0x70]
     d80:      	add	sp, sp, #0x80
     d84:      	ret

Disassembly of section .fini:

0000000000000d88 <_fini>:
     d88:      	nop
     d8c:      	stp	x29, x30, [sp, #-0x10]!
     d90:      	mov	x29, sp
     d94:      	ldp	x29, x30, [sp], #0x10
     d98:      	ret
