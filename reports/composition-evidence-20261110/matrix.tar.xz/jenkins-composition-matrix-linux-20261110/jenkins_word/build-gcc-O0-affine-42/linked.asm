
/work/experiments/runs/jenkins-composition-matrix-linux-20261110/jenkins_word/build-gcc-O0-affine-42/program:	file format elf64-littleaarch64

Disassembly of section .init:

0000000000000730 <_init>:
     730:      	nop
     734:      	stp	x29, x30, [sp, #-0x10]!
     738:      	mov	x29, sp
     73c:      	bl	0x834 <call_weak_fn>
     740:      	ldp	x29, x30, [sp], #0x10
     744:      	ret

Disassembly of section .plt:

0000000000000750 <.plt>:
     750:      	stp	x16, x30, [sp, #-0x10]!
     754:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1dd40>
     758:      	ldr	x17, [x16, #0xf78]
     75c:      	add	x16, x16, #0xf78
     760:      	br	x17
     764:      	nop
     768:      	nop
     76c:      	nop

0000000000000770 <strtoul@plt>:
     770:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1dd40>
     774:      	ldr	x17, [x16, #0xf80]
     778:      	add	x16, x16, #0xf80
     77c:      	br	x17

0000000000000780 <__libc_start_main@plt>:
     780:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1dd40>
     784:      	ldr	x17, [x16, #0xf88]
     788:      	add	x16, x16, #0xf88
     78c:      	br	x17

0000000000000790 <__cxa_finalize@plt>:
     790:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1dd40>
     794:      	ldr	x17, [x16, #0xf90]
     798:      	add	x16, x16, #0xf90
     79c:      	br	x17

00000000000007a0 <clock_gettime@plt>:
     7a0:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1dd40>
     7a4:      	ldr	x17, [x16, #0xf98]
     7a8:      	add	x16, x16, #0xf98
     7ac:      	br	x17

00000000000007b0 <__stack_chk_fail@plt>:
     7b0:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1dd40>
     7b4:      	ldr	x17, [x16, #0xfa0]
     7b8:      	add	x16, x16, #0xfa0
     7bc:      	br	x17

00000000000007c0 <__gmon_start__@plt>:
     7c0:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1dd40>
     7c4:      	ldr	x17, [x16, #0xfa8]
     7c8:      	add	x16, x16, #0xfa8
     7cc:      	br	x17

00000000000007d0 <abort@plt>:
     7d0:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1dd40>
     7d4:      	ldr	x17, [x16, #0xfb0]
     7d8:      	add	x16, x16, #0xfb0
     7dc:      	br	x17

00000000000007e0 <__isoc99_scanf@plt>:
     7e0:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1dd40>
     7e4:      	ldr	x17, [x16, #0xfb8]
     7e8:      	add	x16, x16, #0xfb8
     7ec:      	br	x17

00000000000007f0 <printf@plt>:
     7f0:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1dd40>
     7f4:      	ldr	x17, [x16, #0xfc0]
     7f8:      	add	x16, x16, #0xfc0
     7fc:      	br	x17

Disassembly of section .text:

0000000000000800 <_start>:
     800:      	nop
     804:      	mov	x29, #0x0               // =0
     808:      	mov	x30, #0x0               // =0
     80c:      	mov	x5, x0
     810:      	ldr	x1, [sp]
     814:      	add	x2, sp, #0x8
     818:      	mov	x6, sp
     81c:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1dd40>
     820:      	ldr	x0, [x0, #0xff0]
     824:      	mov	x3, #0x0                // =0
     828:      	mov	x4, #0x0                // =0
     82c:      	bl	0x780 <__libc_start_main@plt>
     830:      	bl	0x7d0 <abort@plt>

0000000000000834 <call_weak_fn>:
     834:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1dd40>
     838:      	ldr	x0, [x0, #0xfe0]
     83c:      	cbz	x0, 0x844 <call_weak_fn+0x10>
     840:      	b	0x7c0 <__gmon_start__@plt>
     844:      	ret
     848:      	nop
     84c:      	nop

0000000000000850 <deregister_tm_clones>:
     850:      	adrp	x0, 0x20000 <data_start>
     854:      	add	x0, x0, #0x10
     858:      	adrp	x1, 0x20000 <data_start>
     85c:      	add	x1, x1, #0x10
     860:      	cmp	x1, x0
     864:      	b.eq	0x87c <deregister_tm_clones+0x2c>
     868:      	adrp	x1, 0x1f000 <__FRAME_END__+0x1dd40>
     86c:      	ldr	x1, [x1, #0xfd0]
     870:      	cbz	x1, 0x87c <deregister_tm_clones+0x2c>
     874:      	mov	x16, x1
     878:      	br	x16
     87c:      	ret

0000000000000880 <register_tm_clones>:
     880:      	adrp	x0, 0x20000 <data_start>
     884:      	add	x0, x0, #0x10
     888:      	adrp	x1, 0x20000 <data_start>
     88c:      	add	x1, x1, #0x10
     890:      	sub	x1, x1, x0
     894:      	lsr	x2, x1, #63
     898:      	add	x1, x2, x1, asr #3
     89c:      	asr	x1, x1, #1
     8a0:      	cbz	x1, 0x8b8 <register_tm_clones+0x38>
     8a4:      	adrp	x2, 0x1f000 <__FRAME_END__+0x1dd40>
     8a8:      	ldr	x2, [x2, #0xff8]
     8ac:      	cbz	x2, 0x8b8 <register_tm_clones+0x38>
     8b0:      	mov	x16, x2
     8b4:      	br	x16
     8b8:      	ret
     8bc:      	nop

00000000000008c0 <__do_global_dtors_aux>:
     8c0:      	paciasp
     8c4:      	stp	x29, x30, [sp, #-0x20]!
     8c8:      	mov	x29, sp
     8cc:      	str	x19, [sp, #0x10]
     8d0:      	adrp	x19, 0x20000 <data_start>
     8d4:      	ldrb	w0, [x19, #0x10]
     8d8:      	tbnz	w0, #0x0, 0x900 <__do_global_dtors_aux+0x40>
     8dc:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1dd40>
     8e0:      	ldr	x0, [x0, #0xfd8]
     8e4:      	cbz	x0, 0x8f4 <__do_global_dtors_aux+0x34>
     8e8:      	adrp	x0, 0x20000 <data_start>
     8ec:      	ldr	x0, [x0, #0x8]
     8f0:      	bl	0x790 <__cxa_finalize@plt>
     8f4:      	bl	0x850 <deregister_tm_clones>
     8f8:      	mov	w0, #0x1                // =1
     8fc:      	strb	w0, [x19, #0x10]
     900:      	ldr	x19, [sp, #0x10]
     904:      	ldp	x29, x30, [sp], #0x20
     908:      	autiasp
     90c:      	ret

0000000000000910 <frame_dummy>:
     910:      	bti	c
     914:      	b	0x880 <register_tm_clones>

0000000000000918 <kernel>:
     918:      	sub	sp, sp, #0x100
     91c:      	str	w0, [sp, #0xc]
     920:      	str	w1, [sp, #0x8]
     924:      	ldr	w0, [sp, #0x8]
     928:      	and	w0, w0, #0xff
     92c:      	str	w0, [sp, #0x14]
     930:      	ldr	w1, [sp, #0xc]
     934:      	mov	w0, #0x1e59             // =7769
     938:      	movk	w0, #0x77d7, lsl #16
     93c:      	mul	w1, w1, w0
     940:      	mov	w0, #0x7c47             // =31815
     944:      	movk	w0, #0x1093, lsl #16
     948:      	add	w0, w1, w0
     94c:      	str	w0, [sp, #0x18]
     950:      	ldr	w1, [sp, #0x14]
     954:      	mov	w0, #0x1e59             // =7769
     958:      	movk	w0, #0x77d7, lsl #16
     95c:      	mul	w1, w1, w0
     960:      	mov	w0, #0x7c47             // =31815
     964:      	movk	w0, #0x1093, lsl #16
     968:      	add	w0, w1, w0
     96c:      	str	w0, [sp, #0x1c]
     970:      	ldr	w1, [sp, #0x18]
     974:      	ldr	w0, [sp, #0x1c]
     978:      	add	w1, w1, w0
     97c:      	mov	w0, #0x83b9             // =33721
     980:      	movk	w0, #0xef6c, lsl #16
     984:      	add	w0, w1, w0
     988:      	str	w0, [sp, #0x20]
     98c:      	ldr	w1, [sp, #0x20]
     990:      	mov	w0, #0x49e9             // =18921
     994:      	movk	w0, #0x9c3e, lsl #16
     998:      	mul	w1, w1, w0
     99c:      	mov	w0, #0xa461             // =42081
     9a0:      	movk	w0, #0x7e21, lsl #16
     9a4:      	add	w0, w1, w0
     9a8:      	str	w0, [sp, #0x24]
     9ac:      	ldr	w0, [sp, #0x24]
     9b0:      	lsl	w0, w0, #10
     9b4:      	str	w0, [sp, #0x28]
     9b8:      	ldr	w1, [sp, #0x28]
     9bc:      	mov	w0, #0x1e59             // =7769
     9c0:      	movk	w0, #0x77d7, lsl #16
     9c4:      	mul	w1, w1, w0
     9c8:      	mov	w0, #0x7c47             // =31815
     9cc:      	movk	w0, #0x1093, lsl #16
     9d0:      	add	w0, w1, w0
     9d4:      	str	w0, [sp, #0x2c]
     9d8:      	ldr	w1, [sp, #0x20]
     9dc:      	ldr	w0, [sp, #0x2c]
     9e0:      	add	w1, w1, w0
     9e4:      	mov	w0, #0x83b9             // =33721
     9e8:      	movk	w0, #0xef6c, lsl #16
     9ec:      	add	w0, w1, w0
     9f0:      	str	w0, [sp, #0x30]
     9f4:      	ldr	w1, [sp, #0x30]
     9f8:      	mov	w0, #0x49e9             // =18921
     9fc:      	movk	w0, #0x9c3e, lsl #16
     a00:      	mul	w1, w1, w0
     a04:      	mov	w0, #0xa461             // =42081
     a08:      	movk	w0, #0x7e21, lsl #16
     a0c:      	add	w0, w1, w0
     a10:      	str	w0, [sp, #0x34]
     a14:      	ldr	w0, [sp, #0x34]
     a18:      	lsr	w0, w0, #6
     a1c:      	str	w0, [sp, #0x38]
     a20:      	ldr	w1, [sp, #0x34]
     a24:      	ldr	w0, [sp, #0x38]
     a28:      	eor	w0, w1, w0
     a2c:      	str	w0, [sp, #0x3c]
     a30:      	ldr	w0, [sp, #0x8]
     a34:      	lsr	w0, w0, #8
     a38:      	str	w0, [sp, #0x40]
     a3c:      	ldr	w0, [sp, #0x40]
     a40:      	and	w0, w0, #0xff
     a44:      	str	w0, [sp, #0x44]
     a48:      	ldr	w1, [sp, #0x3c]
     a4c:      	mov	w0, #0x1e59             // =7769
     a50:      	movk	w0, #0x77d7, lsl #16
     a54:      	mul	w1, w1, w0
     a58:      	mov	w0, #0x7c47             // =31815
     a5c:      	movk	w0, #0x1093, lsl #16
     a60:      	add	w0, w1, w0
     a64:      	str	w0, [sp, #0x48]
     a68:      	ldr	w1, [sp, #0x44]
     a6c:      	mov	w0, #0x1e59             // =7769
     a70:      	movk	w0, #0x77d7, lsl #16
     a74:      	mul	w1, w1, w0
     a78:      	mov	w0, #0x7c47             // =31815
     a7c:      	movk	w0, #0x1093, lsl #16
     a80:      	add	w0, w1, w0
     a84:      	str	w0, [sp, #0x4c]
     a88:      	ldr	w1, [sp, #0x48]
     a8c:      	ldr	w0, [sp, #0x4c]
     a90:      	add	w1, w1, w0
     a94:      	mov	w0, #0x83b9             // =33721
     a98:      	movk	w0, #0xef6c, lsl #16
     a9c:      	add	w0, w1, w0
     aa0:      	str	w0, [sp, #0x50]
     aa4:      	ldr	w1, [sp, #0x50]
     aa8:      	mov	w0, #0x49e9             // =18921
     aac:      	movk	w0, #0x9c3e, lsl #16
     ab0:      	mul	w1, w1, w0
     ab4:      	mov	w0, #0xa461             // =42081
     ab8:      	movk	w0, #0x7e21, lsl #16
     abc:      	add	w0, w1, w0
     ac0:      	str	w0, [sp, #0x54]
     ac4:      	ldr	w0, [sp, #0x54]
     ac8:      	lsl	w0, w0, #10
     acc:      	str	w0, [sp, #0x58]
     ad0:      	ldr	w1, [sp, #0x58]
     ad4:      	mov	w0, #0x1e59             // =7769
     ad8:      	movk	w0, #0x77d7, lsl #16
     adc:      	mul	w1, w1, w0
     ae0:      	mov	w0, #0x7c47             // =31815
     ae4:      	movk	w0, #0x1093, lsl #16
     ae8:      	add	w0, w1, w0
     aec:      	str	w0, [sp, #0x5c]
     af0:      	ldr	w1, [sp, #0x50]
     af4:      	ldr	w0, [sp, #0x5c]
     af8:      	add	w1, w1, w0
     afc:      	mov	w0, #0x83b9             // =33721
     b00:      	movk	w0, #0xef6c, lsl #16
     b04:      	add	w0, w1, w0
     b08:      	str	w0, [sp, #0x60]
     b0c:      	ldr	w1, [sp, #0x60]
     b10:      	mov	w0, #0x49e9             // =18921
     b14:      	movk	w0, #0x9c3e, lsl #16
     b18:      	mul	w1, w1, w0
     b1c:      	mov	w0, #0xa461             // =42081
     b20:      	movk	w0, #0x7e21, lsl #16
     b24:      	add	w0, w1, w0
     b28:      	str	w0, [sp, #0x64]
     b2c:      	ldr	w0, [sp, #0x64]
     b30:      	lsr	w0, w0, #6
     b34:      	str	w0, [sp, #0x68]
     b38:      	ldr	w1, [sp, #0x64]
     b3c:      	ldr	w0, [sp, #0x68]
     b40:      	eor	w0, w1, w0
     b44:      	str	w0, [sp, #0x6c]
     b48:      	ldr	w0, [sp, #0x40]
     b4c:      	lsr	w0, w0, #8
     b50:      	str	w0, [sp, #0x70]
     b54:      	ldr	w0, [sp, #0x70]
     b58:      	and	w0, w0, #0xff
     b5c:      	str	w0, [sp, #0x74]
     b60:      	ldr	w1, [sp, #0x6c]
     b64:      	mov	w0, #0x1e59             // =7769
     b68:      	movk	w0, #0x77d7, lsl #16
     b6c:      	mul	w1, w1, w0
     b70:      	mov	w0, #0x7c47             // =31815
     b74:      	movk	w0, #0x1093, lsl #16
     b78:      	add	w0, w1, w0
     b7c:      	str	w0, [sp, #0x78]
     b80:      	ldr	w1, [sp, #0x74]
     b84:      	mov	w0, #0x1e59             // =7769
     b88:      	movk	w0, #0x77d7, lsl #16
     b8c:      	mul	w1, w1, w0
     b90:      	mov	w0, #0x7c47             // =31815
     b94:      	movk	w0, #0x1093, lsl #16
     b98:      	add	w0, w1, w0
     b9c:      	str	w0, [sp, #0x7c]
     ba0:      	ldr	w1, [sp, #0x78]
     ba4:      	ldr	w0, [sp, #0x7c]
     ba8:      	add	w1, w1, w0
     bac:      	mov	w0, #0x83b9             // =33721
     bb0:      	movk	w0, #0xef6c, lsl #16
     bb4:      	add	w0, w1, w0
     bb8:      	str	w0, [sp, #0x80]
     bbc:      	ldr	w1, [sp, #0x80]
     bc0:      	mov	w0, #0x49e9             // =18921
     bc4:      	movk	w0, #0x9c3e, lsl #16
     bc8:      	mul	w1, w1, w0
     bcc:      	mov	w0, #0xa461             // =42081
     bd0:      	movk	w0, #0x7e21, lsl #16
     bd4:      	add	w0, w1, w0
     bd8:      	str	w0, [sp, #0x84]
     bdc:      	ldr	w0, [sp, #0x84]
     be0:      	lsl	w0, w0, #10
     be4:      	str	w0, [sp, #0x88]
     be8:      	ldr	w1, [sp, #0x88]
     bec:      	mov	w0, #0x1e59             // =7769
     bf0:      	movk	w0, #0x77d7, lsl #16
     bf4:      	mul	w1, w1, w0
     bf8:      	mov	w0, #0x7c47             // =31815
     bfc:      	movk	w0, #0x1093, lsl #16
     c00:      	add	w0, w1, w0
     c04:      	str	w0, [sp, #0x8c]
     c08:      	ldr	w1, [sp, #0x80]
     c0c:      	ldr	w0, [sp, #0x8c]
     c10:      	add	w1, w1, w0
     c14:      	mov	w0, #0x83b9             // =33721
     c18:      	movk	w0, #0xef6c, lsl #16
     c1c:      	add	w0, w1, w0
     c20:      	str	w0, [sp, #0x90]
     c24:      	ldr	w1, [sp, #0x90]
     c28:      	mov	w0, #0x49e9             // =18921
     c2c:      	movk	w0, #0x9c3e, lsl #16
     c30:      	mul	w1, w1, w0
     c34:      	mov	w0, #0xa461             // =42081
     c38:      	movk	w0, #0x7e21, lsl #16
     c3c:      	add	w0, w1, w0
     c40:      	str	w0, [sp, #0x94]
     c44:      	ldr	w0, [sp, #0x94]
     c48:      	lsr	w0, w0, #6
     c4c:      	str	w0, [sp, #0x98]
     c50:      	ldr	w1, [sp, #0x94]
     c54:      	ldr	w0, [sp, #0x98]
     c58:      	eor	w0, w1, w0
     c5c:      	str	w0, [sp, #0x9c]
     c60:      	ldr	w0, [sp, #0x70]
     c64:      	lsr	w0, w0, #8
     c68:      	str	w0, [sp, #0xa0]
     c6c:      	ldr	w0, [sp, #0xa0]
     c70:      	and	w0, w0, #0xff
     c74:      	str	w0, [sp, #0xa4]
     c78:      	ldr	w1, [sp, #0x9c]
     c7c:      	mov	w0, #0x1e59             // =7769
     c80:      	movk	w0, #0x77d7, lsl #16
     c84:      	mul	w1, w1, w0
     c88:      	mov	w0, #0x7c47             // =31815
     c8c:      	movk	w0, #0x1093, lsl #16
     c90:      	add	w0, w1, w0
     c94:      	str	w0, [sp, #0xa8]
     c98:      	ldr	w1, [sp, #0xa4]
     c9c:      	mov	w0, #0x1e59             // =7769
     ca0:      	movk	w0, #0x77d7, lsl #16
     ca4:      	mul	w1, w1, w0
     ca8:      	mov	w0, #0x7c47             // =31815
     cac:      	movk	w0, #0x1093, lsl #16
     cb0:      	add	w0, w1, w0
     cb4:      	str	w0, [sp, #0xac]
     cb8:      	ldr	w1, [sp, #0xa8]
     cbc:      	ldr	w0, [sp, #0xac]
     cc0:      	add	w1, w1, w0
     cc4:      	mov	w0, #0x83b9             // =33721
     cc8:      	movk	w0, #0xef6c, lsl #16
     ccc:      	add	w0, w1, w0
     cd0:      	str	w0, [sp, #0xb0]
     cd4:      	ldr	w1, [sp, #0xb0]
     cd8:      	mov	w0, #0x49e9             // =18921
     cdc:      	movk	w0, #0x9c3e, lsl #16
     ce0:      	mul	w1, w1, w0
     ce4:      	mov	w0, #0xa461             // =42081
     ce8:      	movk	w0, #0x7e21, lsl #16
     cec:      	add	w0, w1, w0
     cf0:      	str	w0, [sp, #0xb4]
     cf4:      	ldr	w0, [sp, #0xb4]
     cf8:      	lsl	w0, w0, #10
     cfc:      	str	w0, [sp, #0xb8]
     d00:      	ldr	w1, [sp, #0xb8]
     d04:      	mov	w0, #0x1e59             // =7769
     d08:      	movk	w0, #0x77d7, lsl #16
     d0c:      	mul	w1, w1, w0
     d10:      	mov	w0, #0x7c47             // =31815
     d14:      	movk	w0, #0x1093, lsl #16
     d18:      	add	w0, w1, w0
     d1c:      	str	w0, [sp, #0xbc]
     d20:      	ldr	w1, [sp, #0xb0]
     d24:      	ldr	w0, [sp, #0xbc]
     d28:      	add	w1, w1, w0
     d2c:      	mov	w0, #0x83b9             // =33721
     d30:      	movk	w0, #0xef6c, lsl #16
     d34:      	add	w0, w1, w0
     d38:      	str	w0, [sp, #0xc0]
     d3c:      	ldr	w1, [sp, #0xc0]
     d40:      	mov	w0, #0x49e9             // =18921
     d44:      	movk	w0, #0x9c3e, lsl #16
     d48:      	mul	w1, w1, w0
     d4c:      	mov	w0, #0xa461             // =42081
     d50:      	movk	w0, #0x7e21, lsl #16
     d54:      	add	w0, w1, w0
     d58:      	str	w0, [sp, #0xc4]
     d5c:      	ldr	w0, [sp, #0xc4]
     d60:      	lsr	w0, w0, #6
     d64:      	str	w0, [sp, #0xc8]
     d68:      	ldr	w1, [sp, #0xc4]
     d6c:      	ldr	w0, [sp, #0xc8]
     d70:      	eor	w0, w1, w0
     d74:      	str	w0, [sp, #0xcc]
     d78:      	ldr	w0, [sp, #0xcc]
     d7c:      	lsl	w0, w0, #3
     d80:      	str	w0, [sp, #0xd0]
     d84:      	ldr	w1, [sp, #0xcc]
     d88:      	mov	w0, #0x1e59             // =7769
     d8c:      	movk	w0, #0x77d7, lsl #16
     d90:      	mul	w1, w1, w0
     d94:      	mov	w0, #0x7c47             // =31815
     d98:      	movk	w0, #0x1093, lsl #16
     d9c:      	add	w0, w1, w0
     da0:      	str	w0, [sp, #0xd4]
     da4:      	ldr	w1, [sp, #0xd0]
     da8:      	mov	w0, #0x1e59             // =7769
     dac:      	movk	w0, #0x77d7, lsl #16
     db0:      	mul	w1, w1, w0
     db4:      	mov	w0, #0x7c47             // =31815
     db8:      	movk	w0, #0x1093, lsl #16
     dbc:      	add	w0, w1, w0
     dc0:      	str	w0, [sp, #0xd8]
     dc4:      	ldr	w1, [sp, #0xd4]
     dc8:      	ldr	w0, [sp, #0xd8]
     dcc:      	add	w1, w1, w0
     dd0:      	mov	w0, #0x83b9             // =33721
     dd4:      	movk	w0, #0xef6c, lsl #16
     dd8:      	add	w0, w1, w0
     ddc:      	str	w0, [sp, #0xdc]
     de0:      	ldr	w1, [sp, #0xdc]
     de4:      	mov	w0, #0x49e9             // =18921
     de8:      	movk	w0, #0x9c3e, lsl #16
     dec:      	mul	w1, w1, w0
     df0:      	mov	w0, #0xa461             // =42081
     df4:      	movk	w0, #0x7e21, lsl #16
     df8:      	add	w0, w1, w0
     dfc:      	str	w0, [sp, #0xe0]
     e00:      	ldr	w0, [sp, #0xe0]
     e04:      	lsr	w0, w0, #11
     e08:      	str	w0, [sp, #0xe4]
     e0c:      	ldr	w1, [sp, #0xe0]
     e10:      	ldr	w0, [sp, #0xe4]
     e14:      	eor	w0, w1, w0
     e18:      	str	w0, [sp, #0xe8]
     e1c:      	ldr	w0, [sp, #0xe8]
     e20:      	lsl	w0, w0, #15
     e24:      	str	w0, [sp, #0xec]
     e28:      	ldr	w1, [sp, #0xe8]
     e2c:      	mov	w0, #0x1e59             // =7769
     e30:      	movk	w0, #0x77d7, lsl #16
     e34:      	mul	w1, w1, w0
     e38:      	mov	w0, #0x7c47             // =31815
     e3c:      	movk	w0, #0x1093, lsl #16
     e40:      	add	w0, w1, w0
     e44:      	str	w0, [sp, #0xf0]
     e48:      	ldr	w1, [sp, #0xec]
     e4c:      	mov	w0, #0x1e59             // =7769
     e50:      	movk	w0, #0x77d7, lsl #16
     e54:      	mul	w1, w1, w0
     e58:      	mov	w0, #0x7c47             // =31815
     e5c:      	movk	w0, #0x1093, lsl #16
     e60:      	add	w0, w1, w0
     e64:      	str	w0, [sp, #0xf4]
     e68:      	ldr	w1, [sp, #0xf0]
     e6c:      	ldr	w0, [sp, #0xf4]
     e70:      	add	w1, w1, w0
     e74:      	mov	w0, #0x83b9             // =33721
     e78:      	movk	w0, #0xef6c, lsl #16
     e7c:      	add	w0, w1, w0
     e80:      	str	w0, [sp, #0xf8]
     e84:      	ldr	w1, [sp, #0xf8]
     e88:      	mov	w0, #0x49e9             // =18921
     e8c:      	movk	w0, #0x9c3e, lsl #16
     e90:      	mul	w1, w1, w0
     e94:      	mov	w0, #0xa461             // =42081
     e98:      	movk	w0, #0x7e21, lsl #16
     e9c:      	add	w0, w1, w0
     ea0:      	str	w0, [sp, #0xfc]
     ea4:      	ldr	w0, [sp, #0xfc]
     ea8:      	add	sp, sp, #0x100
     eac:      	ret

0000000000000eb0 <csrd_matrix_next_value>:
     eb0:      	sub	sp, sp, #0x10
     eb4:      	str	x0, [sp, #0x8]
     eb8:      	ldr	x0, [sp, #0x8]
     ebc:      	ldr	w1, [x0]
     ec0:      	ldr	x0, [sp, #0x8]
     ec4:      	ldr	w0, [x0]
     ec8:      	lsl	w0, w0, #13
     ecc:      	eor	w1, w1, w0
     ed0:      	ldr	x0, [sp, #0x8]
     ed4:      	str	w1, [x0]
     ed8:      	ldr	x0, [sp, #0x8]
     edc:      	ldr	w1, [x0]
     ee0:      	ldr	x0, [sp, #0x8]
     ee4:      	ldr	w0, [x0]
     ee8:      	lsr	w0, w0, #17
     eec:      	eor	w1, w1, w0
     ef0:      	ldr	x0, [sp, #0x8]
     ef4:      	str	w1, [x0]
     ef8:      	ldr	x0, [sp, #0x8]
     efc:      	ldr	w1, [x0]
     f00:      	ldr	x0, [sp, #0x8]
     f04:      	ldr	w0, [x0]
     f08:      	lsl	w0, w0, #5
     f0c:      	eor	w1, w1, w0
     f10:      	ldr	x0, [sp, #0x8]
     f14:      	str	w1, [x0]
     f18:      	ldr	x0, [sp, #0x8]
     f1c:      	ldr	w0, [x0]
     f20:      	add	sp, sp, #0x10
     f24:      	ret

0000000000000f28 <main>:
     f28:      	sub	sp, sp, #0x80
     f2c:      	stp	x29, x30, [sp, #0x70]
     f30:      	add	x29, sp, #0x70
     f34:      	str	w0, [sp, #0xc]
     f38:      	str	x1, [sp]
     f3c:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1dd40>
     f40:      	ldr	x0, [x0, #0xfe8]
     f44:      	ldr	x1, [x0]
     f48:      	str	x1, [sp, #0x68]
     f4c:      	mov	x1, #0x0                // =0
     f50:      	ldr	w0, [sp, #0xc]
     f54:      	cmp	w0, #0x1
     f58:      	b.ne	0xfac <main+0x84>
     f5c:      	b	0xf7c <main+0x54>
     f60:      	ldr	w0, [sp, #0x60]
     f64:      	ldr	w1, [sp, #0x64]
     f68:      	bl	0x918 <kernel>
     f6c:      	mov	w1, w0
     f70:      	adrp	x0, 0x1000 <main+0xd8>
     f74:      	add	x0, x0, #0x160
     f78:      	bl	0x7f0 <printf@plt>
     f7c:      	add	x0, sp, #0x60
     f80:      	add	x1, x0, #0x4
     f84:      	add	x0, sp, #0x60
     f88:      	mov	x2, x1
     f8c:      	mov	x1, x0
     f90:      	adrp	x0, 0x1000 <main+0xd8>
     f94:      	add	x0, x0, #0x168
     f98:      	bl	0x7e0 <__isoc99_scanf@plt>
     f9c:      	cmp	w0, #0x2
     fa0:      	b.eq	0xf60 <main+0x38>
     fa4:      	mov	w0, #0x0                // =0
     fa8:      	b	0x110c <main+0x1e4>
     fac:      	ldr	w0, [sp, #0xc]
     fb0:      	cmp	w0, #0x3
     fb4:      	b.eq	0xfc0 <main+0x98>
     fb8:      	mov	w0, #0x3                // =3
     fbc:      	b	0x110c <main+0x1e4>
     fc0:      	ldr	x0, [sp]
     fc4:      	add	x0, x0, #0x8
     fc8:      	ldr	x0, [x0]
     fcc:      	mov	w2, #0xa                // =10
     fd0:      	mov	x1, #0x0                // =0
     fd4:      	bl	0x770 <strtoul@plt>
     fd8:      	str	x0, [sp, #0x30]
     fdc:      	ldr	x0, [sp]
     fe0:      	add	x0, x0, #0x10
     fe4:      	ldr	x0, [x0]
     fe8:      	mov	w2, #0xa                // =10
     fec:      	mov	x1, #0x0                // =0
     ff0:      	bl	0x770 <strtoul@plt>
     ff4:      	str	w0, [sp, #0x18]
     ff8:      	str	xzr, [sp, #0x20]
     ffc:      	add	x0, sp, #0x40
    1000:      	mov	x1, x0
    1004:      	mov	w0, #0x1                // =1
    1008:      	bl	0x7a0 <clock_gettime@plt>
    100c:      	cmp	w0, #0x0
    1010:      	b.eq	0x101c <main+0xf4>
    1014:      	mov	w0, #0x2                // =2
    1018:      	b	0x110c <main+0x1e4>
    101c:      	str	xzr, [sp, #0x28]
    1020:      	b	0x1088 <main+0x160>
    1024:      	str	wzr, [sp, #0x1c]
    1028:      	b	0x1054 <main+0x12c>
    102c:      	add	x0, sp, #0x18
    1030:      	bl	0xeb0 <csrd_matrix_next_value>
    1034:      	mov	w2, w0
    1038:      	ldr	w0, [sp, #0x1c]
    103c:      	lsl	x0, x0, #2
    1040:      	add	x1, sp, #0x60
    1044:      	str	w2, [x1, x0]
    1048:      	ldr	w0, [sp, #0x1c]
    104c:      	add	w0, w0, #0x1
    1050:      	str	w0, [sp, #0x1c]
    1054:      	ldr	w0, [sp, #0x1c]
    1058:      	cmp	w0, #0x1
    105c:      	b.ls	0x102c <main+0x104>
    1060:      	ldr	w0, [sp, #0x60]
    1064:      	ldr	w1, [sp, #0x64]
    1068:      	bl	0x918 <kernel>
    106c:      	mov	w0, w0
    1070:      	ldr	x1, [sp, #0x20]
    1074:      	add	x0, x1, x0
    1078:      	str	x0, [sp, #0x20]
    107c:      	ldr	x0, [sp, #0x28]
    1080:      	add	x0, x0, #0x1
    1084:      	str	x0, [sp, #0x28]
    1088:      	ldr	x1, [sp, #0x28]
    108c:      	ldr	x0, [sp, #0x30]
    1090:      	cmp	x1, x0
    1094:      	b.lo	0x1024 <main+0xfc>
    1098:      	add	x0, sp, #0x50
    109c:      	mov	x1, x0
    10a0:      	mov	w0, #0x1                // =1
    10a4:      	bl	0x7a0 <clock_gettime@plt>
    10a8:      	cmp	w0, #0x0
    10ac:      	b.eq	0x10b8 <main+0x190>
    10b0:      	mov	w0, #0x2                // =2
    10b4:      	b	0x110c <main+0x1e4>
    10b8:      	ldr	x1, [sp, #0x50]
    10bc:      	ldr	x0, [sp, #0x40]
    10c0:      	sub	x0, x1, x0
    10c4:      	fmov	d0, x0
    10c8:      	scvtf	d1, d0
    10cc:      	ldr	x1, [sp, #0x58]
    10d0:      	ldr	x0, [sp, #0x48]
    10d4:      	sub	x0, x1, x0
    10d8:      	fmov	d0, x0
    10dc:      	scvtf	d0, d0
    10e0:      	adrp	x0, 0x1000 <main+0xd8>
    10e4:      	ldr	d2, [x0, #0x180]
    10e8:      	fmul	d0, d0, d2
    10ec:      	fadd	d0, d1, d0
    10f0:      	str	d0, [sp, #0x38]
    10f4:      	ldr	x1, [sp, #0x20]
    10f8:      	ldr	d0, [sp, #0x38]
    10fc:      	adrp	x0, 0x1000 <main+0xd8>
    1100:      	add	x0, x0, #0x170
    1104:      	bl	0x7f0 <printf@plt>
    1108:      	mov	w0, #0x0                // =0
    110c:      	mov	w1, w0
    1110:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1dd40>
    1114:      	ldr	x0, [x0, #0xfe8]
    1118:      	ldr	x3, [sp, #0x68]
    111c:      	ldr	x2, [x0]
    1120:      	subs	x3, x3, x2
    1124:      	mov	x2, #0x0                // =0
    1128:      	b.eq	0x1130 <main+0x208>
    112c:      	bl	0x7b0 <__stack_chk_fail@plt>
    1130:      	mov	w0, w1
    1134:      	ldp	x29, x30, [sp, #0x70]
    1138:      	add	sp, sp, #0x80
    113c:      	ret

Disassembly of section .fini:

0000000000001140 <_fini>:
    1140:      	nop
    1144:      	stp	x29, x30, [sp, #-0x10]!
    1148:      	mov	x29, sp
    114c:      	ldp	x29, x30, [sp], #0x10
    1150:      	ret
