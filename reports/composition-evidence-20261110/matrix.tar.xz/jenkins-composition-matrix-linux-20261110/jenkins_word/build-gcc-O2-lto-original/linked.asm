
/work/experiments/runs/jenkins-composition-matrix-linux-20261110/jenkins_word/build-gcc-O2-lto-original/program:	file format elf64-littleaarch64

Disassembly of section .init:

0000000000000738 <_init>:
     738:      	nop
     73c:      	stp	x29, x30, [sp, #-0x10]!
     740:      	mov	x29, sp
     744:      	bl	0xa74 <call_weak_fn>
     748:      	ldp	x29, x30, [sp], #0x10
     74c:      	ret

Disassembly of section .plt:

0000000000000750 <.plt>:
     750:      	stp	x16, x30, [sp, #-0x10]!
     754:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e344>
     758:      	ldr	x17, [x16, #0xf78]
     75c:      	add	x16, x16, #0xf78
     760:      	br	x17
     764:      	nop
     768:      	nop
     76c:      	nop

0000000000000770 <strtoul@plt>:
     770:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e344>
     774:      	ldr	x17, [x16, #0xf80]
     778:      	add	x16, x16, #0xf80
     77c:      	br	x17

0000000000000780 <__libc_start_main@plt>:
     780:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e344>
     784:      	ldr	x17, [x16, #0xf88]
     788:      	add	x16, x16, #0xf88
     78c:      	br	x17

0000000000000790 <__cxa_finalize@plt>:
     790:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e344>
     794:      	ldr	x17, [x16, #0xf90]
     798:      	add	x16, x16, #0xf90
     79c:      	br	x17

00000000000007a0 <clock_gettime@plt>:
     7a0:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e344>
     7a4:      	ldr	x17, [x16, #0xf98]
     7a8:      	add	x16, x16, #0xf98
     7ac:      	br	x17

00000000000007b0 <__printf_chk@plt>:
     7b0:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e344>
     7b4:      	ldr	x17, [x16, #0xfa0]
     7b8:      	add	x16, x16, #0xfa0
     7bc:      	br	x17

00000000000007c0 <__stack_chk_fail@plt>:
     7c0:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e344>
     7c4:      	ldr	x17, [x16, #0xfa8]
     7c8:      	add	x16, x16, #0xfa8
     7cc:      	br	x17

00000000000007d0 <__gmon_start__@plt>:
     7d0:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e344>
     7d4:      	ldr	x17, [x16, #0xfb0]
     7d8:      	add	x16, x16, #0xfb0
     7dc:      	br	x17

00000000000007e0 <abort@plt>:
     7e0:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e344>
     7e4:      	ldr	x17, [x16, #0xfb8]
     7e8:      	add	x16, x16, #0xfb8
     7ec:      	br	x17

00000000000007f0 <__isoc99_scanf@plt>:
     7f0:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e344>
     7f4:      	ldr	x17, [x16, #0xfc0]
     7f8:      	add	x16, x16, #0xfc0
     7fc:      	br	x17

Disassembly of section .text:

0000000000000800 <main>:
     800:      	sub	sp, sp, #0x60
     804:      	mov	w2, w0
     808:      	adrp	x3, 0x1f000 <__FRAME_END__+0x1e344>
     80c:      	ldr	x3, [x3, #0xfe8]
     810:      	stp	x29, x30, [sp, #0x30]
     814:      	add	x29, sp, #0x30
     818:      	ldr	x0, [x3]
     81c:      	str	x0, [sp, #0x28]
     820:      	mov	x0, #0x0                // =0
     824:      	cmp	w2, #0x1
     828:      	b.eq	0x960 <main+0x160>
     82c:      	mov	w0, #0x3                // =3
     830:      	cmp	w2, w0
     834:      	b.eq	0x860 <main+0x60>
     838:      	adrp	x1, 0x1f000 <__FRAME_END__+0x1e344>
     83c:      	ldr	x1, [x1, #0xfe8]
     840:      	ldr	x3, [sp, #0x28]
     844:      	ldr	x2, [x1]
     848:      	subs	x3, x3, x2
     84c:      	mov	x2, #0x0                // =0
     850:      	b.ne	0xa04 <main+0x204>
     854:      	ldp	x29, x30, [sp, #0x30]
     858:      	add	sp, sp, #0x60
     85c:      	ret
     860:      	stp	x19, x20, [sp, #0x40]
     864:      	mov	x19, x1
     868:      	mov	w2, #0xa                // =10
     86c:      	mov	x1, #0x0                // =0
     870:      	ldr	x0, [x19, #0x8]
     874:      	bl	0x770 <strtoul@plt>
     878:      	mov	x20, x0
     87c:      	ldr	x0, [x19, #0x10]
     880:      	mov	w2, #0xa                // =10
     884:      	mov	x1, #0x0                // =0
     888:      	bl	0x770 <strtoul@plt>
     88c:      	mov	x19, x0
     890:      	add	x1, sp, #0x10
     894:      	mov	w0, #0x1                // =1
     898:      	bl	0x7a0 <clock_gettime@plt>
     89c:      	cbnz	w0, 0x9f8 <main+0x1f8>
     8a0:      	cbz	x20, 0x910 <main+0x110>
     8a4:      	mov	w2, w19
     8a8:      	mov	x6, #0x0                // =0
     8ac:      	mov	x7, #0x0                // =0
     8b0:      	eor	w2, w2, w2, lsl #13
     8b4:      	mov	w4, #0x4                // =4
     8b8:      	eor	w2, w2, w2, lsr #17
     8bc:      	eor	w5, w2, w2, lsl #5
     8c0:      	mov	w1, w5
     8c4:      	eor	w2, w5, w5, lsl #13
     8c8:      	eor	w2, w2, w2, lsr #17
     8cc:      	eor	w2, w2, w2, lsl #5
     8d0:      	mov	w3, w2
     8d4:      	add	w1, w1, w3, uxtb
     8d8:      	subs	w4, w4, #0x1
     8dc:      	lsr	w3, w3, #8
     8e0:      	add	w1, w1, w1, lsl #10
     8e4:      	eor	w1, w1, w1, lsr #6
     8e8:      	b.ne	0x8d4 <main+0xd4>
     8ec:      	add	w1, w1, w1, lsl #3
     8f0:      	add	x6, x6, #0x1
     8f4:      	eor	w1, w1, w1, lsr #11
     8f8:      	add	w1, w1, w1, lsl #15
     8fc:      	add	x7, x7, x1
     900:      	cmp	x20, x6
     904:      	b.ne	0x8b0 <main+0xb0>
     908:      	mov	x20, x7
     90c:      	stp	w5, w2, [sp, #0x20]
     910:      	mov	x1, sp
     914:      	mov	w0, #0x1                // =1
     918:      	bl	0x7a0 <clock_gettime@plt>
     91c:      	cbnz	w0, 0x9f8 <main+0x1f8>
     920:      	adrp	x1, 0x0 <strtoul@GLIBC_2.17>
     924:      	mov	x2, x20
     928:      	ldp	x3, x0, [sp]
     92c:      	ldr	d1, [x1, #0xb98]
     930:      	ldp	x4, x1, [sp, #0x10]
     934:      	sub	x0, x0, x1
     938:      	sub	x3, x3, x4
     93c:      	adrp	x1, 0x0 <strtoul@GLIBC_2.17>
     940:      	add	x1, x1, #0xb88
     944:      	scvtf	d0, x0
     948:      	mov	w0, #0x2                // =2
     94c:      	fmul	d0, d0, d1
     950:      	scvtf	d1, x3
     954:      	fadd	d0, d0, d1
     958:      	bl	0x7b0 <__printf_chk@plt>
     95c:      	b	0x9ec <main+0x1ec>
     960:      	stp	x19, x20, [sp, #0x40]
     964:      	adrp	x19, 0x0 <strtoul@GLIBC_2.17>
     968:      	add	x19, x19, #0xb80
     96c:      	stp	x21, x22, [sp, #0x50]
     970:      	add	x22, sp, #0x20
     974:      	add	x21, sp, #0x24
     978:      	adrp	x20, 0x0 <strtoul@GLIBC_2.17>
     97c:      	mov	x2, x21
     980:      	add	x20, x20, #0xb78
     984:      	mov	x1, x22
     988:      	mov	x0, x19
     98c:      	bl	0x7f0 <__isoc99_scanf@plt>
     990:      	cmp	w0, #0x2
     994:      	b.ne	0x9e8 <main+0x1e8>
     998:      	ldp	w2, w0, [sp, #0x20]
     99c:      	mov	w1, #0x4                // =4
     9a0:      	add	w2, w2, w0, uxtb
     9a4:      	subs	w1, w1, #0x1
     9a8:      	lsr	w0, w0, #8
     9ac:      	add	w2, w2, w2, lsl #10
     9b0:      	eor	w2, w2, w2, lsr #6
     9b4:      	b.ne	0x9a0 <main+0x1a0>
     9b8:      	add	w2, w2, w2, lsl #3
     9bc:      	mov	x1, x20
     9c0:      	mov	w0, #0x2                // =2
     9c4:      	eor	w2, w2, w2, lsr #11
     9c8:      	add	w2, w2, w2, lsl #15
     9cc:      	bl	0x7b0 <__printf_chk@plt>
     9d0:      	mov	x2, x21
     9d4:      	mov	x1, x22
     9d8:      	mov	x0, x19
     9dc:      	bl	0x7f0 <__isoc99_scanf@plt>
     9e0:      	cmp	w0, #0x2
     9e4:      	b.eq	0x998 <main+0x198>
     9e8:      	ldp	x21, x22, [sp, #0x50]
     9ec:      	mov	w0, #0x0                // =0
     9f0:      	ldp	x19, x20, [sp, #0x40]
     9f4:      	b	0x838 <main+0x38>
     9f8:      	ldp	x19, x20, [sp, #0x40]
     9fc:      	mov	w0, #0x2                // =2
     a00:      	b	0x838 <main+0x38>
     a04:      	stp	x19, x20, [sp, #0x40]
     a08:      	stp	x21, x22, [sp, #0x50]
     a0c:      	bl	0x7c0 <__stack_chk_fail@plt>
     a10:      	nop
     a14:      	nop
     a18:      	nop
     a1c:      	nop
     a20:      	nop
     a24:      	nop
     a28:      	nop
     a2c:      	nop
     a30:      	nop
     a34:      	nop
     a38:      	nop
     a3c:      	nop

0000000000000a40 <_start>:
     a40:      	nop
     a44:      	mov	x29, #0x0               // =0
     a48:      	mov	x30, #0x0               // =0
     a4c:      	mov	x5, x0
     a50:      	ldr	x1, [sp]
     a54:      	add	x2, sp, #0x8
     a58:      	mov	x6, sp
     a5c:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e344>
     a60:      	ldr	x0, [x0, #0xff0]
     a64:      	mov	x3, #0x0                // =0
     a68:      	mov	x4, #0x0                // =0
     a6c:      	bl	0x780 <__libc_start_main@plt>
     a70:      	bl	0x7e0 <abort@plt>

0000000000000a74 <call_weak_fn>:
     a74:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e344>
     a78:      	ldr	x0, [x0, #0xfe0]
     a7c:      	cbz	x0, 0xa84 <call_weak_fn+0x10>
     a80:      	b	0x7d0 <__gmon_start__@plt>
     a84:      	ret
     a88:      	nop
     a8c:      	nop

0000000000000a90 <deregister_tm_clones>:
     a90:      	adrp	x0, 0x20000 <data_start>
     a94:      	add	x0, x0, #0x10
     a98:      	adrp	x1, 0x20000 <data_start>
     a9c:      	add	x1, x1, #0x10
     aa0:      	cmp	x1, x0
     aa4:      	b.eq	0xabc <deregister_tm_clones+0x2c>
     aa8:      	adrp	x1, 0x1f000 <__FRAME_END__+0x1e344>
     aac:      	ldr	x1, [x1, #0xfd0]
     ab0:      	cbz	x1, 0xabc <deregister_tm_clones+0x2c>
     ab4:      	mov	x16, x1
     ab8:      	br	x16
     abc:      	ret

0000000000000ac0 <register_tm_clones>:
     ac0:      	adrp	x0, 0x20000 <data_start>
     ac4:      	add	x0, x0, #0x10
     ac8:      	adrp	x1, 0x20000 <data_start>
     acc:      	add	x1, x1, #0x10
     ad0:      	sub	x1, x1, x0
     ad4:      	lsr	x2, x1, #63
     ad8:      	add	x1, x2, x1, asr #3
     adc:      	asr	x1, x1, #1
     ae0:      	cbz	x1, 0xaf8 <register_tm_clones+0x38>
     ae4:      	adrp	x2, 0x1f000 <__FRAME_END__+0x1e344>
     ae8:      	ldr	x2, [x2, #0xff8]
     aec:      	cbz	x2, 0xaf8 <register_tm_clones+0x38>
     af0:      	mov	x16, x2
     af4:      	br	x16
     af8:      	ret
     afc:      	nop

0000000000000b00 <__do_global_dtors_aux>:
     b00:      	paciasp
     b04:      	stp	x29, x30, [sp, #-0x20]!
     b08:      	mov	x29, sp
     b0c:      	str	x19, [sp, #0x10]
     b10:      	adrp	x19, 0x20000 <data_start>
     b14:      	ldrb	w0, [x19, #0x10]
     b18:      	tbnz	w0, #0x0, 0xb40 <__do_global_dtors_aux+0x40>
     b1c:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e344>
     b20:      	ldr	x0, [x0, #0xfd8]
     b24:      	cbz	x0, 0xb34 <__do_global_dtors_aux+0x34>
     b28:      	adrp	x0, 0x20000 <data_start>
     b2c:      	ldr	x0, [x0, #0x8]
     b30:      	bl	0x790 <__cxa_finalize@plt>
     b34:      	bl	0xa90 <deregister_tm_clones>
     b38:      	mov	w0, #0x1                // =1
     b3c:      	strb	w0, [x19, #0x10]
     b40:      	ldr	x19, [sp, #0x10]
     b44:      	ldp	x29, x30, [sp], #0x20
     b48:      	autiasp
     b4c:      	ret

0000000000000b50 <frame_dummy>:
     b50:      	bti	c
     b54:      	b	0xac0 <register_tm_clones>

Disassembly of section .fini:

0000000000000b58 <_fini>:
     b58:      	nop
     b5c:      	stp	x29, x30, [sp, #-0x10]!
     b60:      	mov	x29, sp
     b64:      	ldp	x29, x30, [sp], #0x10
     b68:      	ret
