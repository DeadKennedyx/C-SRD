; ModuleID = '/work/experiments/runs/jenkins-composition-matrix-linux-20261110/jenkins_word/build-clang-O1-sanitizers-limbs16/validation/compiler-0-O1/candidate.i'
source_filename = "/work/experiments/runs/jenkins-composition-matrix-linux-20261110/jenkins_word/build-clang-O1-sanitizers-limbs16/validation/compiler-0-O1/candidate.i"
target datalayout = "e-m:e-i8:8:32-i16:16:32-i64:64-i128:128-n32:64-S128"
target triple = "aarch64-unknown-linux-gnu"

$asan.module_ctor = comdat any

@llvm.used = appending global [1 x ptr] [ptr @asan.module_ctor], section "llvm.metadata"
@___asan_globals_registered = common hidden global i64 0
@__start_asan_globals = extern_weak hidden global i64
@__stop_asan_globals = extern_weak hidden global i64
@llvm.global_ctors = appending global [1 x { i32, ptr, ptr }] [{ i32, ptr, ptr } { i32 1, ptr @asan.module_ctor, ptr @asan.module_ctor }]

; Function Attrs: mustprogress nofree norecurse nosync nounwind sanitize_address willreturn memory(none) uwtable
define dso_local i32 @kernel(i32 noundef %state, i32 noundef %word) local_unnamed_addr #0 !func_sanitize !6 {
entry:
  %and = and i32 %state, 65535
  %shr = lshr i32 %state, 16
  %and5 = and i32 %word, 255
  %add = add nuw nsw i32 %and5, %and
  %and7 = and i32 %add, 65535
  %shr11 = lshr i32 %add, 16
  %add12 = add nuw nsw i32 %shr11, %shr
  %shl = shl nuw nsw i32 %add, 10
  %and16 = and i32 %shl, 64512
  %shl19 = shl nuw nsw i32 %add12, 10
  %shr22 = lshr i32 %and7, 6
  %add24 = add nuw nsw i32 %and16, %and7
  %and25 = and i32 %add24, 65535
  %shr29 = lshr i32 %add24, 16
  %and23 = add nuw nsw i32 %add12, %shr22
  %add26 = add nuw nsw i32 %and23, %shl19
  %add30 = add nuw nsw i32 %add26, %shr29
  %and31 = and i32 %add30, 65535
  %shr34 = lshr i32 %and25, 6
  %shl37 = shl nuw nsw i32 %and31, 10
  %shl37.masked = and i32 %shl37, 64512
  %and39 = or disjoint i32 %shl37.masked, %shr34
  %shr42 = lshr i32 %and31, 6
  %xor = xor i32 %and39, %and25
  %xor43 = xor i32 %shr42, %add30
  %and1 = lshr i32 %word, 8
  %shr46 = and i32 %and1, 255
  %0 = lshr i32 %word, 16
  %shl49.masked = and i32 %0, 255
  %add57 = add nuw nsw i32 %xor, %shr46
  %and58 = and i32 %add57, 65535
  %shr62 = lshr i32 %add57, 16
  %add63 = add nuw nsw i32 %shr62, %xor43
  %shl67 = shl nuw nsw i32 %and58, 10
  %and68 = and i32 %shl67, 64512
  %and64 = shl i32 %add63, 10
  %shr74 = lshr i32 %and58, 6
  %add77 = add nuw nsw i32 %and68, %and58
  %and78 = and i32 %add77, 65535
  %shr82 = lshr i32 %add77, 16
  %and76 = add nuw nsw i32 %add63, %shr74
  %add79 = add i32 %and76, %and64
  %add83 = add i32 %add79, %shr82
  %and84 = and i32 %add83, 65535
  %shr87 = lshr i32 %and78, 6
  %shl90 = shl nuw nsw i32 %and84, 10
  %shl90.masked = and i32 %shl90, 64512
  %and92 = or disjoint i32 %shl90.masked, %shr87
  %shr95 = lshr i32 %and84, 6
  %xor96 = xor i32 %and92, %and78
  %xor97 = xor i32 %shr95, %add83
  %or104 = lshr i32 %word, 24
  %add111 = add nuw nsw i32 %xor96, %shl49.masked
  %and112 = and i32 %add111, 65535
  %shr116 = lshr i32 %add111, 16
  %add117 = add i32 %shr116, %xor97
  %shl121 = shl nuw nsw i32 %and112, 10
  %and122 = and i32 %shl121, 64512
  %and118 = shl i32 %add117, 10
  %shr128 = lshr i32 %and112, 6
  %add131 = add nuw nsw i32 %and122, %and112
  %and132 = and i32 %add131, 65535
  %shr136 = lshr i32 %add131, 16
  %and130 = add i32 %add117, %shr128
  %add133 = add i32 %and130, %and118
  %add137 = add i32 %add133, %shr136
  %and138 = and i32 %add137, 65535
  %shr141 = lshr i32 %and132, 6
  %shl144 = shl nuw nsw i32 %and138, 10
  %shl144.masked = and i32 %shl144, 64512
  %and146 = or disjoint i32 %shl144.masked, %shr141
  %shr149 = lshr i32 %and138, 6
  %xor150 = xor i32 %and146, %and132
  %xor151 = xor i32 %shr149, %add137
  %add165 = add nuw nsw i32 %xor150, %or104
  %and166 = and i32 %add165, 65535
  %shr170 = lshr i32 %add165, 16
  %add171 = add i32 %shr170, %xor151
  %shl175 = shl nuw nsw i32 %and166, 10
  %and176 = and i32 %shl175, 64512
  %and172 = shl i32 %add171, 10
  %shr182 = lshr i32 %and166, 6
  %add185 = add nuw nsw i32 %and176, %and166
  %and186 = and i32 %add185, 65535
  %shr190 = lshr i32 %add185, 16
  %and184 = add i32 %add171, %shr182
  %add187 = add i32 %and184, %and172
  %add191 = add i32 %add187, %shr190
  %and192 = and i32 %add191, 65535
  %shr195 = lshr i32 %and186, 6
  %shl198 = shl nuw nsw i32 %and192, 10
  %shl198.masked = and i32 %shl198, 64512
  %and200 = or disjoint i32 %shl198.masked, %shr195
  %shr203 = lshr i32 %and192, 6
  %xor204 = xor i32 %and200, %and186
  %xor205 = xor i32 %shr203, %add191
  %shl208 = shl nuw nsw i32 %xor204, 3
  %and209 = and i32 %shl208, 65528
  %shr215 = lshr i32 %xor204, 13
  %add218 = add nuw nsw i32 %and209, %xor204
  %and219 = and i32 %add218, 65535
  %shr223 = lshr i32 %add218, 16
  %and217 = mul i32 %xor205, 9
  %add220 = add i32 %and217, %shr215
  %add224 = add i32 %add220, %shr223
  %and225 = and i32 %add224, 65535
  %shr228 = lshr i32 %and219, 11
  %shl231 = shl nuw nsw i32 %and225, 5
  %shl231.masked = and i32 %shl231, 65504
  %and233 = or disjoint i32 %shl231.masked, %shr228
  %shr236 = lshr i32 %and225, 11
  %xor237 = xor i32 %and233, %and219
  %xor238 = xor i32 %shr236, %add224
  %shl241 = shl nuw nsw i32 %xor237, 15
  %and242 = and i32 %shl241, 32768
  %shr248 = lshr i32 %xor237, 1
  %add251 = add nuw nsw i32 %and242, %xor237
  %and250 = mul i32 %xor238, 32769
  %add253 = add i32 %and250, %shr248
  %add257398 = shl i32 %add253, 16
  %shr256399 = add i32 %add251, %add257398
  ret i32 %shr256399
}

declare void @__asan_register_elf_globals(i64, i64, i64)

declare void @__asan_init()

; Function Attrs: nounwind uwtable
define internal void @asan.module_ctor() #1 comdat {
  call void @__asan_init()
  call void @__asan_version_mismatch_check_v8()
  call void @__asan_register_elf_globals(i64 ptrtoint (ptr @___asan_globals_registered to i64), i64 ptrtoint (ptr @__start_asan_globals to i64), i64 ptrtoint (ptr @__stop_asan_globals to i64))
  ret void
}

declare void @__asan_version_mismatch_check_v8()

attributes #0 = { mustprogress nofree norecurse nosync nounwind sanitize_address willreturn memory(none) uwtable "frame-pointer"="non-leaf" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+fp-armv8,+neon,+outline-atomics,+v8a,-fmv" }
attributes #1 = { nounwind uwtable "frame-pointer"="non-leaf" }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 1, !"wchar_size", i32 4}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 1}
!5 = !{!"Ubuntu clang version 18.1.3 (1ubuntu1)"}
!6 = !{i32 -1056584962, i32 -455559067}
