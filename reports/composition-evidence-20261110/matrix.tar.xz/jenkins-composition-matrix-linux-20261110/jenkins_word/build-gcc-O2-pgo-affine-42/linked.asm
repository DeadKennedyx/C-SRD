
/work/experiments/runs/jenkins-composition-matrix-linux-20261110/jenkins_word/build-gcc-O2-pgo-affine-42/program:	file format elf64-littleaarch64

Disassembly of section .init:

0000000000000738 <_init>:
     738:      	nop
     73c:      	stp	x29, x30, [sp, #-0x10]!
     740:      	mov	x29, sp
     744:      	bl	0xa74 <call_weak_fn>
     748:      	ldp	x29, x30, [sp], #0x10
     74c:      	ret

Disassembly of section .plt:

0000000000000750 <.plt>:
     750:      	stp	x16, x30, [sp, #-0x10]!
     754:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e318>
     758:      	ldr	x17, [x16, #0xf78]
     75c:      	add	x16, x16, #0xf78
     760:      	br	x17
     764:      	nop
     768:      	nop
     76c:      	nop

0000000000000770 <strtoul@plt>:
     770:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e318>
     774:      	ldr	x17, [x16, #0xf80]
     778:      	add	x16, x16, #0xf80
     77c:      	br	x17

0000000000000780 <__libc_start_main@plt>:
     780:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e318>
     784:      	ldr	x17, [x16, #0xf88]
     788:      	add	x16, x16, #0xf88
     78c:      	br	x17

0000000000000790 <__cxa_finalize@plt>:
     790:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e318>
     794:      	ldr	x17, [x16, #0xf90]
     798:      	add	x16, x16, #0xf90
     79c:      	br	x17

00000000000007a0 <clock_gettime@plt>:
     7a0:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e318>
     7a4:      	ldr	x17, [x16, #0xf98]
     7a8:      	add	x16, x16, #0xf98
     7ac:      	br	x17

00000000000007b0 <__printf_chk@plt>:
     7b0:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e318>
     7b4:      	ldr	x17, [x16, #0xfa0]
     7b8:      	add	x16, x16, #0xfa0
     7bc:      	br	x17

00000000000007c0 <__stack_chk_fail@plt>:
     7c0:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e318>
     7c4:      	ldr	x17, [x16, #0xfa8]
     7c8:      	add	x16, x16, #0xfa8
     7cc:      	br	x17

00000000000007d0 <__gmon_start__@plt>:
     7d0:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e318>
     7d4:      	ldr	x17, [x16, #0xfb0]
     7d8:      	add	x16, x16, #0xfb0
     7dc:      	br	x17

00000000000007e0 <abort@plt>:
     7e0:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e318>
     7e4:      	ldr	x17, [x16, #0xfb8]
     7e8:      	add	x16, x16, #0xfb8
     7ec:      	br	x17

00000000000007f0 <__isoc99_scanf@plt>:
     7f0:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e318>
     7f4:      	ldr	x17, [x16, #0xfc0]
     7f8:      	add	x16, x16, #0xfc0
     7fc:      	br	x17

Disassembly of section .text:

0000000000000800 <main>:
     800:      	sub	sp, sp, #0x70
     804:      	adrp	x2, 0x1f000 <__FRAME_END__+0x1e318>
     808:      	ldr	x2, [x2, #0xfe8]
     80c:      	stp	x29, x30, [sp, #0x30]
     810:      	add	x29, sp, #0x30
     814:      	ldr	x3, [x2]
     818:      	str	x3, [sp, #0x28]
     81c:      	mov	x3, #0x0                // =0
     820:      	cmp	w0, #0x1
     824:      	b.ne	0x8bc <main+0xbc>
     828:      	stp	x19, x20, [sp, #0x40]
     82c:      	adrp	x20, 0x0 <strtoul@GLIBC_2.17>
     830:      	add	x20, x20, #0xb80
     834:      	stp	x21, x22, [sp, #0x50]
     838:      	adrp	x21, 0x0 <strtoul@GLIBC_2.17>
     83c:      	add	x22, sp, #0x24
     840:      	add	x21, x21, #0xb78
     844:      	str	x23, [sp, #0x60]
     848:      	add	x23, sp, #0x20
     84c:      	b	0x868 <main+0x68>
     850:      	ldp	w0, w1, [sp, #0x20]
     854:      	bl	0x9c0 <kernel>
     858:      	mov	w2, w0
     85c:      	mov	x1, x21
     860:      	mov	w0, w19
     864:      	bl	0x7b0 <__printf_chk@plt>
     868:      	mov	x2, x22
     86c:      	mov	x1, x23
     870:      	mov	x0, x20
     874:      	bl	0x7f0 <__isoc99_scanf@plt>
     878:      	mov	w19, w0
     87c:      	cmp	w0, #0x2
     880:      	b.eq	0x850 <main+0x50>
     884:      	ldr	x23, [sp, #0x60]
     888:      	mov	w0, #0x0                // =0
     88c:      	ldp	x19, x20, [sp, #0x40]
     890:      	ldp	x21, x22, [sp, #0x50]
     894:      	adrp	x1, 0x1f000 <__FRAME_END__+0x1e318>
     898:      	ldr	x1, [x1, #0xfe8]
     89c:      	ldr	x3, [sp, #0x28]
     8a0:      	ldr	x2, [x1]
     8a4:      	subs	x3, x3, x2
     8a8:      	mov	x2, #0x0                // =0
     8ac:      	b.ne	0x970 <main+0x170>
     8b0:      	ldp	x29, x30, [sp, #0x30]
     8b4:      	add	sp, sp, #0x70
     8b8:      	ret
     8bc:      	cmp	w0, #0x3
     8c0:      	b.eq	0x8cc <main+0xcc>
     8c4:      	mov	w0, #0x3                // =3
     8c8:      	b	0x894 <main+0x94>
     8cc:      	stp	x19, x20, [sp, #0x40]
     8d0:      	mov	x19, x1
     8d4:      	mov	w2, #0xa                // =10
     8d8:      	mov	x1, #0x0                // =0
     8dc:      	stp	x21, x22, [sp, #0x50]
     8e0:      	ldr	x0, [x19, #0x8]
     8e4:      	bl	0x770 <strtoul@plt>
     8e8:      	mov	x22, x0
     8ec:      	ldr	x0, [x19, #0x10]
     8f0:      	mov	w2, #0xa                // =10
     8f4:      	mov	x1, #0x0                // =0
     8f8:      	bl	0x770 <strtoul@plt>
     8fc:      	mov	w19, w0
     900:      	mov	x1, sp
     904:      	mov	w0, #0x1                // =1
     908:      	bl	0x7a0 <clock_gettime@plt>
     90c:      	cbnz	w0, 0x960 <main+0x160>
     910:      	mov	x21, #0x0               // =0
     914:      	mov	x20, #0x0               // =0
     918:      	cmp	x21, x22
     91c:      	b.eq	0x950 <main+0x150>
     920:      	eor	w0, w19, w19, lsl #13
     924:      	add	x21, x21, #0x1
     928:      	eor	w0, w0, w0, lsr #17
     92c:      	eor	w0, w0, w0, lsl #5
     930:      	eor	w19, w0, w0, lsl #13
     934:      	eor	w19, w19, w19, lsr #17
     938:      	eor	w19, w19, w19, lsl #5
     93c:      	stp	w0, w19, [sp, #0x20]
     940:      	mov	w1, w19
     944:      	bl	0x9c0 <kernel>
     948:      	add	x20, x20, w0, uxtw
     94c:      	b	0x918 <main+0x118>
     950:      	add	x1, sp, #0x10
     954:      	mov	w0, #0x1                // =1
     958:      	bl	0x7a0 <clock_gettime@plt>
     95c:      	cbz	w0, 0x980 <main+0x180>
     960:      	ldp	x19, x20, [sp, #0x40]
     964:      	mov	w0, #0x2                // =2
     968:      	ldp	x21, x22, [sp, #0x50]
     96c:      	b	0x894 <main+0x94>
     970:      	stp	x19, x20, [sp, #0x40]
     974:      	stp	x21, x22, [sp, #0x50]
     978:      	str	x23, [sp, #0x60]
     97c:      	bl	0x7c0 <__stack_chk_fail@plt>
     980:      	adrp	x0, 0x0 <strtoul@GLIBC_2.17>
     984:      	mov	x2, x20
     988:      	ldp	x4, x1, [sp]
     98c:      	ldr	d1, [x0, #0xb98]
     990:      	ldp	x3, x0, [sp, #0x10]
     994:      	sub	x0, x0, x1
     998:      	sub	x3, x3, x4
     99c:      	adrp	x1, 0x0 <strtoul@GLIBC_2.17>
     9a0:      	add	x1, x1, #0xb88
     9a4:      	scvtf	d0, x0
     9a8:      	mov	w0, #0x2                // =2
     9ac:      	fmul	d0, d0, d1
     9b0:      	scvtf	d1, x3
     9b4:      	fadd	d0, d0, d1
     9b8:      	bl	0x7b0 <__printf_chk@plt>
     9bc:      	b	0x888 <main+0x88>

00000000000009c0 <kernel>:
     9c0:      	add	w0, w0, w1, uxtb
     9c4:      	ubfx	x3, x1, #8, #8
     9c8:      	ubfx	x2, x1, #16, #8
     9cc:      	add	w0, w0, w0, lsl #10
     9d0:      	eor	w0, w0, w0, lsr #6
     9d4:      	add	w0, w0, w3
     9d8:      	add	w0, w0, w0, lsl #10
     9dc:      	eor	w0, w0, w0, lsr #6
     9e0:      	add	w0, w0, w2
     9e4:      	add	w0, w0, w0, lsl #10
     9e8:      	eor	w0, w0, w0, lsr #6
     9ec:      	add	w0, w0, w1, lsr #24
     9f0:      	add	w0, w0, w0, lsl #10
     9f4:      	eor	w0, w0, w0, lsr #6
     9f8:      	add	w0, w0, w0, lsl #3
     9fc:      	eor	w0, w0, w0, lsr #11
     a00:      	add	w0, w0, w0, lsl #15
     a04:      	ret
     a08:      	nop
     a0c:      	nop
     a10:      	nop
     a14:      	nop
     a18:      	nop
     a1c:      	nop
     a20:      	nop
     a24:      	nop
     a28:      	nop
     a2c:      	nop
     a30:      	nop
     a34:      	nop
     a38:      	nop
     a3c:      	nop

0000000000000a40 <_start>:
     a40:      	nop
     a44:      	mov	x29, #0x0               // =0
     a48:      	mov	x30, #0x0               // =0
     a4c:      	mov	x5, x0
     a50:      	ldr	x1, [sp]
     a54:      	add	x2, sp, #0x8
     a58:      	mov	x6, sp
     a5c:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e318>
     a60:      	ldr	x0, [x0, #0xff0]
     a64:      	mov	x3, #0x0                // =0
     a68:      	mov	x4, #0x0                // =0
     a6c:      	bl	0x780 <__libc_start_main@plt>
     a70:      	bl	0x7e0 <abort@plt>

0000000000000a74 <call_weak_fn>:
     a74:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e318>
     a78:      	ldr	x0, [x0, #0xfe0]
     a7c:      	cbz	x0, 0xa84 <call_weak_fn+0x10>
     a80:      	b	0x7d0 <__gmon_start__@plt>
     a84:      	ret
     a88:      	nop
     a8c:      	nop

0000000000000a90 <deregister_tm_clones>:
     a90:      	adrp	x0, 0x20000 <data_start>
     a94:      	add	x0, x0, #0x10
     a98:      	adrp	x1, 0x20000 <data_start>
     a9c:      	add	x1, x1, #0x10
     aa0:      	cmp	x1, x0
     aa4:      	b.eq	0xabc <deregister_tm_clones+0x2c>
     aa8:      	adrp	x1, 0x1f000 <__FRAME_END__+0x1e318>
     aac:      	ldr	x1, [x1, #0xfd0]
     ab0:      	cbz	x1, 0xabc <deregister_tm_clones+0x2c>
     ab4:      	mov	x16, x1
     ab8:      	br	x16
     abc:      	ret

0000000000000ac0 <register_tm_clones>:
     ac0:      	adrp	x0, 0x20000 <data_start>
     ac4:      	add	x0, x0, #0x10
     ac8:      	adrp	x1, 0x20000 <data_start>
     acc:      	add	x1, x1, #0x10
     ad0:      	sub	x1, x1, x0
     ad4:      	lsr	x2, x1, #63
     ad8:      	add	x1, x2, x1, asr #3
     adc:      	asr	x1, x1, #1
     ae0:      	cbz	x1, 0xaf8 <register_tm_clones+0x38>
     ae4:      	adrp	x2, 0x1f000 <__FRAME_END__+0x1e318>
     ae8:      	ldr	x2, [x2, #0xff8]
     aec:      	cbz	x2, 0xaf8 <register_tm_clones+0x38>
     af0:      	mov	x16, x2
     af4:      	br	x16
     af8:      	ret
     afc:      	nop

0000000000000b00 <__do_global_dtors_aux>:
     b00:      	paciasp
     b04:      	stp	x29, x30, [sp, #-0x20]!
     b08:      	mov	x29, sp
     b0c:      	str	x19, [sp, #0x10]
     b10:      	adrp	x19, 0x20000 <data_start>
     b14:      	ldrb	w0, [x19, #0x10]
     b18:      	tbnz	w0, #0x0, 0xb40 <__do_global_dtors_aux+0x40>
     b1c:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e318>
     b20:      	ldr	x0, [x0, #0xfd8]
     b24:      	cbz	x0, 0xb34 <__do_global_dtors_aux+0x34>
     b28:      	adrp	x0, 0x20000 <data_start>
     b2c:      	ldr	x0, [x0, #0x8]
     b30:      	bl	0x790 <__cxa_finalize@plt>
     b34:      	bl	0xa90 <deregister_tm_clones>
     b38:      	mov	w0, #0x1                // =1
     b3c:      	strb	w0, [x19, #0x10]
     b40:      	ldr	x19, [sp, #0x10]
     b44:      	ldp	x29, x30, [sp], #0x20
     b48:      	autiasp
     b4c:      	ret

0000000000000b50 <frame_dummy>:
     b50:      	bti	c
     b54:      	b	0xac0 <register_tm_clones>

Disassembly of section .fini:

0000000000000b58 <_fini>:
     b58:      	nop
     b5c:      	stp	x29, x30, [sp, #-0x10]!
     b60:      	mov	x29, sp
     b64:      	ldp	x29, x30, [sp], #0x10
     b68:      	ret
