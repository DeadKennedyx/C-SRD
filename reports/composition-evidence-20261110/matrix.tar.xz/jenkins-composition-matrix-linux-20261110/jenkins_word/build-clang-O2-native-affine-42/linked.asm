
/work/experiments/runs/jenkins-composition-matrix-linux-20261110/jenkins_word/build-clang-O2-native-affine-42/program:	file format elf64-littleaarch64

Disassembly of section .init:

0000000000000678 <_init>:
     678:      	nop
     67c:      	stp	x29, x30, [sp, #-0x10]!
     680:      	mov	x29, sp
     684:      	bl	0x774 <call_weak_fn>
     688:      	ldp	x29, x30, [sp], #0x10
     68c:      	ret

Disassembly of section .plt:

0000000000000690 <.plt>:
     690:      	stp	x16, x30, [sp, #-0x10]!
     694:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e498>
     698:      	ldr	x17, [x16, #0xff8]
     69c:      	add	x16, x16, #0xff8
     6a0:      	br	x17
     6a4:      	nop
     6a8:      	nop
     6ac:      	nop

00000000000006b0 <strtoul@plt>:
     6b0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6b4:      	ldr	x17, [x16]
     6b8:      	add	x16, x16, #0x0
     6bc:      	br	x17

00000000000006c0 <__libc_start_main@plt>:
     6c0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6c4:      	ldr	x17, [x16, #0x8]
     6c8:      	add	x16, x16, #0x8
     6cc:      	br	x17

00000000000006d0 <__cxa_finalize@plt>:
     6d0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6d4:      	ldr	x17, [x16, #0x10]
     6d8:      	add	x16, x16, #0x10
     6dc:      	br	x17

00000000000006e0 <clock_gettime@plt>:
     6e0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6e4:      	ldr	x17, [x16, #0x18]
     6e8:      	add	x16, x16, #0x18
     6ec:      	br	x17

00000000000006f0 <__gmon_start__@plt>:
     6f0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6f4:      	ldr	x17, [x16, #0x20]
     6f8:      	add	x16, x16, #0x20
     6fc:      	br	x17

0000000000000700 <abort@plt>:
     700:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     704:      	ldr	x17, [x16, #0x28]
     708:      	add	x16, x16, #0x28
     70c:      	br	x17

0000000000000710 <__isoc99_scanf@plt>:
     710:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     714:      	ldr	x17, [x16, #0x30]
     718:      	add	x16, x16, #0x30
     71c:      	br	x17

0000000000000720 <printf@plt>:
     720:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     724:      	ldr	x17, [x16, #0x38]
     728:      	add	x16, x16, #0x38
     72c:      	br	x17

Disassembly of section .text:

0000000000000740 <_start>:
     740:      	nop
     744:      	mov	x29, #0x0               // =0
     748:      	mov	x30, #0x0               // =0
     74c:      	mov	x5, x0
     750:      	ldr	x1, [sp]
     754:      	add	x2, sp, #0x8
     758:      	mov	x6, sp
     75c:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e498>
     760:      	ldr	x0, [x0, #0xfd8]
     764:      	mov	x3, #0x0                // =0
     768:      	mov	x4, #0x0                // =0
     76c:      	bl	0x6c0 <__libc_start_main@plt>
     770:      	bl	0x700 <abort@plt>

0000000000000774 <call_weak_fn>:
     774:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e498>
     778:      	ldr	x0, [x0, #0xfd0]
     77c:      	cbz	x0, 0x784 <call_weak_fn+0x10>
     780:      	b	0x6f0 <__gmon_start__@plt>
     784:      	ret
     788:      	nop
     78c:      	nop

0000000000000790 <deregister_tm_clones>:
     790:      	adrp	x0, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     794:      	add	x0, x0, #0x50
     798:      	adrp	x1, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     79c:      	add	x1, x1, #0x50
     7a0:      	cmp	x1, x0
     7a4:      	b.eq	0x7bc <deregister_tm_clones+0x2c>
     7a8:      	adrp	x1, 0x1f000 <__FRAME_END__+0x1e498>
     7ac:      	ldr	x1, [x1, #0xfc0]
     7b0:      	cbz	x1, 0x7bc <deregister_tm_clones+0x2c>
     7b4:      	mov	x16, x1
     7b8:      	br	x16
     7bc:      	ret

00000000000007c0 <register_tm_clones>:
     7c0:      	adrp	x0, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     7c4:      	add	x0, x0, #0x50
     7c8:      	adrp	x1, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     7cc:      	add	x1, x1, #0x50
     7d0:      	sub	x1, x1, x0
     7d4:      	lsr	x2, x1, #63
     7d8:      	add	x1, x2, x1, asr #3
     7dc:      	asr	x1, x1, #1
     7e0:      	cbz	x1, 0x7f8 <register_tm_clones+0x38>
     7e4:      	adrp	x2, 0x1f000 <__FRAME_END__+0x1e498>
     7e8:      	ldr	x2, [x2, #0xfe0]
     7ec:      	cbz	x2, 0x7f8 <register_tm_clones+0x38>
     7f0:      	mov	x16, x2
     7f4:      	br	x16
     7f8:      	ret
     7fc:      	nop

0000000000000800 <__do_global_dtors_aux>:
     800:      	paciasp
     804:      	stp	x29, x30, [sp, #-0x20]!
     808:      	mov	x29, sp
     80c:      	str	x19, [sp, #0x10]
     810:      	adrp	x19, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     814:      	ldrb	w0, [x19, #0x50]
     818:      	tbnz	w0, #0x0, 0x840 <__do_global_dtors_aux+0x40>
     81c:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e498>
     820:      	ldr	x0, [x0, #0xfc8]
     824:      	cbz	x0, 0x834 <__do_global_dtors_aux+0x34>
     828:      	adrp	x0, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     82c:      	ldr	x0, [x0, #0x48]
     830:      	bl	0x6d0 <__cxa_finalize@plt>
     834:      	bl	0x790 <deregister_tm_clones>
     838:      	mov	w0, #0x1                // =1
     83c:      	strb	w0, [x19, #0x50]
     840:      	ldr	x19, [sp, #0x10]
     844:      	ldp	x29, x30, [sp], #0x20
     848:      	autiasp
     84c:      	ret

0000000000000850 <frame_dummy>:
     850:      	bti	c
     854:      	b	0x7c0 <register_tm_clones>

0000000000000858 <kernel>:
     858:      	add	w8, w0, w1, uxtb
     85c:      	lsr	w9, w1, #8
     860:      	add	w8, w8, w8, lsl #10
     864:      	eor	w8, w8, w8, lsr #6
     868:      	add	w8, w8, w9, uxtb
     86c:      	lsr	w9, w1, #16
     870:      	add	w8, w8, w8, lsl #10
     874:      	eor	w8, w8, w8, lsr #6
     878:      	add	w8, w8, w9, uxtb
     87c:      	add	w8, w8, w8, lsl #10
     880:      	eor	w8, w8, w8, lsr #6
     884:      	add	w8, w8, w1, lsr #24
     888:      	add	w8, w8, w8, lsl #10
     88c:      	eor	w8, w8, w8, lsr #6
     890:      	add	w8, w8, w8, lsl #3
     894:      	eor	w8, w8, w8, lsr #11
     898:      	add	w0, w8, w8, lsl #15
     89c:      	ret

00000000000008a0 <main>:
     8a0:      	sub	sp, sp, #0x50
     8a4:      	stp	x29, x30, [sp, #0x20]
     8a8:      	str	x21, [sp, #0x30]
     8ac:      	stp	x20, x19, [sp, #0x40]
     8b0:      	add	x29, sp, #0x20
     8b4:      	cmp	w0, #0x3
     8b8:      	b.eq	0x924 <main+0x84>
     8bc:      	cmp	w0, #0x1
     8c0:      	b.ne	0x9b0 <main+0x110>
     8c4:      	add	x21, sp, #0x10
     8c8:      	adrp	x0, 0x0 <strtoul@GLIBC_2.17>
     8cc:      	add	x0, x0, #0xa28
     8d0:      	add	x1, sp, #0x10
     8d4:      	add	x2, x21, #0x4
     8d8:      	bl	0x710 <__isoc99_scanf@plt>
     8dc:      	cmp	w0, #0x2
     8e0:      	b.ne	0x9ec <main+0x14c>
     8e4:      	adrp	x19, 0x0 <strtoul@GLIBC_2.17>
     8e8:      	add	x19, x19, #0xa2d
     8ec:      	adrp	x20, 0x0 <strtoul@GLIBC_2.17>
     8f0:      	add	x20, x20, #0xa28
     8f4:      	ldp	w0, w1, [sp, #0x10]
     8f8:      	bl	0x858 <kernel>
     8fc:      	mov	w1, w0
     900:      	mov	x0, x19
     904:      	bl	0x720 <printf@plt>
     908:      	add	x1, sp, #0x10
     90c:      	add	x2, x21, #0x4
     910:      	mov	x0, x20
     914:      	bl	0x710 <__isoc99_scanf@plt>
     918:      	cmp	w0, #0x2
     91c:      	b.eq	0x8f4 <main+0x54>
     920:      	b	0x9ec <main+0x14c>
     924:      	ldr	x0, [x1, #0x8]
     928:      	mov	x19, x1
     92c:      	mov	x1, xzr
     930:      	mov	w2, #0xa                // =10
     934:      	bl	0x6b0 <strtoul@plt>
     938:      	ldr	x8, [x19, #0x10]
     93c:      	mov	x20, x0
     940:      	mov	x1, xzr
     944:      	mov	w2, #0xa                // =10
     948:      	mov	x0, x8
     94c:      	bl	0x6b0 <strtoul@plt>
     950:      	mov	x21, x0
     954:      	add	x1, sp, #0x10
     958:      	mov	w0, #0x1                // =1
     95c:      	bl	0x6e0 <clock_gettime@plt>
     960:      	cbnz	w0, 0x9a8 <main+0x108>
     964:      	mov	x19, xzr
     968:      	cbz	x20, 0x998 <main+0xf8>
     96c:      	eor	w8, w21, w21, lsl #13
     970:      	eor	w8, w8, w8, lsr #17
     974:      	eor	w0, w8, w8, lsl #5
     978:      	eor	w8, w0, w0, lsl #13
     97c:      	eor	w8, w8, w8, lsr #17
     980:      	eor	w21, w8, w8, lsl #5
     984:      	mov	w1, w21
     988:      	bl	0x858 <kernel>
     98c:      	add	x19, x19, w0, uxtw
     990:      	subs	x20, x20, #0x1
     994:      	b.ne	0x96c <main+0xcc>
     998:      	mov	x1, sp
     99c:      	mov	w0, #0x1                // =1
     9a0:      	bl	0x6e0 <clock_gettime@plt>
     9a4:      	cbz	w0, 0x9b8 <main+0x118>
     9a8:      	mov	w0, #0x2                // =2
     9ac:      	b	0x9f0 <main+0x150>
     9b0:      	mov	w0, #0x3                // =3
     9b4:      	b	0x9f0 <main+0x150>
     9b8:      	ldp	x8, x9, [sp]
     9bc:      	adrp	x0, 0x0 <strtoul@GLIBC_2.17>
     9c0:      	add	x0, x0, #0xa31
     9c4:      	ldp	x10, x11, [sp, #0x10]
     9c8:      	mov	x1, x19
     9cc:      	sub	x8, x8, x10
     9d0:      	sub	x9, x9, x11
     9d4:      	scvtf	d0, x8
     9d8:      	scvtf	d1, x9
     9dc:      	adrp	x8, 0x0 <strtoul@GLIBC_2.17>
     9e0:      	ldr	d2, [x8, #0xa20]
     9e4:      	fmadd	d0, d1, d2, d0
     9e8:      	bl	0x720 <printf@plt>
     9ec:      	mov	w0, wzr
     9f0:      	ldp	x20, x19, [sp, #0x40]
     9f4:      	ldr	x21, [sp, #0x30]
     9f8:      	ldp	x29, x30, [sp, #0x20]
     9fc:      	add	sp, sp, #0x50
     a00:      	ret

Disassembly of section .fini:

0000000000000a04 <_fini>:
     a04:      	nop
     a08:      	stp	x29, x30, [sp, #-0x10]!
     a0c:      	mov	x29, sp
     a10:      	ldp	x29, x30, [sp], #0x10
     a14:      	ret
