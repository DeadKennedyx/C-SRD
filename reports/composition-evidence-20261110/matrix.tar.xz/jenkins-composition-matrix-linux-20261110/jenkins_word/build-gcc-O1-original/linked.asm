
/work/experiments/runs/jenkins-composition-matrix-linux-20261110/jenkins_word/build-gcc-O1-original/program:	file format elf64-littleaarch64

Disassembly of section .init:

0000000000000738 <_init>:
     738:      	nop
     73c:      	stp	x29, x30, [sp, #-0x10]!
     740:      	mov	x29, sp
     744:      	bl	0x834 <call_weak_fn>
     748:      	ldp	x29, x30, [sp], #0x10
     74c:      	ret

Disassembly of section .plt:

0000000000000750 <.plt>:
     750:      	stp	x16, x30, [sp, #-0x10]!
     754:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e35c>
     758:      	ldr	x17, [x16, #0xf78]
     75c:      	add	x16, x16, #0xf78
     760:      	br	x17
     764:      	nop
     768:      	nop
     76c:      	nop

0000000000000770 <strtoul@plt>:
     770:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e35c>
     774:      	ldr	x17, [x16, #0xf80]
     778:      	add	x16, x16, #0xf80
     77c:      	br	x17

0000000000000780 <__libc_start_main@plt>:
     780:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e35c>
     784:      	ldr	x17, [x16, #0xf88]
     788:      	add	x16, x16, #0xf88
     78c:      	br	x17

0000000000000790 <__cxa_finalize@plt>:
     790:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e35c>
     794:      	ldr	x17, [x16, #0xf90]
     798:      	add	x16, x16, #0xf90
     79c:      	br	x17

00000000000007a0 <clock_gettime@plt>:
     7a0:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e35c>
     7a4:      	ldr	x17, [x16, #0xf98]
     7a8:      	add	x16, x16, #0xf98
     7ac:      	br	x17

00000000000007b0 <__printf_chk@plt>:
     7b0:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e35c>
     7b4:      	ldr	x17, [x16, #0xfa0]
     7b8:      	add	x16, x16, #0xfa0
     7bc:      	br	x17

00000000000007c0 <__stack_chk_fail@plt>:
     7c0:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e35c>
     7c4:      	ldr	x17, [x16, #0xfa8]
     7c8:      	add	x16, x16, #0xfa8
     7cc:      	br	x17

00000000000007d0 <__gmon_start__@plt>:
     7d0:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e35c>
     7d4:      	ldr	x17, [x16, #0xfb0]
     7d8:      	add	x16, x16, #0xfb0
     7dc:      	br	x17

00000000000007e0 <abort@plt>:
     7e0:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e35c>
     7e4:      	ldr	x17, [x16, #0xfb8]
     7e8:      	add	x16, x16, #0xfb8
     7ec:      	br	x17

00000000000007f0 <__isoc99_scanf@plt>:
     7f0:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e35c>
     7f4:      	ldr	x17, [x16, #0xfc0]
     7f8:      	add	x16, x16, #0xfc0
     7fc:      	br	x17

Disassembly of section .text:

0000000000000800 <_start>:
     800:      	nop
     804:      	mov	x29, #0x0               // =0
     808:      	mov	x30, #0x0               // =0
     80c:      	mov	x5, x0
     810:      	ldr	x1, [sp]
     814:      	add	x2, sp, #0x8
     818:      	mov	x6, sp
     81c:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e35c>
     820:      	ldr	x0, [x0, #0xff0]
     824:      	mov	x3, #0x0                // =0
     828:      	mov	x4, #0x0                // =0
     82c:      	bl	0x780 <__libc_start_main@plt>
     830:      	bl	0x7e0 <abort@plt>

0000000000000834 <call_weak_fn>:
     834:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e35c>
     838:      	ldr	x0, [x0, #0xfe0]
     83c:      	cbz	x0, 0x844 <call_weak_fn+0x10>
     840:      	b	0x7d0 <__gmon_start__@plt>
     844:      	ret
     848:      	nop
     84c:      	nop

0000000000000850 <deregister_tm_clones>:
     850:      	adrp	x0, 0x20000 <data_start>
     854:      	add	x0, x0, #0x10
     858:      	adrp	x1, 0x20000 <data_start>
     85c:      	add	x1, x1, #0x10
     860:      	cmp	x1, x0
     864:      	b.eq	0x87c <deregister_tm_clones+0x2c>
     868:      	adrp	x1, 0x1f000 <__FRAME_END__+0x1e35c>
     86c:      	ldr	x1, [x1, #0xfd0]
     870:      	cbz	x1, 0x87c <deregister_tm_clones+0x2c>
     874:      	mov	x16, x1
     878:      	br	x16
     87c:      	ret

0000000000000880 <register_tm_clones>:
     880:      	adrp	x0, 0x20000 <data_start>
     884:      	add	x0, x0, #0x10
     888:      	adrp	x1, 0x20000 <data_start>
     88c:      	add	x1, x1, #0x10
     890:      	sub	x1, x1, x0
     894:      	lsr	x2, x1, #63
     898:      	add	x1, x2, x1, asr #3
     89c:      	asr	x1, x1, #1
     8a0:      	cbz	x1, 0x8b8 <register_tm_clones+0x38>
     8a4:      	adrp	x2, 0x1f000 <__FRAME_END__+0x1e35c>
     8a8:      	ldr	x2, [x2, #0xff8]
     8ac:      	cbz	x2, 0x8b8 <register_tm_clones+0x38>
     8b0:      	mov	x16, x2
     8b4:      	br	x16
     8b8:      	ret
     8bc:      	nop

00000000000008c0 <__do_global_dtors_aux>:
     8c0:      	paciasp
     8c4:      	stp	x29, x30, [sp, #-0x20]!
     8c8:      	mov	x29, sp
     8cc:      	str	x19, [sp, #0x10]
     8d0:      	adrp	x19, 0x20000 <data_start>
     8d4:      	ldrb	w0, [x19, #0x10]
     8d8:      	tbnz	w0, #0x0, 0x900 <__do_global_dtors_aux+0x40>
     8dc:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e35c>
     8e0:      	ldr	x0, [x0, #0xfd8]
     8e4:      	cbz	x0, 0x8f4 <__do_global_dtors_aux+0x34>
     8e8:      	adrp	x0, 0x20000 <data_start>
     8ec:      	ldr	x0, [x0, #0x8]
     8f0:      	bl	0x790 <__cxa_finalize@plt>
     8f4:      	bl	0x850 <deregister_tm_clones>
     8f8:      	mov	w0, #0x1                // =1
     8fc:      	strb	w0, [x19, #0x10]
     900:      	ldr	x19, [sp, #0x10]
     904:      	ldp	x29, x30, [sp], #0x20
     908:      	autiasp
     90c:      	ret

0000000000000910 <frame_dummy>:
     910:      	bti	c
     914:      	b	0x880 <register_tm_clones>

0000000000000918 <kernel>:
     918:      	mov	w2, #0x4                // =4
     91c:      	add	w0, w0, w1, uxtb
     920:      	add	w0, w0, w0, lsl #10
     924:      	eor	w0, w0, w0, lsr #6
     928:      	lsr	w1, w1, #8
     92c:      	subs	w2, w2, #0x1
     930:      	b.ne	0x91c <kernel+0x4>
     934:      	add	w0, w0, w0, lsl #3
     938:      	eor	w0, w0, w0, lsr #11
     93c:      	add	w0, w0, w0, lsl #15
     940:      	ret

0000000000000944 <main>:
     944:      	sub	sp, sp, #0x60
     948:      	stp	x29, x30, [sp, #0x30]
     94c:      	add	x29, sp, #0x30
     950:      	stp	x19, x20, [sp, #0x40]
     954:      	mov	x19, x1
     958:      	adrp	x1, 0x1f000 <__FRAME_END__+0x1e35c>
     95c:      	ldr	x1, [x1, #0xfe8]
     960:      	ldr	x2, [x1]
     964:      	str	x2, [sp, #0x28]
     968:      	mov	x2, #0x0                // =0
     96c:      	cmp	w0, #0x1
     970:      	b.eq	0x9b0 <main+0x6c>
     974:      	mov	w20, #0x3               // =3
     978:      	cmp	w0, w20
     97c:      	b.eq	0xa10 <main+0xcc>
     980:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e35c>
     984:      	ldr	x0, [x0, #0xfe8]
     988:      	ldr	x2, [sp, #0x28]
     98c:      	ldr	x1, [x0]
     990:      	subs	x2, x2, x1
     994:      	mov	x1, #0x0                // =0
     998:      	b.ne	0xb18 <main+0x1d4>
     99c:      	mov	w0, w20
     9a0:      	ldp	x19, x20, [sp, #0x40]
     9a4:      	ldp	x29, x30, [sp, #0x30]
     9a8:      	add	sp, sp, #0x60
     9ac:      	ret
     9b0:      	stp	x21, x22, [sp, #0x50]
     9b4:      	add	x22, sp, #0x20
     9b8:      	add	x21, sp, #0x24
     9bc:      	adrp	x19, 0x0 <strtoul@GLIBC_2.17>
     9c0:      	add	x19, x19, #0xb48
     9c4:      	adrp	x20, 0x0 <strtoul@GLIBC_2.17>
     9c8:      	add	x20, x20, #0xb40
     9cc:      	b	0x9ec <main+0xa8>
     9d0:      	ldr	w1, [sp, #0x24]
     9d4:      	ldr	w0, [sp, #0x20]
     9d8:      	bl	0x918 <kernel>
     9dc:      	mov	w2, w0
     9e0:      	mov	x1, x20
     9e4:      	mov	w0, #0x2                // =2
     9e8:      	bl	0x7b0 <__printf_chk@plt>
     9ec:      	mov	x2, x21
     9f0:      	mov	x1, x22
     9f4:      	mov	x0, x19
     9f8:      	bl	0x7f0 <__isoc99_scanf@plt>
     9fc:      	cmp	w0, #0x2
     a00:      	b.eq	0x9d0 <main+0x8c>
     a04:      	mov	w20, #0x0               // =0
     a08:      	ldp	x21, x22, [sp, #0x50]
     a0c:      	b	0x980 <main+0x3c>
     a10:      	stp	x21, x22, [sp, #0x50]
     a14:      	mov	w2, #0xa                // =10
     a18:      	mov	x1, #0x0                // =0
     a1c:      	ldr	x0, [x19, #0x8]
     a20:      	bl	0x770 <strtoul@plt>
     a24:      	mov	x21, x0
     a28:      	mov	w2, #0xa                // =10
     a2c:      	mov	x1, #0x0                // =0
     a30:      	ldr	x0, [x19, #0x10]
     a34:      	bl	0x770 <strtoul@plt>
     a38:      	mov	x19, x0
     a3c:      	mov	x1, sp
     a40:      	mov	w0, #0x1                // =1
     a44:      	bl	0x7a0 <clock_gettime@plt>
     a48:      	cbnz	w0, 0xb00 <main+0x1bc>
     a4c:      	cbz	x21, 0xaf8 <main+0x1b4>
     a50:      	mov	x20, #0x0               // =0
     a54:      	mov	x22, #0x0               // =0
     a58:      	eor	w19, w19, w19, lsl #13
     a5c:      	eor	w19, w19, w19, lsr #17
     a60:      	eor	w0, w19, w19, lsl #5
     a64:      	str	w0, [sp, #0x20]
     a68:      	eor	w19, w0, w0, lsl #13
     a6c:      	eor	w19, w19, w19, lsr #17
     a70:      	eor	w19, w19, w19, lsl #5
     a74:      	str	w19, [sp, #0x24]
     a78:      	mov	w1, w19
     a7c:      	bl	0x918 <kernel>
     a80:      	add	x22, x22, w0, uxtw
     a84:      	add	x20, x20, #0x1
     a88:      	cmp	x21, x20
     a8c:      	b.ne	0xa58 <main+0x114>
     a90:      	add	x1, sp, #0x10
     a94:      	mov	w0, #0x1                // =1
     a98:      	bl	0x7a0 <clock_gettime@plt>
     a9c:      	mov	w20, w0
     aa0:      	cbnz	w0, 0xb0c <main+0x1c8>
     aa4:      	ldr	x0, [sp, #0x18]
     aa8:      	ldr	x1, [sp, #0x8]
     aac:      	sub	x0, x0, x1
     ab0:      	fmov	d1, x0
     ab4:      	scvtf	d1, d1
     ab8:      	adrp	x0, 0x0 <strtoul@GLIBC_2.17>
     abc:      	ldr	d0, [x0, #0xb60]
     ac0:      	fmul	d1, d1, d0
     ac4:      	ldr	x0, [sp, #0x10]
     ac8:      	ldr	x1, [sp]
     acc:      	sub	x0, x0, x1
     ad0:      	fmov	d0, x0
     ad4:      	scvtf	d0, d0
     ad8:      	mov	x2, x22
     adc:      	fadd	d0, d1, d0
     ae0:      	adrp	x1, 0x0 <strtoul@GLIBC_2.17>
     ae4:      	add	x1, x1, #0xb50
     ae8:      	mov	w0, #0x2                // =2
     aec:      	bl	0x7b0 <__printf_chk@plt>
     af0:      	ldp	x21, x22, [sp, #0x50]
     af4:      	b	0x980 <main+0x3c>
     af8:      	mov	x22, x21
     afc:      	b	0xa90 <main+0x14c>
     b00:      	mov	w20, #0x2               // =2
     b04:      	ldp	x21, x22, [sp, #0x50]
     b08:      	b	0x980 <main+0x3c>
     b0c:      	mov	w20, #0x2               // =2
     b10:      	ldp	x21, x22, [sp, #0x50]
     b14:      	b	0x980 <main+0x3c>
     b18:      	stp	x21, x22, [sp, #0x50]
     b1c:      	bl	0x7c0 <__stack_chk_fail@plt>

Disassembly of section .fini:

0000000000000b20 <_fini>:
     b20:      	nop
     b24:      	stp	x29, x30, [sp, #-0x10]!
     b28:      	mov	x29, sp
     b2c:      	ldp	x29, x30, [sp], #0x10
     b30:      	ret
