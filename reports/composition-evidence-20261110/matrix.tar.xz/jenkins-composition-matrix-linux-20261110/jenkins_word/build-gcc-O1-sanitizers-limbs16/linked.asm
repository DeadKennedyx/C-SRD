
/work/experiments/runs/jenkins-composition-matrix-linux-20261110/jenkins_word/build-gcc-O1-sanitizers-limbs16/program:	file format elf64-littleaarch64

Disassembly of section .init:

00000000000011c0 <_init>:
    11c0:      	nop
    11c4:      	stp	x29, x30, [sp, #-0x10]!
    11c8:      	mov	x29, sp
    11cc:      	bl	0x13b4 <call_weak_fn>
    11d0:      	ldp	x29, x30, [sp], #0x10
    11d4:      	ret

Disassembly of section .plt:

00000000000011e0 <.plt>:
    11e0:      	stp	x16, x30, [sp, #-0x10]!
    11e4:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1cf5c>
    11e8:      	ldr	x17, [x16, #0xf08]
    11ec:      	add	x16, x16, #0xf08
    11f0:      	br	x17
    11f4:      	nop
    11f8:      	nop
    11fc:      	nop

0000000000001200 <__asan_report_store4@plt>:
    1200:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1cf5c>
    1204:      	ldr	x17, [x16, #0xf10]
    1208:      	add	x16, x16, #0xf10
    120c:      	br	x17

0000000000001210 <__ubsan_handle_type_mismatch_v1_abort@plt>:
    1210:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1cf5c>
    1214:      	ldr	x17, [x16, #0xf18]
    1218:      	add	x16, x16, #0xf18
    121c:      	br	x17

0000000000001220 <__asan_register_globals@plt>:
    1220:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1cf5c>
    1224:      	ldr	x17, [x16, #0xf20]
    1228:      	add	x16, x16, #0xf20
    122c:      	br	x17

0000000000001230 <__stack_chk_fail@plt>:
    1230:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1cf5c>
    1234:      	ldr	x17, [x16, #0xf28]
    1238:      	add	x16, x16, #0xf28
    123c:      	br	x17

0000000000001240 <__ubsan_handle_nonnull_arg_abort@plt>:
    1240:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1cf5c>
    1244:      	ldr	x17, [x16, #0xf30]
    1248:      	add	x16, x16, #0xf30
    124c:      	br	x17

0000000000001250 <__ubsan_handle_sub_overflow_abort@plt>:
    1250:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1cf5c>
    1254:      	ldr	x17, [x16, #0xf38]
    1258:      	add	x16, x16, #0xf38
    125c:      	br	x17

0000000000001260 <__asan_report_load4@plt>:
    1260:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1cf5c>
    1264:      	ldr	x17, [x16, #0xf40]
    1268:      	add	x16, x16, #0xf40
    126c:      	br	x17

0000000000001270 <__cxa_finalize@plt>:
    1270:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1cf5c>
    1274:      	ldr	x17, [x16, #0xf48]
    1278:      	add	x16, x16, #0xf48
    127c:      	br	x17

0000000000001280 <__libc_start_main@plt>:
    1280:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1cf5c>
    1284:      	ldr	x17, [x16, #0xf50]
    1288:      	add	x16, x16, #0xf50
    128c:      	br	x17

0000000000001290 <__asan_unregister_globals@plt>:
    1290:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1cf5c>
    1294:      	ldr	x17, [x16, #0xf58]
    1298:      	add	x16, x16, #0xf58
    129c:      	br	x17

00000000000012a0 <__asan_handle_no_return@plt>:
    12a0:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1cf5c>
    12a4:      	ldr	x17, [x16, #0xf60]
    12a8:      	add	x16, x16, #0xf60
    12ac:      	br	x17

00000000000012b0 <__asan_init@plt>:
    12b0:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1cf5c>
    12b4:      	ldr	x17, [x16, #0xf68]
    12b8:      	add	x16, x16, #0xf68
    12bc:      	br	x17

00000000000012c0 <strtoul@plt>:
    12c0:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1cf5c>
    12c4:      	ldr	x17, [x16, #0xf70]
    12c8:      	add	x16, x16, #0xf70
    12cc:      	br	x17

00000000000012d0 <clock_gettime@plt>:
    12d0:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1cf5c>
    12d4:      	ldr	x17, [x16, #0xf78]
    12d8:      	add	x16, x16, #0xf78
    12dc:      	br	x17

00000000000012e0 <__asan_report_load8@plt>:
    12e0:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1cf5c>
    12e4:      	ldr	x17, [x16, #0xf80]
    12e8:      	add	x16, x16, #0xf80
    12ec:      	br	x17

00000000000012f0 <abort@plt>:
    12f0:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1cf5c>
    12f4:      	ldr	x17, [x16, #0xf88]
    12f8:      	add	x16, x16, #0xf88
    12fc:      	br	x17

0000000000001300 <__asan_stack_malloc_2@plt>:
    1300:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1cf5c>
    1304:      	ldr	x17, [x16, #0xf90]
    1308:      	add	x16, x16, #0xf90
    130c:      	br	x17

0000000000001310 <__asan_version_mismatch_check_v8@plt>:
    1310:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1cf5c>
    1314:      	ldr	x17, [x16, #0xf98]
    1318:      	add	x16, x16, #0xf98
    131c:      	br	x17

0000000000001320 <__isoc99_scanf@plt>:
    1320:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1cf5c>
    1324:      	ldr	x17, [x16, #0xfa0]
    1328:      	add	x16, x16, #0xfa0
    132c:      	br	x17

0000000000001330 <__printf_chk@plt>:
    1330:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1cf5c>
    1334:      	ldr	x17, [x16, #0xfa8]
    1338:      	add	x16, x16, #0xfa8
    133c:      	br	x17

0000000000001340 <__gmon_start__@plt>:
    1340:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1cf5c>
    1344:      	ldr	x17, [x16, #0xfb0]
    1348:      	add	x16, x16, #0xfb0
    134c:      	br	x17

0000000000001350 <__ubsan_handle_pointer_overflow_abort@plt>:
    1350:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1cf5c>
    1354:      	ldr	x17, [x16, #0xfb8]
    1358:      	add	x16, x16, #0xfb8
    135c:      	br	x17

Disassembly of section .text:

0000000000001380 <_start>:
    1380:      	nop
    1384:      	mov	x29, #0x0               // =0
    1388:      	mov	x30, #0x0               // =0
    138c:      	mov	x5, x0
    1390:      	ldr	x1, [sp]
    1394:      	add	x2, sp, #0x8
    1398:      	mov	x6, sp
    139c:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1cf5c>
    13a0:      	ldr	x0, [x0, #0xfd0]
    13a4:      	mov	x3, #0x0                // =0
    13a8:      	mov	x4, #0x0                // =0
    13ac:      	bl	0x1280 <__libc_start_main@plt>
    13b0:      	bl	0x12f0 <abort@plt>

00000000000013b4 <call_weak_fn>:
    13b4:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1cf5c>
    13b8:      	ldr	x0, [x0, #0xff0]
    13bc:      	cbz	x0, 0x13c4 <call_weak_fn+0x10>
    13c0:      	b	0x1340 <__gmon_start__@plt>
    13c4:      	ret
    13c8:      	nop
    13cc:      	nop

00000000000013d0 <deregister_tm_clones>:
    13d0:      	adrp	x0, 0x20000 <data_start>
    13d4:      	add	x0, x0, #0x780
    13d8:      	adrp	x1, 0x20000 <data_start>
    13dc:      	add	x1, x1, #0x780
    13e0:      	cmp	x1, x0
    13e4:      	b.eq	0x13fc <deregister_tm_clones+0x2c>
    13e8:      	adrp	x1, 0x1f000 <__FRAME_END__+0x1cf5c>
    13ec:      	ldr	x1, [x1, #0xfe8]
    13f0:      	cbz	x1, 0x13fc <deregister_tm_clones+0x2c>
    13f4:      	mov	x16, x1
    13f8:      	br	x16
    13fc:      	ret

0000000000001400 <register_tm_clones>:
    1400:      	adrp	x0, 0x20000 <data_start>
    1404:      	add	x0, x0, #0x780
    1408:      	adrp	x1, 0x20000 <data_start>
    140c:      	add	x1, x1, #0x780
    1410:      	sub	x1, x1, x0
    1414:      	lsr	x2, x1, #63
    1418:      	add	x1, x2, x1, asr #3
    141c:      	asr	x1, x1, #1
    1420:      	cbz	x1, 0x1438 <register_tm_clones+0x38>
    1424:      	adrp	x2, 0x1f000 <__FRAME_END__+0x1cf5c>
    1428:      	ldr	x2, [x2, #0xff8]
    142c:      	cbz	x2, 0x1438 <register_tm_clones+0x38>
    1430:      	mov	x16, x2
    1434:      	br	x16
    1438:      	ret
    143c:      	nop

0000000000001440 <__do_global_dtors_aux>:
    1440:      	paciasp
    1444:      	stp	x29, x30, [sp, #-0x20]!
    1448:      	mov	x29, sp
    144c:      	str	x19, [sp, #0x10]
    1450:      	adrp	x19, 0x20000 <data_start>
    1454:      	ldrb	w0, [x19, #0x780]
    1458:      	tbnz	w0, #0x0, 0x1480 <__do_global_dtors_aux+0x40>
    145c:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1cf5c>
    1460:      	ldr	x0, [x0, #0xfd8]
    1464:      	cbz	x0, 0x1474 <__do_global_dtors_aux+0x34>
    1468:      	adrp	x0, 0x20000 <data_start>
    146c:      	ldr	x0, [x0, #0x8]
    1470:      	bl	0x1270 <__cxa_finalize@plt>
    1474:      	bl	0x13d0 <deregister_tm_clones>
    1478:      	mov	w0, #0x1                // =1
    147c:      	strb	w0, [x19, #0x780]
    1480:      	ldr	x19, [sp, #0x10]
    1484:      	ldp	x29, x30, [sp], #0x20
    1488:      	autiasp
    148c:      	ret

0000000000001490 <frame_dummy>:
    1490:      	bti	c
    1494:      	b	0x1400 <register_tm_clones>

0000000000001498 <kernel>:
    1498:      	and	w2, w1, #0xff
    149c:      	add	w2, w2, w0, uxth
    14a0:      	lsr	w0, w0, #16
    14a4:      	add	w0, w0, w2, lsr #16
    14a8:      	ubfiz	w3, w2, #10, #6
    14ac:      	add	w3, w3, w2, uxth
    14b0:      	ubfiz	w4, w0, #10, #16
    14b4:      	ubfx	x2, x2, #6, #10
    14b8:      	orr	w2, w4, w2
    14bc:      	add	w2, w2, w3, lsr #16
    14c0:      	add	w0, w2, w0, uxth
    14c4:      	and	w4, w0, #0xffff
    14c8:      	ubfx	x5, x1, #8, #8
    14cc:      	ubfx	x2, x3, #6, #10
    14d0:      	ubfiz	w6, w0, #10, #16
    14d4:      	orr	w2, w2, w6
    14d8:      	eor	w2, w2, w3
    14dc:      	add	w2, w5, w2, uxth
    14e0:      	ubfx	x0, x0, #6, #10
    14e4:      	eor	w0, w0, w4
    14e8:      	add	w0, w0, w2, lsr #16
    14ec:      	ubfiz	w3, w2, #10, #6
    14f0:      	add	w3, w3, w2, uxth
    14f4:      	ubfiz	w4, w0, #10, #16
    14f8:      	ubfx	x2, x2, #6, #10
    14fc:      	orr	w2, w4, w2
    1500:      	add	w2, w2, w3, lsr #16
    1504:      	add	w0, w2, w0, uxth
    1508:      	and	w4, w0, #0xffff
    150c:      	ubfx	x5, x1, #16, #8
    1510:      	ubfx	x2, x3, #6, #10
    1514:      	ubfiz	w6, w0, #10, #16
    1518:      	orr	w2, w2, w6
    151c:      	eor	w2, w2, w3
    1520:      	add	w2, w5, w2, uxth
    1524:      	ubfx	x0, x0, #6, #10
    1528:      	eor	w0, w0, w4
    152c:      	add	w0, w0, w2, lsr #16
    1530:      	ubfiz	w3, w2, #10, #6
    1534:      	add	w3, w3, w2, uxth
    1538:      	ubfiz	w4, w0, #10, #16
    153c:      	ubfx	x2, x2, #6, #10
    1540:      	orr	w2, w4, w2
    1544:      	add	w2, w2, w3, lsr #16
    1548:      	add	w0, w2, w0, uxth
    154c:      	and	w4, w0, #0xffff
    1550:      	ubfx	x2, x3, #6, #10
    1554:      	ubfiz	w5, w0, #10, #16
    1558:      	orr	w2, w2, w5
    155c:      	eor	w2, w2, w3
    1560:      	lsr	w1, w1, #24
    1564:      	add	w1, w1, w2, uxth
    1568:      	ubfx	x0, x0, #6, #10
    156c:      	eor	w0, w0, w4
    1570:      	add	w0, w0, w1, lsr #16
    1574:      	ubfiz	w2, w1, #10, #6
    1578:      	add	w2, w2, w1, uxth
    157c:      	ubfiz	w3, w0, #10, #16
    1580:      	ubfx	x1, x1, #6, #10
    1584:      	orr	w1, w3, w1
    1588:      	add	w1, w1, w2, lsr #16
    158c:      	add	w0, w1, w0, uxth
    1590:      	and	w3, w0, #0xffff
    1594:      	ubfx	x1, x2, #6, #10
    1598:      	ubfiz	w4, w0, #10, #16
    159c:      	orr	w1, w1, w4
    15a0:      	eor	w1, w1, w2
    15a4:      	ubfx	x0, x0, #6, #10
    15a8:      	eor	w0, w0, w3
    15ac:      	ubfiz	w3, w1, #3, #13
    15b0:      	add	w3, w3, w1, uxth
    15b4:      	ubfx	x1, x1, #13, #3
    15b8:      	orr	w1, w1, w0, lsl #3
    15bc:      	add	w0, w0, w1, uxth
    15c0:      	add	w0, w0, w3, lsr #16
    15c4:      	and	w1, w0, #0xffff
    15c8:      	ubfx	x2, x3, #11, #5
    15cc:      	ubfiz	w4, w0, #5, #16
    15d0:      	orr	w2, w2, w4
    15d4:      	eor	w2, w2, w3
    15d8:      	ubfx	x0, x0, #11, #5
    15dc:      	eor	w1, w0, w1
    15e0:      	ubfiz	w0, w2, #15, #1
    15e4:      	add	w0, w0, w2, uxth
    15e8:      	ubfx	x2, x2, #1, #15
    15ec:      	orr	w2, w2, w1, lsl #15
    15f0:      	add	w2, w1, w2, uxth
    15f4:      	add	w2, w2, w0, lsr #16
    15f8:      	bfi	w0, w2, #16, #16
    15fc:      	ret

0000000000001600 <_sub_I_00099_0>:
    1600:      	stp	x29, x30, [sp, #-0x10]!
    1604:      	mov	x29, sp
    1608:      	bl	0x12b0 <__asan_init@plt>
    160c:      	bl	0x1310 <__asan_version_mismatch_check_v8@plt>
    1610:      	ldp	x29, x30, [sp], #0x10
    1614:      	ret

0000000000001618 <main>:
    1618:      	sub	sp, sp, #0x130
    161c:      	stp	x29, x30, [sp, #0xd0]
    1620:      	add	x29, sp, #0xd0
    1624:      	stp	x19, x20, [sp, #0xe0]
    1628:      	stp	x21, x22, [sp, #0xf0]
    162c:      	stp	x23, x24, [sp, #0x100]
    1630:      	stp	x27, x28, [sp, #0x120]
    1634:      	mov	w21, w0
    1638:      	mov	x20, x1
    163c:      	add	x23, sp, #0x10
    1640:      	mov	x28, x23
    1644:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1cf5c>
    1648:      	ldr	x0, [x0, #0xfe0]
    164c:      	ldr	w0, [x0]
    1650:      	cbnz	w0, 0x195c <main+0x344>
    1654:      	mov	x19, x23
    1658:      	mov	x0, #0x8ab3             // =35507
    165c:      	movk	x0, #0x41b5, lsl #16
    1660:      	str	x0, [x19], #0xc0
    1664:      	adrp	x0, 0x1000 <strtoul@GLIBC_2.17+0x1000>
    1668:      	add	x0, x0, #0xc28
    166c:      	str	x0, [x23, #0x8]
    1670:      	adrp	x0, 0x1000 <strtoul@GLIBC_2.17+0x1000>
    1674:      	add	x0, x0, #0x618
    1678:      	str	x0, [x23, #0x10]
    167c:      	lsr	x24, x23, #3
    1680:      	mov	x0, #0x1000000000       // =68719476736
    1684:      	add	x1, x24, x0
    1688:      	mov	w2, #-0xe0e0e0f         // =-235802127
    168c:      	str	w2, [x24, x0]
    1690:      	add	w2, w2, #0x130, lsl #12 // =0x130000
    1694:      	str	w2, [x1, #0x4]
    1698:      	mov	w0, #-0xd0e0000         // =-219021312
    169c:      	str	w0, [x1, #0x8]
    16a0:      	str	w0, [x1, #0xc]
    16a4:      	mov	w0, #0xf300             // =62208
    16a8:      	movk	w0, #0xf3f3, lsl #16
    16ac:      	str	w0, [x1, #0x10]
    16b0:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1cf5c>
    16b4:      	ldr	x0, [x0, #0xfc8]
    16b8:      	ldr	x1, [x0]
    16bc:      	str	x1, [sp, #0xc8]
    16c0:      	mov	x1, #0x0                // =0
    16c4:      	cmp	w21, #0x1
    16c8:      	b.eq	0x1970 <main+0x358>
    16cc:      	cmp	w21, #0x3
    16d0:      	b.ne	0x1b18 <main+0x500>
    16d4:      	stp	x25, x26, [sp, #0x110]
    16d8:      	add	x2, x20, #0x8
    16dc:      	cmn	x20, #0x8
    16e0:      	b.hs	0x1a14 <main+0x3fc>
    16e4:      	adds	x1, x20, #0x8
    16e8:      	b.eq	0x1a24 <main+0x40c>
    16ec:      	tst	x1, #0x7
    16f0:      	b.ne	0x1a24 <main+0x40c>
    16f4:      	add	x0, x20, #0x8
    16f8:      	lsr	x2, x0, #3
    16fc:      	mov	x1, #0x1000000000       // =68719476736
    1700:      	ldrsb	w1, [x2, x1]
    1704:      	cbnz	w1, 0x1a34 <main+0x41c>
    1708:      	ldr	x0, [x20, #0x8]
    170c:      	cbz	x0, 0x1a38 <main+0x420>
    1710:      	mov	w2, #0xa                // =10
    1714:      	mov	x1, #0x0                // =0
    1718:      	bl	0x12c0 <strtoul@plt>
    171c:      	mov	x25, x0
    1720:      	add	x2, x20, #0x10
    1724:      	cmn	x20, #0x10
    1728:      	b.hs	0x1a4c <main+0x434>
    172c:      	adds	x1, x20, #0x10
    1730:      	b.eq	0x1a60 <main+0x448>
    1734:      	tst	x1, #0x7
    1738:      	b.ne	0x1a60 <main+0x448>
    173c:      	add	x0, x20, #0x10
    1740:      	lsr	x2, x0, #3
    1744:      	mov	x1, #0x1000000000       // =68719476736
    1748:      	ldrsb	w1, [x2, x1]
    174c:      	cbnz	w1, 0x1a70 <main+0x458>
    1750:      	ldr	x0, [x20, #0x10]
    1754:      	cbz	x0, 0x1a74 <main+0x45c>
    1758:      	mov	w2, #0xa                // =10
    175c:      	mov	x1, #0x0                // =0
    1760:      	bl	0x12c0 <strtoul@plt>
    1764:      	sub	x2, x19, #0x90
    1768:      	lsr	x3, x2, #3
    176c:      	mov	x1, #0x1000000000       // =68719476736
    1770:      	ldrsb	w1, [x3, x1]
    1774:      	cmp	w1, #0x0
    1778:      	mov	w3, #0x3                // =3
    177c:      	ccmp	w3, w1, #0x1, ne
    1780:      	b.ge	0x1a88 <main+0x470>
    1784:      	stur	w0, [x19, #-0x90]
    1788:      	sub	x1, x19, #0x80
    178c:      	mov	w0, #0x1                // =1
    1790:      	bl	0x12d0 <clock_gettime@plt>
    1794:      	cbnz	w0, 0x1b70 <main+0x558>
    1798:      	cbz	x25, 0x1ad8 <main+0x4c0>
    179c:      	mov	x21, #0x0               // =0
    17a0:      	mov	x22, #0x0               // =0
    17a4:      	sub	x0, x19, #0x90
    17a8:      	str	x0, [sp, #0x8]
    17ac:      	lsr	x27, x0, #3
    17b0:      	sub	x20, x19, #0x40
    17b4:      	and	x26, x19, #0x7
    17b8:      	add	w26, w26, #0x3
    17bc:      	mov	x0, #0x1000000000       // =68719476736
    17c0:      	ldrsb	w0, [x27, x0]
    17c4:      	cmp	w0, #0x0
    17c8:      	mov	w1, #0x3                // =3
    17cc:      	ccmp	w1, w0, #0x1, ne
    17d0:      	b.ge	0x1a90 <main+0x478>
    17d4:      	ldur	w0, [x19, #-0x90]
    17d8:      	eor	w0, w0, w0, lsl #13
    17dc:      	eor	w0, w0, w0, lsr #17
    17e0:      	eor	w0, w0, w0, lsl #5
    17e4:      	stur	w0, [x19, #-0x90]
    17e8:      	lsr	x1, x20, #3
    17ec:      	mov	x2, #0x1000000000       // =68719476736
    17f0:      	ldrsb	w1, [x1, x2]
    17f4:      	cmp	w1, #0x0
    17f8:      	ccmp	w26, w1, #0x1, ne
    17fc:      	b.ge	0x1a98 <main+0x480>
    1800:      	stur	w0, [x19, #-0x40]
    1804:      	eor	w1, w0, w0, lsl #13
    1808:      	eor	w1, w1, w1, lsr #17
    180c:      	eor	w1, w1, w1, lsl #5
    1810:      	stur	w1, [x19, #-0x90]
    1814:      	sub	x2, x19, #0x38
    1818:      	sub	x2, x2, x20
    181c:      	cmp	x2, #0x8
    1820:      	b.hi	0x1aa0 <main+0x488>
    1824:      	sub	x3, x19, #0x3c
    1828:      	lsr	x4, x3, #3
    182c:      	mov	x2, #0x1000000000       // =68719476736
    1830:      	ldrsb	w4, [x4, x2]
    1834:      	and	x2, x3, #0x7
    1838:      	add	w2, w2, #0x3
    183c:      	cmp	w4, #0x0
    1840:      	ccmp	w2, w4, #0x1, ne
    1844:      	b.ge	0x1ac0 <main+0x4a8>
    1848:      	stur	w1, [x19, #-0x3c]
    184c:      	lsr	x2, x20, #3
    1850:      	mov	x3, #0x1000000000       // =68719476736
    1854:      	ldrsb	w2, [x2, x3]
    1858:      	cmp	w2, #0x0
    185c:      	mov	w3, #0x3                // =3
    1860:      	ccmp	w3, w2, #0x1, ne
    1864:      	b.ge	0x1ac8 <main+0x4b0>
    1868:      	sub	x3, x19, #0x3c
    186c:      	lsr	x4, x3, #3
    1870:      	mov	x2, #0x1000000000       // =68719476736
    1874:      	ldrsb	w4, [x4, x2]
    1878:      	and	x2, x3, #0x7
    187c:      	add	w2, w2, #0x3
    1880:      	cmp	w4, #0x0
    1884:      	ccmp	w2, w4, #0x1, ne
    1888:      	b.ge	0x1ad0 <main+0x4b8>
    188c:      	bl	0x1498 <kernel>
    1890:      	add	x22, x22, w0, uxtw
    1894:      	add	x21, x21, #0x1
    1898:      	cmp	x25, x21
    189c:      	b.ne	0x17bc <main+0x1a4>
    18a0:      	sub	x1, x19, #0x60
    18a4:      	mov	w0, #0x1                // =1
    18a8:      	bl	0x12d0 <clock_gettime@plt>
    18ac:      	mov	w20, w0
    18b0:      	cbnz	w0, 0x1b7c <main+0x564>
    18b4:      	sub	x0, x19, #0x60
    18b8:      	lsr	x2, x0, #3
    18bc:      	mov	x1, #0x1000000000       // =68719476736
    18c0:      	ldrsb	w1, [x2, x1]
    18c4:      	cbnz	w1, 0x1ae0 <main+0x4c8>
    18c8:      	ldur	x1, [x19, #-0x60]
    18cc:      	sub	x0, x19, #0x80
    18d0:      	lsr	x3, x0, #3
    18d4:      	mov	x2, #0x1000000000       // =68719476736
    18d8:      	ldrsb	w2, [x3, x2]
    18dc:      	cbnz	w2, 0x1ae4 <main+0x4cc>
    18e0:      	ldur	x0, [x19, #-0x80]
    18e4:      	subs	x0, x1, x0
    18e8:      	b.vs	0x1ae8 <main+0x4d0>
    18ec:      	scvtf	d1, x0
    18f0:      	sub	x0, x19, #0x58
    18f4:      	lsr	x2, x0, #3
    18f8:      	mov	x1, #0x1000000000       // =68719476736
    18fc:      	ldrsb	w1, [x2, x1]
    1900:      	cbnz	w1, 0x1afc <main+0x4e4>
    1904:      	ldur	x1, [x19, #-0x58]
    1908:      	sub	x0, x19, #0x78
    190c:      	lsr	x3, x0, #3
    1910:      	mov	x2, #0x1000000000       // =68719476736
    1914:      	ldrsb	w2, [x3, x2]
    1918:      	cbnz	w2, 0x1b00 <main+0x4e8>
    191c:      	ldur	x0, [x19, #-0x78]
    1920:      	subs	x0, x1, x0
    1924:      	b.vs	0x1b04 <main+0x4ec>
    1928:      	scvtf	d0, x0
    192c:      	adrp	x0, 0x1000 <strtoul@GLIBC_2.17+0x1000>
    1930:      	ldr	d2, [x0, #0xd50]
    1934:      	fmul	d0, d0, d2
    1938:      	mov	x2, x22
    193c:      	fadd	d0, d0, d1
    1940:      	adrp	x1, 0x1000 <strtoul@GLIBC_2.17+0x1000>
    1944:      	add	x1, x1, #0xd60
    1948:      	add	x1, x1, #0x80
    194c:      	mov	w0, #0x2                // =2
    1950:      	bl	0x1330 <__printf_chk@plt>
    1954:      	ldp	x25, x26, [sp, #0x110]
    1958:      	b	0x1b1c <main+0x504>
    195c:      	mov	x0, #0xa0               // =160
    1960:      	bl	0x1300 <__asan_stack_malloc_2@plt>
    1964:      	cmp	x0, #0x0
    1968:      	csel	x23, x23, x0, eq
    196c:      	b	0x1654 <main+0x3c>
    1970:      	stp	x25, x26, [sp, #0x110]
    1974:      	sub	x20, x19, #0x3c
    1978:      	adrp	x21, 0x1000 <strtoul@GLIBC_2.17+0x1000>
    197c:      	add	x21, x21, #0xd60
    1980:      	add	x25, x21, #0x40
    1984:      	and	x22, x20, #0x7
    1988:      	add	w22, w22, #0x3
    198c:      	b	0x19ac <main+0x394>
    1990:      	bl	0x1260 <__asan_report_load4@plt>
    1994:      	ldur	w1, [x19, #-0x3c]
    1998:      	bl	0x1498 <kernel>
    199c:      	mov	w2, w0
    19a0:      	mov	x1, x21
    19a4:      	mov	w0, #0x2                // =2
    19a8:      	bl	0x1330 <__printf_chk@plt>
    19ac:      	mov	x2, x20
    19b0:      	sub	x1, x19, #0x40
    19b4:      	mov	x0, x25
    19b8:      	bl	0x1320 <__isoc99_scanf@plt>
    19bc:      	cmp	w0, #0x2
    19c0:      	b.ne	0x1a08 <main+0x3f0>
    19c4:      	sub	x0, x19, #0x40
    19c8:      	lsr	x2, x0, #3
    19cc:      	mov	x1, #0x1000000000       // =68719476736
    19d0:      	ldrsb	w1, [x2, x1]
    19d4:      	cmp	w1, #0x0
    19d8:      	mov	w2, #0x3                // =3
    19dc:      	ccmp	w2, w1, #0x1, ne
    19e0:      	b.ge	0x1990 <main+0x378>
    19e4:      	ldur	w0, [x19, #-0x40]
    19e8:      	lsr	x1, x20, #3
    19ec:      	mov	x2, #0x1000000000       // =68719476736
    19f0:      	ldrsb	w1, [x1, x2]
    19f4:      	cmp	w1, #0x0
    19f8:      	ccmp	w22, w1, #0x1, ne
    19fc:      	b.lt	0x1994 <main+0x37c>
    1a00:      	mov	x0, x20
    1a04:      	bl	0x1260 <__asan_report_load4@plt>
    1a08:      	mov	w20, #0x0               // =0
    1a0c:      	ldp	x25, x26, [sp, #0x110]
    1a10:      	b	0x1b1c <main+0x504>
    1a14:      	mov	x1, x20
    1a18:      	adrp	x0, 0x20000 <data_start>
    1a1c:      	add	x0, x0, #0xe0
    1a20:      	bl	0x1350 <__ubsan_handle_pointer_overflow_abort@plt>
    1a24:      	adrp	x0, 0x20000 <data_start>
    1a28:      	add	x0, x0, #0xe0
    1a2c:      	add	x0, x0, #0x40
    1a30:      	bl	0x1210 <__ubsan_handle_type_mismatch_v1_abort@plt>
    1a34:      	bl	0x12e0 <__asan_report_load8@plt>
    1a38:      	bl	0x12a0 <__asan_handle_no_return@plt>
    1a3c:      	adrp	x0, 0x20000 <data_start>
    1a40:      	add	x0, x0, #0xe0
    1a44:      	add	x0, x0, #0x80
    1a48:      	bl	0x1240 <__ubsan_handle_nonnull_arg_abort@plt>
    1a4c:      	mov	x1, x20
    1a50:      	adrp	x0, 0x20000 <data_start>
    1a54:      	add	x0, x0, #0xe0
    1a58:      	add	x0, x0, #0xe0
    1a5c:      	bl	0x1350 <__ubsan_handle_pointer_overflow_abort@plt>
    1a60:      	adrp	x0, 0x20000 <data_start>
    1a64:      	add	x0, x0, #0xe0
    1a68:      	add	x0, x0, #0x120
    1a6c:      	bl	0x1210 <__ubsan_handle_type_mismatch_v1_abort@plt>
    1a70:      	bl	0x12e0 <__asan_report_load8@plt>
    1a74:      	bl	0x12a0 <__asan_handle_no_return@plt>
    1a78:      	adrp	x0, 0x20000 <data_start>
    1a7c:      	add	x0, x0, #0xe0
    1a80:      	add	x0, x0, #0x160
    1a84:      	bl	0x1240 <__ubsan_handle_nonnull_arg_abort@plt>
    1a88:      	mov	x0, x2
    1a8c:      	bl	0x1200 <__asan_report_store4@plt>
    1a90:      	ldr	x0, [sp, #0x8]
    1a94:      	bl	0x1260 <__asan_report_load4@plt>
    1a98:      	mov	x0, x20
    1a9c:      	bl	0x1200 <__asan_report_store4@plt>
    1aa0:      	sub	x3, x19, #0x3c
    1aa4:      	cmn	x3, x2
    1aa8:      	b.hs	0x1824 <main+0x20c>
    1aac:      	mov	x1, x3
    1ab0:      	adrp	x0, 0x20000 <data_start>
    1ab4:      	add	x0, x0, #0xe0
    1ab8:      	add	x0, x0, #0x1c0
    1abc:      	bl	0x1210 <__ubsan_handle_type_mismatch_v1_abort@plt>
    1ac0:      	mov	x0, x3
    1ac4:      	bl	0x1200 <__asan_report_store4@plt>
    1ac8:      	mov	x0, x20
    1acc:      	bl	0x1260 <__asan_report_load4@plt>
    1ad0:      	mov	x0, x3
    1ad4:      	bl	0x1260 <__asan_report_load4@plt>
    1ad8:      	mov	x22, x25
    1adc:      	b	0x18a0 <main+0x288>
    1ae0:      	bl	0x12e0 <__asan_report_load8@plt>
    1ae4:      	bl	0x12e0 <__asan_report_load8@plt>
    1ae8:      	ldur	x2, [x19, #-0x80]
    1aec:      	adrp	x0, 0x20000 <data_start>
    1af0:      	add	x0, x0, #0xe0
    1af4:      	add	x0, x0, #0x200
    1af8:      	bl	0x1250 <__ubsan_handle_sub_overflow_abort@plt>
    1afc:      	bl	0x12e0 <__asan_report_load8@plt>
    1b00:      	bl	0x12e0 <__asan_report_load8@plt>
    1b04:      	ldur	x2, [x19, #-0x78]
    1b08:      	adrp	x0, 0x20000 <data_start>
    1b0c:      	add	x0, x0, #0xe0
    1b10:      	add	x0, x0, #0x240
    1b14:      	bl	0x1250 <__ubsan_handle_sub_overflow_abort@plt>
    1b18:      	mov	w20, #0x3               // =3
    1b1c:      	cmp	x28, x23
    1b20:      	b.ne	0x1b88 <main+0x570>
    1b24:      	mov	x0, #0x1000000000       // =68719476736
    1b28:      	add	x24, x24, x0
    1b2c:      	stp	xzr, xzr, [x24]
    1b30:      	str	wzr, [x24, #0x10]
    1b34:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1cf5c>
    1b38:      	ldr	x0, [x0, #0xfc8]
    1b3c:      	ldr	x2, [sp, #0xc8]
    1b40:      	ldr	x1, [x0]
    1b44:      	subs	x2, x2, x1
    1b48:      	mov	x1, #0x0                // =0
    1b4c:      	b.ne	0x1bac <main+0x594>
    1b50:      	mov	w0, w20
    1b54:      	ldp	x19, x20, [sp, #0xe0]
    1b58:      	ldp	x21, x22, [sp, #0xf0]
    1b5c:      	ldp	x23, x24, [sp, #0x100]
    1b60:      	ldp	x27, x28, [sp, #0x120]
    1b64:      	ldp	x29, x30, [sp, #0xd0]
    1b68:      	add	sp, sp, #0x130
    1b6c:      	ret
    1b70:      	mov	w20, #0x2               // =2
    1b74:      	ldp	x25, x26, [sp, #0x110]
    1b78:      	b	0x1b1c <main+0x504>
    1b7c:      	mov	w20, #0x2               // =2
    1b80:      	ldp	x25, x26, [sp, #0x110]
    1b84:      	b	0x1b1c <main+0x504>
    1b88:      	mov	x0, #0x360e             // =13838
    1b8c:      	movk	x0, #0x45e0, lsl #16
    1b90:      	str	x0, [x23]
    1b94:      	mov	x0, #0x1000000000       // =68719476736
    1b98:      	add	x1, x24, x0
    1b9c:      	movi	v0.16b, #0xf5
    1ba0:      	str	q0, [x24, x0]
    1ba4:      	str	s0, [x1, #0x10]
    1ba8:      	b	0x1b34 <main+0x51c>
    1bac:      	stp	x25, x26, [sp, #0x110]
    1bb0:      	bl	0x1230 <__stack_chk_fail@plt>

0000000000001bb4 <_sub_D_00099_0>:
    1bb4:      	stp	x29, x30, [sp, #-0x10]!
    1bb8:      	mov	x29, sp
    1bbc:      	mov	x1, #0x10               // =16
    1bc0:      	adrp	x0, 0x20000 <data_start>
    1bc4:      	add	x0, x0, #0xe0
    1bc8:      	add	x0, x0, #0x280
    1bcc:      	bl	0x1290 <__asan_unregister_globals@plt>
    1bd0:      	ldp	x29, x30, [sp], #0x10
    1bd4:      	ret

0000000000001bd8 <_sub_I_00099_1>:
    1bd8:      	stp	x29, x30, [sp, #-0x10]!
    1bdc:      	mov	x29, sp
    1be0:      	bl	0x12b0 <__asan_init@plt>
    1be4:      	bl	0x1310 <__asan_version_mismatch_check_v8@plt>
    1be8:      	mov	x1, #0x10               // =16
    1bec:      	adrp	x0, 0x20000 <data_start>
    1bf0:      	add	x0, x0, #0xe0
    1bf4:      	add	x0, x0, #0x280
    1bf8:      	bl	0x1220 <__asan_register_globals@plt>
    1bfc:      	ldp	x29, x30, [sp], #0x10
    1c00:      	ret

Disassembly of section .fini:

0000000000001c04 <_fini>:
    1c04:      	nop
    1c08:      	stp	x29, x30, [sp, #-0x10]!
    1c0c:      	mov	x29, sp
    1c10:      	ldp	x29, x30, [sp], #0x10
    1c14:      	ret
