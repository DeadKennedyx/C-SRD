
/work/experiments/runs/jenkins-composition-matrix-linux-20261110/jenkins_word/build-gcc-O2-lto-limbs16/program:	file format elf64-littleaarch64

Disassembly of section .init:

0000000000000738 <_init>:
     738:      	nop
     73c:      	stp	x29, x30, [sp, #-0x10]!
     740:      	mov	x29, sp
     744:      	bl	0x9f4 <call_weak_fn>
     748:      	ldp	x29, x30, [sp], #0x10
     74c:      	ret

Disassembly of section .plt:

0000000000000750 <.plt>:
     750:      	stp	x16, x30, [sp, #-0x10]!
     754:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e238>
     758:      	ldr	x17, [x16, #0xf78]
     75c:      	add	x16, x16, #0xf78
     760:      	br	x17
     764:      	nop
     768:      	nop
     76c:      	nop

0000000000000770 <strtoul@plt>:
     770:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e238>
     774:      	ldr	x17, [x16, #0xf80]
     778:      	add	x16, x16, #0xf80
     77c:      	br	x17

0000000000000780 <__libc_start_main@plt>:
     780:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e238>
     784:      	ldr	x17, [x16, #0xf88]
     788:      	add	x16, x16, #0xf88
     78c:      	br	x17

0000000000000790 <__cxa_finalize@plt>:
     790:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e238>
     794:      	ldr	x17, [x16, #0xf90]
     798:      	add	x16, x16, #0xf90
     79c:      	br	x17

00000000000007a0 <clock_gettime@plt>:
     7a0:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e238>
     7a4:      	ldr	x17, [x16, #0xf98]
     7a8:      	add	x16, x16, #0xf98
     7ac:      	br	x17

00000000000007b0 <__printf_chk@plt>:
     7b0:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e238>
     7b4:      	ldr	x17, [x16, #0xfa0]
     7b8:      	add	x16, x16, #0xfa0
     7bc:      	br	x17

00000000000007c0 <__stack_chk_fail@plt>:
     7c0:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e238>
     7c4:      	ldr	x17, [x16, #0xfa8]
     7c8:      	add	x16, x16, #0xfa8
     7cc:      	br	x17

00000000000007d0 <__gmon_start__@plt>:
     7d0:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e238>
     7d4:      	ldr	x17, [x16, #0xfb0]
     7d8:      	add	x16, x16, #0xfb0
     7dc:      	br	x17

00000000000007e0 <abort@plt>:
     7e0:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e238>
     7e4:      	ldr	x17, [x16, #0xfb8]
     7e8:      	add	x16, x16, #0xfb8
     7ec:      	br	x17

00000000000007f0 <__isoc99_scanf@plt>:
     7f0:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e238>
     7f4:      	ldr	x17, [x16, #0xfc0]
     7f8:      	add	x16, x16, #0xfc0
     7fc:      	br	x17

Disassembly of section .text:

0000000000000800 <main>:
     800:      	sub	sp, sp, #0x60
     804:      	mov	w2, w0
     808:      	adrp	x3, 0x1f000 <__FRAME_END__+0x1e238>
     80c:      	ldr	x3, [x3, #0xfe8]
     810:      	stp	x29, x30, [sp, #0x30]
     814:      	add	x29, sp, #0x30
     818:      	ldr	x0, [x3]
     81c:      	str	x0, [sp, #0x28]
     820:      	mov	x0, #0x0                // =0
     824:      	cmp	w2, #0x1
     828:      	b.eq	0x93c <main+0x13c>
     82c:      	mov	w0, #0x3                // =3
     830:      	cmp	w2, w0
     834:      	b.eq	0x860 <main+0x60>
     838:      	adrp	x1, 0x1f000 <__FRAME_END__+0x1e238>
     83c:      	ldr	x1, [x1, #0xfe8]
     840:      	ldr	x3, [sp, #0x28]
     844:      	ldr	x2, [x1]
     848:      	subs	x3, x3, x2
     84c:      	mov	x2, #0x0                // =0
     850:      	b.ne	0x9b0 <main+0x1b0>
     854:      	ldp	x29, x30, [sp, #0x30]
     858:      	add	sp, sp, #0x60
     85c:      	ret
     860:      	stp	x19, x20, [sp, #0x40]
     864:      	mov	x19, x1
     868:      	mov	w2, #0xa                // =10
     86c:      	mov	x1, #0x0                // =0
     870:      	ldr	x0, [x19, #0x8]
     874:      	bl	0x770 <strtoul@plt>
     878:      	mov	x20, x0
     87c:      	ldr	x0, [x19, #0x10]
     880:      	mov	w2, #0xa                // =10
     884:      	mov	x1, #0x0                // =0
     888:      	bl	0x770 <strtoul@plt>
     88c:      	mov	x19, x0
     890:      	add	x1, sp, #0x10
     894:      	mov	w0, #0x1                // =1
     898:      	bl	0x7a0 <clock_gettime@plt>
     89c:      	cbnz	w0, 0x9a4 <main+0x1a4>
     8a0:      	cbz	x20, 0x8ec <main+0xec>
     8a4:      	mov	w8, w19
     8a8:      	mov	x10, #0x0               // =0
     8ac:      	mov	x11, #0x0               // =0
     8b0:      	eor	w8, w8, w8, lsl #13
     8b4:      	add	x10, x10, #0x1
     8b8:      	eor	w8, w8, w8, lsr #17
     8bc:      	eor	w9, w8, w8, lsl #5
     8c0:      	mov	w0, w9
     8c4:      	eor	w8, w9, w9, lsl #13
     8c8:      	eor	w8, w8, w8, lsr #17
     8cc:      	eor	w8, w8, w8, lsl #5
     8d0:      	mov	w1, w8
     8d4:      	bl	0xae0 <kernel>
     8d8:      	add	x11, x11, w0, uxtw
     8dc:      	cmp	x20, x10
     8e0:      	b.ne	0x8b0 <main+0xb0>
     8e4:      	mov	x20, x11
     8e8:      	stp	w9, w8, [sp, #0x20]
     8ec:      	mov	x1, sp
     8f0:      	mov	w0, #0x1                // =1
     8f4:      	bl	0x7a0 <clock_gettime@plt>
     8f8:      	cbnz	w0, 0x9a4 <main+0x1a4>
     8fc:      	adrp	x1, 0x0 <strtoul@GLIBC_2.17>
     900:      	mov	x2, x20
     904:      	ldp	x3, x0, [sp]
     908:      	ldr	d1, [x1, #0xc88]
     90c:      	ldp	x4, x1, [sp, #0x10]
     910:      	sub	x0, x0, x1
     914:      	sub	x3, x3, x4
     918:      	adrp	x1, 0x0 <strtoul@GLIBC_2.17>
     91c:      	add	x1, x1, #0xc78
     920:      	scvtf	d0, x0
     924:      	mov	w0, #0x2                // =2
     928:      	fmul	d0, d0, d1
     92c:      	scvtf	d1, x3
     930:      	fadd	d0, d0, d1
     934:      	bl	0x7b0 <__printf_chk@plt>
     938:      	b	0x998 <main+0x198>
     93c:      	stp	x19, x20, [sp, #0x40]
     940:      	adrp	x19, 0x0 <strtoul@GLIBC_2.17>
     944:      	adrp	x20, 0x0 <strtoul@GLIBC_2.17>
     948:      	add	x19, x19, #0xc70
     94c:      	add	x20, x20, #0xc68
     950:      	stp	x21, x22, [sp, #0x50]
     954:      	add	x22, sp, #0x20
     958:      	add	x21, sp, #0x24
     95c:      	b	0x978 <main+0x178>
     960:      	ldp	w0, w1, [sp, #0x20]
     964:      	bl	0xae0 <kernel>
     968:      	mov	w2, w0
     96c:      	mov	x1, x20
     970:      	mov	w0, w8
     974:      	bl	0x7b0 <__printf_chk@plt>
     978:      	mov	x2, x21
     97c:      	mov	x1, x22
     980:      	mov	x0, x19
     984:      	bl	0x7f0 <__isoc99_scanf@plt>
     988:      	mov	w8, w0
     98c:      	cmp	w0, #0x2
     990:      	b.eq	0x960 <main+0x160>
     994:      	ldp	x21, x22, [sp, #0x50]
     998:      	mov	w0, #0x0                // =0
     99c:      	ldp	x19, x20, [sp, #0x40]
     9a0:      	b	0x838 <main+0x38>
     9a4:      	ldp	x19, x20, [sp, #0x40]
     9a8:      	mov	w0, #0x2                // =2
     9ac:      	b	0x838 <main+0x38>
     9b0:      	stp	x19, x20, [sp, #0x40]
     9b4:      	stp	x21, x22, [sp, #0x50]
     9b8:      	bl	0x7c0 <__stack_chk_fail@plt>
     9bc:      	nop

00000000000009c0 <_start>:
     9c0:      	nop
     9c4:      	mov	x29, #0x0               // =0
     9c8:      	mov	x30, #0x0               // =0
     9cc:      	mov	x5, x0
     9d0:      	ldr	x1, [sp]
     9d4:      	add	x2, sp, #0x8
     9d8:      	mov	x6, sp
     9dc:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e238>
     9e0:      	ldr	x0, [x0, #0xff0]
     9e4:      	mov	x3, #0x0                // =0
     9e8:      	mov	x4, #0x0                // =0
     9ec:      	bl	0x780 <__libc_start_main@plt>
     9f0:      	bl	0x7e0 <abort@plt>

00000000000009f4 <call_weak_fn>:
     9f4:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e238>
     9f8:      	ldr	x0, [x0, #0xfe0]
     9fc:      	cbz	x0, 0xa04 <call_weak_fn+0x10>
     a00:      	b	0x7d0 <__gmon_start__@plt>
     a04:      	ret
     a08:      	nop
     a0c:      	nop

0000000000000a10 <deregister_tm_clones>:
     a10:      	adrp	x0, 0x20000 <data_start>
     a14:      	add	x0, x0, #0x10
     a18:      	adrp	x1, 0x20000 <data_start>
     a1c:      	add	x1, x1, #0x10
     a20:      	cmp	x1, x0
     a24:      	b.eq	0xa3c <deregister_tm_clones+0x2c>
     a28:      	adrp	x1, 0x1f000 <__FRAME_END__+0x1e238>
     a2c:      	ldr	x1, [x1, #0xfd0]
     a30:      	cbz	x1, 0xa3c <deregister_tm_clones+0x2c>
     a34:      	mov	x16, x1
     a38:      	br	x16
     a3c:      	ret

0000000000000a40 <register_tm_clones>:
     a40:      	adrp	x0, 0x20000 <data_start>
     a44:      	add	x0, x0, #0x10
     a48:      	adrp	x1, 0x20000 <data_start>
     a4c:      	add	x1, x1, #0x10
     a50:      	sub	x1, x1, x0
     a54:      	lsr	x2, x1, #63
     a58:      	add	x1, x2, x1, asr #3
     a5c:      	asr	x1, x1, #1
     a60:      	cbz	x1, 0xa78 <register_tm_clones+0x38>
     a64:      	adrp	x2, 0x1f000 <__FRAME_END__+0x1e238>
     a68:      	ldr	x2, [x2, #0xff8]
     a6c:      	cbz	x2, 0xa78 <register_tm_clones+0x38>
     a70:      	mov	x16, x2
     a74:      	br	x16
     a78:      	ret
     a7c:      	nop

0000000000000a80 <__do_global_dtors_aux>:
     a80:      	paciasp
     a84:      	stp	x29, x30, [sp, #-0x20]!
     a88:      	mov	x29, sp
     a8c:      	str	x19, [sp, #0x10]
     a90:      	adrp	x19, 0x20000 <data_start>
     a94:      	ldrb	w0, [x19, #0x10]
     a98:      	tbnz	w0, #0x0, 0xac0 <__do_global_dtors_aux+0x40>
     a9c:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e238>
     aa0:      	ldr	x0, [x0, #0xfd8]
     aa4:      	cbz	x0, 0xab4 <__do_global_dtors_aux+0x34>
     aa8:      	adrp	x0, 0x20000 <data_start>
     aac:      	ldr	x0, [x0, #0x8]
     ab0:      	bl	0x790 <__cxa_finalize@plt>
     ab4:      	bl	0xa10 <deregister_tm_clones>
     ab8:      	mov	w0, #0x1                // =1
     abc:      	strb	w0, [x19, #0x10]
     ac0:      	ldr	x19, [sp, #0x10]
     ac4:      	ldp	x29, x30, [sp], #0x20
     ac8:      	autiasp
     acc:      	ret

0000000000000ad0 <frame_dummy>:
     ad0:      	bti	c
     ad4:      	b	0xa40 <register_tm_clones>
     ad8:      	nop
     adc:      	nop

0000000000000ae0 <kernel>:
     ae0:      	and	w2, w1, #0xff
     ae4:      	ubfx	x6, x1, #8, #8
     ae8:      	add	w2, w2, w0, uxth
     aec:      	lsr	w0, w0, #16
     af0:      	ubfx	x5, x1, #16, #8
     af4:      	lsr	w4, w1, #24
     af8:      	add	w0, w0, w2, lsr #16
     afc:      	ubfiz	w3, w2, #10, #6
     b00:      	add	w3, w3, w2, uxth
     b04:      	ubfx	x7, x2, #6, #10
     b08:      	ubfiz	w2, w0, #10, #16
     b0c:      	orr	w1, w2, w7
     b10:      	ubfx	x2, x3, #6, #10
     b14:      	add	w1, w1, w3, lsr #16
     b18:      	add	w0, w1, w0, uxth
     b1c:      	and	w1, w0, #0xffff
     b20:      	ubfiz	w7, w0, #10, #16
     b24:      	ubfx	x0, x0, #6, #10
     b28:      	orr	w2, w2, w7
     b2c:      	eor	w0, w0, w1
     b30:      	eor	w2, w2, w3
     b34:      	add	w2, w6, w2, uxth
     b38:      	add	w0, w0, w2, lsr #16
     b3c:      	ubfiz	w1, w2, #10, #6
     b40:      	add	w3, w1, w2, uxth
     b44:      	ubfx	x6, x2, #6, #10
     b48:      	ubfiz	w1, w0, #10, #16
     b4c:      	orr	w1, w1, w6
     b50:      	ubfx	x2, x3, #6, #10
     b54:      	add	w1, w1, w3, lsr #16
     b58:      	add	w0, w1, w0, uxth
     b5c:      	and	w1, w0, #0xffff
     b60:      	ubfiz	w6, w0, #10, #16
     b64:      	ubfx	x0, x0, #6, #10
     b68:      	orr	w2, w2, w6
     b6c:      	eor	w0, w0, w1
     b70:      	eor	w2, w2, w3
     b74:      	add	w2, w5, w2, uxth
     b78:      	add	w0, w0, w2, lsr #16
     b7c:      	ubfiz	w3, w2, #10, #6
     b80:      	ubfx	x1, x2, #6, #10
     b84:      	add	w2, w3, w2, uxth
     b88:      	ubfiz	w3, w0, #10, #16
     b8c:      	orr	w3, w3, w1
     b90:      	ubfx	x1, x2, #6, #10
     b94:      	add	w3, w3, w2, lsr #16
     b98:      	add	w0, w3, w0, uxth
     b9c:      	and	w3, w0, #0xffff
     ba0:      	ubfiz	w5, w0, #10, #16
     ba4:      	ubfx	x0, x0, #6, #10
     ba8:      	orr	w1, w1, w5
     bac:      	eor	w0, w0, w3
     bb0:      	eor	w1, w1, w2
     bb4:      	add	w1, w4, w1, uxth
     bb8:      	add	w0, w0, w1, lsr #16
     bbc:      	ubfiz	w3, w1, #10, #6
     bc0:      	ubfx	x2, x1, #6, #10
     bc4:      	add	w1, w3, w1, uxth
     bc8:      	ubfiz	w3, w0, #10, #16
     bcc:      	orr	w3, w3, w2
     bd0:      	ubfx	x2, x1, #6, #10
     bd4:      	add	w3, w3, w1, lsr #16
     bd8:      	add	w0, w3, w0, uxth
     bdc:      	and	w3, w0, #0xffff
     be0:      	ubfiz	w4, w0, #10, #16
     be4:      	ubfx	x0, x0, #6, #10
     be8:      	orr	w2, w2, w4
     bec:      	eor	w0, w0, w3
     bf0:      	eor	w2, w2, w1
     bf4:      	ubfx	x1, x2, #13, #3
     bf8:      	ubfiz	w3, w2, #3, #13
     bfc:      	orr	w1, w1, w0, lsl #3
     c00:      	add	w2, w3, w2, uxth
     c04:      	add	w1, w0, w1, uxth
     c08:      	ubfx	x0, x2, #11, #5
     c0c:      	add	w1, w1, w2, lsr #16
     c10:      	and	w3, w1, #0xffff
     c14:      	ubfiz	w4, w1, #5, #16
     c18:      	ubfx	x1, x1, #11, #5
     c1c:      	orr	w0, w0, w4
     c20:      	eor	w1, w1, w3
     c24:      	eor	w0, w0, w2
     c28:      	ubfx	x2, x0, #1, #15
     c2c:      	ubfiz	w3, w0, #15, #1
     c30:      	orr	w2, w2, w1, lsl #15
     c34:      	add	w0, w3, w0, uxth
     c38:      	add	w1, w1, w2, uxth
     c3c:      	add	w1, w1, w0, lsr #16
     c40:      	bfi	w0, w1, #16, #16
     c44:      	ret

Disassembly of section .fini:

0000000000000c48 <_fini>:
     c48:      	nop
     c4c:      	stp	x29, x30, [sp, #-0x10]!
     c50:      	mov	x29, sp
     c54:      	ldp	x29, x30, [sp], #0x10
     c58:      	ret
