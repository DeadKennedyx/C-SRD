
/work/experiments/runs/jenkins-composition-matrix-linux-20261110/jenkins_word/build-clang-Oz-limbs16/program:	file format elf64-littleaarch64

Disassembly of section .init:

0000000000000678 <_init>:
     678:      	nop
     67c:      	stp	x29, x30, [sp, #-0x10]!
     680:      	mov	x29, sp
     684:      	bl	0x774 <call_weak_fn>
     688:      	ldp	x29, x30, [sp], #0x10
     68c:      	ret

Disassembly of section .plt:

0000000000000690 <.plt>:
     690:      	stp	x16, x30, [sp, #-0x10]!
     694:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e3ac>
     698:      	ldr	x17, [x16, #0xff8]
     69c:      	add	x16, x16, #0xff8
     6a0:      	br	x17
     6a4:      	nop
     6a8:      	nop
     6ac:      	nop

00000000000006b0 <strtoul@plt>:
     6b0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6b4:      	ldr	x17, [x16]
     6b8:      	add	x16, x16, #0x0
     6bc:      	br	x17

00000000000006c0 <__libc_start_main@plt>:
     6c0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6c4:      	ldr	x17, [x16, #0x8]
     6c8:      	add	x16, x16, #0x8
     6cc:      	br	x17

00000000000006d0 <__cxa_finalize@plt>:
     6d0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6d4:      	ldr	x17, [x16, #0x10]
     6d8:      	add	x16, x16, #0x10
     6dc:      	br	x17

00000000000006e0 <clock_gettime@plt>:
     6e0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6e4:      	ldr	x17, [x16, #0x18]
     6e8:      	add	x16, x16, #0x18
     6ec:      	br	x17

00000000000006f0 <__gmon_start__@plt>:
     6f0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6f4:      	ldr	x17, [x16, #0x20]
     6f8:      	add	x16, x16, #0x20
     6fc:      	br	x17

0000000000000700 <abort@plt>:
     700:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     704:      	ldr	x17, [x16, #0x28]
     708:      	add	x16, x16, #0x28
     70c:      	br	x17

0000000000000710 <__isoc99_scanf@plt>:
     710:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     714:      	ldr	x17, [x16, #0x30]
     718:      	add	x16, x16, #0x30
     71c:      	br	x17

0000000000000720 <printf@plt>:
     720:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     724:      	ldr	x17, [x16, #0x38]
     728:      	add	x16, x16, #0x38
     72c:      	br	x17

Disassembly of section .text:

0000000000000740 <_start>:
     740:      	nop
     744:      	mov	x29, #0x0               // =0
     748:      	mov	x30, #0x0               // =0
     74c:      	mov	x5, x0
     750:      	ldr	x1, [sp]
     754:      	add	x2, sp, #0x8
     758:      	mov	x6, sp
     75c:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e3ac>
     760:      	ldr	x0, [x0, #0xfd8]
     764:      	mov	x3, #0x0                // =0
     768:      	mov	x4, #0x0                // =0
     76c:      	bl	0x6c0 <__libc_start_main@plt>
     770:      	bl	0x700 <abort@plt>

0000000000000774 <call_weak_fn>:
     774:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e3ac>
     778:      	ldr	x0, [x0, #0xfd0]
     77c:      	cbz	x0, 0x784 <call_weak_fn+0x10>
     780:      	b	0x6f0 <__gmon_start__@plt>
     784:      	ret
     788:      	nop
     78c:      	nop

0000000000000790 <deregister_tm_clones>:
     790:      	adrp	x0, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     794:      	add	x0, x0, #0x50
     798:      	adrp	x1, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     79c:      	add	x1, x1, #0x50
     7a0:      	cmp	x1, x0
     7a4:      	b.eq	0x7bc <deregister_tm_clones+0x2c>
     7a8:      	adrp	x1, 0x1f000 <__FRAME_END__+0x1e3ac>
     7ac:      	ldr	x1, [x1, #0xfc0]
     7b0:      	cbz	x1, 0x7bc <deregister_tm_clones+0x2c>
     7b4:      	mov	x16, x1
     7b8:      	br	x16
     7bc:      	ret

00000000000007c0 <register_tm_clones>:
     7c0:      	adrp	x0, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     7c4:      	add	x0, x0, #0x50
     7c8:      	adrp	x1, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     7cc:      	add	x1, x1, #0x50
     7d0:      	sub	x1, x1, x0
     7d4:      	lsr	x2, x1, #63
     7d8:      	add	x1, x2, x1, asr #3
     7dc:      	asr	x1, x1, #1
     7e0:      	cbz	x1, 0x7f8 <register_tm_clones+0x38>
     7e4:      	adrp	x2, 0x1f000 <__FRAME_END__+0x1e3ac>
     7e8:      	ldr	x2, [x2, #0xfe0]
     7ec:      	cbz	x2, 0x7f8 <register_tm_clones+0x38>
     7f0:      	mov	x16, x2
     7f4:      	br	x16
     7f8:      	ret
     7fc:      	nop

0000000000000800 <__do_global_dtors_aux>:
     800:      	paciasp
     804:      	stp	x29, x30, [sp, #-0x20]!
     808:      	mov	x29, sp
     80c:      	str	x19, [sp, #0x10]
     810:      	adrp	x19, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     814:      	ldrb	w0, [x19, #0x50]
     818:      	tbnz	w0, #0x0, 0x840 <__do_global_dtors_aux+0x40>
     81c:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e3ac>
     820:      	ldr	x0, [x0, #0xfc8]
     824:      	cbz	x0, 0x834 <__do_global_dtors_aux+0x34>
     828:      	adrp	x0, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     82c:      	ldr	x0, [x0, #0x48]
     830:      	bl	0x6d0 <__cxa_finalize@plt>
     834:      	bl	0x790 <deregister_tm_clones>
     838:      	mov	w0, #0x1                // =1
     83c:      	strb	w0, [x19, #0x50]
     840:      	ldr	x19, [sp, #0x10]
     844:      	ldp	x29, x30, [sp], #0x20
     848:      	autiasp
     84c:      	ret

0000000000000850 <frame_dummy>:
     850:      	bti	c
     854:      	b	0x7c0 <register_tm_clones>

0000000000000858 <kernel>:
     858:      	and	w8, w1, #0xff
     85c:      	add	w8, w8, w0, uxth
     860:      	lsr	w9, w8, #16
     864:      	and	w10, w8, #0xffff
     868:      	ubfiz	w11, w8, #10, #6
     86c:      	add	w9, w9, w0, lsr #16
     870:      	add	w8, w11, w8, uxth
     874:      	lsr	w11, w1, #8
     878:      	add	w10, w9, w10, lsr #6
     87c:      	mov	x0, x30
     880:      	bl	0x934 <OUTLINED_FUNCTION_0>
     884:      	mov	x30, x0
     888:      	lsr	w11, w1, #16
     88c:      	mov	x0, x30
     890:      	bl	0x934 <OUTLINED_FUNCTION_0>
     894:      	mov	x30, x0
     898:      	add	w9, w10, w9, lsl #10
     89c:      	ubfx	w10, w8, #6, #10
     8a0:      	add	w9, w9, w8, lsr #16
     8a4:      	and	w8, w8, #0xffff
     8a8:      	bfi	w10, w9, #10, #6
     8ac:      	and	w11, w9, #0xffc0
     8b0:      	eor	w9, w9, w11, lsr #6
     8b4:      	eor	w8, w10, w8
     8b8:      	add	w8, w8, w1, lsr #24
     8bc:      	add	w9, w9, w8, lsr #16
     8c0:      	and	w10, w8, #0xffff
     8c4:      	ubfiz	w11, w8, #10, #6
     8c8:      	add	w10, w9, w10, lsr #6
     8cc:      	add	w8, w11, w8, uxth
     8d0:      	add	w9, w10, w9, lsl #10
     8d4:      	ubfx	w10, w8, #6, #10
     8d8:      	add	w9, w9, w8, lsr #16
     8dc:      	and	w8, w8, #0xffff
     8e0:      	and	w11, w9, #0xffc0
     8e4:      	bfi	w10, w9, #10, #6
     8e8:      	eor	w9, w9, w11, lsr #6
     8ec:      	eor	w8, w10, w8
     8f0:      	add	w9, w9, w9, lsl #3
     8f4:      	ubfiz	w10, w8, #3, #13
     8f8:      	add	w9, w9, w8, lsr #13
     8fc:      	add	w8, w10, w8
     900:      	ubfx	w10, w8, #11, #5
     904:      	add	w9, w9, w8, lsr #16
     908:      	and	w8, w8, #0xffff
     90c:      	and	w11, w9, #0xf800
     910:      	bfi	w10, w9, #5, #11
     914:      	eor	w9, w9, w11, lsr #11
     918:      	eor	w8, w10, w8
     91c:      	add	w9, w9, w9, lsl #15
     920:      	ubfiz	w10, w8, #15, #1
     924:      	add	w9, w9, w8, lsr #1
     928:      	add	w8, w10, w8
     92c:      	add	w0, w8, w9, lsl #16
     930:      	ret

0000000000000934 <OUTLINED_FUNCTION_0>:
     934:      	add	w9, w10, w9, lsl #10
     938:      	ubfx	w10, w8, #6, #10
     93c:      	add	w9, w9, w8, lsr #16
     940:      	and	w8, w8, #0xffff
     944:      	bfi	w10, w9, #10, #6
     948:      	and	w12, w9, #0xffc0
     94c:      	eor	w9, w9, w12, lsr #6
     950:      	eor	w8, w10, w8
     954:      	add	w8, w8, w11, uxtb
     958:      	add	w9, w9, w8, lsr #16
     95c:      	and	w10, w8, #0xffff
     960:      	ubfiz	w11, w8, #10, #6
     964:      	add	w10, w9, w10, lsr #6
     968:      	add	w8, w11, w8, uxth
     96c:      	ret

0000000000000970 <main>:
     970:      	sub	sp, sp, #0x60
     974:      	stp	x29, x30, [sp, #0x20]
     978:      	str	x23, [sp, #0x30]
     97c:      	stp	x22, x21, [sp, #0x40]
     980:      	stp	x20, x19, [sp, #0x50]
     984:      	add	x29, sp, #0x20
     988:      	cmp	w0, #0x3
     98c:      	b.eq	0x9dc <main+0x6c>
     990:      	cmp	w0, #0x1
     994:      	b.ne	0xa68 <main+0xf8>
     998:      	adrp	x19, 0x0 <strtoul@GLIBC_2.17>
     99c:      	add	x19, x19, #0xb00
     9a0:      	add	x21, x29, #0x18
     9a4:      	adrp	x20, 0x0 <strtoul@GLIBC_2.17>
     9a8:      	add	x20, x20, #0xb05
     9ac:      	add	x1, x29, #0x18
     9b0:      	add	x2, x21, #0x4
     9b4:      	mov	x0, x19
     9b8:      	bl	0x710 <__isoc99_scanf@plt>
     9bc:      	cmp	w0, #0x2
     9c0:      	b.ne	0xabc <main+0x14c>
     9c4:      	ldp	w0, w1, [x29, #0x18]
     9c8:      	bl	0x858 <kernel>
     9cc:      	mov	w1, w0
     9d0:      	mov	x0, x20
     9d4:      	bl	0x720 <printf@plt>
     9d8:      	b	0x9ac <main+0x3c>
     9dc:      	ldr	x0, [x1, #0x8]
     9e0:      	mov	x19, x1
     9e4:      	mov	x1, xzr
     9e8:      	mov	w2, #0xa                // =10
     9ec:      	bl	0x6b0 <strtoul@plt>
     9f0:      	ldr	x8, [x19, #0x10]
     9f4:      	mov	x20, x0
     9f8:      	mov	x1, xzr
     9fc:      	mov	w2, #0xa                // =10
     a00:      	mov	x0, x8
     a04:      	bl	0x6b0 <strtoul@plt>
     a08:      	mov	x21, x0
     a0c:      	add	x1, sp, #0x10
     a10:      	mov	w0, #0x1                // =1
     a14:      	bl	0x6e0 <clock_gettime@plt>
     a18:      	cbnz	w0, 0xa80 <main+0x110>
     a1c:      	mov	x19, xzr
     a20:      	mov	x22, xzr
     a24:      	add	x23, x29, #0x18
     a28:      	cmp	x22, x20
     a2c:      	b.eq	0xa70 <main+0x100>
     a30:      	mov	x8, xzr
     a34:      	cmp	x8, #0x8
     a38:      	b.eq	0xa54 <main+0xe4>
     a3c:      	eor	w9, w21, w21, lsl #13
     a40:      	eor	w9, w9, w9, lsr #17
     a44:      	eor	w21, w9, w9, lsl #5
     a48:      	str	w21, [x23, x8]
     a4c:      	add	x8, x8, #0x4
     a50:      	b	0xa34 <main+0xc4>
     a54:      	ldp	w0, w1, [x29, #0x18]
     a58:      	bl	0x858 <kernel>
     a5c:      	add	x19, x19, w0, uxtw
     a60:      	add	x22, x22, #0x1
     a64:      	b	0xa28 <main+0xb8>
     a68:      	mov	w0, #0x3                // =3
     a6c:      	b	0xac0 <main+0x150>
     a70:      	mov	x1, sp
     a74:      	mov	w0, #0x1                // =1
     a78:      	bl	0x6e0 <clock_gettime@plt>
     a7c:      	cbz	w0, 0xa88 <main+0x118>
     a80:      	mov	w0, #0x2                // =2
     a84:      	b	0xac0 <main+0x150>
     a88:      	ldp	x8, x9, [sp]
     a8c:      	adrp	x0, 0x0 <strtoul@GLIBC_2.17>
     a90:      	add	x0, x0, #0xb09
     a94:      	ldp	x10, x11, [sp, #0x10]
     a98:      	mov	x1, x19
     a9c:      	sub	x8, x8, x10
     aa0:      	sub	x9, x9, x11
     aa4:      	scvtf	d0, x8
     aa8:      	scvtf	d1, x9
     aac:      	adrp	x8, 0x0 <strtoul@GLIBC_2.17>
     ab0:      	ldr	d2, [x8, #0xaf8]
     ab4:      	fmadd	d0, d1, d2, d0
     ab8:      	bl	0x720 <printf@plt>
     abc:      	mov	w0, wzr
     ac0:      	ldp	x20, x19, [sp, #0x50]
     ac4:      	ldr	x23, [sp, #0x30]
     ac8:      	ldp	x22, x21, [sp, #0x40]
     acc:      	ldp	x29, x30, [sp, #0x20]
     ad0:      	add	sp, sp, #0x60
     ad4:      	ret

Disassembly of section .fini:

0000000000000ad8 <_fini>:
     ad8:      	nop
     adc:      	stp	x29, x30, [sp, #-0x10]!
     ae0:      	mov	x29, sp
     ae4:      	ldp	x29, x30, [sp], #0x10
     ae8:      	ret
