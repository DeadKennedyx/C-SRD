; ModuleID = '/work/experiments/runs/jenkins-composition-matrix-linux-20261110/jenkins_word/build-clang-Og-original/validation/compiler-0-Og/candidate.i'
source_filename = "/work/experiments/runs/jenkins-composition-matrix-linux-20261110/jenkins_word/build-clang-Og-original/validation/compiler-0-Og/candidate.i"
target datalayout = "e-m:e-i8:8:32-i16:16:32-i64:64-i128:128-n32:64-S128"
target triple = "aarch64-unknown-linux-gnu"

; Function Attrs: nofree norecurse nosync nounwind memory(none) uwtable
define dso_local i32 @kernel(i32 noundef %0, i32 noundef %1) local_unnamed_addr #0 {
  br label %8

3:                                                ; preds = %8
  %4 = mul i32 %16, 9
  %5 = lshr i32 %4, 11
  %6 = xor i32 %5, %4
  %7 = mul i32 %6, 32769
  ret i32 %7

8:                                                ; preds = %2, %8
  %9 = phi i32 [ 0, %2 ], [ %18, %8 ]
  %10 = phi i32 [ %1, %2 ], [ %17, %8 ]
  %11 = phi i32 [ %0, %2 ], [ %16, %8 ]
  %12 = and i32 %10, 255
  %13 = add i32 %12, %11
  %14 = mul i32 %13, 1025
  %15 = lshr i32 %14, 6
  %16 = xor i32 %15, %14
  %17 = lshr i32 %10, 8
  %18 = add nuw nsw i32 %9, 1
  %19 = icmp eq i32 %18, 4
  br i1 %19, label %3, label %8, !llvm.loop !6
}

attributes #0 = { nofree norecurse nosync nounwind memory(none) uwtable "frame-pointer"="non-leaf" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+fp-armv8,+neon,+outline-atomics,+v8a,-fmv" }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 1, !"wchar_size", i32 4}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 1}
!5 = !{!"Ubuntu clang version 18.1.3 (1ubuntu1)"}
!6 = distinct !{!6, !7, !8}
!7 = !{!"llvm.loop.mustprogress"}
!8 = !{!"llvm.loop.unroll.disable"}
