
/work/experiments/runs/jenkins-composition-matrix-linux-20261110/jenkins_word/build-gcc-O1-limbs16/program:	file format elf64-littleaarch64

Disassembly of section .init:

0000000000000738 <_init>:
     738:      	nop
     73c:      	stp	x29, x30, [sp, #-0x10]!
     740:      	mov	x29, sp
     744:      	bl	0x834 <call_weak_fn>
     748:      	ldp	x29, x30, [sp], #0x10
     74c:      	ret

Disassembly of section .plt:

0000000000000750 <.plt>:
     750:      	stp	x16, x30, [sp, #-0x10]!
     754:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e224>
     758:      	ldr	x17, [x16, #0xf78]
     75c:      	add	x16, x16, #0xf78
     760:      	br	x17
     764:      	nop
     768:      	nop
     76c:      	nop

0000000000000770 <strtoul@plt>:
     770:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e224>
     774:      	ldr	x17, [x16, #0xf80]
     778:      	add	x16, x16, #0xf80
     77c:      	br	x17

0000000000000780 <__libc_start_main@plt>:
     780:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e224>
     784:      	ldr	x17, [x16, #0xf88]
     788:      	add	x16, x16, #0xf88
     78c:      	br	x17

0000000000000790 <__cxa_finalize@plt>:
     790:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e224>
     794:      	ldr	x17, [x16, #0xf90]
     798:      	add	x16, x16, #0xf90
     79c:      	br	x17

00000000000007a0 <clock_gettime@plt>:
     7a0:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e224>
     7a4:      	ldr	x17, [x16, #0xf98]
     7a8:      	add	x16, x16, #0xf98
     7ac:      	br	x17

00000000000007b0 <__printf_chk@plt>:
     7b0:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e224>
     7b4:      	ldr	x17, [x16, #0xfa0]
     7b8:      	add	x16, x16, #0xfa0
     7bc:      	br	x17

00000000000007c0 <__stack_chk_fail@plt>:
     7c0:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e224>
     7c4:      	ldr	x17, [x16, #0xfa8]
     7c8:      	add	x16, x16, #0xfa8
     7cc:      	br	x17

00000000000007d0 <__gmon_start__@plt>:
     7d0:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e224>
     7d4:      	ldr	x17, [x16, #0xfb0]
     7d8:      	add	x16, x16, #0xfb0
     7dc:      	br	x17

00000000000007e0 <abort@plt>:
     7e0:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e224>
     7e4:      	ldr	x17, [x16, #0xfb8]
     7e8:      	add	x16, x16, #0xfb8
     7ec:      	br	x17

00000000000007f0 <__isoc99_scanf@plt>:
     7f0:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e224>
     7f4:      	ldr	x17, [x16, #0xfc0]
     7f8:      	add	x16, x16, #0xfc0
     7fc:      	br	x17

Disassembly of section .text:

0000000000000800 <_start>:
     800:      	nop
     804:      	mov	x29, #0x0               // =0
     808:      	mov	x30, #0x0               // =0
     80c:      	mov	x5, x0
     810:      	ldr	x1, [sp]
     814:      	add	x2, sp, #0x8
     818:      	mov	x6, sp
     81c:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e224>
     820:      	ldr	x0, [x0, #0xff0]
     824:      	mov	x3, #0x0                // =0
     828:      	mov	x4, #0x0                // =0
     82c:      	bl	0x780 <__libc_start_main@plt>
     830:      	bl	0x7e0 <abort@plt>

0000000000000834 <call_weak_fn>:
     834:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e224>
     838:      	ldr	x0, [x0, #0xfe0]
     83c:      	cbz	x0, 0x844 <call_weak_fn+0x10>
     840:      	b	0x7d0 <__gmon_start__@plt>
     844:      	ret
     848:      	nop
     84c:      	nop

0000000000000850 <deregister_tm_clones>:
     850:      	adrp	x0, 0x20000 <data_start>
     854:      	add	x0, x0, #0x10
     858:      	adrp	x1, 0x20000 <data_start>
     85c:      	add	x1, x1, #0x10
     860:      	cmp	x1, x0
     864:      	b.eq	0x87c <deregister_tm_clones+0x2c>
     868:      	adrp	x1, 0x1f000 <__FRAME_END__+0x1e224>
     86c:      	ldr	x1, [x1, #0xfd0]
     870:      	cbz	x1, 0x87c <deregister_tm_clones+0x2c>
     874:      	mov	x16, x1
     878:      	br	x16
     87c:      	ret

0000000000000880 <register_tm_clones>:
     880:      	adrp	x0, 0x20000 <data_start>
     884:      	add	x0, x0, #0x10
     888:      	adrp	x1, 0x20000 <data_start>
     88c:      	add	x1, x1, #0x10
     890:      	sub	x1, x1, x0
     894:      	lsr	x2, x1, #63
     898:      	add	x1, x2, x1, asr #3
     89c:      	asr	x1, x1, #1
     8a0:      	cbz	x1, 0x8b8 <register_tm_clones+0x38>
     8a4:      	adrp	x2, 0x1f000 <__FRAME_END__+0x1e224>
     8a8:      	ldr	x2, [x2, #0xff8]
     8ac:      	cbz	x2, 0x8b8 <register_tm_clones+0x38>
     8b0:      	mov	x16, x2
     8b4:      	br	x16
     8b8:      	ret
     8bc:      	nop

00000000000008c0 <__do_global_dtors_aux>:
     8c0:      	paciasp
     8c4:      	stp	x29, x30, [sp, #-0x20]!
     8c8:      	mov	x29, sp
     8cc:      	str	x19, [sp, #0x10]
     8d0:      	adrp	x19, 0x20000 <data_start>
     8d4:      	ldrb	w0, [x19, #0x10]
     8d8:      	tbnz	w0, #0x0, 0x900 <__do_global_dtors_aux+0x40>
     8dc:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e224>
     8e0:      	ldr	x0, [x0, #0xfd8]
     8e4:      	cbz	x0, 0x8f4 <__do_global_dtors_aux+0x34>
     8e8:      	adrp	x0, 0x20000 <data_start>
     8ec:      	ldr	x0, [x0, #0x8]
     8f0:      	bl	0x790 <__cxa_finalize@plt>
     8f4:      	bl	0x850 <deregister_tm_clones>
     8f8:      	mov	w0, #0x1                // =1
     8fc:      	strb	w0, [x19, #0x10]
     900:      	ldr	x19, [sp, #0x10]
     904:      	ldp	x29, x30, [sp], #0x20
     908:      	autiasp
     90c:      	ret

0000000000000910 <frame_dummy>:
     910:      	bti	c
     914:      	b	0x880 <register_tm_clones>

0000000000000918 <kernel>:
     918:      	and	w2, w1, #0xff
     91c:      	add	w2, w2, w0, uxth
     920:      	lsr	w0, w0, #16
     924:      	add	w0, w0, w2, lsr #16
     928:      	ubfiz	w3, w2, #10, #6
     92c:      	add	w3, w3, w2, uxth
     930:      	ubfiz	w4, w0, #10, #16
     934:      	ubfx	x2, x2, #6, #10
     938:      	orr	w2, w4, w2
     93c:      	add	w2, w2, w3, lsr #16
     940:      	add	w0, w2, w0, uxth
     944:      	and	w4, w0, #0xffff
     948:      	ubfx	x5, x1, #8, #8
     94c:      	ubfx	x2, x3, #6, #10
     950:      	ubfiz	w6, w0, #10, #16
     954:      	orr	w2, w2, w6
     958:      	eor	w2, w2, w3
     95c:      	add	w2, w5, w2, uxth
     960:      	ubfx	x0, x0, #6, #10
     964:      	eor	w0, w0, w4
     968:      	add	w0, w0, w2, lsr #16
     96c:      	ubfiz	w3, w2, #10, #6
     970:      	add	w3, w3, w2, uxth
     974:      	ubfiz	w4, w0, #10, #16
     978:      	ubfx	x2, x2, #6, #10
     97c:      	orr	w2, w4, w2
     980:      	add	w2, w2, w3, lsr #16
     984:      	add	w0, w2, w0, uxth
     988:      	and	w4, w0, #0xffff
     98c:      	ubfx	x5, x1, #16, #8
     990:      	ubfx	x2, x3, #6, #10
     994:      	ubfiz	w6, w0, #10, #16
     998:      	orr	w2, w2, w6
     99c:      	eor	w2, w2, w3
     9a0:      	add	w2, w5, w2, uxth
     9a4:      	ubfx	x0, x0, #6, #10
     9a8:      	eor	w0, w0, w4
     9ac:      	add	w0, w0, w2, lsr #16
     9b0:      	ubfiz	w3, w2, #10, #6
     9b4:      	add	w3, w3, w2, uxth
     9b8:      	ubfiz	w4, w0, #10, #16
     9bc:      	ubfx	x2, x2, #6, #10
     9c0:      	orr	w2, w4, w2
     9c4:      	add	w2, w2, w3, lsr #16
     9c8:      	add	w0, w2, w0, uxth
     9cc:      	and	w4, w0, #0xffff
     9d0:      	ubfx	x2, x3, #6, #10
     9d4:      	ubfiz	w5, w0, #10, #16
     9d8:      	orr	w2, w2, w5
     9dc:      	eor	w2, w2, w3
     9e0:      	lsr	w1, w1, #24
     9e4:      	add	w1, w1, w2, uxth
     9e8:      	ubfx	x0, x0, #6, #10
     9ec:      	eor	w0, w0, w4
     9f0:      	add	w0, w0, w1, lsr #16
     9f4:      	ubfiz	w2, w1, #10, #6
     9f8:      	add	w2, w2, w1, uxth
     9fc:      	ubfiz	w3, w0, #10, #16
     a00:      	ubfx	x1, x1, #6, #10
     a04:      	orr	w1, w3, w1
     a08:      	add	w1, w1, w2, lsr #16
     a0c:      	add	w0, w1, w0, uxth
     a10:      	and	w3, w0, #0xffff
     a14:      	ubfx	x1, x2, #6, #10
     a18:      	ubfiz	w4, w0, #10, #16
     a1c:      	orr	w1, w1, w4
     a20:      	eor	w1, w1, w2
     a24:      	ubfx	x0, x0, #6, #10
     a28:      	eor	w0, w0, w3
     a2c:      	ubfiz	w3, w1, #3, #13
     a30:      	add	w3, w3, w1, uxth
     a34:      	ubfx	x1, x1, #13, #3
     a38:      	orr	w1, w1, w0, lsl #3
     a3c:      	add	w0, w0, w1, uxth
     a40:      	add	w0, w0, w3, lsr #16
     a44:      	and	w1, w0, #0xffff
     a48:      	ubfx	x2, x3, #11, #5
     a4c:      	ubfiz	w4, w0, #5, #16
     a50:      	orr	w2, w2, w4
     a54:      	eor	w2, w2, w3
     a58:      	ubfx	x0, x0, #11, #5
     a5c:      	eor	w1, w0, w1
     a60:      	ubfiz	w0, w2, #15, #1
     a64:      	add	w0, w0, w2, uxth
     a68:      	ubfx	x2, x2, #1, #15
     a6c:      	orr	w2, w2, w1, lsl #15
     a70:      	add	w2, w1, w2, uxth
     a74:      	add	w2, w2, w0, lsr #16
     a78:      	bfi	w0, w2, #16, #16
     a7c:      	ret

0000000000000a80 <main>:
     a80:      	sub	sp, sp, #0x60
     a84:      	stp	x29, x30, [sp, #0x30]
     a88:      	add	x29, sp, #0x30
     a8c:      	stp	x19, x20, [sp, #0x40]
     a90:      	mov	x19, x1
     a94:      	adrp	x1, 0x1f000 <__FRAME_END__+0x1e224>
     a98:      	ldr	x1, [x1, #0xfe8]
     a9c:      	ldr	x2, [x1]
     aa0:      	str	x2, [sp, #0x28]
     aa4:      	mov	x2, #0x0                // =0
     aa8:      	cmp	w0, #0x1
     aac:      	b.eq	0xaec <main+0x6c>
     ab0:      	mov	w20, #0x3               // =3
     ab4:      	cmp	w0, w20
     ab8:      	b.eq	0xb4c <main+0xcc>
     abc:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e224>
     ac0:      	ldr	x0, [x0, #0xfe8]
     ac4:      	ldr	x2, [sp, #0x28]
     ac8:      	ldr	x1, [x0]
     acc:      	subs	x2, x2, x1
     ad0:      	mov	x1, #0x0                // =0
     ad4:      	b.ne	0xc54 <main+0x1d4>
     ad8:      	mov	w0, w20
     adc:      	ldp	x19, x20, [sp, #0x40]
     ae0:      	ldp	x29, x30, [sp, #0x30]
     ae4:      	add	sp, sp, #0x60
     ae8:      	ret
     aec:      	stp	x21, x22, [sp, #0x50]
     af0:      	add	x22, sp, #0x20
     af4:      	add	x21, sp, #0x24
     af8:      	adrp	x19, 0x0 <strtoul@GLIBC_2.17>
     afc:      	add	x19, x19, #0xc80
     b00:      	adrp	x20, 0x0 <strtoul@GLIBC_2.17>
     b04:      	add	x20, x20, #0xc78
     b08:      	b	0xb28 <main+0xa8>
     b0c:      	ldr	w1, [sp, #0x24]
     b10:      	ldr	w0, [sp, #0x20]
     b14:      	bl	0x918 <kernel>
     b18:      	mov	w2, w0
     b1c:      	mov	x1, x20
     b20:      	mov	w0, #0x2                // =2
     b24:      	bl	0x7b0 <__printf_chk@plt>
     b28:      	mov	x2, x21
     b2c:      	mov	x1, x22
     b30:      	mov	x0, x19
     b34:      	bl	0x7f0 <__isoc99_scanf@plt>
     b38:      	cmp	w0, #0x2
     b3c:      	b.eq	0xb0c <main+0x8c>
     b40:      	mov	w20, #0x0               // =0
     b44:      	ldp	x21, x22, [sp, #0x50]
     b48:      	b	0xabc <main+0x3c>
     b4c:      	stp	x21, x22, [sp, #0x50]
     b50:      	mov	w2, #0xa                // =10
     b54:      	mov	x1, #0x0                // =0
     b58:      	ldr	x0, [x19, #0x8]
     b5c:      	bl	0x770 <strtoul@plt>
     b60:      	mov	x21, x0
     b64:      	mov	w2, #0xa                // =10
     b68:      	mov	x1, #0x0                // =0
     b6c:      	ldr	x0, [x19, #0x10]
     b70:      	bl	0x770 <strtoul@plt>
     b74:      	mov	x19, x0
     b78:      	mov	x1, sp
     b7c:      	mov	w0, #0x1                // =1
     b80:      	bl	0x7a0 <clock_gettime@plt>
     b84:      	cbnz	w0, 0xc3c <main+0x1bc>
     b88:      	cbz	x21, 0xc34 <main+0x1b4>
     b8c:      	mov	x20, #0x0               // =0
     b90:      	mov	x22, #0x0               // =0
     b94:      	eor	w19, w19, w19, lsl #13
     b98:      	eor	w19, w19, w19, lsr #17
     b9c:      	eor	w0, w19, w19, lsl #5
     ba0:      	str	w0, [sp, #0x20]
     ba4:      	eor	w19, w0, w0, lsl #13
     ba8:      	eor	w19, w19, w19, lsr #17
     bac:      	eor	w19, w19, w19, lsl #5
     bb0:      	str	w19, [sp, #0x24]
     bb4:      	mov	w1, w19
     bb8:      	bl	0x918 <kernel>
     bbc:      	add	x22, x22, w0, uxtw
     bc0:      	add	x20, x20, #0x1
     bc4:      	cmp	x21, x20
     bc8:      	b.ne	0xb94 <main+0x114>
     bcc:      	add	x1, sp, #0x10
     bd0:      	mov	w0, #0x1                // =1
     bd4:      	bl	0x7a0 <clock_gettime@plt>
     bd8:      	mov	w20, w0
     bdc:      	cbnz	w0, 0xc48 <main+0x1c8>
     be0:      	ldr	x0, [sp, #0x18]
     be4:      	ldr	x1, [sp, #0x8]
     be8:      	sub	x0, x0, x1
     bec:      	fmov	d1, x0
     bf0:      	scvtf	d1, d1
     bf4:      	adrp	x0, 0x0 <strtoul@GLIBC_2.17>
     bf8:      	ldr	d0, [x0, #0xc98]
     bfc:      	fmul	d1, d1, d0
     c00:      	ldr	x0, [sp, #0x10]
     c04:      	ldr	x1, [sp]
     c08:      	sub	x0, x0, x1
     c0c:      	fmov	d0, x0
     c10:      	scvtf	d0, d0
     c14:      	mov	x2, x22
     c18:      	fadd	d0, d1, d0
     c1c:      	adrp	x1, 0x0 <strtoul@GLIBC_2.17>
     c20:      	add	x1, x1, #0xc88
     c24:      	mov	w0, #0x2                // =2
     c28:      	bl	0x7b0 <__printf_chk@plt>
     c2c:      	ldp	x21, x22, [sp, #0x50]
     c30:      	b	0xabc <main+0x3c>
     c34:      	mov	x22, x21
     c38:      	b	0xbcc <main+0x14c>
     c3c:      	mov	w20, #0x2               // =2
     c40:      	ldp	x21, x22, [sp, #0x50]
     c44:      	b	0xabc <main+0x3c>
     c48:      	mov	w20, #0x2               // =2
     c4c:      	ldp	x21, x22, [sp, #0x50]
     c50:      	b	0xabc <main+0x3c>
     c54:      	stp	x21, x22, [sp, #0x50]
     c58:      	bl	0x7c0 <__stack_chk_fail@plt>

Disassembly of section .fini:

0000000000000c5c <_fini>:
     c5c:      	nop
     c60:      	stp	x29, x30, [sp, #-0x10]!
     c64:      	mov	x29, sp
     c68:      	ldp	x29, x30, [sp], #0x10
     c6c:      	ret
