
/work/experiments/runs/jenkins-composition-matrix-linux-20261110/jenkins_word/build-gcc-O1-sanitizers-affine-42/program:	file format elf64-littleaarch64

Disassembly of section .init:

00000000000011c0 <_init>:
    11c0:      	nop
    11c4:      	stp	x29, x30, [sp, #-0x10]!
    11c8:      	mov	x29, sp
    11cc:      	bl	0x13b4 <call_weak_fn>
    11d0:      	ldp	x29, x30, [sp], #0x10
    11d4:      	ret

Disassembly of section .plt:

00000000000011e0 <.plt>:
    11e0:      	stp	x16, x30, [sp, #-0x10]!
    11e4:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1d07c>
    11e8:      	ldr	x17, [x16, #0xf08]
    11ec:      	add	x16, x16, #0xf08
    11f0:      	br	x17
    11f4:      	nop
    11f8:      	nop
    11fc:      	nop

0000000000001200 <__asan_report_store4@plt>:
    1200:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1d07c>
    1204:      	ldr	x17, [x16, #0xf10]
    1208:      	add	x16, x16, #0xf10
    120c:      	br	x17

0000000000001210 <__ubsan_handle_type_mismatch_v1_abort@plt>:
    1210:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1d07c>
    1214:      	ldr	x17, [x16, #0xf18]
    1218:      	add	x16, x16, #0xf18
    121c:      	br	x17

0000000000001220 <__asan_register_globals@plt>:
    1220:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1d07c>
    1224:      	ldr	x17, [x16, #0xf20]
    1228:      	add	x16, x16, #0xf20
    122c:      	br	x17

0000000000001230 <__stack_chk_fail@plt>:
    1230:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1d07c>
    1234:      	ldr	x17, [x16, #0xf28]
    1238:      	add	x16, x16, #0xf28
    123c:      	br	x17

0000000000001240 <__ubsan_handle_nonnull_arg_abort@plt>:
    1240:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1d07c>
    1244:      	ldr	x17, [x16, #0xf30]
    1248:      	add	x16, x16, #0xf30
    124c:      	br	x17

0000000000001250 <__ubsan_handle_sub_overflow_abort@plt>:
    1250:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1d07c>
    1254:      	ldr	x17, [x16, #0xf38]
    1258:      	add	x16, x16, #0xf38
    125c:      	br	x17

0000000000001260 <__asan_report_load4@plt>:
    1260:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1d07c>
    1264:      	ldr	x17, [x16, #0xf40]
    1268:      	add	x16, x16, #0xf40
    126c:      	br	x17

0000000000001270 <__cxa_finalize@plt>:
    1270:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1d07c>
    1274:      	ldr	x17, [x16, #0xf48]
    1278:      	add	x16, x16, #0xf48
    127c:      	br	x17

0000000000001280 <__libc_start_main@plt>:
    1280:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1d07c>
    1284:      	ldr	x17, [x16, #0xf50]
    1288:      	add	x16, x16, #0xf50
    128c:      	br	x17

0000000000001290 <__asan_unregister_globals@plt>:
    1290:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1d07c>
    1294:      	ldr	x17, [x16, #0xf58]
    1298:      	add	x16, x16, #0xf58
    129c:      	br	x17

00000000000012a0 <__asan_handle_no_return@plt>:
    12a0:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1d07c>
    12a4:      	ldr	x17, [x16, #0xf60]
    12a8:      	add	x16, x16, #0xf60
    12ac:      	br	x17

00000000000012b0 <__asan_init@plt>:
    12b0:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1d07c>
    12b4:      	ldr	x17, [x16, #0xf68]
    12b8:      	add	x16, x16, #0xf68
    12bc:      	br	x17

00000000000012c0 <strtoul@plt>:
    12c0:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1d07c>
    12c4:      	ldr	x17, [x16, #0xf70]
    12c8:      	add	x16, x16, #0xf70
    12cc:      	br	x17

00000000000012d0 <clock_gettime@plt>:
    12d0:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1d07c>
    12d4:      	ldr	x17, [x16, #0xf78]
    12d8:      	add	x16, x16, #0xf78
    12dc:      	br	x17

00000000000012e0 <__asan_report_load8@plt>:
    12e0:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1d07c>
    12e4:      	ldr	x17, [x16, #0xf80]
    12e8:      	add	x16, x16, #0xf80
    12ec:      	br	x17

00000000000012f0 <abort@plt>:
    12f0:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1d07c>
    12f4:      	ldr	x17, [x16, #0xf88]
    12f8:      	add	x16, x16, #0xf88
    12fc:      	br	x17

0000000000001300 <__asan_stack_malloc_2@plt>:
    1300:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1d07c>
    1304:      	ldr	x17, [x16, #0xf90]
    1308:      	add	x16, x16, #0xf90
    130c:      	br	x17

0000000000001310 <__asan_version_mismatch_check_v8@plt>:
    1310:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1d07c>
    1314:      	ldr	x17, [x16, #0xf98]
    1318:      	add	x16, x16, #0xf98
    131c:      	br	x17

0000000000001320 <__isoc99_scanf@plt>:
    1320:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1d07c>
    1324:      	ldr	x17, [x16, #0xfa0]
    1328:      	add	x16, x16, #0xfa0
    132c:      	br	x17

0000000000001330 <__printf_chk@plt>:
    1330:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1d07c>
    1334:      	ldr	x17, [x16, #0xfa8]
    1338:      	add	x16, x16, #0xfa8
    133c:      	br	x17

0000000000001340 <__gmon_start__@plt>:
    1340:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1d07c>
    1344:      	ldr	x17, [x16, #0xfb0]
    1348:      	add	x16, x16, #0xfb0
    134c:      	br	x17

0000000000001350 <__ubsan_handle_pointer_overflow_abort@plt>:
    1350:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1d07c>
    1354:      	ldr	x17, [x16, #0xfb8]
    1358:      	add	x16, x16, #0xfb8
    135c:      	br	x17

Disassembly of section .text:

0000000000001380 <_start>:
    1380:      	nop
    1384:      	mov	x29, #0x0               // =0
    1388:      	mov	x30, #0x0               // =0
    138c:      	mov	x5, x0
    1390:      	ldr	x1, [sp]
    1394:      	add	x2, sp, #0x8
    1398:      	mov	x6, sp
    139c:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1d07c>
    13a0:      	ldr	x0, [x0, #0xfd0]
    13a4:      	mov	x3, #0x0                // =0
    13a8:      	mov	x4, #0x0                // =0
    13ac:      	bl	0x1280 <__libc_start_main@plt>
    13b0:      	bl	0x12f0 <abort@plt>

00000000000013b4 <call_weak_fn>:
    13b4:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1d07c>
    13b8:      	ldr	x0, [x0, #0xff0]
    13bc:      	cbz	x0, 0x13c4 <call_weak_fn+0x10>
    13c0:      	b	0x1340 <__gmon_start__@plt>
    13c4:      	ret
    13c8:      	nop
    13cc:      	nop

00000000000013d0 <deregister_tm_clones>:
    13d0:      	adrp	x0, 0x20000 <data_start>
    13d4:      	add	x0, x0, #0x780
    13d8:      	adrp	x1, 0x20000 <data_start>
    13dc:      	add	x1, x1, #0x780
    13e0:      	cmp	x1, x0
    13e4:      	b.eq	0x13fc <deregister_tm_clones+0x2c>
    13e8:      	adrp	x1, 0x1f000 <__FRAME_END__+0x1d07c>
    13ec:      	ldr	x1, [x1, #0xfe8]
    13f0:      	cbz	x1, 0x13fc <deregister_tm_clones+0x2c>
    13f4:      	mov	x16, x1
    13f8:      	br	x16
    13fc:      	ret

0000000000001400 <register_tm_clones>:
    1400:      	adrp	x0, 0x20000 <data_start>
    1404:      	add	x0, x0, #0x780
    1408:      	adrp	x1, 0x20000 <data_start>
    140c:      	add	x1, x1, #0x780
    1410:      	sub	x1, x1, x0
    1414:      	lsr	x2, x1, #63
    1418:      	add	x1, x2, x1, asr #3
    141c:      	asr	x1, x1, #1
    1420:      	cbz	x1, 0x1438 <register_tm_clones+0x38>
    1424:      	adrp	x2, 0x1f000 <__FRAME_END__+0x1d07c>
    1428:      	ldr	x2, [x2, #0xff8]
    142c:      	cbz	x2, 0x1438 <register_tm_clones+0x38>
    1430:      	mov	x16, x2
    1434:      	br	x16
    1438:      	ret
    143c:      	nop

0000000000001440 <__do_global_dtors_aux>:
    1440:      	paciasp
    1444:      	stp	x29, x30, [sp, #-0x20]!
    1448:      	mov	x29, sp
    144c:      	str	x19, [sp, #0x10]
    1450:      	adrp	x19, 0x20000 <data_start>
    1454:      	ldrb	w0, [x19, #0x780]
    1458:      	tbnz	w0, #0x0, 0x1480 <__do_global_dtors_aux+0x40>
    145c:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1d07c>
    1460:      	ldr	x0, [x0, #0xfd8]
    1464:      	cbz	x0, 0x1474 <__do_global_dtors_aux+0x34>
    1468:      	adrp	x0, 0x20000 <data_start>
    146c:      	ldr	x0, [x0, #0x8]
    1470:      	bl	0x1270 <__cxa_finalize@plt>
    1474:      	bl	0x13d0 <deregister_tm_clones>
    1478:      	mov	w0, #0x1                // =1
    147c:      	strb	w0, [x19, #0x780]
    1480:      	ldr	x19, [sp, #0x10]
    1484:      	ldp	x29, x30, [sp], #0x20
    1488:      	autiasp
    148c:      	ret

0000000000001490 <frame_dummy>:
    1490:      	bti	c
    1494:      	b	0x1400 <register_tm_clones>

0000000000001498 <kernel>:
    1498:      	add	w0, w0, w1, uxtb
    149c:      	add	w0, w0, w0, lsl #10
    14a0:      	eor	w0, w0, w0, lsr #6
    14a4:      	ubfx	x2, x1, #8, #8
    14a8:      	add	w0, w0, w2
    14ac:      	add	w0, w0, w0, lsl #10
    14b0:      	eor	w0, w0, w0, lsr #6
    14b4:      	ubfx	x2, x1, #16, #8
    14b8:      	add	w0, w0, w2
    14bc:      	add	w0, w0, w0, lsl #10
    14c0:      	eor	w0, w0, w0, lsr #6
    14c4:      	add	w0, w0, w1, lsr #24
    14c8:      	add	w0, w0, w0, lsl #10
    14cc:      	eor	w0, w0, w0, lsr #6
    14d0:      	add	w0, w0, w0, lsl #3
    14d4:      	eor	w0, w0, w0, lsr #11
    14d8:      	add	w0, w0, w0, lsl #15
    14dc:      	ret

00000000000014e0 <_sub_I_00099_0>:
    14e0:      	stp	x29, x30, [sp, #-0x10]!
    14e4:      	mov	x29, sp
    14e8:      	bl	0x12b0 <__asan_init@plt>
    14ec:      	bl	0x1310 <__asan_version_mismatch_check_v8@plt>
    14f0:      	ldp	x29, x30, [sp], #0x10
    14f4:      	ret

00000000000014f8 <main>:
    14f8:      	sub	sp, sp, #0x130
    14fc:      	stp	x29, x30, [sp, #0xd0]
    1500:      	add	x29, sp, #0xd0
    1504:      	stp	x19, x20, [sp, #0xe0]
    1508:      	stp	x21, x22, [sp, #0xf0]
    150c:      	stp	x23, x24, [sp, #0x100]
    1510:      	stp	x27, x28, [sp, #0x120]
    1514:      	mov	w21, w0
    1518:      	mov	x20, x1
    151c:      	add	x23, sp, #0x10
    1520:      	mov	x28, x23
    1524:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1d07c>
    1528:      	ldr	x0, [x0, #0xfe0]
    152c:      	ldr	w0, [x0]
    1530:      	cbnz	w0, 0x183c <main+0x344>
    1534:      	mov	x19, x23
    1538:      	mov	x0, #0x8ab3             // =35507
    153c:      	movk	x0, #0x41b5, lsl #16
    1540:      	str	x0, [x19], #0xc0
    1544:      	adrp	x0, 0x1000 <strtoul@GLIBC_2.17+0x1000>
    1548:      	add	x0, x0, #0xb08
    154c:      	str	x0, [x23, #0x8]
    1550:      	adrp	x0, 0x1000 <strtoul@GLIBC_2.17+0x1000>
    1554:      	add	x0, x0, #0x4f8
    1558:      	str	x0, [x23, #0x10]
    155c:      	lsr	x24, x23, #3
    1560:      	mov	x0, #0x1000000000       // =68719476736
    1564:      	add	x1, x24, x0
    1568:      	mov	w2, #-0xe0e0e0f         // =-235802127
    156c:      	str	w2, [x24, x0]
    1570:      	add	w2, w2, #0x130, lsl #12 // =0x130000
    1574:      	str	w2, [x1, #0x4]
    1578:      	mov	w0, #-0xd0e0000         // =-219021312
    157c:      	str	w0, [x1, #0x8]
    1580:      	str	w0, [x1, #0xc]
    1584:      	mov	w0, #0xf300             // =62208
    1588:      	movk	w0, #0xf3f3, lsl #16
    158c:      	str	w0, [x1, #0x10]
    1590:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1d07c>
    1594:      	ldr	x0, [x0, #0xfc8]
    1598:      	ldr	x1, [x0]
    159c:      	str	x1, [sp, #0xc8]
    15a0:      	mov	x1, #0x0                // =0
    15a4:      	cmp	w21, #0x1
    15a8:      	b.eq	0x1850 <main+0x358>
    15ac:      	cmp	w21, #0x3
    15b0:      	b.ne	0x19f8 <main+0x500>
    15b4:      	stp	x25, x26, [sp, #0x110]
    15b8:      	add	x2, x20, #0x8
    15bc:      	cmn	x20, #0x8
    15c0:      	b.hs	0x18f4 <main+0x3fc>
    15c4:      	adds	x1, x20, #0x8
    15c8:      	b.eq	0x1904 <main+0x40c>
    15cc:      	tst	x1, #0x7
    15d0:      	b.ne	0x1904 <main+0x40c>
    15d4:      	add	x0, x20, #0x8
    15d8:      	lsr	x2, x0, #3
    15dc:      	mov	x1, #0x1000000000       // =68719476736
    15e0:      	ldrsb	w1, [x2, x1]
    15e4:      	cbnz	w1, 0x1914 <main+0x41c>
    15e8:      	ldr	x0, [x20, #0x8]
    15ec:      	cbz	x0, 0x1918 <main+0x420>
    15f0:      	mov	w2, #0xa                // =10
    15f4:      	mov	x1, #0x0                // =0
    15f8:      	bl	0x12c0 <strtoul@plt>
    15fc:      	mov	x25, x0
    1600:      	add	x2, x20, #0x10
    1604:      	cmn	x20, #0x10
    1608:      	b.hs	0x192c <main+0x434>
    160c:      	adds	x1, x20, #0x10
    1610:      	b.eq	0x1940 <main+0x448>
    1614:      	tst	x1, #0x7
    1618:      	b.ne	0x1940 <main+0x448>
    161c:      	add	x0, x20, #0x10
    1620:      	lsr	x2, x0, #3
    1624:      	mov	x1, #0x1000000000       // =68719476736
    1628:      	ldrsb	w1, [x2, x1]
    162c:      	cbnz	w1, 0x1950 <main+0x458>
    1630:      	ldr	x0, [x20, #0x10]
    1634:      	cbz	x0, 0x1954 <main+0x45c>
    1638:      	mov	w2, #0xa                // =10
    163c:      	mov	x1, #0x0                // =0
    1640:      	bl	0x12c0 <strtoul@plt>
    1644:      	sub	x2, x19, #0x90
    1648:      	lsr	x3, x2, #3
    164c:      	mov	x1, #0x1000000000       // =68719476736
    1650:      	ldrsb	w1, [x3, x1]
    1654:      	cmp	w1, #0x0
    1658:      	mov	w3, #0x3                // =3
    165c:      	ccmp	w3, w1, #0x1, ne
    1660:      	b.ge	0x1968 <main+0x470>
    1664:      	stur	w0, [x19, #-0x90]
    1668:      	sub	x1, x19, #0x80
    166c:      	mov	w0, #0x1                // =1
    1670:      	bl	0x12d0 <clock_gettime@plt>
    1674:      	cbnz	w0, 0x1a50 <main+0x558>
    1678:      	cbz	x25, 0x19b8 <main+0x4c0>
    167c:      	mov	x21, #0x0               // =0
    1680:      	mov	x22, #0x0               // =0
    1684:      	sub	x0, x19, #0x90
    1688:      	str	x0, [sp, #0x8]
    168c:      	lsr	x27, x0, #3
    1690:      	sub	x20, x19, #0x40
    1694:      	and	x26, x19, #0x7
    1698:      	add	w26, w26, #0x3
    169c:      	mov	x0, #0x1000000000       // =68719476736
    16a0:      	ldrsb	w0, [x27, x0]
    16a4:      	cmp	w0, #0x0
    16a8:      	mov	w1, #0x3                // =3
    16ac:      	ccmp	w1, w0, #0x1, ne
    16b0:      	b.ge	0x1970 <main+0x478>
    16b4:      	ldur	w0, [x19, #-0x90]
    16b8:      	eor	w0, w0, w0, lsl #13
    16bc:      	eor	w0, w0, w0, lsr #17
    16c0:      	eor	w0, w0, w0, lsl #5
    16c4:      	stur	w0, [x19, #-0x90]
    16c8:      	lsr	x1, x20, #3
    16cc:      	mov	x2, #0x1000000000       // =68719476736
    16d0:      	ldrsb	w1, [x1, x2]
    16d4:      	cmp	w1, #0x0
    16d8:      	ccmp	w26, w1, #0x1, ne
    16dc:      	b.ge	0x1978 <main+0x480>
    16e0:      	stur	w0, [x19, #-0x40]
    16e4:      	eor	w1, w0, w0, lsl #13
    16e8:      	eor	w1, w1, w1, lsr #17
    16ec:      	eor	w1, w1, w1, lsl #5
    16f0:      	stur	w1, [x19, #-0x90]
    16f4:      	sub	x2, x19, #0x38
    16f8:      	sub	x2, x2, x20
    16fc:      	cmp	x2, #0x8
    1700:      	b.hi	0x1980 <main+0x488>
    1704:      	sub	x3, x19, #0x3c
    1708:      	lsr	x4, x3, #3
    170c:      	mov	x2, #0x1000000000       // =68719476736
    1710:      	ldrsb	w4, [x4, x2]
    1714:      	and	x2, x3, #0x7
    1718:      	add	w2, w2, #0x3
    171c:      	cmp	w4, #0x0
    1720:      	ccmp	w2, w4, #0x1, ne
    1724:      	b.ge	0x19a0 <main+0x4a8>
    1728:      	stur	w1, [x19, #-0x3c]
    172c:      	lsr	x2, x20, #3
    1730:      	mov	x3, #0x1000000000       // =68719476736
    1734:      	ldrsb	w2, [x2, x3]
    1738:      	cmp	w2, #0x0
    173c:      	mov	w3, #0x3                // =3
    1740:      	ccmp	w3, w2, #0x1, ne
    1744:      	b.ge	0x19a8 <main+0x4b0>
    1748:      	sub	x3, x19, #0x3c
    174c:      	lsr	x4, x3, #3
    1750:      	mov	x2, #0x1000000000       // =68719476736
    1754:      	ldrsb	w4, [x4, x2]
    1758:      	and	x2, x3, #0x7
    175c:      	add	w2, w2, #0x3
    1760:      	cmp	w4, #0x0
    1764:      	ccmp	w2, w4, #0x1, ne
    1768:      	b.ge	0x19b0 <main+0x4b8>
    176c:      	bl	0x1498 <kernel>
    1770:      	add	x22, x22, w0, uxtw
    1774:      	add	x21, x21, #0x1
    1778:      	cmp	x25, x21
    177c:      	b.ne	0x169c <main+0x1a4>
    1780:      	sub	x1, x19, #0x60
    1784:      	mov	w0, #0x1                // =1
    1788:      	bl	0x12d0 <clock_gettime@plt>
    178c:      	mov	w20, w0
    1790:      	cbnz	w0, 0x1a5c <main+0x564>
    1794:      	sub	x0, x19, #0x60
    1798:      	lsr	x2, x0, #3
    179c:      	mov	x1, #0x1000000000       // =68719476736
    17a0:      	ldrsb	w1, [x2, x1]
    17a4:      	cbnz	w1, 0x19c0 <main+0x4c8>
    17a8:      	ldur	x1, [x19, #-0x60]
    17ac:      	sub	x0, x19, #0x80
    17b0:      	lsr	x3, x0, #3
    17b4:      	mov	x2, #0x1000000000       // =68719476736
    17b8:      	ldrsb	w2, [x3, x2]
    17bc:      	cbnz	w2, 0x19c4 <main+0x4cc>
    17c0:      	ldur	x0, [x19, #-0x80]
    17c4:      	subs	x0, x1, x0
    17c8:      	b.vs	0x19c8 <main+0x4d0>
    17cc:      	scvtf	d1, x0
    17d0:      	sub	x0, x19, #0x58
    17d4:      	lsr	x2, x0, #3
    17d8:      	mov	x1, #0x1000000000       // =68719476736
    17dc:      	ldrsb	w1, [x2, x1]
    17e0:      	cbnz	w1, 0x19dc <main+0x4e4>
    17e4:      	ldur	x1, [x19, #-0x58]
    17e8:      	sub	x0, x19, #0x78
    17ec:      	lsr	x3, x0, #3
    17f0:      	mov	x2, #0x1000000000       // =68719476736
    17f4:      	ldrsb	w2, [x3, x2]
    17f8:      	cbnz	w2, 0x19e0 <main+0x4e8>
    17fc:      	ldur	x0, [x19, #-0x78]
    1800:      	subs	x0, x1, x0
    1804:      	b.vs	0x19e4 <main+0x4ec>
    1808:      	scvtf	d0, x0
    180c:      	adrp	x0, 0x1000 <strtoul@GLIBC_2.17+0x1000>
    1810:      	ldr	d2, [x0, #0xc30]
    1814:      	fmul	d0, d0, d2
    1818:      	mov	x2, x22
    181c:      	fadd	d0, d0, d1
    1820:      	adrp	x1, 0x1000 <strtoul@GLIBC_2.17+0x1000>
    1824:      	add	x1, x1, #0xc40
    1828:      	add	x1, x1, #0x80
    182c:      	mov	w0, #0x2                // =2
    1830:      	bl	0x1330 <__printf_chk@plt>
    1834:      	ldp	x25, x26, [sp, #0x110]
    1838:      	b	0x19fc <main+0x504>
    183c:      	mov	x0, #0xa0               // =160
    1840:      	bl	0x1300 <__asan_stack_malloc_2@plt>
    1844:      	cmp	x0, #0x0
    1848:      	csel	x23, x23, x0, eq
    184c:      	b	0x1534 <main+0x3c>
    1850:      	stp	x25, x26, [sp, #0x110]
    1854:      	sub	x20, x19, #0x3c
    1858:      	adrp	x21, 0x1000 <strtoul@GLIBC_2.17+0x1000>
    185c:      	add	x21, x21, #0xc40
    1860:      	add	x25, x21, #0x40
    1864:      	and	x22, x20, #0x7
    1868:      	add	w22, w22, #0x3
    186c:      	b	0x188c <main+0x394>
    1870:      	bl	0x1260 <__asan_report_load4@plt>
    1874:      	ldur	w1, [x19, #-0x3c]
    1878:      	bl	0x1498 <kernel>
    187c:      	mov	w2, w0
    1880:      	mov	x1, x21
    1884:      	mov	w0, #0x2                // =2
    1888:      	bl	0x1330 <__printf_chk@plt>
    188c:      	mov	x2, x20
    1890:      	sub	x1, x19, #0x40
    1894:      	mov	x0, x25
    1898:      	bl	0x1320 <__isoc99_scanf@plt>
    189c:      	cmp	w0, #0x2
    18a0:      	b.ne	0x18e8 <main+0x3f0>
    18a4:      	sub	x0, x19, #0x40
    18a8:      	lsr	x2, x0, #3
    18ac:      	mov	x1, #0x1000000000       // =68719476736
    18b0:      	ldrsb	w1, [x2, x1]
    18b4:      	cmp	w1, #0x0
    18b8:      	mov	w2, #0x3                // =3
    18bc:      	ccmp	w2, w1, #0x1, ne
    18c0:      	b.ge	0x1870 <main+0x378>
    18c4:      	ldur	w0, [x19, #-0x40]
    18c8:      	lsr	x1, x20, #3
    18cc:      	mov	x2, #0x1000000000       // =68719476736
    18d0:      	ldrsb	w1, [x1, x2]
    18d4:      	cmp	w1, #0x0
    18d8:      	ccmp	w22, w1, #0x1, ne
    18dc:      	b.lt	0x1874 <main+0x37c>
    18e0:      	mov	x0, x20
    18e4:      	bl	0x1260 <__asan_report_load4@plt>
    18e8:      	mov	w20, #0x0               // =0
    18ec:      	ldp	x25, x26, [sp, #0x110]
    18f0:      	b	0x19fc <main+0x504>
    18f4:      	mov	x1, x20
    18f8:      	adrp	x0, 0x20000 <data_start>
    18fc:      	add	x0, x0, #0xe0
    1900:      	bl	0x1350 <__ubsan_handle_pointer_overflow_abort@plt>
    1904:      	adrp	x0, 0x20000 <data_start>
    1908:      	add	x0, x0, #0xe0
    190c:      	add	x0, x0, #0x40
    1910:      	bl	0x1210 <__ubsan_handle_type_mismatch_v1_abort@plt>
    1914:      	bl	0x12e0 <__asan_report_load8@plt>
    1918:      	bl	0x12a0 <__asan_handle_no_return@plt>
    191c:      	adrp	x0, 0x20000 <data_start>
    1920:      	add	x0, x0, #0xe0
    1924:      	add	x0, x0, #0x80
    1928:      	bl	0x1240 <__ubsan_handle_nonnull_arg_abort@plt>
    192c:      	mov	x1, x20
    1930:      	adrp	x0, 0x20000 <data_start>
    1934:      	add	x0, x0, #0xe0
    1938:      	add	x0, x0, #0xe0
    193c:      	bl	0x1350 <__ubsan_handle_pointer_overflow_abort@plt>
    1940:      	adrp	x0, 0x20000 <data_start>
    1944:      	add	x0, x0, #0xe0
    1948:      	add	x0, x0, #0x120
    194c:      	bl	0x1210 <__ubsan_handle_type_mismatch_v1_abort@plt>
    1950:      	bl	0x12e0 <__asan_report_load8@plt>
    1954:      	bl	0x12a0 <__asan_handle_no_return@plt>
    1958:      	adrp	x0, 0x20000 <data_start>
    195c:      	add	x0, x0, #0xe0
    1960:      	add	x0, x0, #0x160
    1964:      	bl	0x1240 <__ubsan_handle_nonnull_arg_abort@plt>
    1968:      	mov	x0, x2
    196c:      	bl	0x1200 <__asan_report_store4@plt>
    1970:      	ldr	x0, [sp, #0x8]
    1974:      	bl	0x1260 <__asan_report_load4@plt>
    1978:      	mov	x0, x20
    197c:      	bl	0x1200 <__asan_report_store4@plt>
    1980:      	sub	x3, x19, #0x3c
    1984:      	cmn	x3, x2
    1988:      	b.hs	0x1704 <main+0x20c>
    198c:      	mov	x1, x3
    1990:      	adrp	x0, 0x20000 <data_start>
    1994:      	add	x0, x0, #0xe0
    1998:      	add	x0, x0, #0x1c0
    199c:      	bl	0x1210 <__ubsan_handle_type_mismatch_v1_abort@plt>
    19a0:      	mov	x0, x3
    19a4:      	bl	0x1200 <__asan_report_store4@plt>
    19a8:      	mov	x0, x20
    19ac:      	bl	0x1260 <__asan_report_load4@plt>
    19b0:      	mov	x0, x3
    19b4:      	bl	0x1260 <__asan_report_load4@plt>
    19b8:      	mov	x22, x25
    19bc:      	b	0x1780 <main+0x288>
    19c0:      	bl	0x12e0 <__asan_report_load8@plt>
    19c4:      	bl	0x12e0 <__asan_report_load8@plt>
    19c8:      	ldur	x2, [x19, #-0x80]
    19cc:      	adrp	x0, 0x20000 <data_start>
    19d0:      	add	x0, x0, #0xe0
    19d4:      	add	x0, x0, #0x200
    19d8:      	bl	0x1250 <__ubsan_handle_sub_overflow_abort@plt>
    19dc:      	bl	0x12e0 <__asan_report_load8@plt>
    19e0:      	bl	0x12e0 <__asan_report_load8@plt>
    19e4:      	ldur	x2, [x19, #-0x78]
    19e8:      	adrp	x0, 0x20000 <data_start>
    19ec:      	add	x0, x0, #0xe0
    19f0:      	add	x0, x0, #0x240
    19f4:      	bl	0x1250 <__ubsan_handle_sub_overflow_abort@plt>
    19f8:      	mov	w20, #0x3               // =3
    19fc:      	cmp	x28, x23
    1a00:      	b.ne	0x1a68 <main+0x570>
    1a04:      	mov	x0, #0x1000000000       // =68719476736
    1a08:      	add	x24, x24, x0
    1a0c:      	stp	xzr, xzr, [x24]
    1a10:      	str	wzr, [x24, #0x10]
    1a14:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1d07c>
    1a18:      	ldr	x0, [x0, #0xfc8]
    1a1c:      	ldr	x2, [sp, #0xc8]
    1a20:      	ldr	x1, [x0]
    1a24:      	subs	x2, x2, x1
    1a28:      	mov	x1, #0x0                // =0
    1a2c:      	b.ne	0x1a8c <main+0x594>
    1a30:      	mov	w0, w20
    1a34:      	ldp	x19, x20, [sp, #0xe0]
    1a38:      	ldp	x21, x22, [sp, #0xf0]
    1a3c:      	ldp	x23, x24, [sp, #0x100]
    1a40:      	ldp	x27, x28, [sp, #0x120]
    1a44:      	ldp	x29, x30, [sp, #0xd0]
    1a48:      	add	sp, sp, #0x130
    1a4c:      	ret
    1a50:      	mov	w20, #0x2               // =2
    1a54:      	ldp	x25, x26, [sp, #0x110]
    1a58:      	b	0x19fc <main+0x504>
    1a5c:      	mov	w20, #0x2               // =2
    1a60:      	ldp	x25, x26, [sp, #0x110]
    1a64:      	b	0x19fc <main+0x504>
    1a68:      	mov	x0, #0x360e             // =13838
    1a6c:      	movk	x0, #0x45e0, lsl #16
    1a70:      	str	x0, [x23]
    1a74:      	mov	x0, #0x1000000000       // =68719476736
    1a78:      	add	x1, x24, x0
    1a7c:      	movi	v0.16b, #0xf5
    1a80:      	str	q0, [x24, x0]
    1a84:      	str	s0, [x1, #0x10]
    1a88:      	b	0x1a14 <main+0x51c>
    1a8c:      	stp	x25, x26, [sp, #0x110]
    1a90:      	bl	0x1230 <__stack_chk_fail@plt>

0000000000001a94 <_sub_D_00099_0>:
    1a94:      	stp	x29, x30, [sp, #-0x10]!
    1a98:      	mov	x29, sp
    1a9c:      	mov	x1, #0x10               // =16
    1aa0:      	adrp	x0, 0x20000 <data_start>
    1aa4:      	add	x0, x0, #0xe0
    1aa8:      	add	x0, x0, #0x280
    1aac:      	bl	0x1290 <__asan_unregister_globals@plt>
    1ab0:      	ldp	x29, x30, [sp], #0x10
    1ab4:      	ret

0000000000001ab8 <_sub_I_00099_1>:
    1ab8:      	stp	x29, x30, [sp, #-0x10]!
    1abc:      	mov	x29, sp
    1ac0:      	bl	0x12b0 <__asan_init@plt>
    1ac4:      	bl	0x1310 <__asan_version_mismatch_check_v8@plt>
    1ac8:      	mov	x1, #0x10               // =16
    1acc:      	adrp	x0, 0x20000 <data_start>
    1ad0:      	add	x0, x0, #0xe0
    1ad4:      	add	x0, x0, #0x280
    1ad8:      	bl	0x1220 <__asan_register_globals@plt>
    1adc:      	ldp	x29, x30, [sp], #0x10
    1ae0:      	ret

Disassembly of section .fini:

0000000000001ae4 <_fini>:
    1ae4:      	nop
    1ae8:      	stp	x29, x30, [sp, #-0x10]!
    1aec:      	mov	x29, sp
    1af0:      	ldp	x29, x30, [sp], #0x10
    1af4:      	ret
