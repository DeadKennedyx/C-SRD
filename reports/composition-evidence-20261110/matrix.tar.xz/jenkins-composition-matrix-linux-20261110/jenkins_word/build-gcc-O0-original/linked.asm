
/work/experiments/runs/jenkins-composition-matrix-linux-20261110/jenkins_word/build-gcc-O0-original/program:	file format elf64-littleaarch64

Disassembly of section .init:

0000000000000730 <_init>:
     730:      	nop
     734:      	stp	x29, x30, [sp, #-0x10]!
     738:      	mov	x29, sp
     73c:      	bl	0x834 <call_weak_fn>
     740:      	ldp	x29, x30, [sp], #0x10
     744:      	ret

Disassembly of section .plt:

0000000000000750 <.plt>:
     750:      	stp	x16, x30, [sp, #-0x10]!
     754:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e218>
     758:      	ldr	x17, [x16, #0xf78]
     75c:      	add	x16, x16, #0xf78
     760:      	br	x17
     764:      	nop
     768:      	nop
     76c:      	nop

0000000000000770 <strtoul@plt>:
     770:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e218>
     774:      	ldr	x17, [x16, #0xf80]
     778:      	add	x16, x16, #0xf80
     77c:      	br	x17

0000000000000780 <__libc_start_main@plt>:
     780:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e218>
     784:      	ldr	x17, [x16, #0xf88]
     788:      	add	x16, x16, #0xf88
     78c:      	br	x17

0000000000000790 <__cxa_finalize@plt>:
     790:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e218>
     794:      	ldr	x17, [x16, #0xf90]
     798:      	add	x16, x16, #0xf90
     79c:      	br	x17

00000000000007a0 <clock_gettime@plt>:
     7a0:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e218>
     7a4:      	ldr	x17, [x16, #0xf98]
     7a8:      	add	x16, x16, #0xf98
     7ac:      	br	x17

00000000000007b0 <__stack_chk_fail@plt>:
     7b0:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e218>
     7b4:      	ldr	x17, [x16, #0xfa0]
     7b8:      	add	x16, x16, #0xfa0
     7bc:      	br	x17

00000000000007c0 <__gmon_start__@plt>:
     7c0:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e218>
     7c4:      	ldr	x17, [x16, #0xfa8]
     7c8:      	add	x16, x16, #0xfa8
     7cc:      	br	x17

00000000000007d0 <abort@plt>:
     7d0:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e218>
     7d4:      	ldr	x17, [x16, #0xfb0]
     7d8:      	add	x16, x16, #0xfb0
     7dc:      	br	x17

00000000000007e0 <__isoc99_scanf@plt>:
     7e0:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e218>
     7e4:      	ldr	x17, [x16, #0xfb8]
     7e8:      	add	x16, x16, #0xfb8
     7ec:      	br	x17

00000000000007f0 <printf@plt>:
     7f0:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e218>
     7f4:      	ldr	x17, [x16, #0xfc0]
     7f8:      	add	x16, x16, #0xfc0
     7fc:      	br	x17

Disassembly of section .text:

0000000000000800 <_start>:
     800:      	nop
     804:      	mov	x29, #0x0               // =0
     808:      	mov	x30, #0x0               // =0
     80c:      	mov	x5, x0
     810:      	ldr	x1, [sp]
     814:      	add	x2, sp, #0x8
     818:      	mov	x6, sp
     81c:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e218>
     820:      	ldr	x0, [x0, #0xff0]
     824:      	mov	x3, #0x0                // =0
     828:      	mov	x4, #0x0                // =0
     82c:      	bl	0x780 <__libc_start_main@plt>
     830:      	bl	0x7d0 <abort@plt>

0000000000000834 <call_weak_fn>:
     834:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e218>
     838:      	ldr	x0, [x0, #0xfe0]
     83c:      	cbz	x0, 0x844 <call_weak_fn+0x10>
     840:      	b	0x7c0 <__gmon_start__@plt>
     844:      	ret
     848:      	nop
     84c:      	nop

0000000000000850 <deregister_tm_clones>:
     850:      	adrp	x0, 0x20000 <data_start>
     854:      	add	x0, x0, #0x10
     858:      	adrp	x1, 0x20000 <data_start>
     85c:      	add	x1, x1, #0x10
     860:      	cmp	x1, x0
     864:      	b.eq	0x87c <deregister_tm_clones+0x2c>
     868:      	adrp	x1, 0x1f000 <__FRAME_END__+0x1e218>
     86c:      	ldr	x1, [x1, #0xfd0]
     870:      	cbz	x1, 0x87c <deregister_tm_clones+0x2c>
     874:      	mov	x16, x1
     878:      	br	x16
     87c:      	ret

0000000000000880 <register_tm_clones>:
     880:      	adrp	x0, 0x20000 <data_start>
     884:      	add	x0, x0, #0x10
     888:      	adrp	x1, 0x20000 <data_start>
     88c:      	add	x1, x1, #0x10
     890:      	sub	x1, x1, x0
     894:      	lsr	x2, x1, #63
     898:      	add	x1, x2, x1, asr #3
     89c:      	asr	x1, x1, #1
     8a0:      	cbz	x1, 0x8b8 <register_tm_clones+0x38>
     8a4:      	adrp	x2, 0x1f000 <__FRAME_END__+0x1e218>
     8a8:      	ldr	x2, [x2, #0xff8]
     8ac:      	cbz	x2, 0x8b8 <register_tm_clones+0x38>
     8b0:      	mov	x16, x2
     8b4:      	br	x16
     8b8:      	ret
     8bc:      	nop

00000000000008c0 <__do_global_dtors_aux>:
     8c0:      	paciasp
     8c4:      	stp	x29, x30, [sp, #-0x20]!
     8c8:      	mov	x29, sp
     8cc:      	str	x19, [sp, #0x10]
     8d0:      	adrp	x19, 0x20000 <data_start>
     8d4:      	ldrb	w0, [x19, #0x10]
     8d8:      	tbnz	w0, #0x0, 0x900 <__do_global_dtors_aux+0x40>
     8dc:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e218>
     8e0:      	ldr	x0, [x0, #0xfd8]
     8e4:      	cbz	x0, 0x8f4 <__do_global_dtors_aux+0x34>
     8e8:      	adrp	x0, 0x20000 <data_start>
     8ec:      	ldr	x0, [x0, #0x8]
     8f0:      	bl	0x790 <__cxa_finalize@plt>
     8f4:      	bl	0x850 <deregister_tm_clones>
     8f8:      	mov	w0, #0x1                // =1
     8fc:      	strb	w0, [x19, #0x10]
     900:      	ldr	x19, [sp, #0x10]
     904:      	ldp	x29, x30, [sp], #0x20
     908:      	autiasp
     90c:      	ret

0000000000000910 <frame_dummy>:
     910:      	bti	c
     914:      	b	0x880 <register_tm_clones>

0000000000000918 <kernel>:
     918:      	sub	sp, sp, #0x20
     91c:      	str	w0, [sp, #0xc]
     920:      	str	w1, [sp, #0x8]
     924:      	ldr	w0, [sp, #0xc]
     928:      	str	w0, [sp, #0x14]
     92c:      	ldr	w0, [sp, #0x8]
     930:      	str	w0, [sp, #0x18]
     934:      	str	wzr, [sp, #0x1c]
     938:      	b	0x990 <kernel+0x78>
     93c:      	ldr	w0, [sp, #0x18]
     940:      	and	w0, w0, #0xff
     944:      	ldr	w1, [sp, #0x14]
     948:      	add	w0, w1, w0
     94c:      	str	w0, [sp, #0x14]
     950:      	ldr	w0, [sp, #0x14]
     954:      	lsl	w0, w0, #10
     958:      	ldr	w1, [sp, #0x14]
     95c:      	add	w0, w1, w0
     960:      	str	w0, [sp, #0x14]
     964:      	ldr	w0, [sp, #0x14]
     968:      	lsr	w0, w0, #6
     96c:      	ldr	w1, [sp, #0x14]
     970:      	eor	w0, w1, w0
     974:      	str	w0, [sp, #0x14]
     978:      	ldr	w0, [sp, #0x18]
     97c:      	lsr	w0, w0, #8
     980:      	str	w0, [sp, #0x18]
     984:      	ldr	w0, [sp, #0x1c]
     988:      	add	w0, w0, #0x1
     98c:      	str	w0, [sp, #0x1c]
     990:      	ldr	w0, [sp, #0x1c]
     994:      	cmp	w0, #0x3
     998:      	b.ls	0x93c <kernel+0x24>
     99c:      	ldr	w0, [sp, #0x14]
     9a0:      	lsl	w0, w0, #3
     9a4:      	ldr	w1, [sp, #0x14]
     9a8:      	add	w0, w1, w0
     9ac:      	str	w0, [sp, #0x14]
     9b0:      	ldr	w0, [sp, #0x14]
     9b4:      	lsr	w0, w0, #11
     9b8:      	ldr	w1, [sp, #0x14]
     9bc:      	eor	w0, w1, w0
     9c0:      	str	w0, [sp, #0x14]
     9c4:      	ldr	w0, [sp, #0x14]
     9c8:      	lsl	w0, w0, #15
     9cc:      	ldr	w1, [sp, #0x14]
     9d0:      	add	w0, w1, w0
     9d4:      	str	w0, [sp, #0x14]
     9d8:      	ldr	w0, [sp, #0x14]
     9dc:      	add	sp, sp, #0x20
     9e0:      	ret

00000000000009e4 <csrd_matrix_next_value>:
     9e4:      	sub	sp, sp, #0x10
     9e8:      	str	x0, [sp, #0x8]
     9ec:      	ldr	x0, [sp, #0x8]
     9f0:      	ldr	w1, [x0]
     9f4:      	ldr	x0, [sp, #0x8]
     9f8:      	ldr	w0, [x0]
     9fc:      	lsl	w0, w0, #13
     a00:      	eor	w1, w1, w0
     a04:      	ldr	x0, [sp, #0x8]
     a08:      	str	w1, [x0]
     a0c:      	ldr	x0, [sp, #0x8]
     a10:      	ldr	w1, [x0]
     a14:      	ldr	x0, [sp, #0x8]
     a18:      	ldr	w0, [x0]
     a1c:      	lsr	w0, w0, #17
     a20:      	eor	w1, w1, w0
     a24:      	ldr	x0, [sp, #0x8]
     a28:      	str	w1, [x0]
     a2c:      	ldr	x0, [sp, #0x8]
     a30:      	ldr	w1, [x0]
     a34:      	ldr	x0, [sp, #0x8]
     a38:      	ldr	w0, [x0]
     a3c:      	lsl	w0, w0, #5
     a40:      	eor	w1, w1, w0
     a44:      	ldr	x0, [sp, #0x8]
     a48:      	str	w1, [x0]
     a4c:      	ldr	x0, [sp, #0x8]
     a50:      	ldr	w0, [x0]
     a54:      	add	sp, sp, #0x10
     a58:      	ret

0000000000000a5c <main>:
     a5c:      	sub	sp, sp, #0x80
     a60:      	stp	x29, x30, [sp, #0x70]
     a64:      	add	x29, sp, #0x70
     a68:      	str	w0, [sp, #0xc]
     a6c:      	str	x1, [sp]
     a70:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e218>
     a74:      	ldr	x0, [x0, #0xfe8]
     a78:      	ldr	x1, [x0]
     a7c:      	str	x1, [sp, #0x68]
     a80:      	mov	x1, #0x0                // =0
     a84:      	ldr	w0, [sp, #0xc]
     a88:      	cmp	w0, #0x1
     a8c:      	b.ne	0xae0 <main+0x84>
     a90:      	b	0xab0 <main+0x54>
     a94:      	ldr	w0, [sp, #0x60]
     a98:      	ldr	w1, [sp, #0x64]
     a9c:      	bl	0x918 <kernel>
     aa0:      	mov	w1, w0
     aa4:      	adrp	x0, 0x0 <strtoul@GLIBC_2.17>
     aa8:      	add	x0, x0, #0xc90
     aac:      	bl	0x7f0 <printf@plt>
     ab0:      	add	x0, sp, #0x60
     ab4:      	add	x1, x0, #0x4
     ab8:      	add	x0, sp, #0x60
     abc:      	mov	x2, x1
     ac0:      	mov	x1, x0
     ac4:      	adrp	x0, 0x0 <strtoul@GLIBC_2.17>
     ac8:      	add	x0, x0, #0xc98
     acc:      	bl	0x7e0 <__isoc99_scanf@plt>
     ad0:      	cmp	w0, #0x2
     ad4:      	b.eq	0xa94 <main+0x38>
     ad8:      	mov	w0, #0x0                // =0
     adc:      	b	0xc40 <main+0x1e4>
     ae0:      	ldr	w0, [sp, #0xc]
     ae4:      	cmp	w0, #0x3
     ae8:      	b.eq	0xaf4 <main+0x98>
     aec:      	mov	w0, #0x3                // =3
     af0:      	b	0xc40 <main+0x1e4>
     af4:      	ldr	x0, [sp]
     af8:      	add	x0, x0, #0x8
     afc:      	ldr	x0, [x0]
     b00:      	mov	w2, #0xa                // =10
     b04:      	mov	x1, #0x0                // =0
     b08:      	bl	0x770 <strtoul@plt>
     b0c:      	str	x0, [sp, #0x30]
     b10:      	ldr	x0, [sp]
     b14:      	add	x0, x0, #0x10
     b18:      	ldr	x0, [x0]
     b1c:      	mov	w2, #0xa                // =10
     b20:      	mov	x1, #0x0                // =0
     b24:      	bl	0x770 <strtoul@plt>
     b28:      	str	w0, [sp, #0x18]
     b2c:      	str	xzr, [sp, #0x20]
     b30:      	add	x0, sp, #0x40
     b34:      	mov	x1, x0
     b38:      	mov	w0, #0x1                // =1
     b3c:      	bl	0x7a0 <clock_gettime@plt>
     b40:      	cmp	w0, #0x0
     b44:      	b.eq	0xb50 <main+0xf4>
     b48:      	mov	w0, #0x2                // =2
     b4c:      	b	0xc40 <main+0x1e4>
     b50:      	str	xzr, [sp, #0x28]
     b54:      	b	0xbbc <main+0x160>
     b58:      	str	wzr, [sp, #0x1c]
     b5c:      	b	0xb88 <main+0x12c>
     b60:      	add	x0, sp, #0x18
     b64:      	bl	0x9e4 <csrd_matrix_next_value>
     b68:      	mov	w2, w0
     b6c:      	ldr	w0, [sp, #0x1c]
     b70:      	lsl	x0, x0, #2
     b74:      	add	x1, sp, #0x60
     b78:      	str	w2, [x1, x0]
     b7c:      	ldr	w0, [sp, #0x1c]
     b80:      	add	w0, w0, #0x1
     b84:      	str	w0, [sp, #0x1c]
     b88:      	ldr	w0, [sp, #0x1c]
     b8c:      	cmp	w0, #0x1
     b90:      	b.ls	0xb60 <main+0x104>
     b94:      	ldr	w0, [sp, #0x60]
     b98:      	ldr	w1, [sp, #0x64]
     b9c:      	bl	0x918 <kernel>
     ba0:      	mov	w0, w0
     ba4:      	ldr	x1, [sp, #0x20]
     ba8:      	add	x0, x1, x0
     bac:      	str	x0, [sp, #0x20]
     bb0:      	ldr	x0, [sp, #0x28]
     bb4:      	add	x0, x0, #0x1
     bb8:      	str	x0, [sp, #0x28]
     bbc:      	ldr	x1, [sp, #0x28]
     bc0:      	ldr	x0, [sp, #0x30]
     bc4:      	cmp	x1, x0
     bc8:      	b.lo	0xb58 <main+0xfc>
     bcc:      	add	x0, sp, #0x50
     bd0:      	mov	x1, x0
     bd4:      	mov	w0, #0x1                // =1
     bd8:      	bl	0x7a0 <clock_gettime@plt>
     bdc:      	cmp	w0, #0x0
     be0:      	b.eq	0xbec <main+0x190>
     be4:      	mov	w0, #0x2                // =2
     be8:      	b	0xc40 <main+0x1e4>
     bec:      	ldr	x1, [sp, #0x50]
     bf0:      	ldr	x0, [sp, #0x40]
     bf4:      	sub	x0, x1, x0
     bf8:      	fmov	d0, x0
     bfc:      	scvtf	d1, d0
     c00:      	ldr	x1, [sp, #0x58]
     c04:      	ldr	x0, [sp, #0x48]
     c08:      	sub	x0, x1, x0
     c0c:      	fmov	d0, x0
     c10:      	scvtf	d0, d0
     c14:      	adrp	x0, 0x0 <strtoul@GLIBC_2.17>
     c18:      	ldr	d2, [x0, #0xcb0]
     c1c:      	fmul	d0, d0, d2
     c20:      	fadd	d0, d1, d0
     c24:      	str	d0, [sp, #0x38]
     c28:      	ldr	x1, [sp, #0x20]
     c2c:      	ldr	d0, [sp, #0x38]
     c30:      	adrp	x0, 0x0 <strtoul@GLIBC_2.17>
     c34:      	add	x0, x0, #0xca0
     c38:      	bl	0x7f0 <printf@plt>
     c3c:      	mov	w0, #0x0                // =0
     c40:      	mov	w1, w0
     c44:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e218>
     c48:      	ldr	x0, [x0, #0xfe8]
     c4c:      	ldr	x3, [sp, #0x68]
     c50:      	ldr	x2, [x0]
     c54:      	subs	x3, x3, x2
     c58:      	mov	x2, #0x0                // =0
     c5c:      	b.eq	0xc64 <main+0x208>
     c60:      	bl	0x7b0 <__stack_chk_fail@plt>
     c64:      	mov	w0, w1
     c68:      	ldp	x29, x30, [sp, #0x70]
     c6c:      	add	sp, sp, #0x80
     c70:      	ret

Disassembly of section .fini:

0000000000000c74 <_fini>:
     c74:      	nop
     c78:      	stp	x29, x30, [sp, #-0x10]!
     c7c:      	mov	x29, sp
     c80:      	ldp	x29, x30, [sp], #0x10
     c84:      	ret
