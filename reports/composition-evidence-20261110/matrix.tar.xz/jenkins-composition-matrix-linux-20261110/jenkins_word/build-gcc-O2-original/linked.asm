
/work/experiments/runs/jenkins-composition-matrix-linux-20261110/jenkins_word/build-gcc-O2-original/program:	file format elf64-littleaarch64

Disassembly of section .init:

0000000000000738 <_init>:
     738:      	nop
     73c:      	stp	x29, x30, [sp, #-0x10]!
     740:      	mov	x29, sp
     744:      	bl	0xa34 <call_weak_fn>
     748:      	ldp	x29, x30, [sp], #0x10
     74c:      	ret

Disassembly of section .plt:

0000000000000750 <.plt>:
     750:      	stp	x16, x30, [sp, #-0x10]!
     754:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e31c>
     758:      	ldr	x17, [x16, #0xf78]
     75c:      	add	x16, x16, #0xf78
     760:      	br	x17
     764:      	nop
     768:      	nop
     76c:      	nop

0000000000000770 <strtoul@plt>:
     770:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e31c>
     774:      	ldr	x17, [x16, #0xf80]
     778:      	add	x16, x16, #0xf80
     77c:      	br	x17

0000000000000780 <__libc_start_main@plt>:
     780:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e31c>
     784:      	ldr	x17, [x16, #0xf88]
     788:      	add	x16, x16, #0xf88
     78c:      	br	x17

0000000000000790 <__cxa_finalize@plt>:
     790:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e31c>
     794:      	ldr	x17, [x16, #0xf90]
     798:      	add	x16, x16, #0xf90
     79c:      	br	x17

00000000000007a0 <clock_gettime@plt>:
     7a0:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e31c>
     7a4:      	ldr	x17, [x16, #0xf98]
     7a8:      	add	x16, x16, #0xf98
     7ac:      	br	x17

00000000000007b0 <__printf_chk@plt>:
     7b0:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e31c>
     7b4:      	ldr	x17, [x16, #0xfa0]
     7b8:      	add	x16, x16, #0xfa0
     7bc:      	br	x17

00000000000007c0 <__stack_chk_fail@plt>:
     7c0:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e31c>
     7c4:      	ldr	x17, [x16, #0xfa8]
     7c8:      	add	x16, x16, #0xfa8
     7cc:      	br	x17

00000000000007d0 <__gmon_start__@plt>:
     7d0:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e31c>
     7d4:      	ldr	x17, [x16, #0xfb0]
     7d8:      	add	x16, x16, #0xfb0
     7dc:      	br	x17

00000000000007e0 <abort@plt>:
     7e0:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e31c>
     7e4:      	ldr	x17, [x16, #0xfb8]
     7e8:      	add	x16, x16, #0xfb8
     7ec:      	br	x17

00000000000007f0 <__isoc99_scanf@plt>:
     7f0:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e31c>
     7f4:      	ldr	x17, [x16, #0xfc0]
     7f8:      	add	x16, x16, #0xfc0
     7fc:      	br	x17

Disassembly of section .text:

0000000000000800 <main>:
     800:      	sub	sp, sp, #0x70
     804:      	mov	w2, w0
     808:      	adrp	x3, 0x1f000 <__FRAME_END__+0x1e31c>
     80c:      	ldr	x3, [x3, #0xfe8]
     810:      	stp	x29, x30, [sp, #0x30]
     814:      	add	x29, sp, #0x30
     818:      	ldr	x0, [x3]
     81c:      	str	x0, [sp, #0x28]
     820:      	mov	x0, #0x0                // =0
     824:      	cmp	w2, #0x1
     828:      	b.eq	0x934 <main+0x134>
     82c:      	mov	w0, #0x3                // =3
     830:      	cmp	w2, w0
     834:      	b.eq	0x860 <main+0x60>
     838:      	adrp	x1, 0x1f000 <__FRAME_END__+0x1e31c>
     83c:      	ldr	x1, [x1, #0xfe8]
     840:      	ldr	x3, [sp, #0x28]
     844:      	ldr	x2, [x1]
     848:      	subs	x3, x3, x2
     84c:      	mov	x2, #0x0                // =0
     850:      	b.ne	0x9bc <main+0x1bc>
     854:      	ldp	x29, x30, [sp, #0x30]
     858:      	add	sp, sp, #0x70
     85c:      	ret
     860:      	stp	x19, x20, [sp, #0x40]
     864:      	mov	x19, x1
     868:      	mov	w2, #0xa                // =10
     86c:      	mov	x1, #0x0                // =0
     870:      	stp	x21, x22, [sp, #0x50]
     874:      	ldr	x0, [x19, #0x8]
     878:      	bl	0x770 <strtoul@plt>
     87c:      	mov	x21, x0
     880:      	ldr	x0, [x19, #0x10]
     884:      	mov	w2, #0xa                // =10
     888:      	mov	x1, #0x0                // =0
     88c:      	bl	0x770 <strtoul@plt>
     890:      	mov	x19, x0
     894:      	mov	x1, sp
     898:      	mov	w0, #0x1                // =1
     89c:      	bl	0x7a0 <clock_gettime@plt>
     8a0:      	cbnz	w0, 0x9a4 <main+0x1a4>
     8a4:      	cbz	x21, 0x9b4 <main+0x1b4>
     8a8:      	mov	x20, #0x0               // =0
     8ac:      	mov	x22, #0x0               // =0
     8b0:      	eor	w0, w19, w19, lsl #13
     8b4:      	add	x20, x20, #0x1
     8b8:      	eor	w0, w0, w0, lsr #17
     8bc:      	eor	w0, w0, w0, lsl #5
     8c0:      	eor	w19, w0, w0, lsl #13
     8c4:      	eor	w19, w19, w19, lsr #17
     8c8:      	eor	w19, w19, w19, lsl #5
     8cc:      	stp	w0, w19, [sp, #0x20]
     8d0:      	mov	w1, w19
     8d4:      	bl	0xb20 <kernel>
     8d8:      	add	x22, x22, w0, uxtw
     8dc:      	cmp	x21, x20
     8e0:      	b.ne	0x8b0 <main+0xb0>
     8e4:      	add	x1, sp, #0x10
     8e8:      	mov	w0, #0x1                // =1
     8ec:      	bl	0x7a0 <clock_gettime@plt>
     8f0:      	cbnz	w0, 0x9a4 <main+0x1a4>
     8f4:      	adrp	x0, 0x0 <strtoul@GLIBC_2.17>
     8f8:      	mov	x2, x22
     8fc:      	ldp	x4, x1, [sp]
     900:      	ldr	d1, [x0, #0xb88]
     904:      	ldp	x3, x0, [sp, #0x10]
     908:      	sub	x0, x0, x1
     90c:      	sub	x3, x3, x4
     910:      	adrp	x1, 0x0 <strtoul@GLIBC_2.17>
     914:      	add	x1, x1, #0xb78
     918:      	scvtf	d0, x0
     91c:      	mov	w0, #0x2                // =2
     920:      	fmul	d0, d0, d1
     924:      	scvtf	d1, x3
     928:      	fadd	d0, d0, d1
     92c:      	bl	0x7b0 <__printf_chk@plt>
     930:      	b	0x994 <main+0x194>
     934:      	stp	x19, x20, [sp, #0x40]
     938:      	adrp	x20, 0x0 <strtoul@GLIBC_2.17>
     93c:      	add	x20, x20, #0xb70
     940:      	stp	x21, x22, [sp, #0x50]
     944:      	adrp	x21, 0x0 <strtoul@GLIBC_2.17>
     948:      	add	x22, sp, #0x24
     94c:      	add	x21, x21, #0xb68
     950:      	str	x23, [sp, #0x60]
     954:      	add	x23, sp, #0x20
     958:      	b	0x974 <main+0x174>
     95c:      	ldp	w0, w1, [sp, #0x20]
     960:      	bl	0xb20 <kernel>
     964:      	mov	w2, w0
     968:      	mov	x1, x21
     96c:      	mov	w0, w19
     970:      	bl	0x7b0 <__printf_chk@plt>
     974:      	mov	x2, x22
     978:      	mov	x1, x23
     97c:      	mov	x0, x20
     980:      	bl	0x7f0 <__isoc99_scanf@plt>
     984:      	mov	w19, w0
     988:      	cmp	w0, #0x2
     98c:      	b.eq	0x95c <main+0x15c>
     990:      	ldr	x23, [sp, #0x60]
     994:      	mov	w0, #0x0                // =0
     998:      	ldp	x19, x20, [sp, #0x40]
     99c:      	ldp	x21, x22, [sp, #0x50]
     9a0:      	b	0x838 <main+0x38>
     9a4:      	ldp	x19, x20, [sp, #0x40]
     9a8:      	mov	w0, #0x2                // =2
     9ac:      	ldp	x21, x22, [sp, #0x50]
     9b0:      	b	0x838 <main+0x38>
     9b4:      	mov	x22, #0x0               // =0
     9b8:      	b	0x8e4 <main+0xe4>
     9bc:      	stp	x19, x20, [sp, #0x40]
     9c0:      	stp	x21, x22, [sp, #0x50]
     9c4:      	str	x23, [sp, #0x60]
     9c8:      	bl	0x7c0 <__stack_chk_fail@plt>
     9cc:      	nop
     9d0:      	nop
     9d4:      	nop
     9d8:      	nop
     9dc:      	nop
     9e0:      	nop
     9e4:      	nop
     9e8:      	nop
     9ec:      	nop
     9f0:      	nop
     9f4:      	nop
     9f8:      	nop
     9fc:      	nop

0000000000000a00 <_start>:
     a00:      	nop
     a04:      	mov	x29, #0x0               // =0
     a08:      	mov	x30, #0x0               // =0
     a0c:      	mov	x5, x0
     a10:      	ldr	x1, [sp]
     a14:      	add	x2, sp, #0x8
     a18:      	mov	x6, sp
     a1c:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e31c>
     a20:      	ldr	x0, [x0, #0xff0]
     a24:      	mov	x3, #0x0                // =0
     a28:      	mov	x4, #0x0                // =0
     a2c:      	bl	0x780 <__libc_start_main@plt>
     a30:      	bl	0x7e0 <abort@plt>

0000000000000a34 <call_weak_fn>:
     a34:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e31c>
     a38:      	ldr	x0, [x0, #0xfe0]
     a3c:      	cbz	x0, 0xa44 <call_weak_fn+0x10>
     a40:      	b	0x7d0 <__gmon_start__@plt>
     a44:      	ret
     a48:      	nop
     a4c:      	nop

0000000000000a50 <deregister_tm_clones>:
     a50:      	adrp	x0, 0x20000 <data_start>
     a54:      	add	x0, x0, #0x10
     a58:      	adrp	x1, 0x20000 <data_start>
     a5c:      	add	x1, x1, #0x10
     a60:      	cmp	x1, x0
     a64:      	b.eq	0xa7c <deregister_tm_clones+0x2c>
     a68:      	adrp	x1, 0x1f000 <__FRAME_END__+0x1e31c>
     a6c:      	ldr	x1, [x1, #0xfd0]
     a70:      	cbz	x1, 0xa7c <deregister_tm_clones+0x2c>
     a74:      	mov	x16, x1
     a78:      	br	x16
     a7c:      	ret

0000000000000a80 <register_tm_clones>:
     a80:      	adrp	x0, 0x20000 <data_start>
     a84:      	add	x0, x0, #0x10
     a88:      	adrp	x1, 0x20000 <data_start>
     a8c:      	add	x1, x1, #0x10
     a90:      	sub	x1, x1, x0
     a94:      	lsr	x2, x1, #63
     a98:      	add	x1, x2, x1, asr #3
     a9c:      	asr	x1, x1, #1
     aa0:      	cbz	x1, 0xab8 <register_tm_clones+0x38>
     aa4:      	adrp	x2, 0x1f000 <__FRAME_END__+0x1e31c>
     aa8:      	ldr	x2, [x2, #0xff8]
     aac:      	cbz	x2, 0xab8 <register_tm_clones+0x38>
     ab0:      	mov	x16, x2
     ab4:      	br	x16
     ab8:      	ret
     abc:      	nop

0000000000000ac0 <__do_global_dtors_aux>:
     ac0:      	paciasp
     ac4:      	stp	x29, x30, [sp, #-0x20]!
     ac8:      	mov	x29, sp
     acc:      	str	x19, [sp, #0x10]
     ad0:      	adrp	x19, 0x20000 <data_start>
     ad4:      	ldrb	w0, [x19, #0x10]
     ad8:      	tbnz	w0, #0x0, 0xb00 <__do_global_dtors_aux+0x40>
     adc:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e31c>
     ae0:      	ldr	x0, [x0, #0xfd8]
     ae4:      	cbz	x0, 0xaf4 <__do_global_dtors_aux+0x34>
     ae8:      	adrp	x0, 0x20000 <data_start>
     aec:      	ldr	x0, [x0, #0x8]
     af0:      	bl	0x790 <__cxa_finalize@plt>
     af4:      	bl	0xa50 <deregister_tm_clones>
     af8:      	mov	w0, #0x1                // =1
     afc:      	strb	w0, [x19, #0x10]
     b00:      	ldr	x19, [sp, #0x10]
     b04:      	ldp	x29, x30, [sp], #0x20
     b08:      	autiasp
     b0c:      	ret

0000000000000b10 <frame_dummy>:
     b10:      	bti	c
     b14:      	b	0xa80 <register_tm_clones>
     b18:      	nop
     b1c:      	nop

0000000000000b20 <kernel>:
     b20:      	mov	w2, #0x4                // =4
     b24:      	add	w0, w0, w1, uxtb
     b28:      	subs	w2, w2, #0x1
     b2c:      	lsr	w1, w1, #8
     b30:      	add	w0, w0, w0, lsl #10
     b34:      	eor	w0, w0, w0, lsr #6
     b38:      	b.ne	0xb24 <kernel+0x4>
     b3c:      	add	w0, w0, w0, lsl #3
     b40:      	eor	w0, w0, w0, lsr #11
     b44:      	add	w0, w0, w0, lsl #15
     b48:      	ret

Disassembly of section .fini:

0000000000000b4c <_fini>:
     b4c:      	nop
     b50:      	stp	x29, x30, [sp, #-0x10]!
     b54:      	mov	x29, sp
     b58:      	ldp	x29, x30, [sp], #0x10
     b5c:      	ret
