
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

uint kernel(uint p0,uint p1)

{
  uint uVar1;
  uint uVar2;
  uint uVar3;
  uint uVar4;
  uint uVar5;
  uint uVar6;
  uint uVar7;
  uint uVar8;
  uint uVar9;
  uint uVar10;
  uint uVar11;
  uint uVar12;
  uint uVar13;
  uint uVar14;
  uint uVar15;
  uint uVar16;
  
  uVar1 = p0 ^ p1 ^ 0xffffffff;
  uVar2 = p0 >> 0x1c ^ 0xf;
  uVar13 = -(uVar1 & 1);
  uVar7 = ~((p0 ^ p1) >> 4);
  uVar16 = uVar1 >> 1;
  uVar3 = uVar13 & 0xe ^ uVar2 >> 1;
  uVar2 = (~(p0 >> 0x18) >> 1 & 7 | (uVar2 & 1) << 3) ^ uVar13 & 0xd;
  uVar10 = (uVar7 & 0xf) << 3;
  uVar12 = -(uVar16 & 1);
  uVar8 = (uVar1 & 1) << 3;
  uVar4 = ((~(p0 >> 0x18) & 1) << 3 | ~(p0 >> 0x14) >> 1 & 7) ^ uVar13 & 0xb;
  uVar5 = ((~(p0 >> 0x14) & 1) << 3 | ~(p0 >> 0x10) >> 1 & 7) ^ uVar8;
  uVar8 = ((~(p0 >> 0x10) & 1) << 3 | ~(p0 >> 0xc) >> 1 & 7) ^ uVar8;
  uVar6 = uVar12 & 0xe ^ uVar3 >> 1;
  uVar13 = ((~(p0 >> 0xc) & 1) << 3 | ~(p0 >> 8) >> 1 & 7) ^ uVar13 & 3;
  uVar3 = ((uVar3 & 1) << 3 | uVar2 >> 1) ^ uVar12 & 0xd;
  uVar7 = ((~(p0 >> 8) & 1) << 3 | uVar7 >> 1 & 7) ^ (uVar1 & 1) << 1;
  uVar11 = -((uVar16 & 2) >> 1);
  uVar9 = (uVar16 & 1) << 3;
  uVar2 = ((uVar2 & 1) << 3 | uVar4 >> 1) ^ uVar12 & 0xb;
  uVar4 = ((uVar4 & 1) << 3 | uVar5 >> 1) ^ uVar9;
  uVar1 = uVar7 << 3;
  uVar9 = ((uVar5 & 1) << 3 | uVar8 >> 1) ^ uVar9;
  uVar5 = uVar11 & 0xe ^ uVar6 >> 1;
  uVar8 = ((uVar8 & 1) << 3 | uVar13 >> 1) ^ uVar12 & 3;
  uVar6 = ((uVar6 & 1) << 3 | uVar3 >> 1) ^ uVar11 & 0xd;
  uVar13 = ((uVar13 & 1) << 3 | uVar7 >> 1) ^ (uVar16 & 1) << 1;
  uVar3 = ((uVar3 & 1) << 3 | uVar2 >> 1) ^ uVar11 & 0xb;
  uVar12 = ((uVar16 & 2) >> 1) << 3;
  uVar14 = -((uVar16 & 4) >> 2);
  uVar7 = ((uVar2 & 1) << 3 | uVar4 >> 1) ^ uVar12;
  uVar2 = uVar13 << 3;
  uVar12 = ((uVar4 & 1) << 3 | uVar9 >> 1) ^ uVar12;
  uVar4 = ((uVar9 & 1) << 3 | uVar8 >> 1) ^ uVar11 & 3;
  uVar9 = uVar14 & 0xe ^ uVar5 >> 1;
  uVar5 = ((uVar5 & 1) << 3 | uVar6 >> 1) ^ uVar14 & 0xd;
  uVar6 = ((uVar6 & 1) << 3 | uVar3 >> 1) ^ uVar14 & 0xb;
  uVar11 = ((uVar16 & 4) >> 2) << 3;
  uVar8 = ((uVar8 & 1) << 3 | uVar13 >> 1) ^ uVar16 & 2;
  uVar13 = ((uVar3 & 1) << 3 | uVar7 >> 1) ^ uVar11;
  uVar11 = ((uVar7 & 1) << 3 | uVar12 >> 1) ^ uVar11;
  uVar15 = -((uVar10 & 8) >> 3);
  uVar7 = ((uVar12 & 1) << 3 | uVar4 >> 1) ^ uVar14 & 3;
  uVar3 = uVar8 << 3;
  uVar12 = ((uVar9 & 1) << 3 | uVar5 >> 1) ^ uVar15 & 0xd;
  uVar5 = ((uVar5 & 1) << 3 | uVar6 >> 1) ^ uVar15 & 0xb;
  uVar4 = ((uVar4 & 1) << 3 | uVar8 >> 1) ^ (uVar16 & 4) >> 1;
  uVar8 = uVar15 & 0xe ^ uVar9 >> 1;
  uVar6 = ((uVar6 & 1) << 3 | uVar13 >> 1) ^ uVar10 & 8;
  uVar13 = ((uVar13 & 1) << 3 | uVar11 >> 1) ^ uVar10 & 8;
  uVar16 = -((uVar1 & 8) >> 3);
  uVar9 = ((uVar11 & 1) << 3 | uVar7 >> 1) ^ uVar15 & 3;
  uVar7 = ((uVar7 & 1) << 3 | uVar4 >> 1) ^ (uVar10 & 8) >> 2;
  uVar11 = ((uVar5 & 1) << 3 | uVar6 >> 1) ^ uVar1 & 8;
  uVar5 = ((uVar12 & 1) << 3 | uVar5 >> 1) ^ uVar16 & 0xb;
  uVar10 = uVar16 & 0xe ^ uVar8 >> 1;
  uVar6 = ((uVar6 & 1) << 3 | uVar13 >> 1) ^ uVar1 & 8;
  uVar8 = ((uVar8 & 1) << 3 | uVar12 >> 1) ^ uVar16 & 0xd;
  uVar13 = ((uVar13 & 1) << 3 | uVar9 >> 1) ^ uVar16 & 3;
  uVar16 = -((uVar2 & 8) >> 3);
  uVar1 = ((uVar9 & 1) << 3 | uVar7 >> 1) ^ (uVar1 & 8) >> 2;
  uVar9 = ((uVar11 & 1) << 3 | uVar6 >> 1) ^ uVar2 & 8;
  uVar12 = ((uVar5 & 1) << 3 | uVar11 >> 1) ^ uVar2 & 8;
  uVar5 = ((uVar8 & 1) << 3 | uVar5 >> 1) ^ uVar16 & 0xb;
  uVar6 = ((uVar6 & 1) << 3 | uVar13 >> 1) ^ uVar16 & 3;
  uVar8 = ((uVar10 & 1) << 3 | uVar8 >> 1) ^ uVar16 & 0xd;
  uVar11 = uVar16 & 0xe ^ uVar10 >> 1;
  uVar10 = -((uVar3 & 8) >> 3);
  uVar2 = ((uVar13 & 1) << 3 | uVar1 >> 1) ^ (uVar2 & 8) >> 2;
  uVar3 = uVar3 & 8;
  return (((uVar9 & 1) << 3 | uVar6 >> 1) ^ uVar10 & 3) << 8 ^ 0xf00 |
         (((uVar12 & 1) << 3 | uVar9 >> 1) ^ uVar3) << 0xc ^ 0xf000 |
         ~((((uVar4 & 1) << 2 | (uVar7 & 1) << 3) >> 1 | (uVar1 & 1) << 3) >> 1 | uVar2 << 3) & 0xf
         | (uVar10 & 0xe ^ uVar11 >> 1) << 0x1c ^ 0xf0000000 |
         (((uVar8 & 1) << 3 | uVar5 >> 1) ^ uVar10 & 0xb) << 0x14 ^ 0xf00000 |
         (((uVar5 & 1) << 3 | uVar12 >> 1) ^ uVar3) << 0x10 ^ 0xf0000 |
         (((uVar6 & 1) << 3 | uVar2 >> 1) ^ uVar10 & 2) << 4 ^ 0xf0 |
         (((uVar11 & 1) << 3 | uVar8 >> 1) ^ uVar10 & 0xd) << 0x18 ^ 0xf000000;
}

