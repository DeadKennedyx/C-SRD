
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

uint kernel(uint p0,uint p1)

{
  uint uVar1;
  uint uVar2;
  uint uVar3;
  uint uVar4;
  uint uVar5;
  uint uVar6;
  uint uVar7;
  uint uVar8;
  uint uVar9;
  uint uVar10;
  uint uVar11;
  uint uVar12;
  uint uVar13;
  
  uVar1 = (p0 & 0xf) + (p1 & 0xf);
  uVar2 = (p0 >> 4 & 0xf) + (p1 >> 4 & 0xf) + (uVar1 >> 4);
  uVar3 = (p0 >> 8 & 0xf) + (uVar2 >> 4);
  uVar12 = uVar2 >> 2 & 3;
  uVar4 = (uVar1 * 4 & 0xc) + (uVar3 & 0xf);
  uVar5 = (p0 >> 0xc & 0xf) + (uVar3 >> 4);
  uVar6 = (p0 >> 0x10 & 0xf) + (uVar5 >> 4);
  uVar7 = (uVar2 * 4 & 0xc | uVar1 >> 2 & 3) + (uVar5 & 0xf) + (uVar4 >> 4);
  uVar8 = (p0 >> 0x14 & 0xf) + (uVar6 >> 4);
  uVar9 = (uVar12 | (uVar3 & 3) << 2) + (uVar6 & 0xf) + (uVar7 >> 4);
  uVar1 = (((uVar4 * 4 & 0x3c | uVar12) ^ uVar1) & 0xf) + (p1 >> 8 & 0xf);
  uVar12 = (p0 >> 0x18 & 0xf) + (uVar8 >> 4);
  uVar3 = ((uVar3 & 0xf) >> 2 | (uVar5 & 3) << 2) + (uVar8 & 0xf) + (uVar9 >> 4);
  uVar2 = (((uVar4 >> 2 & 3 | uVar7 * 4 & 0x3c) ^ uVar2) & 0xf) + (p1 >> 0xc & 0xf) + (uVar1 >> 4);
  uVar5 = ((uVar5 & 0xf) >> 2 | (uVar6 & 3) << 2) + (uVar12 & 0xf) + (uVar3 >> 4);
  uVar4 = (((uVar7 >> 2 & 3 | uVar9 * 4 & 0x3c) ^ uVar4) & 0xf) + (uVar2 >> 4);
  uVar6 = ((uVar12 >> 4) + (p0 >> 0x1c) & 0xf) + ((uVar6 & 0xf) >> 2 | (uVar8 & 3) << 2) +
          (uVar5 >> 4);
  uVar7 = (((uVar9 >> 2 & 3 | uVar3 * 4 & 0x3c) ^ uVar7) & 0xf) + (uVar4 >> 4);
  uVar8 = (uVar1 * 4 & 0xc) + (uVar4 & 0xf);
  uVar13 = uVar2 >> 2 & 3;
  uVar9 = (((uVar3 >> 2 & 3 | uVar5 * 4 & 0x3c) ^ uVar9) & 0xf) + (uVar7 >> 4);
  uVar12 = (uVar2 * 4 & 0xc | uVar1 >> 2 & 3) + (uVar7 & 0xf) + (uVar8 >> 4);
  uVar10 = (uVar13 | (uVar4 & 3) << 2) + (uVar9 & 0xf) + (uVar12 >> 4);
  uVar3 = (((uVar5 >> 2 & 3 | uVar6 * 4 & 0x3c) ^ uVar3) & 0xf) + (uVar9 >> 4);
  uVar1 = (((uVar8 * 4 & 0x3c | uVar13) ^ uVar1) & 0xf) + (p1 >> 0x10 & 0xf);
  uVar5 = (uVar6 >> 2 & 3 ^ uVar5 & 0xf) + (uVar3 >> 4);
  uVar4 = ((uVar4 & 0xf) >> 2 | (uVar7 & 3) << 2) + (uVar3 & 0xf) + (uVar10 >> 4);
  uVar2 = (((uVar8 >> 2 & 3 | uVar12 * 4 & 0x3c) ^ uVar2) & 0xf) + (p1 >> 0x14 & 0xf) + (uVar1 >> 4)
  ;
  uVar7 = ((uVar7 & 0xf) >> 2 | (uVar9 & 3) << 2) + (uVar5 & 0xf) + (uVar4 >> 4);
  uVar8 = (((uVar12 >> 2 & 3 | uVar10 * 4 & 0x3c) ^ uVar8) & 0xf) + (uVar2 >> 4);
  uVar3 = ((uVar9 & 0xf) >> 2 | (uVar3 & 3) << 2) + ((uVar6 & 0xf) + (uVar5 >> 4) & 0xf) +
          (uVar7 >> 4);
  uVar5 = (uVar1 * 4 & 0xc) + (uVar8 & 0xf);
  uVar6 = (((uVar10 >> 2 & 3 | uVar4 * 4 & 0x3c) ^ uVar12) & 0xf) + (uVar8 >> 4);
  uVar13 = uVar2 >> 2 & 3;
  uVar9 = (((uVar4 >> 2 & 3 | uVar7 * 4 & 0x3c) ^ uVar10) & 0xf) + (uVar6 >> 4);
  uVar12 = (uVar2 * 4 & 0xc | uVar1 >> 2 & 3) + (uVar6 & 0xf) + (uVar5 >> 4);
  uVar4 = (((uVar7 >> 2 & 3 | uVar3 * 4 & 0x3c) ^ uVar4) & 0xf) + (uVar9 >> 4);
  uVar10 = (uVar13 | (uVar8 & 3) << 2) + (uVar9 & 0xf) + (uVar12 >> 4);
  uVar1 = (((uVar5 * 4 & 0x3c | uVar13) ^ uVar1) & 0xf) + (p1 >> 0x18 & 0xf);
  uVar7 = (uVar3 >> 2 & 3 ^ uVar7 & 0xf) + (uVar4 >> 4);
  uVar8 = ((uVar8 & 0xf) >> 2 | (uVar6 & 3) << 2) + (uVar4 & 0xf) + (uVar10 >> 4);
  uVar6 = ((uVar6 & 0xf) >> 2 | (uVar9 & 3) << 2) + (uVar7 & 0xf) + (uVar8 >> 4);
  uVar2 = (((uVar5 >> 2 & 3 | uVar12 * 4 & 0x3c) ^ uVar2) & 0xf) + (uVar1 >> 4) + (p1 >> 0x1c);
  uVar3 = ((uVar9 & 0xf) >> 2 | (uVar4 & 3) << 2) + ((uVar3 & 0xf) + (uVar7 >> 4) & 0xf) +
          (uVar6 >> 4);
  uVar4 = (((uVar12 >> 2 & 3 | uVar10 * 4 & 0x3c) ^ uVar5) & 0xf) + (uVar2 >> 4);
  uVar5 = (((uVar10 >> 2 & 3 | uVar8 * 4 & 0x3c) ^ uVar12) & 0xf) + (uVar4 >> 4);
  uVar7 = (uVar1 * 4 & 0xc) + (uVar4 & 0xf);
  uVar13 = uVar2 >> 2 & 3;
  uVar9 = (((uVar8 >> 2 & 3 | uVar6 * 4 & 0x3c) ^ uVar10) & 0xf) + (uVar5 >> 4);
  uVar12 = (uVar2 * 4 & 0xc | uVar1 >> 2 & 3) + (uVar5 & 0xf) + (uVar7 >> 4);
  uVar8 = (((uVar6 >> 2 & 3 | uVar3 * 4 & 0x3c) ^ uVar8) & 0xf) + (uVar9 >> 4);
  uVar10 = (uVar13 | (uVar4 & 3) << 2) + (uVar9 & 0xf) + (uVar12 >> 4);
  uVar6 = (uVar3 >> 2 & 3 ^ uVar6 & 0xf) + (uVar8 >> 4);
  uVar1 = (uVar7 * 4 & 0x3c | uVar13) ^ uVar1;
  uVar4 = ((uVar4 & 0xf) >> 2 | (uVar5 & 3) << 2) + (uVar8 & 0xf) + (uVar10 >> 4);
  uVar2 = (uVar7 >> 2 & 3 | uVar12 * 4 & 0x3c) ^ uVar2;
  uVar13 = uVar1 & 0xf;
  uVar5 = ((uVar5 & 0xf) >> 2 | (uVar9 & 3) << 2) + (uVar6 & 0xf) + (uVar4 >> 4);
  uVar1 = (uVar1 & 1) * 8 + uVar13;
  uVar7 = (uVar12 >> 2 & 3 | uVar10 * 4 & 0x3c) ^ uVar7;
  uVar11 = uVar2 & 0xf;
  uVar3 = ((uVar9 & 0xf) >> 2 | (uVar8 & 3) << 2) + ((uVar3 & 0xf) + (uVar6 >> 4) & 0xf) +
          (uVar5 >> 4);
  uVar12 = (uVar10 >> 2 & 3 | uVar4 * 4 & 0x3c) ^ uVar12;
  uVar2 = ((uVar2 & 1) << 3 | uVar13 >> 1) + uVar11 + (uVar1 >> 4);
  uVar8 = uVar7 & 0xf;
  uVar10 = (uVar4 >> 2 & 3 | uVar5 * 4 & 0x3c) ^ uVar10;
  uVar9 = uVar12 & 0xf;
  uVar6 = ((uVar7 & 1) << 3 | uVar11 >> 1) + (uVar2 >> 4) + uVar8;
  uVar4 = (uVar5 >> 2 & 3 | uVar3 * 4 & 0x3c) ^ uVar4;
  uVar13 = uVar10 & 0xf;
  uVar7 = ((uVar12 & 1) << 3 | uVar8 >> 1) + uVar9 + (uVar6 >> 4);
  uVar8 = uVar4 & 0xf;
  uVar12 = uVar3 >> 2 & 3 ^ uVar5 & 0xf;
  uVar5 = ((uVar10 & 1) << 3 | uVar9 >> 1) + uVar13 + (uVar7 >> 4);
  uVar4 = ((uVar4 & 1) << 3 | uVar13 >> 1) + uVar8 + (uVar5 >> 4);
  uVar8 = (uVar8 >> 1 | (uVar12 & 1) << 3) + uVar12 + (uVar4 >> 4);
  uVar3 = (uVar3 * 8 & 8 | uVar12 >> 1) + (uVar3 & 0xf) + (uVar8 >> 4);
  uVar1 = (uVar6 >> 3 & 1 | uVar7 * 2 & 0x1e) ^ uVar1;
  uVar10 = (uVar4 >> 3 & 1 | uVar8 * 2 & 0x1e) ^ uVar7;
  uVar2 = (uVar7 >> 3 & 1 | uVar5 * 2 & 0x1e) ^ uVar2;
  uVar12 = uVar10 & 0xf;
  uVar6 = (uVar5 >> 3 & 1 | uVar4 * 2 & 0x1e) ^ uVar6;
  uVar7 = (uVar1 & 1) * 8 + uVar12;
  uVar5 = (uVar8 >> 3 & 1 | uVar3 * 2 & 0x1e) ^ uVar5;
  uVar9 = ((uVar2 & 1) << 3 | uVar1 >> 1 & 7) + (uVar5 & 0xf) + (uVar7 >> 4);
  uVar4 = ((uVar6 & 1) << 3 | uVar2 >> 1 & 7) + (uVar3 >> 3 & 1 ^ uVar4 & 0xf) + (uVar9 >> 4);
  uVar8 = (uVar6 >> 1 & 7 | (uVar10 & 1) << 3) + (uVar8 & 0xf) + (uVar4 >> 4);
  return uVar7 * 0x1000 & 0xf000 | (uVar6 & 0xf) << 8 | (uVar2 & 0xf) << 4 | uVar1 & 0xf |
         uVar9 * 0x10000 & 0xf0000 | uVar4 * 0x100000 & 0xf00000 |
         uVar8 * 0x1000000 & 0xf000000 |
         ((uVar12 >> 1 | (uVar5 & 1) << 3) + (uVar3 & 0xf) + (uVar8 >> 4)) * 0x10000000;
}

