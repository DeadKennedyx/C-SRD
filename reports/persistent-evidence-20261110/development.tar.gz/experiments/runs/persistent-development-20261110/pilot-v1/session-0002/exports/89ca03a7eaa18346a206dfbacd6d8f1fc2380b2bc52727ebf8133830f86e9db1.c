
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

uint kernel(uint p0,uint p1)

{
  uint uVar1;
  int iVar2;
  
  uVar1 = p1 & 0xff ^ p0 ^ 0xffffffff;
  iVar2 = 8;
  do {
    iVar2 = iVar2 + -1;
    uVar1 = -(uVar1 & 1) & 0xedb88320 ^ uVar1 >> 1;
  } while (iVar2 != 0);
  return ~uVar1;
}

