
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

uint kernel(uint p0,uint p1)

{
  uint uVar1;
  
  uVar1 = (p0 + (p1 & 0xff)) * 0x401;
  uVar1 = ((uVar1 ^ uVar1 >> 6) + (p1 >> 8 & 0xff)) * 0x401;
  uVar1 = ((uVar1 ^ uVar1 >> 6) + (p1 >> 0x10 & 0xff)) * 0x401;
  uVar1 = ((uVar1 ^ uVar1 >> 6) + (p1 >> 0x18)) * 0x401;
  uVar1 = (uVar1 ^ uVar1 >> 6) * 9;
  return (uVar1 ^ uVar1 >> 0xb) * 0x8001;
}

