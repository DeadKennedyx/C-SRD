
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

uint kernel(uint p0,uint p1)

{
  uint uVar1;
  uint uVar2;
  uint uVar3;
  uint uVar4;
  uint uVar5;
  uint uVar6;
  uint uVar7;
  uint uVar8;
  uint uVar9;
  uint uVar10;
  uint uVar11;
  uint uVar12;
  uint uVar13;
  uint uVar14;
  uint uVar15;
  uint uVar16;
  uint uVar17;
  uint uVar18;
  uint uVar19;
  uint uVar20;
  uint uVar21;
  uint uVar22;
  
  uVar22 = p1 ^ p0 ^ 0xffffffff;
  uVar1 = p1 ^ p0;
  uVar2 = p0 >> 8 ^ 0xffffffff;
  uVar3 = p0 >> 0xc ^ 0xffffffff;
  uVar17 = -(uVar22 & 1);
  uVar4 = p0 >> 0x10 ^ 0xffffffff;
  uVar18 = -(uVar22 >> 1 & 1);
  uVar16 = ~p0;
  uVar5 = p0 >> 0x14 ^ 0xffffffff;
  uVar6 = p0 >> 0x18 ^ 0xffffffff;
  uVar7 = uVar1 >> 4 ^ 0xffffffff;
  uVar8 = uVar17 & 3 ^ (uVar2 >> 1 & 7 | (uVar3 & 1) << 3);
  uVar9 = uVar17 & 8 ^ (uVar3 >> 1 & 7 | (uVar4 & 1) << 3);
  uVar3 = (uVar8 >> 1 | (uVar3 >> 1 & 1) << 3) ^ uVar18 & 3;
  uVar2 = uVar17 & 2 ^ ((uVar2 & 1) << 3 | uVar7 >> 1 & 7);
  uVar10 = uVar17 & 8 ^ (uVar4 >> 1 & 7 | (uVar5 & 1) << 3);
  uVar5 = uVar17 & 0xb ^ (uVar5 >> 1 & 7 | (uVar6 & 1) << 3);
  uVar6 = uVar17 & 0xd ^ (uVar16 >> 0x19 & 8 | uVar6 >> 1 & 7);
  uVar19 = -(uVar22 >> 2 & 1);
  uVar11 = (uVar5 >> 1 | (uVar6 & 1) << 3) ^ uVar18 & 0xb;
  uVar6 = (uVar16 >> 0x1a & 8 | uVar6 >> 1) ^ uVar18 & 0xd;
  uVar22 = uVar16 >> 0x1e ^ (uVar17 & 0xe) >> 1;
  uVar8 = (uVar2 >> 1 | (uVar8 & 1) << 3) ^ uVar18 & 2;
  uVar15 = uVar8 >> 1;
  uVar16 = uVar22 ^ uVar18 & 0xf;
  uVar5 = (((uVar5 & 1) << 3 ^ uVar18 & 8) >> 1 | (uVar11 & 1) << 3) ^ uVar19 & 8;
  uVar17 = (uVar3 >> 1 | (uVar9 >> 1 & 1) << 3) ^ uVar19 & 3;
  uVar4 = (((uVar4 >> 1 & 1) << 3 ^ uVar18 & 8) >> 1 | (uVar10 >> 1 & 1) << 3) ^ uVar19 & 8;
  uVar18 = (uVar15 | uVar3 << 3) >> 1;
  uVar3 = (uVar6 >> 1 | (uVar22 & 1) << 3) ^ uVar19 & 0xd;
  uVar22 = 0xf;
  if (((uVar1 ^ 0xffffffff) & 8) == 0) {
    uVar22 = 0;
  }
  uVar6 = (uVar11 >> 1 | (uVar6 & 1) << 3) ^ uVar19 & 0xb;
  uVar11 = uVar19 & 0xf ^ uVar16 >> 1;
  uVar12 = ((p0 >> 0x10 ^ 0xffffffff) & 8 | uVar4 >> 1) ^ uVar22 & 8;
  uVar13 = ((p0 >> 0xc ^ 0xffffffff) & 8 | uVar17 >> 1) ^ uVar22 & 3;
  uVar20 = -((uVar1 >> 4 ^ 0xffffffff) & 1);
  uVar1 = (uVar5 >> 1 | (uVar6 & 1) << 3) ^ uVar22 & 8;
  uVar6 = (uVar6 >> 1 | (uVar3 & 1) << 3) ^ uVar22 & 0xfffffffb;
  uVar3 = (uVar3 >> 1 | (uVar16 >> 1 & 1) << 3) ^ uVar22 & 0xfffffffd;
  uVar16 = uVar11 >> 2 ^ uVar22 >> 1;
  uVar9 = (uVar9 & 8 | uVar13 >> 1) ^ uVar20 & 3;
  uVar14 = ((uVar3 & 1) << 3 | uVar6 >> 1) ^ uVar20 & 0xb;
  uVar3 = ((uVar11 & 2) << 2 | uVar3 >> 1) ^ uVar20 & 0xd;
  uVar11 = uVar16 ^ uVar20 & 0xf;
  uVar13 = (((uVar18 & 6 | (uVar17 & 1) << 3) >> 1 | (uVar13 & 1) << 3) ^ uVar20 & 2) >> 1;
  uVar21 = -(uVar7 >> 1 & 1);
  uVar7 = (uVar9 >> 1 | (uVar12 >> 1 & 1) << 3) ^ uVar21 & 3;
  uVar17 = (uVar14 >> 1 | (uVar3 & 1) << 3) ^ uVar21 & 0xb;
  uVar3 = (uVar3 >> 1 | (uVar16 & 1) << 3) ^ uVar21 & 0xd;
  uVar16 = -(uVar2 >> 1 & 1);
  uVar2 = uVar21 & 0xf ^ uVar11 >> 1;
  uVar4 = (uVar4 & 8 | uVar7 >> 1) ^ uVar16 & 3;
  uVar11 = (uVar3 >> 1 | (uVar11 >> 1 & 1) << 3) ^ uVar16 & 0xd;
  uVar8 = -(uVar8 >> 1 & 1);
  uVar3 = (uVar17 >> 1 | (uVar3 & 1) << 3) ^ uVar16 & 0xb;
  return ((((uVar11 >> 1 | (uVar2 >> 1 & 1) << 3) ^ uVar8 & 0xd) << 0x18 |
          (uVar8 & 0xe ^ uVar16 >> 1 & 7 ^ uVar2 >> 2 ^ 0xffffffff) << 0x1c) ^ 0xf000000 |
          ((uVar12 & 8 | uVar4 >> 1) ^ uVar8 & 3) << 8 ^ 0xf00 |
          ((uVar3 >> 1 | (uVar11 & 1) << 3) ^ uVar8 & 0xb) << 0x14 ^ 0xf00000 |
          ((uVar15 ^ uVar19) & 2 | ((uVar18 ^ uVar22) >> 1 & 1) << 2 | (uVar13 & 1) << 3) >> 1 |
          ((uVar13 ^ uVar21) >> 1 & 1) << 3 |
          (((uVar4 & 1) << 3 |
           (((uVar7 & 1) << 3 | (uVar13 | (uVar9 & 1) << 3) >> 1) ^ uVar16 & 2) >> 1) ^ uVar8 & 2)
          << 4 | ((uVar1 & 8 |
                  ((uVar5 & 8 |
                   (((uVar10 & 8 ^ uVar20 & 8) >> 1 | (uVar1 >> 1 & 1) << 3) ^ uVar21 & 8) >> 1) ^
                  uVar16 & 8) >> 1) ^ uVar8 & 8) << 0xc ^ 0xf000 |
         ((((((((uVar6 & 1) << 3 ^ uVar20 & 8) >> 1 | (uVar14 & 1) << 3) ^ uVar21 & 8) >> 1 |
            (uVar17 & 1) << 3) ^ uVar16 & 8) >> 1 | (uVar3 & 1) << 3) ^ uVar8 & 8) << 0x10 ^ 0xf0000
         ) ^ 0xff;
}

