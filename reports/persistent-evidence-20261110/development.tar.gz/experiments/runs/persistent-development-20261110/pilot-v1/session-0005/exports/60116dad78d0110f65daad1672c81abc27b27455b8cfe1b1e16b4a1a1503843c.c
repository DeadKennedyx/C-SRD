
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

uint kernel(uint p0,uint p1)

{
  uint uVar1;
  int iVar2;
  
  iVar2 = 4;
  do {
    uVar1 = p1 & 0xff;
    iVar2 = iVar2 + -1;
    p1 = p1 >> 8;
    uVar1 = (p0 + uVar1) * 0x401;
    p0 = uVar1 ^ uVar1 >> 6;
  } while (iVar2 != 0);
  return (p0 * 9 ^ p0 * 9 >> 0xb) * 0x8001;
}

