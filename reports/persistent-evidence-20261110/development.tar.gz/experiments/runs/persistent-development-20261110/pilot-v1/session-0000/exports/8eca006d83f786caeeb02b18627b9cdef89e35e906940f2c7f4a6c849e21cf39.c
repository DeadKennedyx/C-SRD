
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

uint kernel(uint p0,uint p1)

{
  uint uVar1;
  uint uVar2;
  uint uVar3;
  uint uVar4;
  undefined1 auVar5 [16];
  int iVar6;
  int iVar7;
  int iVar8;
  int iVar9;
  byte bVar10;
  byte bVar11;
  byte bVar12;
  byte bVar13;
  byte bVar14;
  byte bVar15;
  byte bVar16;
  byte bVar17;
  byte bVar18;
  byte bVar19;
  byte bVar20;
  byte bVar21;
  byte bVar22;
  byte bVar23;
  byte bVar24;
  byte bVar25;
  undefined1 auVar26 [16];
  
  uVar1 = p0 ^ 0xffffffff;
  uVar2 = p1 & 0xff ^ uVar1;
  bVar10 = (byte)uVar2;
  bVar11 = (byte)(uVar1 >> 8);
  bVar12 = (byte)(uVar1 >> 0x10);
  bVar13 = (byte)(uVar1 >> 0x18);
  iVar6 = -(uint)(CONCAT13(bVar13 & (byte)((ulong)_DAT_00100a70 >> 0x18),
                           CONCAT12(bVar12 & (byte)((ulong)_DAT_00100a70 >> 0x10),
                                    CONCAT11(bVar11 & (byte)((ulong)_DAT_00100a70 >> 8),
                                             bVar10 & (byte)_DAT_00100a70))) == 0);
  iVar7 = -(uint)(CONCAT13(bVar13 & (byte)((ulong)_DAT_00100a70 >> 0x38),
                           CONCAT12(bVar12 & (byte)((ulong)_DAT_00100a70 >> 0x30),
                                    CONCAT11(bVar11 & (byte)((ulong)_DAT_00100a70 >> 0x28),
                                             bVar10 & (byte)((ulong)_DAT_00100a70 >> 0x20)))) == 0);
  iVar8 = -(uint)(CONCAT13(bVar13 & (byte)((ulong)_UNK_00100a78 >> 0x18),
                           CONCAT12(bVar12 & (byte)((ulong)_UNK_00100a78 >> 0x10),
                                    CONCAT11(bVar11 & (byte)((ulong)_UNK_00100a78 >> 8),
                                             bVar10 & (byte)_UNK_00100a78))) == 0);
  iVar9 = -(uint)(CONCAT13(bVar13 & (byte)((ulong)_UNK_00100a78 >> 0x38),
                           CONCAT12(bVar12 & (byte)((ulong)_UNK_00100a78 >> 0x30),
                                    CONCAT11(bVar11 & (byte)((ulong)_UNK_00100a78 >> 0x28),
                                             bVar10 & (byte)((ulong)_UNK_00100a78 >> 0x20)))) == 0);
  uVar3 = -(uVar2 & 1) & 0xedb88320 ^ uVar2 >> 1;
  uVar2 = (int)(uVar2 << 0x1e) >> 0x1f & 0xedb88320U ^ uVar3 >> 1;
  bVar10 = (byte)_DAT_00100a80 & ~(byte)iVar6;
  bVar11 = (byte)((ulong)_DAT_00100a80 >> 8) & ~(byte)((uint)iVar6 >> 8);
  bVar12 = (byte)((ulong)_DAT_00100a80 >> 0x10) & ~(byte)((uint)iVar6 >> 0x10);
  bVar13 = (byte)((ulong)_DAT_00100a80 >> 0x18) & ~(byte)((uint)iVar6 >> 0x18);
  bVar14 = (byte)((ulong)_DAT_00100a80 >> 0x20) & ~(byte)iVar7;
  bVar15 = (byte)((ulong)_DAT_00100a80 >> 0x28) & ~(byte)((uint)iVar7 >> 8);
  bVar16 = (byte)((ulong)_DAT_00100a80 >> 0x30) & ~(byte)((uint)iVar7 >> 0x10);
  bVar17 = (byte)((ulong)_DAT_00100a80 >> 0x38) & ~(byte)((uint)iVar7 >> 0x18);
  bVar18 = (byte)_UNK_00100a88 & ~(byte)iVar8;
  bVar19 = (byte)((ulong)_UNK_00100a88 >> 8) & ~(byte)((uint)iVar8 >> 8);
  bVar20 = (byte)((ulong)_UNK_00100a88 >> 0x10) & ~(byte)((uint)iVar8 >> 0x10);
  bVar21 = (byte)((ulong)_UNK_00100a88 >> 0x18) & ~(byte)((uint)iVar8 >> 0x18);
  bVar22 = (byte)((ulong)_UNK_00100a88 >> 0x20) & ~(byte)iVar9;
  bVar23 = (byte)((ulong)_UNK_00100a88 >> 0x28) & ~(byte)((uint)iVar9 >> 8);
  bVar24 = (byte)((ulong)_UNK_00100a88 >> 0x30) & ~(byte)((uint)iVar9 >> 0x10);
  bVar25 = (byte)((ulong)_UNK_00100a88 >> 0x38) & ~(byte)((uint)iVar9 >> 0x18);
  uVar1 = 0x12477cdf;
  if ((uVar2 & 0x20) == 0) {
    uVar1 = 0xffffffff;
  }
  auVar26[1] = bVar11;
  auVar26[0] = bVar10;
  auVar26[2] = bVar12;
  auVar26[3] = bVar13;
  auVar26[4] = bVar14;
  auVar26[5] = bVar15;
  auVar26[6] = bVar16;
  auVar26[7] = bVar17;
  auVar26[8] = bVar18;
  auVar26[9] = bVar19;
  auVar26[10] = bVar20;
  auVar26[0xb] = bVar21;
  auVar26[0xc] = bVar22;
  auVar26[0xd] = bVar23;
  auVar26[0xe] = bVar24;
  auVar26[0xf] = bVar25;
  auVar5[1] = bVar11;
  auVar5[0] = bVar10;
  auVar5[2] = bVar12;
  auVar5[3] = bVar13;
  auVar5[4] = bVar14;
  auVar5[5] = bVar15;
  auVar5[6] = bVar16;
  auVar5[7] = bVar17;
  auVar5[8] = bVar18;
  auVar5[9] = bVar19;
  auVar5[10] = bVar20;
  auVar5[0xb] = bVar21;
  auVar5[0xc] = bVar22;
  auVar5[0xd] = bVar23;
  auVar5[0xe] = bVar24;
  auVar5[0xf] = bVar25;
  auVar26 = NEON_ext(auVar26,auVar5,8,1);
  uVar4 = CONCAT13(bVar13 ^ auVar26[3],
                   CONCAT12(bVar12 ^ auVar26[2],CONCAT11(bVar11 ^ auVar26[1],bVar10 ^ auVar26[0])));
  return uVar4 ^ (int)(uVar3 << 0x1a) >> 0x1f & 0x76dc4190U ^ uVar1 ^ uVar2 >> 6 ^
         (uint)(CONCAT17(bVar17 ^ auVar26[7],
                         CONCAT16(bVar16 ^ auVar26[6],
                                  CONCAT15(bVar15 ^ auVar26[5],CONCAT14(bVar14 ^ auVar26[4],uVar4)))
                        ) >> 0x20);
}

