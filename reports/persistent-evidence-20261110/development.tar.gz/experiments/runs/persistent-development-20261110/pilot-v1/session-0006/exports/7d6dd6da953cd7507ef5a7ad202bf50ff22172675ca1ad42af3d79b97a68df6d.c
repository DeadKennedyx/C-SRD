
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

uint kernel(uint p0,uint p1)

{
  uint uVar1;
  uint uVar2;
  uint uVar3;
  uint uVar4;
  uint uVar5;
  uint uVar6;
  uint uVar7;
  uint uVar8;
  uint uVar9;
  uint uVar10;
  uint uVar11;
  uint uVar12;
  
  uVar1 = (p1 & 0xf) + (p0 & 0xf);
  uVar2 = (p1 >> 4 & 0xf) + (p0 >> 4 & 0xf) + (uVar1 >> 4);
  uVar3 = (p0 >> 8 & 0xf) + (uVar2 >> 4);
  uVar11 = uVar2 >> 2 & 3;
  uVar4 = (p0 >> 0xc & 0xf) + (uVar3 >> 4);
  uVar5 = (p0 >> 0x10 & 0xf) + (uVar4 >> 4);
  uVar6 = (uVar3 & 0xf) + (uVar1 * 4 & 0xc);
  uVar7 = (p0 >> 0x14 & 0xf) + (uVar5 >> 4);
  uVar8 = (uVar1 >> 2 & 3 | uVar2 * 4 & 0xc) + (uVar4 & 0xf) + (uVar6 >> 4);
  uVar9 = (p0 >> 0x18 & 0xf) + (uVar7 >> 4);
  uVar10 = (uVar11 | uVar3 * 4 & 0xc) + (uVar5 & 0xf) + (uVar8 >> 4);
  uVar3 = (uVar3 >> 2 & 3 | uVar4 * 4 & 0xc) + (uVar7 & 0xf) + (uVar10 >> 4);
  uVar4 = (uVar4 >> 2 & 3 | uVar5 * 4 & 0xc) + (uVar9 & 0xf) + (uVar3 >> 4);
  uVar1 = ((uVar11 | uVar6 * 4 & 0xc) ^ uVar1 & 0xf) + (p1 >> 8 & 0xf);
  uVar5 = (uVar5 >> 2 & 3) + (p0 >> 0x1c) + uVar7 * 4 + (uVar9 >> 4) + (uVar4 >> 4);
  uVar2 = (p1 >> 0xc & 0xf) + (uVar1 >> 4) + ((uVar6 >> 2 & 3 | uVar8 * 4 & 0xc) ^ uVar2 & 0xf);
  uVar6 = ((uVar8 >> 2 & 3 | uVar10 * 4 & 0xc) ^ uVar6 & 0xf) + (uVar2 >> 4);
  uVar7 = ((uVar10 >> 2 & 3 | uVar3 * 4 & 0xc) ^ uVar8 & 0xf) + (uVar6 >> 4);
  uVar12 = uVar2 >> 2 & 3;
  uVar8 = ((uVar3 >> 2 & 3 | uVar4 * 4 & 0xc) ^ uVar10 & 0xf) + (uVar7 >> 4);
  uVar9 = (uVar6 & 0xf) + (uVar1 * 4 & 0xc);
  uVar3 = ((uVar4 >> 2 & 3 | uVar5 * 4 & 0xc) ^ uVar3 & 0xf) + (uVar8 >> 4);
  uVar10 = (uVar1 >> 2 & 3 | uVar2 * 4 & 0xc) + (uVar7 & 0xf) + (uVar9 >> 4);
  uVar11 = uVar3 & 0xf;
  uVar3 = (uVar4 & 0xf ^ (uVar5 & 0xc) >> 2) + (uVar3 >> 4);
  uVar4 = (uVar12 | uVar6 * 4 & 0xc) + (uVar8 & 0xf) + (uVar10 >> 4);
  uVar6 = (uVar6 >> 2 & 3 | uVar7 * 4 & 0xc) + uVar11 + (uVar4 >> 4);
  uVar7 = (uVar7 >> 2 & 3 | uVar8 * 4 & 0xc) + (uVar3 & 0xf) + (uVar6 >> 4);
  uVar1 = ((uVar12 | uVar9 * 4 & 0xc) ^ uVar1 & 0xf) + (p1 >> 0x10 & 0xf);
  uVar3 = uVar5 + ((uVar8 & 0xf) >> 2) + uVar11 * 4 + (uVar3 >> 4) + (uVar7 >> 4);
  uVar2 = (p1 >> 0x14 & 0xf) + (uVar1 >> 4) + ((uVar9 >> 2 & 3 | uVar10 * 4 & 0xc) ^ uVar2 & 0xf);
  uVar5 = ((uVar10 >> 2 & 3 | uVar4 * 4 & 0xc) ^ uVar9 & 0xf) + (uVar2 >> 4);
  uVar8 = ((uVar4 >> 2 & 3 | uVar6 * 4 & 0xc) ^ uVar10 & 0xf) + (uVar5 >> 4);
  uVar12 = uVar2 >> 2 & 3;
  uVar4 = ((uVar6 >> 2 & 3 | uVar7 * 4 & 0xc) ^ uVar4 & 0xf) + (uVar8 >> 4);
  uVar9 = (uVar5 & 0xf) + (uVar1 * 4 & 0xc);
  uVar6 = ((uVar7 >> 2 & 3 | uVar3 * 4 & 0xc) ^ uVar6 & 0xf) + (uVar4 >> 4);
  uVar10 = (uVar1 >> 2 & 3 | uVar2 * 4 & 0xc) + (uVar8 & 0xf) + (uVar9 >> 4);
  uVar7 = (uVar7 & 0xf ^ (uVar3 & 0xc) >> 2) + (uVar6 >> 4);
  uVar6 = uVar6 & 0xf;
  uVar11 = (uVar12 | uVar5 * 4 & 0xc) + (uVar4 & 0xf) + (uVar10 >> 4);
  uVar5 = (uVar5 >> 2 & 3 | uVar8 * 4 & 0xc) + uVar6 + (uVar11 >> 4);
  uVar8 = (uVar8 >> 2 & 3 | uVar4 * 4 & 0xc) + (uVar7 & 0xf) + (uVar5 >> 4);
  uVar1 = ((uVar12 | uVar9 * 4 & 0xc) ^ uVar1 & 0xf) + (p1 >> 0x18 & 0xf);
  uVar3 = uVar3 + ((uVar4 & 0xf) >> 2) + uVar6 * 4 + (uVar7 >> 4) + (uVar8 >> 4);
  uVar2 = (uVar1 >> 4) + (p1 >> 0x1c) + ((uVar9 >> 2 & 3 | uVar10 * 4 & 0xc) ^ uVar2 & 0xf);
  uVar4 = ((uVar10 >> 2 & 3 | uVar11 * 4 & 0xc) ^ uVar9 & 0xf) + (uVar2 >> 4);
  uVar12 = uVar2 >> 2 & 3;
  uVar6 = ((uVar11 >> 2 & 3 | uVar5 * 4 & 0xc) ^ uVar10 & 0xf) + (uVar4 >> 4);
  uVar7 = ((uVar5 >> 2 & 3 | uVar8 * 4 & 0xc) ^ uVar11 & 0xf) + (uVar6 >> 4);
  uVar5 = ((uVar8 >> 2 & 3 | uVar3 * 4 & 0xc) ^ uVar5 & 0xf) + (uVar7 >> 4);
  uVar9 = (uVar4 & 0xf) + (uVar1 * 4 & 0xc);
  uVar10 = (uVar1 >> 2 & 3 | uVar2 * 4 & 0xc) + (uVar6 & 0xf) + (uVar9 >> 4);
  uVar8 = (uVar8 & 0xf ^ (uVar3 & 0xc) >> 2) + (uVar5 >> 4);
  uVar5 = uVar5 & 0xf;
  uVar11 = (uVar12 | uVar4 * 4 & 0xc) + (uVar7 & 0xf) + (uVar10 >> 4);
  uVar4 = (uVar4 >> 2 & 3 | uVar6 * 4 & 0xc) + uVar5 + (uVar11 >> 4);
  uVar12 = (uVar12 | uVar9 * 4 & 0xc) ^ uVar1 & 0xf;
  uVar1 = (uVar6 >> 2 & 3 | uVar7 * 4 & 0xc) + (uVar8 & 0xf) + (uVar4 >> 4);
  uVar6 = (uVar9 >> 2 & 3 | uVar10 * 4 & 0xc) ^ uVar2 & 0xf;
  uVar9 = (uVar10 >> 2 & 3 | uVar11 * 4 & 0xc) ^ uVar9 & 0xf;
  uVar2 = uVar3 + ((uVar7 & 0xf) >> 2) + uVar5 * 4 + (uVar8 >> 4) + (uVar1 >> 4);
  uVar3 = (uVar12 & 1) * 8 + uVar12;
  uVar7 = (uVar11 >> 2 & 3 | uVar4 * 4 & 0xc) ^ uVar10 & 0xf;
  uVar8 = (uVar4 >> 2 & 3 | uVar1 * 4 & 0xc) ^ uVar11 & 0xf;
  uVar5 = uVar6 + (uVar12 >> 1) + (uVar3 >> 4) + (uVar6 & 1) * 8;
  uVar6 = uVar9 + (uVar6 >> 1) + (uVar9 & 1) * 8 + (uVar5 >> 4);
  uVar10 = (uVar1 >> 2 & 3 | uVar2 * 4 & 0xc) ^ uVar4 & 0xf;
  uVar11 = uVar1 & 0xf ^ (uVar2 & 0xf) >> 2;
  uVar1 = uVar7 + (uVar9 >> 1) + (uVar7 & 1) * 8 + (uVar6 >> 4);
  uVar4 = uVar8 + (uVar7 >> 1) + (uVar8 & 1) * 8 + (uVar1 >> 4);
  uVar7 = uVar10 + (uVar8 >> 1) + (uVar10 & 1) * 8 + (uVar4 >> 4);
  uVar8 = (uVar11 & 1) * 8 + uVar11 + (uVar10 >> 1) + (uVar7 >> 4);
  uVar2 = uVar2 + (uVar2 & 0xf) * 8 + (uVar11 >> 1) + (uVar8 >> 4);
  uVar9 = (uVar6 >> 3 & 1 | uVar1 * 2 & 0xe) ^ uVar3 & 0xf;
  uVar10 = (uVar1 >> 3 & 1 | uVar4 * 2 & 0xe) ^ uVar5 & 0xf;
  uVar6 = (uVar4 >> 3 & 1 | uVar7 * 2 & 0xe) ^ uVar6 & 0xf;
  uVar11 = (uVar7 >> 3 & 1 | uVar8 * 2 & 0xe) ^ uVar1 & 0xf;
  uVar12 = (uVar8 >> 3 & 1 | uVar2 * 2 & 0xe) ^ uVar4 & 0xf;
  uVar1 = uVar11 + (uVar9 & 1) * 8;
  uVar3 = (uVar9 >> 1 | (uVar10 & 1) << 3) + uVar12 + (uVar1 >> 4);
  uVar4 = (uVar10 >> 1 | (uVar6 & 1) << 3) + (uVar7 & 0xf ^ (uVar2 & 8) >> 3) + (uVar3 >> 4);
  uVar5 = (uVar8 & 0xf) + (uVar6 >> 1) + (uVar11 & 1) * 8 + (uVar4 >> 4);
  return uVar10 << 4 | uVar6 << 8 | uVar1 * 0x1000 & 0xf000 | uVar3 * 0x10000 & 0xf0000 |
         uVar4 * 0x100000 & 0xf00000 | uVar5 * 0x1000000 & 0xf000000 |
         (uVar2 + (uVar11 >> 1) + uVar12 * 8 + (uVar5 >> 4)) * 0x10000000 | uVar9;
}

