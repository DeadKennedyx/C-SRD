; 
(set-info :status unknown)
(declare-fun local_2 () Bool)
(declare-fun local_0 () Bool)
(declare-fun local_1 () Bool)
(assert
 (let (($x21535 (and true local_2)))
(let (($x21494 (and true local_0)))
(let (($x21524 (or (or false (and true local_1)) $x21494)))
(and (distinct (or local_1 local_0 local_2) (or $x21524 $x21535)) true)))))
(check-sat)
