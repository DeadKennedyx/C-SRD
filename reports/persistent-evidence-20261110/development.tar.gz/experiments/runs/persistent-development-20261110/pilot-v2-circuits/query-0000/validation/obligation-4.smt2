; 
(set-info :status unknown)
(declare-fun local_2 () Bool)
(declare-fun local_1 () Bool)
(declare-fun local_0 () Bool)
(assert
 (let (($x21475 (and true local_1)))
(let (($x21496 (or (or false (and true local_0)) $x21475)))
(let (($x21537 (or local_0 local_1 local_2)))
(and (distinct $x21537 (or $x21496 (and true local_2))) true)))))
(check-sat)
