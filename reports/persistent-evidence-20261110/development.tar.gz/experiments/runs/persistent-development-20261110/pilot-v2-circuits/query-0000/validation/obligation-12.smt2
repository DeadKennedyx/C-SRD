; 
(set-info :status unknown)
(declare-fun local_0 () Bool)
(assert
 (let (($x21494 (and true local_0)))
(let (($x21495 (or false $x21494)))
(and (distinct local_0 $x21495) true))))
(check-sat)
