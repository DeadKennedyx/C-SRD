; 
(set-info :status unknown)
(declare-fun local_1 () Bool)
(declare-fun local_0 () Bool)
(assert
 (let (($x21555 (or (or false (and (and true (not local_0)) (not local_1))) (and (and true local_0) local_1))))
(let (($x21556 (= local_0 local_1)))
(and (distinct $x21556 $x21555) true))))
(check-sat)
