; 
(set-info :status unknown)
(declare-fun local_0 () Bool)
(assert
 (let (($x21467 (not local_0)))
(and (distinct $x21467 (or false (and true $x21467))) true)))
(check-sat)
