; 
(set-info :status unknown)
(declare-fun local_0 () Bool)
(declare-fun local_1 () Bool)
(declare-fun local_2 () Bool)
(assert
 (let (($x21494 (and true local_0)))
(let (($x29264 (or (or (or false (and true local_2)) (and true local_1)) $x21494)))
(and (distinct (or local_2 local_1 local_0) $x29264) true))))
(check-sat)
