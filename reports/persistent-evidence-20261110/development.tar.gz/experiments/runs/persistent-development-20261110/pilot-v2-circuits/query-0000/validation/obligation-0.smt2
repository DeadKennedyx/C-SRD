; 
(set-info :status unknown)
(assert
 (let (($x18962 (or false true)))
(and (distinct true $x18962) true)))
(check-sat)
