; 
(set-info :status unknown)
(declare-fun wire_0 () Bool)
(declare-fun output () Bool)
(assert
 (= wire_0 true))
(assert
 (= output wire_0))
(check-sat)
