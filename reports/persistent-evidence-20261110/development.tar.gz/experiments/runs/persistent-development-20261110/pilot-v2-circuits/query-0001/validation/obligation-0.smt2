; 
(set-info :status unknown)
(assert
 (let (($x101 (or false true)))
(and (distinct true $x101) true)))
(check-sat)
