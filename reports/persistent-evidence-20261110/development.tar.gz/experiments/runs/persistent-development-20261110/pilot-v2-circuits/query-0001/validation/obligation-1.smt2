; 
(set-info :status unknown)
(declare-fun local_0 () Bool)
(assert
 (and (distinct local_0 (or false (and true local_0))) true))
(check-sat)
