#include <stdint.h>

extern uint32_t next_value(uint32_t value);
extern void record_event(uint32_t value);

uint32_t region_pipeline(uint32_t *buffer, uint32_t x, int limit)
{
    uint32_t y = buffer[0];
    { _Static_assert((unsigned char)~0u == 255u && sizeof(short)==2 && sizeof(int)==4 && sizeof(long)==8 && sizeof(long long)==8 && (((char)-1 < 0)==1), "C-SRD integer data model mismatch"); unsigned long long csrd_frame_208_0 = ((428335287ULL*((unsigned long long)(x))+2542628964ULL) & 4294967295ULL); (void)csrd_frame_208_0; unsigned long long csrd_frame_208_1 = ((428335287ULL*((unsigned long long)(y))+2542628964ULL) & 4294967295ULL); (void)csrd_frame_208_1; unsigned long long csrd_frame_208_2 = (((csrd_frame_208_0)+(csrd_frame_208_1)-2542628964ULL) & 4294967295ULL); (void)csrd_frame_208_2; unsigned long long csrd_frame_208_3 = ((3ULL*(csrd_frame_208_2)+3504676664ULL) & 4294967295ULL); (void)csrd_frame_208_3; unsigned long long csrd_frame_208_4 = (((csrd_frame_208_3)+(2959349825ULL)-2542628964ULL) & 4294967295ULL); (void)csrd_frame_208_4; unsigned long long csrd_frame_208_5 = ((2171403527ULL*((csrd_frame_208_4)-2542628964ULL)) & 4294967295ULL); (void)csrd_frame_208_5; x = ((unsigned int)(csrd_frame_208_5));
}
    record_event(x);
    if (limit < 0) return x;
    while (limit-- > 0) {
        y = next_value(x);
        { _Static_assert((unsigned char)~0u == 255u && sizeof(short)==2 && sizeof(int)==4 && sizeof(long)==8 && sizeof(long long)==8 && (((char)-1 < 0)==1), "C-SRD integer data model mismatch"); unsigned long long csrd_frame_352_0 = ((1367317615ULL*((unsigned long long)(x))+1250390762ULL) & 4294967295ULL); (void)csrd_frame_352_0; unsigned long long csrd_frame_352_1 = ((1367317615ULL*((unsigned long long)(y))+1250390762ULL) & 4294967295ULL); (void)csrd_frame_352_1; unsigned long long csrd_frame_352_2 = (((csrd_frame_352_0)+(csrd_frame_352_1)-1250390762ULL) & 4294967295ULL); (void)csrd_frame_352_2; unsigned long long csrd_frame_352_3 = ((5ULL*(csrd_frame_352_2)+3588371544ULL) & 4294967295ULL); (void)csrd_frame_352_3; unsigned long long csrd_frame_352_4 = (((csrd_frame_352_3)-(2231679475ULL)+1250390762ULL) & 4294967295ULL); (void)csrd_frame_352_4; unsigned long long csrd_frame_352_5 = ((3662496399ULL*((csrd_frame_352_4)-1250390762ULL)) & 4294967295ULL); (void)csrd_frame_352_5; x = ((unsigned int)(csrd_frame_352_5));
}
        buffer[0] = x;
        record_event(y);
    }
    return x;
}

int region_outputs(uint32_t *buffer, uint32_t x, uint32_t y)
{
    uint32_t pending;
    { _Static_assert((unsigned char)~0u == 255u && sizeof(short)==2 && sizeof(int)==4 && sizeof(long)==8 && sizeof(long long)==8 && (((char)-1 < 0)==1), "C-SRD integer data model mismatch"); unsigned long long csrd_frame_548_0 = ((530885835ULL*((unsigned long long)(x))+1388492207ULL) & 4294967295ULL); (void)csrd_frame_548_0; unsigned long long csrd_frame_548_1 = ((530885835ULL*((unsigned long long)(y))+1388492207ULL) & 4294967295ULL); (void)csrd_frame_548_1; unsigned long long csrd_frame_548_2 = (((1823616810ULL)+(csrd_frame_548_0)-1388492207ULL) & 4294967295ULL); (void)csrd_frame_548_2; unsigned long long csrd_frame_548_3 = ((3ULL*(csrd_frame_548_2)+1517982882ULL) & 4294967295ULL); (void)csrd_frame_548_3; unsigned long long csrd_frame_548_4 = (((csrd_frame_548_3)+(csrd_frame_548_1)-1388492207ULL) & 4294967295ULL); (void)csrd_frame_548_4; unsigned long long csrd_frame_548_5 = (((csrd_frame_548_4)-(csrd_frame_548_2)+1388492207ULL) & 4294967295ULL); (void)csrd_frame_548_5; unsigned long long csrd_frame_548_6 = ((455039203ULL*((csrd_frame_548_2)-1388492207ULL)) & 4294967295ULL); (void)csrd_frame_548_6; unsigned long long csrd_frame_548_7 = ((455039203ULL*((csrd_frame_548_4)-1388492207ULL)) & 4294967295ULL); (void)csrd_frame_548_7; unsigned long long csrd_frame_548_8 = ((455039203ULL*((csrd_frame_548_5)-1388492207ULL)) & 4294967295ULL); (void)csrd_frame_548_8; pending = ((unsigned int)(csrd_frame_548_6)); x = ((unsigned int)(csrd_frame_548_7)); y = ((unsigned int)(csrd_frame_548_8));


}
    record_event(x);
    buffer[0] = y;
    buffer[1] = pending;
    return x == y;
}
