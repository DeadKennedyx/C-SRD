
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

uint region_pipeline(uint *p0,uint p1,int p2)

{
  *p0 = p1 & 0xff;
  p0[1] = 0;
  return p1 & 0xff;
}

