#include <stdint.h>
#include <stdlib.h>
#include <limits.h>
_Static_assert(sizeof(int)==4, "32-bit int ABI required");
extern uint32_t next_value(uint32_t);
extern void record_event(uint32_t);
uint32_t region_pipeline(uint32_t *p0,uint32_t p1,int32_t p2){
    unsigned steps=0, incoming=0;
    (void)p0;(void)p1;(void)p2;(void)incoming;
    uint64_t v0=0; (void)v0;
    uint64_t v3=0; (void)v3;
    uint64_t v5=0; (void)v5;
    uint64_t v7=0; (void)v7;
    uint64_t v9=0; (void)v9;
    uint64_t v11=0; (void)v11;
    uint64_t v13=0; (void)v13;
    uint64_t v15=0; (void)v15;
    uint64_t v17=0; (void)v17;
    uint64_t v19=0; (void)v19;
    uint64_t v21=0; (void)v21;
    uint64_t v23=0; (void)v23;
    uint64_t v25=0; (void)v25;
    uint64_t v27=0; (void)v27;
    uint64_t v29=0; (void)v29;
    uint64_t v31=0; (void)v31;
    uint64_t v33=0; (void)v33;
    uint64_t v35=0; (void)v35;
    uint64_t v37=0; (void)v37;
    uint64_t v39=0; (void)v39;
    uint64_t v41=0; (void)v41;
    uint64_t v43=0; (void)v43;
    uint64_t v45=0; (void)v45;
    uint64_t v47=0; (void)v47;
    uint64_t v49=0; (void)v49;
    uint64_t v51=0; (void)v51;
    uint64_t v53=0; (void)v53;
    uint64_t v56=0; (void)v56;
    uint64_t v58=0; (void)v58;
    uint64_t v60=0; (void)v60;
    uint64_t v61=0; (void)v61;
    uint64_t v62=0; (void)v62;
    uint64_t v63=0; (void)v63;
    uint64_t v65=0; (void)v65;
    uint64_t v67=0; (void)v67;
    uint64_t v69=0; (void)v69;
    uint64_t v70=0; (void)v70;
    uint64_t v72=0; (void)v72;
    uint64_t v74=0; (void)v74;
    uint64_t v76=0; (void)v76;
    uint64_t v78=0; (void)v78;
    uint64_t v80=0; (void)v80;
    uint64_t v82=0; (void)v82;
    uint64_t v85=0; (void)v85;
    uint64_t v86=0; (void)v86;
    uint64_t v88=0; (void)v88;
    uint64_t v90=0; (void)v90;
    uint64_t v91=0; (void)v91;
    uint64_t v92=0; (void)v92;
    uint64_t v93=0; (void)v93;
    uint64_t v95=0; (void)v95;
    uint64_t v97=0; (void)v97;
    uint64_t v99=0; (void)v99;
    uint64_t v100=0; (void)v100;
    uint64_t v102=0; (void)v102;
    uint64_t v104=0; (void)v104;
    uint64_t v106=0; (void)v106;
    uint64_t v108=0; (void)v108;
    uint64_t v110=0; (void)v110;
    uint64_t v112=0; (void)v112;
    uint64_t v115=0; (void)v115;
    uint64_t v116=0; (void)v116;
    uint64_t v118=0; (void)v118;
    uint64_t v120=0; (void)v120;
    uint64_t v121=0; (void)v121;
    uint64_t v123=0; (void)v123;
    uint64_t v125=0; (void)v125;
    uint64_t v127=0; (void)v127;
    uint64_t v129=0; (void)v129;
    uint64_t v131=0; (void)v131;
    uint64_t v133=0; (void)v133;
    uint64_t v134=0; (void)v134;
    uint64_t v135=0; (void)v135;
    uint64_t v137=0; (void)v137;
    uint64_t v139=0; (void)v139;
    uint64_t v141=0; (void)v141;
    uint64_t v143=0; (void)v143;
    uint64_t v145=0; (void)v145;
    uint64_t v147=0; (void)v147;
    uint64_t v149=0; (void)v149;
    uint64_t v151=0; (void)v151;
    uint64_t v153=0; (void)v153;
    uint64_t v155=0; (void)v155;
    uint64_t v157=0; (void)v157;
    uint64_t v160=0; (void)v160;
    uint64_t v162=0; (void)v162;
    uint64_t v163=0; (void)v163;
    uint64_t v165=0; (void)v165;
    uint64_t v167=0; (void)v167;
    uint64_t v168=0; (void)v168;
    uint64_t v170=0; (void)v170;
    uint64_t v172=0; (void)v172;
    uint64_t v174=0; (void)v174;
    uint64_t v175=0; (void)v175;
    uint64_t v177=0; (void)v177;
    uint64_t v178=0; (void)v178;
    uint64_t v180=0; (void)v180;
    uint64_t v182=0; (void)v182;
    uint64_t v184=0; (void)v184;
    uint64_t v186=0; (void)v186;
    uint64_t v188=0; (void)v188;
    uint64_t v190=0; (void)v190;
    uint64_t v192=0; (void)v192;
    uint64_t v194=0; (void)v194;
    uint64_t v197=0; (void)v197;
    uint64_t v198=0; (void)v198;
    uint64_t v200=0; (void)v200;
    uint64_t v202=0; (void)v202;
    uint64_t v204=0; (void)v204;
    uint64_t v207=0; (void)v207;
    uint64_t v209=0; (void)v209;
    uint64_t v211=0; (void)v211;
    uint64_t v213=0; (void)v213;
    uint64_t v215=0; (void)v215;
    uint64_t v217=0; (void)v217;
    uint64_t v219=0; (void)v219;
    uint64_t v222=0; (void)v222;
    uint64_t v224=0; (void)v224;
    uint64_t v226=0; (void)v226;
    uint64_t v228=0; (void)v228;
    uint64_t v230=0; (void)v230;
    uint64_t v232=0; (void)v232;
    uint64_t v234=0; (void)v234;
    uint64_t v236=0; (void)v236;
    uint64_t v238=0; (void)v238;
    uint64_t v240=0; (void)v240;
    uint64_t v242=0; (void)v242;
    uint64_t v245=0; (void)v245;
    uint64_t v247=0; (void)v247;
    uint64_t v249=0; (void)v249;
    uint64_t v250=0; (void)v250;
    uint64_t v251=0; (void)v251;
    uint64_t v252=0; (void)v252;
    uint64_t v255=0; (void)v255;
    uint64_t v257=0; (void)v257;
    uint64_t v259=0; (void)v259;
    uint64_t v260=0; (void)v260;
    uint64_t v261=0; (void)v261;
    uint64_t v262=0; (void)v262;
    uint64_t v264=0; (void)v264;
    uint64_t v265=0; (void)v265;
    uint64_t v268=0; (void)v268;
    uint64_t v269=0; (void)v269;
    uint64_t v271=0; (void)v271;
    uint64_t v273=0; (void)v273;
    uint64_t v274=0; (void)v274;
    uint64_t v275=0; (void)v275;
    uint64_t v276=0; (void)v276;
    uint64_t v278=0; (void)v278;
    uint64_t v279=0; (void)v279;
    uint64_t v280=0; (void)v280;
    uint64_t v282=0; (void)v282;
    uint64_t v283=0; (void)v283;
    uint64_t v285=0; (void)v285;
    uint64_t v287=0; (void)v287;
    uint64_t v290=0; (void)v290;
    uint64_t v292=0; (void)v292;
    uint64_t v294=0; (void)v294;
    uint64_t v296=0; (void)v296;
    uint64_t v297=0; (void)v297;
    uint64_t v298=0; (void)v298;
    uint64_t v300=0; (void)v300;
    uint64_t v302=0; (void)v302;
    uint64_t v304=0; (void)v304;
    uint64_t v306=0; (void)v306;
    uint64_t v308=0; (void)v308;
    uint64_t v309=0; (void)v309;
    uint64_t v311=0; (void)v311;
    uint64_t v313=0; (void)v313;
    uint64_t v315=0; (void)v315;
    uint64_t v316=0; (void)v316;
    uint64_t v214=0; (void)v214;
    uint64_t v216=0; (void)v216;
    uint64_t v324=0; (void)v324;
    uint64_t v212=0; (void)v212;
    uint64_t v329=0; (void)v329;
    uint64_t v331=0; (void)v331;
    uint64_t v332=0; (void)v332;
    uint64_t phi60=0;
    uint64_t phi90=0;
    uint64_t phi120=0;
    uint64_t phi162=0;
    uint64_t phi202=0;
    uint64_t phi211=0;
    uint64_t phi213=0;
    uint64_t phi215=0;
    uint64_t phi249=0;
    uint64_t phi259=0;
    uint64_t phi273=0;
    uint64_t phi296=0;
    uint64_t phi331=0;
    goto b0;
b0:
    if(++steps>10000u)exit(71);
    v0=(p0[0]) & UINT64_C(4294967295);
    v3=(((uint64_t)(uint32_t)p1)) & UINT64_C(18446744073709551615);
    v5=((v3 * UINT64_C(4066321351))) & UINT64_C(18446744073709551615);
    v7=((v5 + UINT64_C(1024304373))) & UINT64_C(18446744073709551615);
    v9=((v7 & UINT64_C(4294967295))) & UINT64_C(18446744073709551615);
    v11=((v0 * UINT64_C(4066321351))) & UINT64_C(4294967295);
    v13=((v11 + UINT64_C(1024304373))) & UINT64_C(4294967295);
    v15=((v7 & UINT64_C(255))) & UINT64_C(18446744073709551615);
    v17=((v13 & UINT64_C(255))) & UINT64_C(4294967295);
    v19=((v9 - UINT64_C(1024304373))) & UINT64_C(18446744073709551615);
    v21=((v19 * UINT64_C(247574007))) & UINT64_C(18446744073709551615);
    v23=((v21 & UINT64_C(4294967295))) & UINT64_C(18446744073709551615);
    v25=((v23 >> 8)) & UINT64_C(18446744073709551615);
    v27=((v25 * UINT64_C(4066321351))) & UINT64_C(18446744073709551615);
    v29=((v27 + UINT64_C(1024304373))) & UINT64_C(18446744073709551615);
    v31=((v29 & UINT64_C(65535))) & UINT64_C(18446744073709551615);
    v33=((v15 - UINT64_C(245))) & UINT64_C(18446744073709551615);
    v35=((v33 * UINT64_C(247))) & UINT64_C(18446744073709551615);
    v37=((v35 & UINT64_C(255))) & UINT64_C(18446744073709551615);
    v39=((v37 * UINT64_C(4066321351))) & UINT64_C(18446744073709551615);
    v41=((v39 + UINT64_C(1024304373))) & UINT64_C(18446744073709551615);
    v43=((v41 & UINT64_C(4294967295))) & UINT64_C(18446744073709551615);
    v45=((v17 - UINT64_C(245))) & UINT64_C(4294967295);
    v47=((v45 * UINT64_C(247))) & UINT64_C(4294967295);
    v49=((v47 & UINT64_C(255))) & UINT64_C(4294967295);
    v51=(v47) & UINT64_C(255);
    v53=((UINT64_C(127) < v49)) & UINT64_C(255);
    if(v53){incoming=0;goto b1;}else{incoming=1;goto b2;}
b1:
    if(++steps>10000u)exit(71);
    v56=((UINT64_C(255) - v51)) & UINT64_C(255);
    v58=(~v56) & UINT64_C(255);
    incoming=0;goto b2;
b2:
    if(++steps>10000u)exit(71);
    switch(incoming){
    case 0:phi60=v58;break;
    case 1:phi60=v51;break;
    default:exit(72);}
    v60=phi60;
    v61=(v60) & UINT64_C(255);
    v62=(((v61 ^ UINT64_C(128)) - UINT64_C(128))) & UINT64_C(18446744073709551615);
    v63=((v62 * UINT64_C(4066321351))) & UINT64_C(18446744073709551615);
    v65=((v63 + UINT64_C(1024304373))) & UINT64_C(18446744073709551615);
    v67=((v65 & UINT64_C(4294967295))) & UINT64_C(18446744073709551615);
    v69=((v43 + v67)) & UINT64_C(18446744073709551615);
    v70=((v69 - UINT64_C(1024304373))) & UINT64_C(18446744073709551615);
    v72=((v70 & UINT64_C(4294967295))) & UINT64_C(18446744073709551615);
    v74=((v31 - UINT64_C(42229))) & UINT64_C(18446744073709551615);
    v76=((v74 * UINT64_C(44535))) & UINT64_C(18446744073709551615);
    v78=((v76 & UINT64_C(65535))) & UINT64_C(18446744073709551615);
    v80=(v76) & UINT64_C(65535);
    v82=((UINT64_C(32767) < v78)) & UINT64_C(255);
    if(v82){incoming=0;goto b3;}else{incoming=1;goto b4;}
b3:
    if(++steps>10000u)exit(71);
    v85=((UINT64_C(0) - v80)) & UINT64_C(65535);
    v86=((v85 - UINT64_C(1))) & UINT64_C(65535);
    v88=(~v86) & UINT64_C(65535);
    incoming=0;goto b4;
b4:
    if(++steps>10000u)exit(71);
    switch(incoming){
    case 0:phi90=v88;break;
    case 1:phi90=v80;break;
    default:exit(72);}
    v90=phi90;
    v91=(v90) & UINT64_C(65535);
    v92=(((v91 ^ UINT64_C(32768)) - UINT64_C(32768))) & UINT64_C(18446744073709551615);
    v93=((v92 * UINT64_C(4066321351))) & UINT64_C(18446744073709551615);
    v95=((v93 + UINT64_C(1024304373))) & UINT64_C(18446744073709551615);
    v97=((v95 & UINT64_C(4294967295))) & UINT64_C(18446744073709551615);
    v99=((v72 + v97)) & UINT64_C(18446744073709551615);
    v100=((v99 - UINT64_C(1024304373))) & UINT64_C(18446744073709551615);
    v102=((v100 & UINT64_C(4294967295))) & UINT64_C(18446744073709551615);
    v104=((v102 - UINT64_C(1024304373))) & UINT64_C(18446744073709551615);
    v106=((v104 * UINT64_C(247574007))) & UINT64_C(18446744073709551615);
    v108=((v106 & UINT64_C(4294967295))) & UINT64_C(18446744073709551615);
    v110=(v106) & UINT64_C(4294967295);
    v112=((UINT64_C(2147483647) < v108)) & UINT64_C(255);
    if(v112){incoming=0;goto b5;}else{incoming=1;goto b6;}
b5:
    if(++steps>10000u)exit(71);
    v115=((UINT64_C(0) - v110)) & UINT64_C(4294967295);
    v116=((v115 - UINT64_C(1))) & UINT64_C(4294967295);
    v118=(~v116) & UINT64_C(4294967295);
    incoming=0;goto b6;
b6:
    if(++steps>10000u)exit(71);
    switch(incoming){
    case 0:phi120=v118;break;
    case 1:phi120=v110;break;
    default:exit(72);}
    v120=phi120;
    v121=((v120 * UINT64_C(4066321351))) & UINT64_C(4294967295);
    v123=((v121 + UINT64_C(1024304373))) & UINT64_C(4294967295);
    v125=((v123 * UINT64_C(3))) & UINT64_C(4294967295);
    v127=((v9 - UINT64_C(1024304373))) & UINT64_C(18446744073709551615);
    v129=((v127 * UINT64_C(247574007))) & UINT64_C(18446744073709551615);
    v131=((v129 << 32)) & UINT64_C(18446744073709551615);
    v133=(v0) & UINT64_C(18446744073709551615);
    v134=((v131 | v133)) & UINT64_C(18446744073709551615);
    v135=((v134 * UINT64_C(980129743084921799))) & UINT64_C(18446744073709551615);
    v137=((v135 + UINT64_C(17423517740513993973))) & UINT64_C(18446744073709551615);
    v139=((v137 * UINT64_C(7))) & UINT64_C(18446744073709551615);
    v141=((v102 - UINT64_C(1024304373))) & UINT64_C(18446744073709551615);
    v143=((v141 * UINT64_C(247574007))) & UINT64_C(18446744073709551615);
    v145=((v143 & UINT64_C(4294967295))) & UINT64_C(18446744073709551615);
    v147=((v145 ^ UINT64_C(2147483648))) & UINT64_C(18446744073709551615);
    v149=((UINT64_C(2147483647) < v147)) & UINT64_C(255);
    v151=((v102 * UINT64_C(4294967295))) & UINT64_C(18446744073709551615);
    v153=((v151 + UINT64_C(2048608746))) & UINT64_C(18446744073709551615);
    v155=((v153 & UINT64_C(4294967295))) & UINT64_C(18446744073709551615);
    v157=((v149 != UINT64_C(255))) & UINT64_C(255);
    if(v157){incoming=0;goto b7;}else{incoming=1;goto b8;}
b7:
    if(++steps>10000u)exit(71);
    v160=(v155) & UINT64_C(18446744073709551615);
    incoming=0;goto b8;
b8:
    if(++steps>10000u)exit(71);
    switch(incoming){
    case 0:phi162=v160;break;
    case 1:phi162=v102;break;
    default:exit(72);}
    v162=phi162;
    v163=((v139 + UINT64_C(1165353285412689853))) & UINT64_C(18446744073709551615);
    v165=((v163 * UINT64_C(12356580284743921143))) & UINT64_C(18446744073709551615);
    v167=(v165) & UINT64_C(18446744073709551615);
    v168=((v167 >> 32)) & UINT64_C(18446744073709551615);
    v170=(v168) & UINT64_C(4294967295);
    v172=((v170 * UINT64_C(4066321351))) & UINT64_C(4294967295);
    v174=((v172 + v125)) & UINT64_C(4294967295);
    v175=(v162) & UINT64_C(4294967295);
    v177=((v174 + v175)) & UINT64_C(4294967295);
    v178=((v139 + UINT64_C(1165353285412689853))) & UINT64_C(18446744073709551615);
    v180=((v178 * UINT64_C(12356580284743921143))) & UINT64_C(18446744073709551615);
    v182=((v162 - UINT64_C(1024304373))) & UINT64_C(18446744073709551615);
    v184=((v182 * UINT64_C(247574007))) & UINT64_C(18446744073709551615);
    v186=((v184 & UINT64_C(4294967295))) & UINT64_C(18446744073709551615);
    v188=(v184) & UINT64_C(4294967295);
    v190=((v177 + UINT64_C(1112333584))) & UINT64_C(4294967295);
    v192=((v190 * UINT64_C(247574007))) & UINT64_C(4294967295);
    v194=((UINT64_C(2147483647) < v186)) & UINT64_C(255);
    if(v194){incoming=0;goto b9;}else{incoming=1;goto b10;}
b9:
    if(++steps>10000u)exit(71);
    v197=((UINT64_C(0) - v188)) & UINT64_C(4294967295);
    v198=((v197 - UINT64_C(1))) & UINT64_C(4294967295);
    v200=(~v198) & UINT64_C(4294967295);
    incoming=0;goto b10;
b10:
    if(++steps>10000u)exit(71);
    switch(incoming){
    case 0:phi202=v200;break;
    case 1:phi202=v188;break;
    default:exit(72);}
    v202=phi202;
    record_event((uint32_t)(v192));
    v204=(((((uint64_t)(uint32_t)p2) ^ UINT64_C(2147483648)) < (UINT64_C(0) ^ UINT64_C(2147483648)))) & UINT64_C(255);
    v207=(((uint64_t)(uint32_t)p2)) & UINT64_C(4294967295);
    if(v204){incoming=0;goto b11;}else{incoming=1;goto b12;}
b11:
    if(++steps>10000u)exit(71);
    v209=(v192) & UINT64_C(4294967295);
    incoming=0;goto b23;
b12:
    if(++steps>10000u)exit(71);
    switch(incoming){
    case 0:phi211=v212;break;
    case 1:phi211=v207;break;
    default:exit(72);}
    switch(incoming){
    case 0:phi213=v214;break;
    case 1:phi213=v180;break;
    default:exit(72);}
    switch(incoming){
    case 0:phi215=v216;break;
    case 1:phi215=v192;break;
    default:exit(72);}
    v211=phi211;
    v213=phi213;
    v215=phi215;
    v217=((v211 + UINT64_C(4294967295))) & UINT64_C(4294967295);
    v219=(((UINT64_C(0) ^ UINT64_C(2147483648)) < (v211 ^ UINT64_C(2147483648)))) & UINT64_C(255);
    if(v219){incoming=0;goto b13;}else{incoming=0;goto b22;}
b13:
    if(++steps>10000u)exit(71);
    v222=(next_value((uint32_t)(v215))) & UINT64_C(4294967295);
    v224=((v222 * UINT64_C(4197008313))) & UINT64_C(4294967295);
    v226=((v224 + UINT64_C(2378020909))) & UINT64_C(4294967295);
    v228=((v213 * UINT64_C(15348229523815089081))) & UINT64_C(18446744073709551615);
    v230=((v228 + UINT64_C(482742558238029869))) & UINT64_C(18446744073709551615);
    v232=((v226 & UINT64_C(255))) & UINT64_C(4294967295);
    v234=((v232 - UINT64_C(45))) & UINT64_C(4294967295);
    v236=((v234 * UINT64_C(137))) & UINT64_C(4294967295);
    v238=((v236 & UINT64_C(255))) & UINT64_C(4294967295);
    v240=(v236) & UINT64_C(255);
    v242=((UINT64_C(127) < v238)) & UINT64_C(255);
    if(v242){incoming=0;goto b14;}else{incoming=1;goto b15;}
b14:
    if(++steps>10000u)exit(71);
    v245=((UINT64_C(255) - v240)) & UINT64_C(255);
    v247=(~v245) & UINT64_C(255);
    incoming=0;goto b15;
b15:
    if(++steps>10000u)exit(71);
    switch(incoming){
    case 0:phi249=v247;break;
    case 1:phi249=v240;break;
    default:exit(72);}
    v249=phi249;
    v250=(v249) & UINT64_C(255);
    v251=(((v250 ^ UINT64_C(128)) - UINT64_C(128))) & UINT64_C(4294967295);
    v252=((UINT64_C(2147483647) < v251)) & UINT64_C(255);
    if(v252){incoming=0;goto b16;}else{incoming=1;goto b17;}
b16:
    if(++steps>10000u)exit(71);
    v255=((UINT64_C(4294967295) - v251)) & UINT64_C(4294967295);
    v257=(~v255) & UINT64_C(4294967295);
    incoming=0;goto b17;
b17:
    if(++steps>10000u)exit(71);
    switch(incoming){
    case 0:phi259=v257;break;
    case 1:phi259=v251;break;
    default:exit(72);}
    v259=phi259;
    v260=(v259) & UINT64_C(4294967295);
    v261=(((v260 ^ UINT64_C(2147483648)) - UINT64_C(2147483648))) & UINT64_C(18446744073709551615);
    v262=((v261 * UINT64_C(15348229523815089081))) & UINT64_C(18446744073709551615);
    v264=(v202) & UINT64_C(4294967295);
    v265=((UINT64_C(2147483647) < v202)) & UINT64_C(255);
    if(v265){incoming=0;goto b18;}else{incoming=1;goto b19;}
b18:
    if(++steps>10000u)exit(71);
    v268=((UINT64_C(0) - v202)) & UINT64_C(4294967295);
    v269=((v268 - UINT64_C(1))) & UINT64_C(4294967295);
    v271=(~v269) & UINT64_C(4294967295);
    incoming=0;goto b19;
b19:
    if(++steps>10000u)exit(71);
    switch(incoming){
    case 0:phi273=v271;break;
    case 1:phi273=v264;break;
    default:exit(72);}
    v273=phi273;
    v274=(v273) & UINT64_C(4294967295);
    v275=(((v274 ^ UINT64_C(2147483648)) - UINT64_C(2147483648))) & UINT64_C(18446744073709551615);
    v276=((v275 * UINT64_C(15348229523815089081))) & UINT64_C(18446744073709551615);
    v278=((v262 + v276)) & UINT64_C(18446744073709551615);
    v279=(v222) & UINT64_C(18446744073709551615);
    v280=((v279 * UINT64_C(13465187096204541952))) & UINT64_C(18446744073709551615);
    v282=((v230 + v280)) & UINT64_C(18446744073709551615);
    v283=((v282 * UINT64_C(3))) & UINT64_C(18446744073709551615);
    v285=((v278 * UINT64_C(2024918909064696457))) & UINT64_C(18446744073709551615);
    v287=((UINT64_C(9223372036854775807) < v285)) & UINT64_C(255);
    if(v287){incoming=0;goto b20;}else{incoming=1;goto b21;}
b20:
    if(++steps>10000u)exit(71);
    v290=((v278 * UINT64_C(16421825164644855159))) & UINT64_C(18446744073709551615);
    v292=((v290 - UINT64_C(1))) & UINT64_C(18446744073709551615);
    v294=(~v292) & UINT64_C(18446744073709551615);
    incoming=0;goto b21;
b21:
    if(++steps>10000u)exit(71);
    switch(incoming){
    case 0:phi296=v294;break;
    case 1:phi296=v285;break;
    default:exit(72);}
    v296=phi296;
    v297=(v296) & UINT64_C(18446744073709551615);
    v298=(((v297 >> 2) | ((UINT64_C(0) - (v297 >> 63)) << 62))) & UINT64_C(18446744073709551615);
    v300=(v298) & UINT64_C(4294967295);
    v302=((v300 * UINT64_C(4197008313))) & UINT64_C(4294967295);
    v304=((v283 + UINT64_C(1361600423865925740))) & UINT64_C(18446744073709551615);
    v306=((v304 * UINT64_C(2024918909064696457))) & UINT64_C(18446744073709551615);
    v308=(v306) & UINT64_C(18446744073709551615);
    v309=((v308 >> 32)) & UINT64_C(18446744073709551615);
    v311=(v309) & UINT64_C(4294967295);
    v313=((v311 * UINT64_C(4197008313))) & UINT64_C(4294967295);
    v315=((v313 + v302)) & UINT64_C(4294967295);
    v316=((v283 + UINT64_C(1361600423865925740))) & UINT64_C(18446744073709551615);
    v214=((v316 * UINT64_C(2024918909064696457))) & UINT64_C(18446744073709551615);
    v216=((v315 * UINT64_C(4056273545))) & UINT64_C(4294967295);
    p0[0]=(uint32_t)(v216);
    v324=(v214) & UINT64_C(4294967295);
    p0[2]=(uint32_t)(v324);
    record_event((uint32_t)(v222));
    v212=(v217) & UINT64_C(4294967295);
    incoming=0;goto b12;
b22:
    if(++steps>10000u)exit(71);
    v329=(v215) & UINT64_C(4294967295);
    incoming=1;goto b23;
b23:
    if(++steps>10000u)exit(71);
    switch(incoming){
    case 0:phi331=v209;break;
    case 1:phi331=v329;break;
    default:exit(72);}
    v331=phi331;
    v332=(v331) & UINT64_C(4294967295);
    return (uint32_t)(v332);
}
