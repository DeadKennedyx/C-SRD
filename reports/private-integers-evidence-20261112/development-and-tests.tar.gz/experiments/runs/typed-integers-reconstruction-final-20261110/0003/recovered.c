#include <stdint.h>
#include <stdlib.h>
#include <limits.h>
_Static_assert(sizeof(int)==4, "32-bit int ABI required");
extern uint32_t next_value(uint32_t);
extern void record_event(uint32_t);
uint32_t region_pipeline(uint32_t *p0,uint32_t p1,int32_t p2){
    unsigned steps=0, incoming=0;
    (void)p0;(void)p1;(void)p2;(void)incoming;
    uint64_t v0=0; (void)v0;
    uint64_t v3=0; (void)v3;
    uint64_t v6=0; (void)v6;
    uint64_t v8=0; (void)v8;
    uint64_t v10=0; (void)v10;
    uint64_t v12=0; (void)v12;
    uint64_t v13=0; (void)v13;
    uint64_t v14=0; (void)v14;
    uint64_t v15=0; (void)v15;
    uint64_t v17=0; (void)v17;
    uint64_t v19=0; (void)v19;
    uint64_t v20=0; (void)v20;
    uint64_t v22=0; (void)v22;
    uint64_t v24=0; (void)v24;
    uint64_t v27=0; (void)v27;
    uint64_t v29=0; (void)v29;
    uint64_t v30=0; (void)v30;
    uint64_t v31=0; (void)v31;
    uint64_t v33=0; (void)v33;
    uint64_t v35=0; (void)v35;
    uint64_t v36=0; (void)v36;
    uint64_t v38=0; (void)v38;
    uint64_t v41=0; (void)v41;
    uint64_t v43=0; (void)v43;
    uint64_t v45=0; (void)v45;
    uint64_t v47=0; (void)v47;
    uint64_t v49=0; (void)v49;
    uint64_t v51=0; (void)v51;
    uint64_t v53=0; (void)v53;
    uint64_t v56=0; (void)v56;
    uint64_t v58=0; (void)v58;
    uint64_t v60=0; (void)v60;
    uint64_t v61=0; (void)v61;
    uint64_t v62=0; (void)v62;
    uint64_t v63=0; (void)v63;
    uint64_t v64=0; (void)v64;
    uint64_t v65=0; (void)v65;
    uint64_t v67=0; (void)v67;
    uint64_t v68=0; (void)v68;
    uint64_t v48=0; (void)v48;
    uint64_t v71=0; (void)v71;
    uint64_t v73=0; (void)v73;
    uint64_t v75=0; (void)v75;
    uint64_t v76=0; (void)v76;
    uint64_t v78=0; (void)v78;
    uint64_t v50=0; (void)v50;
    uint64_t v84=0; (void)v84;
    uint64_t v46=0; (void)v46;
    uint64_t v89=0; (void)v89;
    uint64_t v91=0; (void)v91;
    uint64_t v92=0; (void)v92;
    uint64_t phi29=0;
    uint64_t phi45=0;
    uint64_t phi47=0;
    uint64_t phi49=0;
    uint64_t phi91=0;
    goto b0;
b0:
    if(++steps>10000u)exit(71);
    v0=(p0[0]) & UINT64_C(4294967295);
    v3=((((uint64_t)(uint32_t)p1) >> 8)) & UINT64_C(4294967295);
    v6=(v3) & UINT64_C(65535);
    v8=((v0 & UINT64_C(255))) & UINT64_C(4294967295);
    v10=((((uint64_t)(uint32_t)p1) & UINT64_C(255))) & UINT64_C(4294967295);
    v12=((v10 + v8)) & UINT64_C(4294967295);
    v13=(((v6 ^ UINT64_C(32768)) - UINT64_C(32768))) & UINT64_C(4294967295);
    v14=((v12 + v13)) & UINT64_C(4294967295);
    v15=((v14 * UINT64_C(3))) & UINT64_C(4294967295);
    v17=((v15 + UINT64_C(4294967292))) & UINT64_C(4294967295);
    v19=(((((uint64_t)(uint32_t)p1) << 32) | v0)) & UINT64_C(18446744073709551615);
    v20=((v19 * UINT64_C(7))) & UINT64_C(18446744073709551615);
    v22=((v20 + UINT64_C(18364758544493064720))) & UINT64_C(18446744073709551615);
    v24=(((v14 ^ UINT64_C(2147483648)) < (UINT64_C(0) ^ UINT64_C(2147483648)))) & UINT64_C(255);
    if(v24){incoming=0;goto b1;}else{incoming=1;goto b2;}
b1:
    if(++steps>10000u)exit(71);
    v27=((UINT64_C(0) - v14)) & UINT64_C(4294967295);
    incoming=0;goto b2;
b2:
    if(++steps>10000u)exit(71);
    switch(incoming){
    case 0:phi29=v27;break;
    case 1:phi29=v14;break;
    default:exit(72);}
    v29=phi29;
    v30=(v22) & UINT64_C(18446744073709551615);
    v31=((v30 >> 32)) & UINT64_C(18446744073709551615);
    v33=(v31) & UINT64_C(4294967295);
    v35=((v33 + v17)) & UINT64_C(4294967295);
    v36=((v35 + v29)) & UINT64_C(4294967295);
    record_event((uint32_t)(v36));
    v38=(((((uint64_t)(uint32_t)p2) ^ UINT64_C(2147483648)) < (UINT64_C(0) ^ UINT64_C(2147483648)))) & UINT64_C(255);
    v41=(((uint64_t)(uint32_t)p2)) & UINT64_C(4294967295);
    if(v38){incoming=0;goto b3;}else{incoming=1;goto b4;}
b3:
    if(++steps>10000u)exit(71);
    v43=(v36) & UINT64_C(4294967295);
    incoming=0;goto b7;
b4:
    if(++steps>10000u)exit(71);
    switch(incoming){
    case 0:phi45=v46;break;
    case 1:phi45=v41;break;
    default:exit(72);}
    switch(incoming){
    case 0:phi47=v48;break;
    case 1:phi47=v22;break;
    default:exit(72);}
    switch(incoming){
    case 0:phi49=v50;break;
    case 1:phi49=v36;break;
    default:exit(72);}
    v45=phi45;
    v47=phi47;
    v49=phi49;
    v51=((v45 + UINT64_C(4294967295))) & UINT64_C(4294967295);
    v53=(((UINT64_C(0) ^ UINT64_C(2147483648)) < (v45 ^ UINT64_C(2147483648)))) & UINT64_C(255);
    if(v53){incoming=0;goto b5;}else{incoming=0;goto b6;}
b5:
    if(++steps>10000u)exit(71);
    v56=(next_value((uint32_t)(v49))) & UINT64_C(4294967295);
    v58=(v56) & UINT64_C(255);
    v60=(((v58 ^ UINT64_C(128)) - UINT64_C(128))) & UINT64_C(4294967295);
    v61=(((v60 ^ UINT64_C(2147483648)) - UINT64_C(2147483648))) & UINT64_C(18446744073709551615);
    v62=(((v29 ^ UINT64_C(2147483648)) - UINT64_C(2147483648))) & UINT64_C(18446744073709551615);
    v63=((v61 + v62)) & UINT64_C(18446744073709551615);
    v64=(v56) & UINT64_C(18446744073709551615);
    v65=((v64 * UINT64_C(131072))) & UINT64_C(18446744073709551615);
    v67=((v47 + v65)) & UINT64_C(18446744073709551615);
    v68=((v67 * UINT64_C(3))) & UINT64_C(18446744073709551615);
    v48=((v68 + UINT64_C(11))) & UINT64_C(18446744073709551615);
    v71=(((v63 >> 2) | ((UINT64_C(0) - (v63 >> 63)) << 62))) & UINT64_C(18446744073709551615);
    v73=(v71) & UINT64_C(4294967295);
    v75=(v48) & UINT64_C(18446744073709551615);
    v76=((v75 >> 32)) & UINT64_C(18446744073709551615);
    v78=(v76) & UINT64_C(4294967295);
    v50=((v78 + v73)) & UINT64_C(4294967295);
    p0[0]=(uint32_t)(v50);
    v84=(v48) & UINT64_C(4294967295);
    p0[2]=(uint32_t)(v84);
    record_event((uint32_t)(v56));
    v46=(v51) & UINT64_C(4294967295);
    incoming=0;goto b4;
b6:
    if(++steps>10000u)exit(71);
    v89=(v49) & UINT64_C(4294967295);
    incoming=1;goto b7;
b7:
    if(++steps>10000u)exit(71);
    switch(incoming){
    case 0:phi91=v43;break;
    case 1:phi91=v89;break;
    default:exit(72);}
    v91=phi91;
    v92=(v91) & UINT64_C(4294967295);
    return (uint32_t)(v92);
}
