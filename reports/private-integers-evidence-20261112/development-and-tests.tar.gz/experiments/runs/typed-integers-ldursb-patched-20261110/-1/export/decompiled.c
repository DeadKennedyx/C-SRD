
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

uint region_pipeline(uint *p0,uint p1,int p2)

{
  *p0 = (int)(char)p1;
  p0[1] = 0;
  return (int)(char)p1;
}

