#include <stdint.h>
#include <stdlib.h>
#include <limits.h>
_Static_assert(sizeof(int)==4, "32-bit int ABI required");
extern uint32_t next_value(uint32_t);
extern void record_event(uint32_t);
uint32_t region_pipeline(uint32_t *p0,uint32_t p1,int32_t p2){
    unsigned steps=0, incoming=0;
    (void)p0;(void)p1;(void)p2;(void)incoming;
    uint64_t v0=0; (void)v0;
    uint64_t v3=0; (void)v3;
    uint64_t v11=0; (void)v11;
    goto b0;
b0:
    if(++steps>10000u)exit(71);
    v0=(((uint64_t)(uint32_t)p1)) & UINT64_C(255);
    v3=(((v0 ^ UINT64_C(128)) - UINT64_C(128))) & UINT64_C(4294967295);
    p0[0]=(uint32_t)(v3);
    p0[1]=(uint32_t)(UINT64_C(0));
    v11=(v3) & UINT64_C(4294967295);
    return (uint32_t)(v11);
}
