python
import sys
sys.path.insert(0,'/work/tools')
import gdb_region_trace
gdb_region_trace.main('/work/experiments/runs/typed-integers-runtime-20261112/0012/8.config.json')
end
