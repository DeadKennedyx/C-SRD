#include <stdint.h>
#include <stdlib.h>
#include <limits.h>
_Static_assert(sizeof(int)==4, "32-bit int ABI required");
extern uint32_t next_value(uint32_t);
extern void record_event(uint32_t);
int32_t region_outputs(uint32_t *p0,uint32_t p1,uint32_t p2){
    unsigned steps=0, incoming=0;
    (void)p0;(void)p1;(void)p2;(void)incoming;
    uint64_t v0=0; (void)v0;
    uint64_t v3=0; (void)v3;
    uint64_t v4=0; (void)v4;
    uint64_t v6=0; (void)v6;
    uint64_t v8=0; (void)v8;
    uint64_t v10=0; (void)v10;
    uint64_t v12=0; (void)v12;
    uint64_t v13=0; (void)v13;
    uint64_t v15=0; (void)v15;
    uint64_t v16=0; (void)v16;
    uint64_t v17=0; (void)v17;
    uint64_t v19=0; (void)v19;
    uint64_t v20=0; (void)v20;
    uint64_t v22=0; (void)v22;
    uint64_t v23=0; (void)v23;
    uint64_t v25=0; (void)v25;
    uint64_t v27=0; (void)v27;
    uint64_t v28=0; (void)v28;
    uint64_t v30=0; (void)v30;
    uint64_t v32=0; (void)v32;
    uint64_t v33=0; (void)v33;
    uint64_t v35=0; (void)v35;
    uint64_t v36=0; (void)v36;
    uint64_t v43=0; (void)v43;
    uint64_t v48=0; (void)v48;
    uint64_t v50=0; (void)v50;
    uint64_t phi32=0;
    goto b0;
b0:
    if(++steps>10000u)exit(71);
    v0=(((uint64_t)(uint32_t)p1)) & UINT64_C(255);
    v3=(((v0 ^ UINT64_C(128)) - UINT64_C(128))) & UINT64_C(4294967295);
    v4=(((uint64_t)(uint32_t)p2)) & UINT64_C(18446744073709551615);
    v6=((((uint64_t)(uint32_t)p2) & UINT64_C(65535))) & UINT64_C(4294967295);
    v8=((v4 << 48)) & UINT64_C(18446744073709551615);
    v10=(((uint64_t)(uint32_t)p2)) & UINT64_C(65535);
    v12=((v3 + ((uint64_t)(uint32_t)p1))) & UINT64_C(4294967295);
    v13=((v6 + UINT64_C(9))) & UINT64_C(4294967295);
    v15=(v6) & UINT64_C(4294967295);
    v16=(((v3 ^ UINT64_C(2147483648)) < (v15 ^ UINT64_C(2147483648)))) & UINT64_C(255);
    v17=((((uint64_t)(uint32_t)p1) & UINT64_C(255))) & UINT64_C(4294967295);
    v19=((v6 + v17)) & UINT64_C(4294967295);
    v20=((v19 != UINT64_C(0))) & UINT64_C(255);
    v22=(v8) & UINT64_C(18446744073709551615);
    v23=(((v22 >> 51) | ((UINT64_C(0) - (v22 >> 63)) << 13))) & UINT64_C(18446744073709551615);
    v25=(v23) & UINT64_C(4294967295);
    v27=((v25 + v12)) & UINT64_C(4294967295);
    v28=(v16) & UINT64_C(4294967295);
    if(v20){incoming=0;goto b1;}else{incoming=0;goto b2;}
b1:
    if(++steps>10000u)exit(71);
    v30=((v28 + UINT64_C(1))) & UINT64_C(4294967295);
    incoming=1;goto b2;
b2:
    if(++steps>10000u)exit(71);
    switch(incoming){
    case 0:phi32=v28;break;
    case 1:phi32=v30;break;
    default:exit(72);}
    v32=phi32;
    v33=((v32 + v27)) & UINT64_C(4294967295);
    record_event((uint32_t)(v33));
    v35=((v20 != v16)) & UINT64_C(255);
    v36=(v35) & UINT64_C(4294967295);
    p0[0]=(uint32_t)(v13);
    p0[1]=(uint32_t)(v33);
    v43=((v36 ^ UINT64_C(1))) & UINT64_C(4294967295);
    v48=(((v10 ^ UINT64_C(32768)) - UINT64_C(32768))) & UINT64_C(4294967295);
    p0[2]=(uint32_t)(v48);
    v50=(v43) & UINT64_C(4294967295);
    {uint32_t r=(uint32_t)(v50);
    return r<=INT32_MAX?(int32_t)r:INT32_MIN+(int32_t)(r-UINT32_C(2147483648));}
}
