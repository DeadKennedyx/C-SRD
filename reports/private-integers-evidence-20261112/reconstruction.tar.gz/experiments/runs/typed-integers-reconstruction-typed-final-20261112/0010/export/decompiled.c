
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int region_outputs(uint *p0,uint p1,uint p2)

{
  uint uVar1;
  int iVar2;
  bool bVar3;
  uint uVar4;
  
  iVar2 = (int)(char)p1;
  uVar1 = p2 & 0xffff;
  bVar3 = uVar1 + (p1 & 0xff) != 0;
  uVar4 = (uint)(iVar2 < (int)uVar1);
  if (bVar3) {
    uVar4 = uVar4 + 1;
  }
  uVar4 = uVar4 + (int)((long)((ulong)p2 << 0x30) >> 0x33) + iVar2 + p1;
  record_event(uVar4);
  *p0 = uVar1 + 9;
  p0[1] = uVar4;
  p0[2] = (int)(short)p2;
  return bVar3 != iVar2 < (int)uVar1 ^ 1;
}

