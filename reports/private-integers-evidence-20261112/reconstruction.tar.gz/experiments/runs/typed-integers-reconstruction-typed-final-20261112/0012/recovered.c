#include <stdint.h>
#include <stdlib.h>
#include <limits.h>
_Static_assert(sizeof(int)==4, "32-bit int ABI required");
extern uint32_t next_value(uint32_t);
extern void record_event(uint32_t);
uint32_t region_pipeline(uint32_t *p0,uint32_t p1,int32_t p2){
    unsigned steps=0, incoming=0;
    (void)p0;(void)p1;(void)p2;(void)incoming;
    uint64_t v0=0; (void)v0;
    uint64_t v2=0; (void)v2;
    uint64_t v4=0; (void)v4;
    uint64_t v6=0; (void)v6;
    uint64_t v9=0; (void)v9;
    uint64_t v10=0; (void)v10;
    uint64_t v12=0; (void)v12;
    uint64_t v14=0; (void)v14;
    uint64_t v16=0; (void)v16;
    uint64_t v18=0; (void)v18;
    uint64_t v20=0; (void)v20;
    uint64_t v22=0; (void)v22;
    uint64_t v24=0; (void)v24;
    uint64_t v26=0; (void)v26;
    uint64_t v28=0; (void)v28;
    uint64_t v30=0; (void)v30;
    uint64_t v32=0; (void)v32;
    uint64_t v34=0; (void)v34;
    uint64_t v36=0; (void)v36;
    uint64_t v38=0; (void)v38;
    uint64_t v39=0; (void)v39;
    uint64_t v40=0; (void)v40;
    uint64_t v41=0; (void)v41;
    uint64_t v42=0; (void)v42;
    uint64_t v44=0; (void)v44;
    uint64_t v45=0; (void)v45;
    uint64_t v47=0; (void)v47;
    uint64_t v49=0; (void)v49;
    uint64_t v51=0; (void)v51;
    uint64_t v52=0; (void)v52;
    uint64_t v54=0; (void)v54;
    uint64_t v56=0; (void)v56;
    uint64_t v58=0; (void)v58;
    uint64_t v60=0; (void)v60;
    uint64_t v62=0; (void)v62;
    uint64_t v64=0; (void)v64;
    uint64_t v66=0; (void)v66;
    uint64_t v67=0; (void)v67;
    uint64_t v69=0; (void)v69;
    uint64_t v71=0; (void)v71;
    uint64_t v73=0; (void)v73;
    uint64_t v74=0; (void)v74;
    uint64_t v76=0; (void)v76;
    uint64_t v78=0; (void)v78;
    uint64_t v79=0; (void)v79;
    uint64_t v80=0; (void)v80;
    uint64_t v82=0; (void)v82;
    uint64_t v83=0; (void)v83;
    uint64_t v85=0; (void)v85;
    uint64_t v88=0; (void)v88;
    uint64_t v92=0; (void)v92;
    uint64_t v94=0; (void)v94;
    uint64_t v96=0; (void)v96;
    uint64_t v98=0; (void)v98;
    uint64_t v100=0; (void)v100;
    uint64_t v102=0; (void)v102;
    uint64_t v104=0; (void)v104;
    uint64_t v106=0; (void)v106;
    uint64_t v108=0; (void)v108;
    uint64_t v109=0; (void)v109;
    uint64_t v111=0; (void)v111;
    uint64_t v113=0; (void)v113;
    uint64_t v115=0; (void)v115;
    uint64_t v117=0; (void)v117;
    uint64_t v119=0; (void)v119;
    uint64_t v121=0; (void)v121;
    uint64_t v123=0; (void)v123;
    uint64_t v124=0; (void)v124;
    uint64_t v126=0; (void)v126;
    uint64_t v128=0; (void)v128;
    uint64_t v101=0; (void)v101;
    uint64_t v130=0; (void)v130;
    uint64_t v131=0; (void)v131;
    uint64_t v136=0; (void)v136;
    uint64_t v139=0; (void)v139;
    uint64_t v141=0; (void)v141;
    uint64_t v142=0; (void)v142;
    uint64_t v144=0; (void)v144;
    uint64_t v105=0; (void)v105;
    uint64_t v103=0; (void)v103;
    uint64_t v149=0; (void)v149;
    uint64_t v152=0; (void)v152;
    uint64_t v153=0; (void)v153;
    uint64_t phi79=0;
    uint64_t phi100=0;
    uint64_t phi102=0;
    uint64_t phi104=0;
    uint64_t phi152=0;
    goto b0;
b0:
    if(++steps>10000u)exit(71);
    v0=(((uint64_t)(uint32_t)p1)) & UINT64_C(18446744073709551615);
    v2=((v0 * UINT64_C(4066321351))) & UINT64_C(18446744073709551615);
    v4=((v2 + UINT64_C(1024304373))) & UINT64_C(18446744073709551615);
    v6=(p0[0]) & UINT64_C(4294967295);
    v9=(v6) & UINT64_C(18446744073709551615);
    v10=((v9 * UINT64_C(4066321351))) & UINT64_C(18446744073709551615);
    v12=((v10 + UINT64_C(1024304373))) & UINT64_C(18446744073709551615);
    v14=((v4 * UINT64_C(247574007))) & UINT64_C(18446744073709551615);
    v16=((v14 + UINT64_C(480724637))) & UINT64_C(18446744073709551615);
    v18=(v4) & UINT64_C(255);
    v20=((v18 * UINT64_C(247))) & UINT64_C(255);
    v22=((v20 + UINT64_C(157))) & UINT64_C(255);
    v24=((v12 * UINT64_C(17798225727368200192))) & UINT64_C(18446744073709551615);
    v26=((v24 + UINT64_C(11313042263954685952))) & UINT64_C(18446744073709551615);
    v28=((v16 << 40)) & UINT64_C(18446744073709551615);
    v30=(((v28 >> 48) | ((UINT64_C(0) - (v28 >> 63)) << 16))) & UINT64_C(18446744073709551615);
    v32=(v12) & UINT64_C(4294967295);
    v34=((v32 * UINT64_C(247574007))) & UINT64_C(4294967295);
    v36=((v34 + UINT64_C(480724637))) & UINT64_C(4294967295);
    v38=(v36) & UINT64_C(18446744073709551615);
    v39=(v22) & UINT64_C(255);
    v40=(v39) & UINT64_C(18446744073709551615);
    v41=((v30 + v40)) & UINT64_C(18446744073709551615);
    v42=(((v26 >> 56) | ((UINT64_C(0) - (v26 >> 63)) << 8))) & UINT64_C(18446744073709551615);
    v44=((v41 + v42)) & UINT64_C(18446744073709551615);
    v45=((v44 * UINT64_C(4066321351))) & UINT64_C(18446744073709551615);
    v47=((v45 + UINT64_C(1024304373))) & UINT64_C(18446744073709551615);
    v49=((v16 << 32)) & UINT64_C(18446744073709551615);
    v51=((v38 | v49)) & UINT64_C(18446744073709551615);
    v52=((v51 * UINT64_C(7))) & UINT64_C(18446744073709551615);
    v54=(v47) & UINT64_C(4294967295);
    v56=((v54 * UINT64_C(247574007))) & UINT64_C(4294967295);
    v58=((v56 + UINT64_C(480724637))) & UINT64_C(4294967295);
    v60=((v52 + UINT64_C(18364758544493064720))) & UINT64_C(18446744073709551615);
    v62=(((v58 ^ UINT64_C(2147483648)) < (UINT64_C(0) ^ UINT64_C(2147483648)))) & UINT64_C(255);
    v64=((v58 * UINT64_C(3609029461))) & UINT64_C(4294967295);
    v66=(v60) & UINT64_C(18446744073709551615);
    v67=((v66 >> 32)) & UINT64_C(18446744073709551615);
    v69=(v67) & UINT64_C(4294967295);
    v71=((v69 * UINT64_C(4066321351))) & UINT64_C(4294967295);
    v73=((v64 + v71)) & UINT64_C(4294967295);
    v74=((UINT64_C(2048608746) - v47)) & UINT64_C(18446744073709551615);
    v76=(v47) & UINT64_C(18446744073709551615);
    if(v62){incoming=0;goto b1;}else{incoming=0;goto b2;}
b1:
    if(++steps>10000u)exit(71);
    v78=(v74) & UINT64_C(18446744073709551615);
    incoming=1;goto b2;
b2:
    if(++steps>10000u)exit(71);
    switch(incoming){
    case 0:phi79=v76;break;
    case 1:phi79=v78;break;
    default:exit(72);}
    v79=phi79;
    v80=(v79) & UINT64_C(4294967295);
    v82=((v73 + v80)) & UINT64_C(4294967295);
    v83=((v82 * UINT64_C(247574007))) & UINT64_C(4294967295);
    v85=((v83 + UINT64_C(480724633))) & UINT64_C(4294967295);
    record_event((uint32_t)(v85));
    v88=(((UINT64_C(0) ^ UINT64_C(2147483648)) < (((uint64_t)(uint32_t)p2) ^ UINT64_C(2147483648)))) & UINT64_C(255);
    if(v88){incoming=0;goto b3;}else{incoming=0;goto b5;}
b3:
    if(++steps>10000u)exit(71);
    v92=((v79 * UINT64_C(1063322263404675072))) & UINT64_C(18446744073709551615);
    v94=((v92 + UINT64_C(2064696594296471552))) & UINT64_C(18446744073709551615);
    v96=((((uint64_t)(uint32_t)p2) + UINT64_C(1))) & UINT64_C(4294967295);
    v98=(((v94 >> 32) | ((UINT64_C(0) - (v94 >> 63)) << 32))) & UINT64_C(18446744073709551615);
    incoming=0;goto b4;
b4:
    if(++steps>10000u)exit(71);
    switch(incoming){
    case 0:phi100=v60;break;
    case 1:phi100=v101;break;
    default:exit(72);}
    switch(incoming){
    case 0:phi102=v96;break;
    case 1:phi102=v103;break;
    default:exit(72);}
    switch(incoming){
    case 0:phi104=v85;break;
    case 1:phi104=v105;break;
    default:exit(72);}
    v100=phi100;
    v102=phi102;
    v104=phi104;
    v106=(next_value((uint32_t)(v104))) & UINT64_C(4294967295);
    v108=(v106) & UINT64_C(18446744073709551615);
    v109=((v108 * UINT64_C(4197008313))) & UINT64_C(18446744073709551615);
    v111=((v109 + UINT64_C(2378020909))) & UINT64_C(18446744073709551615);
    v113=((v111 * UINT64_C(531663886090240))) & UINT64_C(18446744073709551615);
    v115=((v113 + UINT64_C(239165452451840))) & UINT64_C(18446744073709551615);
    v117=((v111 * UINT64_C(9871890383196127232))) & UINT64_C(18446744073709551615);
    v119=((v117 + UINT64_C(16933534598913064960))) & UINT64_C(18446744073709551615);
    v121=((v115 & UINT64_C(562949953290240))) & UINT64_C(18446744073709551615);
    v123=((v121 + v100)) & UINT64_C(18446744073709551615);
    v124=((v123 * UINT64_C(3))) & UINT64_C(18446744073709551615);
    v126=(((v119 >> 56) | ((UINT64_C(0) - (v119 >> 63)) << 8))) & UINT64_C(18446744073709551615);
    v128=((v98 + v126)) & UINT64_C(18446744073709551615);
    v101=((v124 + UINT64_C(11))) & UINT64_C(18446744073709551615);
    v130=(v128) & UINT64_C(18446744073709551615);
    v131=((v130 >> 2)) & UINT64_C(18446744073709551615);
    v136=(v101) & UINT64_C(4294967295);
    p0[2]=(uint32_t)(v136);
    v139=(v131) & UINT64_C(4294967295);
    v141=(v101) & UINT64_C(18446744073709551615);
    v142=((v141 >> 32)) & UINT64_C(18446744073709551615);
    v144=(v142) & UINT64_C(4294967295);
    v105=((v144 + v139)) & UINT64_C(4294967295);
    p0[0]=(uint32_t)(v105);
    record_event((uint32_t)(v106));
    v103=((v102 - UINT64_C(1))) & UINT64_C(4294967295);
    v149=((UINT64_C(1) < v103)) & UINT64_C(255);
    if(v149){incoming=1;goto b4;}else{incoming=1;goto b5;}
b5:
    if(++steps>10000u)exit(71);
    switch(incoming){
    case 0:phi152=v85;break;
    case 1:phi152=v105;break;
    default:exit(72);}
    v152=phi152;
    v153=(v152) & UINT64_C(4294967295);
    return (uint32_t)(v153);
}
