
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

uint region_pipeline(uint *p0,uint p1,int p2)

{
  int iVar1;
  uint value;
  long lVar2;
  long lVar3;
  long lVar4;
  long lVar5;
  uint value_00;
  uint uVar6;
  
  lVar3 = (ulong)p1 * 0xf25f23c7 + 0x3d0da4f5;
  lVar4 = (ulong)*p0 * 0xf25f23c7 + 0x3d0da4f5;
  lVar5 = lVar3 * 0xec1adf7 + 0x1ca7469d;
  lVar2 = (((lVar5 << 0x28) >> 0x30) + (ulong)(byte)((char)lVar3 * -9 + 0x9d) +
          (lVar4 * -0x900000000000000 + -0x6300000000000000 >> 0x38)) * 0xf25f23c7 + 0x3d0da4f5;
  iVar1 = (int)lVar2 * 0xec1adf7 + 0x1ca7469d;
  lVar3 = ((ulong)((int)lVar4 * 0xec1adf7 + 0x1ca7469d) | lVar5 << 0x20) * 7 + -0x123456789abcdf0;
  if (iVar1 < 0) {
    lVar2 = 0x7a1b49ea - lVar2;
  }
  value_00 = (iVar1 * -0x28e294ab + (int)((ulong)lVar3 >> 0x20) * -0xda0dc39 + (int)lVar2) *
             0xec1adf7 + 0x1ca74699;
  record_event(value_00);
  if (0 < p2) {
    uVar6 = p2 + 1;
    do {
      value = next_value(value_00);
      lVar4 = (ulong)value * 0xfa2943b9 + 0x8dbdb82d;
      lVar3 = ((lVar4 * 0x1e38ba5120000 + 0xd9850bd60000U & 0x1fffffffe0000) + lVar3) * 3 + 0xb;
      p0[2] = (uint)lVar3;
      value_00 = (int)((ulong)lVar3 >> 0x20) +
                 (int)((ulong)((lVar2 * 0xec1adf700000000 + 0x1ca7469d00000000 >> 0x20) +
                              (lVar4 * -0x7700000000000000 + -0x1500000000000000 >> 0x38)) >> 2);
      *p0 = value_00;
      record_event(value);
      uVar6 = uVar6 - 1;
    } while (1 < uVar6);
  }
  return value_00;
}

