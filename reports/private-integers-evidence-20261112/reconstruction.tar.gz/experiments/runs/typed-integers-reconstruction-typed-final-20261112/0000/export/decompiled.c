
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int region_outputs(uint *p0,uint p1,uint p2)

{
  uint value;
  uint uVar1;
  bool bVar2;
  bool bVar3;
  int iVar4;
  
  uVar1 = p2 & 0xffff;
  bVar3 = uVar1 + (p1 & 0xff) != 0;
  iVar4 = (int)((long)((ulong)p2 << 0x30) >> 0x33);
  if (bVar3) {
    iVar4 = iVar4 + 1;
  }
  value = iVar4 + (int)(char)p1 + p1;
  bVar2 = ((int)(char)p1 ^ 0x80000000U) < (uVar1 | 0x80000000);
  if (bVar2) {
    value = value + 1;
  }
  record_event(value);
  *p0 = uVar1 + 9;
  p0[1] = value;
  p0[2] = (int)(short)p2;
  return bVar3 != bVar2 ^ 1;
}

