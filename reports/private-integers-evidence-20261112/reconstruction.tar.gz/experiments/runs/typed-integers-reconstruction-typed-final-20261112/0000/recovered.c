#include <stdint.h>
#include <stdlib.h>
#include <limits.h>
_Static_assert(sizeof(int)==4, "32-bit int ABI required");
extern uint32_t next_value(uint32_t);
extern void record_event(uint32_t);
int32_t region_outputs(uint32_t *p0,uint32_t p1,uint32_t p2){
    unsigned steps=0, incoming=0;
    (void)p0;(void)p1;(void)p2;(void)incoming;
    uint64_t v0=0; (void)v0;
    uint64_t v3=0; (void)v3;
    uint64_t v4=0; (void)v4;
    uint64_t v7=0; (void)v7;
    uint64_t v8=0; (void)v8;
    uint64_t v10=0; (void)v10;
    uint64_t v11=0; (void)v11;
    uint64_t v13=0; (void)v13;
    uint64_t v15=0; (void)v15;
    uint64_t v17=0; (void)v17;
    uint64_t v18=0; (void)v18;
    uint64_t v20=0; (void)v20;
    uint64_t v23=0; (void)v23;
    uint64_t v25=0; (void)v25;
    uint64_t v26=0; (void)v26;
    uint64_t v27=0; (void)v27;
    uint64_t v28=0; (void)v28;
    uint64_t v30=0; (void)v30;
    uint64_t v31=0; (void)v31;
    uint64_t v33=0; (void)v33;
    uint64_t v34=0; (void)v34;
    uint64_t v37=0; (void)v37;
    uint64_t v39=0; (void)v39;
    uint64_t v41=0; (void)v41;
    uint64_t v42=0; (void)v42;
    uint64_t v49=0; (void)v49;
    uint64_t v54=0; (void)v54;
    uint64_t v56=0; (void)v56;
    uint64_t phi25=0;
    uint64_t phi39=0;
    goto b0;
b0:
    if(++steps>10000u)exit(71);
    v0=((((uint64_t)(uint32_t)p2) & UINT64_C(65535))) & UINT64_C(4294967295);
    v3=(((uint64_t)(uint32_t)p2)) & UINT64_C(18446744073709551615);
    v4=(((uint64_t)(uint32_t)p1)) & UINT64_C(255);
    v7=(((v4 ^ UINT64_C(128)) - UINT64_C(128))) & UINT64_C(4294967295);
    v8=((((uint64_t)(uint32_t)p1) & UINT64_C(255))) & UINT64_C(4294967295);
    v10=((v0 + v8)) & UINT64_C(4294967295);
    v11=((v10 != UINT64_C(0))) & UINT64_C(255);
    v13=((v3 << 48)) & UINT64_C(18446744073709551615);
    v15=((v0 | UINT64_C(2147483648))) & UINT64_C(4294967295);
    v17=(v13) & UINT64_C(18446744073709551615);
    v18=(((v17 >> 51) | ((UINT64_C(0) - (v17 >> 63)) << 13))) & UINT64_C(18446744073709551615);
    v20=(v18) & UINT64_C(4294967295);
    if(v11){incoming=0;goto b1;}else{incoming=0;goto b2;}
b1:
    if(++steps>10000u)exit(71);
    v23=((v20 + UINT64_C(1))) & UINT64_C(4294967295);
    incoming=1;goto b2;
b2:
    if(++steps>10000u)exit(71);
    switch(incoming){
    case 0:phi25=v20;break;
    case 1:phi25=v23;break;
    default:exit(72);}
    v25=phi25;
    v26=(((v4 ^ UINT64_C(128)) - UINT64_C(128))) & UINT64_C(4294967295);
    v27=((v26 + ((uint64_t)(uint32_t)p1))) & UINT64_C(4294967295);
    v28=((v7 ^ UINT64_C(2147483648))) & UINT64_C(4294967295);
    v30=((v25 + v27)) & UINT64_C(4294967295);
    v31=(((uint64_t)(uint32_t)p2)) & UINT64_C(65535);
    v33=((v28 < v15)) & UINT64_C(255);
    v34=((v0 + UINT64_C(9))) & UINT64_C(4294967295);
    if(v33){incoming=0;goto b3;}else{incoming=0;goto b4;}
b3:
    if(++steps>10000u)exit(71);
    v37=((v30 + UINT64_C(1))) & UINT64_C(4294967295);
    incoming=1;goto b4;
b4:
    if(++steps>10000u)exit(71);
    switch(incoming){
    case 0:phi39=v30;break;
    case 1:phi39=v37;break;
    default:exit(72);}
    v39=phi39;
    record_event((uint32_t)(v39));
    v41=((v11 != v33)) & UINT64_C(255);
    v42=(v41) & UINT64_C(4294967295);
    p0[0]=(uint32_t)(v34);
    p0[1]=(uint32_t)(v39);
    v49=((v42 ^ UINT64_C(1))) & UINT64_C(4294967295);
    v54=(((v31 ^ UINT64_C(32768)) - UINT64_C(32768))) & UINT64_C(4294967295);
    p0[2]=(uint32_t)(v54);
    v56=(v49) & UINT64_C(4294967295);
    {uint32_t r=(uint32_t)(v56);
    return r<=INT32_MAX?(int32_t)r:INT32_MIN+(int32_t)(r-UINT32_C(2147483648));}
}
