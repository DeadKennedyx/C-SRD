
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

uint region_pipeline(uint *p0,uint p1,int p2)

{
  int iVar1;
  uint value;
  int local_74;
  uint local_5c;
  long local_50;
  int local_28;
  uint local_14;
  
  local_74 = (p1 & 0xff) + (int)(char)*p0 + (int)(short)(p1 >> 8);
  iVar1 = local_74 * 3;
  local_50 = CONCAT44(p1,*p0) * 7 + -0x123456789abcdf0;
  if (local_74 < 0) {
    local_74 = -local_74;
  }
  local_5c = (int)((ulong)local_50 >> 0x20) + iVar1 + -4 + local_74;
  record_event(local_5c);
  local_28 = p2;
  if (p2 < 0) {
    local_14 = local_5c;
  }
  else {
    for (; 0 < local_28; local_28 = local_28 + -1) {
      value = next_value(local_5c);
      local_50 = (local_50 + (ulong)value * 0x20000) * 3 + 0xb;
      local_5c = (int)((ulong)local_50 >> 0x20) +
                 (int)((long)(int)(char)value + (long)local_74 >> 2);
      *p0 = local_5c;
      p0[2] = (uint)local_50;
      record_event(value);
    }
    local_14 = local_5c;
  }
  return local_14;
}

