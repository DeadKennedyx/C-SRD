#include <stdint.h>
#include <stdlib.h>
#include <limits.h>
_Static_assert(sizeof(int)==4, "32-bit int ABI required");
extern uint32_t next_value(uint32_t);
extern void record_event(uint32_t);
uint32_t region_pipeline(uint32_t *p0,uint32_t p1,int32_t p2){
    unsigned steps=0, incoming=0;
    (void)p0;(void)p1;(void)p2;(void)incoming;
    uint64_t v0=0; (void)v0;
    uint64_t v3=0; (void)v3;
    uint64_t v5=0; (void)v5;
    uint64_t v8=0; (void)v8;
    uint64_t v10=0; (void)v10;
    uint64_t v11=0; (void)v11;
    uint64_t v13=0; (void)v13;
    uint64_t v14=0; (void)v14;
    uint64_t v15=0; (void)v15;
    uint64_t v16=0; (void)v16;
    uint64_t v18=0; (void)v18;
    uint64_t v20=0; (void)v20;
    uint64_t v21=0; (void)v21;
    uint64_t v23=0; (void)v23;
    uint64_t v25=0; (void)v25;
    uint64_t v28=0; (void)v28;
    uint64_t v30=0; (void)v30;
    uint64_t v31=0; (void)v31;
    uint64_t v32=0; (void)v32;
    uint64_t v34=0; (void)v34;
    uint64_t v36=0; (void)v36;
    uint64_t v37=0; (void)v37;
    uint64_t v39=0; (void)v39;
    uint64_t v42=0; (void)v42;
    uint64_t v44=0; (void)v44;
    uint64_t v46=0; (void)v46;
    uint64_t v48=0; (void)v48;
    uint64_t v50=0; (void)v50;
    uint64_t v52=0; (void)v52;
    uint64_t v54=0; (void)v54;
    uint64_t v57=0; (void)v57;
    uint64_t v59=0; (void)v59;
    uint64_t v61=0; (void)v61;
    uint64_t v62=0; (void)v62;
    uint64_t v63=0; (void)v63;
    uint64_t v64=0; (void)v64;
    uint64_t v65=0; (void)v65;
    uint64_t v66=0; (void)v66;
    uint64_t v68=0; (void)v68;
    uint64_t v69=0; (void)v69;
    uint64_t v49=0; (void)v49;
    uint64_t v72=0; (void)v72;
    uint64_t v74=0; (void)v74;
    uint64_t v76=0; (void)v76;
    uint64_t v77=0; (void)v77;
    uint64_t v79=0; (void)v79;
    uint64_t v51=0; (void)v51;
    uint64_t v85=0; (void)v85;
    uint64_t v47=0; (void)v47;
    uint64_t v90=0; (void)v90;
    uint64_t v92=0; (void)v92;
    uint64_t v93=0; (void)v93;
    uint64_t phi30=0;
    uint64_t phi46=0;
    uint64_t phi48=0;
    uint64_t phi50=0;
    uint64_t phi92=0;
    goto b0;
b0:
    if(++steps>10000u)exit(71);
    v0=(p0[0]) & UINT64_C(4294967295);
    v3=(v0) & UINT64_C(255);
    v5=((((uint64_t)(uint32_t)p1) >> 8)) & UINT64_C(4294967295);
    v8=(v5) & UINT64_C(65535);
    v10=(((v3 ^ UINT64_C(128)) - UINT64_C(128))) & UINT64_C(4294967295);
    v11=((((uint64_t)(uint32_t)p1) & UINT64_C(255))) & UINT64_C(4294967295);
    v13=((v11 + v10)) & UINT64_C(4294967295);
    v14=(((v8 ^ UINT64_C(32768)) - UINT64_C(32768))) & UINT64_C(4294967295);
    v15=((v13 + v14)) & UINT64_C(4294967295);
    v16=((v15 * UINT64_C(3))) & UINT64_C(4294967295);
    v18=((v16 + UINT64_C(4294967292))) & UINT64_C(4294967295);
    v20=(((((uint64_t)(uint32_t)p1) << 32) | v0)) & UINT64_C(18446744073709551615);
    v21=((v20 * UINT64_C(7))) & UINT64_C(18446744073709551615);
    v23=((v21 + UINT64_C(18364758544493064720))) & UINT64_C(18446744073709551615);
    v25=(((v15 ^ UINT64_C(2147483648)) < (UINT64_C(0) ^ UINT64_C(2147483648)))) & UINT64_C(255);
    if(v25){incoming=0;goto b1;}else{incoming=1;goto b2;}
b1:
    if(++steps>10000u)exit(71);
    v28=((UINT64_C(0) - v15)) & UINT64_C(4294967295);
    incoming=0;goto b2;
b2:
    if(++steps>10000u)exit(71);
    switch(incoming){
    case 0:phi30=v28;break;
    case 1:phi30=v15;break;
    default:exit(72);}
    v30=phi30;
    v31=(v23) & UINT64_C(18446744073709551615);
    v32=((v31 >> 32)) & UINT64_C(18446744073709551615);
    v34=(v32) & UINT64_C(4294967295);
    v36=((v34 + v18)) & UINT64_C(4294967295);
    v37=((v36 + v30)) & UINT64_C(4294967295);
    record_event((uint32_t)(v37));
    v39=(((((uint64_t)(uint32_t)p2) ^ UINT64_C(2147483648)) < (UINT64_C(0) ^ UINT64_C(2147483648)))) & UINT64_C(255);
    v42=(((uint64_t)(uint32_t)p2)) & UINT64_C(4294967295);
    if(v39){incoming=0;goto b3;}else{incoming=1;goto b4;}
b3:
    if(++steps>10000u)exit(71);
    v44=(v37) & UINT64_C(4294967295);
    incoming=0;goto b7;
b4:
    if(++steps>10000u)exit(71);
    switch(incoming){
    case 0:phi46=v47;break;
    case 1:phi46=v42;break;
    default:exit(72);}
    switch(incoming){
    case 0:phi48=v49;break;
    case 1:phi48=v23;break;
    default:exit(72);}
    switch(incoming){
    case 0:phi50=v51;break;
    case 1:phi50=v37;break;
    default:exit(72);}
    v46=phi46;
    v48=phi48;
    v50=phi50;
    v52=((v46 + UINT64_C(4294967295))) & UINT64_C(4294967295);
    v54=(((UINT64_C(0) ^ UINT64_C(2147483648)) < (v46 ^ UINT64_C(2147483648)))) & UINT64_C(255);
    if(v54){incoming=0;goto b5;}else{incoming=0;goto b6;}
b5:
    if(++steps>10000u)exit(71);
    v57=(next_value((uint32_t)(v50))) & UINT64_C(4294967295);
    v59=(v57) & UINT64_C(255);
    v61=(((v59 ^ UINT64_C(128)) - UINT64_C(128))) & UINT64_C(4294967295);
    v62=(((v61 ^ UINT64_C(2147483648)) - UINT64_C(2147483648))) & UINT64_C(18446744073709551615);
    v63=(((v30 ^ UINT64_C(2147483648)) - UINT64_C(2147483648))) & UINT64_C(18446744073709551615);
    v64=((v62 + v63)) & UINT64_C(18446744073709551615);
    v65=(v57) & UINT64_C(18446744073709551615);
    v66=((v65 * UINT64_C(131072))) & UINT64_C(18446744073709551615);
    v68=((v48 + v66)) & UINT64_C(18446744073709551615);
    v69=((v68 * UINT64_C(3))) & UINT64_C(18446744073709551615);
    v49=((v69 + UINT64_C(11))) & UINT64_C(18446744073709551615);
    v72=(((v64 >> 2) | ((UINT64_C(0) - (v64 >> 63)) << 62))) & UINT64_C(18446744073709551615);
    v74=(v72) & UINT64_C(4294967295);
    v76=(v49) & UINT64_C(18446744073709551615);
    v77=((v76 >> 32)) & UINT64_C(18446744073709551615);
    v79=(v77) & UINT64_C(4294967295);
    v51=((v79 + v74)) & UINT64_C(4294967295);
    p0[0]=(uint32_t)(v51);
    v85=(v49) & UINT64_C(4294967295);
    p0[2]=(uint32_t)(v85);
    record_event((uint32_t)(v57));
    v47=(v52) & UINT64_C(4294967295);
    incoming=0;goto b4;
b6:
    if(++steps>10000u)exit(71);
    v90=(v50) & UINT64_C(4294967295);
    incoming=1;goto b7;
b7:
    if(++steps>10000u)exit(71);
    switch(incoming){
    case 0:phi92=v44;break;
    case 1:phi92=v90;break;
    default:exit(72);}
    v92=phi92;
    v93=(v92) & UINT64_C(4294967295);
    return (uint32_t)(v93);
}
