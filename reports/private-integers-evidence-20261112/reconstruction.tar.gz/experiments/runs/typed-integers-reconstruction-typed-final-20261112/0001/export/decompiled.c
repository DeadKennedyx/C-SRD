
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

uint region_pipeline(uint *p0,uint p1,int p2)

{
  int iVar1;
  int iVar2;
  uint value;
  int local_60;
  uint local_3c;
  long local_28;
  
  iVar2 = (p1 & 0xff) + (int)(char)*p0 + (int)(short)(p1 >> 8);
  iVar1 = iVar2 * 3;
  local_28 = CONCAT44(p1,*p0) * 7 + -0x123456789abcdf0;
  if (iVar2 < 0) {
    iVar2 = -iVar2;
  }
  local_3c = (int)((ulong)local_28 >> 0x20) + iVar1 + -4 + iVar2;
  record_event(local_3c);
  local_60 = p2;
  if (-1 < p2) {
    for (; 0 < local_60; local_60 = local_60 + -1) {
      value = next_value(local_3c);
      local_28 = (local_28 + (ulong)value * 0x20000) * 3 + 0xb;
      local_3c = (int)((ulong)local_28 >> 0x20) + (int)((long)(int)(char)value + (long)iVar2 >> 2);
      *p0 = local_3c;
      p0[2] = (uint)local_28;
      record_event(value);
    }
  }
  return local_3c;
}

