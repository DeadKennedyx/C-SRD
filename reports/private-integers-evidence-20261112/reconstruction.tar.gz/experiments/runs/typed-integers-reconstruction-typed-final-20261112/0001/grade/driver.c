#include <stdint.h>
#include <inttypes.h>
#include <stdio.h>
#include <stdlib.h>
uint32_t region_pipeline(uint32_t*,uint32_t,int);
uint32_t csrd_observation_memory[3], csrd_events[128], csrd_event_count, csrd_mode;
void record_event(uint32_t value){
    if(csrd_event_count>=128u)exit(70);
    csrd_events[csrd_event_count++]=value;
}
uint32_t next_value(uint32_t value){
    record_event(value);
    if(csrd_mode==0u){csrd_observation_memory[1]+=value;return value+csrd_observation_memory[1];}
    if(csrd_mode==1u){csrd_observation_memory[1]^=value;return 3u*value+csrd_observation_memory[1]+1u;}
    csrd_observation_memory[1]-=value;return (value>>3)^csrd_observation_memory[1];
}
int main(void){
    uint32_t x; int64_t arg;
    while(scanf("%" SCNu32 " %" SCNd64 " %" SCNu32 " %" SCNu32 " %" SCNu32 " %" SCNu32,
        &x,&arg,&csrd_observation_memory[0],&csrd_observation_memory[1],&csrd_observation_memory[2],&csrd_mode)==6){
        csrd_event_count=0u;
        uint32_t result=(uint32_t)region_pipeline(csrd_observation_memory,x,(int)arg);
        printf("%" PRIu32 " %" PRIu32 " %" PRIu32 " %" PRIu32 " %" PRIu32,result,
            csrd_observation_memory[0],csrd_observation_memory[1],csrd_observation_memory[2],csrd_event_count);
        for(uint32_t i=0;i<csrd_event_count;++i)printf(" %" PRIu32,csrd_events[i]);
        putchar('\n');
    }
    return 0;
}
