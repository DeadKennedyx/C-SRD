#include <stdint.h>
#include <stdlib.h>
#include <limits.h>
_Static_assert(sizeof(int)==4, "32-bit int ABI required");
extern uint32_t next_value(uint32_t);
extern void record_event(uint32_t);
uint32_t region_pipeline(uint32_t *p0,uint32_t p1,int32_t p2){
    unsigned steps=0, incoming=0;
    (void)p0;(void)p1;(void)p2;(void)incoming;
    uint64_t v0=0; (void)v0;
    uint64_t v3=0; (void)v3;
    uint64_t v5=0; (void)v5;
    uint64_t v8=0; (void)v8;
    uint64_t v10=0; (void)v10;
    uint64_t v11=0; (void)v11;
    uint64_t v13=0; (void)v13;
    uint64_t v14=0; (void)v14;
    uint64_t v15=0; (void)v15;
    uint64_t v16=0; (void)v16;
    uint64_t v18=0; (void)v18;
    uint64_t v20=0; (void)v20;
    uint64_t v21=0; (void)v21;
    uint64_t v23=0; (void)v23;
    uint64_t v25=0; (void)v25;
    uint64_t v28=0; (void)v28;
    uint64_t v30=0; (void)v30;
    uint64_t v31=0; (void)v31;
    uint64_t v32=0; (void)v32;
    uint64_t v34=0; (void)v34;
    uint64_t v36=0; (void)v36;
    uint64_t v37=0; (void)v37;
    uint64_t v39=0; (void)v39;
    uint64_t v42=0; (void)v42;
    uint64_t v43=0; (void)v43;
    uint64_t v45=0; (void)v45;
    uint64_t v47=0; (void)v47;
    uint64_t v49=0; (void)v49;
    uint64_t v51=0; (void)v51;
    uint64_t v53=0; (void)v53;
    uint64_t v56=0; (void)v56;
    uint64_t v58=0; (void)v58;
    uint64_t v60=0; (void)v60;
    uint64_t v61=0; (void)v61;
    uint64_t v62=0; (void)v62;
    uint64_t v63=0; (void)v63;
    uint64_t v64=0; (void)v64;
    uint64_t v65=0; (void)v65;
    uint64_t v67=0; (void)v67;
    uint64_t v68=0; (void)v68;
    uint64_t v46=0; (void)v46;
    uint64_t v71=0; (void)v71;
    uint64_t v73=0; (void)v73;
    uint64_t v75=0; (void)v75;
    uint64_t v76=0; (void)v76;
    uint64_t v78=0; (void)v78;
    uint64_t v48=0; (void)v48;
    uint64_t v84=0; (void)v84;
    uint64_t v50=0; (void)v50;
    uint64_t v88=0; (void)v88;
    uint64_t v89=0; (void)v89;
    uint64_t phi30=0;
    uint64_t phi45=0;
    uint64_t phi47=0;
    uint64_t phi49=0;
    uint64_t phi88=0;
    goto b0;
b0:
    if(++steps>10000u)exit(71);
    v0=(p0[0]) & UINT64_C(4294967295);
    v3=(v0) & UINT64_C(255);
    v5=((((uint64_t)(uint32_t)p1) >> 8)) & UINT64_C(4294967295);
    v8=(v5) & UINT64_C(65535);
    v10=(((v3 ^ UINT64_C(128)) - UINT64_C(128))) & UINT64_C(4294967295);
    v11=((((uint64_t)(uint32_t)p1) & UINT64_C(255))) & UINT64_C(4294967295);
    v13=((v11 + v10)) & UINT64_C(4294967295);
    v14=(((v8 ^ UINT64_C(32768)) - UINT64_C(32768))) & UINT64_C(4294967295);
    v15=((v13 + v14)) & UINT64_C(4294967295);
    v16=((v15 * UINT64_C(3))) & UINT64_C(4294967295);
    v18=((v16 + UINT64_C(4294967292))) & UINT64_C(4294967295);
    v20=(((((uint64_t)(uint32_t)p1) << 32) | v0)) & UINT64_C(18446744073709551615);
    v21=((v20 * UINT64_C(7))) & UINT64_C(18446744073709551615);
    v23=((v21 + UINT64_C(18364758544493064720))) & UINT64_C(18446744073709551615);
    v25=(((v15 ^ UINT64_C(2147483648)) < (UINT64_C(0) ^ UINT64_C(2147483648)))) & UINT64_C(255);
    if(v25){incoming=0;goto b1;}else{incoming=1;goto b2;}
b1:
    if(++steps>10000u)exit(71);
    v28=((UINT64_C(0) - v15)) & UINT64_C(4294967295);
    incoming=0;goto b2;
b2:
    if(++steps>10000u)exit(71);
    switch(incoming){
    case 0:phi30=v28;break;
    case 1:phi30=v15;break;
    default:exit(72);}
    v30=phi30;
    v31=(v23) & UINT64_C(18446744073709551615);
    v32=((v31 >> 32)) & UINT64_C(18446744073709551615);
    v34=(v32) & UINT64_C(4294967295);
    v36=((v34 + v18)) & UINT64_C(4294967295);
    v37=((v36 + v30)) & UINT64_C(4294967295);
    record_event((uint32_t)(v37));
    v39=(((UINT64_C(4294967295) ^ UINT64_C(2147483648)) < (((uint64_t)(uint32_t)p2) ^ UINT64_C(2147483648)))) & UINT64_C(255);
    v42=(((uint64_t)(uint32_t)p2)) & UINT64_C(4294967295);
    v43=(v42) & UINT64_C(4294967295);
    if(v39){incoming=0;goto b3;}else{incoming=1;goto b5;}
b3:
    if(++steps>10000u)exit(71);
    switch(incoming){
    case 0:phi45=v23;break;
    case 1:phi45=v46;break;
    default:exit(72);}
    switch(incoming){
    case 0:phi47=v37;break;
    case 1:phi47=v48;break;
    default:exit(72);}
    switch(incoming){
    case 0:phi49=v43;break;
    case 1:phi49=v50;break;
    default:exit(72);}
    v45=phi45;
    v47=phi47;
    v49=phi49;
    v51=((v49 + UINT64_C(4294967295))) & UINT64_C(4294967295);
    v53=(((UINT64_C(0) ^ UINT64_C(2147483648)) < (v49 ^ UINT64_C(2147483648)))) & UINT64_C(255);
    if(v53){incoming=0;goto b4;}else{incoming=0;goto b5;}
b4:
    if(++steps>10000u)exit(71);
    v56=(next_value((uint32_t)(v47))) & UINT64_C(4294967295);
    v58=(v56) & UINT64_C(255);
    v60=(((v58 ^ UINT64_C(128)) - UINT64_C(128))) & UINT64_C(4294967295);
    v61=(((v60 ^ UINT64_C(2147483648)) - UINT64_C(2147483648))) & UINT64_C(18446744073709551615);
    v62=(((v30 ^ UINT64_C(2147483648)) - UINT64_C(2147483648))) & UINT64_C(18446744073709551615);
    v63=((v61 + v62)) & UINT64_C(18446744073709551615);
    v64=(v56) & UINT64_C(18446744073709551615);
    v65=((v64 * UINT64_C(131072))) & UINT64_C(18446744073709551615);
    v67=((v45 + v65)) & UINT64_C(18446744073709551615);
    v68=((v67 * UINT64_C(3))) & UINT64_C(18446744073709551615);
    v46=((v68 + UINT64_C(11))) & UINT64_C(18446744073709551615);
    v71=(((v63 >> 2) | ((UINT64_C(0) - (v63 >> 63)) << 62))) & UINT64_C(18446744073709551615);
    v73=(v71) & UINT64_C(4294967295);
    v75=(v46) & UINT64_C(18446744073709551615);
    v76=((v75 >> 32)) & UINT64_C(18446744073709551615);
    v78=(v76) & UINT64_C(4294967295);
    v48=((v78 + v73)) & UINT64_C(4294967295);
    p0[0]=(uint32_t)(v48);
    v84=(v46) & UINT64_C(4294967295);
    p0[2]=(uint32_t)(v84);
    record_event((uint32_t)(v56));
    v50=(v51) & UINT64_C(4294967295);
    incoming=1;goto b3;
b5:
    if(++steps>10000u)exit(71);
    switch(incoming){
    case 0:phi88=v47;break;
    case 1:phi88=v37;break;
    default:exit(72);}
    v88=phi88;
    v89=(v88) & UINT64_C(4294967295);
    return (uint32_t)(v89);
}
