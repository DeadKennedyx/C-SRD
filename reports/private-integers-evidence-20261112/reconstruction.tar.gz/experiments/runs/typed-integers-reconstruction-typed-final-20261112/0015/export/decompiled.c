
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int region_outputs(uint *p0,uint p1,uint p2)

{
  ulong uVar1;
  ulong uVar2;
  long lVar3;
  long lVar4;
  bool bVar5;
  int iVar6;
  uint value;
  ulong uVar7;
  ulong uVar8;
  
  uVar1 = (ulong)p1 * 0x5f724d71 + 0x3587ff58;
  uVar2 = (ulong)p2 * 0x5f724d71 + 0x3587ff58;
  uVar7 = uVar2 & 0xffff;
  bVar5 = ((((((uVar1 & 0xff) * 0x91 - 0x31d8 & 0xff) * 0x5f724d71 + 0x3587ff58 & 0xffffffff) +
            ((uVar7 * 0xd391 - 0xffff28d8 & 0xffff) * 0x5f724d71 + 0x3587ff58 & 0xffffffff)) -
            0x3587ff58 & 0xffffffff) * 0x424ed391 + 0x19b2d728 & 0xffffffff) != 0;
  uVar8 = (long)(char)((char)uVar1 * -0x6f + '(') * 0x5f724d71 + 0x3587ff58U & 0xffffffff;
  if ((uVar8 * 0x424ed391 + 0x19b2d728 & 0xffffffff ^ 0x80000000) <
      (((uVar7 * 0xd391 - 0xffff28d8 & 0xffff) * 0x5f724d71 + 0x3587ff58 & 0xffffffff) * 0x424ed391
       + 0x19b2d728 & 0xffffffff ^ 0x80000000)) {
    iVar6 = -0x6b05b337;
  }
  else {
    iVar6 = 0x3587ff58;
  }
  lVar3 = (long)(short)((short)uVar2 * -0x2c6f + -0x28d8) * -0x399a7d83a08db28f +
          -0x1e542d83ca7800a8;
  lVar4 = (((((((uVar8 + (uVar1 & 0xffffffff)) - 0x3587ff58 & 0xffffffff) * 0x424ed391 + 0x19b2d728
              & 0xffffffff) * -0x399a7d83a08db28f + -0x1e542d83ca7800a8) * 0x5eb45d98424ed391 +
            0x5d29740219b2d728) * 0x5f724d7100000000 + -0x1e542d83ca7800a8) * 0x5eb45d98424ed391 +
           0x5d29740219b2d728 |
          ((uVar7 * 0xd391 - 0xffff28d8 & 0xffff) * -0x399a7d83a08db28f + -0x1e542d83ca7800a8) *
          0x5eb45d98424ed391 + 0x5d29740219b2d728) * -0x399a7d83a08db28f + -0x24c297246f7347af;
  value = ((int)((ulong)(lVar4 * 0x5eb45d98424ed391 + 0x5d29740219b2d728) >> 0x20) * 0x5f724d71 +
           (int)(lVar3 * 0x5eb45d98424ed391 + 0x5d29740219b2d728 >> 3) * 0x5f724d71 +
           (uint)bVar5 * 0x5f724d71 + iVar6) * 0x424ed391 + 0x19b2d728;
  record_event(value);
  *p0 = (int)lVar4 * 0x424ed391 + 0x19b2d728;
  p0[1] = value;
  p0[2] = (int)lVar3 * 0x424ed391 + 0x19b2d728;
  return (uint)(iVar6 * 0x424ed391 + 0x19b2d728U == (uint)bVar5);
}

