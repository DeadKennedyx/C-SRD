
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

uint region_pipeline(uint *p0,uint p1,int p2)

{
  uint uVar1;
  uint uVar2;
  byte bVar3;
  ushort uVar4;
  uint uVar5;
  uint uVar6;
  ulong local_438;
  byte local_420;
  uint local_28c;
  long local_280;
  int local_38;
  uint local_24;
  
  uVar2 = *p0;
  bVar3 = (byte)uVar2;
  uVar4 = (ushort)(p1 >> 8);
  if (0x7f < (uVar2 & 0xff)) {
    bVar3 = ~(0xff - bVar3);
  }
  if (0x7fff < (p1 >> 8 & 0xffff)) {
    uVar4 = ~(0xffff - uVar4);
  }
  uVar5 = (p1 & 0xff) + (int)(char)bVar3 + (int)(short)uVar4;
  uVar6 = uVar5;
  if (0x7fffffff < uVar5) {
    uVar6 = ~(0xffffffff - uVar5);
  }
  local_280 = CONCAT44(p1,uVar2) * 7 + -0x123456789abcdf0;
  if ((uVar5 ^ 0x80000000) < 0x80000000) {
    uVar5 = -uVar5;
  }
  local_28c = (int)((ulong)local_280 >> 0x20) + uVar6 * 3 + -4 + uVar5;
  if (0x7fffffff < uVar5) {
    uVar5 = ~(0xffffffff - uVar5);
  }
  record_event(local_28c);
  local_38 = p2;
  if (p2 < 0) {
    local_24 = local_28c;
  }
  else {
    for (; 0 < local_38; local_38 = local_38 + -1) {
      uVar2 = next_value(local_28c);
      local_420 = (byte)uVar2;
      if (0x7f < ((ulong)uVar2 & 0xff)) {
        local_420 = ~(-local_420 - 1);
      }
      uVar6 = (uint)(char)local_420;
      if (0x7fffffff < uVar6) {
        uVar6 = ~(0xffffffff - uVar6);
      }
      uVar1 = uVar5;
      if (0x7fffffff < uVar5) {
        uVar1 = ~(0xffffffff - uVar5);
      }
      local_438 = (long)(int)uVar6 + (long)(int)uVar1;
      local_280 = (local_280 + (ulong)uVar2 * 0x20000) * 3 + 0xb;
      if (0x7fffffffffffffff < local_438) {
        local_438 = ~(-local_438 - 1);
      }
      local_28c = (int)((ulong)local_280 >> 0x20) + (int)((long)local_438 >> 2);
      *p0 = local_28c;
      p0[2] = (uint)local_280;
      record_event(uVar2);
    }
    local_24 = local_28c;
  }
  return local_24;
}

