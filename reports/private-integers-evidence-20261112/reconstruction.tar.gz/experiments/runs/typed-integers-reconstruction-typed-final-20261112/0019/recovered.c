#include <stdint.h>
#include <stdlib.h>
#include <limits.h>
_Static_assert(sizeof(int)==4, "32-bit int ABI required");
extern uint32_t next_value(uint32_t);
extern void record_event(uint32_t);
uint32_t region_pipeline(uint32_t *p0,uint32_t p1,int32_t p2){
    unsigned steps=0, incoming=0;
    (void)p0;(void)p1;(void)p2;(void)incoming;
    uint64_t v0=0; (void)v0;
    uint64_t v3=0; (void)v3;
    uint64_t v6=0; (void)v6;
    uint64_t v8=0; (void)v8;
    uint64_t v10=0; (void)v10;
    uint64_t v12=0; (void)v12;
    uint64_t v14=0; (void)v14;
    uint64_t v16=0; (void)v16;
    uint64_t v18=0; (void)v18;
    uint64_t v21=0; (void)v21;
    uint64_t v23=0; (void)v23;
    uint64_t v25=0; (void)v25;
    uint64_t v26=0; (void)v26;
    uint64_t v27=0; (void)v27;
    uint64_t v28=0; (void)v28;
    uint64_t v29=0; (void)v29;
    uint64_t v32=0; (void)v32;
    uint64_t v34=0; (void)v34;
    uint64_t v36=0; (void)v36;
    uint64_t v37=0; (void)v37;
    uint64_t v38=0; (void)v38;
    uint64_t v39=0; (void)v39;
    uint64_t v40=0; (void)v40;
    uint64_t v42=0; (void)v42;
    uint64_t v44=0; (void)v44;
    uint64_t v46=0; (void)v46;
    uint64_t v47=0; (void)v47;
    uint64_t v49=0; (void)v49;
    uint64_t v50=0; (void)v50;
    uint64_t v52=0; (void)v52;
    uint64_t v54=0; (void)v54;
    uint64_t v55=0; (void)v55;
    uint64_t v57=0; (void)v57;
    uint64_t v59=0; (void)v59;
    uint64_t v61=0; (void)v61;
    uint64_t v63=0; (void)v63;
    uint64_t v65=0; (void)v65;
    uint64_t v67=0; (void)v67;
    uint64_t v68=0; (void)v68;
    uint64_t v69=0; (void)v69;
    uint64_t v71=0; (void)v71;
    uint64_t v73=0; (void)v73;
    uint64_t v74=0; (void)v74;
    uint64_t v75=0; (void)v75;
    uint64_t v78=0; (void)v78;
    uint64_t v80=0; (void)v80;
    uint64_t v82=0; (void)v82;
    uint64_t v84=0; (void)v84;
    uint64_t v87=0; (void)v87;
    uint64_t v89=0; (void)v89;
    uint64_t v91=0; (void)v91;
    uint64_t v93=0; (void)v93;
    uint64_t v95=0; (void)v95;
    uint64_t v97=0; (void)v97;
    uint64_t v99=0; (void)v99;
    uint64_t v102=0; (void)v102;
    uint64_t v104=0; (void)v104;
    uint64_t v105=0; (void)v105;
    uint64_t v107=0; (void)v107;
    uint64_t v109=0; (void)v109;
    uint64_t v112=0; (void)v112;
    uint64_t v113=0; (void)v113;
    uint64_t v115=0; (void)v115;
    uint64_t v117=0; (void)v117;
    uint64_t v118=0; (void)v118;
    uint64_t v119=0; (void)v119;
    uint64_t v120=0; (void)v120;
    uint64_t v123=0; (void)v123;
    uint64_t v125=0; (void)v125;
    uint64_t v127=0; (void)v127;
    uint64_t v128=0; (void)v128;
    uint64_t v129=0; (void)v129;
    uint64_t v130=0; (void)v130;
    uint64_t v132=0; (void)v132;
    uint64_t v134=0; (void)v134;
    uint64_t v136=0; (void)v136;
    uint64_t v137=0; (void)v137;
    uint64_t v139=0; (void)v139;
    uint64_t v140=0; (void)v140;
    uint64_t v141=0; (void)v141;
    uint64_t v142=0; (void)v142;
    uint64_t v143=0; (void)v143;
    uint64_t v145=0; (void)v145;
    uint64_t v146=0; (void)v146;
    uint64_t v94=0; (void)v94;
    uint64_t v149=0; (void)v149;
    uint64_t v152=0; (void)v152;
    uint64_t v153=0; (void)v153;
    uint64_t v155=0; (void)v155;
    uint64_t v157=0; (void)v157;
    uint64_t v158=0; (void)v158;
    uint64_t v159=0; (void)v159;
    uint64_t v161=0; (void)v161;
    uint64_t v163=0; (void)v163;
    uint64_t v164=0; (void)v164;
    uint64_t v166=0; (void)v166;
    uint64_t v96=0; (void)v96;
    uint64_t v172=0; (void)v172;
    uint64_t v92=0; (void)v92;
    uint64_t v177=0; (void)v177;
    uint64_t v179=0; (void)v179;
    uint64_t v180=0; (void)v180;
    uint64_t phi25=0;
    uint64_t phi36=0;
    uint64_t phi49=0;
    uint64_t phi67=0;
    uint64_t phi82=0;
    uint64_t phi91=0;
    uint64_t phi93=0;
    uint64_t phi95=0;
    uint64_t phi117=0;
    uint64_t phi127=0;
    uint64_t phi139=0;
    uint64_t phi157=0;
    uint64_t phi179=0;
    goto b0;
b0:
    if(++steps>10000u)exit(71);
    v0=(p0[0]) & UINT64_C(4294967295);
    v3=((((uint64_t)(uint32_t)p1) & UINT64_C(255))) & UINT64_C(4294967295);
    v6=((v0 & UINT64_C(255))) & UINT64_C(4294967295);
    v8=(v0) & UINT64_C(255);
    v10=((((uint64_t)(uint32_t)p1) >> 8)) & UINT64_C(4294967295);
    v12=((v10 & UINT64_C(65535))) & UINT64_C(4294967295);
    v14=((((uint64_t)(uint32_t)p1) >> 8)) & UINT64_C(4294967295);
    v16=(v14) & UINT64_C(65535);
    v18=((UINT64_C(127) < v6)) & UINT64_C(255);
    if(v18){incoming=0;goto b1;}else{incoming=1;goto b2;}
b1:
    if(++steps>10000u)exit(71);
    v21=((UINT64_C(255) - v8)) & UINT64_C(255);
    v23=(~v21) & UINT64_C(255);
    incoming=0;goto b2;
b2:
    if(++steps>10000u)exit(71);
    switch(incoming){
    case 0:phi25=v23;break;
    case 1:phi25=v8;break;
    default:exit(72);}
    v25=phi25;
    v26=(v25) & UINT64_C(255);
    v27=(((v26 ^ UINT64_C(128)) - UINT64_C(128))) & UINT64_C(4294967295);
    v28=((v3 + v27)) & UINT64_C(4294967295);
    v29=((UINT64_C(32767) < v12)) & UINT64_C(255);
    if(v29){incoming=0;goto b3;}else{incoming=1;goto b4;}
b3:
    if(++steps>10000u)exit(71);
    v32=((UINT64_C(65535) - v16)) & UINT64_C(65535);
    v34=(~v32) & UINT64_C(65535);
    incoming=0;goto b4;
b4:
    if(++steps>10000u)exit(71);
    switch(incoming){
    case 0:phi36=v34;break;
    case 1:phi36=v16;break;
    default:exit(72);}
    v36=phi36;
    v37=(v36) & UINT64_C(65535);
    v38=(((v37 ^ UINT64_C(32768)) - UINT64_C(32768))) & UINT64_C(4294967295);
    v39=((v28 + v38)) & UINT64_C(4294967295);
    v40=((UINT64_C(2147483647) < v39)) & UINT64_C(255);
    v42=(v39) & UINT64_C(4294967295);
    if(v40){incoming=0;goto b5;}else{incoming=1;goto b6;}
b5:
    if(++steps>10000u)exit(71);
    v44=((UINT64_C(4294967295) - v39)) & UINT64_C(4294967295);
    v46=(~v44) & UINT64_C(4294967295);
    v47=(v46) & UINT64_C(4294967295);
    incoming=0;goto b6;
b6:
    if(++steps>10000u)exit(71);
    switch(incoming){
    case 0:phi49=v47;break;
    case 1:phi49=v42;break;
    default:exit(72);}
    v49=phi49;
    v50=((v49 * UINT64_C(3))) & UINT64_C(4294967295);
    v52=((v50 + UINT64_C(4294967292))) & UINT64_C(4294967295);
    v54=(((((uint64_t)(uint32_t)p1) << 32) | v0)) & UINT64_C(18446744073709551615);
    v55=((v54 * UINT64_C(7))) & UINT64_C(18446744073709551615);
    v57=((v55 + UINT64_C(18364758544493064720))) & UINT64_C(18446744073709551615);
    v59=((v39 ^ UINT64_C(2147483648))) & UINT64_C(4294967295);
    v61=((v59 < UINT64_C(2147483648))) & UINT64_C(255);
    v63=((UINT64_C(0) - v39)) & UINT64_C(4294967295);
    if(v61){incoming=0;goto b7;}else{incoming=1;goto b8;}
b7:
    if(++steps>10000u)exit(71);
    v65=(v63) & UINT64_C(4294967295);
    incoming=0;goto b8;
b8:
    if(++steps>10000u)exit(71);
    switch(incoming){
    case 0:phi67=v65;break;
    case 1:phi67=v39;break;
    default:exit(72);}
    v67=phi67;
    v68=(v57) & UINT64_C(18446744073709551615);
    v69=((v68 >> 32)) & UINT64_C(18446744073709551615);
    v71=(v69) & UINT64_C(4294967295);
    v73=((v71 + v52)) & UINT64_C(4294967295);
    v74=((v73 + v67)) & UINT64_C(4294967295);
    v75=((UINT64_C(2147483647) < v67)) & UINT64_C(255);
    if(v75){incoming=0;goto b9;}else{incoming=1;goto b10;}
b9:
    if(++steps>10000u)exit(71);
    v78=((UINT64_C(4294967295) - v67)) & UINT64_C(4294967295);
    v80=(~v78) & UINT64_C(4294967295);
    incoming=0;goto b10;
b10:
    if(++steps>10000u)exit(71);
    switch(incoming){
    case 0:phi82=v80;break;
    case 1:phi82=v67;break;
    default:exit(72);}
    v82=phi82;
    record_event((uint32_t)(v74));
    v84=(((((uint64_t)(uint32_t)p2) ^ UINT64_C(2147483648)) < (UINT64_C(0) ^ UINT64_C(2147483648)))) & UINT64_C(255);
    v87=(((uint64_t)(uint32_t)p2)) & UINT64_C(4294967295);
    if(v84){incoming=0;goto b11;}else{incoming=1;goto b12;}
b11:
    if(++steps>10000u)exit(71);
    v89=(v74) & UINT64_C(4294967295);
    incoming=0;goto b23;
b12:
    if(++steps>10000u)exit(71);
    switch(incoming){
    case 0:phi91=v92;break;
    case 1:phi91=v87;break;
    default:exit(72);}
    switch(incoming){
    case 0:phi93=v94;break;
    case 1:phi93=v57;break;
    default:exit(72);}
    switch(incoming){
    case 0:phi95=v96;break;
    case 1:phi95=v74;break;
    default:exit(72);}
    v91=phi91;
    v93=phi93;
    v95=phi95;
    v97=((v91 + UINT64_C(4294967295))) & UINT64_C(4294967295);
    v99=(((UINT64_C(0) ^ UINT64_C(2147483648)) < (v91 ^ UINT64_C(2147483648)))) & UINT64_C(255);
    if(v99){incoming=0;goto b13;}else{incoming=0;goto b22;}
b13:
    if(++steps>10000u)exit(71);
    v102=(next_value((uint32_t)(v95))) & UINT64_C(4294967295);
    v104=(v102) & UINT64_C(18446744073709551615);
    v105=((v104 & UINT64_C(255))) & UINT64_C(18446744073709551615);
    v107=(v102) & UINT64_C(255);
    v109=((UINT64_C(127) < v105)) & UINT64_C(255);
    if(v109){incoming=0;goto b14;}else{incoming=1;goto b15;}
b14:
    if(++steps>10000u)exit(71);
    v112=((UINT64_C(0) - v107)) & UINT64_C(255);
    v113=((v112 - UINT64_C(1))) & UINT64_C(255);
    v115=(~v113) & UINT64_C(255);
    incoming=0;goto b15;
b15:
    if(++steps>10000u)exit(71);
    switch(incoming){
    case 0:phi117=v115;break;
    case 1:phi117=v107;break;
    default:exit(72);}
    v117=phi117;
    v118=(v117) & UINT64_C(255);
    v119=(((v118 ^ UINT64_C(128)) - UINT64_C(128))) & UINT64_C(4294967295);
    v120=((UINT64_C(2147483647) < v119)) & UINT64_C(255);
    if(v120){incoming=0;goto b16;}else{incoming=1;goto b17;}
b16:
    if(++steps>10000u)exit(71);
    v123=((UINT64_C(4294967295) - v119)) & UINT64_C(4294967295);
    v125=(~v123) & UINT64_C(4294967295);
    incoming=0;goto b17;
b17:
    if(++steps>10000u)exit(71);
    switch(incoming){
    case 0:phi127=v125;break;
    case 1:phi127=v119;break;
    default:exit(72);}
    v127=phi127;
    v128=(v127) & UINT64_C(4294967295);
    v129=(((v128 ^ UINT64_C(2147483648)) - UINT64_C(2147483648))) & UINT64_C(18446744073709551615);
    v130=((UINT64_C(2147483647) < v82)) & UINT64_C(255);
    v132=(v82) & UINT64_C(4294967295);
    if(v130){incoming=0;goto b18;}else{incoming=1;goto b19;}
b18:
    if(++steps>10000u)exit(71);
    v134=((UINT64_C(4294967295) - v82)) & UINT64_C(4294967295);
    v136=(~v134) & UINT64_C(4294967295);
    v137=(v136) & UINT64_C(4294967295);
    incoming=0;goto b19;
b19:
    if(++steps>10000u)exit(71);
    switch(incoming){
    case 0:phi139=v137;break;
    case 1:phi139=v132;break;
    default:exit(72);}
    v139=phi139;
    v140=(v139) & UINT64_C(4294967295);
    v141=(((v140 ^ UINT64_C(2147483648)) - UINT64_C(2147483648))) & UINT64_C(18446744073709551615);
    v142=((v129 + v141)) & UINT64_C(18446744073709551615);
    v143=((v104 * UINT64_C(131072))) & UINT64_C(18446744073709551615);
    v145=((v93 + v143)) & UINT64_C(18446744073709551615);
    v146=((v145 * UINT64_C(3))) & UINT64_C(18446744073709551615);
    v94=((v146 + UINT64_C(11))) & UINT64_C(18446744073709551615);
    v149=((UINT64_C(9223372036854775807) < v142)) & UINT64_C(255);
    if(v149){incoming=0;goto b20;}else{incoming=1;goto b21;}
b20:
    if(++steps>10000u)exit(71);
    v152=((UINT64_C(0) - v142)) & UINT64_C(18446744073709551615);
    v153=((v152 - UINT64_C(1))) & UINT64_C(18446744073709551615);
    v155=(~v153) & UINT64_C(18446744073709551615);
    incoming=0;goto b21;
b21:
    if(++steps>10000u)exit(71);
    switch(incoming){
    case 0:phi157=v155;break;
    case 1:phi157=v142;break;
    default:exit(72);}
    v157=phi157;
    v158=(v157) & UINT64_C(18446744073709551615);
    v159=(((v158 >> 2) | ((UINT64_C(0) - (v158 >> 63)) << 62))) & UINT64_C(18446744073709551615);
    v161=(v159) & UINT64_C(4294967295);
    v163=(v94) & UINT64_C(18446744073709551615);
    v164=((v163 >> 32)) & UINT64_C(18446744073709551615);
    v166=(v164) & UINT64_C(4294967295);
    v96=((v166 + v161)) & UINT64_C(4294967295);
    p0[0]=(uint32_t)(v96);
    v172=(v94) & UINT64_C(4294967295);
    p0[2]=(uint32_t)(v172);
    record_event((uint32_t)(v102));
    v92=(v97) & UINT64_C(4294967295);
    incoming=0;goto b12;
b22:
    if(++steps>10000u)exit(71);
    v177=(v95) & UINT64_C(4294967295);
    incoming=1;goto b23;
b23:
    if(++steps>10000u)exit(71);
    switch(incoming){
    case 0:phi179=v89;break;
    case 1:phi179=v177;break;
    default:exit(72);}
    v179=phi179;
    v180=(v179) & UINT64_C(4294967295);
    return (uint32_t)(v180);
}
