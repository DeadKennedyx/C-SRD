
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

uint region_pipeline(uint *p0,uint p1,int p2)

{
  uint uVar1;
  byte bVar2;
  ulong uVar3;
  ulong uVar4;
  long lVar5;
  uint uVar6;
  ulong uVar7;
  long lVar8;
  ulong local_498;
  uint local_490;
  uint local_478;
  ulong local_448;
  uint local_440;
  ushort local_438;
  uint local_28c;
  long local_280;
  int local_38;
  uint local_24;
  
  uVar4 = (ulong)p1 * 0xf25f23c7 + 0x3d0da4f5;
  uVar7 = uVar4 & 0xffffffff;
  uVar1 = ((*p0 * -0xda0dc39 + 0x3d0da4f5 & 0xff) - 0xf5) * 0xf7;
  bVar2 = (byte)uVar1;
  if (0x7f < (uVar1 & 0xff)) {
    bVar2 = ~(0xff - bVar2);
  }
  uVar3 = (((((uVar7 - 0x3d0da4f5) * 0xec1adf7 & 0xffffffff) >> 8) * 0xf25f23c7 + 0x3d0da4f5 &
           0xffff) - 0xa4f5) * 0xadf7;
  local_438 = (ushort)uVar3;
  if (0x7fff < (uVar3 & 0xffff)) {
    local_438 = ~(-local_438 - 1);
  }
  local_448 = (((((((uVar4 & 0xff) - 0xf5) * 0xf7 & 0xff) * 0xf25f23c7 + 0x3d0da4f5 & 0xffffffff) +
                ((long)(char)bVar2 * 0xf25f23c7 + 0x3d0da4f5U & 0xffffffff)) - 0x3d0da4f5 &
               0xffffffff) + ((long)(short)local_438 * 0xf25f23c7 + 0x3d0da4f5U & 0xffffffff)) -
              0x3d0da4f5 & 0xffffffff;
  uVar4 = (local_448 - 0x3d0da4f5) * 0xec1adf7;
  local_440 = (uint)uVar4;
  if (0x7fffffff < (uVar4 & 0xffffffff)) {
    local_440 = ~(-local_440 - 1);
  }
  lVar8 = (((uVar7 - 0x3d0da4f5) * 0xec1adf7 << 0x20 | (ulong)*p0) * 0xd9a1ecef25f23c7 +
          -0xe333aedc2f25b0b) * 7;
  if (0x7fffffff < ((local_448 - 0x3d0da4f5) * 0xec1adf7 & 0xffffffff ^ 0x80000000) != true) {
    local_448 = local_448 * 0xffffffff + 0x7a1b49ea & 0xffffffff;
  }
  local_280 = (lVar8 + 0x102c2aa386db97bd) * -0x54849bb2f13e5209;
  uVar4 = (local_448 - 0x3d0da4f5) * 0xec1adf7;
  local_478 = (uint)uVar4;
  local_28c = ((int)((ulong)((lVar8 + 0x102c2aa386db97bd) * -0x54849bb2f13e5209) >> 0x20) *
               -0xda0dc39 + (local_440 * -0xda0dc39 + 0x3d0da4f5) * 3 + (int)local_448 + 0x424cdd10)
              * 0xec1adf7;
  if (0x7fffffff < (uVar4 & 0xffffffff)) {
    local_478 = ~(-local_478 - 1);
  }
  record_event(local_28c);
  local_38 = p2;
  if (p2 < 0) {
    local_24 = local_28c;
  }
  else {
    for (; 0 < local_38; local_38 = local_38 + -1) {
      uVar1 = next_value(local_28c);
      uVar6 = ((uVar1 * -0x5d6bc47 + 0x8dbdb82d & 0xff) - 0x2d) * 0x89;
      bVar2 = (byte)uVar6;
      if (0x7f < (uVar6 & 0xff)) {
        bVar2 = ~(0xff - bVar2);
      }
      uVar6 = (uint)(char)bVar2;
      if (0x7fffffff < uVar6) {
        uVar6 = ~(0xffffffff - uVar6);
      }
      local_490 = local_478;
      if (0x7fffffff < local_478) {
        local_490 = ~(-local_478 - 1);
      }
      lVar8 = (long)(int)uVar6 * -0x2b00229105d6bc47 + (long)(int)local_490 * -0x2b00229105d6bc47;
      lVar5 = (local_280 * -0x2b00229105d6bc47 + 0x6b30bcc8dbdb82d +
              (ulong)uVar1 * -0x45220bad788e0000) * 3;
      local_498 = lVar8 * 0x1c19f504f1c5d289;
      if (0x7fffffffffffffff < local_498) {
        local_498 = ~(lVar8 * -0x1c19f504f1c5d289 - 1U);
      }
      local_280 = (lVar5 + 0x12e5605f168cc06c) * 0x1c19f504f1c5d289;
      local_28c = ((int)((ulong)((lVar5 + 0x12e5605f168cc06c) * 0x1c19f504f1c5d289) >> 0x20) *
                   -0x5d6bc47 + (int)((long)local_498 >> 2) * -0x5d6bc47) * -0xe3a2d77;
      *p0 = local_28c;
      p0[2] = (uint)local_280;
      record_event(uVar1);
    }
    local_24 = local_28c;
  }
  return local_24;
}

