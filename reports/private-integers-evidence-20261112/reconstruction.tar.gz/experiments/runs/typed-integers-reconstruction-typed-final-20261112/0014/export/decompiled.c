
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int region_outputs(uint *p0,uint p1,uint p2)

{
  long lVar1;
  bool bVar2;
  bool bVar3;
  uint value;
  ulong uVar4;
  
  uVar4 = (ulong)p2 & 0xffff;
  bVar3 = ((ulong)p1 & 0xff) + uVar4 != 0;
  bVar2 = ((ulong)(uint)(int)(char)p1 ^ 0x80000000) < (uVar4 ^ 0x80000000);
  lVar1 = ((ulong)(uint)(int)(char)p1 + (ulong)p1 << 0x20 | uVar4) + 9;
  value = (int)((ulong)lVar1 >> 0x20) + (int)((long)(short)p2 >> 3) + (uint)bVar3 + (uint)bVar2;
  record_event(value);
  *p0 = (uint)lVar1;
  p0[1] = value;
  p0[2] = (int)(short)p2;
  return (uint)(bVar2 == bVar3);
}

