
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int region_outputs(uint *p0,uint p1,uint p2)

{
  long lVar1;
  uint value;
  ushort uVar2;
  bool bVar3;
  uint uVar4;
  
  uVar2 = (ushort)p2;
  bVar3 = (p1 & 0xff) + (p2 & 0xffff) != 0;
  uVar4 = (uint)((int)(char)p1 < (int)(p2 & 0xffff));
  lVar1 = ((ulong)uVar2 | (ulong)((int)(char)p1 + p1) << 0x20) + 9;
  value = (int)((ulong)lVar1 >> 0x20) + (int)((long)(short)uVar2 >> 3) + (uint)bVar3 + uVar4;
  record_event(value);
  *p0 = (uint)lVar1;
  p0[1] = value;
  p0[2] = (int)(short)uVar2;
  return (int)(bVar3 == uVar4);
}

