#include <stdint.h>
#include <stdlib.h>
#include <limits.h>
_Static_assert(sizeof(int)==4, "32-bit int ABI required");
extern uint32_t next_value(uint32_t);
extern void record_event(uint32_t);
int32_t region_outputs(uint32_t *p0,uint32_t p1,uint32_t p2){
    unsigned steps=0, incoming=0;
    (void)p0;(void)p1;(void)p2;(void)incoming;
    uint64_t v0=0; (void)v0;
    uint64_t v3=0; (void)v3;
    uint64_t v5=0; (void)v5;
    uint64_t v7=0; (void)v7;
    uint64_t v9=0; (void)v9;
    uint64_t v11=0; (void)v11;
    uint64_t v13=0; (void)v13;
    uint64_t v15=0; (void)v15;
    uint64_t v17=0; (void)v17;
    uint64_t v19=0; (void)v19;
    uint64_t v20=0; (void)v20;
    uint64_t v22=0; (void)v22;
    uint64_t v24=0; (void)v24;
    uint64_t v26=0; (void)v26;
    uint64_t v28=0; (void)v28;
    uint64_t v29=0; (void)v29;
    uint64_t v31=0; (void)v31;
    uint64_t v33=0; (void)v33;
    uint64_t v35=0; (void)v35;
    uint64_t v37=0; (void)v37;
    uint64_t v39=0; (void)v39;
    uint64_t v41=0; (void)v41;
    uint64_t v43=0; (void)v43;
    uint64_t v45=0; (void)v45;
    uint64_t v47=0; (void)v47;
    uint64_t v48=0; (void)v48;
    uint64_t v49=0; (void)v49;
    uint64_t v51=0; (void)v51;
    uint64_t v53=0; (void)v53;
    uint64_t v55=0; (void)v55;
    uint64_t v57=0; (void)v57;
    uint64_t v59=0; (void)v59;
    uint64_t v61=0; (void)v61;
    uint64_t v63=0; (void)v63;
    uint64_t v65=0; (void)v65;
    uint64_t v67=0; (void)v67;
    uint64_t v69=0; (void)v69;
    uint64_t v70=0; (void)v70;
    uint64_t v72=0; (void)v72;
    uint64_t v74=0; (void)v74;
    uint64_t v76=0; (void)v76;
    uint64_t v77=0; (void)v77;
    uint64_t v78=0; (void)v78;
    uint64_t v79=0; (void)v79;
    uint64_t v80=0; (void)v80;
    uint64_t v82=0; (void)v82;
    uint64_t v84=0; (void)v84;
    uint64_t v85=0; (void)v85;
    uint64_t v87=0; (void)v87;
    uint64_t v88=0; (void)v88;
    uint64_t v90=0; (void)v90;
    uint64_t v91=0; (void)v91;
    uint64_t v93=0; (void)v93;
    uint64_t v94=0; (void)v94;
    uint64_t v96=0; (void)v96;
    uint64_t v98=0; (void)v98;
    uint64_t v99=0; (void)v99;
    uint64_t v101=0; (void)v101;
    uint64_t v103=0; (void)v103;
    uint64_t v105=0; (void)v105;
    uint64_t v107=0; (void)v107;
    uint64_t v109=0; (void)v109;
    uint64_t v111=0; (void)v111;
    uint64_t v113=0; (void)v113;
    uint64_t v114=0; (void)v114;
    uint64_t v115=0; (void)v115;
    uint64_t v116=0; (void)v116;
    uint64_t v117=0; (void)v117;
    uint64_t v119=0; (void)v119;
    uint64_t v122=0; (void)v122;
    uint64_t v134=0; (void)v134;
    uint64_t phi76=0;
    uint64_t phi77=0;
    uint64_t phi113=0;
    goto b0;
b0:
    if(++steps>10000u)exit(71);
    v0=((((uint64_t)(uint32_t)p1) * UINT64_C(1601326449))) & UINT64_C(4294967295);
    v3=((v0 + UINT64_C(898105176))) & UINT64_C(4294967295);
    v5=(((uint64_t)(uint32_t)p2)) & UINT64_C(18446744073709551615);
    v7=((v5 * UINT64_C(1601326449))) & UINT64_C(18446744073709551615);
    v9=((v7 + UINT64_C(898105176))) & UINT64_C(18446744073709551615);
    v11=((v3 * UINT64_C(8))) & UINT64_C(4294967295);
    v13=((v11 & UINT64_C(2040))) & UINT64_C(4294967295);
    v15=((v9 & UINT64_C(65535))) & UINT64_C(18446744073709551615);
    v17=((v3 & UINT64_C(255))) & UINT64_C(4294967295);
    v19=((v13 + v17)) & UINT64_C(4294967295);
    v20=((v15 * UINT64_C(54161))) & UINT64_C(18446744073709551615);
    v22=((v20 - UINT64_C(4294912216))) & UINT64_C(18446744073709551615);
    v24=((v19 * UINT64_C(16))) & UINT64_C(4294967295);
    v26=((v3 & UINT64_C(255))) & UINT64_C(4294967295);
    v28=((v24 + v26)) & UINT64_C(4294967295);
    v29=((v28 - UINT64_C(12760))) & UINT64_C(4294967295);
    v31=((v22 & UINT64_C(65535))) & UINT64_C(18446744073709551615);
    v33=(UINT64_C(1601326449)) & UINT64_C(4294967295);
    v35=((v29 & UINT64_C(255))) & UINT64_C(4294967295);
    v37=(v29) & UINT64_C(255);
    v39=(v31) & UINT64_C(4294967295);
    v41=((v39 * UINT64_C(1601326449))) & UINT64_C(4294967295);
    v43=((v41 + UINT64_C(898105176))) & UINT64_C(4294967295);
    v45=((v35 * UINT64_C(1601326449))) & UINT64_C(4294967295);
    v47=((v43 + v45)) & UINT64_C(4294967295);
    v48=(((v37 ^ UINT64_C(128)) - UINT64_C(128))) & UINT64_C(4294967295);
    v49=((v48 * UINT64_C(1601326449))) & UINT64_C(4294967295);
    v51=((v49 + UINT64_C(898105176))) & UINT64_C(4294967295);
    v53=((v47 * UINT64_C(1112462225))) & UINT64_C(4294967295);
    v55=((v43 * UINT64_C(1112462225))) & UINT64_C(4294967295);
    v57=((v55 + UINT64_C(431150888))) & UINT64_C(4294967295);
    v59=((v51 * UINT64_C(1112462225))) & UINT64_C(4294967295);
    v61=((v59 + UINT64_C(431150888))) & UINT64_C(4294967295);
    v63=((v53 != UINT64_C(3863816408))) & UINT64_C(255);
    v65=((v57 ^ UINT64_C(2147483648))) & UINT64_C(4294967295);
    v67=((v61 ^ UINT64_C(2147483648))) & UINT64_C(4294967295);
    v69=((v65 <= v67)) & UINT64_C(255);
    v70=(v63) & UINT64_C(255);
    if(v69){incoming=0;goto b1;}else{incoming=0;goto b2;}
b1:
    if(++steps>10000u)exit(71);
    v72=((v53 == UINT64_C(3863816408))) & UINT64_C(255);
    v74=(UINT64_C(0)) & UINT64_C(4294967295);
    incoming=1;goto b2;
b2:
    if(++steps>10000u)exit(71);
    switch(incoming){
    case 0:phi76=v70;break;
    case 1:phi76=v72;break;
    default:exit(72);}
    switch(incoming){
    case 0:phi77=v33;break;
    case 1:phi77=v74;break;
    default:exit(72);}
    v76=phi76;
    v77=phi77;
    v78=(v76) & UINT64_C(4294967295);
    v79=((v0 + v51)) & UINT64_C(4294967295);
    v80=((v79 * UINT64_C(1112462225))) & UINT64_C(4294967295);
    v82=((v80 + UINT64_C(431150888))) & UINT64_C(4294967295);
    v84=(v82) & UINT64_C(18446744073709551615);
    v85=(v22) & UINT64_C(65535);
    v87=(((v85 ^ UINT64_C(32768)) - UINT64_C(32768))) & UINT64_C(4294967295);
    v88=((v84 << 32)) & UINT64_C(18446744073709551615);
    v90=((v31 | v88)) & UINT64_C(18446744073709551615);
    v91=((v90 + UINT64_C(9))) & UINT64_C(18446744073709551615);
    v93=(v87) & UINT64_C(4294967295);
    v94=(((v93 >> 3) | ((UINT64_C(0) - (v93 >> 31)) << 29))) & UINT64_C(4294967295);
    v96=((v94 * UINT64_C(1601326449))) & UINT64_C(4294967295);
    v98=(v91) & UINT64_C(18446744073709551615);
    v99=((v98 >> 32)) & UINT64_C(18446744073709551615);
    v101=(v99) & UINT64_C(4294967295);
    v103=((v101 * UINT64_C(1601326449))) & UINT64_C(4294967295);
    v105=((v103 + UINT64_C(898105176))) & UINT64_C(4294967295);
    v107=(UINT64_C(1601326449)) & UINT64_C(4294967295);
    v109=((v63 == 0)) & UINT64_C(255);
    if(v109){incoming=0;goto b3;}else{incoming=0;goto b4;}
b3:
    if(++steps>10000u)exit(71);
    v111=(UINT64_C(0)) & UINT64_C(4294967295);
    incoming=1;goto b4;
b4:
    if(++steps>10000u)exit(71);
    switch(incoming){
    case 0:phi113=v107;break;
    case 1:phi113=v111;break;
    default:exit(72);}
    v113=phi113;
    v114=((v113 + v77)) & UINT64_C(4294967295);
    v115=((v96 + v105)) & UINT64_C(4294967295);
    v116=((v115 + v114)) & UINT64_C(4294967295);
    v117=((v116 * UINT64_C(1112462225))) & UINT64_C(4294967295);
    v119=((v117 + UINT64_C(431150888))) & UINT64_C(4294967295);
    record_event((uint32_t)(v119));
    v122=(v91) & UINT64_C(4294967295);
    p0[0]=(uint32_t)(v122);
    p0[1]=(uint32_t)(v119);
    p0[2]=(uint32_t)(v87);
    v134=(v78) & UINT64_C(4294967295);
    {uint32_t r=(uint32_t)(v134);
    return r<=INT32_MAX?(int32_t)r:INT32_MIN+(int32_t)(r-UINT32_C(2147483648));}
}
