
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int region_outputs(uint *p0,uint p1,uint p2)

{
  long lVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  bool bVar5;
  ulong uVar6;
  uint uVar7;
  ulong uVar8;
  int iVar9;
  uint value;
  
  uVar7 = p1 * 0x5f724d71 + 0x3587ff58;
  uVar8 = ((ulong)p2 * 0x5f724d71 + 0x3587ff58 & 0xffff) * 0xd391 - 0xffff28d8;
  uVar7 = (((uVar7 * 8 & 0x7f8) + (uVar7 & 0xff)) * 0x10 + (uVar7 & 0xff)) - 0x31d8;
  uVar6 = uVar8 & 0xffff;
  iVar9 = 0x5f724d71;
  iVar3 = (int)uVar6 * 0x5f724d71 + 0x3587ff58;
  iVar4 = (char)uVar7 * 0x5f724d71 + 0x3587ff58;
  iVar2 = (iVar3 + (uVar7 & 0xff) * 0x5f724d71) * 0x424ed391;
  bVar5 = iVar2 != -0x19b2d728;
  if ((iVar3 * 0x424ed391 + 0x19b2d728U ^ 0x80000000) <=
      (iVar4 * 0x424ed391 + 0x19b2d728U ^ 0x80000000)) {
    bVar5 = iVar2 == -0x19b2d728;
    iVar9 = 0;
  }
  uVar7 = (uint)(short)uVar8;
  lVar1 = (uVar6 | (ulong)((p1 * 0x5f724d71 + iVar4) * 0x424ed391 + 0x19b2d728) << 0x20) + 9;
  iVar3 = 0x5f724d71;
  if (iVar2 == -0x19b2d728) {
    iVar3 = 0;
  }
  value = (((int)uVar7 >> 3) * 0x5f724d71 + (int)((ulong)lVar1 >> 0x20) * 0x5f724d71 + 0x3587ff58 +
          iVar3 + iVar9) * 0x424ed391 + 0x19b2d728;
  record_event(value);
  *p0 = (uint)lVar1;
  p0[1] = value;
  p0[2] = uVar7;
  return (uint)bVar5;
}

