#include <stdint.h>
#include <stdlib.h>
#include <limits.h>
_Static_assert(sizeof(int)==4, "32-bit int ABI required");
extern uint32_t next_value(uint32_t);
extern void record_event(uint32_t);
uint32_t region_pipeline(uint32_t *p0,uint32_t p1,int32_t p2){
    unsigned steps=0, incoming=0;
    (void)p0;(void)p1;(void)p2;(void)incoming;
    uint64_t v0=0; (void)v0;
    uint64_t v3=0; (void)v3;
    uint64_t v6=0; (void)v6;
    uint64_t v7=0; (void)v7;
    uint64_t v9=0; (void)v9;
    uint64_t v10=0; (void)v10;
    uint64_t v12=0; (void)v12;
    uint64_t v13=0; (void)v13;
    uint64_t v15=0; (void)v15;
    uint64_t v16=0; (void)v16;
    uint64_t v17=0; (void)v17;
    uint64_t v19=0; (void)v19;
    uint64_t v21=0; (void)v21;
    uint64_t v22=0; (void)v22;
    uint64_t v24=0; (void)v24;
    uint64_t v25=0; (void)v25;
    uint64_t v27=0; (void)v27;
    uint64_t v28=0; (void)v28;
    uint64_t v29=0; (void)v29;
    uint64_t v30=0; (void)v30;
    uint64_t v32=0; (void)v32;
    uint64_t v33=0; (void)v33;
    uint64_t v34=0; (void)v34;
    uint64_t v36=0; (void)v36;
    uint64_t v38=0; (void)v38;
    uint64_t v39=0; (void)v39;
    uint64_t v42=0; (void)v42;
    uint64_t v46=0; (void)v46;
    uint64_t v48=0; (void)v48;
    uint64_t v50=0; (void)v50;
    uint64_t v52=0; (void)v52;
    uint64_t v54=0; (void)v54;
    uint64_t v56=0; (void)v56;
    uint64_t v57=0; (void)v57;
    uint64_t v59=0; (void)v59;
    uint64_t v60=0; (void)v60;
    uint64_t v61=0; (void)v61;
    uint64_t v63=0; (void)v63;
    uint64_t v64=0; (void)v64;
    uint64_t v49=0; (void)v49;
    uint64_t v67=0; (void)v67;
    uint64_t v72=0; (void)v72;
    uint64_t v75=0; (void)v75;
    uint64_t v77=0; (void)v77;
    uint64_t v78=0; (void)v78;
    uint64_t v80=0; (void)v80;
    uint64_t v53=0; (void)v53;
    uint64_t v51=0; (void)v51;
    uint64_t v85=0; (void)v85;
    uint64_t v88=0; (void)v88;
    uint64_t v89=0; (void)v89;
    uint64_t phi28=0;
    uint64_t phi48=0;
    uint64_t phi50=0;
    uint64_t phi52=0;
    uint64_t phi88=0;
    goto b0;
b0:
    if(++steps>10000u)exit(71);
    v0=(p0[0]) & UINT64_C(4294967295);
    v3=((((uint64_t)(uint32_t)p1) << 8)) & UINT64_C(4294967295);
    v6=(v3) & UINT64_C(4294967295);
    v7=(((v6 >> 16) | ((UINT64_C(0) - (v6 >> 31)) << 16))) & UINT64_C(4294967295);
    v9=(((((uint64_t)(uint32_t)p1) << 32) | v0)) & UINT64_C(18446744073709551615);
    v10=((((uint64_t)(uint32_t)p1) & UINT64_C(255))) & UINT64_C(4294967295);
    v12=((v7 + v10)) & UINT64_C(4294967295);
    v13=(v0) & UINT64_C(255);
    v15=(((v13 ^ UINT64_C(128)) - UINT64_C(128))) & UINT64_C(4294967295);
    v16=((v12 + v15)) & UINT64_C(4294967295);
    v17=((v9 * UINT64_C(7))) & UINT64_C(18446744073709551615);
    v19=((v16 * UINT64_C(3))) & UINT64_C(4294967295);
    v21=(v16) & UINT64_C(4294967295);
    v22=(((UINT64_C(4294967295) ^ UINT64_C(2147483648)) < (v21 ^ UINT64_C(2147483648)))) & UINT64_C(255);
    v24=((UINT64_C(0) - v16)) & UINT64_C(4294967295);
    v25=(v24) & UINT64_C(4294967295);
    if(v22){incoming=0;goto b1;}else{incoming=0;goto b2;}
b1:
    if(++steps>10000u)exit(71);
    v27=(v16) & UINT64_C(4294967295);
    incoming=1;goto b2;
b2:
    if(++steps>10000u)exit(71);
    switch(incoming){
    case 0:phi28=v25;break;
    case 1:phi28=v27;break;
    default:exit(72);}
    v28=phi28;
    v29=(v28) & UINT64_C(18446744073709551615);
    v30=((v17 + UINT64_C(18364758544493064720))) & UINT64_C(18446744073709551615);
    v32=((v19 + v28)) & UINT64_C(4294967295);
    v33=(v30) & UINT64_C(18446744073709551615);
    v34=((v33 >> 32)) & UINT64_C(18446744073709551615);
    v36=(v34) & UINT64_C(4294967295);
    v38=((v32 + v36)) & UINT64_C(4294967295);
    v39=((v38 - UINT64_C(4))) & UINT64_C(4294967295);
    record_event((uint32_t)(v39));
    v42=(((UINT64_C(0) ^ UINT64_C(2147483648)) < (((uint64_t)(uint32_t)p2) ^ UINT64_C(2147483648)))) & UINT64_C(255);
    if(v42){incoming=0;goto b3;}else{incoming=0;goto b5;}
b3:
    if(++steps>10000u)exit(71);
    v46=((((uint64_t)(uint32_t)p2) + UINT64_C(1))) & UINT64_C(4294967295);
    incoming=0;goto b4;
b4:
    if(++steps>10000u)exit(71);
    switch(incoming){
    case 0:phi48=v30;break;
    case 1:phi48=v49;break;
    default:exit(72);}
    switch(incoming){
    case 0:phi50=v46;break;
    case 1:phi50=v51;break;
    default:exit(72);}
    switch(incoming){
    case 0:phi52=v39;break;
    case 1:phi52=v53;break;
    default:exit(72);}
    v48=phi48;
    v50=phi50;
    v52=phi52;
    v54=(next_value((uint32_t)(v52))) & UINT64_C(4294967295);
    v56=(v54) & UINT64_C(18446744073709551615);
    v57=(v54) & UINT64_C(255);
    v59=(((v57 ^ UINT64_C(128)) - UINT64_C(128))) & UINT64_C(18446744073709551615);
    v60=((v29 + v59)) & UINT64_C(18446744073709551615);
    v61=((v56 * UINT64_C(131072))) & UINT64_C(18446744073709551615);
    v63=((v48 + v61)) & UINT64_C(18446744073709551615);
    v64=((v63 * UINT64_C(3))) & UINT64_C(18446744073709551615);
    v49=((v64 + UINT64_C(11))) & UINT64_C(18446744073709551615);
    v67=((v60 >> 2)) & UINT64_C(18446744073709551615);
    v72=(v49) & UINT64_C(4294967295);
    p0[2]=(uint32_t)(v72);
    v75=(v67) & UINT64_C(4294967295);
    v77=(v49) & UINT64_C(18446744073709551615);
    v78=((v77 >> 32)) & UINT64_C(18446744073709551615);
    v80=(v78) & UINT64_C(4294967295);
    v53=((v80 + v75)) & UINT64_C(4294967295);
    p0[0]=(uint32_t)(v53);
    record_event((uint32_t)(v54));
    v51=((v50 - UINT64_C(1))) & UINT64_C(4294967295);
    v85=((UINT64_C(1) < v51)) & UINT64_C(255);
    if(v85){incoming=1;goto b4;}else{incoming=1;goto b5;}
b5:
    if(++steps>10000u)exit(71);
    switch(incoming){
    case 0:phi88=v39;break;
    case 1:phi88=v53;break;
    default:exit(72);}
    v88=phi88;
    v89=(v88) & UINT64_C(4294967295);
    return (uint32_t)(v89);
}
