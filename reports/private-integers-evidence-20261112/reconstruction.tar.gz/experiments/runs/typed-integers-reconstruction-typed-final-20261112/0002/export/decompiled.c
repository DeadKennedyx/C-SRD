
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

uint region_pipeline(uint *p0,uint p1,int p2)

{
  uint uVar1;
  uint value;
  uint uVar2;
  uint uVar3;
  long lVar4;
  
  uVar2 = ((int)(p1 << 8) >> 0x10) + (p1 & 0xff) + (int)(char)*p0;
  uVar1 = -uVar2;
  if (-1 < (int)uVar2) {
    uVar1 = uVar2;
  }
  lVar4 = CONCAT44(p1,*p0) * 7 + -0x123456789abcdf0;
  uVar2 = (uVar2 * 3 + uVar1 + (int)((ulong)lVar4 >> 0x20)) - 4;
  record_event(uVar2);
  if (0 < p2) {
    uVar3 = p2 + 1;
    do {
      value = next_value(uVar2);
      lVar4 = (lVar4 + (ulong)value * 0x20000) * 3 + 0xb;
      p0[2] = (uint)lVar4;
      uVar2 = (int)((ulong)lVar4 >> 0x20) + (int)((ulong)uVar1 + (long)(char)value >> 2);
      *p0 = uVar2;
      record_event(value);
      uVar3 = uVar3 - 1;
    } while (1 < uVar3);
  }
  return uVar2;
}

