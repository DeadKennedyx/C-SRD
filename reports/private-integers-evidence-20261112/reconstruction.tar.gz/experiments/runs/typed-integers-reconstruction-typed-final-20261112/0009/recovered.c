#include <stdint.h>
#include <stdlib.h>
#include <limits.h>
_Static_assert(sizeof(int)==4, "32-bit int ABI required");
extern uint32_t next_value(uint32_t);
extern void record_event(uint32_t);
int32_t region_outputs(uint32_t *p0,uint32_t p1,uint32_t p2){
    unsigned steps=0, incoming=0;
    (void)p0;(void)p1;(void)p2;(void)incoming;
    uint64_t v0=0; (void)v0;
    uint64_t v2=0; (void)v2;
    uint64_t v5=0; (void)v5;
    uint64_t v6=0; (void)v6;
    uint64_t v8=0; (void)v8;
    uint64_t v9=0; (void)v9;
    uint64_t v10=0; (void)v10;
    uint64_t v12=0; (void)v12;
    uint64_t v14=0; (void)v14;
    uint64_t v15=0; (void)v15;
    uint64_t v17=0; (void)v17;
    uint64_t v18=0; (void)v18;
    uint64_t v20=0; (void)v20;
    uint64_t v22=0; (void)v22;
    uint64_t v24=0; (void)v24;
    uint64_t v26=0; (void)v26;
    uint64_t v27=0; (void)v27;
    uint64_t v28=0; (void)v28;
    uint64_t v29=0; (void)v29;
    uint64_t v31=0; (void)v31;
    uint64_t v34=0; (void)v34;
    uint64_t v36=0; (void)v36;
    uint64_t v37=0; (void)v37;
    uint64_t v38=0; (void)v38;
    uint64_t v40=0; (void)v40;
    uint64_t v42=0; (void)v42;
    uint64_t v43=0; (void)v43;
    uint64_t v44=0; (void)v44;
    uint64_t v45=0; (void)v45;
    uint64_t v47=0; (void)v47;
    uint64_t v48=0; (void)v48;
    uint64_t v49=0; (void)v49;
    uint64_t v51=0; (void)v51;
    uint64_t v52=0; (void)v52;
    uint64_t v53=0; (void)v53;
    uint64_t v65=0; (void)v65;
    uint64_t phi36=0;
    goto b0;
b0:
    if(++steps>10000u)exit(71);
    v0=(((uint64_t)(uint32_t)p2)) & UINT64_C(18446744073709551615);
    v2=(((uint64_t)(uint32_t)p1)) & UINT64_C(255);
    v5=(((v2 ^ UINT64_C(128)) - UINT64_C(128))) & UINT64_C(4294967295);
    v6=((v0 & UINT64_C(65535))) & UINT64_C(18446744073709551615);
    v8=((v5 + ((uint64_t)(uint32_t)p1))) & UINT64_C(4294967295);
    v9=(v8) & UINT64_C(18446744073709551615);
    v10=((((uint64_t)(uint32_t)p1) & UINT64_C(255))) & UINT64_C(4294967295);
    v12=((v9 << 32)) & UINT64_C(18446744073709551615);
    v14=((v6 | v12)) & UINT64_C(18446744073709551615);
    v15=((((uint64_t)(uint32_t)p2) & UINT64_C(65535))) & UINT64_C(4294967295);
    v17=((v10 + v15)) & UINT64_C(4294967295);
    v18=((v17 != UINT64_C(0))) & UINT64_C(255);
    v20=((v14 + UINT64_C(9))) & UINT64_C(18446744073709551615);
    v22=((v0 << 48)) & UINT64_C(18446744073709551615);
    v24=((((uint64_t)(uint32_t)p2) & UINT64_C(65535))) & UINT64_C(4294967295);
    v26=(v24) & UINT64_C(4294967295);
    v27=(((v5 ^ UINT64_C(2147483648)) < (v26 ^ UINT64_C(2147483648)))) & UINT64_C(255);
    v28=(v22) & UINT64_C(18446744073709551615);
    v29=(((v28 >> 51) | ((UINT64_C(0) - (v28 >> 63)) << 13))) & UINT64_C(18446744073709551615);
    v31=(v29) & UINT64_C(4294967295);
    if(v27){incoming=0;goto b1;}else{incoming=0;goto b2;}
b1:
    if(++steps>10000u)exit(71);
    v34=((v31 + UINT64_C(1))) & UINT64_C(4294967295);
    incoming=1;goto b2;
b2:
    if(++steps>10000u)exit(71);
    switch(incoming){
    case 0:phi36=v31;break;
    case 1:phi36=v34;break;
    default:exit(72);}
    v36=phi36;
    v37=(v20) & UINT64_C(18446744073709551615);
    v38=((v37 >> 32)) & UINT64_C(18446744073709551615);
    v40=(v38) & UINT64_C(4294967295);
    v42=(v18) & UINT64_C(4294967295);
    v43=((v42 + v40)) & UINT64_C(4294967295);
    v44=((v43 + v36)) & UINT64_C(4294967295);
    v45=(((uint64_t)(uint32_t)p2)) & UINT64_C(65535);
    v47=(((v45 ^ UINT64_C(32768)) - UINT64_C(32768))) & UINT64_C(4294967295);
    v48=(v24) & UINT64_C(4294967295);
    v49=(((v5 ^ UINT64_C(2147483648)) < (v48 ^ UINT64_C(2147483648)))) & UINT64_C(255);
    record_event((uint32_t)(v44));
    v51=(v49) & UINT64_C(4294967295);
    v52=((v51 == v42)) & UINT64_C(255);
    v53=(v20) & UINT64_C(4294967295);
    p0[0]=(uint32_t)(v53);
    p0[1]=(uint32_t)(v44);
    p0[2]=(uint32_t)(v47);
    v65=(v52) & UINT64_C(4294967295);
    {uint32_t r=(uint32_t)(v65);
    return r<=INT32_MAX?(int32_t)r:INT32_MIN+(int32_t)(r-UINT32_C(2147483648));}
}
