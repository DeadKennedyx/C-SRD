
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int region_outputs(uint *p0,uint p1,uint p2)

{
  long lVar1;
  uint value;
  int iVar2;
  int iVar3;
  uint uVar4;
  
  iVar2 = (int)(char)p1;
  lVar1 = ((ulong)p2 & 0xffff | (ulong)(iVar2 + p1) << 0x20) + 9;
  iVar3 = (int)((long)((ulong)p2 << 0x30) >> 0x33);
  if (iVar2 < (int)(p2 & 0xffff)) {
    iVar3 = iVar3 + 1;
  }
  uVar4 = (uint)((p1 & 0xff) + (p2 & 0xffff) != 0);
  value = uVar4 + (int)((ulong)lVar1 >> 0x20) + iVar3;
  record_event(value);
  *p0 = (uint)lVar1;
  p0[1] = value;
  p0[2] = (int)(short)p2;
  return (int)(iVar2 < (int)(p2 & 0xffff) == uVar4);
}

