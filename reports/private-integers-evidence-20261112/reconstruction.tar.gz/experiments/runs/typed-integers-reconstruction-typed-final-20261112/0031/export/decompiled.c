
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

uint region_pipeline(uint *p0,uint p1,int p2)

{
  uint uVar1;
  ulong uVar2;
  long lVar3;
  int iVar4;
  int iVar5;
  int iVar6;
  uint value;
  ulong uVar7;
  int local_3a0;
  uint local_37c;
  long local_368;
  
  uVar2 = (ulong)p1 * 0x487e86a1 + 0x72f86ab4;
  uVar7 = uVar2 & 0xffffffff;
  uVar1 = *p0 * 0x487e86a1 + 0x72f86ab4;
  uVar2 = ((((((uVar2 & 0xff) * 0x61 - 0x4434 & 0xff) * 0x487e86a1 + 0x72f86ab4 & 0xffffffff) +
            ((long)(char)((char)uVar1 * 'a' + -0x34) * 0x487e86a1 + 0x72f86ab4U & 0xffffffff)) -
            0x72f86ab4 & 0xffffffff) +
          ((long)(short)(((short)(uVar7 * 0x3c16dd61 + 0xa04a2dcc >> 8) * -0x795f + 0x6ab4) *
                         -0x229f + 0x2dcc) * 0x487e86a1 + 0x72f86ab4U & 0xffffffff)) - 0x72f86ab4;
  iVar5 = (int)uVar2;
  iVar4 = iVar5 * 0x3c16dd61;
  lVar3 = ((((((uVar7 * 0x3c16dd61 + 0xa04a2dcc & 0xffffffff) * -0x9d8a0fab781795f +
              0x78ae01d72f86ab4) * -0x7c9b2b22c3e9229f + 0x544c60d7a04a2dcc) * 0x487e86a100000000 +
            0x78ae01d72f86ab4) * -0x7c9b2b22c3e9229f + 0x544c60d7a04a2dcc |
           (((ulong)uVar1 * 0x3c16dd61 + 0xa04a2dcc & 0xffffffff) * -0x9d8a0fab781795f +
           0x78ae01d72f86ab4) * -0x7c9b2b22c3e9229f + 0x544c60d7a04a2dcc) * -0x9d8a0fab781795f +
          0x78ae01d72f86ab4) * 7 + -0x13c9430910caa428;
  if (((uVar2 & 0xffffffff) * 0x3c16dd61 + 0xa04a2dcc & 0xffffffff ^ 0x80000000) < 0x80000000) {
    iVar6 = -0x44890eab;
  }
  else {
    iVar6 = 0x72f86ab4;
  }
  if (((uint)(iVar6 * 0x3c16dd61 != 0x5fb5d234) * 0x487e86a1 + 0x72f86ab4) * 0x3c16dd61 !=
      0x5fb5d234) {
    iVar5 = -0x1a0f2a98 - iVar5;
  }
  local_368 = lVar3 * -0x7c9b2b22c3e9229f + 0x544c60d7a04a2dcc;
  local_37c = ((int)((ulong)(lVar3 * -0x7c9b2b22c3e9229f + 0x544c60d7a04a2dcc) >> 0x20) * 0x487e86a1
               + ((iVar4 + -0x5fb5d234) * 0x487e86a1 + 0x72f86ab4) * 3 + iVar5 + -0x7ae35aa0) *
              0x3c16dd61 + 0xa04a2dcc;
  record_event(local_37c);
  local_3a0 = p2;
  if (-1 < p2) {
    for (; 0 < local_3a0; local_3a0 = local_3a0 + -1) {
      value = next_value(local_37c);
      uVar1 = value * 0xe648b75 + 0x4b7cd876;
      lVar3 = (local_368 * 0x21f8d5330e648b75 +
               ((((ulong)uVar1 * 0x6c5dacdd + 0x88ebda22 & 0xffffffff) * 0x21f8d5330e648b75 +
                0x792520724b7cd876) * 0x40c5c4b16c5dacdd + -0x6211e6a5771425de) *
               -0x5599e336e9160000 + 0x792520724b7cd876) * 3 + -0x7c9917b2f8a7b2e5;
      local_368 = lVar3 * 0x40c5c4b16c5dacdd + -0x6211e6a5771425de;
      local_37c = ((int)((ulong)(lVar3 * 0x40c5c4b16c5dacdd + -0x6211e6a5771425de) >> 0x20) *
                   0xe648b75 +
                  (int)(((long)(((char)((char)uVar1 * -0x23 + '\"') * 0xe648b75 + 0x4b7cd876) *
                                0x6c5dacdd + -0x771425de) * 0x21f8d5330e648b75 +
                         (long)(((iVar5 * 0x3c16dd61 + -0x5fb5d234) * 0xe648b75 + 0x4b7cd876) *
                                0x6c5dacdd + -0x771425de) * 0x21f8d5330e648b75 + 0x792520724b7cd876)
                        * 0x40c5c4b16c5dacdd + -0x6211e6a5771425de >> 2) * 0xe648b75 + 0x4b7cd876) *
                  0x6c5dacdd + 0x88ebda22;
      *p0 = local_37c;
      p0[2] = (uint)local_368;
      record_event(value);
    }
  }
  return local_37c;
}

