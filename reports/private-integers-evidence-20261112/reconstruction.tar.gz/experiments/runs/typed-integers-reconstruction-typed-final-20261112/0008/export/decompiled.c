
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

uint region_pipeline(uint *p0,uint p1,int p2)

{
  int iVar1;
  uint uVar2;
  uint value;
  uint value_00;
  int iVar3;
  int iVar4;
  int iVar5;
  long lVar6;
  
  uVar2 = p1 * 0x487e86a1 + 0x72f86ab4;
  iVar5 = uVar2 * 0x3c16dd61 + -0x5fb5d234;
  iVar1 = *p0 * 0x487e86a1 + 0x72f86ab4;
  iVar3 = ((((uVar2 * 2 & 0x1fe) + (uVar2 & 0xff)) * 0x20 + (uVar2 & 0xff)) - 0x4434 & 0xff) *
          0x487e86a1 + 0x72f86ab4 + (char)((char)iVar1 * 'a' + -0x34) * 0x487e86a1 +
          (short)(((short)((uint)iVar5 >> 8) * -0x795f + 0x6ab4) * -0x229f + 0x2dcc) * 0x487e86a1;
  uVar2 = iVar3 * 0x3c16dd61 + 0xa04a2dcc;
  iVar4 = uVar2 * -0x26846c1d;
  if ((uVar2 ^ 0x80000000) < 0x80000000) {
    iVar3 = -0x1a0f2a98 - iVar3;
    uVar2 = iVar3 * 0x3c16dd61 + 0xa04a2dcc;
  }
  lVar6 = CONCAT44(iVar5,iVar1 * 0x3c16dd61 + -0x5fb5d234) * 7 + -0x123456789abcdf0;
  value = ((int)((ulong)lVar6 >> 0x20) * 0x487e86a1 + iVar4 + -0x21fa1a84 + iVar3) * 0x3c16dd61 +
          0xa04a2dcc;
  record_event(value);
  if (0 < p2) {
    do {
      value_00 = next_value(value);
      iVar3 = value_00 * 0xe648b75 + 0x4b7cd876;
      lVar6 = ((ulong)(iVar3 * 0x6c5dacdd + 0x88ebda22) * -0x5599e336e9160000 + -0xdb5bf1b69064f14 +
              lVar6 * 0x21f8d5330e648b75) * -0x3daeb1ebbae6f969 + -0x4c6b67e0ca78e329;
      p0[2] = (uint)lVar6;
      value = ((int)((ulong)lVar6 >> 0x20) * 0xe648b75 +
              (int)((long)(int)((uVar2 * 0xe648b75 + 0x4b7cd876) * 0x6c5dacdd + -0x771425de) +
                    (long)(((char)((char)iVar3 * -0x23 + '\"') * 0xe648b75 + 0x4b7cd876) *
                           0x6c5dacdd + -0x771425de) >> 2) * 0xe648b75 + 0x4b7cd876) * 0x6c5dacdd +
              0x88ebda22;
      *p0 = value;
      record_event(value_00);
      p2 = p2 + -1;
    } while (p2 != 0);
  }
  return value;
}

