
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

uint region_pipeline(uint *p0,uint p1,int p2)

{
  int iVar1;
  uint uVar2;
  uint value;
  int local_3a0;
  uint local_37c;
  long local_368;
  
  uVar2 = (p1 & 0xff) + (int)(char)*p0 + (int)(short)(p1 >> 8);
  iVar1 = uVar2 * 3;
  local_368 = CONCAT44(p1,*p0) * 7 + -0x123456789abcdf0;
  if ((uVar2 ^ 0x80000000) < 0x80000000) {
    uVar2 = -uVar2;
  }
  local_37c = (int)((ulong)local_368 >> 0x20) + iVar1 + -4 + uVar2;
  record_event(local_37c);
  local_3a0 = p2;
  if (-1 < p2) {
    for (; 0 < local_3a0; local_3a0 = local_3a0 + -1) {
      value = next_value(local_37c);
      local_368 = (local_368 + (ulong)value * 0x20000) * 3 + 0xb;
      local_37c = (int)((ulong)local_368 >> 0x20) +
                  (int)((long)(int)(char)value + (long)(int)uVar2 >> 2);
      *p0 = local_37c;
      p0[2] = (uint)local_368;
      record_event(value);
    }
  }
  return local_37c;
}

