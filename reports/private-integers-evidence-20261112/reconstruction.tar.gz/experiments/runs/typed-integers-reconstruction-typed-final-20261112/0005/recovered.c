#include <stdint.h>
#include <stdlib.h>
#include <limits.h>
_Static_assert(sizeof(int)==4, "32-bit int ABI required");
extern uint32_t next_value(uint32_t);
extern void record_event(uint32_t);
uint32_t region_pipeline(uint32_t *p0,uint32_t p1,int32_t p2){
    unsigned steps=0, incoming=0;
    (void)p0;(void)p1;(void)p2;(void)incoming;
    uint64_t v0=0; (void)v0;
    uint64_t v3=0; (void)v3;
    uint64_t v6=0; (void)v6;
    uint64_t v8=0; (void)v8;
    uint64_t v9=0; (void)v9;
    uint64_t v10=0; (void)v10;
    uint64_t v12=0; (void)v12;
    uint64_t v14=0; (void)v14;
    uint64_t v15=0; (void)v15;
    uint64_t v16=0; (void)v16;
    uint64_t v18=0; (void)v18;
    uint64_t v20=0; (void)v20;
    uint64_t v21=0; (void)v21;
    uint64_t v23=0; (void)v23;
    uint64_t v25=0; (void)v25;
    uint64_t v27=0; (void)v27;
    uint64_t v29=0; (void)v29;
    uint64_t v31=0; (void)v31;
    uint64_t v33=0; (void)v33;
    uint64_t v34=0; (void)v34;
    uint64_t v35=0; (void)v35;
    uint64_t v37=0; (void)v37;
    uint64_t v39=0; (void)v39;
    uint64_t v40=0; (void)v40;
    uint64_t v42=0; (void)v42;
    uint64_t v45=0; (void)v45;
    uint64_t v46=0; (void)v46;
    uint64_t v48=0; (void)v48;
    uint64_t v50=0; (void)v50;
    uint64_t v52=0; (void)v52;
    uint64_t v54=0; (void)v54;
    uint64_t v56=0; (void)v56;
    uint64_t v59=0; (void)v59;
    uint64_t v61=0; (void)v61;
    uint64_t v62=0; (void)v62;
    uint64_t v64=0; (void)v64;
    uint64_t v65=0; (void)v65;
    uint64_t v66=0; (void)v66;
    uint64_t v67=0; (void)v67;
    uint64_t v68=0; (void)v68;
    uint64_t v69=0; (void)v69;
    uint64_t v71=0; (void)v71;
    uint64_t v72=0; (void)v72;
    uint64_t v49=0; (void)v49;
    uint64_t v75=0; (void)v75;
    uint64_t v77=0; (void)v77;
    uint64_t v79=0; (void)v79;
    uint64_t v80=0; (void)v80;
    uint64_t v82=0; (void)v82;
    uint64_t v51=0; (void)v51;
    uint64_t v88=0; (void)v88;
    uint64_t v53=0; (void)v53;
    uint64_t v92=0; (void)v92;
    uint64_t v93=0; (void)v93;
    uint64_t phi33=0;
    uint64_t phi48=0;
    uint64_t phi50=0;
    uint64_t phi52=0;
    uint64_t phi92=0;
    goto b0;
b0:
    if(++steps>10000u)exit(71);
    v0=(p0[0]) & UINT64_C(4294967295);
    v3=((((uint64_t)(uint32_t)p1) & UINT64_C(255))) & UINT64_C(4294967295);
    v6=(v0) & UINT64_C(255);
    v8=(((v6 ^ UINT64_C(128)) - UINT64_C(128))) & UINT64_C(4294967295);
    v9=((v3 + v8)) & UINT64_C(4294967295);
    v10=((((uint64_t)(uint32_t)p1) >> 8)) & UINT64_C(4294967295);
    v12=(v10) & UINT64_C(65535);
    v14=(((v12 ^ UINT64_C(32768)) - UINT64_C(32768))) & UINT64_C(4294967295);
    v15=((v9 + v14)) & UINT64_C(4294967295);
    v16=((v15 * UINT64_C(3))) & UINT64_C(4294967295);
    v18=((v16 + UINT64_C(4294967292))) & UINT64_C(4294967295);
    v20=(((((uint64_t)(uint32_t)p1) << 32) | v0)) & UINT64_C(18446744073709551615);
    v21=((v20 * UINT64_C(7))) & UINT64_C(18446744073709551615);
    v23=((v21 + UINT64_C(18364758544493064720))) & UINT64_C(18446744073709551615);
    v25=((v15 ^ UINT64_C(2147483648))) & UINT64_C(4294967295);
    v27=((v25 < UINT64_C(2147483648))) & UINT64_C(255);
    v29=((UINT64_C(0) - v15)) & UINT64_C(4294967295);
    if(v27){incoming=0;goto b1;}else{incoming=1;goto b2;}
b1:
    if(++steps>10000u)exit(71);
    v31=(v29) & UINT64_C(4294967295);
    incoming=0;goto b2;
b2:
    if(++steps>10000u)exit(71);
    switch(incoming){
    case 0:phi33=v31;break;
    case 1:phi33=v15;break;
    default:exit(72);}
    v33=phi33;
    v34=(v23) & UINT64_C(18446744073709551615);
    v35=((v34 >> 32)) & UINT64_C(18446744073709551615);
    v37=(v35) & UINT64_C(4294967295);
    v39=((v37 + v18)) & UINT64_C(4294967295);
    v40=((v39 + v33)) & UINT64_C(4294967295);
    record_event((uint32_t)(v40));
    v42=(((UINT64_C(4294967295) ^ UINT64_C(2147483648)) < (((uint64_t)(uint32_t)p2) ^ UINT64_C(2147483648)))) & UINT64_C(255);
    v45=(((uint64_t)(uint32_t)p2)) & UINT64_C(4294967295);
    v46=(v45) & UINT64_C(4294967295);
    if(v42){incoming=0;goto b3;}else{incoming=1;goto b5;}
b3:
    if(++steps>10000u)exit(71);
    switch(incoming){
    case 0:phi48=v23;break;
    case 1:phi48=v49;break;
    default:exit(72);}
    switch(incoming){
    case 0:phi50=v40;break;
    case 1:phi50=v51;break;
    default:exit(72);}
    switch(incoming){
    case 0:phi52=v46;break;
    case 1:phi52=v53;break;
    default:exit(72);}
    v48=phi48;
    v50=phi50;
    v52=phi52;
    v54=((v52 + UINT64_C(4294967295))) & UINT64_C(4294967295);
    v56=(((UINT64_C(0) ^ UINT64_C(2147483648)) < (v52 ^ UINT64_C(2147483648)))) & UINT64_C(255);
    if(v56){incoming=0;goto b4;}else{incoming=0;goto b5;}
b4:
    if(++steps>10000u)exit(71);
    v59=(next_value((uint32_t)(v50))) & UINT64_C(4294967295);
    v61=(v59) & UINT64_C(18446744073709551615);
    v62=(v59) & UINT64_C(255);
    v64=(((v62 ^ UINT64_C(128)) - UINT64_C(128))) & UINT64_C(4294967295);
    v65=(((v64 ^ UINT64_C(2147483648)) - UINT64_C(2147483648))) & UINT64_C(18446744073709551615);
    v66=(v33) & UINT64_C(4294967295);
    v67=(((v66 ^ UINT64_C(2147483648)) - UINT64_C(2147483648))) & UINT64_C(18446744073709551615);
    v68=((v65 + v67)) & UINT64_C(18446744073709551615);
    v69=((v61 * UINT64_C(131072))) & UINT64_C(18446744073709551615);
    v71=((v48 + v69)) & UINT64_C(18446744073709551615);
    v72=((v71 * UINT64_C(3))) & UINT64_C(18446744073709551615);
    v49=((v72 + UINT64_C(11))) & UINT64_C(18446744073709551615);
    v75=(((v68 >> 2) | ((UINT64_C(0) - (v68 >> 63)) << 62))) & UINT64_C(18446744073709551615);
    v77=(v75) & UINT64_C(4294967295);
    v79=(v49) & UINT64_C(18446744073709551615);
    v80=((v79 >> 32)) & UINT64_C(18446744073709551615);
    v82=(v80) & UINT64_C(4294967295);
    v51=((v82 + v77)) & UINT64_C(4294967295);
    p0[0]=(uint32_t)(v51);
    v88=(v49) & UINT64_C(4294967295);
    p0[2]=(uint32_t)(v88);
    record_event((uint32_t)(v59));
    v53=(v54) & UINT64_C(4294967295);
    incoming=1;goto b3;
b5:
    if(++steps>10000u)exit(71);
    switch(incoming){
    case 0:phi92=v50;break;
    case 1:phi92=v40;break;
    default:exit(72);}
    v92=phi92;
    v93=(v92) & UINT64_C(4294967295);
    return (uint32_t)(v93);
}
