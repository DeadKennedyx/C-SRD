
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

uint region_pipeline(uint *p0,uint p1,int p2)

{
  uint uVar1;
  uint value;
  uint uVar2;
  uint uVar3;
  long lVar4;
  
  uVar3 = (int)(short)(p1 >> 8) + (p1 & 0xff) + (int)(char)*p0;
  lVar4 = CONCAT44(p1,*p0) * 7 + -0x123456789abcdf0;
  uVar1 = -uVar3;
  if (((ulong)uVar3 ^ 0x80000000) >> 0x1f != 0) {
    uVar1 = uVar3;
  }
  uVar3 = ((int)((ulong)lVar4 >> 0x20) + uVar3 * 3 + uVar1) - 4;
  record_event(uVar3);
  if (0 < p2) {
    uVar2 = p2 + 1;
    do {
      value = next_value(uVar3);
      lVar4 = (lVar4 + (ulong)value * 0x20000) * 3 + 0xb;
      p0[2] = (uint)lVar4;
      uVar3 = (int)((ulong)lVar4 >> 0x20) +
              (int)((ulong)((long)(int)uVar1 + (long)(char)value) >> 2);
      *p0 = uVar3;
      record_event(value);
      uVar2 = uVar2 - 1;
    } while (1 < uVar2);
  }
  return uVar3;
}

