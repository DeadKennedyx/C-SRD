#include <stdint.h>
#include <stdlib.h>
#include <limits.h>
_Static_assert(sizeof(int)==4, "32-bit int ABI required");
extern uint32_t next_value(uint32_t);
extern void record_event(uint32_t);
uint32_t region_pipeline(uint32_t *p0,uint32_t p1,int32_t p2){
    unsigned steps=0, incoming=0;
    (void)p0;(void)p1;(void)p2;(void)incoming;
    uint64_t v0=0; (void)v0;
    uint64_t v3=0; (void)v3;
    uint64_t v6=0; (void)v6;
    uint64_t v8=0; (void)v8;
    uint64_t v9=0; (void)v9;
    uint64_t v11=0; (void)v11;
    uint64_t v12=0; (void)v12;
    uint64_t v13=0; (void)v13;
    uint64_t v15=0; (void)v15;
    uint64_t v16=0; (void)v16;
    uint64_t v17=0; (void)v17;
    uint64_t v19=0; (void)v19;
    uint64_t v20=0; (void)v20;
    uint64_t v22=0; (void)v22;
    uint64_t v24=0; (void)v24;
    uint64_t v26=0; (void)v26;
    uint64_t v28=0; (void)v28;
    uint64_t v29=0; (void)v29;
    uint64_t v31=0; (void)v31;
    uint64_t v33=0; (void)v33;
    uint64_t v34=0; (void)v34;
    uint64_t v35=0; (void)v35;
    uint64_t v36=0; (void)v36;
    uint64_t v38=0; (void)v38;
    uint64_t v40=0; (void)v40;
    uint64_t v41=0; (void)v41;
    uint64_t v42=0; (void)v42;
    uint64_t v45=0; (void)v45;
    uint64_t v49=0; (void)v49;
    uint64_t v50=0; (void)v50;
    uint64_t v51=0; (void)v51;
    uint64_t v53=0; (void)v53;
    uint64_t v55=0; (void)v55;
    uint64_t v57=0; (void)v57;
    uint64_t v59=0; (void)v59;
    uint64_t v61=0; (void)v61;
    uint64_t v62=0; (void)v62;
    uint64_t v64=0; (void)v64;
    uint64_t v65=0; (void)v65;
    uint64_t v67=0; (void)v67;
    uint64_t v68=0; (void)v68;
    uint64_t v69=0; (void)v69;
    uint64_t v71=0; (void)v71;
    uint64_t v72=0; (void)v72;
    uint64_t v54=0; (void)v54;
    uint64_t v78=0; (void)v78;
    uint64_t v81=0; (void)v81;
    uint64_t v83=0; (void)v83;
    uint64_t v84=0; (void)v84;
    uint64_t v86=0; (void)v86;
    uint64_t v56=0; (void)v56;
    uint64_t v58=0; (void)v58;
    uint64_t v91=0; (void)v91;
    uint64_t v94=0; (void)v94;
    uint64_t v95=0; (void)v95;
    uint64_t phi34=0;
    uint64_t phi53=0;
    uint64_t phi55=0;
    uint64_t phi57=0;
    uint64_t phi94=0;
    goto b0;
b0:
    if(++steps>10000u)exit(71);
    v0=(p0[0]) & UINT64_C(4294967295);
    v3=((((uint64_t)(uint32_t)p1) >> 8)) & UINT64_C(4294967295);
    v6=(v3) & UINT64_C(65535);
    v8=(((v6 ^ UINT64_C(32768)) - UINT64_C(32768))) & UINT64_C(4294967295);
    v9=((((uint64_t)(uint32_t)p1) & UINT64_C(255))) & UINT64_C(4294967295);
    v11=((v8 + v9)) & UINT64_C(4294967295);
    v12=(((((uint64_t)(uint32_t)p1) << 32) | v0)) & UINT64_C(18446744073709551615);
    v13=(v0) & UINT64_C(255);
    v15=(((v13 ^ UINT64_C(128)) - UINT64_C(128))) & UINT64_C(4294967295);
    v16=((v11 + v15)) & UINT64_C(4294967295);
    v17=((v12 * UINT64_C(7))) & UINT64_C(18446744073709551615);
    v19=(v16) & UINT64_C(18446744073709551615);
    v20=((v19 ^ UINT64_C(2147483648))) & UINT64_C(18446744073709551615);
    v22=((v17 + UINT64_C(18364758544493064720))) & UINT64_C(18446744073709551615);
    v24=((v20 >> 31)) & UINT64_C(18446744073709551615);
    v26=((v16 * UINT64_C(3))) & UINT64_C(4294967295);
    v28=((UINT64_C(0) - v16)) & UINT64_C(4294967295);
    v29=((v24 != UINT64_C(0))) & UINT64_C(255);
    v31=(v28) & UINT64_C(4294967295);
    if(v29){incoming=0;goto b1;}else{incoming=0;goto b2;}
b1:
    if(++steps>10000u)exit(71);
    v33=(v16) & UINT64_C(4294967295);
    incoming=1;goto b2;
b2:
    if(++steps>10000u)exit(71);
    switch(incoming){
    case 0:phi34=v31;break;
    case 1:phi34=v33;break;
    default:exit(72);}
    v34=phi34;
    v35=(v22) & UINT64_C(18446744073709551615);
    v36=((v35 >> 32)) & UINT64_C(18446744073709551615);
    v38=(v36) & UINT64_C(4294967295);
    v40=((v38 + v26)) & UINT64_C(4294967295);
    v41=((v40 + v34)) & UINT64_C(4294967295);
    v42=((v41 - UINT64_C(4))) & UINT64_C(4294967295);
    record_event((uint32_t)(v42));
    v45=(((UINT64_C(0) ^ UINT64_C(2147483648)) < (((uint64_t)(uint32_t)p2) ^ UINT64_C(2147483648)))) & UINT64_C(255);
    if(v45){incoming=0;goto b3;}else{incoming=0;goto b5;}
b3:
    if(++steps>10000u)exit(71);
    v49=(v34) & UINT64_C(4294967295);
    v50=(((v49 ^ UINT64_C(2147483648)) - UINT64_C(2147483648))) & UINT64_C(18446744073709551615);
    v51=((((uint64_t)(uint32_t)p2) + UINT64_C(1))) & UINT64_C(4294967295);
    incoming=0;goto b4;
b4:
    if(++steps>10000u)exit(71);
    switch(incoming){
    case 0:phi53=v22;break;
    case 1:phi53=v54;break;
    default:exit(72);}
    switch(incoming){
    case 0:phi55=v42;break;
    case 1:phi55=v56;break;
    default:exit(72);}
    switch(incoming){
    case 0:phi57=v51;break;
    case 1:phi57=v58;break;
    default:exit(72);}
    v53=phi53;
    v55=phi55;
    v57=phi57;
    v59=(next_value((uint32_t)(v55))) & UINT64_C(4294967295);
    v61=(v59) & UINT64_C(18446744073709551615);
    v62=((v61 * UINT64_C(131072))) & UINT64_C(18446744073709551615);
    v64=((v53 + v62)) & UINT64_C(18446744073709551615);
    v65=(v59) & UINT64_C(255);
    v67=(((v65 ^ UINT64_C(128)) - UINT64_C(128))) & UINT64_C(18446744073709551615);
    v68=((v50 + v67)) & UINT64_C(18446744073709551615);
    v69=((v64 * UINT64_C(3))) & UINT64_C(18446744073709551615);
    v71=(v68) & UINT64_C(18446744073709551615);
    v72=((v71 >> 2)) & UINT64_C(18446744073709551615);
    v54=((v69 + UINT64_C(11))) & UINT64_C(18446744073709551615);
    v78=(v54) & UINT64_C(4294967295);
    p0[2]=(uint32_t)(v78);
    v81=(v72) & UINT64_C(4294967295);
    v83=(v54) & UINT64_C(18446744073709551615);
    v84=((v83 >> 32)) & UINT64_C(18446744073709551615);
    v86=(v84) & UINT64_C(4294967295);
    v56=((v86 + v81)) & UINT64_C(4294967295);
    p0[0]=(uint32_t)(v56);
    record_event((uint32_t)(v59));
    v58=((v57 - UINT64_C(1))) & UINT64_C(4294967295);
    v91=((UINT64_C(1) < v58)) & UINT64_C(255);
    if(v91){incoming=1;goto b4;}else{incoming=1;goto b5;}
b5:
    if(++steps>10000u)exit(71);
    switch(incoming){
    case 0:phi94=v42;break;
    case 1:phi94=v56;break;
    default:exit(72);}
    v94=phi94;
    v95=(v94) & UINT64_C(4294967295);
    return (uint32_t)(v95);
}
