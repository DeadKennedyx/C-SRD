
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

uint region_pipeline(uint *p0,uint p1,int p2)

{
  int iVar1;
  int iVar2;
  uint value;
  uint value_00;
  long lVar3;
  
  lVar3 = CONCAT44(p1,*p0) * 7 + -0x123456789abcdf0;
  iVar1 = (int)(char)*p0 + (p1 & 0xff) + (int)(short)(p1 >> 8);
  iVar2 = -iVar1;
  if (-1 < iVar1) {
    iVar2 = iVar1;
  }
  value_00 = (iVar2 + (int)((ulong)lVar3 >> 0x20) + iVar1 * 3) - 4;
  record_event(value_00);
  if (0 < p2) {
    do {
      value = next_value(value_00);
      lVar3 = ((ulong)value * 0x20000 + lVar3) * 3 + 0xb;
      p0[2] = (uint)lVar3;
      value_00 = (int)((long)iVar2 + (long)(char)value >> 2) + (int)((ulong)lVar3 >> 0x20);
      *p0 = value_00;
      record_event(value);
      p2 = p2 + -1;
    } while (p2 != 0);
  }
  return value_00;
}

