#include <stdint.h>
#include <stdlib.h>
#include <limits.h>
_Static_assert(sizeof(int)==4, "32-bit int ABI required");
extern uint32_t next_value(uint32_t);
extern void record_event(uint32_t);
uint32_t region_pipeline(uint32_t *p0,uint32_t p1,int32_t p2){
    unsigned steps=0, incoming=0;
    (void)p0;(void)p1;(void)p2;(void)incoming;
    uint64_t v0=0; (void)v0;
    uint64_t v3=0; (void)v3;
    uint64_t v5=0; (void)v5;
    uint64_t v7=0; (void)v7;
    uint64_t v8=0; (void)v8;
    uint64_t v10=0; (void)v10;
    uint64_t v12=0; (void)v12;
    uint64_t v13=0; (void)v13;
    uint64_t v15=0; (void)v15;
    uint64_t v17=0; (void)v17;
    uint64_t v19=0; (void)v19;
    uint64_t v20=0; (void)v20;
    uint64_t v21=0; (void)v21;
    uint64_t v23=0; (void)v23;
    uint64_t v24=0; (void)v24;
    uint64_t v26=0; (void)v26;
    uint64_t v27=0; (void)v27;
    uint64_t v28=0; (void)v28;
    uint64_t v29=0; (void)v29;
    uint64_t v31=0; (void)v31;
    uint64_t v33=0; (void)v33;
    uint64_t v34=0; (void)v34;
    uint64_t v36=0; (void)v36;
    uint64_t v37=0; (void)v37;
    uint64_t v40=0; (void)v40;
    uint64_t v44=0; (void)v44;
    uint64_t v45=0; (void)v45;
    uint64_t v47=0; (void)v47;
    uint64_t v49=0; (void)v49;
    uint64_t v51=0; (void)v51;
    uint64_t v53=0; (void)v53;
    uint64_t v54=0; (void)v54;
    uint64_t v56=0; (void)v56;
    uint64_t v58=0; (void)v58;
    uint64_t v59=0; (void)v59;
    uint64_t v60=0; (void)v60;
    uint64_t v61=0; (void)v61;
    uint64_t v63=0; (void)v63;
    uint64_t v48=0; (void)v48;
    uint64_t v69=0; (void)v69;
    uint64_t v72=0; (void)v72;
    uint64_t v73=0; (void)v73;
    uint64_t v75=0; (void)v75;
    uint64_t v77=0; (void)v77;
    uint64_t v50=0; (void)v50;
    uint64_t v46=0; (void)v46;
    uint64_t v82=0; (void)v82;
    uint64_t v85=0; (void)v85;
    uint64_t v86=0; (void)v86;
    uint64_t phi27=0;
    uint64_t phi45=0;
    uint64_t phi47=0;
    uint64_t phi49=0;
    uint64_t phi85=0;
    goto b0;
b0:
    if(++steps>10000u)exit(71);
    v0=(p0[0]) & UINT64_C(4294967295);
    v3=(((((uint64_t)(uint32_t)p1) << 32) | v0)) & UINT64_C(18446744073709551615);
    v5=(v0) & UINT64_C(255);
    v7=(((v5 ^ UINT64_C(128)) - UINT64_C(128))) & UINT64_C(4294967295);
    v8=((v3 * UINT64_C(7))) & UINT64_C(18446744073709551615);
    v10=((((uint64_t)(uint32_t)p1) & UINT64_C(255))) & UINT64_C(4294967295);
    v12=((v7 + v10)) & UINT64_C(4294967295);
    v13=((v8 + UINT64_C(18364758544493064720))) & UINT64_C(18446744073709551615);
    v15=((((uint64_t)(uint32_t)p1) >> 8)) & UINT64_C(4294967295);
    v17=(v15) & UINT64_C(65535);
    v19=(((v17 ^ UINT64_C(32768)) - UINT64_C(32768))) & UINT64_C(4294967295);
    v20=((v12 + v19)) & UINT64_C(4294967295);
    v21=(((UINT64_C(4294967295) ^ UINT64_C(2147483648)) < (v20 ^ UINT64_C(2147483648)))) & UINT64_C(255);
    v23=((UINT64_C(0) - v20)) & UINT64_C(4294967295);
    v24=(v23) & UINT64_C(4294967295);
    if(v21){incoming=0;goto b1;}else{incoming=0;goto b2;}
b1:
    if(++steps>10000u)exit(71);
    v26=(v20) & UINT64_C(4294967295);
    incoming=1;goto b2;
b2:
    if(++steps>10000u)exit(71);
    switch(incoming){
    case 0:phi27=v24;break;
    case 1:phi27=v26;break;
    default:exit(72);}
    v27=phi27;
    v28=(v13) & UINT64_C(18446744073709551615);
    v29=((v28 >> 32)) & UINT64_C(18446744073709551615);
    v31=(v29) & UINT64_C(4294967295);
    v33=((v27 + v31)) & UINT64_C(4294967295);
    v34=((v20 * UINT64_C(3))) & UINT64_C(4294967295);
    v36=((v33 + v34)) & UINT64_C(4294967295);
    v37=((v36 - UINT64_C(4))) & UINT64_C(4294967295);
    record_event((uint32_t)(v37));
    v40=(((UINT64_C(0) ^ UINT64_C(2147483648)) < (((uint64_t)(uint32_t)p2) ^ UINT64_C(2147483648)))) & UINT64_C(255);
    if(v40){incoming=0;goto b3;}else{incoming=0;goto b5;}
b3:
    if(++steps>10000u)exit(71);
    v44=(((v27 ^ UINT64_C(2147483648)) - UINT64_C(2147483648))) & UINT64_C(18446744073709551615);
    incoming=0;goto b4;
b4:
    if(++steps>10000u)exit(71);
    switch(incoming){
    case 0:phi45=((uint64_t)(uint32_t)p2);break;
    case 1:phi45=v46;break;
    default:exit(72);}
    switch(incoming){
    case 0:phi47=v13;break;
    case 1:phi47=v48;break;
    default:exit(72);}
    switch(incoming){
    case 0:phi49=v37;break;
    case 1:phi49=v50;break;
    default:exit(72);}
    v45=phi45;
    v47=phi47;
    v49=phi49;
    v51=(next_value((uint32_t)(v49))) & UINT64_C(4294967295);
    v53=(v51) & UINT64_C(18446744073709551615);
    v54=((v53 * UINT64_C(131072))) & UINT64_C(18446744073709551615);
    v56=(v51) & UINT64_C(255);
    v58=(((v56 ^ UINT64_C(128)) - UINT64_C(128))) & UINT64_C(18446744073709551615);
    v59=((v44 + v58)) & UINT64_C(18446744073709551615);
    v60=((v54 + v47)) & UINT64_C(18446744073709551615);
    v61=(((v59 >> 2) | ((UINT64_C(0) - (v59 >> 63)) << 62))) & UINT64_C(18446744073709551615);
    v63=((v60 * UINT64_C(3))) & UINT64_C(18446744073709551615);
    v48=((v63 + UINT64_C(11))) & UINT64_C(18446744073709551615);
    v69=(v48) & UINT64_C(4294967295);
    p0[2]=(uint32_t)(v69);
    v72=(v48) & UINT64_C(18446744073709551615);
    v73=((v72 >> 32)) & UINT64_C(18446744073709551615);
    v75=(v73) & UINT64_C(4294967295);
    v77=(v61) & UINT64_C(4294967295);
    v50=((v77 + v75)) & UINT64_C(4294967295);
    p0[0]=(uint32_t)(v50);
    record_event((uint32_t)(v51));
    v46=((v45 + UINT64_C(4294967295))) & UINT64_C(4294967295);
    v82=((v46 != UINT64_C(0))) & UINT64_C(255);
    if(v82){incoming=1;goto b4;}else{incoming=1;goto b5;}
b5:
    if(++steps>10000u)exit(71);
    switch(incoming){
    case 0:phi85=v37;break;
    case 1:phi85=v50;break;
    default:exit(72);}
    v85=phi85;
    v86=(v85) & UINT64_C(4294967295);
    return (uint32_t)(v86);
}
