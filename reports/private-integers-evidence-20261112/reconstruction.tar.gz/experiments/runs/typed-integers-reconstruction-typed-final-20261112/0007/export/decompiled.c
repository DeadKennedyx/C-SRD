
/* WARNING: Restarted to delay deadcode elimination for space: stack */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int region_outputs(uint *p0,uint p1,uint p2)

{
  ulong uVar1;
  bool bVar2;
  uint value;
  ulong uVar3;
  ulong uVar4;
  ulong uVar5;
  long lVar6;
  ulong local_2b0;
  uint local_2a8;
  ulong local_298;
  ushort local_290;
  byte local_288;
  
  uVar1 = (ulong)p1 * 0xb46855e1 + 0x6621ac1a;
  uVar3 = uVar1 & 0xff;
  uVar4 = (ulong)p2 * 0xb46855e1 + 0x6621ac1a & 0xffff;
  bVar2 = (((((((uVar3 - 0x1a) * 0x21 & 0xff) * 0xb46855e1 + 0x6621ac1a & 0xffffffff) +
             (((uVar4 - 0xac1a) * 0xae21 & 0xffff) * 0xb46855e1 + 0x6621ac1a & 0xffffffff)) -
             0x6621ac1a & 0xffffffff) - 0x6621ac1a) * 0x9deeae21 & 0xffffffff) != 0;
  uVar3 = (uVar3 - 0x1a) * 0x21;
  local_288 = (byte)uVar3;
  if (0x7f < (uVar3 & 0xff)) {
    local_288 = ~(-local_288 - 1);
  }
  uVar3 = (long)(char)local_288 * 0xb46855e1 + 0x6621ac1aU & 0xffffffff;
  local_2a8 = (uint)(((uVar3 - 0x6621ac1a) * 0x9deeae21 & 0xffffffff ^ 0x80000000) <
                    (((((uVar4 - 0xac1a) * 0xae21 & 0xffff) * 0xb46855e1 + 0x6621ac1a & 0xffffffff)
                     - 0x6621ac1a) * 0x9deeae21 & 0xffffffff ^ 0x80000000));
  uVar5 = (uVar4 - 0xac1a) * 0xae21;
  local_290 = (ushort)uVar5;
  if (0x7fff < (uVar5 & 0xffff)) {
    local_290 = ~(-local_290 - 1);
  }
  local_2b0 = (ulong)(short)local_290;
  lVar6 = ((((uVar3 + (uVar1 & 0xffffffff)) - 0x6621ac1a & 0xffffffff) - 0x6621ac1a) * 0x9deeae21 <<
           0x20 | (uVar4 - 0xac1a) * 0xae21 & 0xffff) * 0x1e37528ab46855e1;
  if (local_2b0 < 0x8000000000000000) {
    local_298 = local_2b0;
  }
  else {
    local_298 = ~(-local_2b0 - 1);
  }
  value = ((int)((ulong)((lVar6 + 0xff1e6e057ab04e9) * -0x51edf8a621151df) >> 0x20) * -0x4b97aa1f +
           (int)((long)local_298 >> 3) * -0x4b97aa1f + (uint)bVar2 * -0x4b97aa1f +
          local_2a8 * -0x4b97aa1f) * -0x621151df;
  if (0x7fffffff < local_2a8) {
    local_2a8 = ~(-local_2a8 - 1);
  }
  if (0x7fffffffffffffff < local_2b0) {
    local_2b0 = ~(-local_2b0 - 1);
  }
  record_event(value);
  *p0 = ((int)lVar6 + 0x57ab04e9) * -0x621151df;
  p0[1] = value;
  p0[2] = (uint)local_2b0;
  return (int)(bVar2 == local_2a8);
}

