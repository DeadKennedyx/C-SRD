#include <stdint.h>
#include <stdlib.h>
#include <limits.h>
_Static_assert(sizeof(int)==4, "32-bit int ABI required");
extern uint32_t next_value(uint32_t);
extern void record_event(uint32_t);
int32_t region_outputs(uint32_t *p0,uint32_t p1,uint32_t p2){
    unsigned steps=0, incoming=0;
    (void)p0;(void)p1;(void)p2;(void)incoming;
    uint64_t v0=0; (void)v0;
    uint64_t v2=0; (void)v2;
    uint64_t v4=0; (void)v4;
    uint64_t v6=0; (void)v6;
    uint64_t v8=0; (void)v8;
    uint64_t v10=0; (void)v10;
    uint64_t v12=0; (void)v12;
    uint64_t v14=0; (void)v14;
    uint64_t v16=0; (void)v16;
    uint64_t v18=0; (void)v18;
    uint64_t v20=0; (void)v20;
    uint64_t v22=0; (void)v22;
    uint64_t v24=0; (void)v24;
    uint64_t v26=0; (void)v26;
    uint64_t v28=0; (void)v28;
    uint64_t v30=0; (void)v30;
    uint64_t v32=0; (void)v32;
    uint64_t v34=0; (void)v34;
    uint64_t v36=0; (void)v36;
    uint64_t v38=0; (void)v38;
    uint64_t v40=0; (void)v40;
    uint64_t v42=0; (void)v42;
    uint64_t v43=0; (void)v43;
    uint64_t v45=0; (void)v45;
    uint64_t v47=0; (void)v47;
    uint64_t v49=0; (void)v49;
    uint64_t v51=0; (void)v51;
    uint64_t v53=0; (void)v53;
    uint64_t v55=0; (void)v55;
    uint64_t v57=0; (void)v57;
    uint64_t v59=0; (void)v59;
    uint64_t v61=0; (void)v61;
    uint64_t v63=0; (void)v63;
    uint64_t v66=0; (void)v66;
    uint64_t v67=0; (void)v67;
    uint64_t v69=0; (void)v69;
    uint64_t v71=0; (void)v71;
    uint64_t v72=0; (void)v72;
    uint64_t v73=0; (void)v73;
    uint64_t v74=0; (void)v74;
    uint64_t v76=0; (void)v76;
    uint64_t v78=0; (void)v78;
    uint64_t v80=0; (void)v80;
    uint64_t v82=0; (void)v82;
    uint64_t v84=0; (void)v84;
    uint64_t v86=0; (void)v86;
    uint64_t v88=0; (void)v88;
    uint64_t v90=0; (void)v90;
    uint64_t v92=0; (void)v92;
    uint64_t v94=0; (void)v94;
    uint64_t v96=0; (void)v96;
    uint64_t v98=0; (void)v98;
    uint64_t v100=0; (void)v100;
    uint64_t v102=0; (void)v102;
    uint64_t v104=0; (void)v104;
    uint64_t v106=0; (void)v106;
    uint64_t v108=0; (void)v108;
    uint64_t v109=0; (void)v109;
    uint64_t v110=0; (void)v110;
    uint64_t v112=0; (void)v112;
    uint64_t v113=0; (void)v113;
    uint64_t v115=0; (void)v115;
    uint64_t v117=0; (void)v117;
    uint64_t v119=0; (void)v119;
    uint64_t v121=0; (void)v121;
    uint64_t v123=0; (void)v123;
    uint64_t v125=0; (void)v125;
    uint64_t v128=0; (void)v128;
    uint64_t v129=0; (void)v129;
    uint64_t v131=0; (void)v131;
    uint64_t v133=0; (void)v133;
    uint64_t v134=0; (void)v134;
    uint64_t v135=0; (void)v135;
    uint64_t v136=0; (void)v136;
    uint64_t v138=0; (void)v138;
    uint64_t v140=0; (void)v140;
    uint64_t v142=0; (void)v142;
    uint64_t v144=0; (void)v144;
    uint64_t v146=0; (void)v146;
    uint64_t v148=0; (void)v148;
    uint64_t v149=0; (void)v149;
    uint64_t v151=0; (void)v151;
    uint64_t v153=0; (void)v153;
    uint64_t v155=0; (void)v155;
    uint64_t v156=0; (void)v156;
    uint64_t v158=0; (void)v158;
    uint64_t v160=0; (void)v160;
    uint64_t v162=0; (void)v162;
    uint64_t v165=0; (void)v165;
    uint64_t v167=0; (void)v167;
    uint64_t v168=0; (void)v168;
    uint64_t v170=0; (void)v170;
    uint64_t v172=0; (void)v172;
    uint64_t v173=0; (void)v173;
    uint64_t v174=0; (void)v174;
    uint64_t v176=0; (void)v176;
    uint64_t v178=0; (void)v178;
    uint64_t v180=0; (void)v180;
    uint64_t v181=0; (void)v181;
    uint64_t v182=0; (void)v182;
    uint64_t v184=0; (void)v184;
    uint64_t v185=0; (void)v185;
    uint64_t v186=0; (void)v186;
    uint64_t v188=0; (void)v188;
    uint64_t v190=0; (void)v190;
    uint64_t v192=0; (void)v192;
    uint64_t v194=0; (void)v194;
    uint64_t v197=0; (void)v197;
    uint64_t v198=0; (void)v198;
    uint64_t v200=0; (void)v200;
    uint64_t v202=0; (void)v202;
    uint64_t v203=0; (void)v203;
    uint64_t v206=0; (void)v206;
    uint64_t v207=0; (void)v207;
    uint64_t v209=0; (void)v209;
    uint64_t v211=0; (void)v211;
    uint64_t v222=0; (void)v222;
    uint64_t v225=0; (void)v225;
    uint64_t v226=0; (void)v226;
    uint64_t v227=0; (void)v227;
    uint64_t phi71=0;
    uint64_t phi133=0;
    uint64_t phi172=0;
    uint64_t phi202=0;
    uint64_t phi211=0;
    goto b0;
b0:
    if(++steps>10000u)exit(71);
    v0=(((uint64_t)(uint32_t)p1)) & UINT64_C(18446744073709551615);
    v2=((v0 * UINT64_C(3026736609))) & UINT64_C(18446744073709551615);
    v4=((v2 + UINT64_C(1713482778))) & UINT64_C(18446744073709551615);
    v6=((v4 & UINT64_C(4294967295))) & UINT64_C(18446744073709551615);
    v8=(((uint64_t)(uint32_t)p2)) & UINT64_C(18446744073709551615);
    v10=((v8 * UINT64_C(3026736609))) & UINT64_C(18446744073709551615);
    v12=((v10 + UINT64_C(1713482778))) & UINT64_C(18446744073709551615);
    v14=((v4 & UINT64_C(255))) & UINT64_C(18446744073709551615);
    v16=((v12 & UINT64_C(65535))) & UINT64_C(18446744073709551615);
    v18=((v14 - UINT64_C(26))) & UINT64_C(18446744073709551615);
    v20=((v18 * UINT64_C(33))) & UINT64_C(18446744073709551615);
    v22=((v20 & UINT64_C(255))) & UINT64_C(18446744073709551615);
    v24=((v22 * UINT64_C(3026736609))) & UINT64_C(18446744073709551615);
    v26=((v24 + UINT64_C(1713482778))) & UINT64_C(18446744073709551615);
    v28=((v26 & UINT64_C(4294967295))) & UINT64_C(18446744073709551615);
    v30=((v16 - UINT64_C(44058))) & UINT64_C(18446744073709551615);
    v32=((v30 * UINT64_C(44577))) & UINT64_C(18446744073709551615);
    v34=((v32 & UINT64_C(65535))) & UINT64_C(18446744073709551615);
    v36=((v34 * UINT64_C(3026736609))) & UINT64_C(18446744073709551615);
    v38=((v36 + UINT64_C(1713482778))) & UINT64_C(18446744073709551615);
    v40=((v38 & UINT64_C(4294967295))) & UINT64_C(18446744073709551615);
    v42=((v28 + v40)) & UINT64_C(18446744073709551615);
    v43=((v42 - UINT64_C(1713482778))) & UINT64_C(18446744073709551615);
    v45=((v43 & UINT64_C(4294967295))) & UINT64_C(18446744073709551615);
    v47=((v45 - UINT64_C(1713482778))) & UINT64_C(18446744073709551615);
    v49=((v47 * UINT64_C(2649665057))) & UINT64_C(18446744073709551615);
    v51=((v49 & UINT64_C(4294967295))) & UINT64_C(18446744073709551615);
    v53=((v51 != UINT64_C(0))) & UINT64_C(255);
    v55=((v14 - UINT64_C(26))) & UINT64_C(18446744073709551615);
    v57=((v55 * UINT64_C(33))) & UINT64_C(18446744073709551615);
    v59=((v57 & UINT64_C(255))) & UINT64_C(18446744073709551615);
    v61=(v57) & UINT64_C(255);
    v63=((UINT64_C(127) < v59)) & UINT64_C(255);
    if(v63){incoming=0;goto b1;}else{incoming=1;goto b2;}
b1:
    if(++steps>10000u)exit(71);
    v66=((UINT64_C(0) - v61)) & UINT64_C(255);
    v67=((v66 - UINT64_C(1))) & UINT64_C(255);
    v69=(~v67) & UINT64_C(255);
    incoming=0;goto b2;
b2:
    if(++steps>10000u)exit(71);
    switch(incoming){
    case 0:phi71=v69;break;
    case 1:phi71=v61;break;
    default:exit(72);}
    v71=phi71;
    v72=(v71) & UINT64_C(255);
    v73=(((v72 ^ UINT64_C(128)) - UINT64_C(128))) & UINT64_C(18446744073709551615);
    v74=((v73 * UINT64_C(3026736609))) & UINT64_C(18446744073709551615);
    v76=((v74 + UINT64_C(1713482778))) & UINT64_C(18446744073709551615);
    v78=((v76 & UINT64_C(4294967295))) & UINT64_C(18446744073709551615);
    v80=((v78 - UINT64_C(1713482778))) & UINT64_C(18446744073709551615);
    v82=((v80 * UINT64_C(2649665057))) & UINT64_C(18446744073709551615);
    v84=((v82 & UINT64_C(4294967295))) & UINT64_C(18446744073709551615);
    v86=((v16 - UINT64_C(44058))) & UINT64_C(18446744073709551615);
    v88=((v86 * UINT64_C(44577))) & UINT64_C(18446744073709551615);
    v90=((v88 & UINT64_C(65535))) & UINT64_C(18446744073709551615);
    v92=((v90 * UINT64_C(3026736609))) & UINT64_C(18446744073709551615);
    v94=((v92 + UINT64_C(1713482778))) & UINT64_C(18446744073709551615);
    v96=((v94 & UINT64_C(4294967295))) & UINT64_C(18446744073709551615);
    v98=((v96 - UINT64_C(1713482778))) & UINT64_C(18446744073709551615);
    v100=((v98 * UINT64_C(2649665057))) & UINT64_C(18446744073709551615);
    v102=((v100 & UINT64_C(4294967295))) & UINT64_C(18446744073709551615);
    v104=((v84 ^ UINT64_C(2147483648))) & UINT64_C(18446744073709551615);
    v106=((v102 ^ UINT64_C(2147483648))) & UINT64_C(18446744073709551615);
    v108=((v104 < v106)) & UINT64_C(255);
    v109=(v108) & UINT64_C(4294967295);
    v110=((v109 * UINT64_C(3026736609))) & UINT64_C(4294967295);
    v112=((v78 + v6)) & UINT64_C(18446744073709551615);
    v113=((v112 - UINT64_C(1713482778))) & UINT64_C(18446744073709551615);
    v115=((v113 & UINT64_C(4294967295))) & UINT64_C(18446744073709551615);
    v117=((v16 - UINT64_C(44058))) & UINT64_C(18446744073709551615);
    v119=((v117 * UINT64_C(44577))) & UINT64_C(18446744073709551615);
    v121=((v119 & UINT64_C(65535))) & UINT64_C(18446744073709551615);
    v123=(v119) & UINT64_C(65535);
    v125=((UINT64_C(32767) < v121)) & UINT64_C(255);
    if(v125){incoming=0;goto b3;}else{incoming=1;goto b4;}
b3:
    if(++steps>10000u)exit(71);
    v128=((UINT64_C(0) - v123)) & UINT64_C(65535);
    v129=((v128 - UINT64_C(1))) & UINT64_C(65535);
    v131=(~v129) & UINT64_C(65535);
    incoming=0;goto b4;
b4:
    if(++steps>10000u)exit(71);
    switch(incoming){
    case 0:phi133=v131;break;
    case 1:phi133=v123;break;
    default:exit(72);}
    v133=phi133;
    v134=(v133) & UINT64_C(65535);
    v135=(((v134 ^ UINT64_C(32768)) - UINT64_C(32768))) & UINT64_C(18446744073709551615);
    v136=((v115 - UINT64_C(1713482778))) & UINT64_C(18446744073709551615);
    v138=((v136 * UINT64_C(2649665057))) & UINT64_C(18446744073709551615);
    v140=((v138 << 32)) & UINT64_C(18446744073709551615);
    v142=((v16 - UINT64_C(44058))) & UINT64_C(18446744073709551615);
    v144=((v142 * UINT64_C(44577))) & UINT64_C(18446744073709551615);
    v146=((v144 & UINT64_C(65535))) & UINT64_C(18446744073709551615);
    v148=((v140 | v146)) & UINT64_C(18446744073709551615);
    v149=((v148 * UINT64_C(2177299700542625249))) & UINT64_C(18446744073709551615);
    v151=((v149 + UINT64_C(1148953231174075625))) & UINT64_C(18446744073709551615);
    v153=((v151 * UINT64_C(18077766068774809121))) & UINT64_C(18446744073709551615);
    v155=(v153) & UINT64_C(18446744073709551615);
    v156=((v155 >> 32)) & UINT64_C(18446744073709551615);
    v158=(v156) & UINT64_C(4294967295);
    v160=((v158 * UINT64_C(3026736609))) & UINT64_C(4294967295);
    v162=((v135 < UINT64_C(9223372036854775808))) & UINT64_C(255);
    if(v162){incoming=0;goto b5;}else{incoming=0;goto b6;}
b5:
    if(++steps>10000u)exit(71);
    v165=(v135) & UINT64_C(18446744073709551615);
    incoming=0;goto b7;
b6:
    if(++steps>10000u)exit(71);
    v167=((UINT64_C(0) - v135)) & UINT64_C(18446744073709551615);
    v168=((v167 - UINT64_C(1))) & UINT64_C(18446744073709551615);
    v170=(~v168) & UINT64_C(18446744073709551615);
    incoming=1;goto b7;
b7:
    if(++steps>10000u)exit(71);
    switch(incoming){
    case 0:phi172=v165;break;
    case 1:phi172=v170;break;
    default:exit(72);}
    v172=phi172;
    v173=(v172) & UINT64_C(18446744073709551615);
    v174=(((v173 >> 3) | ((UINT64_C(0) - (v173 >> 63)) << 61))) & UINT64_C(18446744073709551615);
    v176=(v174) & UINT64_C(4294967295);
    v178=((v176 * UINT64_C(3026736609))) & UINT64_C(4294967295);
    v180=((v160 + v178)) & UINT64_C(4294967295);
    v181=(v53) & UINT64_C(4294967295);
    v182=((v181 * UINT64_C(3026736609))) & UINT64_C(4294967295);
    v184=((v180 + v182)) & UINT64_C(4294967295);
    v185=((v184 + v110)) & UINT64_C(4294967295);
    v186=(v149) & UINT64_C(4294967295);
    v188=((v186 + UINT64_C(1470825705))) & UINT64_C(4294967295);
    v190=((v188 * UINT64_C(2649665057))) & UINT64_C(4294967295);
    v192=((v185 * UINT64_C(2649665057))) & UINT64_C(4294967295);
    v194=((UINT64_C(2147483647) < v109)) & UINT64_C(255);
    if(v194){incoming=0;goto b8;}else{incoming=1;goto b9;}
b8:
    if(++steps>10000u)exit(71);
    v197=((UINT64_C(0) - v109)) & UINT64_C(4294967295);
    v198=((v197 - UINT64_C(1))) & UINT64_C(4294967295);
    v200=(~v198) & UINT64_C(4294967295);
    incoming=0;goto b9;
b9:
    if(++steps>10000u)exit(71);
    switch(incoming){
    case 0:phi202=v200;break;
    case 1:phi202=v109;break;
    default:exit(72);}
    v202=phi202;
    v203=((UINT64_C(9223372036854775807) < v135)) & UINT64_C(255);
    if(v203){incoming=0;goto b10;}else{incoming=1;goto b11;}
b10:
    if(++steps>10000u)exit(71);
    v206=((UINT64_C(0) - v135)) & UINT64_C(18446744073709551615);
    v207=((v206 - UINT64_C(1))) & UINT64_C(18446744073709551615);
    v209=(~v207) & UINT64_C(18446744073709551615);
    incoming=0;goto b11;
b11:
    if(++steps>10000u)exit(71);
    switch(incoming){
    case 0:phi211=v209;break;
    case 1:phi211=v135;break;
    default:exit(72);}
    v211=phi211;
    record_event((uint32_t)(v192));
    p0[0]=(uint32_t)(v190);
    p0[1]=(uint32_t)(v192);
    v222=(v211) & UINT64_C(4294967295);
    p0[2]=(uint32_t)(v222);
    v225=(v53) & UINT64_C(4294967295);
    v226=((v225 == v202)) & UINT64_C(255);
    v227=(v226) & UINT64_C(4294967295);
    {uint32_t r=(uint32_t)(v227);
    return r<=INT32_MAX?(int32_t)r:INT32_MIN+(int32_t)(r-UINT32_C(2147483648));}
}
