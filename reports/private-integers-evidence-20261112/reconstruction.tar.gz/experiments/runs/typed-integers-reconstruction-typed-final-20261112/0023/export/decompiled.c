
/* WARNING: Restarted to delay deadcode elimination for space: stack */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int region_outputs(uint *p0,uint p1,uint p2)

{
  long lVar1;
  bool bVar2;
  ulong uVar3;
  ulong uVar4;
  ulong local_280;
  ulong local_268;
  ulong local_260;
  byte local_258;
  uint local_1d0;
  uint local_e8;
  ulong local_b8;
  
  uVar3 = (ulong)p1;
  uVar4 = (ulong)p2 & 0xffff;
  bVar2 = (uVar3 & 0xff) + uVar4 != 0;
  local_258 = (byte)p1;
  if (0x7f < (uVar3 & 0xff)) {
    local_258 = ~(-local_258 - 1);
  }
  local_b8 = (ulong)(uint)(int)(char)local_258;
  local_e8 = (uint)(((ulong)(uint)(int)(char)local_258 ^ 0x80000000) < (uVar4 ^ 0x80000000));
  if (uVar4 < 0x8000) {
    local_260 = uVar4;
  }
  else {
    local_260 = ~(0xffff - uVar4);
  }
  local_280 = (ulong)(short)local_260;
  lVar1 = (local_b8 + uVar3 << 0x20 | uVar4) + 9;
  if (local_280 < 0x8000000000000000) {
    local_268 = local_280;
  }
  else {
    local_268 = ~(-local_280 - 1);
  }
  local_1d0 = (int)((ulong)lVar1 >> 0x20) + (int)((long)local_268 >> 3) + (uint)bVar2 + local_e8;
  if (0x7fffffff < local_e8) {
    local_e8 = ~(0xffffffff - local_e8);
  }
  if (0x7fffffffffffffff < local_280) {
    local_280 = ~(-local_280 - 1);
  }
  record_event(local_1d0);
  *p0 = (uint)lVar1;
  p0[1] = local_1d0;
  p0[2] = (uint)local_280;
  return (int)(bVar2 == local_e8);
}

