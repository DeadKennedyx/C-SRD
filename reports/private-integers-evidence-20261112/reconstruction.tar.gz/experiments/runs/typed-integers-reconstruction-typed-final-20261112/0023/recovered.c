#include <stdint.h>
#include <stdlib.h>
#include <limits.h>
_Static_assert(sizeof(int)==4, "32-bit int ABI required");
extern uint32_t next_value(uint32_t);
extern void record_event(uint32_t);
int32_t region_outputs(uint32_t *p0,uint32_t p1,uint32_t p2){
    unsigned steps=0, incoming=0;
    (void)p0;(void)p1;(void)p2;(void)incoming;
    uint64_t v0=0; (void)v0;
    uint64_t v2=0; (void)v2;
    uint64_t v4=0; (void)v4;
    uint64_t v6=0; (void)v6;
    uint64_t v8=0; (void)v8;
    uint64_t v9=0; (void)v9;
    uint64_t v11=0; (void)v11;
    uint64_t v13=0; (void)v13;
    uint64_t v15=0; (void)v15;
    uint64_t v18=0; (void)v18;
    uint64_t v19=0; (void)v19;
    uint64_t v21=0; (void)v21;
    uint64_t v23=0; (void)v23;
    uint64_t v24=0; (void)v24;
    uint64_t v25=0; (void)v25;
    uint64_t v26=0; (void)v26;
    uint64_t v27=0; (void)v27;
    uint64_t v28=0; (void)v28;
    uint64_t v29=0; (void)v29;
    uint64_t v30=0; (void)v30;
    uint64_t v32=0; (void)v32;
    uint64_t v34=0; (void)v34;
    uint64_t v35=0; (void)v35;
    uint64_t v36=0; (void)v36;
    uint64_t v37=0; (void)v37;
    uint64_t v40=0; (void)v40;
    uint64_t v42=0; (void)v42;
    uint64_t v44=0; (void)v44;
    uint64_t v46=0; (void)v46;
    uint64_t v47=0; (void)v47;
    uint64_t v49=0; (void)v49;
    uint64_t v50=0; (void)v50;
    uint64_t v52=0; (void)v52;
    uint64_t v53=0; (void)v53;
    uint64_t v55=0; (void)v55;
    uint64_t v56=0; (void)v56;
    uint64_t v58=0; (void)v58;
    uint64_t v60=0; (void)v60;
    uint64_t v63=0; (void)v63;
    uint64_t v65=0; (void)v65;
    uint64_t v66=0; (void)v66;
    uint64_t v68=0; (void)v68;
    uint64_t v70=0; (void)v70;
    uint64_t v71=0; (void)v71;
    uint64_t v72=0; (void)v72;
    uint64_t v74=0; (void)v74;
    uint64_t v76=0; (void)v76;
    uint64_t v77=0; (void)v77;
    uint64_t v78=0; (void)v78;
    uint64_t v79=0; (void)v79;
    uint64_t v80=0; (void)v80;
    uint64_t v83=0; (void)v83;
    uint64_t v85=0; (void)v85;
    uint64_t v87=0; (void)v87;
    uint64_t v88=0; (void)v88;
    uint64_t v91=0; (void)v91;
    uint64_t v92=0; (void)v92;
    uint64_t v94=0; (void)v94;
    uint64_t v96=0; (void)v96;
    uint64_t v98=0; (void)v98;
    uint64_t v109=0; (void)v109;
    uint64_t v112=0; (void)v112;
    uint64_t v113=0; (void)v113;
    uint64_t v114=0; (void)v114;
    uint64_t phi23=0;
    uint64_t phi46=0;
    uint64_t phi70=0;
    uint64_t phi87=0;
    uint64_t phi96=0;
    goto b0;
b0:
    if(++steps>10000u)exit(71);
    v0=(((uint64_t)(uint32_t)p1)) & UINT64_C(18446744073709551615);
    v2=(((uint64_t)(uint32_t)p2)) & UINT64_C(18446744073709551615);
    v4=((v0 & UINT64_C(255))) & UINT64_C(18446744073709551615);
    v6=((v2 & UINT64_C(65535))) & UINT64_C(18446744073709551615);
    v8=((v4 + v6)) & UINT64_C(18446744073709551615);
    v9=((v8 != UINT64_C(0))) & UINT64_C(255);
    v11=((v0 & UINT64_C(255))) & UINT64_C(18446744073709551615);
    v13=(((uint64_t)(uint32_t)p1)) & UINT64_C(255);
    v15=((UINT64_C(127) < v11)) & UINT64_C(255);
    if(v15){incoming=0;goto b1;}else{incoming=1;goto b2;}
b1:
    if(++steps>10000u)exit(71);
    v18=((UINT64_C(0) - v13)) & UINT64_C(255);
    v19=((v18 - UINT64_C(1))) & UINT64_C(255);
    v21=(~v19) & UINT64_C(255);
    incoming=0;goto b2;
b2:
    if(++steps>10000u)exit(71);
    switch(incoming){
    case 0:phi23=v21;break;
    case 1:phi23=v13;break;
    default:exit(72);}
    v23=phi23;
    v24=(v23) & UINT64_C(255);
    v25=(((v24 ^ UINT64_C(128)) - UINT64_C(128))) & UINT64_C(4294967295);
    v26=(v25) & UINT64_C(4294967295);
    v27=(v26) & UINT64_C(18446744073709551615);
    v28=(v25) & UINT64_C(4294967295);
    v29=(v28) & UINT64_C(18446744073709551615);
    v30=((v29 ^ UINT64_C(2147483648))) & UINT64_C(18446744073709551615);
    v32=((v6 ^ UINT64_C(2147483648))) & UINT64_C(18446744073709551615);
    v34=((v30 < v32)) & UINT64_C(255);
    v35=(v34) & UINT64_C(4294967295);
    v36=((v27 + v0)) & UINT64_C(18446744073709551615);
    v37=((v6 < UINT64_C(32768))) & UINT64_C(255);
    if(v37){incoming=0;goto b3;}else{incoming=0;goto b4;}
b3:
    if(++steps>10000u)exit(71);
    v40=(v6) & UINT64_C(18446744073709551615);
    incoming=0;goto b5;
b4:
    if(++steps>10000u)exit(71);
    v42=((UINT64_C(65535) - v6)) & UINT64_C(18446744073709551615);
    v44=(~v42) & UINT64_C(18446744073709551615);
    incoming=1;goto b5;
b5:
    if(++steps>10000u)exit(71);
    switch(incoming){
    case 0:phi46=v40;break;
    case 1:phi46=v44;break;
    default:exit(72);}
    v46=phi46;
    v47=(v46) & UINT64_C(65535);
    v49=(((v47 ^ UINT64_C(32768)) - UINT64_C(32768))) & UINT64_C(18446744073709551615);
    v50=((v36 << 32)) & UINT64_C(18446744073709551615);
    v52=((v50 | v6)) & UINT64_C(18446744073709551615);
    v53=((v52 + UINT64_C(9))) & UINT64_C(18446744073709551615);
    v55=(v53) & UINT64_C(18446744073709551615);
    v56=((v55 >> 32)) & UINT64_C(18446744073709551615);
    v58=(v56) & UINT64_C(4294967295);
    v60=((v49 < UINT64_C(9223372036854775808))) & UINT64_C(255);
    if(v60){incoming=0;goto b6;}else{incoming=0;goto b7;}
b6:
    if(++steps>10000u)exit(71);
    v63=(v49) & UINT64_C(18446744073709551615);
    incoming=0;goto b8;
b7:
    if(++steps>10000u)exit(71);
    v65=((UINT64_C(0) - v49)) & UINT64_C(18446744073709551615);
    v66=((v65 - UINT64_C(1))) & UINT64_C(18446744073709551615);
    v68=(~v66) & UINT64_C(18446744073709551615);
    incoming=1;goto b8;
b8:
    if(++steps>10000u)exit(71);
    switch(incoming){
    case 0:phi70=v63;break;
    case 1:phi70=v68;break;
    default:exit(72);}
    v70=phi70;
    v71=(v70) & UINT64_C(18446744073709551615);
    v72=(((v71 >> 3) | ((UINT64_C(0) - (v71 >> 63)) << 61))) & UINT64_C(18446744073709551615);
    v74=(v72) & UINT64_C(4294967295);
    v76=((v58 + v74)) & UINT64_C(4294967295);
    v77=(v9) & UINT64_C(4294967295);
    v78=((v76 + v77)) & UINT64_C(4294967295);
    v79=((v78 + v35)) & UINT64_C(4294967295);
    v80=((UINT64_C(2147483647) < v35)) & UINT64_C(255);
    if(v80){incoming=0;goto b9;}else{incoming=1;goto b10;}
b9:
    if(++steps>10000u)exit(71);
    v83=((UINT64_C(4294967295) - v35)) & UINT64_C(4294967295);
    v85=(~v83) & UINT64_C(4294967295);
    incoming=0;goto b10;
b10:
    if(++steps>10000u)exit(71);
    switch(incoming){
    case 0:phi87=v85;break;
    case 1:phi87=v35;break;
    default:exit(72);}
    v87=phi87;
    v88=((UINT64_C(9223372036854775807) < v49)) & UINT64_C(255);
    if(v88){incoming=0;goto b11;}else{incoming=1;goto b12;}
b11:
    if(++steps>10000u)exit(71);
    v91=((UINT64_C(0) - v49)) & UINT64_C(18446744073709551615);
    v92=((v91 - UINT64_C(1))) & UINT64_C(18446744073709551615);
    v94=(~v92) & UINT64_C(18446744073709551615);
    incoming=0;goto b12;
b12:
    if(++steps>10000u)exit(71);
    switch(incoming){
    case 0:phi96=v94;break;
    case 1:phi96=v49;break;
    default:exit(72);}
    v96=phi96;
    record_event((uint32_t)(v79));
    v98=(v53) & UINT64_C(4294967295);
    p0[0]=(uint32_t)(v98);
    p0[1]=(uint32_t)(v79);
    v109=(v96) & UINT64_C(4294967295);
    p0[2]=(uint32_t)(v109);
    v112=(v9) & UINT64_C(4294967295);
    v113=((v112 == v87)) & UINT64_C(255);
    v114=(v113) & UINT64_C(4294967295);
    {uint32_t r=(uint32_t)(v114);
    return r<=INT32_MAX?(int32_t)r:INT32_MIN+(int32_t)(r-UINT32_C(2147483648));}
}
