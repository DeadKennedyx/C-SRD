
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int region_outputs(uint *p0,uint p1,uint p2)

{
  long lVar1;
  long lVar2;
  uint uVar3;
  int iVar4;
  int iVar5;
  bool bVar6;
  long lVar7;
  long lVar8;
  
  uVar3 = p2 & 0xffff;
  lVar7 = (ulong)p1 * 0xb46855e1 + 0x6621ac1a;
  lVar2 = (ulong)uVar3 + 0x106494c00000009;
  lVar1 = lVar7 * 0x21 + 0xa6;
  lVar8 = (long)(char)lVar1 * 0xb46855e1 + 0x6621ac1a;
  bVar6 = (((uint)lVar1 & 0xff) * -0x4b97aa1f + uVar3 * -0x4b97aa1f + -0x33bca7cc) * -0x621151df !=
          -0x106494c;
  iVar4 = 0x1a8a01fb;
  if (!bVar6) {
    iVar4 = 0x6621ac1a;
  }
  iVar5 = 0x1a8a01fb;
  if (((ulong)uVar3 | 0x80000000) <= ((ulong)((int)lVar8 * -0x621151df + 0x8324a6) ^ 0x80000000)) {
    iVar5 = 0x6621ac1a;
  }
  uVar3 = (iVar4 + iVar5 +
          ((int)((ulong)(lVar2 + (lVar8 + lVar7) * -0x621151df00000000) >> 0x20) +
          (int)((long)((ulong)p2 << 0x30) >> 0x33)) * -0x4b97aa1f) * -0x621151df + 0x106494c;
  record_event(uVar3);
  *p0 = (uint)lVar2;
  p0[1] = uVar3;
  p0[2] = (int)(short)p2;
  return (int)(iVar5 * -0x621151df + 0x8324a6U == (uint)bVar6);
}

