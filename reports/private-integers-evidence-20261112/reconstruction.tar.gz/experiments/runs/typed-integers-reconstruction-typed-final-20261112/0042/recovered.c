#include <stdint.h>
#include <stdlib.h>
#include <limits.h>
_Static_assert(sizeof(int)==4, "32-bit int ABI required");
extern uint32_t next_value(uint32_t);
extern void record_event(uint32_t);
int32_t region_outputs(uint32_t *p0,uint32_t p1,uint32_t p2){
    unsigned steps=0, incoming=0;
    (void)p0;(void)p1;(void)p2;(void)incoming;
    uint64_t v0=0; (void)v0;
    uint64_t v3=0; (void)v3;
    uint64_t v4=0; (void)v4;
    uint64_t v6=0; (void)v6;
    uint64_t v8=0; (void)v8;
    uint64_t v10=0; (void)v10;
    uint64_t v12=0; (void)v12;
    uint64_t v14=0; (void)v14;
    uint64_t v16=0; (void)v16;
    uint64_t v18=0; (void)v18;
    uint64_t v20=0; (void)v20;
    uint64_t v22=0; (void)v22;
    uint64_t v24=0; (void)v24;
    uint64_t v25=0; (void)v25;
    uint64_t v27=0; (void)v27;
    uint64_t v29=0; (void)v29;
    uint64_t v31=0; (void)v31;
    uint64_t v33=0; (void)v33;
    uint64_t v35=0; (void)v35;
    uint64_t v36=0; (void)v36;
    uint64_t v37=0; (void)v37;
    uint64_t v39=0; (void)v39;
    uint64_t v41=0; (void)v41;
    uint64_t v42=0; (void)v42;
    uint64_t v44=0; (void)v44;
    uint64_t v46=0; (void)v46;
    uint64_t v48=0; (void)v48;
    uint64_t v50=0; (void)v50;
    uint64_t v51=0; (void)v51;
    uint64_t v53=0; (void)v53;
    uint64_t v55=0; (void)v55;
    uint64_t v57=0; (void)v57;
    uint64_t v58=0; (void)v58;
    uint64_t v60=0; (void)v60;
    uint64_t v61=0; (void)v61;
    uint64_t v63=0; (void)v63;
    uint64_t v64=0; (void)v64;
    uint64_t v65=0; (void)v65;
    uint64_t v66=0; (void)v66;
    uint64_t v68=0; (void)v68;
    uint64_t v69=0; (void)v69;
    uint64_t v71=0; (void)v71;
    uint64_t v73=0; (void)v73;
    uint64_t v74=0; (void)v74;
    uint64_t v76=0; (void)v76;
    uint64_t v78=0; (void)v78;
    uint64_t v79=0; (void)v79;
    uint64_t v81=0; (void)v81;
    uint64_t v82=0; (void)v82;
    uint64_t v83=0; (void)v83;
    uint64_t v84=0; (void)v84;
    uint64_t v86=0; (void)v86;
    uint64_t v87=0; (void)v87;
    uint64_t v89=0; (void)v89;
    uint64_t v91=0; (void)v91;
    uint64_t v93=0; (void)v93;
    uint64_t v96=0; (void)v96;
    uint64_t v97=0; (void)v97;
    uint64_t v98=0; (void)v98;
    uint64_t v109=0; (void)v109;
    uint64_t v111=0; (void)v111;
    uint64_t phi64=0;
    uint64_t phi82=0;
    goto b0;
b0:
    if(++steps>10000u)exit(71);
    v0=((((uint64_t)(uint32_t)p2) & UINT64_C(65535))) & UINT64_C(4294967295);
    v3=(v0) & UINT64_C(18446744073709551615);
    v4=(UINT64_C(1713482778)) & UINT64_C(4294967295);
    v6=(((uint64_t)(uint32_t)p1)) & UINT64_C(18446744073709551615);
    v8=((v6 * UINT64_C(3026736609))) & UINT64_C(18446744073709551615);
    v10=((v8 + UINT64_C(1713482778))) & UINT64_C(18446744073709551615);
    v12=((v3 + UINT64_C(73827034664534025))) & UINT64_C(18446744073709551615);
    v14=((v10 * UINT64_C(33))) & UINT64_C(18446744073709551615);
    v16=(UINT64_C(445252091)) & UINT64_C(4294967295);
    v18=((v14 + UINT64_C(166))) & UINT64_C(18446744073709551615);
    v20=(v18) & UINT64_C(4294967295);
    v22=(v18) & UINT64_C(255);
    v24=(((v22 ^ UINT64_C(128)) - UINT64_C(128))) & UINT64_C(18446744073709551615);
    v25=((v20 & UINT64_C(255))) & UINT64_C(4294967295);
    v27=((v25 * UINT64_C(3026736609))) & UINT64_C(4294967295);
    v29=((v24 * UINT64_C(3026736609))) & UINT64_C(18446744073709551615);
    v31=((v29 + UINT64_C(1713482778))) & UINT64_C(18446744073709551615);
    v33=((v0 * UINT64_C(3026736609))) & UINT64_C(4294967295);
    v35=((v27 + v33)) & UINT64_C(4294967295);
    v36=((v31 + v10)) & UINT64_C(18446744073709551615);
    v37=((v35 + UINT64_C(3426965556))) & UINT64_C(4294967295);
    v39=((v36 * UINT64_C(11380224765168975872))) & UINT64_C(18446744073709551615);
    v41=((v12 + v39)) & UINT64_C(18446744073709551615);
    v42=((v37 * UINT64_C(2649665057))) & UINT64_C(4294967295);
    v44=(v31) & UINT64_C(4294967295);
    v46=((v44 * UINT64_C(2649665057))) & UINT64_C(4294967295);
    v48=((v46 + UINT64_C(8594598))) & UINT64_C(4294967295);
    v50=(v48) & UINT64_C(18446744073709551615);
    v51=((v42 != UINT64_C(4277778100))) & UINT64_C(255);
    v53=((v50 ^ UINT64_C(2147483648))) & UINT64_C(18446744073709551615);
    v55=((v3 | UINT64_C(2147483648))) & UINT64_C(18446744073709551615);
    v57=(((uint64_t)(uint32_t)p2)) & UINT64_C(18446744073709551615);
    v58=((v57 << 48)) & UINT64_C(18446744073709551615);
    v60=((v51 == 0)) & UINT64_C(255);
    v61=(v16) & UINT64_C(4294967295);
    if(v60){incoming=0;goto b1;}else{incoming=0;goto b2;}
b1:
    if(++steps>10000u)exit(71);
    v63=(v4) & UINT64_C(4294967295);
    incoming=1;goto b2;
b2:
    if(++steps>10000u)exit(71);
    switch(incoming){
    case 0:phi64=v61;break;
    case 1:phi64=v63;break;
    default:exit(72);}
    v64=phi64;
    v65=((v55 <= v53)) & UINT64_C(255);
    v66=(((uint64_t)(uint32_t)p2)) & UINT64_C(65535);
    v68=(v58) & UINT64_C(18446744073709551615);
    v69=(((v68 >> 51) | ((UINT64_C(0) - (v68 >> 63)) << 13))) & UINT64_C(18446744073709551615);
    v71=(v69) & UINT64_C(4294967295);
    v73=(v41) & UINT64_C(18446744073709551615);
    v74=((v73 >> 32)) & UINT64_C(18446744073709551615);
    v76=(v74) & UINT64_C(4294967295);
    v78=((v76 + v71)) & UINT64_C(4294967295);
    v79=(v16) & UINT64_C(4294967295);
    if(v65){incoming=0;goto b3;}else{incoming=0;goto b4;}
b3:
    if(++steps>10000u)exit(71);
    v81=(v4) & UINT64_C(4294967295);
    incoming=1;goto b4;
b4:
    if(++steps>10000u)exit(71);
    switch(incoming){
    case 0:phi82=v79;break;
    case 1:phi82=v81;break;
    default:exit(72);}
    v82=phi82;
    v83=((v64 + v82)) & UINT64_C(4294967295);
    v84=((v78 * UINT64_C(3026736609))) & UINT64_C(4294967295);
    v86=((v83 + v84)) & UINT64_C(4294967295);
    v87=((v82 * UINT64_C(2649665057))) & UINT64_C(4294967295);
    v89=((v87 + UINT64_C(8594598))) & UINT64_C(4294967295);
    v91=((v86 * UINT64_C(2649665057))) & UINT64_C(4294967295);
    v93=((v91 + UINT64_C(17189196))) & UINT64_C(4294967295);
    record_event((uint32_t)(v93));
    v96=(v51) & UINT64_C(4294967295);
    v97=((v89 == v96)) & UINT64_C(255);
    v98=(v12) & UINT64_C(4294967295);
    p0[0]=(uint32_t)(v98);
    p0[1]=(uint32_t)(v93);
    v109=(((v66 ^ UINT64_C(32768)) - UINT64_C(32768))) & UINT64_C(4294967295);
    p0[2]=(uint32_t)(v109);
    v111=(v97) & UINT64_C(4294967295);
    {uint32_t r=(uint32_t)(v111);
    return r<=INT32_MAX?(int32_t)r:INT32_MIN+(int32_t)(r-UINT32_C(2147483648));}
}
