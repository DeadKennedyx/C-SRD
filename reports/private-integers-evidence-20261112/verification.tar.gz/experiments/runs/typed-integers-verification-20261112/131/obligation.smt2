; 
(set-info :status unknown)
(declare-fun input_1 () (_ BitVec 32))
(declare-fun input_0 () (_ BitVec 32))
(assert
 (let ((?x8 ((_ extract 15 0) input_1)))
 (let ((?x27 (concat (_ bv0 16) ?x8)))
 (let ((?x7 ((_ extract 7 0) input_0)))
 (let ((?x25 (concat (_ bv0 24) ?x7)))
 (let ((?x46 (bvadd ?x25 ?x27)))
 (let ((?x47 ((_ extract 31 31) ?x46)))
 (let ((?x48 (concat ?x47 ?x47 ?x47 ?x47 ?x47 ?x47 ?x47 ?x47 ?x47 ?x47 ?x47 ?x47 ?x47 ?x47 ?x47 ?x47 ?x47 ?x47 ?x47 ?x47 ?x47 ?x47 ?x47 ?x47 ?x47 ?x47 ?x47 ?x47 ?x47 ?x47 ?x47 ?x47 ?x46)))
 (= (bvadd (concat (_ bv0 56) ?x7) (concat (_ bv0 48) ?x8)) ?x48)))))))))
(check-sat)
