; 
(set-info :status unknown)
(declare-fun input_1 () (_ BitVec 32))
(declare-fun input_0 () (_ BitVec 32))
(assert
 (let ((?x202 (concat (_ bv0 32) (bvadd (_ bv1024304373 32) (bvmul (_ bv4066321351 32) input_1)))))
 (let ((?x199 (concat (_ bv0 32) (bvadd (_ bv1024304373 32) (bvmul (_ bv4066321351 32) input_0)))))
 (let (($x105 (not true)))
 (let (($x108 (or $x105 (and (distinct ?x199 ((_ zero_extend 32) (bvadd (bvmul input_0 (_ bv4066321351 32)) (_ bv1024304373 32)))) true))))
 (let (($x139 (or $x108 (and (distinct ?x202 ((_ zero_extend 32) (bvadd (bvmul input_1 (_ bv4066321351 32)) (_ bv1024304373 32)))) true))))
 (and true $x139)))))))
(check-sat-using (then (using-params simplify :som true :push_ite_bv true) blast-term-ite (using-params simplify :som true :push_ite_bv true) smt))
