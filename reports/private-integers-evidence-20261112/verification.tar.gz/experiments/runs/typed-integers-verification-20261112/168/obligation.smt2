; 
(set-info :status unknown)
(declare-fun input_1 () (_ BitVec 32))
(declare-fun input_0 () (_ BitVec 32))
(assert
 (let ((?x93 (concat (_ bv0 32) input_1)))
 (let ((?x76 (concat (_ bv0 32) input_0)))
 (let (($x71 (not true)))
 (let (($x99 (or $x71 (and (distinct ?x76 ((_ zero_extend 32) (bvadd (bvmul input_0 (_ bv1 32)) (_ bv0 32)))) true))))
 (let (($x95 (or $x99 (and (distinct ?x93 ((_ zero_extend 32) (bvadd (bvmul input_1 (_ bv1 32)) (_ bv0 32)))) true))))
 (and true $x95)))))))
(check-sat-using (then (using-params simplify :som true :push_ite_bv true) blast-term-ite (using-params simplify :som true :push_ite_bv true) smt))
