; 
(set-info :status unknown)
(declare-fun input_1 () (_ BitVec 32))
(declare-fun input_2 () (_ BitVec 64))
(declare-fun input_0 () (_ BitVec 32))
(assert
 (let ((?x112 (concat (_ bv0 32) input_1)))
 (let ((?x97 (concat (_ bv0 32) input_0)))
 (let (($x94 (not true)))
 (let (($x102 (or $x94 (and (distinct ?x97 ((_ zero_extend 32) (bvadd (bvmul input_0 (_ bv1 32)) (_ bv0 32)))) true))))
 (let (($x109 (or $x102 (and (distinct input_2 (bvadd (bvmul input_2 (_ bv1 64)) (_ bv0 64))) true))))
 (let (($x100 (or $x109 (and (distinct ?x112 ((_ zero_extend 32) (bvadd (bvmul input_1 (_ bv1 32)) (_ bv0 32)))) true))))
 (and true $x100))))))))
(check-sat-using (then (using-params simplify :som true :push_ite_bv true) blast-term-ite (using-params simplify :som true :push_ite_bv true) smt))
