; 
(set-info :status unknown)
(declare-fun input_1 () (_ BitVec 32))
(declare-fun input_0 () (_ BitVec 32))
(assert
 (let ((?x109 (concat (_ bv0 32) input_1)))
 (let ((?x152 (concat (_ bv0 32) input_0)))
 (let (($x105 (not true)))
 (let (($x147 (or $x105 (and (distinct ?x152 ((_ zero_extend 32) (bvadd (bvmul input_0 (_ bv1 32)) (_ bv0 32)))) true))))
 (let (($x141 (or $x147 (and (distinct ?x109 ((_ zero_extend 32) (bvadd (bvmul input_1 (_ bv1 32)) (_ bv0 32)))) true))))
 (and true $x141)))))))
(check-sat-using (then (using-params simplify :som true :push_ite_bv true) blast-term-ite (using-params simplify :som true :push_ite_bv true) smt))
