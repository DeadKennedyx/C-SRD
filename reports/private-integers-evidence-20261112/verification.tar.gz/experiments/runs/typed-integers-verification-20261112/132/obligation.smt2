; 
(set-info :status unknown)
(declare-fun input_1 () (_ BitVec 32))
(declare-fun input_0 () (_ BitVec 32))
(assert
 (let ((?x199 (concat (_ bv0 32) (bvadd (_ bv1713482778 32) (bvmul (_ bv3026736609 32) input_1)))))
 (let ((?x209 (concat (_ bv0 32) (bvadd (_ bv1713482778 32) (bvmul (_ bv3026736609 32) input_0)))))
 (let (($x71 (not true)))
 (let (($x92 (or $x71 (and (distinct ?x209 ((_ zero_extend 32) (bvadd (bvmul input_0 (_ bv3026736609 32)) (_ bv1713482778 32)))) true))))
 (let (($x94 (or $x92 (and (distinct ?x199 ((_ zero_extend 32) (bvadd (bvmul input_1 (_ bv3026736609 32)) (_ bv1713482778 32)))) true))))
 (and true $x94)))))))
(check-sat-using (then (using-params simplify :som true :push_ite_bv true) blast-term-ite (using-params simplify :som true :push_ite_bv true) smt))
