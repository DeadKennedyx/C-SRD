typedef unsigned char __u_char;
typedef unsigned short int __u_short;
typedef unsigned int __u_int;
typedef unsigned long int __u_long;
typedef signed char __int8_t;
typedef unsigned char __uint8_t;
typedef signed short int __int16_t;
typedef unsigned short int __uint16_t;
typedef signed int __int32_t;
typedef unsigned int __uint32_t;
typedef signed long int __int64_t;
typedef unsigned long int __uint64_t;
typedef __int8_t __int_least8_t;
typedef __uint8_t __uint_least8_t;
typedef __int16_t __int_least16_t;
typedef __uint16_t __uint_least16_t;
typedef __int32_t __int_least32_t;
typedef __uint32_t __uint_least32_t;
typedef __int64_t __int_least64_t;
typedef __uint64_t __uint_least64_t;
typedef long int __quad_t;
typedef unsigned long int __u_quad_t;
typedef long int __intmax_t;
typedef unsigned long int __uintmax_t;
typedef unsigned long int __dev_t;
typedef unsigned int __uid_t;
typedef unsigned int __gid_t;
typedef unsigned long int __ino_t;
typedef unsigned long int __ino64_t;
typedef unsigned int __mode_t;
typedef unsigned int __nlink_t;
typedef long int __off_t;
typedef long int __off64_t;
typedef int __pid_t;
typedef struct { int __val[2]; } __fsid_t;
typedef long int __clock_t;
typedef unsigned long int __rlim_t;
typedef unsigned long int __rlim64_t;
typedef unsigned int __id_t;
typedef long int __time_t;
typedef unsigned int __useconds_t;
typedef long int __suseconds_t;
typedef long int __suseconds64_t;
typedef int __daddr_t;
typedef int __key_t;
typedef int __clockid_t;
typedef void * __timer_t;
typedef int __blksize_t;
typedef long int __blkcnt_t;
typedef long int __blkcnt64_t;
typedef unsigned long int __fsblkcnt_t;
typedef unsigned long int __fsblkcnt64_t;
typedef unsigned long int __fsfilcnt_t;
typedef unsigned long int __fsfilcnt64_t;
typedef long int __fsword_t;
typedef long int __ssize_t;
typedef long int __syscall_slong_t;
typedef unsigned long int __syscall_ulong_t;
typedef __off64_t __loff_t;
typedef char *__caddr_t;
typedef long int __intptr_t;
typedef unsigned int __socklen_t;
typedef int __sig_atomic_t;
typedef __int8_t int8_t;
typedef __int16_t int16_t;
typedef __int32_t int32_t;
typedef __int64_t int64_t;
typedef __uint8_t uint8_t;
typedef __uint16_t uint16_t;
typedef __uint32_t uint32_t;
typedef __uint64_t uint64_t;
typedef __int_least8_t int_least8_t;
typedef __int_least16_t int_least16_t;
typedef __int_least32_t int_least32_t;
typedef __int_least64_t int_least64_t;
typedef __uint_least8_t uint_least8_t;
typedef __uint_least16_t uint_least16_t;
typedef __uint_least32_t uint_least32_t;
typedef __uint_least64_t uint_least64_t;
typedef signed char int_fast8_t;
typedef long int int_fast16_t;
typedef long int int_fast32_t;
typedef long int int_fast64_t;
typedef unsigned char uint_fast8_t;
typedef unsigned long int uint_fast16_t;
typedef unsigned long int uint_fast32_t;
typedef unsigned long int uint_fast64_t;
typedef long int intptr_t;
typedef unsigned long int uintptr_t;
typedef __intmax_t intmax_t;
typedef __uintmax_t uintmax_t;
extern uint32_t next_value(uint32_t value);
extern void record_event(uint32_t value);
uint32_t region_pipeline(uint32_t *buffer, uint32_t x, int limit)
{
    uint32_t y = buffer[0];
    _Static_assert((unsigned char)~0u == 255u && ~0 == -1 && ~0L == -1L && ~0LL == -1LL && (-1 >> 1) == -1 && sizeof(short)==2 && sizeof(int)==4 && sizeof(long)==8 && sizeof(long long)==8 && (((char)-1 < 0)==0), "C-SRD integer data model mismatch"); unsigned long long csrd_frame_3191_0 = (((unsigned long long)(x)) & 4294967295ULL); (void)csrd_frame_3191_0; unsigned long long csrd_frame_3191_1 = (((unsigned long long)(y)) & 4294967295ULL); (void)csrd_frame_3191_1; unsigned long long csrd_frame_3191_2 = ((csrd_frame_3191_0) & 255ULL); (void)csrd_frame_3191_2; unsigned long long csrd_frame_3191_3 = csrd_frame_3191_2; (void)csrd_frame_3191_3; unsigned long long csrd_frame_3191_4 = ((csrd_frame_3191_1) & 255ULL); (void)csrd_frame_3191_4; unsigned long long csrd_frame_3191_5 = csrd_frame_3191_4; (void)csrd_frame_3191_5; unsigned long long csrd_frame_3191_6 = ((csrd_frame_3191_0) & 4294967295ULL); (void)csrd_frame_3191_6; unsigned long long csrd_frame_3191_7 = (((csrd_frame_3191_6 >> 8u)) & 4294967295ULL); (void)csrd_frame_3191_7; unsigned long long csrd_frame_3191_8 = ((csrd_frame_3191_7) & 65535ULL); (void)csrd_frame_3191_8; unsigned long long csrd_frame_3191_9 = csrd_frame_3191_8; (void)csrd_frame_3191_9; unsigned long long csrd_frame_3191_10 = ((csrd_frame_3191_3) & 255ULL); (void)csrd_frame_3191_10; unsigned long long csrd_frame_3191_11 = ((csrd_frame_3191_10) & 4294967295ULL); (void)csrd_frame_3191_11; unsigned long long csrd_frame_3191_12 = ((csrd_frame_3191_5) & 255ULL); (void)csrd_frame_3191_12; unsigned long long csrd_frame_3191_13 = (((unsigned long long)((signed char)((csrd_frame_3191_12)<=127ULL ? (long long)(csrd_frame_3191_12) : ~(long long)(255ULL-(csrd_frame_3191_12))))) & 4294967295ULL); (void)csrd_frame_3191_13; unsigned long long csrd_frame_3191_14 = (((csrd_frame_3191_11)+(csrd_frame_3191_13)-0ULL) & 4294967295ULL); (void)csrd_frame_3191_14; unsigned long long csrd_frame_3191_15 = ((csrd_frame_3191_9) & 65535ULL); (void)csrd_frame_3191_15; unsigned long long csrd_frame_3191_16 = (((unsigned long long)((short)((csrd_frame_3191_15)<=32767ULL ? (long long)(csrd_frame_3191_15) : ~(long long)(65535ULL-(csrd_frame_3191_15))))) & 4294967295ULL); (void)csrd_frame_3191_16; unsigned long long csrd_frame_3191_17 = (((csrd_frame_3191_14)+(csrd_frame_3191_16)-0ULL) & 4294967295ULL); (void)csrd_frame_3191_17; unsigned long long csrd_frame_3191_18 = csrd_frame_3191_17; (void)csrd_frame_3191_18; unsigned long long csrd_frame_3191_19 = ((csrd_frame_3191_18) & 4294967295ULL); (void)csrd_frame_3191_19; unsigned long long csrd_frame_3191_20 = ((unsigned long long)((int)((csrd_frame_3191_19)<=2147483647ULL ? (long long)(csrd_frame_3191_19) : ~(long long)(4294967295ULL-(csrd_frame_3191_19))))); (void)csrd_frame_3191_20; unsigned long long csrd_frame_3191_21 = (3ULL*(csrd_frame_3191_20)+0ULL); (void)csrd_frame_3191_21; unsigned long long csrd_frame_3191_22 = ((csrd_frame_3191_21)-(5ULL)+0ULL); (void)csrd_frame_3191_22; unsigned long long csrd_frame_3191_23 = csrd_frame_3191_22; (void)csrd_frame_3191_23; unsigned long long csrd_frame_3191_24 = ((csrd_frame_3191_23)+(4294967297ULL)-0ULL); (void)csrd_frame_3191_24; unsigned long long csrd_frame_3191_25 = csrd_frame_3191_24; (void)csrd_frame_3191_25; unsigned long long csrd_frame_3191_26 = ((csrd_frame_3191_0) & 4294967295ULL); (void)csrd_frame_3191_26; unsigned long long csrd_frame_3191_27 = (csrd_frame_3191_26); (void)csrd_frame_3191_27; unsigned long long csrd_frame_3191_28 = (csrd_frame_3191_27); (void)csrd_frame_3191_28; unsigned long long csrd_frame_3191_29 = ((csrd_frame_3191_28 << 32u)); (void)csrd_frame_3191_29; unsigned long long csrd_frame_3191_30 = (csrd_frame_3191_29); (void)csrd_frame_3191_30; unsigned long long csrd_frame_3191_31 = ((csrd_frame_3191_1) & 4294967295ULL); (void)csrd_frame_3191_31; unsigned long long csrd_frame_3191_32 = (csrd_frame_3191_31); (void)csrd_frame_3191_32; unsigned long long csrd_frame_3191_33 = (csrd_frame_3191_32); (void)csrd_frame_3191_33; unsigned long long csrd_frame_3191_34 = ((csrd_frame_3191_30 | csrd_frame_3191_33)); (void)csrd_frame_3191_34; unsigned long long csrd_frame_3191_35 = csrd_frame_3191_34; (void)csrd_frame_3191_35; unsigned long long csrd_frame_3191_36 = (7ULL*(csrd_frame_3191_35)+0ULL); (void)csrd_frame_3191_36; unsigned long long csrd_frame_3191_37 = ((csrd_frame_3191_36)+(18364758544493064720ULL)-0ULL); (void)csrd_frame_3191_37; unsigned long long csrd_frame_3191_38 = csrd_frame_3191_37; (void)csrd_frame_3191_38; unsigned long long csrd_frame_3191_39 = ((csrd_frame_3191_18) & 4294967295ULL); (void)csrd_frame_3191_39; unsigned long long csrd_frame_3191_40 = ((0ULL) & 4294967295ULL); (void)csrd_frame_3191_40; unsigned long long csrd_frame_3191_41 = ((((csrd_frame_3191_39 ^ 2147483648ULL) < (csrd_frame_3191_40 ^ 2147483648ULL))) & 4294967295ULL); (void)csrd_frame_3191_41; unsigned long long csrd_frame_3191_42 = ((csrd_frame_3191_41) & 4294967295ULL); (void)csrd_frame_3191_42; unsigned long long csrd_frame_3191_43 = (((csrd_frame_3191_42 != 0ULL)) & 1ULL); (void)csrd_frame_3191_43; unsigned long long csrd_frame_3191_44 = csrd_frame_3191_43; (void)csrd_frame_3191_44; unsigned long long csrd_frame_3191_45 = ((csrd_frame_3191_44) & 1ULL); (void)csrd_frame_3191_45; unsigned long long csrd_frame_3191_46 = ((csrd_frame_3191_45) & 4294967295ULL); (void)csrd_frame_3191_46; unsigned long long csrd_frame_3191_47 = ((csrd_frame_3191_46) & 4294967295ULL); (void)csrd_frame_3191_47; unsigned long long csrd_frame_3191_48 = ((4294967295ULL*(csrd_frame_3191_18)+0ULL) & 4294967295ULL); (void)csrd_frame_3191_48; unsigned long long csrd_frame_3191_49 = (csrd_frame_3191_47 ? csrd_frame_3191_48 : csrd_frame_3191_18); (void)csrd_frame_3191_49; unsigned long long csrd_frame_3191_50 = csrd_frame_3191_49; (void)csrd_frame_3191_50; unsigned long long csrd_frame_3191_51 = (csrd_frame_3191_38); (void)csrd_frame_3191_51; unsigned long long csrd_frame_3191_52 = ((csrd_frame_3191_51 >> 32u)); (void)csrd_frame_3191_52; unsigned long long csrd_frame_3191_53 = ((csrd_frame_3191_52) & 4294967295ULL); (void)csrd_frame_3191_53; unsigned long long csrd_frame_3191_54 = ((csrd_frame_3191_25) & 4294967295ULL); (void)csrd_frame_3191_54; unsigned long long csrd_frame_3191_55 = (((csrd_frame_3191_53)+(csrd_frame_3191_54)-0ULL) & 4294967295ULL); (void)csrd_frame_3191_55; unsigned long long csrd_frame_3191_56 = (((csrd_frame_3191_55)+(csrd_frame_3191_50)-0ULL) & 4294967295ULL); (void)csrd_frame_3191_56; unsigned long long csrd_frame_3191_57 = csrd_frame_3191_56; (void)csrd_frame_3191_57; unsigned long long csrd_frame_3191_58 = ((csrd_frame_3191_3) & 255ULL); (void)csrd_frame_3191_58; unsigned long long csrd_frame_3191_59 = ((csrd_frame_3191_5) & 255ULL); (void)csrd_frame_3191_59; unsigned long long csrd_frame_3191_60 = ((csrd_frame_3191_9) & 65535ULL); (void)csrd_frame_3191_60; unsigned long long csrd_frame_3191_61 = ((csrd_frame_3191_18) & 4294967295ULL); (void)csrd_frame_3191_61; unsigned long long csrd_frame_3191_62 = (csrd_frame_3191_23); (void)csrd_frame_3191_62; unsigned long long csrd_frame_3191_63 = (csrd_frame_3191_25); (void)csrd_frame_3191_63; unsigned long long csrd_frame_3191_64 = (csrd_frame_3191_38); (void)csrd_frame_3191_64; unsigned long long csrd_frame_3191_65 = ((csrd_frame_3191_44) & 1ULL); (void)csrd_frame_3191_65; unsigned long long csrd_frame_3191_66 = ((csrd_frame_3191_50) & 4294967295ULL); (void)csrd_frame_3191_66; unsigned long long csrd_frame_3191_67 = ((csrd_frame_3191_57) & 4294967295ULL); (void)csrd_frame_3191_67; unsigned char byte = ((unsigned char)(csrd_frame_3191_58)); (void)byte; signed char small = ((signed char)((csrd_frame_3191_59)<=127ULL ? (long long)(csrd_frame_3191_59) : ~(long long)(255ULL-(csrd_frame_3191_59)))); (void)small; short half = ((short)((csrd_frame_3191_60)<=32767ULL ? (long long)(csrd_frame_3191_60) : ~(long long)(65535ULL-(csrd_frame_3191_60)))); (void)half; int delta = ((int)((csrd_frame_3191_61)<=2147483647ULL ? (long long)(csrd_frame_3191_61) : ~(long long)(4294967295ULL-(csrd_frame_3191_61)))); (void)delta; long wide = ((long)((csrd_frame_3191_62)<=9223372036854775807ULL ? (long long)(csrd_frame_3191_62) : ~(long long)(18446744073709551615ULL-(csrd_frame_3191_62)))); (void)wide; long long adjusted = ((long long)((csrd_frame_3191_63)<=9223372036854775807ULL ? (long long)(csrd_frame_3191_63) : ~(long long)(18446744073709551615ULL-(csrd_frame_3191_63)))); (void)adjusted; unsigned long long packed = ((unsigned long long)(csrd_frame_3191_64)); (void)packed; _Bool negative = ((_Bool)(csrd_frame_3191_65)); (void)negative; int magnitude = ((int)((csrd_frame_3191_66)<=2147483647ULL ? (long long)(csrd_frame_3191_66) : ~(long long)(4294967295ULL-(csrd_frame_3191_66)))); (void)magnitude; unsigned int result = ((unsigned int)(csrd_frame_3191_67)); (void)result









;
    record_event(result);
    if (limit < 0) return result;
    while (limit-- > 0) {
        y = next_value(result);
        _Static_assert((unsigned char)~0u == 255u && ~0 == -1 && ~0L == -1L && ~0LL == -1LL && (-1 >> 1) == -1 && sizeof(short)==2 && sizeof(int)==4 && sizeof(long)==8 && sizeof(long long)==8 && (((char)-1 < 0)==0), "C-SRD integer data model mismatch"); unsigned long long csrd_frame_3881_0 = (((unsigned long long)(y)) & 4294967295ULL); (void)csrd_frame_3881_0; unsigned long long csrd_frame_3881_1 = (((unsigned long long)(magnitude)) & 4294967295ULL); (void)csrd_frame_3881_1; unsigned long long csrd_frame_3881_2 = ((unsigned long long)(packed)); (void)csrd_frame_3881_2; unsigned long long csrd_frame_3881_3 = ((csrd_frame_3881_0) & 255ULL); (void)csrd_frame_3881_3; unsigned long long csrd_frame_3881_4 = ((csrd_frame_3881_3) & 255ULL); (void)csrd_frame_3881_4; unsigned long long csrd_frame_3881_5 = (((unsigned long long)((signed char)((csrd_frame_3881_4)<=127ULL ? (long long)(csrd_frame_3881_4) : ~(long long)(255ULL-(csrd_frame_3881_4))))) & 4294967295ULL); (void)csrd_frame_3881_5; unsigned long long csrd_frame_3881_6 = csrd_frame_3881_5; (void)csrd_frame_3881_6; unsigned long long csrd_frame_3881_7 = ((csrd_frame_3881_6) & 4294967295ULL); (void)csrd_frame_3881_7; unsigned long long csrd_frame_3881_8 = ((unsigned long long)((int)((csrd_frame_3881_7)<=2147483647ULL ? (long long)(csrd_frame_3881_7) : ~(long long)(4294967295ULL-(csrd_frame_3881_7))))); (void)csrd_frame_3881_8; unsigned long long csrd_frame_3881_9 = ((csrd_frame_3881_1) & 4294967295ULL); (void)csrd_frame_3881_9; unsigned long long csrd_frame_3881_10 = ((unsigned long long)((int)((csrd_frame_3881_9)<=2147483647ULL ? (long long)(csrd_frame_3881_9) : ~(long long)(4294967295ULL-(csrd_frame_3881_9))))); (void)csrd_frame_3881_10; unsigned long long csrd_frame_3881_11 = ((csrd_frame_3881_8)+(csrd_frame_3881_10)-0ULL); (void)csrd_frame_3881_11; unsigned long long csrd_frame_3881_12 = csrd_frame_3881_11; (void)csrd_frame_3881_12; unsigned long long csrd_frame_3881_13 = ((csrd_frame_3881_0) & 4294967295ULL); (void)csrd_frame_3881_13; unsigned long long csrd_frame_3881_14 = (csrd_frame_3881_13); (void)csrd_frame_3881_14; unsigned long long csrd_frame_3881_15 = (csrd_frame_3881_14); (void)csrd_frame_3881_15; unsigned long long csrd_frame_3881_16 = ((csrd_frame_3881_15 << 17u)); (void)csrd_frame_3881_16; unsigned long long csrd_frame_3881_17 = ((csrd_frame_3881_2)+(csrd_frame_3881_16)-0ULL); (void)csrd_frame_3881_17; unsigned long long csrd_frame_3881_18 = csrd_frame_3881_17; (void)csrd_frame_3881_18; unsigned long long csrd_frame_3881_19 = (3ULL*(csrd_frame_3881_18)+0ULL); (void)csrd_frame_3881_19; unsigned long long csrd_frame_3881_20 = ((csrd_frame_3881_19)+(11ULL)-0ULL); (void)csrd_frame_3881_20; unsigned long long csrd_frame_3881_21 = csrd_frame_3881_20; (void)csrd_frame_3881_21; unsigned long long csrd_frame_3881_22 = (csrd_frame_3881_12); (void)csrd_frame_3881_22; unsigned long long csrd_frame_3881_23 = (((unsigned long long)(((long long)((csrd_frame_3881_22)<=9223372036854775807ULL ? (long long)(csrd_frame_3881_22) : ~(long long)(18446744073709551615ULL-(csrd_frame_3881_22)))) >> 2u))); (void)csrd_frame_3881_23; unsigned long long csrd_frame_3881_24 = csrd_frame_3881_23; (void)csrd_frame_3881_24; unsigned long long csrd_frame_3881_25 = (csrd_frame_3881_21); (void)csrd_frame_3881_25; unsigned long long csrd_frame_3881_26 = ((csrd_frame_3881_25 >> 32u)); (void)csrd_frame_3881_26; unsigned long long csrd_frame_3881_27 = ((csrd_frame_3881_26) & 4294967295ULL); (void)csrd_frame_3881_27; unsigned long long csrd_frame_3881_28 = ((csrd_frame_3881_24) & 4294967295ULL); (void)csrd_frame_3881_28; unsigned long long csrd_frame_3881_29 = (((csrd_frame_3881_27)+(csrd_frame_3881_28)-0ULL) & 4294967295ULL); (void)csrd_frame_3881_29; unsigned long long csrd_frame_3881_30 = csrd_frame_3881_29; (void)csrd_frame_3881_30; unsigned long long csrd_frame_3881_31 = ((csrd_frame_3881_6) & 4294967295ULL); (void)csrd_frame_3881_31; unsigned long long csrd_frame_3881_32 = (csrd_frame_3881_12); (void)csrd_frame_3881_32; unsigned long long csrd_frame_3881_33 = (csrd_frame_3881_21); (void)csrd_frame_3881_33; unsigned long long csrd_frame_3881_34 = (csrd_frame_3881_24); (void)csrd_frame_3881_34; unsigned long long csrd_frame_3881_35 = ((csrd_frame_3881_30) & 4294967295ULL); (void)csrd_frame_3881_35; packed = ((unsigned long long)(csrd_frame_3881_33)); result = ((unsigned int)(csrd_frame_3881_35)); int step = ((int)((csrd_frame_3881_31)<=2147483647ULL ? (long long)(csrd_frame_3881_31) : ~(long long)(4294967295ULL-(csrd_frame_3881_31)))); (void)step; long long blended = ((long long)((csrd_frame_3881_32)<=9223372036854775807ULL ? (long long)(csrd_frame_3881_32) : ~(long long)(18446744073709551615ULL-(csrd_frame_3881_32)))); (void)blended; long long shifted = ((long long)((csrd_frame_3881_34)<=9223372036854775807ULL ? (long long)(csrd_frame_3881_34) : ~(long long)(18446744073709551615ULL-(csrd_frame_3881_34)))); (void)shifted




;
        buffer[0] = result;
        buffer[2] = (uint32_t)packed;
        record_event(y);
    }
    return result;
}
int region_outputs(uint32_t *buffer, uint32_t x, uint32_t y)
{
    _Static_assert((unsigned char)~0u == 255u && ~0 == -1 && ~0L == -1L && ~0LL == -1LL && (-1 >> 1) == -1 && sizeof(short)==2 && sizeof(int)==4 && sizeof(long)==8 && sizeof(long long)==8 && (((char)-1 < 0)==0), "C-SRD integer data model mismatch"); unsigned long long csrd_frame_4368_0 = (((unsigned long long)(x)) & 4294967295ULL); (void)csrd_frame_4368_0; unsigned long long csrd_frame_4368_1 = (((unsigned long long)(y)) & 4294967295ULL); (void)csrd_frame_4368_1; unsigned long long csrd_frame_4368_2 = ((csrd_frame_4368_0) & 255ULL); (void)csrd_frame_4368_2; unsigned long long csrd_frame_4368_3 = csrd_frame_4368_2; (void)csrd_frame_4368_3; unsigned long long csrd_frame_4368_4 = ((csrd_frame_4368_1) & 65535ULL); (void)csrd_frame_4368_4; unsigned long long csrd_frame_4368_5 = csrd_frame_4368_4; (void)csrd_frame_4368_5; unsigned long long csrd_frame_4368_6 = ((csrd_frame_4368_3) & 255ULL); (void)csrd_frame_4368_6; unsigned long long csrd_frame_4368_7 = ((csrd_frame_4368_6) & 4294967295ULL); (void)csrd_frame_4368_7; unsigned long long csrd_frame_4368_8 = ((csrd_frame_4368_5) & 65535ULL); (void)csrd_frame_4368_8; unsigned long long csrd_frame_4368_9 = ((csrd_frame_4368_8) & 4294967295ULL); (void)csrd_frame_4368_9; unsigned long long csrd_frame_4368_10 = (((csrd_frame_4368_7)+(csrd_frame_4368_9)-0ULL) & 4294967295ULL); (void)csrd_frame_4368_10; unsigned long long csrd_frame_4368_11 = ((csrd_frame_4368_10) & 4294967295ULL); (void)csrd_frame_4368_11; unsigned long long csrd_frame_4368_12 = (((csrd_frame_4368_11 != 0ULL)) & 1ULL); (void)csrd_frame_4368_12; unsigned long long csrd_frame_4368_13 = csrd_frame_4368_12; (void)csrd_frame_4368_13; unsigned long long csrd_frame_4368_14 = ((csrd_frame_4368_3) & 255ULL); (void)csrd_frame_4368_14; unsigned long long csrd_frame_4368_15 = (((unsigned long long)((signed char)((csrd_frame_4368_14)<=127ULL ? (long long)(csrd_frame_4368_14) : ~(long long)(255ULL-(csrd_frame_4368_14))))) & 4294967295ULL); (void)csrd_frame_4368_15; unsigned long long csrd_frame_4368_16 = csrd_frame_4368_15; (void)csrd_frame_4368_16; unsigned long long csrd_frame_4368_17 = ((csrd_frame_4368_16) & 4294967295ULL); (void)csrd_frame_4368_17; unsigned long long csrd_frame_4368_18 = ((csrd_frame_4368_5) & 65535ULL); (void)csrd_frame_4368_18; unsigned long long csrd_frame_4368_19 = ((csrd_frame_4368_18) & 4294967295ULL); (void)csrd_frame_4368_19; unsigned long long csrd_frame_4368_20 = ((csrd_frame_4368_19) & 4294967295ULL); (void)csrd_frame_4368_20; unsigned long long csrd_frame_4368_21 = ((((csrd_frame_4368_17 ^ 2147483648ULL) < (csrd_frame_4368_20 ^ 2147483648ULL))) & 4294967295ULL); (void)csrd_frame_4368_21; unsigned long long csrd_frame_4368_22 = csrd_frame_4368_21; (void)csrd_frame_4368_22; unsigned long long csrd_frame_4368_23 = (((csrd_frame_4368_16)+(csrd_frame_4368_0)-0ULL) & 4294967295ULL); (void)csrd_frame_4368_23; unsigned long long csrd_frame_4368_24 = csrd_frame_4368_23; (void)csrd_frame_4368_24; unsigned long long csrd_frame_4368_25 = ((csrd_frame_4368_5) & 65535ULL); (void)csrd_frame_4368_25; unsigned long long csrd_frame_4368_26 = ((unsigned long long)((short)((csrd_frame_4368_25)<=32767ULL ? (long long)(csrd_frame_4368_25) : ~(long long)(65535ULL-(csrd_frame_4368_25))))); (void)csrd_frame_4368_26; unsigned long long csrd_frame_4368_27 = csrd_frame_4368_26; (void)csrd_frame_4368_27; unsigned long long csrd_frame_4368_28 = ((csrd_frame_4368_24) & 4294967295ULL); (void)csrd_frame_4368_28; unsigned long long csrd_frame_4368_29 = (csrd_frame_4368_28); (void)csrd_frame_4368_29; unsigned long long csrd_frame_4368_30 = (csrd_frame_4368_29); (void)csrd_frame_4368_30; unsigned long long csrd_frame_4368_31 = ((csrd_frame_4368_30 << 32u)); (void)csrd_frame_4368_31; unsigned long long csrd_frame_4368_32 = (csrd_frame_4368_31); (void)csrd_frame_4368_32; unsigned long long csrd_frame_4368_33 = ((csrd_frame_4368_5) & 65535ULL); (void)csrd_frame_4368_33; unsigned long long csrd_frame_4368_34 = (csrd_frame_4368_33); (void)csrd_frame_4368_34; unsigned long long csrd_frame_4368_35 = (csrd_frame_4368_34); (void)csrd_frame_4368_35; unsigned long long csrd_frame_4368_36 = ((csrd_frame_4368_32 | csrd_frame_4368_35)); (void)csrd_frame_4368_36; unsigned long long csrd_frame_4368_37 = csrd_frame_4368_36; (void)csrd_frame_4368_37; unsigned long long csrd_frame_4368_38 = ((csrd_frame_4368_37)+(9ULL)-0ULL); (void)csrd_frame_4368_38; unsigned long long csrd_frame_4368_39 = csrd_frame_4368_38; (void)csrd_frame_4368_39; unsigned long long csrd_frame_4368_40 = (csrd_frame_4368_39); (void)csrd_frame_4368_40; unsigned long long csrd_frame_4368_41 = ((csrd_frame_4368_40 >> 32u)); (void)csrd_frame_4368_41; unsigned long long csrd_frame_4368_42 = ((csrd_frame_4368_41) & 4294967295ULL); (void)csrd_frame_4368_42; unsigned long long csrd_frame_4368_43 = (csrd_frame_4368_27); (void)csrd_frame_4368_43; unsigned long long csrd_frame_4368_44 = (((unsigned long long)(((long long)((csrd_frame_4368_43)<=9223372036854775807ULL ? (long long)(csrd_frame_4368_43) : ~(long long)(18446744073709551615ULL-(csrd_frame_4368_43)))) >> 3u))); (void)csrd_frame_4368_44; unsigned long long csrd_frame_4368_45 = ((csrd_frame_4368_44) & 4294967295ULL); (void)csrd_frame_4368_45; unsigned long long csrd_frame_4368_46 = (((csrd_frame_4368_42)+(csrd_frame_4368_45)-0ULL) & 4294967295ULL); (void)csrd_frame_4368_46; unsigned long long csrd_frame_4368_47 = ((csrd_frame_4368_13) & 1ULL); (void)csrd_frame_4368_47; unsigned long long csrd_frame_4368_48 = ((csrd_frame_4368_47) & 4294967295ULL); (void)csrd_frame_4368_48; unsigned long long csrd_frame_4368_49 = (((csrd_frame_4368_46)+(csrd_frame_4368_48)-0ULL) & 4294967295ULL); (void)csrd_frame_4368_49; unsigned long long csrd_frame_4368_50 = (((csrd_frame_4368_49)+(csrd_frame_4368_22)-0ULL) & 4294967295ULL); (void)csrd_frame_4368_50; unsigned long long csrd_frame_4368_51 = csrd_frame_4368_50; (void)csrd_frame_4368_51; unsigned long long csrd_frame_4368_52 = ((csrd_frame_4368_3) & 255ULL); (void)csrd_frame_4368_52; unsigned long long csrd_frame_4368_53 = ((csrd_frame_4368_5) & 65535ULL); (void)csrd_frame_4368_53; unsigned long long csrd_frame_4368_54 = ((csrd_frame_4368_13) & 1ULL); (void)csrd_frame_4368_54; unsigned long long csrd_frame_4368_55 = ((csrd_frame_4368_16) & 4294967295ULL); (void)csrd_frame_4368_55; unsigned long long csrd_frame_4368_56 = ((csrd_frame_4368_22) & 4294967295ULL); (void)csrd_frame_4368_56; unsigned long long csrd_frame_4368_57 = ((csrd_frame_4368_24) & 4294967295ULL); (void)csrd_frame_4368_57; unsigned long long csrd_frame_4368_58 = (csrd_frame_4368_27); (void)csrd_frame_4368_58; unsigned long long csrd_frame_4368_59 = (csrd_frame_4368_39); (void)csrd_frame_4368_59; unsigned long long csrd_frame_4368_60 = ((csrd_frame_4368_51) & 4294967295ULL); (void)csrd_frame_4368_60; unsigned char byte = ((unsigned char)(csrd_frame_4368_52)); (void)byte; unsigned short half = ((unsigned short)(csrd_frame_4368_53)); (void)half; _Bool flag = ((_Bool)(csrd_frame_4368_54)); (void)flag; int small = ((int)((csrd_frame_4368_55)<=2147483647ULL ? (long long)(csrd_frame_4368_55) : ~(long long)(4294967295ULL-(csrd_frame_4368_55)))); (void)small; int ordered = ((int)((csrd_frame_4368_56)<=2147483647ULL ? (long long)(csrd_frame_4368_56) : ~(long long)(4294967295ULL-(csrd_frame_4368_56)))); (void)ordered; unsigned int mixed = ((unsigned int)(csrd_frame_4368_57)); (void)mixed; long long extended = ((long long)((csrd_frame_4368_58)<=9223372036854775807ULL ? (long long)(csrd_frame_4368_58) : ~(long long)(18446744073709551615ULL-(csrd_frame_4368_58)))); (void)extended; unsigned long long packed = ((unsigned long long)(csrd_frame_4368_59)); (void)packed; unsigned int result = ((unsigned int)(csrd_frame_4368_60)); (void)result








;
    record_event(result);
    buffer[0] = (uint32_t)packed;
    buffer[1] = result;
    buffer[2] = (uint32_t)extended;
    return flag == ordered;
}
