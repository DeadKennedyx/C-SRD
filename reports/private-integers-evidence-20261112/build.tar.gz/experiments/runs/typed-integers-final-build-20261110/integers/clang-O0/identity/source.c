typedef unsigned char __u_char;
typedef unsigned short int __u_short;
typedef unsigned int __u_int;
typedef unsigned long int __u_long;
typedef signed char __int8_t;
typedef unsigned char __uint8_t;
typedef signed short int __int16_t;
typedef unsigned short int __uint16_t;
typedef signed int __int32_t;
typedef unsigned int __uint32_t;
typedef signed long int __int64_t;
typedef unsigned long int __uint64_t;
typedef __int8_t __int_least8_t;
typedef __uint8_t __uint_least8_t;
typedef __int16_t __int_least16_t;
typedef __uint16_t __uint_least16_t;
typedef __int32_t __int_least32_t;
typedef __uint32_t __uint_least32_t;
typedef __int64_t __int_least64_t;
typedef __uint64_t __uint_least64_t;
typedef long int __quad_t;
typedef unsigned long int __u_quad_t;
typedef long int __intmax_t;
typedef unsigned long int __uintmax_t;
typedef unsigned long int __dev_t;
typedef unsigned int __uid_t;
typedef unsigned int __gid_t;
typedef unsigned long int __ino_t;
typedef unsigned long int __ino64_t;
typedef unsigned int __mode_t;
typedef unsigned int __nlink_t;
typedef long int __off_t;
typedef long int __off64_t;
typedef int __pid_t;
typedef struct { int __val[2]; } __fsid_t;
typedef long int __clock_t;
typedef unsigned long int __rlim_t;
typedef unsigned long int __rlim64_t;
typedef unsigned int __id_t;
typedef long int __time_t;
typedef unsigned int __useconds_t;
typedef long int __suseconds_t;
typedef long int __suseconds64_t;
typedef int __daddr_t;
typedef int __key_t;
typedef int __clockid_t;
typedef void * __timer_t;
typedef int __blksize_t;
typedef long int __blkcnt_t;
typedef long int __blkcnt64_t;
typedef unsigned long int __fsblkcnt_t;
typedef unsigned long int __fsblkcnt64_t;
typedef unsigned long int __fsfilcnt_t;
typedef unsigned long int __fsfilcnt64_t;
typedef long int __fsword_t;
typedef long int __ssize_t;
typedef long int __syscall_slong_t;
typedef unsigned long int __syscall_ulong_t;
typedef __off64_t __loff_t;
typedef char *__caddr_t;
typedef long int __intptr_t;
typedef unsigned int __socklen_t;
typedef int __sig_atomic_t;
typedef __int8_t int8_t;
typedef __int16_t int16_t;
typedef __int32_t int32_t;
typedef __int64_t int64_t;
typedef __uint8_t uint8_t;
typedef __uint16_t uint16_t;
typedef __uint32_t uint32_t;
typedef __uint64_t uint64_t;
typedef __int_least8_t int_least8_t;
typedef __int_least16_t int_least16_t;
typedef __int_least32_t int_least32_t;
typedef __int_least64_t int_least64_t;
typedef __uint_least8_t uint_least8_t;
typedef __uint_least16_t uint_least16_t;
typedef __uint_least32_t uint_least32_t;
typedef __uint_least64_t uint_least64_t;
typedef signed char int_fast8_t;
typedef long int int_fast16_t;
typedef long int int_fast32_t;
typedef long int int_fast64_t;
typedef unsigned char uint_fast8_t;
typedef unsigned long int uint_fast16_t;
typedef unsigned long int uint_fast32_t;
typedef unsigned long int uint_fast64_t;
typedef long int intptr_t;
typedef unsigned long int uintptr_t;
typedef __intmax_t intmax_t;
typedef __uintmax_t uintmax_t;

extern uint32_t next_value(uint32_t value);
extern void record_event(uint32_t value);
uint32_t region_pipeline(uint32_t *buffer, uint32_t x, int limit)
{
    uint32_t y = buffer[0];
    _Static_assert((unsigned char)~0u == 255u && ~0 == -1 && ~0L == -1L && ~0LL == -1LL && (-1 >> 1) == -1 && sizeof(short)==2 && sizeof(int)==4 && sizeof(long)==8 && sizeof(long long)==8 && (((char)-1 < 0)==0), "C-SRD integer data model mismatch"); unsigned long long csrd_frame_3192_0 = (((unsigned long long)(x)) & 4294967295ULL); (void)csrd_frame_3192_0; unsigned long long csrd_frame_3192_1 = (((unsigned long long)(y)) & 4294967295ULL); (void)csrd_frame_3192_1; unsigned long long csrd_frame_3192_2 = ((csrd_frame_3192_0) & 255ULL); (void)csrd_frame_3192_2; unsigned long long csrd_frame_3192_3 = csrd_frame_3192_2; (void)csrd_frame_3192_3; unsigned long long csrd_frame_3192_4 = ((csrd_frame_3192_1) & 255ULL); (void)csrd_frame_3192_4; unsigned long long csrd_frame_3192_5 = csrd_frame_3192_4; (void)csrd_frame_3192_5; unsigned long long csrd_frame_3192_6 = ((csrd_frame_3192_0) & 4294967295ULL); (void)csrd_frame_3192_6; unsigned long long csrd_frame_3192_7 = (((csrd_frame_3192_6 >> 8u)) & 4294967295ULL); (void)csrd_frame_3192_7; unsigned long long csrd_frame_3192_8 = ((csrd_frame_3192_7) & 65535ULL); (void)csrd_frame_3192_8; unsigned long long csrd_frame_3192_9 = csrd_frame_3192_8; (void)csrd_frame_3192_9; unsigned long long csrd_frame_3192_10 = ((csrd_frame_3192_3) & 255ULL); (void)csrd_frame_3192_10; unsigned long long csrd_frame_3192_11 = ((csrd_frame_3192_10) & 4294967295ULL); (void)csrd_frame_3192_11; unsigned long long csrd_frame_3192_12 = ((csrd_frame_3192_5) & 255ULL); (void)csrd_frame_3192_12; unsigned long long csrd_frame_3192_13 = (((unsigned long long)((signed char)((csrd_frame_3192_12)<=127ULL ? (long long)(csrd_frame_3192_12) : ~(long long)(255ULL-(csrd_frame_3192_12))))) & 4294967295ULL); (void)csrd_frame_3192_13; unsigned long long csrd_frame_3192_14 = (((csrd_frame_3192_11)+(csrd_frame_3192_13)-0ULL) & 4294967295ULL); (void)csrd_frame_3192_14; unsigned long long csrd_frame_3192_15 = ((csrd_frame_3192_9) & 65535ULL); (void)csrd_frame_3192_15; unsigned long long csrd_frame_3192_16 = (((unsigned long long)((short)((csrd_frame_3192_15)<=32767ULL ? (long long)(csrd_frame_3192_15) : ~(long long)(65535ULL-(csrd_frame_3192_15))))) & 4294967295ULL); (void)csrd_frame_3192_16; unsigned long long csrd_frame_3192_17 = (((csrd_frame_3192_14)+(csrd_frame_3192_16)-0ULL) & 4294967295ULL); (void)csrd_frame_3192_17; unsigned long long csrd_frame_3192_18 = csrd_frame_3192_17; (void)csrd_frame_3192_18; unsigned long long csrd_frame_3192_19 = ((csrd_frame_3192_18) & 4294967295ULL); (void)csrd_frame_3192_19; unsigned long long csrd_frame_3192_20 = ((unsigned long long)((int)((csrd_frame_3192_19)<=2147483647ULL ? (long long)(csrd_frame_3192_19) : ~(long long)(4294967295ULL-(csrd_frame_3192_19))))); (void)csrd_frame_3192_20; unsigned long long csrd_frame_3192_21 = (3ULL*(csrd_frame_3192_20)+0ULL); (void)csrd_frame_3192_21; unsigned long long csrd_frame_3192_22 = ((csrd_frame_3192_21)-(5ULL)+0ULL); (void)csrd_frame_3192_22; unsigned long long csrd_frame_3192_23 = csrd_frame_3192_22; (void)csrd_frame_3192_23; unsigned long long csrd_frame_3192_24 = ((csrd_frame_3192_23)+(4294967297ULL)-0ULL); (void)csrd_frame_3192_24; unsigned long long csrd_frame_3192_25 = csrd_frame_3192_24; (void)csrd_frame_3192_25; unsigned long long csrd_frame_3192_26 = ((csrd_frame_3192_0) & 4294967295ULL); (void)csrd_frame_3192_26; unsigned long long csrd_frame_3192_27 = (csrd_frame_3192_26); (void)csrd_frame_3192_27; unsigned long long csrd_frame_3192_28 = (csrd_frame_3192_27); (void)csrd_frame_3192_28; unsigned long long csrd_frame_3192_29 = ((csrd_frame_3192_28 << 32u)); (void)csrd_frame_3192_29; unsigned long long csrd_frame_3192_30 = (csrd_frame_3192_29); (void)csrd_frame_3192_30; unsigned long long csrd_frame_3192_31 = ((csrd_frame_3192_1) & 4294967295ULL); (void)csrd_frame_3192_31; unsigned long long csrd_frame_3192_32 = (csrd_frame_3192_31); (void)csrd_frame_3192_32; unsigned long long csrd_frame_3192_33 = (csrd_frame_3192_32); (void)csrd_frame_3192_33; unsigned long long csrd_frame_3192_34 = ((csrd_frame_3192_30 | csrd_frame_3192_33)); (void)csrd_frame_3192_34; unsigned long long csrd_frame_3192_35 = csrd_frame_3192_34; (void)csrd_frame_3192_35; unsigned long long csrd_frame_3192_36 = (7ULL*(csrd_frame_3192_35)+0ULL); (void)csrd_frame_3192_36; unsigned long long csrd_frame_3192_37 = ((csrd_frame_3192_36)+(18364758544493064720ULL)-0ULL); (void)csrd_frame_3192_37; unsigned long long csrd_frame_3192_38 = csrd_frame_3192_37; (void)csrd_frame_3192_38; unsigned long long csrd_frame_3192_39 = ((csrd_frame_3192_18) & 4294967295ULL); (void)csrd_frame_3192_39; unsigned long long csrd_frame_3192_40 = ((0ULL) & 4294967295ULL); (void)csrd_frame_3192_40; unsigned long long csrd_frame_3192_41 = ((((csrd_frame_3192_39 ^ 2147483648ULL) < (csrd_frame_3192_40 ^ 2147483648ULL))) & 4294967295ULL); (void)csrd_frame_3192_41; unsigned long long csrd_frame_3192_42 = ((csrd_frame_3192_41) & 4294967295ULL); (void)csrd_frame_3192_42; unsigned long long csrd_frame_3192_43 = (((csrd_frame_3192_42 != 0ULL)) & 1ULL); (void)csrd_frame_3192_43; unsigned long long csrd_frame_3192_44 = csrd_frame_3192_43; (void)csrd_frame_3192_44; unsigned long long csrd_frame_3192_45 = ((csrd_frame_3192_44) & 1ULL); (void)csrd_frame_3192_45; unsigned long long csrd_frame_3192_46 = ((csrd_frame_3192_45) & 4294967295ULL); (void)csrd_frame_3192_46; unsigned long long csrd_frame_3192_47 = ((csrd_frame_3192_46) & 4294967295ULL); (void)csrd_frame_3192_47; unsigned long long csrd_frame_3192_48 = ((4294967295ULL*(csrd_frame_3192_18)+0ULL) & 4294967295ULL); (void)csrd_frame_3192_48; unsigned long long csrd_frame_3192_49 = (csrd_frame_3192_47 ? csrd_frame_3192_48 : csrd_frame_3192_18); (void)csrd_frame_3192_49; unsigned long long csrd_frame_3192_50 = csrd_frame_3192_49; (void)csrd_frame_3192_50; unsigned long long csrd_frame_3192_51 = (csrd_frame_3192_38); (void)csrd_frame_3192_51; unsigned long long csrd_frame_3192_52 = ((csrd_frame_3192_51 >> 32u)); (void)csrd_frame_3192_52; unsigned long long csrd_frame_3192_53 = ((csrd_frame_3192_52) & 4294967295ULL); (void)csrd_frame_3192_53; unsigned long long csrd_frame_3192_54 = ((csrd_frame_3192_25) & 4294967295ULL); (void)csrd_frame_3192_54; unsigned long long csrd_frame_3192_55 = (((csrd_frame_3192_53)+(csrd_frame_3192_54)-0ULL) & 4294967295ULL); (void)csrd_frame_3192_55; unsigned long long csrd_frame_3192_56 = (((csrd_frame_3192_55)+(csrd_frame_3192_50)-0ULL) & 4294967295ULL); (void)csrd_frame_3192_56; unsigned long long csrd_frame_3192_57 = csrd_frame_3192_56; (void)csrd_frame_3192_57; unsigned long long csrd_frame_3192_58 = ((csrd_frame_3192_3) & 255ULL); (void)csrd_frame_3192_58; unsigned long long csrd_frame_3192_59 = ((csrd_frame_3192_5) & 255ULL); (void)csrd_frame_3192_59; unsigned long long csrd_frame_3192_60 = ((csrd_frame_3192_9) & 65535ULL); (void)csrd_frame_3192_60; unsigned long long csrd_frame_3192_61 = ((csrd_frame_3192_18) & 4294967295ULL); (void)csrd_frame_3192_61; unsigned long long csrd_frame_3192_62 = (csrd_frame_3192_23); (void)csrd_frame_3192_62; unsigned long long csrd_frame_3192_63 = (csrd_frame_3192_25); (void)csrd_frame_3192_63; unsigned long long csrd_frame_3192_64 = (csrd_frame_3192_38); (void)csrd_frame_3192_64; unsigned long long csrd_frame_3192_65 = ((csrd_frame_3192_44) & 1ULL); (void)csrd_frame_3192_65; unsigned long long csrd_frame_3192_66 = ((csrd_frame_3192_50) & 4294967295ULL); (void)csrd_frame_3192_66; unsigned long long csrd_frame_3192_67 = ((csrd_frame_3192_57) & 4294967295ULL); (void)csrd_frame_3192_67; unsigned char byte = ((unsigned char)(csrd_frame_3192_58)); (void)byte; signed char small = ((signed char)((csrd_frame_3192_59)<=127ULL ? (long long)(csrd_frame_3192_59) : ~(long long)(255ULL-(csrd_frame_3192_59)))); (void)small; short half = ((short)((csrd_frame_3192_60)<=32767ULL ? (long long)(csrd_frame_3192_60) : ~(long long)(65535ULL-(csrd_frame_3192_60)))); (void)half; int delta = ((int)((csrd_frame_3192_61)<=2147483647ULL ? (long long)(csrd_frame_3192_61) : ~(long long)(4294967295ULL-(csrd_frame_3192_61)))); (void)delta; long wide = ((long)((csrd_frame_3192_62)<=9223372036854775807ULL ? (long long)(csrd_frame_3192_62) : ~(long long)(18446744073709551615ULL-(csrd_frame_3192_62)))); (void)wide; long long adjusted = ((long long)((csrd_frame_3192_63)<=9223372036854775807ULL ? (long long)(csrd_frame_3192_63) : ~(long long)(18446744073709551615ULL-(csrd_frame_3192_63)))); (void)adjusted; unsigned long long packed = ((unsigned long long)(csrd_frame_3192_64)); (void)packed; _Bool negative = ((_Bool)(csrd_frame_3192_65)); (void)negative; int magnitude = ((int)((csrd_frame_3192_66)<=2147483647ULL ? (long long)(csrd_frame_3192_66) : ~(long long)(4294967295ULL-(csrd_frame_3192_66)))); (void)magnitude; unsigned int result = ((unsigned int)(csrd_frame_3192_67)); (void)result









;
    record_event(result);
    if (limit < 0) return result;
    while (limit-- > 0) {
        y = next_value(result);
        _Static_assert((unsigned char)~0u == 255u && ~0 == -1 && ~0L == -1L && ~0LL == -1LL && (-1 >> 1) == -1 && sizeof(short)==2 && sizeof(int)==4 && sizeof(long)==8 && sizeof(long long)==8 && (((char)-1 < 0)==0), "C-SRD integer data model mismatch"); unsigned long long csrd_frame_3882_0 = (((unsigned long long)(y)) & 4294967295ULL); (void)csrd_frame_3882_0; unsigned long long csrd_frame_3882_1 = (((unsigned long long)(magnitude)) & 4294967295ULL); (void)csrd_frame_3882_1; unsigned long long csrd_frame_3882_2 = ((unsigned long long)(packed)); (void)csrd_frame_3882_2; unsigned long long csrd_frame_3882_3 = ((csrd_frame_3882_0) & 255ULL); (void)csrd_frame_3882_3; unsigned long long csrd_frame_3882_4 = ((csrd_frame_3882_3) & 255ULL); (void)csrd_frame_3882_4; unsigned long long csrd_frame_3882_5 = (((unsigned long long)((signed char)((csrd_frame_3882_4)<=127ULL ? (long long)(csrd_frame_3882_4) : ~(long long)(255ULL-(csrd_frame_3882_4))))) & 4294967295ULL); (void)csrd_frame_3882_5; unsigned long long csrd_frame_3882_6 = csrd_frame_3882_5; (void)csrd_frame_3882_6; unsigned long long csrd_frame_3882_7 = ((csrd_frame_3882_6) & 4294967295ULL); (void)csrd_frame_3882_7; unsigned long long csrd_frame_3882_8 = ((unsigned long long)((int)((csrd_frame_3882_7)<=2147483647ULL ? (long long)(csrd_frame_3882_7) : ~(long long)(4294967295ULL-(csrd_frame_3882_7))))); (void)csrd_frame_3882_8; unsigned long long csrd_frame_3882_9 = ((csrd_frame_3882_1) & 4294967295ULL); (void)csrd_frame_3882_9; unsigned long long csrd_frame_3882_10 = ((unsigned long long)((int)((csrd_frame_3882_9)<=2147483647ULL ? (long long)(csrd_frame_3882_9) : ~(long long)(4294967295ULL-(csrd_frame_3882_9))))); (void)csrd_frame_3882_10; unsigned long long csrd_frame_3882_11 = ((csrd_frame_3882_8)+(csrd_frame_3882_10)-0ULL); (void)csrd_frame_3882_11; unsigned long long csrd_frame_3882_12 = csrd_frame_3882_11; (void)csrd_frame_3882_12; unsigned long long csrd_frame_3882_13 = ((csrd_frame_3882_0) & 4294967295ULL); (void)csrd_frame_3882_13; unsigned long long csrd_frame_3882_14 = (csrd_frame_3882_13); (void)csrd_frame_3882_14; unsigned long long csrd_frame_3882_15 = (csrd_frame_3882_14); (void)csrd_frame_3882_15; unsigned long long csrd_frame_3882_16 = ((csrd_frame_3882_15 << 17u)); (void)csrd_frame_3882_16; unsigned long long csrd_frame_3882_17 = ((csrd_frame_3882_2)+(csrd_frame_3882_16)-0ULL); (void)csrd_frame_3882_17; unsigned long long csrd_frame_3882_18 = csrd_frame_3882_17; (void)csrd_frame_3882_18; unsigned long long csrd_frame_3882_19 = (3ULL*(csrd_frame_3882_18)+0ULL); (void)csrd_frame_3882_19; unsigned long long csrd_frame_3882_20 = ((csrd_frame_3882_19)+(11ULL)-0ULL); (void)csrd_frame_3882_20; unsigned long long csrd_frame_3882_21 = csrd_frame_3882_20; (void)csrd_frame_3882_21; unsigned long long csrd_frame_3882_22 = (csrd_frame_3882_12); (void)csrd_frame_3882_22; unsigned long long csrd_frame_3882_23 = (((unsigned long long)(((long long)((csrd_frame_3882_22)<=9223372036854775807ULL ? (long long)(csrd_frame_3882_22) : ~(long long)(18446744073709551615ULL-(csrd_frame_3882_22)))) >> 2u))); (void)csrd_frame_3882_23; unsigned long long csrd_frame_3882_24 = csrd_frame_3882_23; (void)csrd_frame_3882_24; unsigned long long csrd_frame_3882_25 = (csrd_frame_3882_21); (void)csrd_frame_3882_25; unsigned long long csrd_frame_3882_26 = ((csrd_frame_3882_25 >> 32u)); (void)csrd_frame_3882_26; unsigned long long csrd_frame_3882_27 = ((csrd_frame_3882_26) & 4294967295ULL); (void)csrd_frame_3882_27; unsigned long long csrd_frame_3882_28 = ((csrd_frame_3882_24) & 4294967295ULL); (void)csrd_frame_3882_28; unsigned long long csrd_frame_3882_29 = (((csrd_frame_3882_27)+(csrd_frame_3882_28)-0ULL) & 4294967295ULL); (void)csrd_frame_3882_29; unsigned long long csrd_frame_3882_30 = csrd_frame_3882_29; (void)csrd_frame_3882_30; unsigned long long csrd_frame_3882_31 = ((csrd_frame_3882_6) & 4294967295ULL); (void)csrd_frame_3882_31; unsigned long long csrd_frame_3882_32 = (csrd_frame_3882_12); (void)csrd_frame_3882_32; unsigned long long csrd_frame_3882_33 = (csrd_frame_3882_21); (void)csrd_frame_3882_33; unsigned long long csrd_frame_3882_34 = (csrd_frame_3882_24); (void)csrd_frame_3882_34; unsigned long long csrd_frame_3882_35 = ((csrd_frame_3882_30) & 4294967295ULL); (void)csrd_frame_3882_35; packed = ((unsigned long long)(csrd_frame_3882_33)); result = ((unsigned int)(csrd_frame_3882_35)); int step = ((int)((csrd_frame_3882_31)<=2147483647ULL ? (long long)(csrd_frame_3882_31) : ~(long long)(4294967295ULL-(csrd_frame_3882_31)))); (void)step; long long blended = ((long long)((csrd_frame_3882_32)<=9223372036854775807ULL ? (long long)(csrd_frame_3882_32) : ~(long long)(18446744073709551615ULL-(csrd_frame_3882_32)))); (void)blended; long long shifted = ((long long)((csrd_frame_3882_34)<=9223372036854775807ULL ? (long long)(csrd_frame_3882_34) : ~(long long)(18446744073709551615ULL-(csrd_frame_3882_34)))); (void)shifted




;
        buffer[0] = result;
        buffer[2] = (uint32_t)packed;
        record_event(y);
    }
    return result;
}
int region_outputs(uint32_t *buffer, uint32_t x, uint32_t y)
{
    _Static_assert((unsigned char)~0u == 255u && ~0 == -1 && ~0L == -1L && ~0LL == -1LL && (-1 >> 1) == -1 && sizeof(short)==2 && sizeof(int)==4 && sizeof(long)==8 && sizeof(long long)==8 && (((char)-1 < 0)==0), "C-SRD integer data model mismatch"); unsigned long long csrd_frame_4369_0 = (((unsigned long long)(x)) & 4294967295ULL); (void)csrd_frame_4369_0; unsigned long long csrd_frame_4369_1 = (((unsigned long long)(y)) & 4294967295ULL); (void)csrd_frame_4369_1; unsigned long long csrd_frame_4369_2 = ((csrd_frame_4369_0) & 255ULL); (void)csrd_frame_4369_2; unsigned long long csrd_frame_4369_3 = csrd_frame_4369_2; (void)csrd_frame_4369_3; unsigned long long csrd_frame_4369_4 = ((csrd_frame_4369_1) & 65535ULL); (void)csrd_frame_4369_4; unsigned long long csrd_frame_4369_5 = csrd_frame_4369_4; (void)csrd_frame_4369_5; unsigned long long csrd_frame_4369_6 = ((csrd_frame_4369_3) & 255ULL); (void)csrd_frame_4369_6; unsigned long long csrd_frame_4369_7 = ((csrd_frame_4369_6) & 4294967295ULL); (void)csrd_frame_4369_7; unsigned long long csrd_frame_4369_8 = ((csrd_frame_4369_5) & 65535ULL); (void)csrd_frame_4369_8; unsigned long long csrd_frame_4369_9 = ((csrd_frame_4369_8) & 4294967295ULL); (void)csrd_frame_4369_9; unsigned long long csrd_frame_4369_10 = (((csrd_frame_4369_7)+(csrd_frame_4369_9)-0ULL) & 4294967295ULL); (void)csrd_frame_4369_10; unsigned long long csrd_frame_4369_11 = ((csrd_frame_4369_10) & 4294967295ULL); (void)csrd_frame_4369_11; unsigned long long csrd_frame_4369_12 = (((csrd_frame_4369_11 != 0ULL)) & 1ULL); (void)csrd_frame_4369_12; unsigned long long csrd_frame_4369_13 = csrd_frame_4369_12; (void)csrd_frame_4369_13; unsigned long long csrd_frame_4369_14 = ((csrd_frame_4369_3) & 255ULL); (void)csrd_frame_4369_14; unsigned long long csrd_frame_4369_15 = (((unsigned long long)((signed char)((csrd_frame_4369_14)<=127ULL ? (long long)(csrd_frame_4369_14) : ~(long long)(255ULL-(csrd_frame_4369_14))))) & 4294967295ULL); (void)csrd_frame_4369_15; unsigned long long csrd_frame_4369_16 = csrd_frame_4369_15; (void)csrd_frame_4369_16; unsigned long long csrd_frame_4369_17 = ((csrd_frame_4369_16) & 4294967295ULL); (void)csrd_frame_4369_17; unsigned long long csrd_frame_4369_18 = ((csrd_frame_4369_5) & 65535ULL); (void)csrd_frame_4369_18; unsigned long long csrd_frame_4369_19 = ((csrd_frame_4369_18) & 4294967295ULL); (void)csrd_frame_4369_19; unsigned long long csrd_frame_4369_20 = ((csrd_frame_4369_19) & 4294967295ULL); (void)csrd_frame_4369_20; unsigned long long csrd_frame_4369_21 = ((((csrd_frame_4369_17 ^ 2147483648ULL) < (csrd_frame_4369_20 ^ 2147483648ULL))) & 4294967295ULL); (void)csrd_frame_4369_21; unsigned long long csrd_frame_4369_22 = csrd_frame_4369_21; (void)csrd_frame_4369_22; unsigned long long csrd_frame_4369_23 = (((csrd_frame_4369_16)+(csrd_frame_4369_0)-0ULL) & 4294967295ULL); (void)csrd_frame_4369_23; unsigned long long csrd_frame_4369_24 = csrd_frame_4369_23; (void)csrd_frame_4369_24; unsigned long long csrd_frame_4369_25 = ((csrd_frame_4369_5) & 65535ULL); (void)csrd_frame_4369_25; unsigned long long csrd_frame_4369_26 = ((unsigned long long)((short)((csrd_frame_4369_25)<=32767ULL ? (long long)(csrd_frame_4369_25) : ~(long long)(65535ULL-(csrd_frame_4369_25))))); (void)csrd_frame_4369_26; unsigned long long csrd_frame_4369_27 = csrd_frame_4369_26; (void)csrd_frame_4369_27; unsigned long long csrd_frame_4369_28 = ((csrd_frame_4369_24) & 4294967295ULL); (void)csrd_frame_4369_28; unsigned long long csrd_frame_4369_29 = (csrd_frame_4369_28); (void)csrd_frame_4369_29; unsigned long long csrd_frame_4369_30 = (csrd_frame_4369_29); (void)csrd_frame_4369_30; unsigned long long csrd_frame_4369_31 = ((csrd_frame_4369_30 << 32u)); (void)csrd_frame_4369_31; unsigned long long csrd_frame_4369_32 = (csrd_frame_4369_31); (void)csrd_frame_4369_32; unsigned long long csrd_frame_4369_33 = ((csrd_frame_4369_5) & 65535ULL); (void)csrd_frame_4369_33; unsigned long long csrd_frame_4369_34 = (csrd_frame_4369_33); (void)csrd_frame_4369_34; unsigned long long csrd_frame_4369_35 = (csrd_frame_4369_34); (void)csrd_frame_4369_35; unsigned long long csrd_frame_4369_36 = ((csrd_frame_4369_32 | csrd_frame_4369_35)); (void)csrd_frame_4369_36; unsigned long long csrd_frame_4369_37 = csrd_frame_4369_36; (void)csrd_frame_4369_37; unsigned long long csrd_frame_4369_38 = ((csrd_frame_4369_37)+(9ULL)-0ULL); (void)csrd_frame_4369_38; unsigned long long csrd_frame_4369_39 = csrd_frame_4369_38; (void)csrd_frame_4369_39; unsigned long long csrd_frame_4369_40 = (csrd_frame_4369_39); (void)csrd_frame_4369_40; unsigned long long csrd_frame_4369_41 = ((csrd_frame_4369_40 >> 32u)); (void)csrd_frame_4369_41; unsigned long long csrd_frame_4369_42 = ((csrd_frame_4369_41) & 4294967295ULL); (void)csrd_frame_4369_42; unsigned long long csrd_frame_4369_43 = (csrd_frame_4369_27); (void)csrd_frame_4369_43; unsigned long long csrd_frame_4369_44 = (((unsigned long long)(((long long)((csrd_frame_4369_43)<=9223372036854775807ULL ? (long long)(csrd_frame_4369_43) : ~(long long)(18446744073709551615ULL-(csrd_frame_4369_43)))) >> 3u))); (void)csrd_frame_4369_44; unsigned long long csrd_frame_4369_45 = ((csrd_frame_4369_44) & 4294967295ULL); (void)csrd_frame_4369_45; unsigned long long csrd_frame_4369_46 = (((csrd_frame_4369_42)+(csrd_frame_4369_45)-0ULL) & 4294967295ULL); (void)csrd_frame_4369_46; unsigned long long csrd_frame_4369_47 = ((csrd_frame_4369_13) & 1ULL); (void)csrd_frame_4369_47; unsigned long long csrd_frame_4369_48 = ((csrd_frame_4369_47) & 4294967295ULL); (void)csrd_frame_4369_48; unsigned long long csrd_frame_4369_49 = (((csrd_frame_4369_46)+(csrd_frame_4369_48)-0ULL) & 4294967295ULL); (void)csrd_frame_4369_49; unsigned long long csrd_frame_4369_50 = (((csrd_frame_4369_49)+(csrd_frame_4369_22)-0ULL) & 4294967295ULL); (void)csrd_frame_4369_50; unsigned long long csrd_frame_4369_51 = csrd_frame_4369_50; (void)csrd_frame_4369_51; unsigned long long csrd_frame_4369_52 = ((csrd_frame_4369_3) & 255ULL); (void)csrd_frame_4369_52; unsigned long long csrd_frame_4369_53 = ((csrd_frame_4369_5) & 65535ULL); (void)csrd_frame_4369_53; unsigned long long csrd_frame_4369_54 = ((csrd_frame_4369_13) & 1ULL); (void)csrd_frame_4369_54; unsigned long long csrd_frame_4369_55 = ((csrd_frame_4369_16) & 4294967295ULL); (void)csrd_frame_4369_55; unsigned long long csrd_frame_4369_56 = ((csrd_frame_4369_22) & 4294967295ULL); (void)csrd_frame_4369_56; unsigned long long csrd_frame_4369_57 = ((csrd_frame_4369_24) & 4294967295ULL); (void)csrd_frame_4369_57; unsigned long long csrd_frame_4369_58 = (csrd_frame_4369_27); (void)csrd_frame_4369_58; unsigned long long csrd_frame_4369_59 = (csrd_frame_4369_39); (void)csrd_frame_4369_59; unsigned long long csrd_frame_4369_60 = ((csrd_frame_4369_51) & 4294967295ULL); (void)csrd_frame_4369_60; unsigned char byte = ((unsigned char)(csrd_frame_4369_52)); (void)byte; unsigned short half = ((unsigned short)(csrd_frame_4369_53)); (void)half; _Bool flag = ((_Bool)(csrd_frame_4369_54)); (void)flag; int small = ((int)((csrd_frame_4369_55)<=2147483647ULL ? (long long)(csrd_frame_4369_55) : ~(long long)(4294967295ULL-(csrd_frame_4369_55)))); (void)small; int ordered = ((int)((csrd_frame_4369_56)<=2147483647ULL ? (long long)(csrd_frame_4369_56) : ~(long long)(4294967295ULL-(csrd_frame_4369_56)))); (void)ordered; unsigned int mixed = ((unsigned int)(csrd_frame_4369_57)); (void)mixed; long long extended = ((long long)((csrd_frame_4369_58)<=9223372036854775807ULL ? (long long)(csrd_frame_4369_58) : ~(long long)(18446744073709551615ULL-(csrd_frame_4369_58)))); (void)extended; unsigned long long packed = ((unsigned long long)(csrd_frame_4369_59)); (void)packed; unsigned int result = ((unsigned int)(csrd_frame_4369_60)); (void)result








;
    record_event(result);
    buffer[0] = (uint32_t)packed;
    buffer[1] = result;
    buffer[2] = (uint32_t)extended;
    return flag == ordered;
}
