#include <stdint.h>
uint32_t calculate(uint32_t p0, uint32_t p1) { return (11u + 3u * p0 + 3u * p1) + 0u; }
