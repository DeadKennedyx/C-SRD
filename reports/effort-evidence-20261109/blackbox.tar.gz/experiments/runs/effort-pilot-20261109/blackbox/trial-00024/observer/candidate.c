#include <stdint.h>
uint32_t kernel(uint32_t p0, uint32_t p1) { return (p0 ^ p1) + 0u; }
