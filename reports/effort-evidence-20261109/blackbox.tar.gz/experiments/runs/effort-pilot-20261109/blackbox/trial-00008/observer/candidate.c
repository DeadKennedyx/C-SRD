#include <stdint.h>
uint32_t kernel(uint32_t p0, uint32_t p1) { return (0u + 1u * p0 + 1u * p1) + 0u; }
