#include <stdint.h>

uint32_t calculate(uint32_t x, uint32_t y)
{ unsigned int csrd_value_0 = ((x) + (y)); unsigned int csrd_value_1 = 0u; if ((csrd_value_0 & 1u) != 0u) { csrd_value_1 = (3u * ((csrd_value_0 - 1u))) + 3u; } else { csrd_value_1 = (3u * (csrd_value_0)); } unsigned int csrd_value_2 = ((csrd_value_1) + (11u)); return csrd_value_2;


}
