; ModuleID = '/work/experiments/runs/effort-pilot-20261109/matrix/calculate/build-clang-O2-affine-42-split-scale/validation/compiler-0-O2/candidate.i'
source_filename = "/work/experiments/runs/effort-pilot-20261109/matrix/calculate/build-clang-O2-affine-42-split-scale/validation/compiler-0-O2/candidate.i"
target datalayout = "e-m:e-i8:8:32-i16:16:32-i64:64-i128:128-n32:64-S128"
target triple = "aarch64-unknown-linux-gnu"

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local i32 @calculate(i32 noundef %0, i32 noundef %1) local_unnamed_addr #0 {
  %3 = add i32 %1, %0
  %4 = mul i32 %3, 1789947473
  %5 = add i32 %4, 1549411197
  %6 = and i32 %5, 1
  %7 = icmp eq i32 %6, 0
  %8 = mul i32 %3, 1074875123
  %9 = add i32 %8, 1549411197
  %10 = mul i32 %5, 3
  %11 = add i32 %10, 1196144902
  %12 = select i1 %7, i32 %11, i32 %9
  %13 = mul i32 %12, 846699185
  %14 = add i32 %13, 54084766
  ret i32 %14
}

attributes #0 = { mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable "frame-pointer"="non-leaf" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+fp-armv8,+neon,+outline-atomics,+v8a,-fmv" }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 1, !"wchar_size", i32 4}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 1}
!5 = !{!"Ubuntu clang version 18.1.3 (1ubuntu1)"}
