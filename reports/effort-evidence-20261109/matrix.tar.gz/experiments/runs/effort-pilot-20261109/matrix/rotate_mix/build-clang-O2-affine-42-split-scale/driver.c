#define _POSIX_C_SOURCE 200809L
#include <stdint.h>
#include <inttypes.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
uint32_t kernel(uint32_t);
static uint32_t csrd_matrix_next_value(uint32_t *s) {
    *s ^= *s << 13; *s ^= *s >> 17; *s ^= *s << 5; return *s;
}
int main(int argc, char **argv) {
    uint32_t x[1];
    if (argc == 1) {
        while (scanf("%" SCNu32, &x[0]) == 1)
            printf("%" PRIu32 "\n", kernel(x[0]));
        return 0;
    }
    if (argc != 3) return 3;
    unsigned long n = strtoul(argv[1], 0, 10);
    uint32_t state = (uint32_t)strtoul(argv[2], 0, 10);
    uint64_t sum = 0;
    struct timespec begin, end;
    if (clock_gettime(CLOCK_MONOTONIC, &begin)) return 2;
    for (unsigned long i = 0; i < n; ++i) {
        for (unsigned j = 0; j < 1; ++j) x[j] = csrd_matrix_next_value(&state);
        sum += kernel(x[0]);
    }
    if (clock_gettime(CLOCK_MONOTONIC, &end)) return 2;
    double elapsed = (double)(end.tv_sec - begin.tv_sec) +
                     (double)(end.tv_nsec - begin.tv_nsec) * 1e-9;
    printf("%.9f %" PRIu64 "\n", elapsed, sum);
    return 0;
}
