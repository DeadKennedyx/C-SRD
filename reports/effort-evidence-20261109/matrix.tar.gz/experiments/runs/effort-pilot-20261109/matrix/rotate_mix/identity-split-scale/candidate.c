#include <stdint.h>
uint32_t kernel(uint32_t x) { unsigned int csrd_value_0 = ((x) << (7u)); unsigned int csrd_value_1 = ((x) >> (25u)); unsigned int csrd_value_2 = ((csrd_value_0) | (csrd_value_1)); unsigned int csrd_value_3 = 0u; if ((csrd_value_2 & 1u) != 0u) { csrd_value_3 = (5u * ((csrd_value_2 - 1u))) + 5u; } else { csrd_value_3 = (5u * (csrd_value_2)); } unsigned int csrd_value_4 = ((csrd_value_3) + (17u)); return csrd_value_4;


}
