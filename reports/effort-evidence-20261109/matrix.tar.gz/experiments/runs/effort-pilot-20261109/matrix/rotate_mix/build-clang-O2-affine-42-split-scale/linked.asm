
/work/experiments/runs/effort-pilot-20261109/matrix/rotate_mix/build-clang-O2-affine-42-split-scale/program:	file format elf64-littleaarch64

Disassembly of section .init:

0000000000000678 <_init>:
     678:      	nop
     67c:      	stp	x29, x30, [sp, #-0x10]!
     680:      	mov	x29, sp
     684:      	bl	0x774 <call_weak_fn>
     688:      	ldp	x29, x30, [sp], #0x10
     68c:      	ret

Disassembly of section .plt:

0000000000000690 <.plt>:
     690:      	stp	x16, x30, [sp, #-0x10]!
     694:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e4a0>
     698:      	ldr	x17, [x16, #0xff8]
     69c:      	add	x16, x16, #0xff8
     6a0:      	br	x17
     6a4:      	nop
     6a8:      	nop
     6ac:      	nop

00000000000006b0 <strtoul@plt>:
     6b0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6b4:      	ldr	x17, [x16]
     6b8:      	add	x16, x16, #0x0
     6bc:      	br	x17

00000000000006c0 <__libc_start_main@plt>:
     6c0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6c4:      	ldr	x17, [x16, #0x8]
     6c8:      	add	x16, x16, #0x8
     6cc:      	br	x17

00000000000006d0 <__cxa_finalize@plt>:
     6d0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6d4:      	ldr	x17, [x16, #0x10]
     6d8:      	add	x16, x16, #0x10
     6dc:      	br	x17

00000000000006e0 <clock_gettime@plt>:
     6e0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6e4:      	ldr	x17, [x16, #0x18]
     6e8:      	add	x16, x16, #0x18
     6ec:      	br	x17

00000000000006f0 <__gmon_start__@plt>:
     6f0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6f4:      	ldr	x17, [x16, #0x20]
     6f8:      	add	x16, x16, #0x20
     6fc:      	br	x17

0000000000000700 <abort@plt>:
     700:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     704:      	ldr	x17, [x16, #0x28]
     708:      	add	x16, x16, #0x28
     70c:      	br	x17

0000000000000710 <__isoc99_scanf@plt>:
     710:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     714:      	ldr	x17, [x16, #0x30]
     718:      	add	x16, x16, #0x30
     71c:      	br	x17

0000000000000720 <printf@plt>:
     720:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     724:      	ldr	x17, [x16, #0x38]
     728:      	add	x16, x16, #0x38
     72c:      	br	x17

Disassembly of section .text:

0000000000000740 <_start>:
     740:      	nop
     744:      	mov	x29, #0x0               // =0
     748:      	mov	x30, #0x0               // =0
     74c:      	mov	x5, x0
     750:      	ldr	x1, [sp]
     754:      	add	x2, sp, #0x8
     758:      	mov	x6, sp
     75c:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e4a0>
     760:      	ldr	x0, [x0, #0xfd8]
     764:      	mov	x3, #0x0                // =0
     768:      	mov	x4, #0x0                // =0
     76c:      	bl	0x6c0 <__libc_start_main@plt>
     770:      	bl	0x700 <abort@plt>

0000000000000774 <call_weak_fn>:
     774:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e4a0>
     778:      	ldr	x0, [x0, #0xfd0]
     77c:      	cbz	x0, 0x784 <call_weak_fn+0x10>
     780:      	b	0x6f0 <__gmon_start__@plt>
     784:      	ret
     788:      	nop
     78c:      	nop

0000000000000790 <deregister_tm_clones>:
     790:      	adrp	x0, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     794:      	add	x0, x0, #0x50
     798:      	adrp	x1, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     79c:      	add	x1, x1, #0x50
     7a0:      	cmp	x1, x0
     7a4:      	b.eq	0x7bc <deregister_tm_clones+0x2c>
     7a8:      	adrp	x1, 0x1f000 <__FRAME_END__+0x1e4a0>
     7ac:      	ldr	x1, [x1, #0xfc0]
     7b0:      	cbz	x1, 0x7bc <deregister_tm_clones+0x2c>
     7b4:      	mov	x16, x1
     7b8:      	br	x16
     7bc:      	ret

00000000000007c0 <register_tm_clones>:
     7c0:      	adrp	x0, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     7c4:      	add	x0, x0, #0x50
     7c8:      	adrp	x1, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     7cc:      	add	x1, x1, #0x50
     7d0:      	sub	x1, x1, x0
     7d4:      	lsr	x2, x1, #63
     7d8:      	add	x1, x2, x1, asr #3
     7dc:      	asr	x1, x1, #1
     7e0:      	cbz	x1, 0x7f8 <register_tm_clones+0x38>
     7e4:      	adrp	x2, 0x1f000 <__FRAME_END__+0x1e4a0>
     7e8:      	ldr	x2, [x2, #0xfe0]
     7ec:      	cbz	x2, 0x7f8 <register_tm_clones+0x38>
     7f0:      	mov	x16, x2
     7f4:      	br	x16
     7f8:      	ret
     7fc:      	nop

0000000000000800 <__do_global_dtors_aux>:
     800:      	paciasp
     804:      	stp	x29, x30, [sp, #-0x20]!
     808:      	mov	x29, sp
     80c:      	str	x19, [sp, #0x10]
     810:      	adrp	x19, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     814:      	ldrb	w0, [x19, #0x50]
     818:      	tbnz	w0, #0x0, 0x840 <__do_global_dtors_aux+0x40>
     81c:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e4a0>
     820:      	ldr	x0, [x0, #0xfc8]
     824:      	cbz	x0, 0x834 <__do_global_dtors_aux+0x34>
     828:      	adrp	x0, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     82c:      	ldr	x0, [x0, #0x48]
     830:      	bl	0x6d0 <__cxa_finalize@plt>
     834:      	bl	0x790 <deregister_tm_clones>
     838:      	mov	w0, #0x1                // =1
     83c:      	strb	w0, [x19, #0x50]
     840:      	ldr	x19, [sp, #0x10]
     844:      	ldp	x29, x30, [sp], #0x20
     848:      	autiasp
     84c:      	ret

0000000000000850 <frame_dummy>:
     850:      	bti	c
     854:      	b	0x7c0 <register_tm_clones>

0000000000000858 <kernel>:
     858:      	ror	w8, w0, #0x19
     85c:      	mov	w9, #0x1e59             // =7769
     860:      	mov	w10, #0x7c47            // =31815
     864:      	movk	w9, #0x77d7, lsl #16
     868:      	movk	w10, #0x1093, lsl #16
     86c:      	mov	w11, #0x97bd            // =38845
     870:      	madd	w9, w8, w9, w10
     874:      	movk	w11, #0x5733, lsl #16
     878:      	madd	w8, w8, w11, w10
     87c:      	mov	w11, #0xee4             // =3812
     880:      	movk	w11, #0xbdb2, lsl #16
     884:      	add	w10, w9, w9, lsl #2
     888:      	tst	w9, #0x1
     88c:      	mov	w9, #0x49e9             // =18921
     890:      	movk	w9, #0x9c3e, lsl #16
     894:      	add	w10, w10, w11
     898:      	csel	w8, w10, w8, eq
     89c:      	mov	w10, #0xa472            // =42098
     8a0:      	movk	w10, #0x7e21, lsl #16
     8a4:      	madd	w0, w8, w9, w10
     8a8:      	ret

00000000000008ac <main>:
     8ac:      	sub	sp, sp, #0x50
     8b0:      	stp	x29, x30, [sp, #0x20]
     8b4:      	str	x21, [sp, #0x30]
     8b8:      	stp	x20, x19, [sp, #0x40]
     8bc:      	add	x29, sp, #0x20
     8c0:      	cmp	w0, #0x3
     8c4:      	b.eq	0x924 <main+0x78>
     8c8:      	cmp	w0, #0x1
     8cc:      	b.ne	0x9a4 <main+0xf8>
     8d0:      	adrp	x0, 0x0 <strtoul@GLIBC_2.17>
     8d4:      	add	x0, x0, #0xa20
     8d8:      	add	x1, sp, #0x10
     8dc:      	bl	0x710 <__isoc99_scanf@plt>
     8e0:      	cmp	w0, #0x1
     8e4:      	b.ne	0x9e0 <main+0x134>
     8e8:      	adrp	x19, 0x0 <strtoul@GLIBC_2.17>
     8ec:      	add	x19, x19, #0xa23
     8f0:      	adrp	x20, 0x0 <strtoul@GLIBC_2.17>
     8f4:      	add	x20, x20, #0xa20
     8f8:      	ldr	w0, [sp, #0x10]
     8fc:      	bl	0x858 <kernel>
     900:      	mov	w1, w0
     904:      	mov	x0, x19
     908:      	bl	0x720 <printf@plt>
     90c:      	add	x1, sp, #0x10
     910:      	mov	x0, x20
     914:      	bl	0x710 <__isoc99_scanf@plt>
     918:      	cmp	w0, #0x1
     91c:      	b.eq	0x8f8 <main+0x4c>
     920:      	b	0x9e0 <main+0x134>
     924:      	ldr	x0, [x1, #0x8]
     928:      	mov	x19, x1
     92c:      	mov	x1, xzr
     930:      	mov	w2, #0xa                // =10
     934:      	bl	0x6b0 <strtoul@plt>
     938:      	ldr	x8, [x19, #0x10]
     93c:      	mov	x20, x0
     940:      	mov	x1, xzr
     944:      	mov	w2, #0xa                // =10
     948:      	mov	x0, x8
     94c:      	bl	0x6b0 <strtoul@plt>
     950:      	mov	x21, x0
     954:      	add	x1, sp, #0x10
     958:      	mov	w0, #0x1                // =1
     95c:      	bl	0x6e0 <clock_gettime@plt>
     960:      	cbnz	w0, 0x99c <main+0xf0>
     964:      	mov	x19, xzr
     968:      	cbz	x20, 0x98c <main+0xe0>
     96c:      	eor	w8, w21, w21, lsl #13
     970:      	eor	w8, w8, w8, lsr #17
     974:      	eor	w21, w8, w8, lsl #5
     978:      	mov	w0, w21
     97c:      	bl	0x858 <kernel>
     980:      	add	x19, x19, w0, uxtw
     984:      	subs	x20, x20, #0x1
     988:      	b.ne	0x96c <main+0xc0>
     98c:      	mov	x1, sp
     990:      	mov	w0, #0x1                // =1
     994:      	bl	0x6e0 <clock_gettime@plt>
     998:      	cbz	w0, 0x9ac <main+0x100>
     99c:      	mov	w0, #0x2                // =2
     9a0:      	b	0x9e4 <main+0x138>
     9a4:      	mov	w0, #0x3                // =3
     9a8:      	b	0x9e4 <main+0x138>
     9ac:      	ldp	x8, x9, [sp]
     9b0:      	adrp	x0, 0x0 <strtoul@GLIBC_2.17>
     9b4:      	add	x0, x0, #0xa27
     9b8:      	ldp	x10, x11, [sp, #0x10]
     9bc:      	mov	x1, x19
     9c0:      	sub	x8, x8, x10
     9c4:      	sub	x9, x9, x11
     9c8:      	scvtf	d0, x8
     9cc:      	scvtf	d1, x9
     9d0:      	adrp	x8, 0x0 <strtoul@GLIBC_2.17>
     9d4:      	ldr	d2, [x8, #0xa18]
     9d8:      	fmadd	d0, d1, d2, d0
     9dc:      	bl	0x720 <printf@plt>
     9e0:      	mov	w0, wzr
     9e4:      	ldp	x20, x19, [sp, #0x40]
     9e8:      	ldr	x21, [sp, #0x30]
     9ec:      	ldp	x29, x30, [sp, #0x20]
     9f0:      	add	sp, sp, #0x50
     9f4:      	ret

Disassembly of section .fini:

00000000000009f8 <_fini>:
     9f8:      	nop
     9fc:      	stp	x29, x30, [sp, #-0x10]!
     a00:      	mov	x29, sp
     a04:      	ldp	x29, x30, [sp], #0x10
     a08:      	ret
