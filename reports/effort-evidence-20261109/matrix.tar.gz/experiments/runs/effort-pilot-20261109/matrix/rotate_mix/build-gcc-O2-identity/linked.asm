
/work/experiments/runs/effort-pilot-20261109/matrix/rotate_mix/build-gcc-O2-identity/program:	file format elf64-littleaarch64

Disassembly of section .init:

0000000000000738 <_init>:
     738:      	nop
     73c:      	stp	x29, x30, [sp, #-0x10]!
     740:      	mov	x29, sp
     744:      	bl	0x9f4 <call_weak_fn>
     748:      	ldp	x29, x30, [sp], #0x10
     74c:      	ret

Disassembly of section .plt:

0000000000000750 <.plt>:
     750:      	stp	x16, x30, [sp, #-0x10]!
     754:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e384>
     758:      	ldr	x17, [x16, #0xf78]
     75c:      	add	x16, x16, #0xf78
     760:      	br	x17
     764:      	nop
     768:      	nop
     76c:      	nop

0000000000000770 <strtoul@plt>:
     770:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e384>
     774:      	ldr	x17, [x16, #0xf80]
     778:      	add	x16, x16, #0xf80
     77c:      	br	x17

0000000000000780 <__libc_start_main@plt>:
     780:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e384>
     784:      	ldr	x17, [x16, #0xf88]
     788:      	add	x16, x16, #0xf88
     78c:      	br	x17

0000000000000790 <__cxa_finalize@plt>:
     790:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e384>
     794:      	ldr	x17, [x16, #0xf90]
     798:      	add	x16, x16, #0xf90
     79c:      	br	x17

00000000000007a0 <clock_gettime@plt>:
     7a0:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e384>
     7a4:      	ldr	x17, [x16, #0xf98]
     7a8:      	add	x16, x16, #0xf98
     7ac:      	br	x17

00000000000007b0 <__printf_chk@plt>:
     7b0:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e384>
     7b4:      	ldr	x17, [x16, #0xfa0]
     7b8:      	add	x16, x16, #0xfa0
     7bc:      	br	x17

00000000000007c0 <__stack_chk_fail@plt>:
     7c0:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e384>
     7c4:      	ldr	x17, [x16, #0xfa8]
     7c8:      	add	x16, x16, #0xfa8
     7cc:      	br	x17

00000000000007d0 <__gmon_start__@plt>:
     7d0:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e384>
     7d4:      	ldr	x17, [x16, #0xfb0]
     7d8:      	add	x16, x16, #0xfb0
     7dc:      	br	x17

00000000000007e0 <abort@plt>:
     7e0:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e384>
     7e4:      	ldr	x17, [x16, #0xfb8]
     7e8:      	add	x16, x16, #0xfb8
     7ec:      	br	x17

00000000000007f0 <__isoc99_scanf@plt>:
     7f0:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e384>
     7f4:      	ldr	x17, [x16, #0xfc0]
     7f8:      	add	x16, x16, #0xfc0
     7fc:      	br	x17

Disassembly of section .text:

0000000000000800 <main>:
     800:      	sub	sp, sp, #0x60
     804:      	mov	w2, w0
     808:      	adrp	x3, 0x1f000 <__FRAME_END__+0x1e384>
     80c:      	ldr	x3, [x3, #0xfe8]
     810:      	stp	x29, x30, [sp, #0x30]
     814:      	add	x29, sp, #0x30
     818:      	ldr	x0, [x3]
     81c:      	str	x0, [sp, #0x28]
     820:      	mov	x0, #0x0                // =0
     824:      	cmp	w2, #0x1
     828:      	b.eq	0x934 <main+0x134>
     82c:      	mov	w0, #0x3                // =3
     830:      	cmp	w2, w0
     834:      	b.eq	0x860 <main+0x60>
     838:      	adrp	x1, 0x1f000 <__FRAME_END__+0x1e384>
     83c:      	ldr	x1, [x1, #0xfe8]
     840:      	ldr	x3, [sp, #0x28]
     844:      	ldr	x2, [x1]
     848:      	subs	x3, x3, x2
     84c:      	mov	x2, #0x0                // =0
     850:      	b.ne	0x99c <main+0x19c>
     854:      	ldp	x29, x30, [sp, #0x30]
     858:      	add	sp, sp, #0x60
     85c:      	ret
     860:      	stp	x19, x20, [sp, #0x40]
     864:      	mov	x19, x1
     868:      	mov	w2, #0xa                // =10
     86c:      	mov	x1, #0x0                // =0
     870:      	stp	x21, x22, [sp, #0x50]
     874:      	ldr	x0, [x19, #0x8]
     878:      	bl	0x770 <strtoul@plt>
     87c:      	mov	x22, x0
     880:      	ldr	x0, [x19, #0x10]
     884:      	mov	w2, #0xa                // =10
     888:      	mov	x1, #0x0                // =0
     88c:      	bl	0x770 <strtoul@plt>
     890:      	mov	x19, x0
     894:      	mov	x1, sp
     898:      	mov	w0, #0x1                // =1
     89c:      	bl	0x7a0 <clock_gettime@plt>
     8a0:      	cbnz	w0, 0x984 <main+0x184>
     8a4:      	cbz	x22, 0x994 <main+0x194>
     8a8:      	mov	x20, #0x0               // =0
     8ac:      	mov	x21, #0x0               // =0
     8b0:      	eor	w19, w19, w19, lsl #13
     8b4:      	add	x20, x20, #0x1
     8b8:      	eor	w19, w19, w19, lsr #17
     8bc:      	eor	w19, w19, w19, lsl #5
     8c0:      	str	w19, [sp, #0x20]
     8c4:      	mov	w0, w19
     8c8:      	bl	0xae0 <kernel>
     8cc:      	add	x21, x21, w0, uxtw
     8d0:      	cmp	x22, x20
     8d4:      	b.ne	0x8b0 <main+0xb0>
     8d8:      	add	x1, sp, #0x10
     8dc:      	mov	w0, #0x1                // =1
     8e0:      	bl	0x7a0 <clock_gettime@plt>
     8e4:      	cbnz	w0, 0x984 <main+0x184>
     8e8:      	adrp	x0, 0x0 <strtoul@GLIBC_2.17>
     8ec:      	mov	x2, x21
     8f0:      	ldp	x4, x1, [sp]
     8f4:      	ldr	d1, [x0, #0xb30]
     8f8:      	ldp	x3, x0, [sp, #0x10]
     8fc:      	sub	x0, x0, x1
     900:      	sub	x3, x3, x4
     904:      	adrp	x1, 0x0 <strtoul@GLIBC_2.17>
     908:      	add	x1, x1, #0xb20
     90c:      	scvtf	d0, x0
     910:      	mov	w0, #0x2                // =2
     914:      	fmul	d0, d0, d1
     918:      	scvtf	d1, x3
     91c:      	fadd	d0, d0, d1
     920:      	bl	0x7b0 <__printf_chk@plt>
     924:      	ldp	x19, x20, [sp, #0x40]
     928:      	mov	w0, #0x0                // =0
     92c:      	ldp	x21, x22, [sp, #0x50]
     930:      	b	0x838 <main+0x38>
     934:      	stp	x19, x20, [sp, #0x40]
     938:      	adrp	x19, 0x0 <strtoul@GLIBC_2.17>
     93c:      	adrp	x20, 0x0 <strtoul@GLIBC_2.17>
     940:      	add	x19, x19, #0xb18
     944:      	add	x20, x20, #0xb10
     948:      	stp	x21, x22, [sp, #0x50]
     94c:      	add	x21, sp, #0x20
     950:      	b	0x96c <main+0x16c>
     954:      	ldr	w0, [sp, #0x20]
     958:      	bl	0xae0 <kernel>
     95c:      	mov	w2, w0
     960:      	mov	x1, x20
     964:      	mov	w0, #0x2                // =2
     968:      	bl	0x7b0 <__printf_chk@plt>
     96c:      	mov	x1, x21
     970:      	mov	x0, x19
     974:      	bl	0x7f0 <__isoc99_scanf@plt>
     978:      	cmp	w0, #0x1
     97c:      	b.eq	0x954 <main+0x154>
     980:      	b	0x924 <main+0x124>
     984:      	ldp	x19, x20, [sp, #0x40]
     988:      	mov	w0, #0x2                // =2
     98c:      	ldp	x21, x22, [sp, #0x50]
     990:      	b	0x838 <main+0x38>
     994:      	mov	x21, #0x0               // =0
     998:      	b	0x8d8 <main+0xd8>
     99c:      	stp	x19, x20, [sp, #0x40]
     9a0:      	stp	x21, x22, [sp, #0x50]
     9a4:      	bl	0x7c0 <__stack_chk_fail@plt>
     9a8:      	nop
     9ac:      	nop
     9b0:      	nop
     9b4:      	nop
     9b8:      	nop
     9bc:      	nop

00000000000009c0 <_start>:
     9c0:      	nop
     9c4:      	mov	x29, #0x0               // =0
     9c8:      	mov	x30, #0x0               // =0
     9cc:      	mov	x5, x0
     9d0:      	ldr	x1, [sp]
     9d4:      	add	x2, sp, #0x8
     9d8:      	mov	x6, sp
     9dc:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e384>
     9e0:      	ldr	x0, [x0, #0xff0]
     9e4:      	mov	x3, #0x0                // =0
     9e8:      	mov	x4, #0x0                // =0
     9ec:      	bl	0x780 <__libc_start_main@plt>
     9f0:      	bl	0x7e0 <abort@plt>

00000000000009f4 <call_weak_fn>:
     9f4:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e384>
     9f8:      	ldr	x0, [x0, #0xfe0]
     9fc:      	cbz	x0, 0xa04 <call_weak_fn+0x10>
     a00:      	b	0x7d0 <__gmon_start__@plt>
     a04:      	ret
     a08:      	nop
     a0c:      	nop

0000000000000a10 <deregister_tm_clones>:
     a10:      	adrp	x0, 0x20000 <data_start>
     a14:      	add	x0, x0, #0x10
     a18:      	adrp	x1, 0x20000 <data_start>
     a1c:      	add	x1, x1, #0x10
     a20:      	cmp	x1, x0
     a24:      	b.eq	0xa3c <deregister_tm_clones+0x2c>
     a28:      	adrp	x1, 0x1f000 <__FRAME_END__+0x1e384>
     a2c:      	ldr	x1, [x1, #0xfd0]
     a30:      	cbz	x1, 0xa3c <deregister_tm_clones+0x2c>
     a34:      	mov	x16, x1
     a38:      	br	x16
     a3c:      	ret

0000000000000a40 <register_tm_clones>:
     a40:      	adrp	x0, 0x20000 <data_start>
     a44:      	add	x0, x0, #0x10
     a48:      	adrp	x1, 0x20000 <data_start>
     a4c:      	add	x1, x1, #0x10
     a50:      	sub	x1, x1, x0
     a54:      	lsr	x2, x1, #63
     a58:      	add	x1, x2, x1, asr #3
     a5c:      	asr	x1, x1, #1
     a60:      	cbz	x1, 0xa78 <register_tm_clones+0x38>
     a64:      	adrp	x2, 0x1f000 <__FRAME_END__+0x1e384>
     a68:      	ldr	x2, [x2, #0xff8]
     a6c:      	cbz	x2, 0xa78 <register_tm_clones+0x38>
     a70:      	mov	x16, x2
     a74:      	br	x16
     a78:      	ret
     a7c:      	nop

0000000000000a80 <__do_global_dtors_aux>:
     a80:      	paciasp
     a84:      	stp	x29, x30, [sp, #-0x20]!
     a88:      	mov	x29, sp
     a8c:      	str	x19, [sp, #0x10]
     a90:      	adrp	x19, 0x20000 <data_start>
     a94:      	ldrb	w0, [x19, #0x10]
     a98:      	tbnz	w0, #0x0, 0xac0 <__do_global_dtors_aux+0x40>
     a9c:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e384>
     aa0:      	ldr	x0, [x0, #0xfd8]
     aa4:      	cbz	x0, 0xab4 <__do_global_dtors_aux+0x34>
     aa8:      	adrp	x0, 0x20000 <data_start>
     aac:      	ldr	x0, [x0, #0x8]
     ab0:      	bl	0x790 <__cxa_finalize@plt>
     ab4:      	bl	0xa10 <deregister_tm_clones>
     ab8:      	mov	w0, #0x1                // =1
     abc:      	strb	w0, [x19, #0x10]
     ac0:      	ldr	x19, [sp, #0x10]
     ac4:      	ldp	x29, x30, [sp], #0x20
     ac8:      	autiasp
     acc:      	ret

0000000000000ad0 <frame_dummy>:
     ad0:      	bti	c
     ad4:      	b	0xa40 <register_tm_clones>
     ad8:      	nop
     adc:      	nop

0000000000000ae0 <kernel>:
     ae0:      	ror	w0, w0, #0x19
     ae4:      	add	w0, w0, w0, lsl #2
     ae8:      	add	w0, w0, #0x11
     aec:      	ret

Disassembly of section .fini:

0000000000000af0 <_fini>:
     af0:      	nop
     af4:      	stp	x29, x30, [sp, #-0x10]!
     af8:      	mov	x29, sp
     afc:      	ldp	x29, x30, [sp], #0x10
     b00:      	ret
