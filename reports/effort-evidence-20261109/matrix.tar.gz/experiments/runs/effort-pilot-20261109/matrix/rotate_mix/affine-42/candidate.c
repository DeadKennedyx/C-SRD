#include <stdint.h>
uint32_t kernel(uint32_t x) { unsigned int csrd_value_0 = ((x) << (7u)); unsigned int csrd_value_1 = ((x) >> (25u)); unsigned int csrd_value_2 = ((csrd_value_0) | (csrd_value_1)); unsigned int csrd_value_3 = ((2010586713u * (csrd_value_2)) + 278101063u); unsigned int csrd_value_4 = ((5u * (csrd_value_3)) + 3182563044u); unsigned int csrd_value_5 = (((csrd_value_4) + (98336816u)) - 278101063u); unsigned int csrd_value_6 = (2621327849u * ((csrd_value_5) - 278101063u)); return csrd_value_6;


}
