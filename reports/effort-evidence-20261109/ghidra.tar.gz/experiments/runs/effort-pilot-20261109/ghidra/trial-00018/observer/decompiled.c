
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

uint kernel(uint p0)

{
  int iVar1;
  uint uVar2;
  uint uVar3;
  
  uVar3 = p0 >> 0x19 | p0 << 7;
  uVar2 = uVar3 * 0x77d71e59 + 0x10937c47;
  iVar1 = uVar2 * 5 + -0x424df11c;
  if ((uVar2 & 1) != 0) {
    iVar1 = uVar3 * 0x573397bd + 0x10937c47;
  }
  return iVar1 * -0x63c1b617 + 0x7e21a472;
}

