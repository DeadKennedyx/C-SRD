
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

uint kernel(uint p0)

{
  return (p0 >> 0x19 | p0 << 7) * 5 + 0x11;
}

