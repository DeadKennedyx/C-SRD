unsigned int calculate(unsigned int p0, unsigned int p1) {
    unsigned int v0 = (p0 + p1);
    unsigned int v3 = (v0 * 3u);
    unsigned int v5 = (v3 + 11u);
    unsigned int v8 = v5;
    (void)p0;
    (void)p1;
    return v8;
}
