
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

uint calculate(uint p0,uint p1)

{
  return (p1 + p0) * 3 + 0xb;
}

