
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

uint calculate(uint p0,uint p1)

{
  int iVar1;
  uint uVar2;
  
  uVar2 = (p1 + p0) * 0x6ab06e51 + 0x5c5a237d;
  iVar1 = uVar2 * 3 + 0x474bb906;
  if ((uVar2 & 1) != 0) {
    iVar1 = (p1 + p0) * 0x40114af3 + 0x5c5a237d;
  }
  return iVar1 * 0x32779ab1 + 0x339449e;
}

