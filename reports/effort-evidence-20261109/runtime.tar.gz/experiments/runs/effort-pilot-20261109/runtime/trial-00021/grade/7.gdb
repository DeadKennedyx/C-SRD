python
import sys
sys.path.insert(0, '/work/tools')
import gdb_trace
gdb_trace.main('/work/experiments/runs/effort-pilot-20261109/runtime/trial-00021/grade/7.json')
end
