#include <stdint.h>

/* Interleave the low 16 bits of x and y; x occupies the even output bits. */
uint32_t kernel(uint32_t x, uint32_t y)
{ unsigned int csrd_value_0 = ((x) & (65535u)); unsigned int csrd_value_1 = ((y) & (65535u)); unsigned int csrd_value_2 = ((csrd_value_0) << (8u)); unsigned int csrd_value_3 = ((csrd_value_0) | (csrd_value_2)); unsigned int csrd_value_4 = ((csrd_value_3) & (16711935u)); unsigned int csrd_value_5 = ((csrd_value_1) << (8u)); unsigned int csrd_value_6 = ((csrd_value_1) | (csrd_value_5)); unsigned int csrd_value_7 = ((csrd_value_6) & (16711935u)); unsigned int csrd_value_8 = ((csrd_value_4) << (4u)); unsigned int csrd_value_9 = ((csrd_value_4) | (csrd_value_8)); unsigned int csrd_value_10 = ((csrd_value_9) & (252645135u)); unsigned int csrd_value_11 = ((csrd_value_7) << (4u)); unsigned int csrd_value_12 = ((csrd_value_7) | (csrd_value_11)); unsigned int csrd_value_13 = ((csrd_value_12) & (252645135u)); unsigned int csrd_value_14 = ((csrd_value_10) << (2u)); unsigned int csrd_value_15 = ((csrd_value_10) | (csrd_value_14)); unsigned int csrd_value_16 = ((csrd_value_15) & (858993459u)); unsigned int csrd_value_17 = ((csrd_value_13) << (2u)); unsigned int csrd_value_18 = ((csrd_value_13) | (csrd_value_17)); unsigned int csrd_value_19 = ((csrd_value_18) & (858993459u)); unsigned int csrd_value_20 = ((csrd_value_16) << (1u)); unsigned int csrd_value_21 = ((csrd_value_16) | (csrd_value_20)); unsigned int csrd_value_22 = ((csrd_value_21) & (1431655765u)); unsigned int csrd_value_23 = ((csrd_value_19) << (1u)); unsigned int csrd_value_24 = ((csrd_value_19) | (csrd_value_23)); unsigned int csrd_value_25 = ((csrd_value_24) & (1431655765u)); unsigned int csrd_value_26 = ((csrd_value_25) << (1u)); unsigned int csrd_value_27 = ((csrd_value_22) | (csrd_value_26)); return csrd_value_27;











}
