#include <stdint.h>

/* Defined integer weighting of 0x??RRGGBB, not a color-management standard. */
uint32_t kernel(uint32_t rgb)
{ unsigned int csrd_value_0 = ((rgb) >> (16u)); unsigned int csrd_value_1 = ((csrd_value_0) & (255u)); unsigned int csrd_value_2 = ((rgb) >> (8u)); unsigned int csrd_value_3 = ((csrd_value_2) & (255u)); unsigned int csrd_value_4 = ((rgb) & (255u)); unsigned int csrd_value_5 = (77u * (csrd_value_1)); unsigned int csrd_value_6 = (150u * (csrd_value_3)); unsigned int csrd_value_7 = ((csrd_value_5) + (csrd_value_6)); unsigned int csrd_value_8 = (29u * (csrd_value_4)); unsigned int csrd_value_9 = ((csrd_value_7) + (csrd_value_8)); unsigned int csrd_value_10 = ((csrd_value_9) >> (8u)); return csrd_value_10;





}
