#include <stdint.h>

/* Defined integer weighting of 0x??RRGGBB, not a color-management standard. */
uint32_t kernel(uint32_t rgb)
{ unsigned int csrd_value_0 = ((rgb) ^ 1732534814u); unsigned int csrd_value_1 = (((csrd_value_0) >> 16u) ^ 1732511066u); unsigned int csrd_value_2 = (((csrd_value_1) & (1732535009u)) ^ (((csrd_value_1) ^ (1732535009u)) & 1732534814u)); unsigned int csrd_value_3 = (((csrd_value_0) >> 8u) ^ 1730356860u); unsigned int csrd_value_4 = (((csrd_value_3) & (1732535009u)) ^ (((csrd_value_3) ^ (1732535009u)) & 1732534814u)); unsigned int csrd_value_5 = (((csrd_value_0) & (1732535009u)) ^ (((csrd_value_0) ^ (1732535009u)) & 1732534814u)); unsigned int csrd_value_6 = ((csrd_value_2) ^ 1732534814u); unsigned int csrd_value_7 = (77u * (csrd_value_6)); unsigned int csrd_value_8 = ((csrd_value_4) ^ 1732534814u); unsigned int csrd_value_9 = (150u * (csrd_value_8)); unsigned int csrd_value_10 = ((csrd_value_7) + (csrd_value_9)); unsigned int csrd_value_11 = ((csrd_value_5) ^ 1732534814u); unsigned int csrd_value_12 = (29u * (csrd_value_11)); unsigned int csrd_value_13 = ((csrd_value_10) + (csrd_value_12)); unsigned int csrd_value_14 = ((csrd_value_13) ^ 1732534814u); unsigned int csrd_value_15 = (((csrd_value_14) >> 8u) ^ 1730356860u); unsigned int csrd_value_16 = ((csrd_value_15) ^ 1732534814u); return csrd_value_16;





}
