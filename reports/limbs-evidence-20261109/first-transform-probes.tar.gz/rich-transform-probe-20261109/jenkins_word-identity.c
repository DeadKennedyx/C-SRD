#include <stdint.h>

/* Jenkins one-at-a-time, four little-endian bytes, supplied initial state. */
uint32_t kernel(uint32_t state, uint32_t word)
{ unsigned int csrd_value_0 = ((word) & (255u)); unsigned int csrd_value_1 = ((state) + (csrd_value_0)); unsigned int csrd_value_2 = ((csrd_value_1) << (10u)); unsigned int csrd_value_3 = ((csrd_value_1) + (csrd_value_2)); unsigned int csrd_value_4 = ((csrd_value_3) >> (6u)); unsigned int csrd_value_5 = ((csrd_value_3) ^ (csrd_value_4)); unsigned int csrd_value_6 = ((word) >> (8u)); unsigned int csrd_value_7 = ((csrd_value_6) & (255u)); unsigned int csrd_value_8 = ((csrd_value_5) + (csrd_value_7)); unsigned int csrd_value_9 = ((csrd_value_8) << (10u)); unsigned int csrd_value_10 = ((csrd_value_8) + (csrd_value_9)); unsigned int csrd_value_11 = ((csrd_value_10) >> (6u)); unsigned int csrd_value_12 = ((csrd_value_10) ^ (csrd_value_11)); unsigned int csrd_value_13 = ((csrd_value_6) >> (8u)); unsigned int csrd_value_14 = ((csrd_value_13) & (255u)); unsigned int csrd_value_15 = ((csrd_value_12) + (csrd_value_14)); unsigned int csrd_value_16 = ((csrd_value_15) << (10u)); unsigned int csrd_value_17 = ((csrd_value_15) + (csrd_value_16)); unsigned int csrd_value_18 = ((csrd_value_17) >> (6u)); unsigned int csrd_value_19 = ((csrd_value_17) ^ (csrd_value_18)); unsigned int csrd_value_20 = ((csrd_value_13) >> (8u)); unsigned int csrd_value_21 = ((csrd_value_20) & (255u)); unsigned int csrd_value_22 = ((csrd_value_19) + (csrd_value_21)); unsigned int csrd_value_23 = ((csrd_value_22) << (10u)); unsigned int csrd_value_24 = ((csrd_value_22) + (csrd_value_23)); unsigned int csrd_value_25 = ((csrd_value_24) >> (6u)); unsigned int csrd_value_26 = ((csrd_value_24) ^ (csrd_value_25)); unsigned int csrd_value_27 = ((csrd_value_26) << (3u)); unsigned int csrd_value_28 = ((csrd_value_26) + (csrd_value_27)); unsigned int csrd_value_29 = ((csrd_value_28) >> (11u)); unsigned int csrd_value_30 = ((csrd_value_28) ^ (csrd_value_29)); unsigned int csrd_value_31 = ((csrd_value_30) << (15u)); unsigned int csrd_value_32 = ((csrd_value_30) + (csrd_value_31)); return csrd_value_32;












}
