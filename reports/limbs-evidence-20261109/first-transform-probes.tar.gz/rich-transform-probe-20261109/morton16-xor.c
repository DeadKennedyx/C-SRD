#include <stdint.h>

/* Interleave the low 16 bits of x and y; x occupies the even output bits. */
uint32_t kernel(uint32_t x, uint32_t y)
{ unsigned int csrd_value_0 = ((x) ^ 1732534814u); unsigned int csrd_value_1 = (((csrd_value_0) & (1732550113u)) ^ (((csrd_value_0) ^ (1732550113u)) & 1732534814u)); unsigned int csrd_value_2 = ((y) ^ 1732534814u); unsigned int csrd_value_3 = (((csrd_value_2) & (1732550113u)) ^ (((csrd_value_2) ^ (1732550113u)) & 1732534814u)); unsigned int csrd_value_4 = (((csrd_value_1) << 8u) ^ 589724702u); unsigned int csrd_value_5 = (((csrd_value_1) | (csrd_value_4)) ^ (((csrd_value_1) ^ (csrd_value_4)) & 1732534814u)); unsigned int csrd_value_6 = (((csrd_value_5) & (1740333793u)) ^ (((csrd_value_5) ^ (1740333793u)) & 1732534814u)); unsigned int csrd_value_7 = (((csrd_value_3) << 8u) ^ 589724702u); unsigned int csrd_value_8 = (((csrd_value_3) | (csrd_value_7)) ^ (((csrd_value_3) ^ (csrd_value_7)) & 1732534814u)); unsigned int csrd_value_9 = (((csrd_value_8) & (1740333793u)) ^ (((csrd_value_8) ^ (1740333793u)) & 1732534814u)); unsigned int csrd_value_10 = (((csrd_value_6) << 4u) ^ 318915582u); unsigned int csrd_value_11 = (((csrd_value_6) | (csrd_value_10)) ^ (((csrd_value_6) ^ (csrd_value_10)) & 1732534814u)); unsigned int csrd_value_12 = (((csrd_value_11) & (1749773585u)) ^ (((csrd_value_11) ^ (1749773585u)) & 1732534814u)); unsigned int csrd_value_13 = (((csrd_value_9) << 4u) ^ 318915582u); unsigned int csrd_value_14 = (((csrd_value_9) | (csrd_value_13)) ^ (((csrd_value_9) ^ (csrd_value_13)) & 1732534814u)); unsigned int csrd_value_15 = (((csrd_value_14) & (1749773585u)) ^ (((csrd_value_14) ^ (1749773585u)) & 1732534814u)); unsigned int csrd_value_16 = (((csrd_value_12) << 2u) ^ 4199934566u); unsigned int csrd_value_17 = (((csrd_value_12) | (csrd_value_16)) ^ (((csrd_value_12) ^ (csrd_value_16)) & 1732534814u)); unsigned int csrd_value_18 = (((csrd_value_17) & (1417105709u)) ^ (((csrd_value_17) ^ (1417105709u)) & 1732534814u)); unsigned int csrd_value_19 = (((csrd_value_15) << 2u) ^ 4199934566u); unsigned int csrd_value_20 = (((csrd_value_15) | (csrd_value_19)) ^ (((csrd_value_15) ^ (csrd_value_19)) & 1732534814u)); unsigned int csrd_value_21 = (((csrd_value_20) & (1417105709u)) ^ (((csrd_value_20) ^ (1417105709u)) & 1732534814u)); unsigned int csrd_value_22 = (((csrd_value_18) << 1u) ^ 2848761378u); unsigned int csrd_value_23 = (((csrd_value_18) | (csrd_value_22)) ^ (((csrd_value_18) ^ (csrd_value_22)) & 1732534814u)); unsigned int csrd_value_24 = (((csrd_value_23) & (839989067u)) ^ (((csrd_value_23) ^ (839989067u)) & 1732534814u)); unsigned int csrd_value_25 = (((csrd_value_21) << 1u) ^ 2848761378u); unsigned int csrd_value_26 = (((csrd_value_21) | (csrd_value_25)) ^ (((csrd_value_21) ^ (csrd_value_25)) & 1732534814u)); unsigned int csrd_value_27 = (((csrd_value_26) & (839989067u)) ^ (((csrd_value_26) ^ (839989067u)) & 1732534814u)); unsigned int csrd_value_28 = (((csrd_value_27) << 1u) ^ 2848761378u); unsigned int csrd_value_29 = (((csrd_value_24) | (csrd_value_28)) ^ (((csrd_value_24) ^ (csrd_value_28)) & 1732534814u)); unsigned int csrd_value_30 = ((csrd_value_29) ^ 1732534814u); return csrd_value_30;











}
