#include <stdint.h>

/* Defined integer weighting of 0x??RRGGBB, not a color-management standard. */
uint32_t kernel(uint32_t rgb)
{ unsigned int csrd_value_0 = ((rgb) >> (16u)); unsigned int csrd_value_1 = ((csrd_value_0) & (255u)); unsigned int csrd_value_2 = ((rgb) >> (8u)); unsigned int csrd_value_3 = ((csrd_value_2) & (255u)); unsigned int csrd_value_4 = ((rgb) & (255u)); unsigned int csrd_value_5 = ((2010586713u * (csrd_value_1)) + 278101063u); unsigned int csrd_value_6 = ((77u * (csrd_value_5)) + 339155692u); unsigned int csrd_value_7 = ((2010586713u * (csrd_value_3)) + 278101063u); unsigned int csrd_value_8 = ((150u * (csrd_value_7)) + 1512614573u); unsigned int csrd_value_9 = (((csrd_value_6) + (csrd_value_8)) - 278101063u); unsigned int csrd_value_10 = ((2010586713u * (csrd_value_4)) + 278101063u); unsigned int csrd_value_11 = ((29u * (csrd_value_10)) + 803104828u); unsigned int csrd_value_12 = (((csrd_value_9) + (csrd_value_11)) - 278101063u); unsigned int csrd_value_13 = (2621327849u * ((csrd_value_12) - 278101063u)); unsigned int csrd_value_14 = ((csrd_value_13) >> (8u)); return csrd_value_14;





}
