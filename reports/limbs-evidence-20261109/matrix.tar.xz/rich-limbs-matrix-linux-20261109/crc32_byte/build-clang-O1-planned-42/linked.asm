
/work/experiments/runs/rich-limbs-matrix-linux-20261109/crc32_byte/build-clang-O1-planned-42/program:	file format elf64-littleaarch64

Disassembly of section .init:

0000000000000678 <_init>:
     678:      	nop
     67c:      	stp	x29, x30, [sp, #-0x10]!
     680:      	mov	x29, sp
     684:      	bl	0x774 <call_weak_fn>
     688:      	ldp	x29, x30, [sp], #0x10
     68c:      	ret

Disassembly of section .plt:

0000000000000690 <.plt>:
     690:      	stp	x16, x30, [sp, #-0x10]!
     694:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e400>
     698:      	ldr	x17, [x16, #0xff8]
     69c:      	add	x16, x16, #0xff8
     6a0:      	br	x17
     6a4:      	nop
     6a8:      	nop
     6ac:      	nop

00000000000006b0 <strtoul@plt>:
     6b0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6b4:      	ldr	x17, [x16]
     6b8:      	add	x16, x16, #0x0
     6bc:      	br	x17

00000000000006c0 <__libc_start_main@plt>:
     6c0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6c4:      	ldr	x17, [x16, #0x8]
     6c8:      	add	x16, x16, #0x8
     6cc:      	br	x17

00000000000006d0 <__cxa_finalize@plt>:
     6d0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6d4:      	ldr	x17, [x16, #0x10]
     6d8:      	add	x16, x16, #0x10
     6dc:      	br	x17

00000000000006e0 <clock_gettime@plt>:
     6e0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6e4:      	ldr	x17, [x16, #0x18]
     6e8:      	add	x16, x16, #0x18
     6ec:      	br	x17

00000000000006f0 <__gmon_start__@plt>:
     6f0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6f4:      	ldr	x17, [x16, #0x20]
     6f8:      	add	x16, x16, #0x20
     6fc:      	br	x17

0000000000000700 <abort@plt>:
     700:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     704:      	ldr	x17, [x16, #0x28]
     708:      	add	x16, x16, #0x28
     70c:      	br	x17

0000000000000710 <__isoc99_scanf@plt>:
     710:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     714:      	ldr	x17, [x16, #0x30]
     718:      	add	x16, x16, #0x30
     71c:      	br	x17

0000000000000720 <printf@plt>:
     720:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     724:      	ldr	x17, [x16, #0x38]
     728:      	add	x16, x16, #0x38
     72c:      	br	x17

Disassembly of section .text:

0000000000000740 <_start>:
     740:      	nop
     744:      	mov	x29, #0x0               // =0
     748:      	mov	x30, #0x0               // =0
     74c:      	mov	x5, x0
     750:      	ldr	x1, [sp]
     754:      	add	x2, sp, #0x8
     758:      	mov	x6, sp
     75c:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e400>
     760:      	ldr	x0, [x0, #0xfd8]
     764:      	mov	x3, #0x0                // =0
     768:      	mov	x4, #0x0                // =0
     76c:      	bl	0x6c0 <__libc_start_main@plt>
     770:      	bl	0x700 <abort@plt>

0000000000000774 <call_weak_fn>:
     774:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e400>
     778:      	ldr	x0, [x0, #0xfd0]
     77c:      	cbz	x0, 0x784 <call_weak_fn+0x10>
     780:      	b	0x6f0 <__gmon_start__@plt>
     784:      	ret
     788:      	nop
     78c:      	nop

0000000000000790 <deregister_tm_clones>:
     790:      	adrp	x0, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     794:      	add	x0, x0, #0x50
     798:      	adrp	x1, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     79c:      	add	x1, x1, #0x50
     7a0:      	cmp	x1, x0
     7a4:      	b.eq	0x7bc <deregister_tm_clones+0x2c>
     7a8:      	adrp	x1, 0x1f000 <__FRAME_END__+0x1e400>
     7ac:      	ldr	x1, [x1, #0xfc0]
     7b0:      	cbz	x1, 0x7bc <deregister_tm_clones+0x2c>
     7b4:      	mov	x16, x1
     7b8:      	br	x16
     7bc:      	ret

00000000000007c0 <register_tm_clones>:
     7c0:      	adrp	x0, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     7c4:      	add	x0, x0, #0x50
     7c8:      	adrp	x1, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     7cc:      	add	x1, x1, #0x50
     7d0:      	sub	x1, x1, x0
     7d4:      	lsr	x2, x1, #63
     7d8:      	add	x1, x2, x1, asr #3
     7dc:      	asr	x1, x1, #1
     7e0:      	cbz	x1, 0x7f8 <register_tm_clones+0x38>
     7e4:      	adrp	x2, 0x1f000 <__FRAME_END__+0x1e400>
     7e8:      	ldr	x2, [x2, #0xfe0]
     7ec:      	cbz	x2, 0x7f8 <register_tm_clones+0x38>
     7f0:      	mov	x16, x2
     7f4:      	br	x16
     7f8:      	ret
     7fc:      	nop

0000000000000800 <__do_global_dtors_aux>:
     800:      	paciasp
     804:      	stp	x29, x30, [sp, #-0x20]!
     808:      	mov	x29, sp
     80c:      	str	x19, [sp, #0x10]
     810:      	adrp	x19, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     814:      	ldrb	w0, [x19, #0x50]
     818:      	tbnz	w0, #0x0, 0x840 <__do_global_dtors_aux+0x40>
     81c:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e400>
     820:      	ldr	x0, [x0, #0xfc8]
     824:      	cbz	x0, 0x834 <__do_global_dtors_aux+0x34>
     828:      	adrp	x0, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     82c:      	ldr	x0, [x0, #0x48]
     830:      	bl	0x6d0 <__cxa_finalize@plt>
     834:      	bl	0x790 <deregister_tm_clones>
     838:      	mov	w0, #0x1                // =1
     83c:      	strb	w0, [x19, #0x50]
     840:      	ldr	x19, [sp, #0x10]
     844:      	ldp	x29, x30, [sp], #0x20
     848:      	autiasp
     84c:      	ret

0000000000000850 <frame_dummy>:
     850:      	bti	c
     854:      	b	0x7c0 <register_tm_clones>

0000000000000858 <kernel>:
     858:      	and	w9, w1, #0xff
     85c:      	mov	w8, #0x8320             // =33568
     860:      	eor	w9, w9, w0
     864:      	movk	w8, #0xedb8, lsl #16
     868:      	orr	w10, w9, #0xfffffffe
     86c:      	lsr	w9, w9, #1
     870:      	add	w10, w10, #0x1
     874:      	and	w10, w10, w8
     878:      	eor	w10, w10, w9
     87c:      	orr	w9, w9, #0xfffffffe
     880:      	add	w9, w9, #0x1
     884:      	lsr	w10, w10, #1
     888:      	and	w9, w9, w8
     88c:      	eor	w9, w10, w9
     890:      	orr	w10, w10, #0xfffffffe
     894:      	add	w10, w10, #0x1
     898:      	lsr	w9, w9, #1
     89c:      	and	w10, w10, w8
     8a0:      	eor	w10, w10, w9
     8a4:      	orr	w9, w9, #0xfffffffe
     8a8:      	add	w9, w9, #0x1
     8ac:      	lsr	w10, w10, #1
     8b0:      	and	w9, w9, w8
     8b4:      	eor	w9, w10, w9
     8b8:      	orr	w10, w10, #0xfffffffe
     8bc:      	add	w10, w10, #0x1
     8c0:      	lsr	w9, w9, #1
     8c4:      	and	w10, w10, w8
     8c8:      	eor	w10, w10, w9
     8cc:      	orr	w9, w9, #0xfffffffe
     8d0:      	add	w9, w9, #0x1
     8d4:      	lsr	w10, w10, #1
     8d8:      	and	w9, w9, w8
     8dc:      	eor	w9, w10, w9
     8e0:      	orr	w10, w10, #0xfffffffe
     8e4:      	lsr	w9, w9, #1
     8e8:      	add	w10, w10, #0x1
     8ec:      	and	w10, w10, w8
     8f0:      	orr	w11, w9, #0xfffffffe
     8f4:      	eor	w9, w10, w9
     8f8:      	add	w11, w11, #0x1
     8fc:      	and	w8, w11, w8
     900:      	eor	w8, w8, w9, lsr #1
     904:      	eor	w0, w8, #0xff000000
     908:      	ret

000000000000090c <main>:
     90c:      	sub	sp, sp, #0x60
     910:      	stp	x29, x30, [sp, #0x20]
     914:      	str	x23, [sp, #0x30]
     918:      	stp	x22, x21, [sp, #0x40]
     91c:      	stp	x20, x19, [sp, #0x50]
     920:      	add	x29, sp, #0x20
     924:      	cmp	w0, #0x3
     928:      	b.eq	0x994 <main+0x88>
     92c:      	cmp	w0, #0x1
     930:      	b.ne	0xa20 <main+0x114>
     934:      	add	x21, x29, #0x18
     938:      	adrp	x0, 0x0 <strtoul@GLIBC_2.17>
     93c:      	add	x0, x0, #0xab8
     940:      	add	x1, x29, #0x18
     944:      	add	x2, x21, #0x4
     948:      	bl	0x710 <__isoc99_scanf@plt>
     94c:      	cmp	w0, #0x2
     950:      	b.ne	0xa78 <main+0x16c>
     954:      	adrp	x19, 0x0 <strtoul@GLIBC_2.17>
     958:      	add	x19, x19, #0xabd
     95c:      	adrp	x20, 0x0 <strtoul@GLIBC_2.17>
     960:      	add	x20, x20, #0xab8
     964:      	ldp	w0, w1, [x29, #0x18]
     968:      	bl	0x858 <kernel>
     96c:      	mov	w1, w0
     970:      	mov	x0, x19
     974:      	bl	0x720 <printf@plt>
     978:      	add	x1, x29, #0x18
     97c:      	add	x2, x21, #0x4
     980:      	mov	x0, x20
     984:      	bl	0x710 <__isoc99_scanf@plt>
     988:      	cmp	w0, #0x2
     98c:      	b.eq	0x964 <main+0x58>
     990:      	b	0xa78 <main+0x16c>
     994:      	ldr	x0, [x1, #0x8]
     998:      	mov	x19, x1
     99c:      	mov	x1, xzr
     9a0:      	mov	w2, #0xa                // =10
     9a4:      	bl	0x6b0 <strtoul@plt>
     9a8:      	ldr	x8, [x19, #0x10]
     9ac:      	mov	x20, x0
     9b0:      	mov	x1, xzr
     9b4:      	mov	w2, #0xa                // =10
     9b8:      	mov	x0, x8
     9bc:      	bl	0x6b0 <strtoul@plt>
     9c0:      	mov	x21, x0
     9c4:      	add	x1, sp, #0x10
     9c8:      	mov	w0, #0x1                // =1
     9cc:      	bl	0x6e0 <clock_gettime@plt>
     9d0:      	cbnz	w0, 0xa3c <main+0x130>
     9d4:      	cbz	x20, 0xa28 <main+0x11c>
     9d8:      	mov	x22, xzr
     9dc:      	mov	x19, xzr
     9e0:      	add	x23, x29, #0x18
     9e4:      	mov	x8, xzr
     9e8:      	eor	w9, w21, w21, lsl #13
     9ec:      	eor	w9, w9, w9, lsr #17
     9f0:      	eor	w21, w9, w9, lsl #5
     9f4:      	str	w21, [x23, x8]
     9f8:      	add	x8, x8, #0x4
     9fc:      	cmp	x8, #0x4
     a00:      	b.eq	0x9e8 <main+0xdc>
     a04:      	ldp	w0, w1, [x29, #0x18]
     a08:      	bl	0x858 <kernel>
     a0c:      	add	x22, x22, #0x1
     a10:      	add	x19, x19, w0, uxtw
     a14:      	cmp	x22, x20
     a18:      	b.ne	0x9e4 <main+0xd8>
     a1c:      	b	0xa2c <main+0x120>
     a20:      	mov	w0, #0x3                // =3
     a24:      	b	0xa7c <main+0x170>
     a28:      	mov	x19, xzr
     a2c:      	mov	x1, sp
     a30:      	mov	w0, #0x1                // =1
     a34:      	bl	0x6e0 <clock_gettime@plt>
     a38:      	cbz	w0, 0xa44 <main+0x138>
     a3c:      	mov	w0, #0x2                // =2
     a40:      	b	0xa7c <main+0x170>
     a44:      	ldp	x8, x9, [sp]
     a48:      	adrp	x0, 0x0 <strtoul@GLIBC_2.17>
     a4c:      	add	x0, x0, #0xac1
     a50:      	ldp	x10, x11, [sp, #0x10]
     a54:      	mov	x1, x19
     a58:      	sub	x8, x8, x10
     a5c:      	sub	x9, x9, x11
     a60:      	scvtf	d0, x8
     a64:      	scvtf	d1, x9
     a68:      	adrp	x8, 0x0 <strtoul@GLIBC_2.17>
     a6c:      	ldr	d2, [x8, #0xab0]
     a70:      	fmadd	d0, d1, d2, d0
     a74:      	bl	0x720 <printf@plt>
     a78:      	mov	w0, wzr
     a7c:      	ldp	x20, x19, [sp, #0x50]
     a80:      	ldr	x23, [sp, #0x30]
     a84:      	ldp	x22, x21, [sp, #0x40]
     a88:      	ldp	x29, x30, [sp, #0x20]
     a8c:      	add	sp, sp, #0x60
     a90:      	ret

Disassembly of section .fini:

0000000000000a94 <_fini>:
     a94:      	nop
     a98:      	stp	x29, x30, [sp, #-0x10]!
     a9c:      	mov	x29, sp
     aa0:      	ldp	x29, x30, [sp], #0x10
     aa4:      	ret
