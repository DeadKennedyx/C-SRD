
/work/experiments/runs/rich-limbs-matrix-linux-20261109/crc32_byte/build-clang-O1-original/program:	file format elf64-littleaarch64

Disassembly of section .init:

0000000000000678 <_init>:
     678:      	nop
     67c:      	stp	x29, x30, [sp, #-0x10]!
     680:      	mov	x29, sp
     684:      	bl	0x774 <call_weak_fn>
     688:      	ldp	x29, x30, [sp], #0x10
     68c:      	ret

Disassembly of section .plt:

0000000000000690 <.plt>:
     690:      	stp	x16, x30, [sp, #-0x10]!
     694:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e480>
     698:      	ldr	x17, [x16, #0xff8]
     69c:      	add	x16, x16, #0xff8
     6a0:      	br	x17
     6a4:      	nop
     6a8:      	nop
     6ac:      	nop

00000000000006b0 <strtoul@plt>:
     6b0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6b4:      	ldr	x17, [x16]
     6b8:      	add	x16, x16, #0x0
     6bc:      	br	x17

00000000000006c0 <__libc_start_main@plt>:
     6c0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6c4:      	ldr	x17, [x16, #0x8]
     6c8:      	add	x16, x16, #0x8
     6cc:      	br	x17

00000000000006d0 <__cxa_finalize@plt>:
     6d0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6d4:      	ldr	x17, [x16, #0x10]
     6d8:      	add	x16, x16, #0x10
     6dc:      	br	x17

00000000000006e0 <clock_gettime@plt>:
     6e0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6e4:      	ldr	x17, [x16, #0x18]
     6e8:      	add	x16, x16, #0x18
     6ec:      	br	x17

00000000000006f0 <__gmon_start__@plt>:
     6f0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6f4:      	ldr	x17, [x16, #0x20]
     6f8:      	add	x16, x16, #0x20
     6fc:      	br	x17

0000000000000700 <abort@plt>:
     700:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     704:      	ldr	x17, [x16, #0x28]
     708:      	add	x16, x16, #0x28
     70c:      	br	x17

0000000000000710 <__isoc99_scanf@plt>:
     710:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     714:      	ldr	x17, [x16, #0x30]
     718:      	add	x16, x16, #0x30
     71c:      	br	x17

0000000000000720 <printf@plt>:
     720:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     724:      	ldr	x17, [x16, #0x38]
     728:      	add	x16, x16, #0x38
     72c:      	br	x17

Disassembly of section .text:

0000000000000740 <_start>:
     740:      	nop
     744:      	mov	x29, #0x0               // =0
     748:      	mov	x30, #0x0               // =0
     74c:      	mov	x5, x0
     750:      	ldr	x1, [sp]
     754:      	add	x2, sp, #0x8
     758:      	mov	x6, sp
     75c:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e480>
     760:      	ldr	x0, [x0, #0xfd8]
     764:      	mov	x3, #0x0                // =0
     768:      	mov	x4, #0x0                // =0
     76c:      	bl	0x6c0 <__libc_start_main@plt>
     770:      	bl	0x700 <abort@plt>

0000000000000774 <call_weak_fn>:
     774:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e480>
     778:      	ldr	x0, [x0, #0xfd0]
     77c:      	cbz	x0, 0x784 <call_weak_fn+0x10>
     780:      	b	0x6f0 <__gmon_start__@plt>
     784:      	ret
     788:      	nop
     78c:      	nop

0000000000000790 <deregister_tm_clones>:
     790:      	adrp	x0, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     794:      	add	x0, x0, #0x50
     798:      	adrp	x1, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     79c:      	add	x1, x1, #0x50
     7a0:      	cmp	x1, x0
     7a4:      	b.eq	0x7bc <deregister_tm_clones+0x2c>
     7a8:      	adrp	x1, 0x1f000 <__FRAME_END__+0x1e480>
     7ac:      	ldr	x1, [x1, #0xfc0]
     7b0:      	cbz	x1, 0x7bc <deregister_tm_clones+0x2c>
     7b4:      	mov	x16, x1
     7b8:      	br	x16
     7bc:      	ret

00000000000007c0 <register_tm_clones>:
     7c0:      	adrp	x0, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     7c4:      	add	x0, x0, #0x50
     7c8:      	adrp	x1, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     7cc:      	add	x1, x1, #0x50
     7d0:      	sub	x1, x1, x0
     7d4:      	lsr	x2, x1, #63
     7d8:      	add	x1, x2, x1, asr #3
     7dc:      	asr	x1, x1, #1
     7e0:      	cbz	x1, 0x7f8 <register_tm_clones+0x38>
     7e4:      	adrp	x2, 0x1f000 <__FRAME_END__+0x1e480>
     7e8:      	ldr	x2, [x2, #0xfe0]
     7ec:      	cbz	x2, 0x7f8 <register_tm_clones+0x38>
     7f0:      	mov	x16, x2
     7f4:      	br	x16
     7f8:      	ret
     7fc:      	nop

0000000000000800 <__do_global_dtors_aux>:
     800:      	paciasp
     804:      	stp	x29, x30, [sp, #-0x20]!
     808:      	mov	x29, sp
     80c:      	str	x19, [sp, #0x10]
     810:      	adrp	x19, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     814:      	ldrb	w0, [x19, #0x50]
     818:      	tbnz	w0, #0x0, 0x840 <__do_global_dtors_aux+0x40>
     81c:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e480>
     820:      	ldr	x0, [x0, #0xfc8]
     824:      	cbz	x0, 0x834 <__do_global_dtors_aux+0x34>
     828:      	adrp	x0, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     82c:      	ldr	x0, [x0, #0x48]
     830:      	bl	0x6d0 <__cxa_finalize@plt>
     834:      	bl	0x790 <deregister_tm_clones>
     838:      	mov	w0, #0x1                // =1
     83c:      	strb	w0, [x19, #0x50]
     840:      	ldr	x19, [sp, #0x10]
     844:      	ldp	x29, x30, [sp], #0x20
     848:      	autiasp
     84c:      	ret

0000000000000850 <frame_dummy>:
     850:      	bti	c
     854:      	b	0x7c0 <register_tm_clones>

0000000000000858 <kernel>:
     858:      	and	w9, w1, #0xff
     85c:      	mov	w10, #0x8320            // =33568
     860:      	mov	w8, #0x8                // =8
     864:      	eon	w9, w9, w0
     868:      	movk	w10, #0xedb8, lsl #16
     86c:      	sbfx	w11, w9, #0, #1
     870:      	subs	w8, w8, #0x1
     874:      	and	w11, w11, w10
     878:      	eor	w9, w11, w9, lsr #1
     87c:      	b.ne	0x86c <kernel+0x14>
     880:      	mvn	w0, w9
     884:      	ret

0000000000000888 <main>:
     888:      	sub	sp, sp, #0x60
     88c:      	stp	x29, x30, [sp, #0x20]
     890:      	str	x23, [sp, #0x30]
     894:      	stp	x22, x21, [sp, #0x40]
     898:      	stp	x20, x19, [sp, #0x50]
     89c:      	add	x29, sp, #0x20
     8a0:      	cmp	w0, #0x3
     8a4:      	b.eq	0x910 <main+0x88>
     8a8:      	cmp	w0, #0x1
     8ac:      	b.ne	0x99c <main+0x114>
     8b0:      	add	x21, x29, #0x18
     8b4:      	adrp	x0, 0x0 <strtoul@GLIBC_2.17>
     8b8:      	add	x0, x0, #0xa38
     8bc:      	add	x1, x29, #0x18
     8c0:      	add	x2, x21, #0x4
     8c4:      	bl	0x710 <__isoc99_scanf@plt>
     8c8:      	cmp	w0, #0x2
     8cc:      	b.ne	0x9f4 <main+0x16c>
     8d0:      	adrp	x19, 0x0 <strtoul@GLIBC_2.17>
     8d4:      	add	x19, x19, #0xa3d
     8d8:      	adrp	x20, 0x0 <strtoul@GLIBC_2.17>
     8dc:      	add	x20, x20, #0xa38
     8e0:      	ldp	w0, w1, [x29, #0x18]
     8e4:      	bl	0x858 <kernel>
     8e8:      	mov	w1, w0
     8ec:      	mov	x0, x19
     8f0:      	bl	0x720 <printf@plt>
     8f4:      	add	x1, x29, #0x18
     8f8:      	add	x2, x21, #0x4
     8fc:      	mov	x0, x20
     900:      	bl	0x710 <__isoc99_scanf@plt>
     904:      	cmp	w0, #0x2
     908:      	b.eq	0x8e0 <main+0x58>
     90c:      	b	0x9f4 <main+0x16c>
     910:      	ldr	x0, [x1, #0x8]
     914:      	mov	x19, x1
     918:      	mov	x1, xzr
     91c:      	mov	w2, #0xa                // =10
     920:      	bl	0x6b0 <strtoul@plt>
     924:      	ldr	x8, [x19, #0x10]
     928:      	mov	x20, x0
     92c:      	mov	x1, xzr
     930:      	mov	w2, #0xa                // =10
     934:      	mov	x0, x8
     938:      	bl	0x6b0 <strtoul@plt>
     93c:      	mov	x21, x0
     940:      	add	x1, sp, #0x10
     944:      	mov	w0, #0x1                // =1
     948:      	bl	0x6e0 <clock_gettime@plt>
     94c:      	cbnz	w0, 0x9b8 <main+0x130>
     950:      	cbz	x20, 0x9a4 <main+0x11c>
     954:      	mov	x22, xzr
     958:      	mov	x19, xzr
     95c:      	add	x23, x29, #0x18
     960:      	mov	x8, xzr
     964:      	eor	w9, w21, w21, lsl #13
     968:      	eor	w9, w9, w9, lsr #17
     96c:      	eor	w21, w9, w9, lsl #5
     970:      	str	w21, [x23, x8]
     974:      	add	x8, x8, #0x4
     978:      	cmp	x8, #0x4
     97c:      	b.eq	0x964 <main+0xdc>
     980:      	ldp	w0, w1, [x29, #0x18]
     984:      	bl	0x858 <kernel>
     988:      	add	x22, x22, #0x1
     98c:      	add	x19, x19, w0, uxtw
     990:      	cmp	x22, x20
     994:      	b.ne	0x960 <main+0xd8>
     998:      	b	0x9a8 <main+0x120>
     99c:      	mov	w0, #0x3                // =3
     9a0:      	b	0x9f8 <main+0x170>
     9a4:      	mov	x19, xzr
     9a8:      	mov	x1, sp
     9ac:      	mov	w0, #0x1                // =1
     9b0:      	bl	0x6e0 <clock_gettime@plt>
     9b4:      	cbz	w0, 0x9c0 <main+0x138>
     9b8:      	mov	w0, #0x2                // =2
     9bc:      	b	0x9f8 <main+0x170>
     9c0:      	ldp	x8, x9, [sp]
     9c4:      	adrp	x0, 0x0 <strtoul@GLIBC_2.17>
     9c8:      	add	x0, x0, #0xa41
     9cc:      	ldp	x10, x11, [sp, #0x10]
     9d0:      	mov	x1, x19
     9d4:      	sub	x8, x8, x10
     9d8:      	sub	x9, x9, x11
     9dc:      	scvtf	d0, x8
     9e0:      	scvtf	d1, x9
     9e4:      	adrp	x8, 0x0 <strtoul@GLIBC_2.17>
     9e8:      	ldr	d2, [x8, #0xa30]
     9ec:      	fmadd	d0, d1, d2, d0
     9f0:      	bl	0x720 <printf@plt>
     9f4:      	mov	w0, wzr
     9f8:      	ldp	x20, x19, [sp, #0x50]
     9fc:      	ldr	x23, [sp, #0x30]
     a00:      	ldp	x22, x21, [sp, #0x40]
     a04:      	ldp	x29, x30, [sp, #0x20]
     a08:      	add	sp, sp, #0x60
     a0c:      	ret

Disassembly of section .fini:

0000000000000a10 <_fini>:
     a10:      	nop
     a14:      	stp	x29, x30, [sp, #-0x10]!
     a18:      	mov	x29, sp
     a1c:      	ldp	x29, x30, [sp], #0x10
     a20:      	ret
