; ModuleID = '/work/experiments/runs/rich-limbs-matrix-linux-20261109/crc32_byte/build-clang-O3-thinlto-limbs16/validation/compiler-0-O3/candidate.i'
source_filename = "/work/experiments/runs/rich-limbs-matrix-linux-20261109/crc32_byte/build-clang-O3-thinlto-limbs16/validation/compiler-0-O3/candidate.i"
target datalayout = "e-m:e-i8:8:32-i16:16:32-i64:64-i128:128-n32:64-S128"
target triple = "aarch64-unknown-linux-gnu"

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local i32 @kernel(i32 noundef %0, i32 noundef %1) local_unnamed_addr #0 {
  %3 = and i32 %0, 65535
  %4 = xor i32 %0, -1
  %5 = and i32 %1, 255
  %6 = xor i32 %3, %5
  %7 = xor i32 %6, 65535
  %8 = and i32 %7, 1
  %9 = icmp eq i32 %8, 0
  %10 = select i1 %9, i32 0, i32 2098
  %11 = select i1 %9, i32 0, i32 60856
  %12 = and i32 %4, 65536
  %13 = or disjoint i32 %7, %12
  %14 = lshr i32 %13, 5
  %15 = lshr i32 %4, 17
  %16 = xor i32 %10, %14
  %17 = xor i32 %11, %15
  %18 = and i32 %7, 2
  %19 = icmp eq i32 %18, 0
  %20 = select i1 %19, i32 0, i32 4196
  %21 = select i1 %19, i32 0, i32 60856
  %22 = shl nuw nsw i32 %15, 12
  %23 = and i32 %22, 4096
  %24 = or i32 %16, %23
  %25 = lshr i32 %17, 1
  %26 = xor i32 %24, %20
  %27 = xor i32 %25, %21
  %28 = and i32 %7, 4
  %29 = icmp eq i32 %28, 0
  %30 = select i1 %29, i32 0, i32 8392
  %31 = select i1 %29, i32 0, i32 60856
  %32 = shl nuw nsw i32 %25, 13
  %33 = and i32 %32, 8192
  %34 = or disjoint i32 %33, %26
  %35 = lshr i32 %27, 1
  %36 = xor i32 %34, %30
  %37 = xor i32 %35, %31
  %38 = and i32 %7, 8
  %39 = icmp eq i32 %38, 0
  %40 = select i1 %39, i32 0, i32 16784
  %41 = select i1 %39, i32 0, i32 60856
  %42 = shl nuw nsw i32 %35, 14
  %43 = and i32 %42, 16384
  %44 = or i32 %36, %43
  %45 = lshr i32 %37, 1
  %46 = xor i32 %44, %40
  %47 = xor i32 %45, %41
  %48 = and i32 %7, 16
  %49 = icmp eq i32 %48, 0
  %50 = select i1 %49, i32 0, i32 33568
  %51 = select i1 %49, i32 0, i32 60856
  %52 = shl nuw nsw i32 %45, 15
  %53 = or i32 %46, %52
  %54 = and i32 %53, 65532
  %55 = lshr i32 %47, 1
  %56 = xor i32 %54, %50
  %57 = xor i32 %55, %51
  %58 = and i32 %7, 32
  %59 = icmp eq i32 %58, 0
  %60 = select i1 %59, i32 0, i32 33568
  %61 = select i1 %59, i32 0, i32 60856
  %62 = lshr exact i32 %56, 1
  %63 = shl nuw nsw i32 %55, 15
  %64 = and i32 %63, 32768
  %65 = or disjoint i32 %62, %64
  %66 = lshr i32 %57, 1
  %67 = xor i32 %65, %60
  %68 = xor i32 %66, %61
  %69 = and i32 %16, 2
  %70 = icmp eq i32 %69, 0
  %71 = select i1 %70, i32 0, i32 33568
  %72 = select i1 %70, i32 0, i32 60856
  %73 = lshr exact i32 %67, 1
  %74 = shl nuw nsw i32 %66, 15
  %75 = and i32 %74, 32768
  %76 = or i32 %73, %75
  %77 = lshr i32 %68, 1
  %78 = xor i32 %76, %71
  %79 = xor i32 %77, %72
  %80 = and i32 %26, 4
  %81 = icmp eq i32 %80, 0
  %82 = select i1 %81, i32 0, i32 33568
  %83 = lshr i32 %78, 1
  %84 = shl nuw nsw i32 %77, 15
  %85 = or i32 %83, %84
  %86 = and i32 %85, 65535
  %87 = lshr i32 %79, 1
  %88 = xor i32 %86, %82
  %89 = select i1 %81, i32 65535, i32 4679
  %90 = xor i32 %87, %89
  %91 = shl nuw i32 %90, 16
  %92 = or disjoint i32 %88, %91
  %93 = xor i32 %92, 65535
  ret i32 %93
}

attributes #0 = { mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable "frame-pointer"="non-leaf" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+fp-armv8,+neon,+outline-atomics,+v8a,-fmv" }

!llvm.module.flags = !{!0, !1, !2, !3, !4, !5}
!llvm.ident = !{!6}

!0 = !{i32 1, !"wchar_size", i32 4}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 1}
!5 = !{i32 1, !"EnableSplitLTOUnit", i32 0}
!6 = !{!"Ubuntu clang version 18.1.3 (1ubuntu1)"}

^0 = module: (path: "[Regular LTO]", hash: (0, 0, 0, 0, 0))
^1 = gv: (name: "kernel", summaries: (function: (module: ^0, flags: (linkage: external, visibility: default, notEligibleToImport: 0, live: 0, dsoLocal: 1, canAutoHide: 0), insts: 92, funcFlags: (readNone: 1, readOnly: 0, noRecurse: 1, returnDoesNotAlias: 0, noInline: 0, alwaysInline: 0, noUnwind: 1, mayThrow: 0, hasUnknownCall: 0, mustBeUnreachable: 0)))) ; guid = 17571550346185820240
^2 = blockcount: 0
