; ModuleID = '/work/experiments/runs/rich-limbs-matrix-linux-20261109/crc32_byte/build-clang-O1-sanitizers-xor-42/validation/compiler-0-O1/candidate.i'
source_filename = "/work/experiments/runs/rich-limbs-matrix-linux-20261109/crc32_byte/build-clang-O1-sanitizers-xor-42/validation/compiler-0-O1/candidate.i"
target datalayout = "e-m:e-i8:8:32-i16:16:32-i64:64-i128:128-n32:64-S128"
target triple = "aarch64-unknown-linux-gnu"

$asan.module_ctor = comdat any

@llvm.used = appending global [1 x ptr] [ptr @asan.module_ctor], section "llvm.metadata"
@___asan_globals_registered = common hidden global i64 0
@__start_asan_globals = extern_weak hidden global i64
@__stop_asan_globals = extern_weak hidden global i64
@llvm.global_ctors = appending global [1 x { i32, ptr, ptr }] [{ i32, ptr, ptr } { i32 1, ptr @asan.module_ctor, ptr @asan.module_ctor }]

; Function Attrs: mustprogress nofree norecurse nosync nounwind sanitize_address willreturn memory(none) uwtable
define dso_local i32 @kernel(i32 noundef %state, i32 noundef %byte) local_unnamed_addr #0 !func_sanitize !6 {
entry:
  %and5 = and i32 %byte, 255
  %xor6 = xor i32 %and5, %state
  %0 = or i32 %xor6, -2
  %.neg = add nsw i32 %0, 1
  %shr = lshr i32 %xor6, 1
  %and18 = and i32 %.neg, -306674912
  %xor19 = xor i32 %and18, %shr
  %1 = or i32 %shr, -2
  %.neg169 = add nsw i32 %1, 1
  %shr30 = lshr i32 %xor19, 1
  %and35 = and i32 %.neg169, -306674912
  %xor36 = xor i32 %shr30, %and35
  %2 = or i32 %shr30, -2
  %xor43.neg = add nsw i32 %2, 1
  %shr47 = lshr i32 %xor36, 1
  %and52 = and i32 %xor43.neg, -306674912
  %xor53 = xor i32 %and52, %shr47
  %3 = or i32 %shr47, -2
  %xor60.neg = add nsw i32 %3, 1
  %shr64 = lshr i32 %xor53, 1
  %and69 = and i32 %xor60.neg, -306674912
  %xor70 = xor i32 %shr64, %and69
  %4 = or i32 %shr64, -2
  %xor77.neg = add nsw i32 %4, 1
  %shr81 = lshr i32 %xor70, 1
  %and86 = and i32 %xor77.neg, -306674912
  %xor87 = xor i32 %and86, %shr81
  %5 = or i32 %shr81, -2
  %xor94.neg = add nsw i32 %5, 1
  %shr98 = lshr i32 %xor87, 1
  %and103 = and i32 %xor94.neg, -306674912
  %xor104 = xor i32 %shr98, %and103
  %6 = or i32 %shr98, -2
  %xor111.neg = add nsw i32 %6, 1
  %shr115 = lshr i32 %xor104, 1
  %and120 = and i32 %xor111.neg, -306674912
  %xor121 = xor i32 %and120, %shr115
  %7 = or i32 %shr115, -2
  %xor128.neg = add nsw i32 %7, 1
  %shr132 = lshr i32 %xor121, 1
  %and137 = and i32 %xor128.neg, -306674912
  %8 = xor i32 %and137, %shr132
  %xor141 = xor i32 %8, -16777216
  ret i32 %xor141
}

declare void @__asan_register_elf_globals(i64, i64, i64)

declare void @__asan_init()

; Function Attrs: nounwind uwtable
define internal void @asan.module_ctor() #1 comdat {
  call void @__asan_init()
  call void @__asan_version_mismatch_check_v8()
  call void @__asan_register_elf_globals(i64 ptrtoint (ptr @___asan_globals_registered to i64), i64 ptrtoint (ptr @__start_asan_globals to i64), i64 ptrtoint (ptr @__stop_asan_globals to i64))
  ret void
}

declare void @__asan_version_mismatch_check_v8()

attributes #0 = { mustprogress nofree norecurse nosync nounwind sanitize_address willreturn memory(none) uwtable "frame-pointer"="non-leaf" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+fp-armv8,+neon,+outline-atomics,+v8a,-fmv" }
attributes #1 = { nounwind uwtable "frame-pointer"="non-leaf" }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 1, !"wchar_size", i32 4}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 1}
!5 = !{!"Ubuntu clang version 18.1.3 (1ubuntu1)"}
!6 = !{i32 -1056584962, i32 -455559067}
