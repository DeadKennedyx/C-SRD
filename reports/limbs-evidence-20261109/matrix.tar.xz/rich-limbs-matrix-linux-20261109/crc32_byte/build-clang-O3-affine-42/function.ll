; ModuleID = '/work/experiments/runs/rich-limbs-matrix-linux-20261109/crc32_byte/build-clang-O3-affine-42/validation/compiler-0-O3/candidate.i'
source_filename = "/work/experiments/runs/rich-limbs-matrix-linux-20261109/crc32_byte/build-clang-O3-affine-42/validation/compiler-0-O3/candidate.i"
target datalayout = "e-m:e-i8:8:32-i16:16:32-i64:64-i128:128-n32:64-S128"
target triple = "aarch64-unknown-linux-gnu"

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local i32 @kernel(i32 noundef %0, i32 noundef %1) local_unnamed_addr #0 {
  %3 = and i32 %1, 255
  %4 = xor i32 %3, %0
  %5 = xor i32 %4, -1
  %6 = lshr i32 %5, 6
  %7 = and i32 %5, 1
  %8 = icmp eq i32 %7, 0
  %9 = select i1 %8, i32 0, i32 124634137
  %10 = and i32 %5, 2
  %11 = icmp eq i32 %10, 0
  %12 = select i1 %11, i32 0, i32 249268274
  %13 = xor i32 %12, %6
  %14 = xor i32 %13, %9
  %15 = insertelement <4 x i32> poison, i32 %5, i64 0
  %16 = shufflevector <4 x i32> %15, <4 x i32> poison, <4 x i32> zeroinitializer
  %17 = and <4 x i32> %16, <i32 4, i32 16, i32 8, i32 32>
  %18 = icmp eq <4 x i32> %17, zeroinitializer
  %19 = select <4 x i1> %18, <4 x i32> zeroinitializer, <4 x i32> <i32 498536548, i32 1994146192, i32 997073096, i32 -306674912>
  %20 = tail call i32 @llvm.vector.reduce.xor.v4i32(<4 x i32> %19)
  %21 = xor i32 %20, %14
  %22 = lshr i32 %21, 2
  %23 = and i32 %14, 1
  %24 = icmp eq i32 %23, 0
  %25 = select i1 %24, i32 0, i32 1994146192
  %26 = xor i32 %25, %22
  %27 = and i32 %13, 2
  %28 = icmp eq i32 %27, 0
  %29 = select i1 %28, i32 -1, i32 306674911
  %30 = xor i32 %26, %29
  ret i32 %30
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.vector.reduce.xor.v4i32(<4 x i32>) #1

attributes #0 = { mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable "frame-pointer"="non-leaf" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+fp-armv8,+neon,+outline-atomics,+v8a,-fmv" }
attributes #1 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 1, !"wchar_size", i32 4}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 1}
!5 = !{!"Ubuntu clang version 18.1.3 (1ubuntu1)"}
