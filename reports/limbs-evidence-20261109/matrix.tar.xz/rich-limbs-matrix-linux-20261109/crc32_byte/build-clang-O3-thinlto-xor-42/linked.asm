
/work/experiments/runs/rich-limbs-matrix-linux-20261109/crc32_byte/build-clang-O3-thinlto-xor-42/program:	file format elf64-littleaarch64

Disassembly of section .init:

0000000000000678 <_init>:
     678:      	nop
     67c:      	stp	x29, x30, [sp, #-0x10]!
     680:      	mov	x29, sp
     684:      	bl	0x774 <call_weak_fn>
     688:      	ldp	x29, x30, [sp], #0x10
     68c:      	ret

Disassembly of section .plt:

0000000000000690 <.plt>:
     690:      	stp	x16, x30, [sp, #-0x10]!
     694:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e26c>
     698:      	ldr	x17, [x16, #0xff8]
     69c:      	add	x16, x16, #0xff8
     6a0:      	br	x17
     6a4:      	nop
     6a8:      	nop
     6ac:      	nop

00000000000006b0 <strtoul@plt>:
     6b0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6b4:      	ldr	x17, [x16]
     6b8:      	add	x16, x16, #0x0
     6bc:      	br	x17

00000000000006c0 <__libc_start_main@plt>:
     6c0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6c4:      	ldr	x17, [x16, #0x8]
     6c8:      	add	x16, x16, #0x8
     6cc:      	br	x17

00000000000006d0 <__cxa_finalize@plt>:
     6d0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6d4:      	ldr	x17, [x16, #0x10]
     6d8:      	add	x16, x16, #0x10
     6dc:      	br	x17

00000000000006e0 <clock_gettime@plt>:
     6e0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6e4:      	ldr	x17, [x16, #0x18]
     6e8:      	add	x16, x16, #0x18
     6ec:      	br	x17

00000000000006f0 <__gmon_start__@plt>:
     6f0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6f4:      	ldr	x17, [x16, #0x20]
     6f8:      	add	x16, x16, #0x20
     6fc:      	br	x17

0000000000000700 <abort@plt>:
     700:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     704:      	ldr	x17, [x16, #0x28]
     708:      	add	x16, x16, #0x28
     70c:      	br	x17

0000000000000710 <__isoc99_scanf@plt>:
     710:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     714:      	ldr	x17, [x16, #0x30]
     718:      	add	x16, x16, #0x30
     71c:      	br	x17

0000000000000720 <printf@plt>:
     720:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     724:      	ldr	x17, [x16, #0x38]
     728:      	add	x16, x16, #0x38
     72c:      	br	x17

Disassembly of section .text:

0000000000000740 <_start>:
     740:      	nop
     744:      	mov	x29, #0x0               // =0
     748:      	mov	x30, #0x0               // =0
     74c:      	mov	x5, x0
     750:      	ldr	x1, [sp]
     754:      	add	x2, sp, #0x8
     758:      	mov	x6, sp
     75c:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e26c>
     760:      	ldr	x0, [x0, #0xfd8]
     764:      	mov	x3, #0x0                // =0
     768:      	mov	x4, #0x0                // =0
     76c:      	bl	0x6c0 <__libc_start_main@plt>
     770:      	bl	0x700 <abort@plt>

0000000000000774 <call_weak_fn>:
     774:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e26c>
     778:      	ldr	x0, [x0, #0xfd0]
     77c:      	cbz	x0, 0x784 <call_weak_fn+0x10>
     780:      	b	0x6f0 <__gmon_start__@plt>
     784:      	ret
     788:      	nop
     78c:      	nop

0000000000000790 <deregister_tm_clones>:
     790:      	adrp	x0, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     794:      	add	x0, x0, #0x50
     798:      	adrp	x1, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     79c:      	add	x1, x1, #0x50
     7a0:      	cmp	x1, x0
     7a4:      	b.eq	0x7bc <deregister_tm_clones+0x2c>
     7a8:      	adrp	x1, 0x1f000 <__FRAME_END__+0x1e26c>
     7ac:      	ldr	x1, [x1, #0xfc0]
     7b0:      	cbz	x1, 0x7bc <deregister_tm_clones+0x2c>
     7b4:      	mov	x16, x1
     7b8:      	br	x16
     7bc:      	ret

00000000000007c0 <register_tm_clones>:
     7c0:      	adrp	x0, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     7c4:      	add	x0, x0, #0x50
     7c8:      	adrp	x1, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     7cc:      	add	x1, x1, #0x50
     7d0:      	sub	x1, x1, x0
     7d4:      	lsr	x2, x1, #63
     7d8:      	add	x1, x2, x1, asr #3
     7dc:      	asr	x1, x1, #1
     7e0:      	cbz	x1, 0x7f8 <register_tm_clones+0x38>
     7e4:      	adrp	x2, 0x1f000 <__FRAME_END__+0x1e26c>
     7e8:      	ldr	x2, [x2, #0xfe0]
     7ec:      	cbz	x2, 0x7f8 <register_tm_clones+0x38>
     7f0:      	mov	x16, x2
     7f4:      	br	x16
     7f8:      	ret
     7fc:      	nop

0000000000000800 <__do_global_dtors_aux>:
     800:      	paciasp
     804:      	stp	x29, x30, [sp, #-0x20]!
     808:      	mov	x29, sp
     80c:      	str	x19, [sp, #0x10]
     810:      	adrp	x19, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     814:      	ldrb	w0, [x19, #0x50]
     818:      	tbnz	w0, #0x0, 0x840 <__do_global_dtors_aux+0x40>
     81c:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e26c>
     820:      	ldr	x0, [x0, #0xfc8]
     824:      	cbz	x0, 0x834 <__do_global_dtors_aux+0x34>
     828:      	adrp	x0, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     82c:      	ldr	x0, [x0, #0x48]
     830:      	bl	0x6d0 <__cxa_finalize@plt>
     834:      	bl	0x790 <deregister_tm_clones>
     838:      	mov	w0, #0x1                // =1
     83c:      	strb	w0, [x19, #0x50]
     840:      	ldr	x19, [sp, #0x10]
     844:      	ldp	x29, x30, [sp], #0x20
     848:      	autiasp
     84c:      	ret

0000000000000850 <frame_dummy>:
     850:      	bti	c
     854:      	b	0x7c0 <register_tm_clones>

0000000000000858 <kernel>:
     858:      	and	w9, w1, #0xff
     85c:      	mov	w8, #0x8320             // =33568
     860:      	eor	w9, w9, w0
     864:      	movk	w8, #0xedb8, lsl #16
     868:      	orr	w10, w9, #0xfffffffe
     86c:      	lsr	w9, w9, #1
     870:      	add	w10, w10, #0x1
     874:      	and	w10, w10, w8
     878:      	eor	w10, w10, w9
     87c:      	orr	w9, w9, #0xfffffffe
     880:      	add	w9, w9, #0x1
     884:      	lsr	w10, w10, #1
     888:      	and	w9, w9, w8
     88c:      	eor	w9, w10, w9
     890:      	orr	w10, w10, #0xfffffffe
     894:      	add	w10, w10, #0x1
     898:      	lsr	w9, w9, #1
     89c:      	and	w10, w10, w8
     8a0:      	eor	w10, w10, w9
     8a4:      	orr	w9, w9, #0xfffffffe
     8a8:      	add	w9, w9, #0x1
     8ac:      	lsr	w10, w10, #1
     8b0:      	and	w9, w9, w8
     8b4:      	eor	w9, w10, w9
     8b8:      	orr	w10, w10, #0xfffffffe
     8bc:      	add	w10, w10, #0x1
     8c0:      	lsr	w9, w9, #1
     8c4:      	and	w10, w10, w8
     8c8:      	eor	w10, w10, w9
     8cc:      	orr	w9, w9, #0xfffffffe
     8d0:      	add	w9, w9, #0x1
     8d4:      	lsr	w10, w10, #1
     8d8:      	and	w9, w9, w8
     8dc:      	eor	w9, w10, w9
     8e0:      	orr	w10, w10, #0xfffffffe
     8e4:      	lsr	w9, w9, #1
     8e8:      	add	w10, w10, #0x1
     8ec:      	and	w10, w10, w8
     8f0:      	orr	w11, w9, #0xfffffffe
     8f4:      	eor	w9, w10, w9
     8f8:      	add	w11, w11, #0x1
     8fc:      	and	w8, w11, w8
     900:      	eor	w8, w8, w9, lsr #1
     904:      	eor	w0, w8, #0xff000000
     908:      	ret

000000000000090c <main>:
     90c:      	sub	sp, sp, #0x50
     910:      	stp	x29, x30, [sp, #0x20]
     914:      	stp	x22, x21, [sp, #0x30]
     918:      	stp	x20, x19, [sp, #0x40]
     91c:      	add	x29, sp, #0x20
     920:      	cmp	w0, #0x3
     924:      	b.eq	0xa38 <main+0x12c>
     928:      	cmp	w0, #0x1
     92c:      	b.ne	0xa90 <main+0x184>
     930:      	add	x21, sp, #0x10
     934:      	adrp	x0, 0x0 <strtoul@GLIBC_2.17>
     938:      	add	x0, x0, #0xc20
     93c:      	add	x1, sp, #0x10
     940:      	add	x2, x21, #0x4
     944:      	bl	0x710 <__isoc99_scanf@plt>
     948:      	cmp	w0, #0x2
     94c:      	b.ne	0xbe0 <main+0x2d4>
     950:      	mov	w22, #0x8320            // =33568
     954:      	adrp	x19, 0x0 <strtoul@GLIBC_2.17>
     958:      	add	x19, x19, #0xc25
     95c:      	movk	w22, #0xedb8, lsl #16
     960:      	adrp	x20, 0x0 <strtoul@GLIBC_2.17>
     964:      	add	x20, x20, #0xc20
     968:      	ldr	w8, [sp, #0x10]
     96c:      	ldrb	w9, [sp, #0x14]
     970:      	mov	x0, x19
     974:      	eor	w8, w9, w8
     978:      	orr	w9, w8, #0xfffffffe
     97c:      	lsr	w8, w8, #1
     980:      	add	w9, w9, #0x1
     984:      	and	w9, w9, w22
     988:      	eor	w9, w9, w8
     98c:      	orr	w8, w8, #0xfffffffe
     990:      	add	w8, w8, #0x1
     994:      	lsr	w9, w9, #1
     998:      	and	w8, w8, w22
     99c:      	eor	w8, w9, w8
     9a0:      	orr	w9, w9, #0xfffffffe
     9a4:      	add	w9, w9, #0x1
     9a8:      	lsr	w8, w8, #1
     9ac:      	and	w9, w9, w22
     9b0:      	eor	w9, w9, w8
     9b4:      	orr	w8, w8, #0xfffffffe
     9b8:      	add	w8, w8, #0x1
     9bc:      	lsr	w9, w9, #1
     9c0:      	and	w8, w8, w22
     9c4:      	eor	w8, w9, w8
     9c8:      	orr	w9, w9, #0xfffffffe
     9cc:      	add	w9, w9, #0x1
     9d0:      	lsr	w8, w8, #1
     9d4:      	and	w9, w9, w22
     9d8:      	eor	w9, w9, w8
     9dc:      	orr	w8, w8, #0xfffffffe
     9e0:      	add	w8, w8, #0x1
     9e4:      	lsr	w9, w9, #1
     9e8:      	and	w8, w8, w22
     9ec:      	eor	w8, w9, w8
     9f0:      	orr	w9, w9, #0xfffffffe
     9f4:      	lsr	w8, w8, #1
     9f8:      	add	w9, w9, #0x1
     9fc:      	and	w9, w9, w22
     a00:      	orr	w10, w8, #0xfffffffe
     a04:      	eor	w8, w9, w8
     a08:      	add	w10, w10, #0x1
     a0c:      	and	w9, w10, w22
     a10:      	eor	w8, w9, w8, lsr #1
     a14:      	eor	w1, w8, #0xff000000
     a18:      	bl	0x720 <printf@plt>
     a1c:      	add	x1, sp, #0x10
     a20:      	add	x2, x21, #0x4
     a24:      	mov	x0, x20
     a28:      	bl	0x710 <__isoc99_scanf@plt>
     a2c:      	cmp	w0, #0x2
     a30:      	b.eq	0x968 <main+0x5c>
     a34:      	b	0xbe0 <main+0x2d4>
     a38:      	ldr	x0, [x1, #0x8]
     a3c:      	mov	x19, x1
     a40:      	mov	x1, xzr
     a44:      	mov	w2, #0xa                // =10
     a48:      	bl	0x6b0 <strtoul@plt>
     a4c:      	ldr	x8, [x19, #0x10]
     a50:      	mov	x20, x0
     a54:      	mov	x1, xzr
     a58:      	mov	w2, #0xa                // =10
     a5c:      	mov	x0, x8
     a60:      	bl	0x6b0 <strtoul@plt>
     a64:      	mov	x21, x0
     a68:      	add	x1, sp, #0x10
     a6c:      	mov	w0, #0x1                // =1
     a70:      	bl	0x6e0 <clock_gettime@plt>
     a74:      	cbz	w0, 0xaa8 <main+0x19c>
     a78:      	mov	w0, #0x2                // =2
     a7c:      	ldp	x20, x19, [sp, #0x40]
     a80:      	ldp	x22, x21, [sp, #0x30]
     a84:      	ldp	x29, x30, [sp, #0x20]
     a88:      	add	sp, sp, #0x50
     a8c:      	ret
     a90:      	mov	w0, #0x3                // =3
     a94:      	ldp	x20, x19, [sp, #0x40]
     a98:      	ldp	x22, x21, [sp, #0x30]
     a9c:      	ldp	x29, x30, [sp, #0x20]
     aa0:      	add	sp, sp, #0x50
     aa4:      	ret
     aa8:      	mov	x19, xzr
     aac:      	cbz	x20, 0xb84 <main+0x278>
     ab0:      	mov	w8, #0x8320             // =33568
     ab4:      	movk	w8, #0xedb8, lsl #16
     ab8:      	eor	w9, w21, w21, lsl #13
     abc:      	subs	x20, x20, #0x1
     ac0:      	eor	w9, w9, w9, lsr #17
     ac4:      	eor	w9, w9, w9, lsl #5
     ac8:      	eor	w10, w9, w9, lsl #13
     acc:      	eor	w10, w10, w10, lsr #17
     ad0:      	eor	w21, w10, w10, lsl #5
     ad4:      	and	w10, w21, #0xff
     ad8:      	eor	w9, w10, w9
     adc:      	orr	w10, w9, #0xfffffffe
     ae0:      	lsr	w9, w9, #1
     ae4:      	add	w10, w10, #0x1
     ae8:      	and	w10, w10, w8
     aec:      	eor	w10, w10, w9
     af0:      	orr	w9, w9, #0xfffffffe
     af4:      	add	w9, w9, #0x1
     af8:      	lsr	w10, w10, #1
     afc:      	and	w9, w9, w8
     b00:      	eor	w9, w10, w9
     b04:      	orr	w10, w10, #0xfffffffe
     b08:      	add	w10, w10, #0x1
     b0c:      	lsr	w9, w9, #1
     b10:      	and	w10, w10, w8
     b14:      	eor	w10, w10, w9
     b18:      	orr	w9, w9, #0xfffffffe
     b1c:      	add	w9, w9, #0x1
     b20:      	lsr	w10, w10, #1
     b24:      	and	w9, w9, w8
     b28:      	eor	w9, w10, w9
     b2c:      	orr	w10, w10, #0xfffffffe
     b30:      	add	w10, w10, #0x1
     b34:      	lsr	w9, w9, #1
     b38:      	and	w10, w10, w8
     b3c:      	eor	w10, w10, w9
     b40:      	orr	w9, w9, #0xfffffffe
     b44:      	add	w9, w9, #0x1
     b48:      	lsr	w10, w10, #1
     b4c:      	and	w9, w9, w8
     b50:      	eor	w9, w10, w9
     b54:      	orr	w10, w10, #0xfffffffe
     b58:      	lsr	w9, w9, #1
     b5c:      	add	w10, w10, #0x1
     b60:      	and	w10, w10, w8
     b64:      	orr	w11, w9, #0xfffffffe
     b68:      	eor	w9, w10, w9
     b6c:      	add	w11, w11, #0x1
     b70:      	and	w10, w11, w8
     b74:      	eor	w9, w10, w9, lsr #1
     b78:      	eor	w9, w9, #0xff000000
     b7c:      	add	x19, x19, x9
     b80:      	b.ne	0xab8 <main+0x1ac>
     b84:      	mov	x1, sp
     b88:      	mov	w0, #0x1                // =1
     b8c:      	bl	0x6e0 <clock_gettime@plt>
     b90:      	cbz	w0, 0xbac <main+0x2a0>
     b94:      	mov	w0, #0x2                // =2
     b98:      	ldp	x20, x19, [sp, #0x40]
     b9c:      	ldp	x22, x21, [sp, #0x30]
     ba0:      	ldp	x29, x30, [sp, #0x20]
     ba4:      	add	sp, sp, #0x50
     ba8:      	ret
     bac:      	ldp	x8, x9, [sp]
     bb0:      	adrp	x0, 0x0 <strtoul@GLIBC_2.17>
     bb4:      	add	x0, x0, #0xc29
     bb8:      	ldp	x10, x11, [sp, #0x10]
     bbc:      	mov	x1, x19
     bc0:      	sub	x8, x8, x10
     bc4:      	sub	x9, x9, x11
     bc8:      	scvtf	d0, x8
     bcc:      	scvtf	d1, x9
     bd0:      	adrp	x8, 0x0 <strtoul@GLIBC_2.17>
     bd4:      	ldr	d2, [x8, #0xc18]
     bd8:      	fmadd	d0, d1, d2, d0
     bdc:      	bl	0x720 <printf@plt>
     be0:      	mov	w0, wzr
     be4:      	ldp	x20, x19, [sp, #0x40]
     be8:      	ldp	x22, x21, [sp, #0x30]
     bec:      	ldp	x29, x30, [sp, #0x20]
     bf0:      	add	sp, sp, #0x50
     bf4:      	ret

Disassembly of section .fini:

0000000000000bf8 <_fini>:
     bf8:      	nop
     bfc:      	stp	x29, x30, [sp, #-0x10]!
     c00:      	mov	x29, sp
     c04:      	ldp	x29, x30, [sp], #0x10
     c08:      	ret
