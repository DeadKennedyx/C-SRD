
/work/experiments/runs/rich-limbs-matrix-linux-20261109/crc32_byte/build-clang-O2-lto-planned-42/program:	file format elf64-littleaarch64

Disassembly of section .init:

0000000000000678 <_init>:
     678:      	nop
     67c:      	stp	x29, x30, [sp, #-0x10]!
     680:      	mov	x29, sp
     684:      	bl	0x774 <call_weak_fn>
     688:      	ldp	x29, x30, [sp], #0x10
     68c:      	ret

Disassembly of section .plt:

0000000000000690 <.plt>:
     690:      	stp	x16, x30, [sp, #-0x10]!
     694:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e3c0>
     698:      	ldr	x17, [x16, #0xff8]
     69c:      	add	x16, x16, #0xff8
     6a0:      	br	x17
     6a4:      	nop
     6a8:      	nop
     6ac:      	nop

00000000000006b0 <strtoul@plt>:
     6b0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6b4:      	ldr	x17, [x16]
     6b8:      	add	x16, x16, #0x0
     6bc:      	br	x17

00000000000006c0 <__libc_start_main@plt>:
     6c0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6c4:      	ldr	x17, [x16, #0x8]
     6c8:      	add	x16, x16, #0x8
     6cc:      	br	x17

00000000000006d0 <__cxa_finalize@plt>:
     6d0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6d4:      	ldr	x17, [x16, #0x10]
     6d8:      	add	x16, x16, #0x10
     6dc:      	br	x17

00000000000006e0 <clock_gettime@plt>:
     6e0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6e4:      	ldr	x17, [x16, #0x18]
     6e8:      	add	x16, x16, #0x18
     6ec:      	br	x17

00000000000006f0 <__gmon_start__@plt>:
     6f0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6f4:      	ldr	x17, [x16, #0x20]
     6f8:      	add	x16, x16, #0x20
     6fc:      	br	x17

0000000000000700 <abort@plt>:
     700:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     704:      	ldr	x17, [x16, #0x28]
     708:      	add	x16, x16, #0x28
     70c:      	br	x17

0000000000000710 <__isoc99_scanf@plt>:
     710:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     714:      	ldr	x17, [x16, #0x30]
     718:      	add	x16, x16, #0x30
     71c:      	br	x17

0000000000000720 <printf@plt>:
     720:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     724:      	ldr	x17, [x16, #0x38]
     728:      	add	x16, x16, #0x38
     72c:      	br	x17

Disassembly of section .text:

0000000000000740 <_start>:
     740:      	nop
     744:      	mov	x29, #0x0               // =0
     748:      	mov	x30, #0x0               // =0
     74c:      	mov	x5, x0
     750:      	ldr	x1, [sp]
     754:      	add	x2, sp, #0x8
     758:      	mov	x6, sp
     75c:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e3c0>
     760:      	ldr	x0, [x0, #0xfd8]
     764:      	mov	x3, #0x0                // =0
     768:      	mov	x4, #0x0                // =0
     76c:      	bl	0x6c0 <__libc_start_main@plt>
     770:      	bl	0x700 <abort@plt>

0000000000000774 <call_weak_fn>:
     774:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e3c0>
     778:      	ldr	x0, [x0, #0xfd0]
     77c:      	cbz	x0, 0x784 <call_weak_fn+0x10>
     780:      	b	0x6f0 <__gmon_start__@plt>
     784:      	ret
     788:      	nop
     78c:      	nop

0000000000000790 <deregister_tm_clones>:
     790:      	adrp	x0, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     794:      	add	x0, x0, #0x50
     798:      	adrp	x1, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     79c:      	add	x1, x1, #0x50
     7a0:      	cmp	x1, x0
     7a4:      	b.eq	0x7bc <deregister_tm_clones+0x2c>
     7a8:      	adrp	x1, 0x1f000 <__FRAME_END__+0x1e3c0>
     7ac:      	ldr	x1, [x1, #0xfc0]
     7b0:      	cbz	x1, 0x7bc <deregister_tm_clones+0x2c>
     7b4:      	mov	x16, x1
     7b8:      	br	x16
     7bc:      	ret

00000000000007c0 <register_tm_clones>:
     7c0:      	adrp	x0, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     7c4:      	add	x0, x0, #0x50
     7c8:      	adrp	x1, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     7cc:      	add	x1, x1, #0x50
     7d0:      	sub	x1, x1, x0
     7d4:      	lsr	x2, x1, #63
     7d8:      	add	x1, x2, x1, asr #3
     7dc:      	asr	x1, x1, #1
     7e0:      	cbz	x1, 0x7f8 <register_tm_clones+0x38>
     7e4:      	adrp	x2, 0x1f000 <__FRAME_END__+0x1e3c0>
     7e8:      	ldr	x2, [x2, #0xfe0]
     7ec:      	cbz	x2, 0x7f8 <register_tm_clones+0x38>
     7f0:      	mov	x16, x2
     7f4:      	br	x16
     7f8:      	ret
     7fc:      	nop

0000000000000800 <__do_global_dtors_aux>:
     800:      	paciasp
     804:      	stp	x29, x30, [sp, #-0x20]!
     808:      	mov	x29, sp
     80c:      	str	x19, [sp, #0x10]
     810:      	adrp	x19, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     814:      	ldrb	w0, [x19, #0x50]
     818:      	tbnz	w0, #0x0, 0x840 <__do_global_dtors_aux+0x40>
     81c:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e3c0>
     820:      	ldr	x0, [x0, #0xfc8]
     824:      	cbz	x0, 0x834 <__do_global_dtors_aux+0x34>
     828:      	adrp	x0, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     82c:      	ldr	x0, [x0, #0x48]
     830:      	bl	0x6d0 <__cxa_finalize@plt>
     834:      	bl	0x790 <deregister_tm_clones>
     838:      	mov	w0, #0x1                // =1
     83c:      	strb	w0, [x19, #0x50]
     840:      	ldr	x19, [sp, #0x10]
     844:      	ldp	x29, x30, [sp], #0x20
     848:      	autiasp
     84c:      	ret

0000000000000850 <frame_dummy>:
     850:      	bti	c
     854:      	b	0x7c0 <register_tm_clones>

0000000000000858 <main>:
     858:      	sub	sp, sp, #0x50
     85c:      	stp	x29, x30, [sp, #0x20]
     860:      	stp	x22, x21, [sp, #0x30]
     864:      	stp	x20, x19, [sp, #0x40]
     868:      	add	x29, sp, #0x20
     86c:      	cmp	w0, #0x3
     870:      	b.eq	0x968 <main+0x110>
     874:      	cmp	w0, #0x1
     878:      	b.ne	0xa9c <main+0x244>
     87c:      	mov	w21, #0x8320            // =33568
     880:      	adrp	x19, 0x0 <strtoul@GLIBC_2.17>
     884:      	add	x19, x19, #0xb18
     888:      	movk	w21, #0xedb8, lsl #16
     88c:      	add	x22, sp, #0x10
     890:      	adrp	x20, 0x0 <strtoul@GLIBC_2.17>
     894:      	add	x20, x20, #0xb1d
     898:      	add	x1, sp, #0x10
     89c:      	add	x2, x22, #0x4
     8a0:      	mov	x0, x19
     8a4:      	bl	0x710 <__isoc99_scanf@plt>
     8a8:      	cmp	w0, #0x2
     8ac:      	b.ne	0xad8 <main+0x280>
     8b0:      	ldr	w8, [sp, #0x10]
     8b4:      	ldrb	w9, [sp, #0x14]
     8b8:      	mov	x0, x20
     8bc:      	eor	w8, w9, w8
     8c0:      	orr	w9, w8, #0xfffffffe
     8c4:      	lsr	w8, w8, #1
     8c8:      	add	w9, w9, #0x1
     8cc:      	and	w9, w9, w21
     8d0:      	eor	w9, w9, w8
     8d4:      	orr	w8, w8, #0xfffffffe
     8d8:      	add	w8, w8, #0x1
     8dc:      	lsr	w9, w9, #1
     8e0:      	and	w8, w8, w21
     8e4:      	eor	w8, w9, w8
     8e8:      	orr	w9, w9, #0xfffffffe
     8ec:      	add	w9, w9, #0x1
     8f0:      	lsr	w8, w8, #1
     8f4:      	and	w9, w9, w21
     8f8:      	eor	w9, w9, w8
     8fc:      	orr	w8, w8, #0xfffffffe
     900:      	add	w8, w8, #0x1
     904:      	lsr	w9, w9, #1
     908:      	and	w8, w8, w21
     90c:      	eor	w8, w9, w8
     910:      	orr	w9, w9, #0xfffffffe
     914:      	add	w9, w9, #0x1
     918:      	lsr	w8, w8, #1
     91c:      	and	w9, w9, w21
     920:      	eor	w9, w9, w8
     924:      	orr	w8, w8, #0xfffffffe
     928:      	add	w8, w8, #0x1
     92c:      	lsr	w9, w9, #1
     930:      	and	w8, w8, w21
     934:      	eor	w8, w9, w8
     938:      	orr	w9, w9, #0xfffffffe
     93c:      	lsr	w8, w8, #1
     940:      	add	w9, w9, #0x1
     944:      	and	w9, w9, w21
     948:      	orr	w10, w8, #0xfffffffe
     94c:      	eor	w8, w9, w8
     950:      	add	w10, w10, #0x1
     954:      	and	w9, w10, w21
     958:      	eor	w8, w9, w8, lsr #1
     95c:      	eor	w1, w8, #0xff000000
     960:      	bl	0x720 <printf@plt>
     964:      	b	0x898 <main+0x40>
     968:      	ldr	x0, [x1, #0x8]
     96c:      	mov	x19, x1
     970:      	mov	x1, xzr
     974:      	mov	w2, #0xa                // =10
     978:      	bl	0x6b0 <strtoul@plt>
     97c:      	ldr	x8, [x19, #0x10]
     980:      	mov	x20, x0
     984:      	mov	x1, xzr
     988:      	mov	w2, #0xa                // =10
     98c:      	mov	x0, x8
     990:      	bl	0x6b0 <strtoul@plt>
     994:      	mov	x21, x0
     998:      	add	x1, sp, #0x10
     99c:      	mov	w0, #0x1                // =1
     9a0:      	bl	0x6e0 <clock_gettime@plt>
     9a4:      	cbnz	w0, 0xa94 <main+0x23c>
     9a8:      	mov	x19, xzr
     9ac:      	cbz	x20, 0xa84 <main+0x22c>
     9b0:      	mov	w8, #0x8320             // =33568
     9b4:      	movk	w8, #0xedb8, lsl #16
     9b8:      	eor	w9, w21, w21, lsl #13
     9bc:      	subs	x20, x20, #0x1
     9c0:      	eor	w9, w9, w9, lsr #17
     9c4:      	eor	w9, w9, w9, lsl #5
     9c8:      	eor	w10, w9, w9, lsl #13
     9cc:      	eor	w10, w10, w10, lsr #17
     9d0:      	eor	w21, w10, w10, lsl #5
     9d4:      	and	w10, w21, #0xff
     9d8:      	eor	w9, w10, w9
     9dc:      	orr	w10, w9, #0xfffffffe
     9e0:      	lsr	w9, w9, #1
     9e4:      	add	w10, w10, #0x1
     9e8:      	and	w10, w10, w8
     9ec:      	eor	w10, w10, w9
     9f0:      	orr	w9, w9, #0xfffffffe
     9f4:      	add	w9, w9, #0x1
     9f8:      	lsr	w10, w10, #1
     9fc:      	and	w9, w9, w8
     a00:      	eor	w9, w10, w9
     a04:      	orr	w10, w10, #0xfffffffe
     a08:      	add	w10, w10, #0x1
     a0c:      	lsr	w9, w9, #1
     a10:      	and	w10, w10, w8
     a14:      	eor	w10, w10, w9
     a18:      	orr	w9, w9, #0xfffffffe
     a1c:      	add	w9, w9, #0x1
     a20:      	lsr	w10, w10, #1
     a24:      	and	w9, w9, w8
     a28:      	eor	w9, w10, w9
     a2c:      	orr	w10, w10, #0xfffffffe
     a30:      	add	w10, w10, #0x1
     a34:      	lsr	w9, w9, #1
     a38:      	and	w10, w10, w8
     a3c:      	eor	w10, w10, w9
     a40:      	orr	w9, w9, #0xfffffffe
     a44:      	add	w9, w9, #0x1
     a48:      	lsr	w10, w10, #1
     a4c:      	and	w9, w9, w8
     a50:      	eor	w9, w10, w9
     a54:      	orr	w10, w10, #0xfffffffe
     a58:      	lsr	w9, w9, #1
     a5c:      	add	w10, w10, #0x1
     a60:      	and	w10, w10, w8
     a64:      	orr	w11, w9, #0xfffffffe
     a68:      	eor	w9, w10, w9
     a6c:      	add	w11, w11, #0x1
     a70:      	and	w10, w11, w8
     a74:      	eor	w9, w10, w9, lsr #1
     a78:      	eor	w9, w9, #0xff000000
     a7c:      	add	x19, x19, x9
     a80:      	b.ne	0x9b8 <main+0x160>
     a84:      	mov	x1, sp
     a88:      	mov	w0, #0x1                // =1
     a8c:      	bl	0x6e0 <clock_gettime@plt>
     a90:      	cbz	w0, 0xaa4 <main+0x24c>
     a94:      	mov	w0, #0x2                // =2
     a98:      	b	0xadc <main+0x284>
     a9c:      	mov	w0, #0x3                // =3
     aa0:      	b	0xadc <main+0x284>
     aa4:      	ldp	x8, x9, [sp]
     aa8:      	adrp	x0, 0x0 <strtoul@GLIBC_2.17>
     aac:      	add	x0, x0, #0xb21
     ab0:      	ldp	x10, x11, [sp, #0x10]
     ab4:      	mov	x1, x19
     ab8:      	sub	x8, x8, x10
     abc:      	sub	x9, x9, x11
     ac0:      	scvtf	d0, x8
     ac4:      	scvtf	d1, x9
     ac8:      	adrp	x8, 0x0 <strtoul@GLIBC_2.17>
     acc:      	ldr	d2, [x8, #0xb10]
     ad0:      	fmadd	d0, d1, d2, d0
     ad4:      	bl	0x720 <printf@plt>
     ad8:      	mov	w0, wzr
     adc:      	ldp	x20, x19, [sp, #0x40]
     ae0:      	ldp	x22, x21, [sp, #0x30]
     ae4:      	ldp	x29, x30, [sp, #0x20]
     ae8:      	add	sp, sp, #0x50
     aec:      	ret

Disassembly of section .fini:

0000000000000af0 <_fini>:
     af0:      	nop
     af4:      	stp	x29, x30, [sp, #-0x10]!
     af8:      	mov	x29, sp
     afc:      	ldp	x29, x30, [sp], #0x10
     b00:      	ret
