; ModuleID = '/work/experiments/runs/rich-limbs-matrix-linux-20261109/crc32_byte/build-clang-O1-sanitizers-limbs16/validation/compiler-0-O1/candidate.i'
source_filename = "/work/experiments/runs/rich-limbs-matrix-linux-20261109/crc32_byte/build-clang-O1-sanitizers-limbs16/validation/compiler-0-O1/candidate.i"
target datalayout = "e-m:e-i8:8:32-i16:16:32-i64:64-i128:128-n32:64-S128"
target triple = "aarch64-unknown-linux-gnu"

$asan.module_ctor = comdat any

@llvm.used = appending global [1 x ptr] [ptr @asan.module_ctor], section "llvm.metadata"
@___asan_globals_registered = common hidden global i64 0
@__start_asan_globals = extern_weak hidden global i64
@__stop_asan_globals = extern_weak hidden global i64
@llvm.global_ctors = appending global [1 x { i32, ptr, ptr }] [{ i32, ptr, ptr } { i32 1, ptr @asan.module_ctor, ptr @asan.module_ctor }]

; Function Attrs: mustprogress nofree norecurse nosync nounwind sanitize_address willreturn memory(none) uwtable
define dso_local i32 @kernel(i32 noundef %state, i32 noundef %byte) local_unnamed_addr #0 !func_sanitize !6 {
entry:
  %and = and i32 %state, 65535
  %0 = xor i32 %state, -1
  %and6 = and i32 %byte, 255
  %1 = xor i32 %and, %and6
  %xor8 = xor i32 %1, 65535
  %and10 = and i32 %xor8, 1
  %2 = icmp eq i32 %and10, 0
  %and12 = select i1 %2, i32 0, i32 2098
  %and15 = select i1 %2, i32 0, i32 60856
  %3 = and i32 %0, 65536
  %4 = or disjoint i32 %xor8, %3
  %and21 = lshr i32 %4, 5
  %shr24 = lshr i32 %0, 17
  %xor27 = xor i32 %and12, %and21
  %xor28 = xor i32 %and15, %shr24
  %5 = and i32 %xor8, 2
  %6 = icmp eq i32 %5, 0
  %and34 = select i1 %6, i32 0, i32 4196
  %and37 = select i1 %6, i32 0, i32 60856
  %shl43 = shl nuw nsw i32 %shr24, 12
  %shl43.masked = and i32 %shl43, 4096
  %and45 = or i32 %xor27, %shl43.masked
  %shr48 = lshr i32 %xor28, 1
  %xor51 = xor i32 %and45, %and34
  %xor52 = xor i32 %shr48, %and37
  %7 = and i32 %xor8, 4
  %8 = icmp eq i32 %7, 0
  %and58 = select i1 %8, i32 0, i32 8392
  %and61 = select i1 %8, i32 0, i32 60856
  %shl67 = shl nuw nsw i32 %shr48, 13
  %shl67.masked = and i32 %shl67, 8192
  %and69 = or disjoint i32 %shl67.masked, %xor51
  %shr72 = lshr i32 %xor52, 1
  %xor75 = xor i32 %and69, %and58
  %xor76 = xor i32 %shr72, %and61
  %9 = and i32 %xor8, 8
  %10 = icmp eq i32 %9, 0
  %and82 = select i1 %10, i32 0, i32 16784
  %and85 = select i1 %10, i32 0, i32 60856
  %shl91 = shl nuw nsw i32 %shr72, 14
  %shl91.masked = and i32 %shl91, 16384
  %and93 = or i32 %xor75, %shl91.masked
  %shr96 = lshr i32 %xor76, 1
  %xor99 = xor i32 %and93, %and82
  %xor100 = xor i32 %shr96, %and85
  %11 = and i32 %xor8, 16
  %12 = icmp eq i32 %11, 0
  %and106 = select i1 %12, i32 0, i32 33568
  %and109 = select i1 %12, i32 0, i32 60856
  %shl115 = shl nuw nsw i32 %shr96, 15
  %or116 = or i32 %xor99, %shl115
  %and117 = and i32 %or116, 65532
  %shr120 = lshr i32 %xor100, 1
  %xor123 = xor i32 %and117, %and106
  %xor124 = xor i32 %shr120, %and109
  %13 = and i32 %xor8, 32
  %14 = icmp eq i32 %13, 0
  %and130 = select i1 %14, i32 0, i32 33568
  %and133 = select i1 %14, i32 0, i32 60856
  %shr136 = lshr exact i32 %xor123, 1
  %shl139 = shl nuw nsw i32 %shr120, 15
  %shl139.masked = and i32 %shl139, 32768
  %and141 = or disjoint i32 %shr136, %shl139.masked
  %shr144 = lshr i32 %xor124, 1
  %xor147 = xor i32 %and141, %and130
  %xor148 = xor i32 %shr144, %and133
  %15 = and i32 %xor27, 2
  %16 = icmp eq i32 %15, 0
  %and154 = select i1 %16, i32 0, i32 33568
  %and157 = select i1 %16, i32 0, i32 60856
  %shr160 = lshr exact i32 %xor147, 1
  %shl163 = shl nuw nsw i32 %shr144, 15
  %shl163.masked = and i32 %shl163, 32768
  %and165 = or i32 %shr160, %shl163.masked
  %shr168 = lshr i32 %xor148, 1
  %xor171 = xor i32 %and165, %and154
  %xor172 = xor i32 %shr168, %and157
  %17 = and i32 %xor51, 4
  %18 = icmp eq i32 %17, 0
  %and178 = select i1 %18, i32 0, i32 33568
  %shr184 = lshr i32 %xor171, 1
  %shl187 = shl nuw nsw i32 %shr168, 15
  %or188 = or i32 %shr184, %shl187
  %and189 = and i32 %or188, 65535
  %shr192 = lshr i32 %xor172, 1
  %xor195 = xor i32 %and189, %and178
  %19 = select i1 %18, i32 65535, i32 4679
  %20 = xor i32 %shr192, %19
  %shl201 = shl nuw i32 %20, 16
  %21 = or disjoint i32 %xor195, %shl201
  %or202 = xor i32 %21, 65535
  ret i32 %or202
}

declare void @__asan_register_elf_globals(i64, i64, i64)

declare void @__asan_init()

; Function Attrs: nounwind uwtable
define internal void @asan.module_ctor() #1 comdat {
  call void @__asan_init()
  call void @__asan_version_mismatch_check_v8()
  call void @__asan_register_elf_globals(i64 ptrtoint (ptr @___asan_globals_registered to i64), i64 ptrtoint (ptr @__start_asan_globals to i64), i64 ptrtoint (ptr @__stop_asan_globals to i64))
  ret void
}

declare void @__asan_version_mismatch_check_v8()

attributes #0 = { mustprogress nofree norecurse nosync nounwind sanitize_address willreturn memory(none) uwtable "frame-pointer"="non-leaf" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+fp-armv8,+neon,+outline-atomics,+v8a,-fmv" }
attributes #1 = { nounwind uwtable "frame-pointer"="non-leaf" }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 1, !"wchar_size", i32 4}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 1}
!5 = !{!"Ubuntu clang version 18.1.3 (1ubuntu1)"}
!6 = !{i32 -1056584962, i32 -455559067}
