
/work/experiments/runs/rich-limbs-matrix-linux-20261109/crc32_byte/build-clang-O0-xor-42/program:	file format elf64-littleaarch64

Disassembly of section .init:

0000000000000678 <_init>:
     678:      	nop
     67c:      	stp	x29, x30, [sp, #-0x10]!
     680:      	mov	x29, sp
     684:      	bl	0x774 <call_weak_fn>
     688:      	ldp	x29, x30, [sp], #0x10
     68c:      	ret

Disassembly of section .plt:

0000000000000690 <.plt>:
     690:      	stp	x16, x30, [sp, #-0x10]!
     694:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1df14>
     698:      	ldr	x17, [x16, #0xff8]
     69c:      	add	x16, x16, #0xff8
     6a0:      	br	x17
     6a4:      	nop
     6a8:      	nop
     6ac:      	nop

00000000000006b0 <strtoul@plt>:
     6b0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6b4:      	ldr	x17, [x16]
     6b8:      	add	x16, x16, #0x0
     6bc:      	br	x17

00000000000006c0 <__libc_start_main@plt>:
     6c0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6c4:      	ldr	x17, [x16, #0x8]
     6c8:      	add	x16, x16, #0x8
     6cc:      	br	x17

00000000000006d0 <__cxa_finalize@plt>:
     6d0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6d4:      	ldr	x17, [x16, #0x10]
     6d8:      	add	x16, x16, #0x10
     6dc:      	br	x17

00000000000006e0 <clock_gettime@plt>:
     6e0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6e4:      	ldr	x17, [x16, #0x18]
     6e8:      	add	x16, x16, #0x18
     6ec:      	br	x17

00000000000006f0 <__gmon_start__@plt>:
     6f0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6f4:      	ldr	x17, [x16, #0x20]
     6f8:      	add	x16, x16, #0x20
     6fc:      	br	x17

0000000000000700 <abort@plt>:
     700:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     704:      	ldr	x17, [x16, #0x28]
     708:      	add	x16, x16, #0x28
     70c:      	br	x17

0000000000000710 <__isoc99_scanf@plt>:
     710:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     714:      	ldr	x17, [x16, #0x30]
     718:      	add	x16, x16, #0x30
     71c:      	br	x17

0000000000000720 <printf@plt>:
     720:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     724:      	ldr	x17, [x16, #0x38]
     728:      	add	x16, x16, #0x38
     72c:      	br	x17

Disassembly of section .text:

0000000000000740 <_start>:
     740:      	nop
     744:      	mov	x29, #0x0               // =0
     748:      	mov	x30, #0x0               // =0
     74c:      	mov	x5, x0
     750:      	ldr	x1, [sp]
     754:      	add	x2, sp, #0x8
     758:      	mov	x6, sp
     75c:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1df14>
     760:      	ldr	x0, [x0, #0xfd8]
     764:      	mov	x3, #0x0                // =0
     768:      	mov	x4, #0x0                // =0
     76c:      	bl	0x6c0 <__libc_start_main@plt>
     770:      	bl	0x700 <abort@plt>

0000000000000774 <call_weak_fn>:
     774:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1df14>
     778:      	ldr	x0, [x0, #0xfd0]
     77c:      	cbz	x0, 0x784 <call_weak_fn+0x10>
     780:      	b	0x6f0 <__gmon_start__@plt>
     784:      	ret
     788:      	nop
     78c:      	nop

0000000000000790 <deregister_tm_clones>:
     790:      	adrp	x0, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     794:      	add	x0, x0, #0x50
     798:      	adrp	x1, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     79c:      	add	x1, x1, #0x50
     7a0:      	cmp	x1, x0
     7a4:      	b.eq	0x7bc <deregister_tm_clones+0x2c>
     7a8:      	adrp	x1, 0x1f000 <__FRAME_END__+0x1df14>
     7ac:      	ldr	x1, [x1, #0xfc0]
     7b0:      	cbz	x1, 0x7bc <deregister_tm_clones+0x2c>
     7b4:      	mov	x16, x1
     7b8:      	br	x16
     7bc:      	ret

00000000000007c0 <register_tm_clones>:
     7c0:      	adrp	x0, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     7c4:      	add	x0, x0, #0x50
     7c8:      	adrp	x1, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     7cc:      	add	x1, x1, #0x50
     7d0:      	sub	x1, x1, x0
     7d4:      	lsr	x2, x1, #63
     7d8:      	add	x1, x2, x1, asr #3
     7dc:      	asr	x1, x1, #1
     7e0:      	cbz	x1, 0x7f8 <register_tm_clones+0x38>
     7e4:      	adrp	x2, 0x1f000 <__FRAME_END__+0x1df14>
     7e8:      	ldr	x2, [x2, #0xfe0]
     7ec:      	cbz	x2, 0x7f8 <register_tm_clones+0x38>
     7f0:      	mov	x16, x2
     7f4:      	br	x16
     7f8:      	ret
     7fc:      	nop

0000000000000800 <__do_global_dtors_aux>:
     800:      	paciasp
     804:      	stp	x29, x30, [sp, #-0x20]!
     808:      	mov	x29, sp
     80c:      	str	x19, [sp, #0x10]
     810:      	adrp	x19, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     814:      	ldrb	w0, [x19, #0x50]
     818:      	tbnz	w0, #0x0, 0x840 <__do_global_dtors_aux+0x40>
     81c:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1df14>
     820:      	ldr	x0, [x0, #0xfc8]
     824:      	cbz	x0, 0x834 <__do_global_dtors_aux+0x34>
     828:      	adrp	x0, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     82c:      	ldr	x0, [x0, #0x48]
     830:      	bl	0x6d0 <__cxa_finalize@plt>
     834:      	bl	0x790 <deregister_tm_clones>
     838:      	mov	w0, #0x1                // =1
     83c:      	strb	w0, [x19, #0x50]
     840:      	ldr	x19, [sp, #0x10]
     844:      	ldp	x29, x30, [sp], #0x20
     848:      	autiasp
     84c:      	ret

0000000000000850 <frame_dummy>:
     850:      	bti	c
     854:      	b	0x7c0 <register_tm_clones>

0000000000000858 <kernel>:
     858:      	sub	sp, sp, #0x120
     85c:      	str	x29, [sp, #0x110]
     860:      	mov	w9, #0x621e             // =25118
     864:      	movk	w9, #0x6744, lsl #16
     868:      	mov	w15, #0x621f            // =25119
     86c:      	movk	w15, #0x6744, lsl #16
     870:      	mov	w8, #0x5311             // =21265
     874:      	movk	w8, #0x54e6, lsl #16
     878:      	mov	w11, #0xe13e            // =57662
     87c:      	movk	w11, #0x8afc, lsl #16
     880:      	str	w0, [sp, #0x10c]
     884:      	str	w1, [sp, #0x108]
     888:      	ldr	w10, [sp, #0x10c]
     88c:      	eor	w10, w10, w9
     890:      	str	w10, [sp, #0x104]
     894:      	ldr	w12, [sp, #0x104]
     898:      	mov	w10, #0x9de1            // =40417
     89c:      	movk	w10, #0x98bb, lsl #16
     8a0:      	eor	w12, w12, w10
     8a4:      	eor	w12, w12, w9
     8a8:      	str	w12, [sp, #0x100]
     8ac:      	ldr	w12, [sp, #0x108]
     8b0:      	eor	w12, w12, w9
     8b4:      	str	w12, [sp, #0xfc]
     8b8:      	ldr	w12, [sp, #0xfc]
     8bc:      	mov	w14, #0x62e1            // =25313
     8c0:      	movk	w14, #0x6744, lsl #16
     8c4:      	and	w12, w12, w14
     8c8:      	ldr	w13, [sp, #0xfc]
     8cc:      	eor	w13, w13, w14
     8d0:      	and	w13, w13, w9
     8d4:      	eor	w12, w12, w13
     8d8:      	str	w12, [sp, #0xf8]
     8dc:      	ldr	w12, [sp, #0x100]
     8e0:      	ldr	w13, [sp, #0xf8]
     8e4:      	eor	w12, w12, w13
     8e8:      	eor	w12, w12, w9
     8ec:      	str	w12, [sp, #0xf4]
     8f0:      	ldr	w12, [sp, #0xf4]
     8f4:      	and	w12, w12, w15
     8f8:      	ldr	w13, [sp, #0xf4]
     8fc:      	eor	w13, w13, w15
     900:      	and	w13, w13, w9
     904:      	eor	w12, w12, w13
     908:      	str	w12, [sp, #0xf0]
     90c:      	ldr	w12, [sp, #0xf0]
     910:      	eor	w12, w12, w9
     914:      	str	w12, [sp, #0xec]
     918:      	ldr	w13, [sp, #0xec]
     91c:      	mov	w12, wzr
     920:      	subs	w13, w12, w13
     924:      	str	w13, [sp, #0xe8]
     928:      	ldr	w13, [sp, #0xf4]
     92c:      	eor	w13, w8, w13, lsr #1
     930:      	str	w13, [sp, #0xe4]
     934:      	ldr	w13, [sp, #0xe8]
     938:      	eor	w13, w13, w9
     93c:      	str	w13, [sp, #0xe0]
     940:      	ldr	w13, [sp, #0xe0]
     944:      	and	w13, w11, w13
     948:      	ldr	w14, [sp, #0xe0]
     94c:      	eor	w14, w11, w14
     950:      	and	w14, w14, w9
     954:      	eor	w13, w13, w14
     958:      	str	w13, [sp, #0xdc]
     95c:      	ldr	w13, [sp, #0xe4]
     960:      	ldr	w14, [sp, #0xdc]
     964:      	eor	w13, w13, w14
     968:      	eor	w13, w13, w9
     96c:      	str	w13, [sp, #0xd8]
     970:      	ldr	w13, [sp, #0xd8]
     974:      	and	w13, w13, w15
     978:      	ldr	w14, [sp, #0xd8]
     97c:      	eor	w14, w14, w15
     980:      	and	w14, w14, w9
     984:      	eor	w13, w13, w14
     988:      	str	w13, [sp, #0xd4]
     98c:      	ldr	w13, [sp, #0xd4]
     990:      	eor	w13, w13, w9
     994:      	str	w13, [sp, #0xd0]
     998:      	ldr	w13, [sp, #0xd0]
     99c:      	subs	w13, w12, w13
     9a0:      	str	w13, [sp, #0xcc]
     9a4:      	ldr	w13, [sp, #0xd8]
     9a8:      	eor	w13, w8, w13, lsr #1
     9ac:      	str	w13, [sp, #0xc8]
     9b0:      	ldr	w13, [sp, #0xcc]
     9b4:      	eor	w13, w13, w9
     9b8:      	str	w13, [sp, #0xc4]
     9bc:      	ldr	w13, [sp, #0xc4]
     9c0:      	and	w13, w11, w13
     9c4:      	ldr	w14, [sp, #0xc4]
     9c8:      	eor	w14, w11, w14
     9cc:      	and	w14, w14, w9
     9d0:      	eor	w13, w13, w14
     9d4:      	str	w13, [sp, #0xc0]
     9d8:      	ldr	w13, [sp, #0xc8]
     9dc:      	ldr	w14, [sp, #0xc0]
     9e0:      	eor	w13, w13, w14
     9e4:      	eor	w13, w13, w9
     9e8:      	str	w13, [sp, #0xbc]
     9ec:      	ldr	w13, [sp, #0xbc]
     9f0:      	and	w13, w13, w15
     9f4:      	ldr	w14, [sp, #0xbc]
     9f8:      	eor	w14, w14, w15
     9fc:      	and	w14, w14, w9
     a00:      	eor	w13, w13, w14
     a04:      	str	w13, [sp, #0xb8]
     a08:      	ldr	w13, [sp, #0xb8]
     a0c:      	eor	w13, w13, w9
     a10:      	str	w13, [sp, #0xb4]
     a14:      	ldr	w13, [sp, #0xb4]
     a18:      	subs	w13, w12, w13
     a1c:      	str	w13, [sp, #0xb0]
     a20:      	ldr	w13, [sp, #0xbc]
     a24:      	eor	w13, w8, w13, lsr #1
     a28:      	str	w13, [sp, #0xac]
     a2c:      	ldr	w13, [sp, #0xb0]
     a30:      	eor	w13, w13, w9
     a34:      	str	w13, [sp, #0xa8]
     a38:      	ldr	w13, [sp, #0xa8]
     a3c:      	and	w13, w11, w13
     a40:      	ldr	w14, [sp, #0xa8]
     a44:      	eor	w14, w11, w14
     a48:      	and	w14, w14, w9
     a4c:      	eor	w13, w13, w14
     a50:      	str	w13, [sp, #0xa4]
     a54:      	ldr	w13, [sp, #0xac]
     a58:      	ldr	w14, [sp, #0xa4]
     a5c:      	eor	w13, w13, w14
     a60:      	eor	w13, w13, w9
     a64:      	str	w13, [sp, #0xa0]
     a68:      	ldr	w13, [sp, #0xa0]
     a6c:      	and	w13, w13, w15
     a70:      	ldr	w14, [sp, #0xa0]
     a74:      	eor	w14, w14, w15
     a78:      	and	w14, w14, w9
     a7c:      	eor	w13, w13, w14
     a80:      	str	w13, [sp, #0x9c]
     a84:      	ldr	w13, [sp, #0x9c]
     a88:      	eor	w13, w13, w9
     a8c:      	str	w13, [sp, #0x98]
     a90:      	ldr	w13, [sp, #0x98]
     a94:      	subs	w13, w12, w13
     a98:      	str	w13, [sp, #0x94]
     a9c:      	ldr	w13, [sp, #0xa0]
     aa0:      	eor	w13, w8, w13, lsr #1
     aa4:      	str	w13, [sp, #0x90]
     aa8:      	ldr	w13, [sp, #0x94]
     aac:      	eor	w13, w13, w9
     ab0:      	str	w13, [sp, #0x8c]
     ab4:      	ldr	w13, [sp, #0x8c]
     ab8:      	and	w13, w11, w13
     abc:      	ldr	w14, [sp, #0x8c]
     ac0:      	eor	w14, w11, w14
     ac4:      	and	w14, w14, w9
     ac8:      	eor	w13, w13, w14
     acc:      	str	w13, [sp, #0x88]
     ad0:      	ldr	w13, [sp, #0x90]
     ad4:      	ldr	w14, [sp, #0x88]
     ad8:      	eor	w13, w13, w14
     adc:      	eor	w13, w13, w9
     ae0:      	str	w13, [sp, #0x84]
     ae4:      	ldr	w13, [sp, #0x84]
     ae8:      	and	w13, w13, w15
     aec:      	ldr	w14, [sp, #0x84]
     af0:      	eor	w14, w14, w15
     af4:      	and	w14, w14, w9
     af8:      	eor	w13, w13, w14
     afc:      	str	w13, [sp, #0x80]
     b00:      	ldr	w13, [sp, #0x80]
     b04:      	eor	w13, w13, w9
     b08:      	str	w13, [sp, #0x7c]
     b0c:      	ldr	w13, [sp, #0x7c]
     b10:      	subs	w13, w12, w13
     b14:      	str	w13, [sp, #0x78]
     b18:      	ldr	w13, [sp, #0x84]
     b1c:      	eor	w13, w8, w13, lsr #1
     b20:      	str	w13, [sp, #0x74]
     b24:      	ldr	w13, [sp, #0x78]
     b28:      	eor	w13, w13, w9
     b2c:      	str	w13, [sp, #0x70]
     b30:      	ldr	w13, [sp, #0x70]
     b34:      	and	w13, w11, w13
     b38:      	ldr	w14, [sp, #0x70]
     b3c:      	eor	w14, w11, w14
     b40:      	and	w14, w14, w9
     b44:      	eor	w13, w13, w14
     b48:      	str	w13, [sp, #0x6c]
     b4c:      	ldr	w13, [sp, #0x74]
     b50:      	ldr	w14, [sp, #0x6c]
     b54:      	eor	w13, w13, w14
     b58:      	eor	w13, w13, w9
     b5c:      	str	w13, [sp, #0x68]
     b60:      	ldr	w13, [sp, #0x68]
     b64:      	and	w13, w13, w15
     b68:      	ldr	w14, [sp, #0x68]
     b6c:      	eor	w14, w14, w15
     b70:      	and	w14, w14, w9
     b74:      	eor	w13, w13, w14
     b78:      	str	w13, [sp, #0x64]
     b7c:      	ldr	w13, [sp, #0x64]
     b80:      	eor	w13, w13, w9
     b84:      	str	w13, [sp, #0x60]
     b88:      	ldr	w13, [sp, #0x60]
     b8c:      	subs	w13, w12, w13
     b90:      	str	w13, [sp, #0x5c]
     b94:      	ldr	w13, [sp, #0x68]
     b98:      	eor	w13, w8, w13, lsr #1
     b9c:      	str	w13, [sp, #0x58]
     ba0:      	ldr	w13, [sp, #0x5c]
     ba4:      	eor	w13, w13, w9
     ba8:      	str	w13, [sp, #0x54]
     bac:      	ldr	w13, [sp, #0x54]
     bb0:      	and	w13, w11, w13
     bb4:      	ldr	w14, [sp, #0x54]
     bb8:      	eor	w14, w11, w14
     bbc:      	and	w14, w14, w9
     bc0:      	eor	w13, w13, w14
     bc4:      	str	w13, [sp, #0x50]
     bc8:      	ldr	w13, [sp, #0x58]
     bcc:      	ldr	w14, [sp, #0x50]
     bd0:      	eor	w13, w13, w14
     bd4:      	eor	w13, w13, w9
     bd8:      	str	w13, [sp, #0x4c]
     bdc:      	ldr	w13, [sp, #0x4c]
     be0:      	and	w13, w13, w15
     be4:      	ldr	w14, [sp, #0x4c]
     be8:      	eor	w14, w14, w15
     bec:      	and	w14, w14, w9
     bf0:      	eor	w13, w13, w14
     bf4:      	str	w13, [sp, #0x48]
     bf8:      	ldr	w13, [sp, #0x48]
     bfc:      	eor	w13, w13, w9
     c00:      	str	w13, [sp, #0x44]
     c04:      	ldr	w13, [sp, #0x44]
     c08:      	subs	w13, w12, w13
     c0c:      	str	w13, [sp, #0x40]
     c10:      	ldr	w13, [sp, #0x4c]
     c14:      	eor	w13, w8, w13, lsr #1
     c18:      	str	w13, [sp, #0x3c]
     c1c:      	ldr	w13, [sp, #0x40]
     c20:      	eor	w13, w13, w9
     c24:      	str	w13, [sp, #0x38]
     c28:      	ldr	w13, [sp, #0x38]
     c2c:      	and	w13, w11, w13
     c30:      	ldr	w14, [sp, #0x38]
     c34:      	eor	w14, w11, w14
     c38:      	and	w14, w14, w9
     c3c:      	eor	w13, w13, w14
     c40:      	str	w13, [sp, #0x34]
     c44:      	ldr	w13, [sp, #0x3c]
     c48:      	ldr	w14, [sp, #0x34]
     c4c:      	eor	w13, w13, w14
     c50:      	eor	w13, w13, w9
     c54:      	str	w13, [sp, #0x30]
     c58:      	ldr	w13, [sp, #0x30]
     c5c:      	and	w13, w13, w15
     c60:      	ldr	w14, [sp, #0x30]
     c64:      	eor	w14, w14, w15
     c68:      	and	w14, w14, w9
     c6c:      	eor	w13, w13, w14
     c70:      	str	w13, [sp, #0x2c]
     c74:      	ldr	w13, [sp, #0x2c]
     c78:      	eor	w13, w13, w9
     c7c:      	str	w13, [sp, #0x28]
     c80:      	ldr	w13, [sp, #0x28]
     c84:      	subs	w12, w12, w13
     c88:      	str	w12, [sp, #0x24]
     c8c:      	ldr	w12, [sp, #0x30]
     c90:      	eor	w8, w8, w12, lsr #1
     c94:      	str	w8, [sp, #0x20]
     c98:      	ldr	w8, [sp, #0x24]
     c9c:      	eor	w8, w8, w9
     ca0:      	str	w8, [sp, #0x1c]
     ca4:      	ldr	w8, [sp, #0x1c]
     ca8:      	and	w8, w11, w8
     cac:      	ldr	w12, [sp, #0x1c]
     cb0:      	eor	w11, w11, w12
     cb4:      	and	w11, w11, w9
     cb8:      	eor	w8, w8, w11
     cbc:      	str	w8, [sp, #0x18]
     cc0:      	ldr	w8, [sp, #0x20]
     cc4:      	ldr	w11, [sp, #0x18]
     cc8:      	eor	w8, w8, w11
     ccc:      	eor	w8, w8, w9
     cd0:      	str	w8, [sp, #0x14]
     cd4:      	ldr	w8, [sp, #0x14]
     cd8:      	eor	w8, w8, w10
     cdc:      	eor	w8, w8, w9
     ce0:      	str	w8, [sp, #0x10]
     ce4:      	ldr	w8, [sp, #0x10]
     ce8:      	eor	w8, w8, w9
     cec:      	str	w8, [sp, #0xc]
     cf0:      	ldr	w0, [sp, #0xc]
     cf4:      	ldr	x29, [sp, #0x110]
     cf8:      	add	sp, sp, #0x120
     cfc:      	ret

0000000000000d00 <main>:
     d00:      	sub	sp, sp, #0x90
     d04:      	stp	x29, x30, [sp, #0x80]
     d08:      	add	x29, sp, #0x80
     d0c:      	stur	wzr, [x29, #-0x4]
     d10:      	stur	w0, [x29, #-0x8]
     d14:      	stur	x1, [x29, #-0x10]
     d18:      	ldur	w8, [x29, #-0x8]
     d1c:      	subs	w8, w8, #0x1
     d20:      	b.ne	0xd74 <main+0x74>
     d24:      	b	0xd28 <main+0x28>
     d28:      	b	0xd2c <main+0x2c>
     d2c:      	sub	x1, x29, #0x18
     d30:      	add	x2, x1, #0x4
     d34:      	adrp	x0, 0x0 <strtoul@GLIBC_2.17>
     d38:      	add	x0, x0, #0xf80
     d3c:      	bl	0x710 <__isoc99_scanf@plt>
     d40:      	subs	w8, w0, #0x2
     d44:      	b.ne	0xd6c <main+0x6c>
     d48:      	b	0xd4c <main+0x4c>
     d4c:      	ldur	w0, [x29, #-0x18]
     d50:      	ldur	w1, [x29, #-0x14]
     d54:      	bl	0x858 <kernel>
     d58:      	mov	w1, w0
     d5c:      	adrp	x0, 0x0 <strtoul@GLIBC_2.17>
     d60:      	add	x0, x0, #0xf85
     d64:      	bl	0x720 <printf@plt>
     d68:      	b	0xd2c <main+0x2c>
     d6c:      	stur	wzr, [x29, #-0x4]
     d70:      	b	0xee8 <main+0x1e8>
     d74:      	ldur	w8, [x29, #-0x8]
     d78:      	subs	w8, w8, #0x3
     d7c:      	b.eq	0xd90 <main+0x90>
     d80:      	b	0xd84 <main+0x84>
     d84:      	mov	w8, #0x3                // =3
     d88:      	stur	w8, [x29, #-0x4]
     d8c:      	b	0xee8 <main+0x1e8>
     d90:      	ldur	x8, [x29, #-0x10]
     d94:      	ldr	x0, [x8, #0x8]
     d98:      	mov	x1, xzr
     d9c:      	str	x1, [sp, #0x8]
     da0:      	mov	w2, #0xa                // =10
     da4:      	str	w2, [sp, #0x14]
     da8:      	bl	0x6b0 <strtoul@plt>
     dac:      	ldr	x1, [sp, #0x8]
     db0:      	ldr	w2, [sp, #0x14]
     db4:      	stur	x0, [x29, #-0x20]
     db8:      	ldur	x8, [x29, #-0x10]
     dbc:      	ldr	x0, [x8, #0x10]
     dc0:      	bl	0x6b0 <strtoul@plt>
     dc4:      	mov	w8, w0
     dc8:      	stur	w8, [x29, #-0x24]
     dcc:      	stur	xzr, [x29, #-0x30]
     dd0:      	mov	w0, #0x1                // =1
     dd4:      	add	x1, sp, #0x40
     dd8:      	bl	0x6e0 <clock_gettime@plt>
     ddc:      	cbz	w0, 0xdf0 <main+0xf0>
     de0:      	b	0xde4 <main+0xe4>
     de4:      	mov	w8, #0x2                // =2
     de8:      	stur	w8, [x29, #-0x4]
     dec:      	b	0xee8 <main+0x1e8>
     df0:      	str	xzr, [sp, #0x28]
     df4:      	b	0xdf8 <main+0xf8>
     df8:      	ldr	x8, [sp, #0x28]
     dfc:      	ldur	x9, [x29, #-0x20]
     e00:      	subs	x8, x8, x9
     e04:      	b.hs	0xe7c <main+0x17c>
     e08:      	b	0xe0c <main+0x10c>
     e0c:      	str	wzr, [sp, #0x24]
     e10:      	b	0xe14 <main+0x114>
     e14:      	ldr	w8, [sp, #0x24]
     e18:      	subs	w8, w8, #0x2
     e1c:      	b.hs	0xe50 <main+0x150>
     e20:      	b	0xe24 <main+0x124>
     e24:      	sub	x0, x29, #0x24
     e28:      	bl	0xef8 <csrd_matrix_next_value>
     e2c:      	ldr	w8, [sp, #0x24]
     e30:      	mov	w9, w8
     e34:      	sub	x8, x29, #0x18
     e38:      	str	w0, [x8, x9, lsl #2]
     e3c:      	b	0xe40 <main+0x140>
     e40:      	ldr	w8, [sp, #0x24]
     e44:      	add	w8, w8, #0x1
     e48:      	str	w8, [sp, #0x24]
     e4c:      	b	0xe14 <main+0x114>
     e50:      	ldur	w0, [x29, #-0x18]
     e54:      	ldur	w1, [x29, #-0x14]
     e58:      	bl	0x858 <kernel>
     e5c:      	ldur	x8, [x29, #-0x30]
     e60:      	add	x8, x8, w0, uxtw
     e64:      	stur	x8, [x29, #-0x30]
     e68:      	b	0xe6c <main+0x16c>
     e6c:      	ldr	x8, [sp, #0x28]
     e70:      	add	x8, x8, #0x1
     e74:      	str	x8, [sp, #0x28]
     e78:      	b	0xdf8 <main+0xf8>
     e7c:      	mov	w0, #0x1                // =1
     e80:      	add	x1, sp, #0x30
     e84:      	bl	0x6e0 <clock_gettime@plt>
     e88:      	cbz	w0, 0xe9c <main+0x19c>
     e8c:      	b	0xe90 <main+0x190>
     e90:      	mov	w8, #0x2                // =2
     e94:      	stur	w8, [x29, #-0x4]
     e98:      	b	0xee8 <main+0x1e8>
     e9c:      	ldr	x8, [sp, #0x30]
     ea0:      	ldr	x9, [sp, #0x40]
     ea4:      	subs	x8, x8, x9
     ea8:      	scvtf	d2, x8
     eac:      	ldr	x8, [sp, #0x38]
     eb0:      	ldr	x9, [sp, #0x48]
     eb4:      	subs	x8, x8, x9
     eb8:      	scvtf	d0, x8
     ebc:      	adrp	x8, 0x0 <strtoul@GLIBC_2.17>
     ec0:      	ldr	d1, [x8, #0xf78]
     ec4:      	fmadd	d0, d0, d1, d2
     ec8:      	str	d0, [sp, #0x18]
     ecc:      	ldr	d0, [sp, #0x18]
     ed0:      	ldur	x1, [x29, #-0x30]
     ed4:      	adrp	x0, 0x0 <strtoul@GLIBC_2.17>
     ed8:      	add	x0, x0, #0xf89
     edc:      	bl	0x720 <printf@plt>
     ee0:      	stur	wzr, [x29, #-0x4]
     ee4:      	b	0xee8 <main+0x1e8>
     ee8:      	ldur	w0, [x29, #-0x4]
     eec:      	ldp	x29, x30, [sp, #0x80]
     ef0:      	add	sp, sp, #0x90
     ef4:      	ret

0000000000000ef8 <csrd_matrix_next_value>:
     ef8:      	sub	sp, sp, #0x10
     efc:      	str	x0, [sp, #0x8]
     f00:      	ldr	x8, [sp, #0x8]
     f04:      	ldr	w10, [x8]
     f08:      	ldr	x9, [sp, #0x8]
     f0c:      	ldr	w8, [x9]
     f10:      	eor	w8, w8, w10, lsl #13
     f14:      	str	w8, [x9]
     f18:      	ldr	x8, [sp, #0x8]
     f1c:      	ldr	w10, [x8]
     f20:      	ldr	x9, [sp, #0x8]
     f24:      	ldr	w8, [x9]
     f28:      	eor	w8, w8, w10, lsr #17
     f2c:      	str	w8, [x9]
     f30:      	ldr	x8, [sp, #0x8]
     f34:      	ldr	w10, [x8]
     f38:      	ldr	x9, [sp, #0x8]
     f3c:      	ldr	w8, [x9]
     f40:      	eor	w8, w8, w10, lsl #5
     f44:      	str	w8, [x9]
     f48:      	ldr	x8, [sp, #0x8]
     f4c:      	ldr	w0, [x8]
     f50:      	add	sp, sp, #0x10
     f54:      	ret

Disassembly of section .fini:

0000000000000f58 <_fini>:
     f58:      	nop
     f5c:      	stp	x29, x30, [sp, #-0x10]!
     f60:      	mov	x29, sp
     f64:      	ldp	x29, x30, [sp], #0x10
     f68:      	ret
