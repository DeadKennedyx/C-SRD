; ModuleID = '/work/experiments/runs/rich-limbs-matrix-linux-20261109/crc32_byte/build-clang-O0-xor-42/validation/compiler-0-O0/candidate.i'
source_filename = "/work/experiments/runs/rich-limbs-matrix-linux-20261109/crc32_byte/build-clang-O0-xor-42/validation/compiler-0-O0/candidate.i"
target datalayout = "e-m:e-i8:8:32-i16:16:32-i64:64-i128:128-n32:64-S128"
target triple = "aarch64-unknown-linux-gnu"

; Function Attrs: noinline nounwind optnone uwtable
define dso_local i32 @kernel(i32 noundef %0, i32 noundef %1) #0 {
  %3 = alloca i32, align 4
  %4 = alloca i32, align 4
  %5 = alloca i32, align 4
  %6 = alloca i32, align 4
  %7 = alloca i32, align 4
  %8 = alloca i32, align 4
  %9 = alloca i32, align 4
  %10 = alloca i32, align 4
  %11 = alloca i32, align 4
  %12 = alloca i32, align 4
  %13 = alloca i32, align 4
  %14 = alloca i32, align 4
  %15 = alloca i32, align 4
  %16 = alloca i32, align 4
  %17 = alloca i32, align 4
  %18 = alloca i32, align 4
  %19 = alloca i32, align 4
  %20 = alloca i32, align 4
  %21 = alloca i32, align 4
  %22 = alloca i32, align 4
  %23 = alloca i32, align 4
  %24 = alloca i32, align 4
  %25 = alloca i32, align 4
  %26 = alloca i32, align 4
  %27 = alloca i32, align 4
  %28 = alloca i32, align 4
  %29 = alloca i32, align 4
  %30 = alloca i32, align 4
  %31 = alloca i32, align 4
  %32 = alloca i32, align 4
  %33 = alloca i32, align 4
  %34 = alloca i32, align 4
  %35 = alloca i32, align 4
  %36 = alloca i32, align 4
  %37 = alloca i32, align 4
  %38 = alloca i32, align 4
  %39 = alloca i32, align 4
  %40 = alloca i32, align 4
  %41 = alloca i32, align 4
  %42 = alloca i32, align 4
  %43 = alloca i32, align 4
  %44 = alloca i32, align 4
  %45 = alloca i32, align 4
  %46 = alloca i32, align 4
  %47 = alloca i32, align 4
  %48 = alloca i32, align 4
  %49 = alloca i32, align 4
  %50 = alloca i32, align 4
  %51 = alloca i32, align 4
  %52 = alloca i32, align 4
  %53 = alloca i32, align 4
  %54 = alloca i32, align 4
  %55 = alloca i32, align 4
  %56 = alloca i32, align 4
  %57 = alloca i32, align 4
  %58 = alloca i32, align 4
  %59 = alloca i32, align 4
  %60 = alloca i32, align 4
  %61 = alloca i32, align 4
  %62 = alloca i32, align 4
  %63 = alloca i32, align 4
  %64 = alloca i32, align 4
  %65 = alloca i32, align 4
  %66 = alloca i32, align 4
  %67 = alloca i32, align 4
  store i32 %0, ptr %3, align 4
  store i32 %1, ptr %4, align 4
  %68 = load i32, ptr %3, align 4
  %69 = xor i32 %68, 1732534814
  store i32 %69, ptr %5, align 4
  %70 = load i32, ptr %5, align 4
  %71 = xor i32 %70, -1732534815
  %72 = xor i32 %71, 1732534814
  store i32 %72, ptr %6, align 4
  %73 = load i32, ptr %4, align 4
  %74 = xor i32 %73, 1732534814
  store i32 %74, ptr %7, align 4
  %75 = load i32, ptr %7, align 4
  %76 = and i32 %75, 1732535009
  %77 = load i32, ptr %7, align 4
  %78 = xor i32 %77, 1732535009
  %79 = and i32 %78, 1732534814
  %80 = xor i32 %76, %79
  store i32 %80, ptr %8, align 4
  %81 = load i32, ptr %6, align 4
  %82 = load i32, ptr %8, align 4
  %83 = xor i32 %81, %82
  %84 = xor i32 %83, 1732534814
  store i32 %84, ptr %9, align 4
  %85 = load i32, ptr %9, align 4
  %86 = and i32 %85, 1732534815
  %87 = load i32, ptr %9, align 4
  %88 = xor i32 %87, 1732534815
  %89 = and i32 %88, 1732534814
  %90 = xor i32 %86, %89
  store i32 %90, ptr %10, align 4
  %91 = load i32, ptr %10, align 4
  %92 = xor i32 %91, 1732534814
  store i32 %92, ptr %11, align 4
  %93 = load i32, ptr %11, align 4
  %94 = sub i32 0, %93
  store i32 %94, ptr %12, align 4
  %95 = load i32, ptr %9, align 4
  %96 = lshr i32 %95, 1
  %97 = xor i32 %96, 1424380689
  store i32 %97, ptr %13, align 4
  %98 = load i32, ptr %12, align 4
  %99 = xor i32 %98, 1732534814
  store i32 %99, ptr %14, align 4
  %100 = load i32, ptr %14, align 4
  %101 = and i32 -1963138754, %100
  %102 = load i32, ptr %14, align 4
  %103 = xor i32 -1963138754, %102
  %104 = and i32 %103, 1732534814
  %105 = xor i32 %101, %104
  store i32 %105, ptr %15, align 4
  %106 = load i32, ptr %13, align 4
  %107 = load i32, ptr %15, align 4
  %108 = xor i32 %106, %107
  %109 = xor i32 %108, 1732534814
  store i32 %109, ptr %16, align 4
  %110 = load i32, ptr %16, align 4
  %111 = and i32 %110, 1732534815
  %112 = load i32, ptr %16, align 4
  %113 = xor i32 %112, 1732534815
  %114 = and i32 %113, 1732534814
  %115 = xor i32 %111, %114
  store i32 %115, ptr %17, align 4
  %116 = load i32, ptr %17, align 4
  %117 = xor i32 %116, 1732534814
  store i32 %117, ptr %18, align 4
  %118 = load i32, ptr %18, align 4
  %119 = sub i32 0, %118
  store i32 %119, ptr %19, align 4
  %120 = load i32, ptr %16, align 4
  %121 = lshr i32 %120, 1
  %122 = xor i32 %121, 1424380689
  store i32 %122, ptr %20, align 4
  %123 = load i32, ptr %19, align 4
  %124 = xor i32 %123, 1732534814
  store i32 %124, ptr %21, align 4
  %125 = load i32, ptr %21, align 4
  %126 = and i32 -1963138754, %125
  %127 = load i32, ptr %21, align 4
  %128 = xor i32 -1963138754, %127
  %129 = and i32 %128, 1732534814
  %130 = xor i32 %126, %129
  store i32 %130, ptr %22, align 4
  %131 = load i32, ptr %20, align 4
  %132 = load i32, ptr %22, align 4
  %133 = xor i32 %131, %132
  %134 = xor i32 %133, 1732534814
  store i32 %134, ptr %23, align 4
  %135 = load i32, ptr %23, align 4
  %136 = and i32 %135, 1732534815
  %137 = load i32, ptr %23, align 4
  %138 = xor i32 %137, 1732534815
  %139 = and i32 %138, 1732534814
  %140 = xor i32 %136, %139
  store i32 %140, ptr %24, align 4
  %141 = load i32, ptr %24, align 4
  %142 = xor i32 %141, 1732534814
  store i32 %142, ptr %25, align 4
  %143 = load i32, ptr %25, align 4
  %144 = sub i32 0, %143
  store i32 %144, ptr %26, align 4
  %145 = load i32, ptr %23, align 4
  %146 = lshr i32 %145, 1
  %147 = xor i32 %146, 1424380689
  store i32 %147, ptr %27, align 4
  %148 = load i32, ptr %26, align 4
  %149 = xor i32 %148, 1732534814
  store i32 %149, ptr %28, align 4
  %150 = load i32, ptr %28, align 4
  %151 = and i32 -1963138754, %150
  %152 = load i32, ptr %28, align 4
  %153 = xor i32 -1963138754, %152
  %154 = and i32 %153, 1732534814
  %155 = xor i32 %151, %154
  store i32 %155, ptr %29, align 4
  %156 = load i32, ptr %27, align 4
  %157 = load i32, ptr %29, align 4
  %158 = xor i32 %156, %157
  %159 = xor i32 %158, 1732534814
  store i32 %159, ptr %30, align 4
  %160 = load i32, ptr %30, align 4
  %161 = and i32 %160, 1732534815
  %162 = load i32, ptr %30, align 4
  %163 = xor i32 %162, 1732534815
  %164 = and i32 %163, 1732534814
  %165 = xor i32 %161, %164
  store i32 %165, ptr %31, align 4
  %166 = load i32, ptr %31, align 4
  %167 = xor i32 %166, 1732534814
  store i32 %167, ptr %32, align 4
  %168 = load i32, ptr %32, align 4
  %169 = sub i32 0, %168
  store i32 %169, ptr %33, align 4
  %170 = load i32, ptr %30, align 4
  %171 = lshr i32 %170, 1
  %172 = xor i32 %171, 1424380689
  store i32 %172, ptr %34, align 4
  %173 = load i32, ptr %33, align 4
  %174 = xor i32 %173, 1732534814
  store i32 %174, ptr %35, align 4
  %175 = load i32, ptr %35, align 4
  %176 = and i32 -1963138754, %175
  %177 = load i32, ptr %35, align 4
  %178 = xor i32 -1963138754, %177
  %179 = and i32 %178, 1732534814
  %180 = xor i32 %176, %179
  store i32 %180, ptr %36, align 4
  %181 = load i32, ptr %34, align 4
  %182 = load i32, ptr %36, align 4
  %183 = xor i32 %181, %182
  %184 = xor i32 %183, 1732534814
  store i32 %184, ptr %37, align 4
  %185 = load i32, ptr %37, align 4
  %186 = and i32 %185, 1732534815
  %187 = load i32, ptr %37, align 4
  %188 = xor i32 %187, 1732534815
  %189 = and i32 %188, 1732534814
  %190 = xor i32 %186, %189
  store i32 %190, ptr %38, align 4
  %191 = load i32, ptr %38, align 4
  %192 = xor i32 %191, 1732534814
  store i32 %192, ptr %39, align 4
  %193 = load i32, ptr %39, align 4
  %194 = sub i32 0, %193
  store i32 %194, ptr %40, align 4
  %195 = load i32, ptr %37, align 4
  %196 = lshr i32 %195, 1
  %197 = xor i32 %196, 1424380689
  store i32 %197, ptr %41, align 4
  %198 = load i32, ptr %40, align 4
  %199 = xor i32 %198, 1732534814
  store i32 %199, ptr %42, align 4
  %200 = load i32, ptr %42, align 4
  %201 = and i32 -1963138754, %200
  %202 = load i32, ptr %42, align 4
  %203 = xor i32 -1963138754, %202
  %204 = and i32 %203, 1732534814
  %205 = xor i32 %201, %204
  store i32 %205, ptr %43, align 4
  %206 = load i32, ptr %41, align 4
  %207 = load i32, ptr %43, align 4
  %208 = xor i32 %206, %207
  %209 = xor i32 %208, 1732534814
  store i32 %209, ptr %44, align 4
  %210 = load i32, ptr %44, align 4
  %211 = and i32 %210, 1732534815
  %212 = load i32, ptr %44, align 4
  %213 = xor i32 %212, 1732534815
  %214 = and i32 %213, 1732534814
  %215 = xor i32 %211, %214
  store i32 %215, ptr %45, align 4
  %216 = load i32, ptr %45, align 4
  %217 = xor i32 %216, 1732534814
  store i32 %217, ptr %46, align 4
  %218 = load i32, ptr %46, align 4
  %219 = sub i32 0, %218
  store i32 %219, ptr %47, align 4
  %220 = load i32, ptr %44, align 4
  %221 = lshr i32 %220, 1
  %222 = xor i32 %221, 1424380689
  store i32 %222, ptr %48, align 4
  %223 = load i32, ptr %47, align 4
  %224 = xor i32 %223, 1732534814
  store i32 %224, ptr %49, align 4
  %225 = load i32, ptr %49, align 4
  %226 = and i32 -1963138754, %225
  %227 = load i32, ptr %49, align 4
  %228 = xor i32 -1963138754, %227
  %229 = and i32 %228, 1732534814
  %230 = xor i32 %226, %229
  store i32 %230, ptr %50, align 4
  %231 = load i32, ptr %48, align 4
  %232 = load i32, ptr %50, align 4
  %233 = xor i32 %231, %232
  %234 = xor i32 %233, 1732534814
  store i32 %234, ptr %51, align 4
  %235 = load i32, ptr %51, align 4
  %236 = and i32 %235, 1732534815
  %237 = load i32, ptr %51, align 4
  %238 = xor i32 %237, 1732534815
  %239 = and i32 %238, 1732534814
  %240 = xor i32 %236, %239
  store i32 %240, ptr %52, align 4
  %241 = load i32, ptr %52, align 4
  %242 = xor i32 %241, 1732534814
  store i32 %242, ptr %53, align 4
  %243 = load i32, ptr %53, align 4
  %244 = sub i32 0, %243
  store i32 %244, ptr %54, align 4
  %245 = load i32, ptr %51, align 4
  %246 = lshr i32 %245, 1
  %247 = xor i32 %246, 1424380689
  store i32 %247, ptr %55, align 4
  %248 = load i32, ptr %54, align 4
  %249 = xor i32 %248, 1732534814
  store i32 %249, ptr %56, align 4
  %250 = load i32, ptr %56, align 4
  %251 = and i32 -1963138754, %250
  %252 = load i32, ptr %56, align 4
  %253 = xor i32 -1963138754, %252
  %254 = and i32 %253, 1732534814
  %255 = xor i32 %251, %254
  store i32 %255, ptr %57, align 4
  %256 = load i32, ptr %55, align 4
  %257 = load i32, ptr %57, align 4
  %258 = xor i32 %256, %257
  %259 = xor i32 %258, 1732534814
  store i32 %259, ptr %58, align 4
  %260 = load i32, ptr %58, align 4
  %261 = and i32 %260, 1732534815
  %262 = load i32, ptr %58, align 4
  %263 = xor i32 %262, 1732534815
  %264 = and i32 %263, 1732534814
  %265 = xor i32 %261, %264
  store i32 %265, ptr %59, align 4
  %266 = load i32, ptr %59, align 4
  %267 = xor i32 %266, 1732534814
  store i32 %267, ptr %60, align 4
  %268 = load i32, ptr %60, align 4
  %269 = sub i32 0, %268
  store i32 %269, ptr %61, align 4
  %270 = load i32, ptr %58, align 4
  %271 = lshr i32 %270, 1
  %272 = xor i32 %271, 1424380689
  store i32 %272, ptr %62, align 4
  %273 = load i32, ptr %61, align 4
  %274 = xor i32 %273, 1732534814
  store i32 %274, ptr %63, align 4
  %275 = load i32, ptr %63, align 4
  %276 = and i32 -1963138754, %275
  %277 = load i32, ptr %63, align 4
  %278 = xor i32 -1963138754, %277
  %279 = and i32 %278, 1732534814
  %280 = xor i32 %276, %279
  store i32 %280, ptr %64, align 4
  %281 = load i32, ptr %62, align 4
  %282 = load i32, ptr %64, align 4
  %283 = xor i32 %281, %282
  %284 = xor i32 %283, 1732534814
  store i32 %284, ptr %65, align 4
  %285 = load i32, ptr %65, align 4
  %286 = xor i32 %285, -1732534815
  %287 = xor i32 %286, 1732534814
  store i32 %287, ptr %66, align 4
  %288 = load i32, ptr %66, align 4
  %289 = xor i32 %288, 1732534814
  store i32 %289, ptr %67, align 4
  %290 = load i32, ptr %67, align 4
  ret i32 %290
}

attributes #0 = { noinline nounwind optnone uwtable "frame-pointer"="non-leaf" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+fp-armv8,+neon,+outline-atomics,+v8a,-fmv" }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 1, !"wchar_size", i32 4}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 1}
!5 = !{!"Ubuntu clang version 18.1.3 (1ubuntu1)"}
