; ModuleID = '/work/experiments/runs/rich-limbs-matrix-linux-20261109/crc32_byte/build-clang-O0-affine-42/validation/compiler-0-O0/candidate.i'
source_filename = "/work/experiments/runs/rich-limbs-matrix-linux-20261109/crc32_byte/build-clang-O0-affine-42/validation/compiler-0-O0/candidate.i"
target datalayout = "e-m:e-i8:8:32-i16:16:32-i64:64-i128:128-n32:64-S128"
target triple = "aarch64-unknown-linux-gnu"

; Function Attrs: noinline nounwind optnone uwtable
define dso_local i32 @kernel(i32 noundef %0, i32 noundef %1) #0 {
  %3 = alloca i32, align 4
  %4 = alloca i32, align 4
  %5 = alloca i32, align 4
  %6 = alloca i32, align 4
  %7 = alloca i32, align 4
  %8 = alloca i32, align 4
  %9 = alloca i32, align 4
  %10 = alloca i32, align 4
  %11 = alloca i32, align 4
  %12 = alloca i32, align 4
  %13 = alloca i32, align 4
  %14 = alloca i32, align 4
  %15 = alloca i32, align 4
  %16 = alloca i32, align 4
  %17 = alloca i32, align 4
  %18 = alloca i32, align 4
  %19 = alloca i32, align 4
  %20 = alloca i32, align 4
  %21 = alloca i32, align 4
  %22 = alloca i32, align 4
  %23 = alloca i32, align 4
  %24 = alloca i32, align 4
  %25 = alloca i32, align 4
  %26 = alloca i32, align 4
  %27 = alloca i32, align 4
  %28 = alloca i32, align 4
  %29 = alloca i32, align 4
  %30 = alloca i32, align 4
  %31 = alloca i32, align 4
  %32 = alloca i32, align 4
  %33 = alloca i32, align 4
  %34 = alloca i32, align 4
  %35 = alloca i32, align 4
  %36 = alloca i32, align 4
  %37 = alloca i32, align 4
  %38 = alloca i32, align 4
  %39 = alloca i32, align 4
  %40 = alloca i32, align 4
  %41 = alloca i32, align 4
  %42 = alloca i32, align 4
  %43 = alloca i32, align 4
  %44 = alloca i32, align 4
  %45 = alloca i32, align 4
  %46 = alloca i32, align 4
  %47 = alloca i32, align 4
  %48 = alloca i32, align 4
  %49 = alloca i32, align 4
  %50 = alloca i32, align 4
  %51 = alloca i32, align 4
  %52 = alloca i32, align 4
  %53 = alloca i32, align 4
  %54 = alloca i32, align 4
  %55 = alloca i32, align 4
  %56 = alloca i32, align 4
  %57 = alloca i32, align 4
  %58 = alloca i32, align 4
  %59 = alloca i32, align 4
  %60 = alloca i32, align 4
  %61 = alloca i32, align 4
  %62 = alloca i32, align 4
  %63 = alloca i32, align 4
  %64 = alloca i32, align 4
  store i32 %0, ptr %3, align 4
  store i32 %1, ptr %4, align 4
  %65 = load i32, ptr %3, align 4
  %66 = xor i32 %65, -1
  store i32 %66, ptr %5, align 4
  %67 = load i32, ptr %4, align 4
  %68 = and i32 %67, 255
  store i32 %68, ptr %6, align 4
  %69 = load i32, ptr %5, align 4
  %70 = load i32, ptr %6, align 4
  %71 = xor i32 %69, %70
  store i32 %71, ptr %7, align 4
  %72 = load i32, ptr %7, align 4
  %73 = and i32 %72, 1
  store i32 %73, ptr %8, align 4
  %74 = load i32, ptr %8, align 4
  %75 = mul i32 2010586713, %74
  %76 = add i32 %75, 278101063
  store i32 %76, ptr %9, align 4
  %77 = load i32, ptr %9, align 4
  %78 = sub i32 278101063, %77
  %79 = add i32 %78, 278101063
  store i32 %79, ptr %10, align 4
  %80 = load i32, ptr %7, align 4
  %81 = lshr i32 %80, 1
  store i32 %81, ptr %11, align 4
  %82 = load i32, ptr %10, align 4
  %83 = sub i32 %82, 278101063
  %84 = mul i32 -1673639447, %83
  store i32 %84, ptr %12, align 4
  %85 = load i32, ptr %12, align 4
  %86 = and i32 -306674912, %85
  store i32 %86, ptr %13, align 4
  %87 = load i32, ptr %11, align 4
  %88 = load i32, ptr %13, align 4
  %89 = xor i32 %87, %88
  store i32 %89, ptr %14, align 4
  %90 = load i32, ptr %14, align 4
  %91 = and i32 %90, 1
  store i32 %91, ptr %15, align 4
  %92 = load i32, ptr %15, align 4
  %93 = mul i32 2010586713, %92
  %94 = add i32 %93, 278101063
  store i32 %94, ptr %16, align 4
  %95 = load i32, ptr %16, align 4
  %96 = sub i32 278101063, %95
  %97 = add i32 %96, 278101063
  store i32 %97, ptr %17, align 4
  %98 = load i32, ptr %14, align 4
  %99 = lshr i32 %98, 1
  store i32 %99, ptr %18, align 4
  %100 = load i32, ptr %17, align 4
  %101 = sub i32 %100, 278101063
  %102 = mul i32 -1673639447, %101
  store i32 %102, ptr %19, align 4
  %103 = load i32, ptr %19, align 4
  %104 = and i32 -306674912, %103
  store i32 %104, ptr %20, align 4
  %105 = load i32, ptr %18, align 4
  %106 = load i32, ptr %20, align 4
  %107 = xor i32 %105, %106
  store i32 %107, ptr %21, align 4
  %108 = load i32, ptr %21, align 4
  %109 = and i32 %108, 1
  store i32 %109, ptr %22, align 4
  %110 = load i32, ptr %22, align 4
  %111 = mul i32 2010586713, %110
  %112 = add i32 %111, 278101063
  store i32 %112, ptr %23, align 4
  %113 = load i32, ptr %23, align 4
  %114 = sub i32 278101063, %113
  %115 = add i32 %114, 278101063
  store i32 %115, ptr %24, align 4
  %116 = load i32, ptr %21, align 4
  %117 = lshr i32 %116, 1
  store i32 %117, ptr %25, align 4
  %118 = load i32, ptr %24, align 4
  %119 = sub i32 %118, 278101063
  %120 = mul i32 -1673639447, %119
  store i32 %120, ptr %26, align 4
  %121 = load i32, ptr %26, align 4
  %122 = and i32 -306674912, %121
  store i32 %122, ptr %27, align 4
  %123 = load i32, ptr %25, align 4
  %124 = load i32, ptr %27, align 4
  %125 = xor i32 %123, %124
  store i32 %125, ptr %28, align 4
  %126 = load i32, ptr %28, align 4
  %127 = and i32 %126, 1
  store i32 %127, ptr %29, align 4
  %128 = load i32, ptr %29, align 4
  %129 = mul i32 2010586713, %128
  %130 = add i32 %129, 278101063
  store i32 %130, ptr %30, align 4
  %131 = load i32, ptr %30, align 4
  %132 = sub i32 278101063, %131
  %133 = add i32 %132, 278101063
  store i32 %133, ptr %31, align 4
  %134 = load i32, ptr %28, align 4
  %135 = lshr i32 %134, 1
  store i32 %135, ptr %32, align 4
  %136 = load i32, ptr %31, align 4
  %137 = sub i32 %136, 278101063
  %138 = mul i32 -1673639447, %137
  store i32 %138, ptr %33, align 4
  %139 = load i32, ptr %33, align 4
  %140 = and i32 -306674912, %139
  store i32 %140, ptr %34, align 4
  %141 = load i32, ptr %32, align 4
  %142 = load i32, ptr %34, align 4
  %143 = xor i32 %141, %142
  store i32 %143, ptr %35, align 4
  %144 = load i32, ptr %35, align 4
  %145 = and i32 %144, 1
  store i32 %145, ptr %36, align 4
  %146 = load i32, ptr %36, align 4
  %147 = mul i32 2010586713, %146
  %148 = add i32 %147, 278101063
  store i32 %148, ptr %37, align 4
  %149 = load i32, ptr %37, align 4
  %150 = sub i32 278101063, %149
  %151 = add i32 %150, 278101063
  store i32 %151, ptr %38, align 4
  %152 = load i32, ptr %35, align 4
  %153 = lshr i32 %152, 1
  store i32 %153, ptr %39, align 4
  %154 = load i32, ptr %38, align 4
  %155 = sub i32 %154, 278101063
  %156 = mul i32 -1673639447, %155
  store i32 %156, ptr %40, align 4
  %157 = load i32, ptr %40, align 4
  %158 = and i32 -306674912, %157
  store i32 %158, ptr %41, align 4
  %159 = load i32, ptr %39, align 4
  %160 = load i32, ptr %41, align 4
  %161 = xor i32 %159, %160
  store i32 %161, ptr %42, align 4
  %162 = load i32, ptr %42, align 4
  %163 = and i32 %162, 1
  store i32 %163, ptr %43, align 4
  %164 = load i32, ptr %43, align 4
  %165 = mul i32 2010586713, %164
  %166 = add i32 %165, 278101063
  store i32 %166, ptr %44, align 4
  %167 = load i32, ptr %44, align 4
  %168 = sub i32 278101063, %167
  %169 = add i32 %168, 278101063
  store i32 %169, ptr %45, align 4
  %170 = load i32, ptr %42, align 4
  %171 = lshr i32 %170, 1
  store i32 %171, ptr %46, align 4
  %172 = load i32, ptr %45, align 4
  %173 = sub i32 %172, 278101063
  %174 = mul i32 -1673639447, %173
  store i32 %174, ptr %47, align 4
  %175 = load i32, ptr %47, align 4
  %176 = and i32 -306674912, %175
  store i32 %176, ptr %48, align 4
  %177 = load i32, ptr %46, align 4
  %178 = load i32, ptr %48, align 4
  %179 = xor i32 %177, %178
  store i32 %179, ptr %49, align 4
  %180 = load i32, ptr %49, align 4
  %181 = and i32 %180, 1
  store i32 %181, ptr %50, align 4
  %182 = load i32, ptr %50, align 4
  %183 = mul i32 2010586713, %182
  %184 = add i32 %183, 278101063
  store i32 %184, ptr %51, align 4
  %185 = load i32, ptr %51, align 4
  %186 = sub i32 278101063, %185
  %187 = add i32 %186, 278101063
  store i32 %187, ptr %52, align 4
  %188 = load i32, ptr %49, align 4
  %189 = lshr i32 %188, 1
  store i32 %189, ptr %53, align 4
  %190 = load i32, ptr %52, align 4
  %191 = sub i32 %190, 278101063
  %192 = mul i32 -1673639447, %191
  store i32 %192, ptr %54, align 4
  %193 = load i32, ptr %54, align 4
  %194 = and i32 -306674912, %193
  store i32 %194, ptr %55, align 4
  %195 = load i32, ptr %53, align 4
  %196 = load i32, ptr %55, align 4
  %197 = xor i32 %195, %196
  store i32 %197, ptr %56, align 4
  %198 = load i32, ptr %56, align 4
  %199 = and i32 %198, 1
  store i32 %199, ptr %57, align 4
  %200 = load i32, ptr %57, align 4
  %201 = mul i32 2010586713, %200
  %202 = add i32 %201, 278101063
  store i32 %202, ptr %58, align 4
  %203 = load i32, ptr %58, align 4
  %204 = sub i32 278101063, %203
  %205 = add i32 %204, 278101063
  store i32 %205, ptr %59, align 4
  %206 = load i32, ptr %56, align 4
  %207 = lshr i32 %206, 1
  store i32 %207, ptr %60, align 4
  %208 = load i32, ptr %59, align 4
  %209 = sub i32 %208, 278101063
  %210 = mul i32 -1673639447, %209
  store i32 %210, ptr %61, align 4
  %211 = load i32, ptr %61, align 4
  %212 = and i32 -306674912, %211
  store i32 %212, ptr %62, align 4
  %213 = load i32, ptr %60, align 4
  %214 = load i32, ptr %62, align 4
  %215 = xor i32 %213, %214
  store i32 %215, ptr %63, align 4
  %216 = load i32, ptr %63, align 4
  %217 = xor i32 %216, -1
  store i32 %217, ptr %64, align 4
  %218 = load i32, ptr %64, align 4
  ret i32 %218
}

attributes #0 = { noinline nounwind optnone uwtable "frame-pointer"="non-leaf" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+fp-armv8,+neon,+outline-atomics,+v8a,-fmv" }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 1, !"wchar_size", i32 4}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 1}
!5 = !{!"Ubuntu clang version 18.1.3 (1ubuntu1)"}
