
/work/experiments/runs/rich-limbs-matrix-linux-20261109/crc32_byte/build-clang-O0-affine-42/program:	file format elf64-littleaarch64

Disassembly of section .init:

0000000000000678 <_init>:
     678:      	nop
     67c:      	stp	x29, x30, [sp, #-0x10]!
     680:      	mov	x29, sp
     684:      	bl	0x774 <call_weak_fn>
     688:      	ldp	x29, x30, [sp], #0x10
     68c:      	ret

Disassembly of section .plt:

0000000000000690 <.plt>:
     690:      	stp	x16, x30, [sp, #-0x10]!
     694:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e02c>
     698:      	ldr	x17, [x16, #0xff8]
     69c:      	add	x16, x16, #0xff8
     6a0:      	br	x17
     6a4:      	nop
     6a8:      	nop
     6ac:      	nop

00000000000006b0 <strtoul@plt>:
     6b0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6b4:      	ldr	x17, [x16]
     6b8:      	add	x16, x16, #0x0
     6bc:      	br	x17

00000000000006c0 <__libc_start_main@plt>:
     6c0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6c4:      	ldr	x17, [x16, #0x8]
     6c8:      	add	x16, x16, #0x8
     6cc:      	br	x17

00000000000006d0 <__cxa_finalize@plt>:
     6d0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6d4:      	ldr	x17, [x16, #0x10]
     6d8:      	add	x16, x16, #0x10
     6dc:      	br	x17

00000000000006e0 <clock_gettime@plt>:
     6e0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6e4:      	ldr	x17, [x16, #0x18]
     6e8:      	add	x16, x16, #0x18
     6ec:      	br	x17

00000000000006f0 <__gmon_start__@plt>:
     6f0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6f4:      	ldr	x17, [x16, #0x20]
     6f8:      	add	x16, x16, #0x20
     6fc:      	br	x17

0000000000000700 <abort@plt>:
     700:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     704:      	ldr	x17, [x16, #0x28]
     708:      	add	x16, x16, #0x28
     70c:      	br	x17

0000000000000710 <__isoc99_scanf@plt>:
     710:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     714:      	ldr	x17, [x16, #0x30]
     718:      	add	x16, x16, #0x30
     71c:      	br	x17

0000000000000720 <printf@plt>:
     720:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     724:      	ldr	x17, [x16, #0x38]
     728:      	add	x16, x16, #0x38
     72c:      	br	x17

Disassembly of section .text:

0000000000000740 <_start>:
     740:      	nop
     744:      	mov	x29, #0x0               // =0
     748:      	mov	x30, #0x0               // =0
     74c:      	mov	x5, x0
     750:      	ldr	x1, [sp]
     754:      	add	x2, sp, #0x8
     758:      	mov	x6, sp
     75c:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e02c>
     760:      	ldr	x0, [x0, #0xfd8]
     764:      	mov	x3, #0x0                // =0
     768:      	mov	x4, #0x0                // =0
     76c:      	bl	0x6c0 <__libc_start_main@plt>
     770:      	bl	0x700 <abort@plt>

0000000000000774 <call_weak_fn>:
     774:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e02c>
     778:      	ldr	x0, [x0, #0xfd0]
     77c:      	cbz	x0, 0x784 <call_weak_fn+0x10>
     780:      	b	0x6f0 <__gmon_start__@plt>
     784:      	ret
     788:      	nop
     78c:      	nop

0000000000000790 <deregister_tm_clones>:
     790:      	adrp	x0, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     794:      	add	x0, x0, #0x50
     798:      	adrp	x1, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     79c:      	add	x1, x1, #0x50
     7a0:      	cmp	x1, x0
     7a4:      	b.eq	0x7bc <deregister_tm_clones+0x2c>
     7a8:      	adrp	x1, 0x1f000 <__FRAME_END__+0x1e02c>
     7ac:      	ldr	x1, [x1, #0xfc0]
     7b0:      	cbz	x1, 0x7bc <deregister_tm_clones+0x2c>
     7b4:      	mov	x16, x1
     7b8:      	br	x16
     7bc:      	ret

00000000000007c0 <register_tm_clones>:
     7c0:      	adrp	x0, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     7c4:      	add	x0, x0, #0x50
     7c8:      	adrp	x1, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     7cc:      	add	x1, x1, #0x50
     7d0:      	sub	x1, x1, x0
     7d4:      	lsr	x2, x1, #63
     7d8:      	add	x1, x2, x1, asr #3
     7dc:      	asr	x1, x1, #1
     7e0:      	cbz	x1, 0x7f8 <register_tm_clones+0x38>
     7e4:      	adrp	x2, 0x1f000 <__FRAME_END__+0x1e02c>
     7e8:      	ldr	x2, [x2, #0xfe0]
     7ec:      	cbz	x2, 0x7f8 <register_tm_clones+0x38>
     7f0:      	mov	x16, x2
     7f4:      	br	x16
     7f8:      	ret
     7fc:      	nop

0000000000000800 <__do_global_dtors_aux>:
     800:      	paciasp
     804:      	stp	x29, x30, [sp, #-0x20]!
     808:      	mov	x29, sp
     80c:      	str	x19, [sp, #0x10]
     810:      	adrp	x19, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     814:      	ldrb	w0, [x19, #0x50]
     818:      	tbnz	w0, #0x0, 0x840 <__do_global_dtors_aux+0x40>
     81c:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e02c>
     820:      	ldr	x0, [x0, #0xfc8]
     824:      	cbz	x0, 0x834 <__do_global_dtors_aux+0x34>
     828:      	adrp	x0, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     82c:      	ldr	x0, [x0, #0x48]
     830:      	bl	0x6d0 <__cxa_finalize@plt>
     834:      	bl	0x790 <deregister_tm_clones>
     838:      	mov	w0, #0x1                // =1
     83c:      	strb	w0, [x19, #0x50]
     840:      	ldr	x19, [sp, #0x10]
     844:      	ldp	x29, x30, [sp], #0x20
     848:      	autiasp
     84c:      	ret

0000000000000850 <frame_dummy>:
     850:      	bti	c
     854:      	b	0x7c0 <register_tm_clones>

0000000000000858 <kernel>:
     858:      	sub	sp, sp, #0x110
     85c:      	str	x29, [sp, #0x100]
     860:      	mov	w10, #0x1e59            // =7769
     864:      	movk	w10, #0x77d7, lsl #16
     868:      	mov	w11, #0x7c47            // =31815
     86c:      	movk	w11, #0x1093, lsl #16
     870:      	mov	w9, #0x49e9             // =18921
     874:      	movk	w9, #0x9c3e, lsl #16
     878:      	mov	w8, #0x8320             // =33568
     87c:      	movk	w8, #0xedb8, lsl #16
     880:      	str	w0, [sp, #0xfc]
     884:      	str	w1, [sp, #0xf8]
     888:      	ldr	w12, [sp, #0xfc]
     88c:      	mvn	w12, w12
     890:      	str	w12, [sp, #0xf4]
     894:      	ldrb	w12, [sp, #0xf8]
     898:      	str	w12, [sp, #0xf0]
     89c:      	ldr	w12, [sp, #0xf4]
     8a0:      	ldr	w13, [sp, #0xf0]
     8a4:      	eor	w12, w12, w13
     8a8:      	str	w12, [sp, #0xec]
     8ac:      	ldr	w12, [sp, #0xec]
     8b0:      	and	w12, w12, #0x1
     8b4:      	str	w12, [sp, #0xe8]
     8b8:      	ldr	w12, [sp, #0xe8]
     8bc:      	mul	w12, w10, w12
     8c0:      	add	w12, w12, w11
     8c4:      	str	w12, [sp, #0xe4]
     8c8:      	ldr	w12, [sp, #0xe4]
     8cc:      	subs	w12, w11, w12
     8d0:      	add	w12, w12, w11
     8d4:      	str	w12, [sp, #0xe0]
     8d8:      	ldr	w12, [sp, #0xec]
     8dc:      	lsr	w12, w12, #1
     8e0:      	str	w12, [sp, #0xdc]
     8e4:      	ldr	w12, [sp, #0xe0]
     8e8:      	subs	w12, w12, w11
     8ec:      	mul	w12, w9, w12
     8f0:      	str	w12, [sp, #0xd8]
     8f4:      	ldr	w12, [sp, #0xd8]
     8f8:      	and	w12, w8, w12
     8fc:      	str	w12, [sp, #0xd4]
     900:      	ldr	w12, [sp, #0xdc]
     904:      	ldr	w13, [sp, #0xd4]
     908:      	eor	w12, w12, w13
     90c:      	str	w12, [sp, #0xd0]
     910:      	ldr	w12, [sp, #0xd0]
     914:      	and	w12, w12, #0x1
     918:      	str	w12, [sp, #0xcc]
     91c:      	ldr	w12, [sp, #0xcc]
     920:      	mul	w12, w10, w12
     924:      	add	w12, w12, w11
     928:      	str	w12, [sp, #0xc8]
     92c:      	ldr	w12, [sp, #0xc8]
     930:      	subs	w12, w11, w12
     934:      	add	w12, w12, w11
     938:      	str	w12, [sp, #0xc4]
     93c:      	ldr	w12, [sp, #0xd0]
     940:      	lsr	w12, w12, #1
     944:      	str	w12, [sp, #0xc0]
     948:      	ldr	w12, [sp, #0xc4]
     94c:      	subs	w12, w12, w11
     950:      	mul	w12, w9, w12
     954:      	str	w12, [sp, #0xbc]
     958:      	ldr	w12, [sp, #0xbc]
     95c:      	and	w12, w8, w12
     960:      	str	w12, [sp, #0xb8]
     964:      	ldr	w12, [sp, #0xc0]
     968:      	ldr	w13, [sp, #0xb8]
     96c:      	eor	w12, w12, w13
     970:      	str	w12, [sp, #0xb4]
     974:      	ldr	w12, [sp, #0xb4]
     978:      	and	w12, w12, #0x1
     97c:      	str	w12, [sp, #0xb0]
     980:      	ldr	w12, [sp, #0xb0]
     984:      	mul	w12, w10, w12
     988:      	add	w12, w12, w11
     98c:      	str	w12, [sp, #0xac]
     990:      	ldr	w12, [sp, #0xac]
     994:      	subs	w12, w11, w12
     998:      	add	w12, w12, w11
     99c:      	str	w12, [sp, #0xa8]
     9a0:      	ldr	w12, [sp, #0xb4]
     9a4:      	lsr	w12, w12, #1
     9a8:      	str	w12, [sp, #0xa4]
     9ac:      	ldr	w12, [sp, #0xa8]
     9b0:      	subs	w12, w12, w11
     9b4:      	mul	w12, w9, w12
     9b8:      	str	w12, [sp, #0xa0]
     9bc:      	ldr	w12, [sp, #0xa0]
     9c0:      	and	w12, w8, w12
     9c4:      	str	w12, [sp, #0x9c]
     9c8:      	ldr	w12, [sp, #0xa4]
     9cc:      	ldr	w13, [sp, #0x9c]
     9d0:      	eor	w12, w12, w13
     9d4:      	str	w12, [sp, #0x98]
     9d8:      	ldr	w12, [sp, #0x98]
     9dc:      	and	w12, w12, #0x1
     9e0:      	str	w12, [sp, #0x94]
     9e4:      	ldr	w12, [sp, #0x94]
     9e8:      	mul	w12, w10, w12
     9ec:      	add	w12, w12, w11
     9f0:      	str	w12, [sp, #0x90]
     9f4:      	ldr	w12, [sp, #0x90]
     9f8:      	subs	w12, w11, w12
     9fc:      	add	w12, w12, w11
     a00:      	str	w12, [sp, #0x8c]
     a04:      	ldr	w12, [sp, #0x98]
     a08:      	lsr	w12, w12, #1
     a0c:      	str	w12, [sp, #0x88]
     a10:      	ldr	w12, [sp, #0x8c]
     a14:      	subs	w12, w12, w11
     a18:      	mul	w12, w9, w12
     a1c:      	str	w12, [sp, #0x84]
     a20:      	ldr	w12, [sp, #0x84]
     a24:      	and	w12, w8, w12
     a28:      	str	w12, [sp, #0x80]
     a2c:      	ldr	w12, [sp, #0x88]
     a30:      	ldr	w13, [sp, #0x80]
     a34:      	eor	w12, w12, w13
     a38:      	str	w12, [sp, #0x7c]
     a3c:      	ldr	w12, [sp, #0x7c]
     a40:      	and	w12, w12, #0x1
     a44:      	str	w12, [sp, #0x78]
     a48:      	ldr	w12, [sp, #0x78]
     a4c:      	mul	w12, w10, w12
     a50:      	add	w12, w12, w11
     a54:      	str	w12, [sp, #0x74]
     a58:      	ldr	w12, [sp, #0x74]
     a5c:      	subs	w12, w11, w12
     a60:      	add	w12, w12, w11
     a64:      	str	w12, [sp, #0x70]
     a68:      	ldr	w12, [sp, #0x7c]
     a6c:      	lsr	w12, w12, #1
     a70:      	str	w12, [sp, #0x6c]
     a74:      	ldr	w12, [sp, #0x70]
     a78:      	subs	w12, w12, w11
     a7c:      	mul	w12, w9, w12
     a80:      	str	w12, [sp, #0x68]
     a84:      	ldr	w12, [sp, #0x68]
     a88:      	and	w12, w8, w12
     a8c:      	str	w12, [sp, #0x64]
     a90:      	ldr	w12, [sp, #0x6c]
     a94:      	ldr	w13, [sp, #0x64]
     a98:      	eor	w12, w12, w13
     a9c:      	str	w12, [sp, #0x60]
     aa0:      	ldr	w12, [sp, #0x60]
     aa4:      	and	w12, w12, #0x1
     aa8:      	str	w12, [sp, #0x5c]
     aac:      	ldr	w12, [sp, #0x5c]
     ab0:      	mul	w12, w10, w12
     ab4:      	add	w12, w12, w11
     ab8:      	str	w12, [sp, #0x58]
     abc:      	ldr	w12, [sp, #0x58]
     ac0:      	subs	w12, w11, w12
     ac4:      	add	w12, w12, w11
     ac8:      	str	w12, [sp, #0x54]
     acc:      	ldr	w12, [sp, #0x60]
     ad0:      	lsr	w12, w12, #1
     ad4:      	str	w12, [sp, #0x50]
     ad8:      	ldr	w12, [sp, #0x54]
     adc:      	subs	w12, w12, w11
     ae0:      	mul	w12, w9, w12
     ae4:      	str	w12, [sp, #0x4c]
     ae8:      	ldr	w12, [sp, #0x4c]
     aec:      	and	w12, w8, w12
     af0:      	str	w12, [sp, #0x48]
     af4:      	ldr	w12, [sp, #0x50]
     af8:      	ldr	w13, [sp, #0x48]
     afc:      	eor	w12, w12, w13
     b00:      	str	w12, [sp, #0x44]
     b04:      	ldr	w12, [sp, #0x44]
     b08:      	and	w12, w12, #0x1
     b0c:      	str	w12, [sp, #0x40]
     b10:      	ldr	w12, [sp, #0x40]
     b14:      	mul	w12, w10, w12
     b18:      	add	w12, w12, w11
     b1c:      	str	w12, [sp, #0x3c]
     b20:      	ldr	w12, [sp, #0x3c]
     b24:      	subs	w12, w11, w12
     b28:      	add	w12, w12, w11
     b2c:      	str	w12, [sp, #0x38]
     b30:      	ldr	w12, [sp, #0x44]
     b34:      	lsr	w12, w12, #1
     b38:      	str	w12, [sp, #0x34]
     b3c:      	ldr	w12, [sp, #0x38]
     b40:      	subs	w12, w12, w11
     b44:      	mul	w12, w9, w12
     b48:      	str	w12, [sp, #0x30]
     b4c:      	ldr	w12, [sp, #0x30]
     b50:      	and	w12, w8, w12
     b54:      	str	w12, [sp, #0x2c]
     b58:      	ldr	w12, [sp, #0x34]
     b5c:      	ldr	w13, [sp, #0x2c]
     b60:      	eor	w12, w12, w13
     b64:      	str	w12, [sp, #0x28]
     b68:      	ldr	w12, [sp, #0x28]
     b6c:      	and	w12, w12, #0x1
     b70:      	str	w12, [sp, #0x24]
     b74:      	ldr	w12, [sp, #0x24]
     b78:      	mul	w10, w10, w12
     b7c:      	add	w10, w10, w11
     b80:      	str	w10, [sp, #0x20]
     b84:      	ldr	w10, [sp, #0x20]
     b88:      	subs	w10, w11, w10
     b8c:      	add	w10, w10, w11
     b90:      	str	w10, [sp, #0x1c]
     b94:      	ldr	w10, [sp, #0x28]
     b98:      	lsr	w10, w10, #1
     b9c:      	str	w10, [sp, #0x18]
     ba0:      	ldr	w10, [sp, #0x1c]
     ba4:      	subs	w10, w10, w11
     ba8:      	mul	w9, w9, w10
     bac:      	str	w9, [sp, #0x14]
     bb0:      	ldr	w9, [sp, #0x14]
     bb4:      	and	w8, w8, w9
     bb8:      	str	w8, [sp, #0x10]
     bbc:      	ldr	w8, [sp, #0x18]
     bc0:      	ldr	w9, [sp, #0x10]
     bc4:      	eor	w8, w8, w9
     bc8:      	str	w8, [sp, #0xc]
     bcc:      	ldr	w8, [sp, #0xc]
     bd0:      	mvn	w8, w8
     bd4:      	str	w8, [sp, #0x8]
     bd8:      	ldr	w0, [sp, #0x8]
     bdc:      	ldr	x29, [sp, #0x100]
     be0:      	add	sp, sp, #0x110
     be4:      	ret

0000000000000be8 <main>:
     be8:      	sub	sp, sp, #0x90
     bec:      	stp	x29, x30, [sp, #0x80]
     bf0:      	add	x29, sp, #0x80
     bf4:      	stur	wzr, [x29, #-0x4]
     bf8:      	stur	w0, [x29, #-0x8]
     bfc:      	stur	x1, [x29, #-0x10]
     c00:      	ldur	w8, [x29, #-0x8]
     c04:      	subs	w8, w8, #0x1
     c08:      	b.ne	0xc5c <main+0x74>
     c0c:      	b	0xc10 <main+0x28>
     c10:      	b	0xc14 <main+0x2c>
     c14:      	sub	x1, x29, #0x18
     c18:      	add	x2, x1, #0x4
     c1c:      	adrp	x0, 0x0 <strtoul@GLIBC_2.17>
     c20:      	add	x0, x0, #0xe68
     c24:      	bl	0x710 <__isoc99_scanf@plt>
     c28:      	subs	w8, w0, #0x2
     c2c:      	b.ne	0xc54 <main+0x6c>
     c30:      	b	0xc34 <main+0x4c>
     c34:      	ldur	w0, [x29, #-0x18]
     c38:      	ldur	w1, [x29, #-0x14]
     c3c:      	bl	0x858 <kernel>
     c40:      	mov	w1, w0
     c44:      	adrp	x0, 0x0 <strtoul@GLIBC_2.17>
     c48:      	add	x0, x0, #0xe6d
     c4c:      	bl	0x720 <printf@plt>
     c50:      	b	0xc14 <main+0x2c>
     c54:      	stur	wzr, [x29, #-0x4]
     c58:      	b	0xdd0 <main+0x1e8>
     c5c:      	ldur	w8, [x29, #-0x8]
     c60:      	subs	w8, w8, #0x3
     c64:      	b.eq	0xc78 <main+0x90>
     c68:      	b	0xc6c <main+0x84>
     c6c:      	mov	w8, #0x3                // =3
     c70:      	stur	w8, [x29, #-0x4]
     c74:      	b	0xdd0 <main+0x1e8>
     c78:      	ldur	x8, [x29, #-0x10]
     c7c:      	ldr	x0, [x8, #0x8]
     c80:      	mov	x1, xzr
     c84:      	str	x1, [sp, #0x8]
     c88:      	mov	w2, #0xa                // =10
     c8c:      	str	w2, [sp, #0x14]
     c90:      	bl	0x6b0 <strtoul@plt>
     c94:      	ldr	x1, [sp, #0x8]
     c98:      	ldr	w2, [sp, #0x14]
     c9c:      	stur	x0, [x29, #-0x20]
     ca0:      	ldur	x8, [x29, #-0x10]
     ca4:      	ldr	x0, [x8, #0x10]
     ca8:      	bl	0x6b0 <strtoul@plt>
     cac:      	mov	w8, w0
     cb0:      	stur	w8, [x29, #-0x24]
     cb4:      	stur	xzr, [x29, #-0x30]
     cb8:      	mov	w0, #0x1                // =1
     cbc:      	add	x1, sp, #0x40
     cc0:      	bl	0x6e0 <clock_gettime@plt>
     cc4:      	cbz	w0, 0xcd8 <main+0xf0>
     cc8:      	b	0xccc <main+0xe4>
     ccc:      	mov	w8, #0x2                // =2
     cd0:      	stur	w8, [x29, #-0x4]
     cd4:      	b	0xdd0 <main+0x1e8>
     cd8:      	str	xzr, [sp, #0x28]
     cdc:      	b	0xce0 <main+0xf8>
     ce0:      	ldr	x8, [sp, #0x28]
     ce4:      	ldur	x9, [x29, #-0x20]
     ce8:      	subs	x8, x8, x9
     cec:      	b.hs	0xd64 <main+0x17c>
     cf0:      	b	0xcf4 <main+0x10c>
     cf4:      	str	wzr, [sp, #0x24]
     cf8:      	b	0xcfc <main+0x114>
     cfc:      	ldr	w8, [sp, #0x24]
     d00:      	subs	w8, w8, #0x2
     d04:      	b.hs	0xd38 <main+0x150>
     d08:      	b	0xd0c <main+0x124>
     d0c:      	sub	x0, x29, #0x24
     d10:      	bl	0xde0 <csrd_matrix_next_value>
     d14:      	ldr	w8, [sp, #0x24]
     d18:      	mov	w9, w8
     d1c:      	sub	x8, x29, #0x18
     d20:      	str	w0, [x8, x9, lsl #2]
     d24:      	b	0xd28 <main+0x140>
     d28:      	ldr	w8, [sp, #0x24]
     d2c:      	add	w8, w8, #0x1
     d30:      	str	w8, [sp, #0x24]
     d34:      	b	0xcfc <main+0x114>
     d38:      	ldur	w0, [x29, #-0x18]
     d3c:      	ldur	w1, [x29, #-0x14]
     d40:      	bl	0x858 <kernel>
     d44:      	ldur	x8, [x29, #-0x30]
     d48:      	add	x8, x8, w0, uxtw
     d4c:      	stur	x8, [x29, #-0x30]
     d50:      	b	0xd54 <main+0x16c>
     d54:      	ldr	x8, [sp, #0x28]
     d58:      	add	x8, x8, #0x1
     d5c:      	str	x8, [sp, #0x28]
     d60:      	b	0xce0 <main+0xf8>
     d64:      	mov	w0, #0x1                // =1
     d68:      	add	x1, sp, #0x30
     d6c:      	bl	0x6e0 <clock_gettime@plt>
     d70:      	cbz	w0, 0xd84 <main+0x19c>
     d74:      	b	0xd78 <main+0x190>
     d78:      	mov	w8, #0x2                // =2
     d7c:      	stur	w8, [x29, #-0x4]
     d80:      	b	0xdd0 <main+0x1e8>
     d84:      	ldr	x8, [sp, #0x30]
     d88:      	ldr	x9, [sp, #0x40]
     d8c:      	subs	x8, x8, x9
     d90:      	scvtf	d2, x8
     d94:      	ldr	x8, [sp, #0x38]
     d98:      	ldr	x9, [sp, #0x48]
     d9c:      	subs	x8, x8, x9
     da0:      	scvtf	d0, x8
     da4:      	adrp	x8, 0x0 <strtoul@GLIBC_2.17>
     da8:      	ldr	d1, [x8, #0xe60]
     dac:      	fmadd	d0, d0, d1, d2
     db0:      	str	d0, [sp, #0x18]
     db4:      	ldr	d0, [sp, #0x18]
     db8:      	ldur	x1, [x29, #-0x30]
     dbc:      	adrp	x0, 0x0 <strtoul@GLIBC_2.17>
     dc0:      	add	x0, x0, #0xe71
     dc4:      	bl	0x720 <printf@plt>
     dc8:      	stur	wzr, [x29, #-0x4]
     dcc:      	b	0xdd0 <main+0x1e8>
     dd0:      	ldur	w0, [x29, #-0x4]
     dd4:      	ldp	x29, x30, [sp, #0x80]
     dd8:      	add	sp, sp, #0x90
     ddc:      	ret

0000000000000de0 <csrd_matrix_next_value>:
     de0:      	sub	sp, sp, #0x10
     de4:      	str	x0, [sp, #0x8]
     de8:      	ldr	x8, [sp, #0x8]
     dec:      	ldr	w10, [x8]
     df0:      	ldr	x9, [sp, #0x8]
     df4:      	ldr	w8, [x9]
     df8:      	eor	w8, w8, w10, lsl #13
     dfc:      	str	w8, [x9]
     e00:      	ldr	x8, [sp, #0x8]
     e04:      	ldr	w10, [x8]
     e08:      	ldr	x9, [sp, #0x8]
     e0c:      	ldr	w8, [x9]
     e10:      	eor	w8, w8, w10, lsr #17
     e14:      	str	w8, [x9]
     e18:      	ldr	x8, [sp, #0x8]
     e1c:      	ldr	w10, [x8]
     e20:      	ldr	x9, [sp, #0x8]
     e24:      	ldr	w8, [x9]
     e28:      	eor	w8, w8, w10, lsl #5
     e2c:      	str	w8, [x9]
     e30:      	ldr	x8, [sp, #0x8]
     e34:      	ldr	w0, [x8]
     e38:      	add	sp, sp, #0x10
     e3c:      	ret

Disassembly of section .fini:

0000000000000e40 <_fini>:
     e40:      	nop
     e44:      	stp	x29, x30, [sp, #-0x10]!
     e48:      	mov	x29, sp
     e4c:      	ldp	x29, x30, [sp], #0x10
     e50:      	ret
