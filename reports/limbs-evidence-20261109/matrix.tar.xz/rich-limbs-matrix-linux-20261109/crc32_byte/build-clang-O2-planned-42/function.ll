; ModuleID = '/work/experiments/runs/rich-limbs-matrix-linux-20261109/crc32_byte/build-clang-O2-planned-42/validation/compiler-0-O2/candidate.i'
source_filename = "/work/experiments/runs/rich-limbs-matrix-linux-20261109/crc32_byte/build-clang-O2-planned-42/validation/compiler-0-O2/candidate.i"
target datalayout = "e-m:e-i8:8:32-i16:16:32-i64:64-i128:128-n32:64-S128"
target triple = "aarch64-unknown-linux-gnu"

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local i32 @kernel(i32 noundef %0, i32 noundef %1) local_unnamed_addr #0 {
  %3 = and i32 %1, 255
  %4 = xor i32 %3, %0
  %5 = or i32 %4, -2
  %6 = add nsw i32 %5, 1
  %7 = lshr i32 %4, 1
  %8 = and i32 %6, -306674912
  %9 = xor i32 %8, %7
  %10 = or i32 %7, -2
  %11 = add nsw i32 %10, 1
  %12 = lshr i32 %9, 1
  %13 = and i32 %11, -306674912
  %14 = xor i32 %12, %13
  %15 = or i32 %12, -2
  %16 = add nsw i32 %15, 1
  %17 = lshr i32 %14, 1
  %18 = and i32 %16, -306674912
  %19 = xor i32 %18, %17
  %20 = or i32 %17, -2
  %21 = add nsw i32 %20, 1
  %22 = lshr i32 %19, 1
  %23 = and i32 %21, -306674912
  %24 = xor i32 %22, %23
  %25 = or i32 %22, -2
  %26 = add nsw i32 %25, 1
  %27 = lshr i32 %24, 1
  %28 = and i32 %26, -306674912
  %29 = xor i32 %28, %27
  %30 = or i32 %27, -2
  %31 = add nsw i32 %30, 1
  %32 = lshr i32 %29, 1
  %33 = and i32 %31, -306674912
  %34 = xor i32 %32, %33
  %35 = or i32 %32, -2
  %36 = add nsw i32 %35, 1
  %37 = lshr i32 %34, 1
  %38 = and i32 %36, -306674912
  %39 = xor i32 %38, %37
  %40 = or i32 %37, -2
  %41 = add nsw i32 %40, 1
  %42 = lshr i32 %39, 1
  %43 = and i32 %41, -306674912
  %44 = xor i32 %43, %42
  %45 = xor i32 %44, -16777216
  ret i32 %45
}

attributes #0 = { mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable "frame-pointer"="non-leaf" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+fp-armv8,+neon,+outline-atomics,+v8a,-fmv" }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 1, !"wchar_size", i32 4}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 1}
!5 = !{!"Ubuntu clang version 18.1.3 (1ubuntu1)"}
