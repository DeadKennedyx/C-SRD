; ModuleID = '/work/experiments/runs/rich-limbs-matrix-linux-20261109/crc32_byte/build-clang-O3-thinlto-affine-42/validation/compiler-0-O3/candidate.i'
source_filename = "/work/experiments/runs/rich-limbs-matrix-linux-20261109/crc32_byte/build-clang-O3-thinlto-affine-42/validation/compiler-0-O3/candidate.i"
target datalayout = "e-m:e-i8:8:32-i16:16:32-i64:64-i128:128-n32:64-S128"
target triple = "aarch64-unknown-linux-gnu"

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local i32 @kernel(i32 noundef %0, i32 noundef %1) local_unnamed_addr #0 {
  %3 = and i32 %1, 255
  %4 = xor i32 %3, %0
  %5 = xor i32 %4, -1
  %6 = lshr i32 %5, 6
  %7 = and i32 %5, 1
  %8 = icmp eq i32 %7, 0
  %9 = select i1 %8, i32 0, i32 124634137
  %10 = and i32 %5, 2
  %11 = icmp eq i32 %10, 0
  %12 = select i1 %11, i32 0, i32 249268274
  %13 = and i32 %5, 4
  %14 = icmp eq i32 %13, 0
  %15 = select i1 %14, i32 0, i32 498536548
  %16 = and i32 %5, 8
  %17 = icmp eq i32 %16, 0
  %18 = select i1 %17, i32 0, i32 997073096
  %19 = and i32 %5, 16
  %20 = icmp eq i32 %19, 0
  %21 = select i1 %20, i32 0, i32 1994146192
  %22 = xor i32 %12, %6
  %23 = xor i32 %22, %9
  %24 = xor i32 %23, %15
  %25 = xor i32 %18, %21
  %26 = and i32 %5, 32
  %27 = icmp eq i32 %26, 0
  %28 = select i1 %27, i32 0, i32 -306674912
  %29 = xor i32 %25, %28
  %30 = xor i32 %29, %24
  %31 = lshr i32 %30, 2
  %32 = and i32 %23, 1
  %33 = icmp eq i32 %32, 0
  %34 = select i1 %33, i32 0, i32 1994146192
  %35 = xor i32 %34, %31
  %36 = and i32 %22, 2
  %37 = icmp eq i32 %36, 0
  %38 = select i1 %37, i32 -1, i32 306674911
  %39 = xor i32 %35, %38
  ret i32 %39
}

attributes #0 = { mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable "frame-pointer"="non-leaf" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+fp-armv8,+neon,+outline-atomics,+v8a,-fmv" }

!llvm.module.flags = !{!0, !1, !2, !3, !4, !5}
!llvm.ident = !{!6}

!0 = !{i32 1, !"wchar_size", i32 4}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 1}
!5 = !{i32 1, !"EnableSplitLTOUnit", i32 0}
!6 = !{!"Ubuntu clang version 18.1.3 (1ubuntu1)"}

^0 = module: (path: "[Regular LTO]", hash: (0, 0, 0, 0, 0))
^1 = gv: (name: "kernel", summaries: (function: (module: ^0, flags: (linkage: external, visibility: default, notEligibleToImport: 0, live: 0, dsoLocal: 1, canAutoHide: 0), insts: 38, funcFlags: (readNone: 1, readOnly: 0, noRecurse: 1, returnDoesNotAlias: 0, noInline: 0, alwaysInline: 0, noUnwind: 1, mayThrow: 0, hasUnknownCall: 0, mustBeUnreachable: 0)))) ; guid = 17571550346185820240
^2 = blockcount: 0
