
/work/experiments/runs/rich-limbs-matrix-linux-20261109/crc32_byte/build-clang-O3-thinlto-affine-42/program:	file format elf64-littleaarch64

Disassembly of section .init:

0000000000000678 <_init>:
     678:      	nop
     67c:      	stp	x29, x30, [sp, #-0x10]!
     680:      	mov	x29, sp
     684:      	bl	0x774 <call_weak_fn>
     688:      	ldp	x29, x30, [sp], #0x10
     68c:      	ret

Disassembly of section .plt:

0000000000000690 <.plt>:
     690:      	stp	x16, x30, [sp, #-0x10]!
     694:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e2e8>
     698:      	ldr	x17, [x16, #0xff8]
     69c:      	add	x16, x16, #0xff8
     6a0:      	br	x17
     6a4:      	nop
     6a8:      	nop
     6ac:      	nop

00000000000006b0 <strtoul@plt>:
     6b0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6b4:      	ldr	x17, [x16]
     6b8:      	add	x16, x16, #0x0
     6bc:      	br	x17

00000000000006c0 <__libc_start_main@plt>:
     6c0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6c4:      	ldr	x17, [x16, #0x8]
     6c8:      	add	x16, x16, #0x8
     6cc:      	br	x17

00000000000006d0 <__cxa_finalize@plt>:
     6d0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6d4:      	ldr	x17, [x16, #0x10]
     6d8:      	add	x16, x16, #0x10
     6dc:      	br	x17

00000000000006e0 <clock_gettime@plt>:
     6e0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6e4:      	ldr	x17, [x16, #0x18]
     6e8:      	add	x16, x16, #0x18
     6ec:      	br	x17

00000000000006f0 <__gmon_start__@plt>:
     6f0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6f4:      	ldr	x17, [x16, #0x20]
     6f8:      	add	x16, x16, #0x20
     6fc:      	br	x17

0000000000000700 <abort@plt>:
     700:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     704:      	ldr	x17, [x16, #0x28]
     708:      	add	x16, x16, #0x28
     70c:      	br	x17

0000000000000710 <__isoc99_scanf@plt>:
     710:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     714:      	ldr	x17, [x16, #0x30]
     718:      	add	x16, x16, #0x30
     71c:      	br	x17

0000000000000720 <printf@plt>:
     720:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     724:      	ldr	x17, [x16, #0x38]
     728:      	add	x16, x16, #0x38
     72c:      	br	x17

Disassembly of section .text:

0000000000000740 <_start>:
     740:      	nop
     744:      	mov	x29, #0x0               // =0
     748:      	mov	x30, #0x0               // =0
     74c:      	mov	x5, x0
     750:      	ldr	x1, [sp]
     754:      	add	x2, sp, #0x8
     758:      	mov	x6, sp
     75c:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e2e8>
     760:      	ldr	x0, [x0, #0xfd8]
     764:      	mov	x3, #0x0                // =0
     768:      	mov	x4, #0x0                // =0
     76c:      	bl	0x6c0 <__libc_start_main@plt>
     770:      	bl	0x700 <abort@plt>

0000000000000774 <call_weak_fn>:
     774:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e2e8>
     778:      	ldr	x0, [x0, #0xfd0]
     77c:      	cbz	x0, 0x784 <call_weak_fn+0x10>
     780:      	b	0x6f0 <__gmon_start__@plt>
     784:      	ret
     788:      	nop
     78c:      	nop

0000000000000790 <deregister_tm_clones>:
     790:      	adrp	x0, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     794:      	add	x0, x0, #0x50
     798:      	adrp	x1, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     79c:      	add	x1, x1, #0x50
     7a0:      	cmp	x1, x0
     7a4:      	b.eq	0x7bc <deregister_tm_clones+0x2c>
     7a8:      	adrp	x1, 0x1f000 <__FRAME_END__+0x1e2e8>
     7ac:      	ldr	x1, [x1, #0xfc0]
     7b0:      	cbz	x1, 0x7bc <deregister_tm_clones+0x2c>
     7b4:      	mov	x16, x1
     7b8:      	br	x16
     7bc:      	ret

00000000000007c0 <register_tm_clones>:
     7c0:      	adrp	x0, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     7c4:      	add	x0, x0, #0x50
     7c8:      	adrp	x1, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     7cc:      	add	x1, x1, #0x50
     7d0:      	sub	x1, x1, x0
     7d4:      	lsr	x2, x1, #63
     7d8:      	add	x1, x2, x1, asr #3
     7dc:      	asr	x1, x1, #1
     7e0:      	cbz	x1, 0x7f8 <register_tm_clones+0x38>
     7e4:      	adrp	x2, 0x1f000 <__FRAME_END__+0x1e2e8>
     7e8:      	ldr	x2, [x2, #0xfe0]
     7ec:      	cbz	x2, 0x7f8 <register_tm_clones+0x38>
     7f0:      	mov	x16, x2
     7f4:      	br	x16
     7f8:      	ret
     7fc:      	nop

0000000000000800 <__do_global_dtors_aux>:
     800:      	paciasp
     804:      	stp	x29, x30, [sp, #-0x20]!
     808:      	mov	x29, sp
     80c:      	str	x19, [sp, #0x10]
     810:      	adrp	x19, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     814:      	ldrb	w0, [x19, #0x50]
     818:      	tbnz	w0, #0x0, 0x840 <__do_global_dtors_aux+0x40>
     81c:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e2e8>
     820:      	ldr	x0, [x0, #0xfc8]
     824:      	cbz	x0, 0x834 <__do_global_dtors_aux+0x34>
     828:      	adrp	x0, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     82c:      	ldr	x0, [x0, #0x48]
     830:      	bl	0x6d0 <__cxa_finalize@plt>
     834:      	bl	0x790 <deregister_tm_clones>
     838:      	mov	w0, #0x1                // =1
     83c:      	strb	w0, [x19, #0x50]
     840:      	ldr	x19, [sp, #0x10]
     844:      	ldp	x29, x30, [sp], #0x20
     848:      	autiasp
     84c:      	ret

0000000000000850 <frame_dummy>:
     850:      	bti	c
     854:      	b	0x7c0 <register_tm_clones>

0000000000000858 <kernel>:
     858:      	and	w9, w1, #0xff
     85c:      	adrp	x8, 0x0 <strtoul@GLIBC_2.17>
     860:      	mov	w10, #0x8832            // =34866
     864:      	eon	w9, w9, w0
     868:      	ldr	q1, [x8, #0xba0]
     86c:      	adrp	x8, 0x0 <strtoul@GLIBC_2.17>
     870:      	dup	v0.4s, w9
     874:      	movk	w10, #0xedb, lsl #16
     878:      	mov	w11, #0xc419            // =50201
     87c:      	movk	w11, #0x76d, lsl #16
     880:      	and	v0.16b, v0.16b, v1.16b
     884:      	ldr	q1, [x8, #0xbb0]
     888:      	lsl	w8, w9, #30
     88c:      	and	w8, w10, w8, asr #31
     890:      	sbfx	w10, w9, #0, #1
     894:      	cmeq	v0.4s, v0.4s, #0
     898:      	eor	w8, w8, w9, lsr #6
     89c:      	and	w9, w10, w11
     8a0:      	bic	v0.16b, v1.16b, v0.16b
     8a4:      	eor	w9, w8, w9
     8a8:      	tst	w8, #0x2
     8ac:      	mov	w8, #0x7cdf             // =31967
     8b0:      	movk	w8, #0x1247, lsl #16
     8b4:      	ext	v1.16b, v0.16b, v0.16b, #0x8
     8b8:      	csinv	w8, w8, wzr, ne
     8bc:      	eor	v0.8b, v0.8b, v1.8b
     8c0:      	fmov	x10, d0
     8c4:      	lsr	x11, x10, #32
     8c8:      	eor	w10, w10, w9
     8cc:      	sbfx	w9, w9, #0, #1
     8d0:      	eor	w10, w10, w11
     8d4:      	mov	w11, #0x4190            // =16784
     8d8:      	movk	w11, #0x76dc, lsl #16
     8dc:      	eor	w8, w8, w10, lsr #2
     8e0:      	and	w9, w9, w11
     8e4:      	eor	w0, w8, w9
     8e8:      	ret

00000000000008ec <main>:
     8ec:      	sub	sp, sp, #0x90
     8f0:      	stp	x29, x30, [sp, #0x40]
     8f4:      	str	x25, [sp, #0x50]
     8f8:      	stp	x24, x23, [sp, #0x60]
     8fc:      	stp	x22, x21, [sp, #0x70]
     900:      	stp	x20, x19, [sp, #0x80]
     904:      	add	x29, sp, #0x40
     908:      	cmp	w0, #0x3
     90c:      	b.eq	0xa0c <main+0x120>
     910:      	cmp	w0, #0x1
     914:      	b.ne	0xb20 <main+0x234>
     918:      	sub	x21, x29, #0x10
     91c:      	adrp	x0, 0x0 <strtoul@GLIBC_2.17>
     920:      	add	x0, x0, #0xbc8
     924:      	sub	x1, x29, #0x10
     928:      	add	x2, x21, #0x4
     92c:      	bl	0x710 <__isoc99_scanf@plt>
     930:      	cmp	w0, #0x2
     934:      	b.ne	0xb5c <main+0x270>
     938:      	adrp	x8, 0x0 <strtoul@GLIBC_2.17>
     93c:      	adrp	x9, 0x0 <strtoul@GLIBC_2.17>
     940:      	mov	w22, #0x4190            // =16784
     944:      	ldr	q0, [x8, #0xba0]
     948:      	mov	w23, #0x7cdf            // =31967
     94c:      	mov	w24, #0x8832            // =34866
     950:      	mov	w25, #0xc419            // =50201
     954:      	movk	w22, #0x76dc, lsl #16
     958:      	movk	w23, #0x1247, lsl #16
     95c:      	str	q0, [sp, #0x10]
     960:      	ldr	q0, [x9, #0xbb0]
     964:      	movk	w24, #0xedb, lsl #16
     968:      	adrp	x19, 0x0 <strtoul@GLIBC_2.17>
     96c:      	add	x19, x19, #0xbcd
     970:      	movk	w25, #0x76d, lsl #16
     974:      	adrp	x20, 0x0 <strtoul@GLIBC_2.17>
     978:      	add	x20, x20, #0xbc8
     97c:      	str	q0, [sp]
     980:      	ldur	w8, [x29, #-0x10]
     984:      	ldurb	w9, [x29, #-0xc]
     988:      	mov	x0, x19
     98c:      	ldp	q1, q2, [sp]
     990:      	eon	w8, w8, w9
     994:      	dup	v0.4s, w8
     998:      	lsl	w9, w8, #30
     99c:      	sbfx	w10, w8, #0, #1
     9a0:      	and	w9, w24, w9, asr #31
     9a4:      	and	v0.16b, v0.16b, v2.16b
     9a8:      	eor	w8, w9, w8, lsr #6
     9ac:      	and	w9, w10, w25
     9b0:      	cmeq	v0.4s, v0.4s, #0
     9b4:      	eor	w9, w8, w9
     9b8:      	tst	w8, #0x2
     9bc:      	bic	v0.16b, v1.16b, v0.16b
     9c0:      	ext	v1.16b, v0.16b, v0.16b, #0x8
     9c4:      	eor	v0.8b, v0.8b, v1.8b
     9c8:      	fmov	x10, d0
     9cc:      	lsr	x11, x10, #32
     9d0:      	eor	w10, w10, w9
     9d4:      	sbfx	w9, w9, #0, #1
     9d8:      	eor	w8, w10, w11
     9dc:      	csinv	w10, w23, wzr, ne
     9e0:      	and	w9, w9, w22
     9e4:      	eor	w8, w10, w8, lsr #2
     9e8:      	eor	w1, w8, w9
     9ec:      	bl	0x720 <printf@plt>
     9f0:      	sub	x1, x29, #0x10
     9f4:      	add	x2, x21, #0x4
     9f8:      	mov	x0, x20
     9fc:      	bl	0x710 <__isoc99_scanf@plt>
     a00:      	cmp	w0, #0x2
     a04:      	b.eq	0x980 <main+0x94>
     a08:      	b	0xb5c <main+0x270>
     a0c:      	ldr	x0, [x1, #0x8]
     a10:      	mov	x19, x1
     a14:      	mov	x1, xzr
     a18:      	mov	w2, #0xa                // =10
     a1c:      	bl	0x6b0 <strtoul@plt>
     a20:      	ldr	x8, [x19, #0x10]
     a24:      	mov	x20, x0
     a28:      	mov	x1, xzr
     a2c:      	mov	w2, #0xa                // =10
     a30:      	mov	x0, x8
     a34:      	bl	0x6b0 <strtoul@plt>
     a38:      	mov	x21, x0
     a3c:      	sub	x1, x29, #0x10
     a40:      	mov	w0, #0x1                // =1
     a44:      	bl	0x6e0 <clock_gettime@plt>
     a48:      	cbnz	w0, 0xb18 <main+0x22c>
     a4c:      	mov	x19, xzr
     a50:      	cbz	x20, 0xb08 <main+0x21c>
     a54:      	adrp	x9, 0x0 <strtoul@GLIBC_2.17>
     a58:      	adrp	x10, 0x0 <strtoul@GLIBC_2.17>
     a5c:      	mov	w8, #0x4190             // =16784
     a60:      	ldr	q0, [x9, #0xba0]
     a64:      	ldr	q1, [x10, #0xbb0]
     a68:      	mov	w9, #0x7cdf             // =31967
     a6c:      	mov	w10, #0x8832            // =34866
     a70:      	mov	w11, #0xc419            // =50201
     a74:      	movk	w8, #0x76dc, lsl #16
     a78:      	movk	w9, #0x1247, lsl #16
     a7c:      	movk	w10, #0xedb, lsl #16
     a80:      	movk	w11, #0x76d, lsl #16
     a84:      	eor	w12, w21, w21, lsl #13
     a88:      	eor	w12, w12, w12, lsr #17
     a8c:      	eor	w12, w12, w12, lsl #5
     a90:      	eor	w13, w12, w12, lsl #13
     a94:      	eor	w13, w13, w13, lsr #17
     a98:      	eor	w21, w13, w13, lsl #5
     a9c:      	and	w13, w21, #0xff
     aa0:      	eon	w12, w12, w13
     aa4:      	dup	v2.4s, w12
     aa8:      	lsl	w13, w12, #30
     aac:      	sbfx	w14, w12, #0, #1
     ab0:      	and	w13, w10, w13, asr #31
     ab4:      	and	v2.16b, v2.16b, v0.16b
     ab8:      	eor	w12, w13, w12, lsr #6
     abc:      	and	w13, w14, w11
     ac0:      	cmeq	v2.4s, v2.4s, #0
     ac4:      	eor	w13, w12, w13
     ac8:      	tst	w12, #0x2
     acc:      	bic	v2.16b, v1.16b, v2.16b
     ad0:      	ext	v3.16b, v2.16b, v2.16b, #0x8
     ad4:      	eor	v2.8b, v2.8b, v3.8b
     ad8:      	fmov	x14, d2
     adc:      	lsr	x15, x14, #32
     ae0:      	eor	w14, w14, w13
     ae4:      	sbfx	w13, w13, #0, #1
     ae8:      	eor	w12, w14, w15
     aec:      	csinv	w14, w9, wzr, ne
     af0:      	and	w13, w13, w8
     af4:      	eor	w12, w14, w12, lsr #2
     af8:      	subs	x20, x20, #0x1
     afc:      	eor	w12, w12, w13
     b00:      	add	x19, x19, x12
     b04:      	b.ne	0xa84 <main+0x198>
     b08:      	add	x1, sp, #0x20
     b0c:      	mov	w0, #0x1                // =1
     b10:      	bl	0x6e0 <clock_gettime@plt>
     b14:      	cbz	w0, 0xb28 <main+0x23c>
     b18:      	mov	w0, #0x2                // =2
     b1c:      	b	0xb60 <main+0x274>
     b20:      	mov	w0, #0x3                // =3
     b24:      	b	0xb60 <main+0x274>
     b28:      	ldp	x8, x9, [sp, #0x20]
     b2c:      	adrp	x0, 0x0 <strtoul@GLIBC_2.17>
     b30:      	add	x0, x0, #0xbd1
     b34:      	ldp	x10, x11, [x29, #-0x10]
     b38:      	mov	x1, x19
     b3c:      	sub	x8, x8, x10
     b40:      	sub	x9, x9, x11
     b44:      	scvtf	d0, x8
     b48:      	scvtf	d1, x9
     b4c:      	adrp	x8, 0x0 <strtoul@GLIBC_2.17>
     b50:      	ldr	d2, [x8, #0xbc0]
     b54:      	fmadd	d0, d1, d2, d0
     b58:      	bl	0x720 <printf@plt>
     b5c:      	mov	w0, wzr
     b60:      	ldp	x20, x19, [sp, #0x80]
     b64:      	ldr	x25, [sp, #0x50]
     b68:      	ldp	x22, x21, [sp, #0x70]
     b6c:      	ldp	x24, x23, [sp, #0x60]
     b70:      	ldp	x29, x30, [sp, #0x40]
     b74:      	add	sp, sp, #0x90
     b78:      	ret

Disassembly of section .fini:

0000000000000b7c <_fini>:
     b7c:      	nop
     b80:      	stp	x29, x30, [sp, #-0x10]!
     b84:      	mov	x29, sp
     b88:      	ldp	x29, x30, [sp], #0x10
     b8c:      	ret
