
/work/experiments/runs/rich-limbs-matrix-linux-20261109/crc32_byte/build-clang-Os-limbs16/program:	file format elf64-littleaarch64

Disassembly of section .init:

0000000000000678 <_init>:
     678:      	nop
     67c:      	stp	x29, x30, [sp, #-0x10]!
     680:      	mov	x29, sp
     684:      	bl	0x774 <call_weak_fn>
     688:      	ldp	x29, x30, [sp], #0x10
     68c:      	ret

Disassembly of section .plt:

0000000000000690 <.plt>:
     690:      	stp	x16, x30, [sp, #-0x10]!
     694:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e360>
     698:      	ldr	x17, [x16, #0xff8]
     69c:      	add	x16, x16, #0xff8
     6a0:      	br	x17
     6a4:      	nop
     6a8:      	nop
     6ac:      	nop

00000000000006b0 <strtoul@plt>:
     6b0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6b4:      	ldr	x17, [x16]
     6b8:      	add	x16, x16, #0x0
     6bc:      	br	x17

00000000000006c0 <__libc_start_main@plt>:
     6c0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6c4:      	ldr	x17, [x16, #0x8]
     6c8:      	add	x16, x16, #0x8
     6cc:      	br	x17

00000000000006d0 <__cxa_finalize@plt>:
     6d0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6d4:      	ldr	x17, [x16, #0x10]
     6d8:      	add	x16, x16, #0x10
     6dc:      	br	x17

00000000000006e0 <clock_gettime@plt>:
     6e0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6e4:      	ldr	x17, [x16, #0x18]
     6e8:      	add	x16, x16, #0x18
     6ec:      	br	x17

00000000000006f0 <__gmon_start__@plt>:
     6f0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6f4:      	ldr	x17, [x16, #0x20]
     6f8:      	add	x16, x16, #0x20
     6fc:      	br	x17

0000000000000700 <abort@plt>:
     700:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     704:      	ldr	x17, [x16, #0x28]
     708:      	add	x16, x16, #0x28
     70c:      	br	x17

0000000000000710 <__isoc99_scanf@plt>:
     710:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     714:      	ldr	x17, [x16, #0x30]
     718:      	add	x16, x16, #0x30
     71c:      	br	x17

0000000000000720 <printf@plt>:
     720:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     724:      	ldr	x17, [x16, #0x38]
     728:      	add	x16, x16, #0x38
     72c:      	br	x17

Disassembly of section .text:

0000000000000740 <_start>:
     740:      	nop
     744:      	mov	x29, #0x0               // =0
     748:      	mov	x30, #0x0               // =0
     74c:      	mov	x5, x0
     750:      	ldr	x1, [sp]
     754:      	add	x2, sp, #0x8
     758:      	mov	x6, sp
     75c:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e360>
     760:      	ldr	x0, [x0, #0xfd8]
     764:      	mov	x3, #0x0                // =0
     768:      	mov	x4, #0x0                // =0
     76c:      	bl	0x6c0 <__libc_start_main@plt>
     770:      	bl	0x700 <abort@plt>

0000000000000774 <call_weak_fn>:
     774:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e360>
     778:      	ldr	x0, [x0, #0xfd0]
     77c:      	cbz	x0, 0x784 <call_weak_fn+0x10>
     780:      	b	0x6f0 <__gmon_start__@plt>
     784:      	ret
     788:      	nop
     78c:      	nop

0000000000000790 <deregister_tm_clones>:
     790:      	adrp	x0, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     794:      	add	x0, x0, #0x50
     798:      	adrp	x1, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     79c:      	add	x1, x1, #0x50
     7a0:      	cmp	x1, x0
     7a4:      	b.eq	0x7bc <deregister_tm_clones+0x2c>
     7a8:      	adrp	x1, 0x1f000 <__FRAME_END__+0x1e360>
     7ac:      	ldr	x1, [x1, #0xfc0]
     7b0:      	cbz	x1, 0x7bc <deregister_tm_clones+0x2c>
     7b4:      	mov	x16, x1
     7b8:      	br	x16
     7bc:      	ret

00000000000007c0 <register_tm_clones>:
     7c0:      	adrp	x0, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     7c4:      	add	x0, x0, #0x50
     7c8:      	adrp	x1, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     7cc:      	add	x1, x1, #0x50
     7d0:      	sub	x1, x1, x0
     7d4:      	lsr	x2, x1, #63
     7d8:      	add	x1, x2, x1, asr #3
     7dc:      	asr	x1, x1, #1
     7e0:      	cbz	x1, 0x7f8 <register_tm_clones+0x38>
     7e4:      	adrp	x2, 0x1f000 <__FRAME_END__+0x1e360>
     7e8:      	ldr	x2, [x2, #0xfe0]
     7ec:      	cbz	x2, 0x7f8 <register_tm_clones+0x38>
     7f0:      	mov	x16, x2
     7f4:      	br	x16
     7f8:      	ret
     7fc:      	nop

0000000000000800 <__do_global_dtors_aux>:
     800:      	paciasp
     804:      	stp	x29, x30, [sp, #-0x20]!
     808:      	mov	x29, sp
     80c:      	str	x19, [sp, #0x10]
     810:      	adrp	x19, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     814:      	ldrb	w0, [x19, #0x50]
     818:      	tbnz	w0, #0x0, 0x840 <__do_global_dtors_aux+0x40>
     81c:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e360>
     820:      	ldr	x0, [x0, #0xfc8]
     824:      	cbz	x0, 0x834 <__do_global_dtors_aux+0x34>
     828:      	adrp	x0, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     82c:      	ldr	x0, [x0, #0x48]
     830:      	bl	0x6d0 <__cxa_finalize@plt>
     834:      	bl	0x790 <deregister_tm_clones>
     838:      	mov	w0, #0x1                // =1
     83c:      	strb	w0, [x19, #0x50]
     840:      	ldr	x19, [sp, #0x10]
     844:      	ldp	x29, x30, [sp], #0x20
     848:      	autiasp
     84c:      	ret

0000000000000850 <frame_dummy>:
     850:      	bti	c
     854:      	b	0x7c0 <register_tm_clones>

0000000000000858 <kernel>:
     858:      	and	w9, w0, #0xffff
     85c:      	and	w10, w1, #0xff
     860:      	mov	w8, #0x76dc             // =30428
     864:      	eor	w9, w9, w10
     868:      	mov	w12, #0x10000           // =65536
     86c:      	mov	w11, #0x832             // =2098
     870:      	eor	w10, w9, #0xffff
     874:      	mvn	w14, w0
     878:      	bic	w12, w12, w0
     87c:      	sbfx	w15, w10, #0, #1
     880:      	lsr	w17, w14, #5
     884:      	orr	w12, w10, w12
     888:      	lsl	w18, w10, #30
     88c:      	mov	w13, #0x1064            // =4196
     890:      	mov	w9, #0xedb8             // =60856
     894:      	and	w0, w15, w8
     898:      	and	w11, w15, w11
     89c:      	lsl	w15, w10, #29
     8a0:      	eor	w14, w0, w14, lsr #18
     8a4:      	eor	w11, w11, w12, lsr #5
     8a8:      	mov	w16, #0x20c8            // =8392
     8ac:      	and	w17, w17, #0x1000
     8b0:      	and	w12, w13, w18, asr #31
     8b4:      	and	w13, w9, w18, asr #31
     8b8:      	lsl	w18, w14, #13
     8bc:      	and	w16, w16, w15, asr #31
     8c0:      	and	w15, w9, w15, asr #31
     8c4:      	orr	w17, w11, w17
     8c8:      	lsl	w0, w10, #28
     8cc:      	eor	w13, w14, w13
     8d0:      	eor	w12, w17, w12
     8d4:      	and	w14, w18, #0x2000
     8d8:      	mov	w17, #0x4190            // =16784
     8dc:      	eor	w15, w15, w13, lsr #1
     8e0:      	orr	w14, w14, w12
     8e4:      	and	w17, w17, w0, asr #31
     8e8:      	and	w18, w18, #0x4000
     8ec:      	eor	w14, w14, w16
     8f0:      	lsr	w13, w13, #3
     8f4:      	lsr	w16, w15, #1
     8f8:      	orr	w14, w14, w18
     8fc:      	lsl	w18, w10, #27
     900:      	eor	w14, w14, w17
     904:      	mov	w17, #0x8320            // =33568
     908:      	lsl	w11, w11, #30
     90c:      	orr	w14, w14, w16, lsl #15
     910:      	and	w16, w17, w18, asr #31
     914:      	tst	w12, #0x4
     918:      	and	w1, w17, w11, asr #31
     91c:      	and	w14, w14, #0xfffc
     920:      	eor	w14, w14, w16
     924:      	lsl	w16, w10, #26
     928:      	sbfx	w10, w10, #4, #1
     92c:      	lsr	w14, w14, #1
     930:      	and	w18, w17, w16, asr #31
     934:      	and	w8, w8, w16, asr #31
     938:      	bfi	w14, w13, #15, #1
     93c:      	eor	w13, w14, w18
     940:      	lsr	w14, w15, #3
     944:      	and	w18, w9, w0, asr #31
     948:      	lsr	w13, w13, #1
     94c:      	mov	w0, #0x3b6e             // =15214
     950:      	and	w9, w9, w11, asr #31
     954:      	and	w10, w0, w10, lsr #2
     958:      	bfi	w13, w14, #15, #1
     95c:      	eor	w14, w18, w15, lsr #1
     960:      	eor	w8, w8, w9
     964:      	eor	w13, w13, w1
     968:      	eor	w10, w10, w14, lsr #3
     96c:      	lsr	w11, w13, #1
     970:      	lsl	w13, w12, #29
     974:      	mov	w12, #0xffff            // =65535
     978:      	eor	w8, w10, w8
     97c:      	orr	w9, w11, w10, lsl #15
     980:      	mov	w11, #0x1247            // =4679
     984:      	and	w10, w17, w13, asr #31
     988:      	csel	w11, w12, w11, eq
     98c:      	and	w9, w9, #0xffff
     990:      	eor	w8, w11, w8, lsr #1
     994:      	eor	w9, w9, w10
     998:      	orr	w8, w9, w8, lsl #16
     99c:      	eor	w0, w8, #0xffff
     9a0:      	ret

00000000000009a4 <main>:
     9a4:      	sub	sp, sp, #0x60
     9a8:      	stp	x29, x30, [sp, #0x20]
     9ac:      	str	x23, [sp, #0x30]
     9b0:      	stp	x22, x21, [sp, #0x40]
     9b4:      	stp	x20, x19, [sp, #0x50]
     9b8:      	add	x29, sp, #0x20
     9bc:      	cmp	w0, #0x3
     9c0:      	b.eq	0xa2c <main+0x88>
     9c4:      	cmp	w0, #0x1
     9c8:      	b.ne	0xac0 <main+0x11c>
     9cc:      	add	x21, x29, #0x18
     9d0:      	adrp	x0, 0x0 <strtoul@GLIBC_2.17>
     9d4:      	add	x0, x0, #0xb58
     9d8:      	add	x1, x29, #0x18
     9dc:      	add	x2, x21, #0x4
     9e0:      	bl	0x710 <__isoc99_scanf@plt>
     9e4:      	cmp	w0, #0x2
     9e8:      	b.ne	0xb18 <main+0x174>
     9ec:      	adrp	x19, 0x0 <strtoul@GLIBC_2.17>
     9f0:      	add	x19, x19, #0xb5d
     9f4:      	adrp	x20, 0x0 <strtoul@GLIBC_2.17>
     9f8:      	add	x20, x20, #0xb58
     9fc:      	ldp	w0, w1, [x29, #0x18]
     a00:      	bl	0x858 <kernel>
     a04:      	mov	w1, w0
     a08:      	mov	x0, x19
     a0c:      	bl	0x720 <printf@plt>
     a10:      	add	x1, x29, #0x18
     a14:      	add	x2, x21, #0x4
     a18:      	mov	x0, x20
     a1c:      	bl	0x710 <__isoc99_scanf@plt>
     a20:      	cmp	w0, #0x2
     a24:      	b.eq	0x9fc <main+0x58>
     a28:      	b	0xb18 <main+0x174>
     a2c:      	ldr	x0, [x1, #0x8]
     a30:      	mov	x19, x1
     a34:      	mov	x1, xzr
     a38:      	mov	w2, #0xa                // =10
     a3c:      	bl	0x6b0 <strtoul@plt>
     a40:      	ldr	x8, [x19, #0x10]
     a44:      	mov	x20, x0
     a48:      	mov	x1, xzr
     a4c:      	mov	w2, #0xa                // =10
     a50:      	mov	x0, x8
     a54:      	bl	0x6b0 <strtoul@plt>
     a58:      	mov	x21, x0
     a5c:      	add	x1, sp, #0x10
     a60:      	mov	w0, #0x1                // =1
     a64:      	bl	0x6e0 <clock_gettime@plt>
     a68:      	cbnz	w0, 0xadc <main+0x138>
     a6c:      	cbz	x20, 0xac8 <main+0x124>
     a70:      	mov	x22, xzr
     a74:      	mov	x19, xzr
     a78:      	add	x23, x29, #0x18
     a7c:      	mov	x8, xzr
     a80:      	mov	w9, #0x1                // =1
     a84:      	eor	w10, w21, w21, lsl #13
     a88:      	mov	w11, w9
     a8c:      	mov	w9, wzr
     a90:      	eor	w10, w10, w10, lsr #17
     a94:      	eor	w21, w10, w10, lsl #5
     a98:      	str	w21, [x23, x8, lsl #2]
     a9c:      	mov	w8, #0x1                // =1
     aa0:      	tbnz	w11, #0x0, 0xa84 <main+0xe0>
     aa4:      	ldp	w0, w1, [x29, #0x18]
     aa8:      	bl	0x858 <kernel>
     aac:      	add	x22, x22, #0x1
     ab0:      	add	x19, x19, w0, uxtw
     ab4:      	cmp	x22, x20
     ab8:      	b.ne	0xa7c <main+0xd8>
     abc:      	b	0xacc <main+0x128>
     ac0:      	mov	w0, #0x3                // =3
     ac4:      	b	0xb1c <main+0x178>
     ac8:      	mov	x19, xzr
     acc:      	mov	x1, sp
     ad0:      	mov	w0, #0x1                // =1
     ad4:      	bl	0x6e0 <clock_gettime@plt>
     ad8:      	cbz	w0, 0xae4 <main+0x140>
     adc:      	mov	w0, #0x2                // =2
     ae0:      	b	0xb1c <main+0x178>
     ae4:      	ldp	x8, x9, [sp]
     ae8:      	adrp	x0, 0x0 <strtoul@GLIBC_2.17>
     aec:      	add	x0, x0, #0xb61
     af0:      	ldp	x10, x11, [sp, #0x10]
     af4:      	mov	x1, x19
     af8:      	sub	x8, x8, x10
     afc:      	sub	x9, x9, x11
     b00:      	scvtf	d0, x8
     b04:      	scvtf	d1, x9
     b08:      	adrp	x8, 0x0 <strtoul@GLIBC_2.17>
     b0c:      	ldr	d2, [x8, #0xb50]
     b10:      	fmadd	d0, d1, d2, d0
     b14:      	bl	0x720 <printf@plt>
     b18:      	mov	w0, wzr
     b1c:      	ldp	x20, x19, [sp, #0x50]
     b20:      	ldr	x23, [sp, #0x30]
     b24:      	ldp	x22, x21, [sp, #0x40]
     b28:      	ldp	x29, x30, [sp, #0x20]
     b2c:      	add	sp, sp, #0x60
     b30:      	ret

Disassembly of section .fini:

0000000000000b34 <_fini>:
     b34:      	nop
     b38:      	stp	x29, x30, [sp, #-0x10]!
     b3c:      	mov	x29, sp
     b40:      	ldp	x29, x30, [sp], #0x10
     b44:      	ret
