
/work/experiments/runs/rich-limbs-matrix-linux-20261109/crc32_byte/build-clang-Oz-affine-42/program:	file format elf64-littleaarch64

Disassembly of section .init:

0000000000000678 <_init>:
     678:      	nop
     67c:      	stp	x29, x30, [sp, #-0x10]!
     680:      	mov	x29, sp
     684:      	bl	0x774 <call_weak_fn>
     688:      	ldp	x29, x30, [sp], #0x10
     68c:      	ret

Disassembly of section .plt:

0000000000000690 <.plt>:
     690:      	stp	x16, x30, [sp, #-0x10]!
     694:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e424>
     698:      	ldr	x17, [x16, #0xff8]
     69c:      	add	x16, x16, #0xff8
     6a0:      	br	x17
     6a4:      	nop
     6a8:      	nop
     6ac:      	nop

00000000000006b0 <strtoul@plt>:
     6b0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6b4:      	ldr	x17, [x16]
     6b8:      	add	x16, x16, #0x0
     6bc:      	br	x17

00000000000006c0 <__libc_start_main@plt>:
     6c0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6c4:      	ldr	x17, [x16, #0x8]
     6c8:      	add	x16, x16, #0x8
     6cc:      	br	x17

00000000000006d0 <__cxa_finalize@plt>:
     6d0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6d4:      	ldr	x17, [x16, #0x10]
     6d8:      	add	x16, x16, #0x10
     6dc:      	br	x17

00000000000006e0 <clock_gettime@plt>:
     6e0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6e4:      	ldr	x17, [x16, #0x18]
     6e8:      	add	x16, x16, #0x18
     6ec:      	br	x17

00000000000006f0 <__gmon_start__@plt>:
     6f0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6f4:      	ldr	x17, [x16, #0x20]
     6f8:      	add	x16, x16, #0x20
     6fc:      	br	x17

0000000000000700 <abort@plt>:
     700:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     704:      	ldr	x17, [x16, #0x28]
     708:      	add	x16, x16, #0x28
     70c:      	br	x17

0000000000000710 <__isoc99_scanf@plt>:
     710:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     714:      	ldr	x17, [x16, #0x30]
     718:      	add	x16, x16, #0x30
     71c:      	br	x17

0000000000000720 <printf@plt>:
     720:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     724:      	ldr	x17, [x16, #0x38]
     728:      	add	x16, x16, #0x38
     72c:      	br	x17

Disassembly of section .text:

0000000000000740 <_start>:
     740:      	nop
     744:      	mov	x29, #0x0               // =0
     748:      	mov	x30, #0x0               // =0
     74c:      	mov	x5, x0
     750:      	ldr	x1, [sp]
     754:      	add	x2, sp, #0x8
     758:      	mov	x6, sp
     75c:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e424>
     760:      	ldr	x0, [x0, #0xfd8]
     764:      	mov	x3, #0x0                // =0
     768:      	mov	x4, #0x0                // =0
     76c:      	bl	0x6c0 <__libc_start_main@plt>
     770:      	bl	0x700 <abort@plt>

0000000000000774 <call_weak_fn>:
     774:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e424>
     778:      	ldr	x0, [x0, #0xfd0]
     77c:      	cbz	x0, 0x784 <call_weak_fn+0x10>
     780:      	b	0x6f0 <__gmon_start__@plt>
     784:      	ret
     788:      	nop
     78c:      	nop

0000000000000790 <deregister_tm_clones>:
     790:      	adrp	x0, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     794:      	add	x0, x0, #0x50
     798:      	adrp	x1, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     79c:      	add	x1, x1, #0x50
     7a0:      	cmp	x1, x0
     7a4:      	b.eq	0x7bc <deregister_tm_clones+0x2c>
     7a8:      	adrp	x1, 0x1f000 <__FRAME_END__+0x1e424>
     7ac:      	ldr	x1, [x1, #0xfc0]
     7b0:      	cbz	x1, 0x7bc <deregister_tm_clones+0x2c>
     7b4:      	mov	x16, x1
     7b8:      	br	x16
     7bc:      	ret

00000000000007c0 <register_tm_clones>:
     7c0:      	adrp	x0, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     7c4:      	add	x0, x0, #0x50
     7c8:      	adrp	x1, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     7cc:      	add	x1, x1, #0x50
     7d0:      	sub	x1, x1, x0
     7d4:      	lsr	x2, x1, #63
     7d8:      	add	x1, x2, x1, asr #3
     7dc:      	asr	x1, x1, #1
     7e0:      	cbz	x1, 0x7f8 <register_tm_clones+0x38>
     7e4:      	adrp	x2, 0x1f000 <__FRAME_END__+0x1e424>
     7e8:      	ldr	x2, [x2, #0xfe0]
     7ec:      	cbz	x2, 0x7f8 <register_tm_clones+0x38>
     7f0:      	mov	x16, x2
     7f4:      	br	x16
     7f8:      	ret
     7fc:      	nop

0000000000000800 <__do_global_dtors_aux>:
     800:      	paciasp
     804:      	stp	x29, x30, [sp, #-0x20]!
     808:      	mov	x29, sp
     80c:      	str	x19, [sp, #0x10]
     810:      	adrp	x19, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     814:      	ldrb	w0, [x19, #0x50]
     818:      	tbnz	w0, #0x0, 0x840 <__do_global_dtors_aux+0x40>
     81c:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e424>
     820:      	ldr	x0, [x0, #0xfc8]
     824:      	cbz	x0, 0x834 <__do_global_dtors_aux+0x34>
     828:      	adrp	x0, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     82c:      	ldr	x0, [x0, #0x48]
     830:      	bl	0x6d0 <__cxa_finalize@plt>
     834:      	bl	0x790 <deregister_tm_clones>
     838:      	mov	w0, #0x1                // =1
     83c:      	strb	w0, [x19, #0x50]
     840:      	ldr	x19, [sp, #0x10]
     844:      	ldp	x29, x30, [sp], #0x20
     848:      	autiasp
     84c:      	ret

0000000000000850 <frame_dummy>:
     850:      	bti	c
     854:      	b	0x7c0 <register_tm_clones>

0000000000000858 <kernel>:
     858:      	and	w9, w1, #0xff
     85c:      	adrp	x8, 0x0 <strtoul@GLIBC_2.17>
     860:      	mov	w10, #0x8832            // =34866
     864:      	eon	w9, w9, w0
     868:      	ldr	q1, [x8, #0xa80]
     86c:      	adrp	x8, 0x0 <strtoul@GLIBC_2.17>
     870:      	dup	v0.4s, w9
     874:      	movk	w10, #0xedb, lsl #16
     878:      	mov	w11, #0xc419            // =50201
     87c:      	movk	w11, #0x76d, lsl #16
     880:      	and	v0.16b, v0.16b, v1.16b
     884:      	ldr	q1, [x8, #0xa90]
     888:      	lsl	w8, w9, #30
     88c:      	and	w8, w10, w8, asr #31
     890:      	sbfx	w10, w9, #0, #1
     894:      	cmeq	v0.4s, v0.4s, #0
     898:      	eor	w8, w8, w9, lsr #6
     89c:      	and	w9, w10, w11
     8a0:      	bic	v0.16b, v1.16b, v0.16b
     8a4:      	eor	w9, w8, w9
     8a8:      	tst	w8, #0x2
     8ac:      	sbfx	w12, w9, #0, #1
     8b0:      	mov	w8, #0x7cdf             // =31967
     8b4:      	movk	w8, #0x1247, lsl #16
     8b8:      	ext	v1.16b, v0.16b, v0.16b, #0x8
     8bc:      	csinv	w8, w8, wzr, ne
     8c0:      	eor	v0.8b, v0.8b, v1.8b
     8c4:      	fmov	x10, d0
     8c8:      	lsr	x11, x10, #32
     8cc:      	eor	w9, w10, w9
     8d0:      	mov	w10, #0x4190            // =16784
     8d4:      	movk	w10, #0x76dc, lsl #16
     8d8:      	eor	w9, w9, w11
     8dc:      	and	w10, w12, w10
     8e0:      	eor	w9, w10, w9, lsr #2
     8e4:      	eor	w0, w9, w8
     8e8:      	ret

00000000000008ec <main>:
     8ec:      	sub	sp, sp, #0x60
     8f0:      	stp	x29, x30, [sp, #0x20]
     8f4:      	str	x23, [sp, #0x30]
     8f8:      	stp	x22, x21, [sp, #0x40]
     8fc:      	stp	x20, x19, [sp, #0x50]
     900:      	add	x29, sp, #0x20
     904:      	cmp	w0, #0x3
     908:      	b.eq	0x958 <main+0x6c>
     90c:      	cmp	w0, #0x1
     910:      	b.ne	0x9e4 <main+0xf8>
     914:      	adrp	x19, 0x0 <strtoul@GLIBC_2.17>
     918:      	add	x19, x19, #0xaa8
     91c:      	add	x21, x29, #0x18
     920:      	adrp	x20, 0x0 <strtoul@GLIBC_2.17>
     924:      	add	x20, x20, #0xaad
     928:      	add	x1, x29, #0x18
     92c:      	add	x2, x21, #0x4
     930:      	mov	x0, x19
     934:      	bl	0x710 <__isoc99_scanf@plt>
     938:      	cmp	w0, #0x2
     93c:      	b.ne	0xa38 <main+0x14c>
     940:      	ldp	w0, w1, [x29, #0x18]
     944:      	bl	0x858 <kernel>
     948:      	mov	w1, w0
     94c:      	mov	x0, x20
     950:      	bl	0x720 <printf@plt>
     954:      	b	0x928 <main+0x3c>
     958:      	ldr	x0, [x1, #0x8]
     95c:      	mov	x19, x1
     960:      	mov	x1, xzr
     964:      	mov	w2, #0xa                // =10
     968:      	bl	0x6b0 <strtoul@plt>
     96c:      	ldr	x8, [x19, #0x10]
     970:      	mov	x20, x0
     974:      	mov	x1, xzr
     978:      	mov	w2, #0xa                // =10
     97c:      	mov	x0, x8
     980:      	bl	0x6b0 <strtoul@plt>
     984:      	mov	x21, x0
     988:      	add	x1, sp, #0x10
     98c:      	mov	w0, #0x1                // =1
     990:      	bl	0x6e0 <clock_gettime@plt>
     994:      	cbnz	w0, 0x9fc <main+0x110>
     998:      	mov	x19, xzr
     99c:      	mov	x22, xzr
     9a0:      	add	x23, x29, #0x18
     9a4:      	cmp	x22, x20
     9a8:      	b.eq	0x9ec <main+0x100>
     9ac:      	mov	x8, xzr
     9b0:      	cmp	x8, #0x8
     9b4:      	b.eq	0x9d0 <main+0xe4>
     9b8:      	eor	w9, w21, w21, lsl #13
     9bc:      	eor	w9, w9, w9, lsr #17
     9c0:      	eor	w21, w9, w9, lsl #5
     9c4:      	str	w21, [x23, x8]
     9c8:      	add	x8, x8, #0x4
     9cc:      	b	0x9b0 <main+0xc4>
     9d0:      	ldp	w0, w1, [x29, #0x18]
     9d4:      	bl	0x858 <kernel>
     9d8:      	add	x19, x19, w0, uxtw
     9dc:      	add	x22, x22, #0x1
     9e0:      	b	0x9a4 <main+0xb8>
     9e4:      	mov	w0, #0x3                // =3
     9e8:      	b	0xa3c <main+0x150>
     9ec:      	mov	x1, sp
     9f0:      	mov	w0, #0x1                // =1
     9f4:      	bl	0x6e0 <clock_gettime@plt>
     9f8:      	cbz	w0, 0xa04 <main+0x118>
     9fc:      	mov	w0, #0x2                // =2
     a00:      	b	0xa3c <main+0x150>
     a04:      	ldp	x8, x9, [sp]
     a08:      	adrp	x0, 0x0 <strtoul@GLIBC_2.17>
     a0c:      	add	x0, x0, #0xab1
     a10:      	ldp	x10, x11, [sp, #0x10]
     a14:      	mov	x1, x19
     a18:      	sub	x8, x8, x10
     a1c:      	sub	x9, x9, x11
     a20:      	scvtf	d0, x8
     a24:      	scvtf	d1, x9
     a28:      	adrp	x8, 0x0 <strtoul@GLIBC_2.17>
     a2c:      	ldr	d2, [x8, #0xaa0]
     a30:      	fmadd	d0, d1, d2, d0
     a34:      	bl	0x720 <printf@plt>
     a38:      	mov	w0, wzr
     a3c:      	ldp	x20, x19, [sp, #0x50]
     a40:      	ldr	x23, [sp, #0x30]
     a44:      	ldp	x22, x21, [sp, #0x40]
     a48:      	ldp	x29, x30, [sp, #0x20]
     a4c:      	add	sp, sp, #0x60
     a50:      	ret

Disassembly of section .fini:

0000000000000a54 <_fini>:
     a54:      	nop
     a58:      	stp	x29, x30, [sp, #-0x10]!
     a5c:      	mov	x29, sp
     a60:      	ldp	x29, x30, [sp], #0x10
     a64:      	ret
