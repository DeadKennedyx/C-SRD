; ModuleID = '/work/experiments/runs/rich-limbs-matrix-linux-20261109/crc32_byte/build-clang-O1-identity/validation/compiler-0-O1/candidate.i'
source_filename = "/work/experiments/runs/rich-limbs-matrix-linux-20261109/crc32_byte/build-clang-O1-identity/validation/compiler-0-O1/candidate.i"
target datalayout = "e-m:e-i8:8:32-i16:16:32-i64:64-i128:128-n32:64-S128"
target triple = "aarch64-unknown-linux-gnu"

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local i32 @kernel(i32 noundef %0, i32 noundef %1) local_unnamed_addr #0 {
  %3 = and i32 %1, 255
  %4 = xor i32 %3, %0
  %5 = xor i32 %4, -1
  %6 = and i32 %5, 1
  %7 = lshr i32 %5, 1
  %8 = icmp eq i32 %6, 0
  %9 = select i1 %8, i32 0, i32 -306674912
  %10 = xor i32 %9, %7
  %11 = lshr i32 %10, 1
  %12 = and i32 %5, 2
  %13 = icmp eq i32 %12, 0
  %14 = select i1 %13, i32 0, i32 -306674912
  %15 = xor i32 %11, %14
  %16 = lshr i32 %15, 6
  %17 = and i32 %5, 4
  %18 = icmp eq i32 %17, 0
  %19 = select i1 %18, i32 0, i32 124634137
  %20 = and i32 %5, 8
  %21 = icmp eq i32 %20, 0
  %22 = select i1 %21, i32 0, i32 249268274
  %23 = and i32 %5, 16
  %24 = icmp eq i32 %23, 0
  %25 = select i1 %24, i32 0, i32 498536548
  %26 = and i32 %5, 32
  %27 = icmp eq i32 %26, 0
  %28 = select i1 %27, i32 0, i32 997073096
  %29 = and i32 %10, 32
  %30 = icmp eq i32 %29, 0
  %31 = select i1 %30, i32 0, i32 1994146192
  %32 = and i32 %15, 32
  %33 = icmp eq i32 %32, 0
  %34 = select i1 %33, i32 -1, i32 306674911
  %35 = xor i32 %22, %19
  %36 = xor i32 %35, %25
  %37 = xor i32 %36, %28
  %38 = xor i32 %37, %16
  %39 = xor i32 %38, %31
  %40 = xor i32 %39, %34
  ret i32 %40
}

attributes #0 = { mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable "frame-pointer"="non-leaf" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+fp-armv8,+neon,+outline-atomics,+v8a,-fmv" }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 1, !"wchar_size", i32 4}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 1}
!5 = !{!"Ubuntu clang version 18.1.3 (1ubuntu1)"}
