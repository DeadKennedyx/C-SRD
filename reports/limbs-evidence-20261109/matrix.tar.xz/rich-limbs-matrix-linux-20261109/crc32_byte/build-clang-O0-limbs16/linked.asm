
/work/experiments/runs/rich-limbs-matrix-linux-20261109/crc32_byte/build-clang-O0-limbs16/program:	file format elf64-littleaarch64

Disassembly of section .init:

0000000000000678 <_init>:
     678:      	nop
     67c:      	stp	x29, x30, [sp, #-0x10]!
     680:      	mov	x29, sp
     684:      	bl	0x774 <call_weak_fn>
     688:      	ldp	x29, x30, [sp], #0x10
     68c:      	ret

Disassembly of section .plt:

0000000000000690 <.plt>:
     690:      	stp	x16, x30, [sp, #-0x10]!
     694:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1dd94>
     698:      	ldr	x17, [x16, #0xff8]
     69c:      	add	x16, x16, #0xff8
     6a0:      	br	x17
     6a4:      	nop
     6a8:      	nop
     6ac:      	nop

00000000000006b0 <strtoul@plt>:
     6b0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6b4:      	ldr	x17, [x16]
     6b8:      	add	x16, x16, #0x0
     6bc:      	br	x17

00000000000006c0 <__libc_start_main@plt>:
     6c0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6c4:      	ldr	x17, [x16, #0x8]
     6c8:      	add	x16, x16, #0x8
     6cc:      	br	x17

00000000000006d0 <__cxa_finalize@plt>:
     6d0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6d4:      	ldr	x17, [x16, #0x10]
     6d8:      	add	x16, x16, #0x10
     6dc:      	br	x17

00000000000006e0 <clock_gettime@plt>:
     6e0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6e4:      	ldr	x17, [x16, #0x18]
     6e8:      	add	x16, x16, #0x18
     6ec:      	br	x17

00000000000006f0 <__gmon_start__@plt>:
     6f0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6f4:      	ldr	x17, [x16, #0x20]
     6f8:      	add	x16, x16, #0x20
     6fc:      	br	x17

0000000000000700 <abort@plt>:
     700:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     704:      	ldr	x17, [x16, #0x28]
     708:      	add	x16, x16, #0x28
     70c:      	br	x17

0000000000000710 <__isoc99_scanf@plt>:
     710:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     714:      	ldr	x17, [x16, #0x30]
     718:      	add	x16, x16, #0x30
     71c:      	br	x17

0000000000000720 <printf@plt>:
     720:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     724:      	ldr	x17, [x16, #0x38]
     728:      	add	x16, x16, #0x38
     72c:      	br	x17

Disassembly of section .text:

0000000000000740 <_start>:
     740:      	nop
     744:      	mov	x29, #0x0               // =0
     748:      	mov	x30, #0x0               // =0
     74c:      	mov	x5, x0
     750:      	ldr	x1, [sp]
     754:      	add	x2, sp, #0x8
     758:      	mov	x6, sp
     75c:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1dd94>
     760:      	ldr	x0, [x0, #0xfd8]
     764:      	mov	x3, #0x0                // =0
     768:      	mov	x4, #0x0                // =0
     76c:      	bl	0x6c0 <__libc_start_main@plt>
     770:      	bl	0x700 <abort@plt>

0000000000000774 <call_weak_fn>:
     774:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1dd94>
     778:      	ldr	x0, [x0, #0xfd0]
     77c:      	cbz	x0, 0x784 <call_weak_fn+0x10>
     780:      	b	0x6f0 <__gmon_start__@plt>
     784:      	ret
     788:      	nop
     78c:      	nop

0000000000000790 <deregister_tm_clones>:
     790:      	adrp	x0, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     794:      	add	x0, x0, #0x50
     798:      	adrp	x1, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     79c:      	add	x1, x1, #0x50
     7a0:      	cmp	x1, x0
     7a4:      	b.eq	0x7bc <deregister_tm_clones+0x2c>
     7a8:      	adrp	x1, 0x1f000 <__FRAME_END__+0x1dd94>
     7ac:      	ldr	x1, [x1, #0xfc0]
     7b0:      	cbz	x1, 0x7bc <deregister_tm_clones+0x2c>
     7b4:      	mov	x16, x1
     7b8:      	br	x16
     7bc:      	ret

00000000000007c0 <register_tm_clones>:
     7c0:      	adrp	x0, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     7c4:      	add	x0, x0, #0x50
     7c8:      	adrp	x1, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     7cc:      	add	x1, x1, #0x50
     7d0:      	sub	x1, x1, x0
     7d4:      	lsr	x2, x1, #63
     7d8:      	add	x1, x2, x1, asr #3
     7dc:      	asr	x1, x1, #1
     7e0:      	cbz	x1, 0x7f8 <register_tm_clones+0x38>
     7e4:      	adrp	x2, 0x1f000 <__FRAME_END__+0x1dd94>
     7e8:      	ldr	x2, [x2, #0xfe0]
     7ec:      	cbz	x2, 0x7f8 <register_tm_clones+0x38>
     7f0:      	mov	x16, x2
     7f4:      	br	x16
     7f8:      	ret
     7fc:      	nop

0000000000000800 <__do_global_dtors_aux>:
     800:      	paciasp
     804:      	stp	x29, x30, [sp, #-0x20]!
     808:      	mov	x29, sp
     80c:      	str	x19, [sp, #0x10]
     810:      	adrp	x19, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     814:      	ldrb	w0, [x19, #0x50]
     818:      	tbnz	w0, #0x0, 0x840 <__do_global_dtors_aux+0x40>
     81c:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1dd94>
     820:      	ldr	x0, [x0, #0xfc8]
     824:      	cbz	x0, 0x834 <__do_global_dtors_aux+0x34>
     828:      	adrp	x0, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     82c:      	ldr	x0, [x0, #0x48]
     830:      	bl	0x6d0 <__cxa_finalize@plt>
     834:      	bl	0x790 <deregister_tm_clones>
     838:      	mov	w0, #0x1                // =1
     83c:      	strb	w0, [x19, #0x50]
     840:      	ldr	x19, [sp, #0x10]
     844:      	ldp	x29, x30, [sp], #0x20
     848:      	autiasp
     84c:      	ret

0000000000000850 <frame_dummy>:
     850:      	bti	c
     854:      	b	0x7c0 <register_tm_clones>

0000000000000858 <kernel>:
     858:      	sub	sp, sp, #0x1b0
     85c:      	str	x29, [sp, #0x1a0]
     860:      	str	w0, [sp, #0x19c]
     864:      	str	w1, [sp, #0x198]
     868:      	ldrh	w8, [sp, #0x19c]
     86c:      	str	w8, [sp, #0x194]
     870:      	ldr	w8, [sp, #0x19c]
     874:      	lsr	w8, w8, #16
     878:      	str	w8, [sp, #0x190]
     87c:      	ldrh	w8, [sp, #0x198]
     880:      	str	w8, [sp, #0x18c]
     884:      	ldr	w8, [sp, #0x198]
     888:      	lsr	w8, w8, #16
     88c:      	str	w8, [sp, #0x188]
     890:      	ldr	w8, [sp, #0x194]
     894:      	eor	w8, w8, #0xffff
     898:      	str	w8, [sp, #0x184]
     89c:      	ldr	w8, [sp, #0x190]
     8a0:      	eor	w8, w8, #0xffff
     8a4:      	str	w8, [sp, #0x180]
     8a8:      	ldrb	w8, [sp, #0x18c]
     8ac:      	str	w8, [sp, #0x17c]
     8b0:      	ldr	w8, [sp, #0x188]
     8b4:      	mov	w10, wzr
     8b8:      	and	w8, w8, w10
     8bc:      	str	w8, [sp, #0x178]
     8c0:      	ldr	w8, [sp, #0x184]
     8c4:      	ldr	w9, [sp, #0x17c]
     8c8:      	eor	w8, w8, w9
     8cc:      	str	w8, [sp, #0x174]
     8d0:      	ldr	w8, [sp, #0x180]
     8d4:      	ldr	w9, [sp, #0x178]
     8d8:      	eor	w8, w8, w9
     8dc:      	str	w8, [sp, #0x170]
     8e0:      	ldr	w8, [sp, #0x174]
     8e4:      	and	w8, w8, #0x1
     8e8:      	str	w8, [sp, #0x16c]
     8ec:      	ldr	w8, [sp, #0x170]
     8f0:      	and	w8, w8, w10
     8f4:      	str	w8, [sp, #0x168]
     8f8:      	ldr	w8, [sp, #0x16c]
     8fc:      	subs	w8, w10, w8
     900:      	cset	w8, lo
     904:      	str	w8, [sp, #0x164]
     908:      	ldr	w8, [sp, #0x16c]
     90c:      	subs	w8, w10, w8
     910:      	and	w8, w8, #0xffff
     914:      	str	w8, [sp, #0x160]
     918:      	ldr	w8, [sp, #0x168]
     91c:      	subs	w8, w10, w8
     920:      	ldr	w9, [sp, #0x164]
     924:      	subs	w8, w8, w9
     928:      	and	w8, w8, #0xffff
     92c:      	str	w8, [sp, #0x15c]
     930:      	ldr	w9, [sp, #0x174]
     934:      	ldr	w8, [sp, #0x170]
     938:      	lsl	w8, w8, #15
     93c:      	orr	w8, w8, w9, lsr #1
     940:      	and	w8, w8, #0xffff
     944:      	str	w8, [sp, #0x158]
     948:      	ldr	w8, [sp, #0x170]
     94c:      	lsr	w8, w8, #1
     950:      	str	w8, [sp, #0x154]
     954:      	ldr	w8, [sp, #0x160]
     958:      	mov	w9, #0x8320             // =33568
     95c:      	and	w8, w9, w8
     960:      	str	w8, [sp, #0x150]
     964:      	ldr	w11, [sp, #0x15c]
     968:      	mov	w8, #0xedb8             // =60856
     96c:      	and	w11, w8, w11
     970:      	str	w11, [sp, #0x14c]
     974:      	ldr	w11, [sp, #0x158]
     978:      	ldr	w12, [sp, #0x150]
     97c:      	eor	w11, w11, w12
     980:      	str	w11, [sp, #0x148]
     984:      	ldr	w11, [sp, #0x154]
     988:      	ldr	w12, [sp, #0x14c]
     98c:      	eor	w11, w11, w12
     990:      	str	w11, [sp, #0x144]
     994:      	ldr	w11, [sp, #0x148]
     998:      	and	w11, w11, #0x1
     99c:      	str	w11, [sp, #0x140]
     9a0:      	ldr	w11, [sp, #0x144]
     9a4:      	and	w11, w11, w10
     9a8:      	str	w11, [sp, #0x13c]
     9ac:      	ldr	w11, [sp, #0x140]
     9b0:      	subs	w11, w10, w11
     9b4:      	cset	w11, lo
     9b8:      	str	w11, [sp, #0x138]
     9bc:      	ldr	w11, [sp, #0x140]
     9c0:      	subs	w11, w10, w11
     9c4:      	and	w11, w11, #0xffff
     9c8:      	str	w11, [sp, #0x134]
     9cc:      	ldr	w11, [sp, #0x13c]
     9d0:      	subs	w11, w10, w11
     9d4:      	ldr	w12, [sp, #0x138]
     9d8:      	subs	w11, w11, w12
     9dc:      	and	w11, w11, #0xffff
     9e0:      	str	w11, [sp, #0x130]
     9e4:      	ldr	w12, [sp, #0x148]
     9e8:      	ldr	w11, [sp, #0x144]
     9ec:      	lsl	w11, w11, #15
     9f0:      	orr	w11, w11, w12, lsr #1
     9f4:      	and	w11, w11, #0xffff
     9f8:      	str	w11, [sp, #0x12c]
     9fc:      	ldr	w11, [sp, #0x144]
     a00:      	lsr	w11, w11, #1
     a04:      	str	w11, [sp, #0x128]
     a08:      	ldr	w11, [sp, #0x134]
     a0c:      	and	w11, w9, w11
     a10:      	str	w11, [sp, #0x124]
     a14:      	ldr	w11, [sp, #0x130]
     a18:      	and	w11, w8, w11
     a1c:      	str	w11, [sp, #0x120]
     a20:      	ldr	w11, [sp, #0x12c]
     a24:      	ldr	w12, [sp, #0x124]
     a28:      	eor	w11, w11, w12
     a2c:      	str	w11, [sp, #0x11c]
     a30:      	ldr	w11, [sp, #0x128]
     a34:      	ldr	w12, [sp, #0x120]
     a38:      	eor	w11, w11, w12
     a3c:      	str	w11, [sp, #0x118]
     a40:      	ldr	w11, [sp, #0x11c]
     a44:      	and	w11, w11, #0x1
     a48:      	str	w11, [sp, #0x114]
     a4c:      	ldr	w11, [sp, #0x118]
     a50:      	and	w11, w11, w10
     a54:      	str	w11, [sp, #0x110]
     a58:      	ldr	w11, [sp, #0x114]
     a5c:      	subs	w11, w10, w11
     a60:      	cset	w11, lo
     a64:      	str	w11, [sp, #0x10c]
     a68:      	ldr	w11, [sp, #0x114]
     a6c:      	subs	w11, w10, w11
     a70:      	and	w11, w11, #0xffff
     a74:      	str	w11, [sp, #0x108]
     a78:      	ldr	w11, [sp, #0x110]
     a7c:      	subs	w11, w10, w11
     a80:      	ldr	w12, [sp, #0x10c]
     a84:      	subs	w11, w11, w12
     a88:      	and	w11, w11, #0xffff
     a8c:      	str	w11, [sp, #0x104]
     a90:      	ldr	w12, [sp, #0x11c]
     a94:      	ldr	w11, [sp, #0x118]
     a98:      	lsl	w11, w11, #15
     a9c:      	orr	w11, w11, w12, lsr #1
     aa0:      	and	w11, w11, #0xffff
     aa4:      	str	w11, [sp, #0x100]
     aa8:      	ldr	w11, [sp, #0x118]
     aac:      	lsr	w11, w11, #1
     ab0:      	str	w11, [sp, #0xfc]
     ab4:      	ldr	w11, [sp, #0x108]
     ab8:      	and	w11, w9, w11
     abc:      	str	w11, [sp, #0xf8]
     ac0:      	ldr	w11, [sp, #0x104]
     ac4:      	and	w11, w8, w11
     ac8:      	str	w11, [sp, #0xf4]
     acc:      	ldr	w11, [sp, #0x100]
     ad0:      	ldr	w12, [sp, #0xf8]
     ad4:      	eor	w11, w11, w12
     ad8:      	str	w11, [sp, #0xf0]
     adc:      	ldr	w11, [sp, #0xfc]
     ae0:      	ldr	w12, [sp, #0xf4]
     ae4:      	eor	w11, w11, w12
     ae8:      	str	w11, [sp, #0xec]
     aec:      	ldr	w11, [sp, #0xf0]
     af0:      	and	w11, w11, #0x1
     af4:      	str	w11, [sp, #0xe8]
     af8:      	ldr	w11, [sp, #0xec]
     afc:      	and	w11, w11, w10
     b00:      	str	w11, [sp, #0xe4]
     b04:      	ldr	w11, [sp, #0xe8]
     b08:      	subs	w11, w10, w11
     b0c:      	cset	w11, lo
     b10:      	str	w11, [sp, #0xe0]
     b14:      	ldr	w11, [sp, #0xe8]
     b18:      	subs	w11, w10, w11
     b1c:      	and	w11, w11, #0xffff
     b20:      	str	w11, [sp, #0xdc]
     b24:      	ldr	w11, [sp, #0xe4]
     b28:      	subs	w11, w10, w11
     b2c:      	ldr	w12, [sp, #0xe0]
     b30:      	subs	w11, w11, w12
     b34:      	and	w11, w11, #0xffff
     b38:      	str	w11, [sp, #0xd8]
     b3c:      	ldr	w12, [sp, #0xf0]
     b40:      	ldr	w11, [sp, #0xec]
     b44:      	lsl	w11, w11, #15
     b48:      	orr	w11, w11, w12, lsr #1
     b4c:      	and	w11, w11, #0xffff
     b50:      	str	w11, [sp, #0xd4]
     b54:      	ldr	w11, [sp, #0xec]
     b58:      	lsr	w11, w11, #1
     b5c:      	str	w11, [sp, #0xd0]
     b60:      	ldr	w11, [sp, #0xdc]
     b64:      	and	w11, w9, w11
     b68:      	str	w11, [sp, #0xcc]
     b6c:      	ldr	w11, [sp, #0xd8]
     b70:      	and	w11, w8, w11
     b74:      	str	w11, [sp, #0xc8]
     b78:      	ldr	w11, [sp, #0xd4]
     b7c:      	ldr	w12, [sp, #0xcc]
     b80:      	eor	w11, w11, w12
     b84:      	str	w11, [sp, #0xc4]
     b88:      	ldr	w11, [sp, #0xd0]
     b8c:      	ldr	w12, [sp, #0xc8]
     b90:      	eor	w11, w11, w12
     b94:      	str	w11, [sp, #0xc0]
     b98:      	ldr	w11, [sp, #0xc4]
     b9c:      	and	w11, w11, #0x1
     ba0:      	str	w11, [sp, #0xbc]
     ba4:      	ldr	w11, [sp, #0xc0]
     ba8:      	and	w11, w11, w10
     bac:      	str	w11, [sp, #0xb8]
     bb0:      	ldr	w11, [sp, #0xbc]
     bb4:      	subs	w11, w10, w11
     bb8:      	cset	w11, lo
     bbc:      	str	w11, [sp, #0xb4]
     bc0:      	ldr	w11, [sp, #0xbc]
     bc4:      	subs	w11, w10, w11
     bc8:      	and	w11, w11, #0xffff
     bcc:      	str	w11, [sp, #0xb0]
     bd0:      	ldr	w11, [sp, #0xb8]
     bd4:      	subs	w11, w10, w11
     bd8:      	ldr	w12, [sp, #0xb4]
     bdc:      	subs	w11, w11, w12
     be0:      	and	w11, w11, #0xffff
     be4:      	str	w11, [sp, #0xac]
     be8:      	ldr	w12, [sp, #0xc4]
     bec:      	ldr	w11, [sp, #0xc0]
     bf0:      	lsl	w11, w11, #15
     bf4:      	orr	w11, w11, w12, lsr #1
     bf8:      	and	w11, w11, #0xffff
     bfc:      	str	w11, [sp, #0xa8]
     c00:      	ldr	w11, [sp, #0xc0]
     c04:      	lsr	w11, w11, #1
     c08:      	str	w11, [sp, #0xa4]
     c0c:      	ldr	w11, [sp, #0xb0]
     c10:      	and	w11, w9, w11
     c14:      	str	w11, [sp, #0xa0]
     c18:      	ldr	w11, [sp, #0xac]
     c1c:      	and	w11, w8, w11
     c20:      	str	w11, [sp, #0x9c]
     c24:      	ldr	w11, [sp, #0xa8]
     c28:      	ldr	w12, [sp, #0xa0]
     c2c:      	eor	w11, w11, w12
     c30:      	str	w11, [sp, #0x98]
     c34:      	ldr	w11, [sp, #0xa4]
     c38:      	ldr	w12, [sp, #0x9c]
     c3c:      	eor	w11, w11, w12
     c40:      	str	w11, [sp, #0x94]
     c44:      	ldr	w11, [sp, #0x98]
     c48:      	and	w11, w11, #0x1
     c4c:      	str	w11, [sp, #0x90]
     c50:      	ldr	w11, [sp, #0x94]
     c54:      	and	w11, w11, w10
     c58:      	str	w11, [sp, #0x8c]
     c5c:      	ldr	w11, [sp, #0x90]
     c60:      	subs	w11, w10, w11
     c64:      	cset	w11, lo
     c68:      	str	w11, [sp, #0x88]
     c6c:      	ldr	w11, [sp, #0x90]
     c70:      	subs	w11, w10, w11
     c74:      	and	w11, w11, #0xffff
     c78:      	str	w11, [sp, #0x84]
     c7c:      	ldr	w11, [sp, #0x8c]
     c80:      	subs	w11, w10, w11
     c84:      	ldr	w12, [sp, #0x88]
     c88:      	subs	w11, w11, w12
     c8c:      	and	w11, w11, #0xffff
     c90:      	str	w11, [sp, #0x80]
     c94:      	ldr	w12, [sp, #0x98]
     c98:      	ldr	w11, [sp, #0x94]
     c9c:      	lsl	w11, w11, #15
     ca0:      	orr	w11, w11, w12, lsr #1
     ca4:      	and	w11, w11, #0xffff
     ca8:      	str	w11, [sp, #0x7c]
     cac:      	ldr	w11, [sp, #0x94]
     cb0:      	lsr	w11, w11, #1
     cb4:      	str	w11, [sp, #0x78]
     cb8:      	ldr	w11, [sp, #0x84]
     cbc:      	and	w11, w9, w11
     cc0:      	str	w11, [sp, #0x74]
     cc4:      	ldr	w11, [sp, #0x80]
     cc8:      	and	w11, w8, w11
     ccc:      	str	w11, [sp, #0x70]
     cd0:      	ldr	w11, [sp, #0x7c]
     cd4:      	ldr	w12, [sp, #0x74]
     cd8:      	eor	w11, w11, w12
     cdc:      	str	w11, [sp, #0x6c]
     ce0:      	ldr	w11, [sp, #0x78]
     ce4:      	ldr	w12, [sp, #0x70]
     ce8:      	eor	w11, w11, w12
     cec:      	str	w11, [sp, #0x68]
     cf0:      	ldr	w11, [sp, #0x6c]
     cf4:      	and	w11, w11, #0x1
     cf8:      	str	w11, [sp, #0x64]
     cfc:      	ldr	w11, [sp, #0x68]
     d00:      	and	w11, w11, w10
     d04:      	str	w11, [sp, #0x60]
     d08:      	ldr	w11, [sp, #0x64]
     d0c:      	subs	w11, w10, w11
     d10:      	cset	w11, lo
     d14:      	str	w11, [sp, #0x5c]
     d18:      	ldr	w11, [sp, #0x64]
     d1c:      	subs	w11, w10, w11
     d20:      	and	w11, w11, #0xffff
     d24:      	str	w11, [sp, #0x58]
     d28:      	ldr	w11, [sp, #0x60]
     d2c:      	subs	w11, w10, w11
     d30:      	ldr	w12, [sp, #0x5c]
     d34:      	subs	w11, w11, w12
     d38:      	and	w11, w11, #0xffff
     d3c:      	str	w11, [sp, #0x54]
     d40:      	ldr	w12, [sp, #0x6c]
     d44:      	ldr	w11, [sp, #0x68]
     d48:      	lsl	w11, w11, #15
     d4c:      	orr	w11, w11, w12, lsr #1
     d50:      	and	w11, w11, #0xffff
     d54:      	str	w11, [sp, #0x50]
     d58:      	ldr	w11, [sp, #0x68]
     d5c:      	lsr	w11, w11, #1
     d60:      	str	w11, [sp, #0x4c]
     d64:      	ldr	w11, [sp, #0x58]
     d68:      	and	w11, w9, w11
     d6c:      	str	w11, [sp, #0x48]
     d70:      	ldr	w11, [sp, #0x54]
     d74:      	and	w11, w8, w11
     d78:      	str	w11, [sp, #0x44]
     d7c:      	ldr	w11, [sp, #0x50]
     d80:      	ldr	w12, [sp, #0x48]
     d84:      	eor	w11, w11, w12
     d88:      	str	w11, [sp, #0x40]
     d8c:      	ldr	w11, [sp, #0x4c]
     d90:      	ldr	w12, [sp, #0x44]
     d94:      	eor	w11, w11, w12
     d98:      	str	w11, [sp, #0x3c]
     d9c:      	ldr	w11, [sp, #0x40]
     da0:      	and	w11, w11, #0x1
     da4:      	str	w11, [sp, #0x38]
     da8:      	ldr	w11, [sp, #0x3c]
     dac:      	and	w11, w11, w10
     db0:      	str	w11, [sp, #0x34]
     db4:      	ldr	w11, [sp, #0x38]
     db8:      	subs	w11, w10, w11
     dbc:      	cset	w11, lo
     dc0:      	str	w11, [sp, #0x30]
     dc4:      	ldr	w11, [sp, #0x38]
     dc8:      	subs	w11, w10, w11
     dcc:      	and	w11, w11, #0xffff
     dd0:      	str	w11, [sp, #0x2c]
     dd4:      	ldr	w11, [sp, #0x34]
     dd8:      	subs	w10, w10, w11
     ddc:      	ldr	w11, [sp, #0x30]
     de0:      	subs	w10, w10, w11
     de4:      	and	w10, w10, #0xffff
     de8:      	str	w10, [sp, #0x28]
     dec:      	ldr	w11, [sp, #0x40]
     df0:      	ldr	w10, [sp, #0x3c]
     df4:      	lsl	w10, w10, #15
     df8:      	orr	w10, w10, w11, lsr #1
     dfc:      	and	w10, w10, #0xffff
     e00:      	str	w10, [sp, #0x24]
     e04:      	ldr	w10, [sp, #0x3c]
     e08:      	lsr	w10, w10, #1
     e0c:      	str	w10, [sp, #0x20]
     e10:      	ldr	w10, [sp, #0x2c]
     e14:      	and	w9, w9, w10
     e18:      	str	w9, [sp, #0x1c]
     e1c:      	ldr	w9, [sp, #0x28]
     e20:      	and	w8, w8, w9
     e24:      	str	w8, [sp, #0x18]
     e28:      	ldr	w8, [sp, #0x24]
     e2c:      	ldr	w9, [sp, #0x1c]
     e30:      	eor	w8, w8, w9
     e34:      	str	w8, [sp, #0x14]
     e38:      	ldr	w8, [sp, #0x20]
     e3c:      	ldr	w9, [sp, #0x18]
     e40:      	eor	w8, w8, w9
     e44:      	str	w8, [sp, #0x10]
     e48:      	ldr	w8, [sp, #0x14]
     e4c:      	eor	w8, w8, #0xffff
     e50:      	str	w8, [sp, #0xc]
     e54:      	ldr	w8, [sp, #0x10]
     e58:      	eor	w8, w8, #0xffff
     e5c:      	str	w8, [sp, #0x8]
     e60:      	ldr	w8, [sp, #0xc]
     e64:      	ldr	w9, [sp, #0x8]
     e68:      	orr	w8, w8, w9, lsl #16
     e6c:      	str	w8, [sp, #0x4]
     e70:      	ldr	w0, [sp, #0x4]
     e74:      	ldr	x29, [sp, #0x1a0]
     e78:      	add	sp, sp, #0x1b0
     e7c:      	ret

0000000000000e80 <main>:
     e80:      	sub	sp, sp, #0x90
     e84:      	stp	x29, x30, [sp, #0x80]
     e88:      	add	x29, sp, #0x80
     e8c:      	stur	wzr, [x29, #-0x4]
     e90:      	stur	w0, [x29, #-0x8]
     e94:      	stur	x1, [x29, #-0x10]
     e98:      	ldur	w8, [x29, #-0x8]
     e9c:      	subs	w8, w8, #0x1
     ea0:      	b.ne	0xef4 <main+0x74>
     ea4:      	b	0xea8 <main+0x28>
     ea8:      	b	0xeac <main+0x2c>
     eac:      	sub	x1, x29, #0x18
     eb0:      	add	x2, x1, #0x4
     eb4:      	adrp	x0, 0x1000 <main+0x180>
     eb8:      	add	x0, x0, #0x100
     ebc:      	bl	0x710 <__isoc99_scanf@plt>
     ec0:      	subs	w8, w0, #0x2
     ec4:      	b.ne	0xeec <main+0x6c>
     ec8:      	b	0xecc <main+0x4c>
     ecc:      	ldur	w0, [x29, #-0x18]
     ed0:      	ldur	w1, [x29, #-0x14]
     ed4:      	bl	0x858 <kernel>
     ed8:      	mov	w1, w0
     edc:      	adrp	x0, 0x1000 <main+0x180>
     ee0:      	add	x0, x0, #0x105
     ee4:      	bl	0x720 <printf@plt>
     ee8:      	b	0xeac <main+0x2c>
     eec:      	stur	wzr, [x29, #-0x4]
     ef0:      	b	0x1068 <main+0x1e8>
     ef4:      	ldur	w8, [x29, #-0x8]
     ef8:      	subs	w8, w8, #0x3
     efc:      	b.eq	0xf10 <main+0x90>
     f00:      	b	0xf04 <main+0x84>
     f04:      	mov	w8, #0x3                // =3
     f08:      	stur	w8, [x29, #-0x4]
     f0c:      	b	0x1068 <main+0x1e8>
     f10:      	ldur	x8, [x29, #-0x10]
     f14:      	ldr	x0, [x8, #0x8]
     f18:      	mov	x1, xzr
     f1c:      	str	x1, [sp, #0x8]
     f20:      	mov	w2, #0xa                // =10
     f24:      	str	w2, [sp, #0x14]
     f28:      	bl	0x6b0 <strtoul@plt>
     f2c:      	ldr	x1, [sp, #0x8]
     f30:      	ldr	w2, [sp, #0x14]
     f34:      	stur	x0, [x29, #-0x20]
     f38:      	ldur	x8, [x29, #-0x10]
     f3c:      	ldr	x0, [x8, #0x10]
     f40:      	bl	0x6b0 <strtoul@plt>
     f44:      	mov	w8, w0
     f48:      	stur	w8, [x29, #-0x24]
     f4c:      	stur	xzr, [x29, #-0x30]
     f50:      	mov	w0, #0x1                // =1
     f54:      	add	x1, sp, #0x40
     f58:      	bl	0x6e0 <clock_gettime@plt>
     f5c:      	cbz	w0, 0xf70 <main+0xf0>
     f60:      	b	0xf64 <main+0xe4>
     f64:      	mov	w8, #0x2                // =2
     f68:      	stur	w8, [x29, #-0x4]
     f6c:      	b	0x1068 <main+0x1e8>
     f70:      	str	xzr, [sp, #0x28]
     f74:      	b	0xf78 <main+0xf8>
     f78:      	ldr	x8, [sp, #0x28]
     f7c:      	ldur	x9, [x29, #-0x20]
     f80:      	subs	x8, x8, x9
     f84:      	b.hs	0xffc <main+0x17c>
     f88:      	b	0xf8c <main+0x10c>
     f8c:      	str	wzr, [sp, #0x24]
     f90:      	b	0xf94 <main+0x114>
     f94:      	ldr	w8, [sp, #0x24]
     f98:      	subs	w8, w8, #0x2
     f9c:      	b.hs	0xfd0 <main+0x150>
     fa0:      	b	0xfa4 <main+0x124>
     fa4:      	sub	x0, x29, #0x24
     fa8:      	bl	0x1078 <csrd_matrix_next_value>
     fac:      	ldr	w8, [sp, #0x24]
     fb0:      	mov	w9, w8
     fb4:      	sub	x8, x29, #0x18
     fb8:      	str	w0, [x8, x9, lsl #2]
     fbc:      	b	0xfc0 <main+0x140>
     fc0:      	ldr	w8, [sp, #0x24]
     fc4:      	add	w8, w8, #0x1
     fc8:      	str	w8, [sp, #0x24]
     fcc:      	b	0xf94 <main+0x114>
     fd0:      	ldur	w0, [x29, #-0x18]
     fd4:      	ldur	w1, [x29, #-0x14]
     fd8:      	bl	0x858 <kernel>
     fdc:      	ldur	x8, [x29, #-0x30]
     fe0:      	add	x8, x8, w0, uxtw
     fe4:      	stur	x8, [x29, #-0x30]
     fe8:      	b	0xfec <main+0x16c>
     fec:      	ldr	x8, [sp, #0x28]
     ff0:      	add	x8, x8, #0x1
     ff4:      	str	x8, [sp, #0x28]
     ff8:      	b	0xf78 <main+0xf8>
     ffc:      	mov	w0, #0x1                // =1
    1000:      	add	x1, sp, #0x30
    1004:      	bl	0x6e0 <clock_gettime@plt>
    1008:      	cbz	w0, 0x101c <main+0x19c>
    100c:      	b	0x1010 <main+0x190>
    1010:      	mov	w8, #0x2                // =2
    1014:      	stur	w8, [x29, #-0x4]
    1018:      	b	0x1068 <main+0x1e8>
    101c:      	ldr	x8, [sp, #0x30]
    1020:      	ldr	x9, [sp, #0x40]
    1024:      	subs	x8, x8, x9
    1028:      	scvtf	d2, x8
    102c:      	ldr	x8, [sp, #0x38]
    1030:      	ldr	x9, [sp, #0x48]
    1034:      	subs	x8, x8, x9
    1038:      	scvtf	d0, x8
    103c:      	adrp	x8, 0x1000 <main+0x180>
    1040:      	ldr	d1, [x8, #0xf8]
    1044:      	fmadd	d0, d0, d1, d2
    1048:      	str	d0, [sp, #0x18]
    104c:      	ldr	d0, [sp, #0x18]
    1050:      	ldur	x1, [x29, #-0x30]
    1054:      	adrp	x0, 0x1000 <main+0x180>
    1058:      	add	x0, x0, #0x109
    105c:      	bl	0x720 <printf@plt>
    1060:      	stur	wzr, [x29, #-0x4]
    1064:      	b	0x1068 <main+0x1e8>
    1068:      	ldur	w0, [x29, #-0x4]
    106c:      	ldp	x29, x30, [sp, #0x80]
    1070:      	add	sp, sp, #0x90
    1074:      	ret

0000000000001078 <csrd_matrix_next_value>:
    1078:      	sub	sp, sp, #0x10
    107c:      	str	x0, [sp, #0x8]
    1080:      	ldr	x8, [sp, #0x8]
    1084:      	ldr	w10, [x8]
    1088:      	ldr	x9, [sp, #0x8]
    108c:      	ldr	w8, [x9]
    1090:      	eor	w8, w8, w10, lsl #13
    1094:      	str	w8, [x9]
    1098:      	ldr	x8, [sp, #0x8]
    109c:      	ldr	w10, [x8]
    10a0:      	ldr	x9, [sp, #0x8]
    10a4:      	ldr	w8, [x9]
    10a8:      	eor	w8, w8, w10, lsr #17
    10ac:      	str	w8, [x9]
    10b0:      	ldr	x8, [sp, #0x8]
    10b4:      	ldr	w10, [x8]
    10b8:      	ldr	x9, [sp, #0x8]
    10bc:      	ldr	w8, [x9]
    10c0:      	eor	w8, w8, w10, lsl #5
    10c4:      	str	w8, [x9]
    10c8:      	ldr	x8, [sp, #0x8]
    10cc:      	ldr	w0, [x8]
    10d0:      	add	sp, sp, #0x10
    10d4:      	ret

Disassembly of section .fini:

00000000000010d8 <_fini>:
    10d8:      	nop
    10dc:      	stp	x29, x30, [sp, #-0x10]!
    10e0:      	mov	x29, sp
    10e4:      	ldp	x29, x30, [sp], #0x10
    10e8:      	ret
