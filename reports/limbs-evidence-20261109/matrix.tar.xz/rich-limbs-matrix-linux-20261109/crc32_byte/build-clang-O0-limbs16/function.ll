; ModuleID = '/work/experiments/runs/rich-limbs-matrix-linux-20261109/crc32_byte/build-clang-O0-limbs16/validation/compiler-0-O0/candidate.i'
source_filename = "/work/experiments/runs/rich-limbs-matrix-linux-20261109/crc32_byte/build-clang-O0-limbs16/validation/compiler-0-O0/candidate.i"
target datalayout = "e-m:e-i8:8:32-i16:16:32-i64:64-i128:128-n32:64-S128"
target triple = "aarch64-unknown-linux-gnu"

; Function Attrs: noinline nounwind optnone uwtable
define dso_local i32 @kernel(i32 noundef %0, i32 noundef %1) #0 {
  %3 = alloca i32, align 4
  %4 = alloca i32, align 4
  %5 = alloca i32, align 4
  %6 = alloca i32, align 4
  %7 = alloca i32, align 4
  %8 = alloca i32, align 4
  %9 = alloca i32, align 4
  %10 = alloca i32, align 4
  %11 = alloca i32, align 4
  %12 = alloca i32, align 4
  %13 = alloca i32, align 4
  %14 = alloca i32, align 4
  %15 = alloca i32, align 4
  %16 = alloca i32, align 4
  %17 = alloca i32, align 4
  %18 = alloca i32, align 4
  %19 = alloca i32, align 4
  %20 = alloca i32, align 4
  %21 = alloca i32, align 4
  %22 = alloca i32, align 4
  %23 = alloca i32, align 4
  %24 = alloca i32, align 4
  %25 = alloca i32, align 4
  %26 = alloca i32, align 4
  %27 = alloca i32, align 4
  %28 = alloca i32, align 4
  %29 = alloca i32, align 4
  %30 = alloca i32, align 4
  %31 = alloca i32, align 4
  %32 = alloca i32, align 4
  %33 = alloca i32, align 4
  %34 = alloca i32, align 4
  %35 = alloca i32, align 4
  %36 = alloca i32, align 4
  %37 = alloca i32, align 4
  %38 = alloca i32, align 4
  %39 = alloca i32, align 4
  %40 = alloca i32, align 4
  %41 = alloca i32, align 4
  %42 = alloca i32, align 4
  %43 = alloca i32, align 4
  %44 = alloca i32, align 4
  %45 = alloca i32, align 4
  %46 = alloca i32, align 4
  %47 = alloca i32, align 4
  %48 = alloca i32, align 4
  %49 = alloca i32, align 4
  %50 = alloca i32, align 4
  %51 = alloca i32, align 4
  %52 = alloca i32, align 4
  %53 = alloca i32, align 4
  %54 = alloca i32, align 4
  %55 = alloca i32, align 4
  %56 = alloca i32, align 4
  %57 = alloca i32, align 4
  %58 = alloca i32, align 4
  %59 = alloca i32, align 4
  %60 = alloca i32, align 4
  %61 = alloca i32, align 4
  %62 = alloca i32, align 4
  %63 = alloca i32, align 4
  %64 = alloca i32, align 4
  %65 = alloca i32, align 4
  %66 = alloca i32, align 4
  %67 = alloca i32, align 4
  %68 = alloca i32, align 4
  %69 = alloca i32, align 4
  %70 = alloca i32, align 4
  %71 = alloca i32, align 4
  %72 = alloca i32, align 4
  %73 = alloca i32, align 4
  %74 = alloca i32, align 4
  %75 = alloca i32, align 4
  %76 = alloca i32, align 4
  %77 = alloca i32, align 4
  %78 = alloca i32, align 4
  %79 = alloca i32, align 4
  %80 = alloca i32, align 4
  %81 = alloca i32, align 4
  %82 = alloca i32, align 4
  %83 = alloca i32, align 4
  %84 = alloca i32, align 4
  %85 = alloca i32, align 4
  %86 = alloca i32, align 4
  %87 = alloca i32, align 4
  %88 = alloca i32, align 4
  %89 = alloca i32, align 4
  %90 = alloca i32, align 4
  %91 = alloca i32, align 4
  %92 = alloca i32, align 4
  %93 = alloca i32, align 4
  %94 = alloca i32, align 4
  %95 = alloca i32, align 4
  %96 = alloca i32, align 4
  %97 = alloca i32, align 4
  %98 = alloca i32, align 4
  %99 = alloca i32, align 4
  %100 = alloca i32, align 4
  %101 = alloca i32, align 4
  %102 = alloca i32, align 4
  %103 = alloca i32, align 4
  %104 = alloca i32, align 4
  %105 = alloca i32, align 4
  store i32 %0, ptr %3, align 4
  store i32 %1, ptr %4, align 4
  %106 = load i32, ptr %3, align 4
  %107 = and i32 %106, 65535
  store i32 %107, ptr %5, align 4
  %108 = load i32, ptr %5, align 4
  %109 = load i32, ptr %3, align 4
  %110 = lshr i32 %109, 16
  store i32 %110, ptr %6, align 4
  %111 = load i32, ptr %6, align 4
  %112 = load i32, ptr %4, align 4
  %113 = and i32 %112, 65535
  store i32 %113, ptr %7, align 4
  %114 = load i32, ptr %7, align 4
  %115 = load i32, ptr %4, align 4
  %116 = lshr i32 %115, 16
  store i32 %116, ptr %8, align 4
  %117 = load i32, ptr %8, align 4
  %118 = load i32, ptr %5, align 4
  %119 = xor i32 %118, 65535
  store i32 %119, ptr %9, align 4
  %120 = load i32, ptr %9, align 4
  %121 = load i32, ptr %6, align 4
  %122 = xor i32 %121, 65535
  store i32 %122, ptr %10, align 4
  %123 = load i32, ptr %10, align 4
  %124 = load i32, ptr %7, align 4
  %125 = and i32 %124, 255
  store i32 %125, ptr %11, align 4
  %126 = load i32, ptr %11, align 4
  %127 = load i32, ptr %8, align 4
  %128 = and i32 %127, 0
  store i32 %128, ptr %12, align 4
  %129 = load i32, ptr %12, align 4
  %130 = load i32, ptr %9, align 4
  %131 = load i32, ptr %11, align 4
  %132 = xor i32 %130, %131
  store i32 %132, ptr %13, align 4
  %133 = load i32, ptr %13, align 4
  %134 = load i32, ptr %10, align 4
  %135 = load i32, ptr %12, align 4
  %136 = xor i32 %134, %135
  store i32 %136, ptr %14, align 4
  %137 = load i32, ptr %14, align 4
  %138 = load i32, ptr %13, align 4
  %139 = and i32 %138, 1
  store i32 %139, ptr %15, align 4
  %140 = load i32, ptr %15, align 4
  %141 = load i32, ptr %14, align 4
  %142 = and i32 %141, 0
  store i32 %142, ptr %16, align 4
  %143 = load i32, ptr %16, align 4
  %144 = load i32, ptr %15, align 4
  %145 = icmp ult i32 0, %144
  %146 = zext i1 %145 to i32
  store i32 %146, ptr %17, align 4
  %147 = load i32, ptr %17, align 4
  %148 = load i32, ptr %15, align 4
  %149 = sub i32 0, %148
  %150 = and i32 %149, 65535
  store i32 %150, ptr %18, align 4
  %151 = load i32, ptr %18, align 4
  %152 = load i32, ptr %16, align 4
  %153 = sub i32 0, %152
  %154 = load i32, ptr %17, align 4
  %155 = sub i32 %153, %154
  %156 = and i32 %155, 65535
  store i32 %156, ptr %19, align 4
  %157 = load i32, ptr %19, align 4
  %158 = load i32, ptr %13, align 4
  %159 = lshr i32 %158, 1
  %160 = load i32, ptr %14, align 4
  %161 = shl i32 %160, 15
  %162 = or i32 %159, %161
  %163 = and i32 %162, 65535
  store i32 %163, ptr %20, align 4
  %164 = load i32, ptr %20, align 4
  %165 = load i32, ptr %14, align 4
  %166 = lshr i32 %165, 1
  store i32 %166, ptr %21, align 4
  %167 = load i32, ptr %21, align 4
  %168 = load i32, ptr %18, align 4
  %169 = and i32 33568, %168
  store i32 %169, ptr %22, align 4
  %170 = load i32, ptr %22, align 4
  %171 = load i32, ptr %19, align 4
  %172 = and i32 60856, %171
  store i32 %172, ptr %23, align 4
  %173 = load i32, ptr %23, align 4
  %174 = load i32, ptr %20, align 4
  %175 = load i32, ptr %22, align 4
  %176 = xor i32 %174, %175
  store i32 %176, ptr %24, align 4
  %177 = load i32, ptr %24, align 4
  %178 = load i32, ptr %21, align 4
  %179 = load i32, ptr %23, align 4
  %180 = xor i32 %178, %179
  store i32 %180, ptr %25, align 4
  %181 = load i32, ptr %25, align 4
  %182 = load i32, ptr %24, align 4
  %183 = and i32 %182, 1
  store i32 %183, ptr %26, align 4
  %184 = load i32, ptr %26, align 4
  %185 = load i32, ptr %25, align 4
  %186 = and i32 %185, 0
  store i32 %186, ptr %27, align 4
  %187 = load i32, ptr %27, align 4
  %188 = load i32, ptr %26, align 4
  %189 = icmp ult i32 0, %188
  %190 = zext i1 %189 to i32
  store i32 %190, ptr %28, align 4
  %191 = load i32, ptr %28, align 4
  %192 = load i32, ptr %26, align 4
  %193 = sub i32 0, %192
  %194 = and i32 %193, 65535
  store i32 %194, ptr %29, align 4
  %195 = load i32, ptr %29, align 4
  %196 = load i32, ptr %27, align 4
  %197 = sub i32 0, %196
  %198 = load i32, ptr %28, align 4
  %199 = sub i32 %197, %198
  %200 = and i32 %199, 65535
  store i32 %200, ptr %30, align 4
  %201 = load i32, ptr %30, align 4
  %202 = load i32, ptr %24, align 4
  %203 = lshr i32 %202, 1
  %204 = load i32, ptr %25, align 4
  %205 = shl i32 %204, 15
  %206 = or i32 %203, %205
  %207 = and i32 %206, 65535
  store i32 %207, ptr %31, align 4
  %208 = load i32, ptr %31, align 4
  %209 = load i32, ptr %25, align 4
  %210 = lshr i32 %209, 1
  store i32 %210, ptr %32, align 4
  %211 = load i32, ptr %32, align 4
  %212 = load i32, ptr %29, align 4
  %213 = and i32 33568, %212
  store i32 %213, ptr %33, align 4
  %214 = load i32, ptr %33, align 4
  %215 = load i32, ptr %30, align 4
  %216 = and i32 60856, %215
  store i32 %216, ptr %34, align 4
  %217 = load i32, ptr %34, align 4
  %218 = load i32, ptr %31, align 4
  %219 = load i32, ptr %33, align 4
  %220 = xor i32 %218, %219
  store i32 %220, ptr %35, align 4
  %221 = load i32, ptr %35, align 4
  %222 = load i32, ptr %32, align 4
  %223 = load i32, ptr %34, align 4
  %224 = xor i32 %222, %223
  store i32 %224, ptr %36, align 4
  %225 = load i32, ptr %36, align 4
  %226 = load i32, ptr %35, align 4
  %227 = and i32 %226, 1
  store i32 %227, ptr %37, align 4
  %228 = load i32, ptr %37, align 4
  %229 = load i32, ptr %36, align 4
  %230 = and i32 %229, 0
  store i32 %230, ptr %38, align 4
  %231 = load i32, ptr %38, align 4
  %232 = load i32, ptr %37, align 4
  %233 = icmp ult i32 0, %232
  %234 = zext i1 %233 to i32
  store i32 %234, ptr %39, align 4
  %235 = load i32, ptr %39, align 4
  %236 = load i32, ptr %37, align 4
  %237 = sub i32 0, %236
  %238 = and i32 %237, 65535
  store i32 %238, ptr %40, align 4
  %239 = load i32, ptr %40, align 4
  %240 = load i32, ptr %38, align 4
  %241 = sub i32 0, %240
  %242 = load i32, ptr %39, align 4
  %243 = sub i32 %241, %242
  %244 = and i32 %243, 65535
  store i32 %244, ptr %41, align 4
  %245 = load i32, ptr %41, align 4
  %246 = load i32, ptr %35, align 4
  %247 = lshr i32 %246, 1
  %248 = load i32, ptr %36, align 4
  %249 = shl i32 %248, 15
  %250 = or i32 %247, %249
  %251 = and i32 %250, 65535
  store i32 %251, ptr %42, align 4
  %252 = load i32, ptr %42, align 4
  %253 = load i32, ptr %36, align 4
  %254 = lshr i32 %253, 1
  store i32 %254, ptr %43, align 4
  %255 = load i32, ptr %43, align 4
  %256 = load i32, ptr %40, align 4
  %257 = and i32 33568, %256
  store i32 %257, ptr %44, align 4
  %258 = load i32, ptr %44, align 4
  %259 = load i32, ptr %41, align 4
  %260 = and i32 60856, %259
  store i32 %260, ptr %45, align 4
  %261 = load i32, ptr %45, align 4
  %262 = load i32, ptr %42, align 4
  %263 = load i32, ptr %44, align 4
  %264 = xor i32 %262, %263
  store i32 %264, ptr %46, align 4
  %265 = load i32, ptr %46, align 4
  %266 = load i32, ptr %43, align 4
  %267 = load i32, ptr %45, align 4
  %268 = xor i32 %266, %267
  store i32 %268, ptr %47, align 4
  %269 = load i32, ptr %47, align 4
  %270 = load i32, ptr %46, align 4
  %271 = and i32 %270, 1
  store i32 %271, ptr %48, align 4
  %272 = load i32, ptr %48, align 4
  %273 = load i32, ptr %47, align 4
  %274 = and i32 %273, 0
  store i32 %274, ptr %49, align 4
  %275 = load i32, ptr %49, align 4
  %276 = load i32, ptr %48, align 4
  %277 = icmp ult i32 0, %276
  %278 = zext i1 %277 to i32
  store i32 %278, ptr %50, align 4
  %279 = load i32, ptr %50, align 4
  %280 = load i32, ptr %48, align 4
  %281 = sub i32 0, %280
  %282 = and i32 %281, 65535
  store i32 %282, ptr %51, align 4
  %283 = load i32, ptr %51, align 4
  %284 = load i32, ptr %49, align 4
  %285 = sub i32 0, %284
  %286 = load i32, ptr %50, align 4
  %287 = sub i32 %285, %286
  %288 = and i32 %287, 65535
  store i32 %288, ptr %52, align 4
  %289 = load i32, ptr %52, align 4
  %290 = load i32, ptr %46, align 4
  %291 = lshr i32 %290, 1
  %292 = load i32, ptr %47, align 4
  %293 = shl i32 %292, 15
  %294 = or i32 %291, %293
  %295 = and i32 %294, 65535
  store i32 %295, ptr %53, align 4
  %296 = load i32, ptr %53, align 4
  %297 = load i32, ptr %47, align 4
  %298 = lshr i32 %297, 1
  store i32 %298, ptr %54, align 4
  %299 = load i32, ptr %54, align 4
  %300 = load i32, ptr %51, align 4
  %301 = and i32 33568, %300
  store i32 %301, ptr %55, align 4
  %302 = load i32, ptr %55, align 4
  %303 = load i32, ptr %52, align 4
  %304 = and i32 60856, %303
  store i32 %304, ptr %56, align 4
  %305 = load i32, ptr %56, align 4
  %306 = load i32, ptr %53, align 4
  %307 = load i32, ptr %55, align 4
  %308 = xor i32 %306, %307
  store i32 %308, ptr %57, align 4
  %309 = load i32, ptr %57, align 4
  %310 = load i32, ptr %54, align 4
  %311 = load i32, ptr %56, align 4
  %312 = xor i32 %310, %311
  store i32 %312, ptr %58, align 4
  %313 = load i32, ptr %58, align 4
  %314 = load i32, ptr %57, align 4
  %315 = and i32 %314, 1
  store i32 %315, ptr %59, align 4
  %316 = load i32, ptr %59, align 4
  %317 = load i32, ptr %58, align 4
  %318 = and i32 %317, 0
  store i32 %318, ptr %60, align 4
  %319 = load i32, ptr %60, align 4
  %320 = load i32, ptr %59, align 4
  %321 = icmp ult i32 0, %320
  %322 = zext i1 %321 to i32
  store i32 %322, ptr %61, align 4
  %323 = load i32, ptr %61, align 4
  %324 = load i32, ptr %59, align 4
  %325 = sub i32 0, %324
  %326 = and i32 %325, 65535
  store i32 %326, ptr %62, align 4
  %327 = load i32, ptr %62, align 4
  %328 = load i32, ptr %60, align 4
  %329 = sub i32 0, %328
  %330 = load i32, ptr %61, align 4
  %331 = sub i32 %329, %330
  %332 = and i32 %331, 65535
  store i32 %332, ptr %63, align 4
  %333 = load i32, ptr %63, align 4
  %334 = load i32, ptr %57, align 4
  %335 = lshr i32 %334, 1
  %336 = load i32, ptr %58, align 4
  %337 = shl i32 %336, 15
  %338 = or i32 %335, %337
  %339 = and i32 %338, 65535
  store i32 %339, ptr %64, align 4
  %340 = load i32, ptr %64, align 4
  %341 = load i32, ptr %58, align 4
  %342 = lshr i32 %341, 1
  store i32 %342, ptr %65, align 4
  %343 = load i32, ptr %65, align 4
  %344 = load i32, ptr %62, align 4
  %345 = and i32 33568, %344
  store i32 %345, ptr %66, align 4
  %346 = load i32, ptr %66, align 4
  %347 = load i32, ptr %63, align 4
  %348 = and i32 60856, %347
  store i32 %348, ptr %67, align 4
  %349 = load i32, ptr %67, align 4
  %350 = load i32, ptr %64, align 4
  %351 = load i32, ptr %66, align 4
  %352 = xor i32 %350, %351
  store i32 %352, ptr %68, align 4
  %353 = load i32, ptr %68, align 4
  %354 = load i32, ptr %65, align 4
  %355 = load i32, ptr %67, align 4
  %356 = xor i32 %354, %355
  store i32 %356, ptr %69, align 4
  %357 = load i32, ptr %69, align 4
  %358 = load i32, ptr %68, align 4
  %359 = and i32 %358, 1
  store i32 %359, ptr %70, align 4
  %360 = load i32, ptr %70, align 4
  %361 = load i32, ptr %69, align 4
  %362 = and i32 %361, 0
  store i32 %362, ptr %71, align 4
  %363 = load i32, ptr %71, align 4
  %364 = load i32, ptr %70, align 4
  %365 = icmp ult i32 0, %364
  %366 = zext i1 %365 to i32
  store i32 %366, ptr %72, align 4
  %367 = load i32, ptr %72, align 4
  %368 = load i32, ptr %70, align 4
  %369 = sub i32 0, %368
  %370 = and i32 %369, 65535
  store i32 %370, ptr %73, align 4
  %371 = load i32, ptr %73, align 4
  %372 = load i32, ptr %71, align 4
  %373 = sub i32 0, %372
  %374 = load i32, ptr %72, align 4
  %375 = sub i32 %373, %374
  %376 = and i32 %375, 65535
  store i32 %376, ptr %74, align 4
  %377 = load i32, ptr %74, align 4
  %378 = load i32, ptr %68, align 4
  %379 = lshr i32 %378, 1
  %380 = load i32, ptr %69, align 4
  %381 = shl i32 %380, 15
  %382 = or i32 %379, %381
  %383 = and i32 %382, 65535
  store i32 %383, ptr %75, align 4
  %384 = load i32, ptr %75, align 4
  %385 = load i32, ptr %69, align 4
  %386 = lshr i32 %385, 1
  store i32 %386, ptr %76, align 4
  %387 = load i32, ptr %76, align 4
  %388 = load i32, ptr %73, align 4
  %389 = and i32 33568, %388
  store i32 %389, ptr %77, align 4
  %390 = load i32, ptr %77, align 4
  %391 = load i32, ptr %74, align 4
  %392 = and i32 60856, %391
  store i32 %392, ptr %78, align 4
  %393 = load i32, ptr %78, align 4
  %394 = load i32, ptr %75, align 4
  %395 = load i32, ptr %77, align 4
  %396 = xor i32 %394, %395
  store i32 %396, ptr %79, align 4
  %397 = load i32, ptr %79, align 4
  %398 = load i32, ptr %76, align 4
  %399 = load i32, ptr %78, align 4
  %400 = xor i32 %398, %399
  store i32 %400, ptr %80, align 4
  %401 = load i32, ptr %80, align 4
  %402 = load i32, ptr %79, align 4
  %403 = and i32 %402, 1
  store i32 %403, ptr %81, align 4
  %404 = load i32, ptr %81, align 4
  %405 = load i32, ptr %80, align 4
  %406 = and i32 %405, 0
  store i32 %406, ptr %82, align 4
  %407 = load i32, ptr %82, align 4
  %408 = load i32, ptr %81, align 4
  %409 = icmp ult i32 0, %408
  %410 = zext i1 %409 to i32
  store i32 %410, ptr %83, align 4
  %411 = load i32, ptr %83, align 4
  %412 = load i32, ptr %81, align 4
  %413 = sub i32 0, %412
  %414 = and i32 %413, 65535
  store i32 %414, ptr %84, align 4
  %415 = load i32, ptr %84, align 4
  %416 = load i32, ptr %82, align 4
  %417 = sub i32 0, %416
  %418 = load i32, ptr %83, align 4
  %419 = sub i32 %417, %418
  %420 = and i32 %419, 65535
  store i32 %420, ptr %85, align 4
  %421 = load i32, ptr %85, align 4
  %422 = load i32, ptr %79, align 4
  %423 = lshr i32 %422, 1
  %424 = load i32, ptr %80, align 4
  %425 = shl i32 %424, 15
  %426 = or i32 %423, %425
  %427 = and i32 %426, 65535
  store i32 %427, ptr %86, align 4
  %428 = load i32, ptr %86, align 4
  %429 = load i32, ptr %80, align 4
  %430 = lshr i32 %429, 1
  store i32 %430, ptr %87, align 4
  %431 = load i32, ptr %87, align 4
  %432 = load i32, ptr %84, align 4
  %433 = and i32 33568, %432
  store i32 %433, ptr %88, align 4
  %434 = load i32, ptr %88, align 4
  %435 = load i32, ptr %85, align 4
  %436 = and i32 60856, %435
  store i32 %436, ptr %89, align 4
  %437 = load i32, ptr %89, align 4
  %438 = load i32, ptr %86, align 4
  %439 = load i32, ptr %88, align 4
  %440 = xor i32 %438, %439
  store i32 %440, ptr %90, align 4
  %441 = load i32, ptr %90, align 4
  %442 = load i32, ptr %87, align 4
  %443 = load i32, ptr %89, align 4
  %444 = xor i32 %442, %443
  store i32 %444, ptr %91, align 4
  %445 = load i32, ptr %91, align 4
  %446 = load i32, ptr %90, align 4
  %447 = and i32 %446, 1
  store i32 %447, ptr %92, align 4
  %448 = load i32, ptr %92, align 4
  %449 = load i32, ptr %91, align 4
  %450 = and i32 %449, 0
  store i32 %450, ptr %93, align 4
  %451 = load i32, ptr %93, align 4
  %452 = load i32, ptr %92, align 4
  %453 = icmp ult i32 0, %452
  %454 = zext i1 %453 to i32
  store i32 %454, ptr %94, align 4
  %455 = load i32, ptr %94, align 4
  %456 = load i32, ptr %92, align 4
  %457 = sub i32 0, %456
  %458 = and i32 %457, 65535
  store i32 %458, ptr %95, align 4
  %459 = load i32, ptr %95, align 4
  %460 = load i32, ptr %93, align 4
  %461 = sub i32 0, %460
  %462 = load i32, ptr %94, align 4
  %463 = sub i32 %461, %462
  %464 = and i32 %463, 65535
  store i32 %464, ptr %96, align 4
  %465 = load i32, ptr %96, align 4
  %466 = load i32, ptr %90, align 4
  %467 = lshr i32 %466, 1
  %468 = load i32, ptr %91, align 4
  %469 = shl i32 %468, 15
  %470 = or i32 %467, %469
  %471 = and i32 %470, 65535
  store i32 %471, ptr %97, align 4
  %472 = load i32, ptr %97, align 4
  %473 = load i32, ptr %91, align 4
  %474 = lshr i32 %473, 1
  store i32 %474, ptr %98, align 4
  %475 = load i32, ptr %98, align 4
  %476 = load i32, ptr %95, align 4
  %477 = and i32 33568, %476
  store i32 %477, ptr %99, align 4
  %478 = load i32, ptr %99, align 4
  %479 = load i32, ptr %96, align 4
  %480 = and i32 60856, %479
  store i32 %480, ptr %100, align 4
  %481 = load i32, ptr %100, align 4
  %482 = load i32, ptr %97, align 4
  %483 = load i32, ptr %99, align 4
  %484 = xor i32 %482, %483
  store i32 %484, ptr %101, align 4
  %485 = load i32, ptr %101, align 4
  %486 = load i32, ptr %98, align 4
  %487 = load i32, ptr %100, align 4
  %488 = xor i32 %486, %487
  store i32 %488, ptr %102, align 4
  %489 = load i32, ptr %102, align 4
  %490 = load i32, ptr %101, align 4
  %491 = xor i32 %490, 65535
  store i32 %491, ptr %103, align 4
  %492 = load i32, ptr %103, align 4
  %493 = load i32, ptr %102, align 4
  %494 = xor i32 %493, 65535
  store i32 %494, ptr %104, align 4
  %495 = load i32, ptr %104, align 4
  %496 = load i32, ptr %103, align 4
  %497 = load i32, ptr %104, align 4
  %498 = shl i32 %497, 16
  %499 = or i32 %496, %498
  store i32 %499, ptr %105, align 4
  %500 = load i32, ptr %105, align 4
  %501 = load i32, ptr %105, align 4
  ret i32 %501
}

attributes #0 = { noinline nounwind optnone uwtable "frame-pointer"="non-leaf" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+fp-armv8,+neon,+outline-atomics,+v8a,-fmv" }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 1, !"wchar_size", i32 4}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 1}
!5 = !{!"Ubuntu clang version 18.1.3 (1ubuntu1)"}
