
/work/experiments/runs/rich-limbs-matrix-linux-20261109/crc32_byte/build-clang-O2-pgo-xor-42/program:	file format elf64-littleaarch64

Disassembly of section .init:

0000000000000678 <_init>:
     678:      	nop
     67c:      	stp	x29, x30, [sp, #-0x10]!
     680:      	mov	x29, sp
     684:      	bl	0x834 <call_weak_fn>
     688:      	ldp	x29, x30, [sp], #0x10
     68c:      	ret

Disassembly of section .plt:

0000000000000690 <.plt>:
     690:      	stp	x16, x30, [sp, #-0x10]!
     694:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e41c>
     698:      	ldr	x17, [x16, #0xff8]
     69c:      	add	x16, x16, #0xff8
     6a0:      	br	x17
     6a4:      	nop
     6a8:      	nop
     6ac:      	nop

00000000000006b0 <strtoul@plt>:
     6b0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6b4:      	ldr	x17, [x16]
     6b8:      	add	x16, x16, #0x0
     6bc:      	br	x17

00000000000006c0 <__libc_start_main@plt>:
     6c0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6c4:      	ldr	x17, [x16, #0x8]
     6c8:      	add	x16, x16, #0x8
     6cc:      	br	x17

00000000000006d0 <__cxa_finalize@plt>:
     6d0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6d4:      	ldr	x17, [x16, #0x10]
     6d8:      	add	x16, x16, #0x10
     6dc:      	br	x17

00000000000006e0 <clock_gettime@plt>:
     6e0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6e4:      	ldr	x17, [x16, #0x18]
     6e8:      	add	x16, x16, #0x18
     6ec:      	br	x17

00000000000006f0 <__gmon_start__@plt>:
     6f0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6f4:      	ldr	x17, [x16, #0x20]
     6f8:      	add	x16, x16, #0x20
     6fc:      	br	x17

0000000000000700 <abort@plt>:
     700:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     704:      	ldr	x17, [x16, #0x28]
     708:      	add	x16, x16, #0x28
     70c:      	br	x17

0000000000000710 <__isoc99_scanf@plt>:
     710:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     714:      	ldr	x17, [x16, #0x30]
     718:      	add	x16, x16, #0x30
     71c:      	br	x17

0000000000000720 <printf@plt>:
     720:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     724:      	ldr	x17, [x16, #0x38]
     728:      	add	x16, x16, #0x38
     72c:      	br	x17

Disassembly of section .text:

0000000000000740 <kernel>:
     740:      	and	w9, w1, #0xff
     744:      	mov	w8, #0x8320             // =33568
     748:      	eor	w9, w9, w0
     74c:      	movk	w8, #0xedb8, lsl #16
     750:      	orr	w10, w9, #0xfffffffe
     754:      	lsr	w9, w9, #1
     758:      	add	w10, w10, #0x1
     75c:      	and	w10, w10, w8
     760:      	eor	w10, w10, w9
     764:      	orr	w9, w9, #0xfffffffe
     768:      	add	w9, w9, #0x1
     76c:      	lsr	w10, w10, #1
     770:      	and	w9, w9, w8
     774:      	eor	w9, w10, w9
     778:      	orr	w10, w10, #0xfffffffe
     77c:      	add	w10, w10, #0x1
     780:      	lsr	w9, w9, #1
     784:      	and	w10, w10, w8
     788:      	eor	w10, w10, w9
     78c:      	orr	w9, w9, #0xfffffffe
     790:      	add	w9, w9, #0x1
     794:      	lsr	w10, w10, #1
     798:      	and	w9, w9, w8
     79c:      	eor	w9, w10, w9
     7a0:      	orr	w10, w10, #0xfffffffe
     7a4:      	add	w10, w10, #0x1
     7a8:      	lsr	w9, w9, #1
     7ac:      	and	w10, w10, w8
     7b0:      	eor	w10, w10, w9
     7b4:      	orr	w9, w9, #0xfffffffe
     7b8:      	add	w9, w9, #0x1
     7bc:      	lsr	w10, w10, #1
     7c0:      	and	w9, w9, w8
     7c4:      	eor	w9, w10, w9
     7c8:      	orr	w10, w10, #0xfffffffe
     7cc:      	lsr	w9, w9, #1
     7d0:      	add	w10, w10, #0x1
     7d4:      	and	w10, w10, w8
     7d8:      	orr	w11, w9, #0xfffffffe
     7dc:      	eor	w9, w10, w9
     7e0:      	add	w11, w11, #0x1
     7e4:      	and	w8, w11, w8
     7e8:      	eor	w8, w8, w9, lsr #1
     7ec:      	eor	w0, w8, #0xff000000
     7f0:      	ret
     7f4:      	nop
     7f8:      	nop
     7fc:      	nop

0000000000000800 <_start>:
     800:      	nop
     804:      	mov	x29, #0x0               // =0
     808:      	mov	x30, #0x0               // =0
     80c:      	mov	x5, x0
     810:      	ldr	x1, [sp]
     814:      	add	x2, sp, #0x8
     818:      	mov	x6, sp
     81c:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e41c>
     820:      	ldr	x0, [x0, #0xfd8]
     824:      	mov	x3, #0x0                // =0
     828:      	mov	x4, #0x0                // =0
     82c:      	bl	0x6c0 <__libc_start_main@plt>
     830:      	bl	0x700 <abort@plt>

0000000000000834 <call_weak_fn>:
     834:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e41c>
     838:      	ldr	x0, [x0, #0xfd0]
     83c:      	cbz	x0, 0x844 <call_weak_fn+0x10>
     840:      	b	0x6f0 <__gmon_start__@plt>
     844:      	ret
     848:      	nop
     84c:      	nop

0000000000000850 <deregister_tm_clones>:
     850:      	adrp	x0, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     854:      	add	x0, x0, #0x50
     858:      	adrp	x1, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     85c:      	add	x1, x1, #0x50
     860:      	cmp	x1, x0
     864:      	b.eq	0x87c <deregister_tm_clones+0x2c>
     868:      	adrp	x1, 0x1f000 <__FRAME_END__+0x1e41c>
     86c:      	ldr	x1, [x1, #0xfc0]
     870:      	cbz	x1, 0x87c <deregister_tm_clones+0x2c>
     874:      	mov	x16, x1
     878:      	br	x16
     87c:      	ret

0000000000000880 <register_tm_clones>:
     880:      	adrp	x0, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     884:      	add	x0, x0, #0x50
     888:      	adrp	x1, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     88c:      	add	x1, x1, #0x50
     890:      	sub	x1, x1, x0
     894:      	lsr	x2, x1, #63
     898:      	add	x1, x2, x1, asr #3
     89c:      	asr	x1, x1, #1
     8a0:      	cbz	x1, 0x8b8 <register_tm_clones+0x38>
     8a4:      	adrp	x2, 0x1f000 <__FRAME_END__+0x1e41c>
     8a8:      	ldr	x2, [x2, #0xfe0]
     8ac:      	cbz	x2, 0x8b8 <register_tm_clones+0x38>
     8b0:      	mov	x16, x2
     8b4:      	br	x16
     8b8:      	ret
     8bc:      	nop

00000000000008c0 <__do_global_dtors_aux>:
     8c0:      	paciasp
     8c4:      	stp	x29, x30, [sp, #-0x20]!
     8c8:      	mov	x29, sp
     8cc:      	str	x19, [sp, #0x10]
     8d0:      	adrp	x19, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     8d4:      	ldrb	w0, [x19, #0x50]
     8d8:      	tbnz	w0, #0x0, 0x900 <__do_global_dtors_aux+0x40>
     8dc:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e41c>
     8e0:      	ldr	x0, [x0, #0xfc8]
     8e4:      	cbz	x0, 0x8f4 <__do_global_dtors_aux+0x34>
     8e8:      	adrp	x0, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     8ec:      	ldr	x0, [x0, #0x48]
     8f0:      	bl	0x6d0 <__cxa_finalize@plt>
     8f4:      	bl	0x850 <deregister_tm_clones>
     8f8:      	mov	w0, #0x1                // =1
     8fc:      	strb	w0, [x19, #0x50]
     900:      	ldr	x19, [sp, #0x10]
     904:      	ldp	x29, x30, [sp], #0x20
     908:      	autiasp
     90c:      	ret

0000000000000910 <frame_dummy>:
     910:      	bti	c
     914:      	b	0x880 <register_tm_clones>

0000000000000918 <main>:
     918:      	sub	sp, sp, #0x50
     91c:      	stp	x29, x30, [sp, #0x20]
     920:      	str	x21, [sp, #0x30]
     924:      	stp	x20, x19, [sp, #0x40]
     928:      	add	x29, sp, #0x20
     92c:      	cmp	w0, #0x1
     930:      	b.ne	0x9a8 <main+0x90>
     934:      	add	x21, sp, #0x10
     938:      	adrp	x0, 0x0 <strtoul@GLIBC_2.17>
     93c:      	add	x0, x0, #0xaa0
     940:      	add	x1, sp, #0x10
     944:      	add	x2, x21, #0x4
     948:      	bl	0x710 <__isoc99_scanf@plt>
     94c:      	cmp	w0, #0x2
     950:      	b.ne	0x990 <main+0x78>
     954:      	adrp	x19, 0x0 <strtoul@GLIBC_2.17>
     958:      	add	x19, x19, #0xaa5
     95c:      	adrp	x20, 0x0 <strtoul@GLIBC_2.17>
     960:      	add	x20, x20, #0xaa0
     964:      	ldp	w0, w1, [sp, #0x10]
     968:      	bl	0x740 <kernel>
     96c:      	mov	w1, w0
     970:      	mov	x0, x19
     974:      	bl	0x720 <printf@plt>
     978:      	add	x1, sp, #0x10
     97c:      	add	x2, x21, #0x4
     980:      	mov	x0, x20
     984:      	bl	0x710 <__isoc99_scanf@plt>
     988:      	cmp	w0, #0x2
     98c:      	b.eq	0x964 <main+0x4c>
     990:      	mov	w0, wzr
     994:      	ldp	x20, x19, [sp, #0x40]
     998:      	ldr	x21, [sp, #0x30]
     99c:      	ldp	x29, x30, [sp, #0x20]
     9a0:      	add	sp, sp, #0x50
     9a4:      	ret
     9a8:      	cmp	w0, #0x3
     9ac:      	b.ne	0x9f8 <main+0xe0>
     9b0:      	ldr	x0, [x1, #0x8]
     9b4:      	mov	x19, x1
     9b8:      	mov	x1, xzr
     9bc:      	mov	w2, #0xa                // =10
     9c0:      	bl	0x6b0 <strtoul@plt>
     9c4:      	ldr	x8, [x19, #0x10]
     9c8:      	mov	x20, x0
     9cc:      	mov	x1, xzr
     9d0:      	mov	w2, #0xa                // =10
     9d4:      	mov	x0, x8
     9d8:      	bl	0x6b0 <strtoul@plt>
     9dc:      	mov	x21, x0
     9e0:      	add	x1, sp, #0x10
     9e4:      	mov	w0, #0x1                // =1
     9e8:      	bl	0x6e0 <clock_gettime@plt>
     9ec:      	cbz	w0, 0xa00 <main+0xe8>
     9f0:      	mov	w0, #0x2                // =2
     9f4:      	b	0x994 <main+0x7c>
     9f8:      	mov	w0, #0x3                // =3
     9fc:      	b	0x994 <main+0x7c>
     a00:      	mov	x19, xzr
     a04:      	cbz	x20, 0xa34 <main+0x11c>
     a08:      	eor	w8, w21, w21, lsl #13
     a0c:      	eor	w8, w8, w8, lsr #17
     a10:      	eor	w0, w8, w8, lsl #5
     a14:      	eor	w8, w0, w0, lsl #13
     a18:      	eor	w8, w8, w8, lsr #17
     a1c:      	eor	w21, w8, w8, lsl #5
     a20:      	mov	w1, w21
     a24:      	bl	0x740 <kernel>
     a28:      	add	x19, x19, w0, uxtw
     a2c:      	subs	x20, x20, #0x1
     a30:      	b.ne	0xa08 <main+0xf0>
     a34:      	mov	x1, sp
     a38:      	mov	w0, #0x1                // =1
     a3c:      	bl	0x6e0 <clock_gettime@plt>
     a40:      	cbnz	w0, 0x9f0 <main+0xd8>
     a44:      	ldp	x8, x9, [sp]
     a48:      	adrp	x0, 0x0 <strtoul@GLIBC_2.17>
     a4c:      	add	x0, x0, #0xaa9
     a50:      	ldp	x10, x11, [sp, #0x10]
     a54:      	mov	x1, x19
     a58:      	sub	x8, x8, x10
     a5c:      	sub	x9, x9, x11
     a60:      	scvtf	d0, x8
     a64:      	scvtf	d1, x9
     a68:      	adrp	x8, 0x0 <strtoul@GLIBC_2.17>
     a6c:      	ldr	d2, [x8, #0xa98]
     a70:      	fmadd	d0, d1, d2, d0
     a74:      	bl	0x720 <printf@plt>
     a78:      	b	0x990 <main+0x78>

Disassembly of section .fini:

0000000000000a7c <_fini>:
     a7c:      	nop
     a80:      	stp	x29, x30, [sp, #-0x10]!
     a84:      	mov	x29, sp
     a88:      	ldp	x29, x30, [sp], #0x10
     a8c:      	ret
