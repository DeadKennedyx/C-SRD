; ModuleID = '/work/experiments/runs/rich-limbs-matrix-linux-20261109/crc32_byte/build-clang-O1-sanitizers-affine-42/validation/compiler-0-O1/candidate.i'
source_filename = "/work/experiments/runs/rich-limbs-matrix-linux-20261109/crc32_byte/build-clang-O1-sanitizers-affine-42/validation/compiler-0-O1/candidate.i"
target datalayout = "e-m:e-i8:8:32-i16:16:32-i64:64-i128:128-n32:64-S128"
target triple = "aarch64-unknown-linux-gnu"

$asan.module_ctor = comdat any

@llvm.used = appending global [1 x ptr] [ptr @asan.module_ctor], section "llvm.metadata"
@___asan_globals_registered = common hidden global i64 0
@__start_asan_globals = extern_weak hidden global i64
@__stop_asan_globals = extern_weak hidden global i64
@llvm.global_ctors = appending global [1 x { i32, ptr, ptr }] [{ i32, ptr, ptr } { i32 1, ptr @asan.module_ctor, ptr @asan.module_ctor }]

; Function Attrs: mustprogress nofree norecurse nosync nounwind sanitize_address willreturn memory(none) uwtable
define dso_local i32 @kernel(i32 noundef %state, i32 noundef %byte) local_unnamed_addr #0 !func_sanitize !6 {
entry:
  %and = and i32 %byte, 255
  %0 = xor i32 %and, %state
  %xor1 = xor i32 %0, -1
  %shr = lshr i32 %xor1, 6
  %1 = and i32 %xor1, 1
  %2 = icmp eq i32 %1, 0
  %and6 = select i1 %2, i32 0, i32 124634137
  %.mask = and i32 %xor1, 2
  %isneg.not = icmp eq i32 %.mask, 0
  %and18 = select i1 %isneg.not, i32 0, i32 249268274
  %.mask101 = and i32 %xor1, 4
  %isneg.not102 = icmp eq i32 %.mask101, 0
  %and30 = select i1 %isneg.not102, i32 0, i32 498536548
  %.mask103 = and i32 %xor1, 8
  %isneg.not104 = icmp eq i32 %.mask103, 0
  %and42 = select i1 %isneg.not104, i32 0, i32 997073096
  %.mask105 = and i32 %xor1, 16
  %isneg.not106 = icmp eq i32 %.mask105, 0
  %and54 = select i1 %isneg.not106, i32 0, i32 1994146192
  %3 = xor i32 %and18, %shr
  %4 = xor i32 %3, %and6
  %5 = xor i32 %4, %and30
  %6 = xor i32 %and42, %and54
  %.mask107 = and i32 %xor1, 32
  %isneg.not108 = icmp eq i32 %.mask107, 0
  %and66 = select i1 %isneg.not108, i32 0, i32 -306674912
  %7 = xor i32 %6, %and66
  %xor67 = xor i32 %7, %5
  %shr75 = lshr i32 %xor67, 2
  %8 = and i32 %4, 1
  %9 = icmp eq i32 %8, 0
  %and78 = select i1 %9, i32 0, i32 1994146192
  %xor79 = xor i32 %and78, %shr75
  %.mask109 = and i32 %3, 2
  %isneg.not110 = icmp eq i32 %.mask109, 0
  %10 = select i1 %isneg.not110, i32 -1, i32 306674911
  %xor92 = xor i32 %xor79, %10
  ret i32 %xor92
}

declare void @__asan_register_elf_globals(i64, i64, i64)

declare void @__asan_init()

; Function Attrs: nounwind uwtable
define internal void @asan.module_ctor() #1 comdat {
  call void @__asan_init()
  call void @__asan_version_mismatch_check_v8()
  call void @__asan_register_elf_globals(i64 ptrtoint (ptr @___asan_globals_registered to i64), i64 ptrtoint (ptr @__start_asan_globals to i64), i64 ptrtoint (ptr @__stop_asan_globals to i64))
  ret void
}

declare void @__asan_version_mismatch_check_v8()

attributes #0 = { mustprogress nofree norecurse nosync nounwind sanitize_address willreturn memory(none) uwtable "frame-pointer"="non-leaf" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+fp-armv8,+neon,+outline-atomics,+v8a,-fmv" }
attributes #1 = { nounwind uwtable "frame-pointer"="non-leaf" }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 1, !"wchar_size", i32 4}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 1}
!5 = !{!"Ubuntu clang version 18.1.3 (1ubuntu1)"}
!6 = !{i32 -1056584962, i32 -455559067}
