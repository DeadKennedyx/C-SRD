; ModuleID = '/work/experiments/runs/rich-limbs-matrix-linux-20261109/crc32_byte/build-clang-Oz-original/validation/compiler-0-Oz/candidate.i'
source_filename = "/work/experiments/runs/rich-limbs-matrix-linux-20261109/crc32_byte/build-clang-Oz-original/validation/compiler-0-Oz/candidate.i"
target datalayout = "e-m:e-i8:8:32-i16:16:32-i64:64-i128:128-n32:64-S128"
target triple = "aarch64-unknown-linux-gnu"

; Function Attrs: minsize nofree norecurse nosync nounwind optsize memory(none) uwtable
define dso_local i32 @kernel(i32 noundef %0, i32 noundef %1) local_unnamed_addr #0 {
  %3 = and i32 %1, 255
  %4 = xor i32 %3, %0
  %5 = xor i32 %4, -1
  br label %6

6:                                                ; preds = %12, %2
  %7 = phi i32 [ %5, %2 ], [ %17, %12 ]
  %8 = phi i32 [ 0, %2 ], [ %18, %12 ]
  %9 = icmp eq i32 %8, 8
  br i1 %9, label %10, label %12

10:                                               ; preds = %6
  %11 = xor i32 %7, -1
  ret i32 %11

12:                                               ; preds = %6
  %13 = and i32 %7, 1
  %14 = lshr i32 %7, 1
  %15 = icmp eq i32 %13, 0
  %16 = select i1 %15, i32 0, i32 -306674912
  %17 = xor i32 %16, %14
  %18 = add nuw nsw i32 %8, 1
  br label %6, !llvm.loop !6
}

attributes #0 = { minsize nofree norecurse nosync nounwind optsize memory(none) uwtable "frame-pointer"="non-leaf" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+fp-armv8,+neon,+outline-atomics,+v8a,-fmv" }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 1, !"wchar_size", i32 4}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 1}
!5 = !{!"Ubuntu clang version 18.1.3 (1ubuntu1)"}
!6 = distinct !{!6, !7}
!7 = !{!"llvm.loop.mustprogress"}
