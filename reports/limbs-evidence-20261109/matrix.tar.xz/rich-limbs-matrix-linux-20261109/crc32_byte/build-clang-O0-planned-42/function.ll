; ModuleID = '/work/experiments/runs/rich-limbs-matrix-linux-20261109/crc32_byte/build-clang-O0-planned-42/validation/compiler-0-O0/candidate.i'
source_filename = "/work/experiments/runs/rich-limbs-matrix-linux-20261109/crc32_byte/build-clang-O0-planned-42/validation/compiler-0-O0/candidate.i"
target datalayout = "e-m:e-i8:8:32-i16:16:32-i64:64-i128:128-n32:64-S128"
target triple = "aarch64-unknown-linux-gnu"

; Function Attrs: noinline nounwind optnone uwtable
define dso_local i32 @kernel(i32 noundef %0, i32 noundef %1) #0 {
  %3 = alloca i32, align 4
  %4 = alloca i32, align 4
  %5 = alloca i32, align 4
  %6 = alloca i32, align 4
  %7 = alloca i32, align 4
  %8 = alloca i32, align 4
  %9 = alloca i32, align 4
  %10 = alloca i32, align 4
  %11 = alloca i32, align 4
  %12 = alloca i32, align 4
  %13 = alloca i32, align 4
  %14 = alloca i32, align 4
  %15 = alloca i32, align 4
  %16 = alloca i32, align 4
  %17 = alloca i32, align 4
  %18 = alloca i32, align 4
  %19 = alloca i32, align 4
  %20 = alloca i32, align 4
  %21 = alloca i32, align 4
  %22 = alloca i32, align 4
  %23 = alloca i32, align 4
  %24 = alloca i32, align 4
  %25 = alloca i32, align 4
  %26 = alloca i32, align 4
  %27 = alloca i32, align 4
  %28 = alloca i32, align 4
  %29 = alloca i32, align 4
  %30 = alloca i32, align 4
  %31 = alloca i32, align 4
  %32 = alloca i32, align 4
  %33 = alloca i32, align 4
  %34 = alloca i32, align 4
  %35 = alloca i32, align 4
  %36 = alloca i32, align 4
  %37 = alloca i32, align 4
  %38 = alloca i32, align 4
  %39 = alloca i32, align 4
  %40 = alloca i32, align 4
  %41 = alloca i32, align 4
  %42 = alloca i32, align 4
  %43 = alloca i32, align 4
  %44 = alloca i32, align 4
  %45 = alloca i32, align 4
  %46 = alloca i32, align 4
  %47 = alloca i32, align 4
  %48 = alloca i32, align 4
  %49 = alloca i32, align 4
  %50 = alloca i32, align 4
  %51 = alloca i32, align 4
  %52 = alloca i32, align 4
  %53 = alloca i32, align 4
  %54 = alloca i32, align 4
  %55 = alloca i32, align 4
  %56 = alloca i32, align 4
  %57 = alloca i32, align 4
  %58 = alloca i32, align 4
  %59 = alloca i32, align 4
  %60 = alloca i32, align 4
  %61 = alloca i32, align 4
  %62 = alloca i32, align 4
  %63 = alloca i32, align 4
  %64 = alloca i32, align 4
  %65 = alloca i32, align 4
  %66 = alloca i32, align 4
  %67 = alloca i32, align 4
  store i32 %0, ptr %3, align 4
  store i32 %1, ptr %4, align 4
  %68 = load i32, ptr %3, align 4
  %69 = xor i32 %68, 1732534814
  store i32 %69, ptr %5, align 4
  %70 = load i32, ptr %5, align 4
  %71 = xor i32 %70, -1732534815
  %72 = xor i32 %71, 1732534814
  store i32 %72, ptr %6, align 4
  %73 = load i32, ptr %4, align 4
  %74 = xor i32 %73, 1732534814
  store i32 %74, ptr %7, align 4
  %75 = load i32, ptr %7, align 4
  %76 = and i32 %75, 1732535009
  %77 = load i32, ptr %7, align 4
  %78 = xor i32 %77, 1732535009
  %79 = and i32 %78, 1732534814
  %80 = xor i32 %76, %79
  store i32 %80, ptr %8, align 4
  %81 = load i32, ptr %6, align 4
  %82 = load i32, ptr %8, align 4
  %83 = xor i32 %81, %82
  %84 = xor i32 %83, 1732534814
  store i32 %84, ptr %9, align 4
  %85 = load i32, ptr %9, align 4
  %86 = and i32 %85, 1732534815
  %87 = load i32, ptr %9, align 4
  %88 = xor i32 %87, 1732534815
  %89 = and i32 %88, 1732534814
  %90 = xor i32 %86, %89
  store i32 %90, ptr %10, align 4
  %91 = load i32, ptr %10, align 4
  %92 = xor i32 %91, 1732534814
  store i32 %92, ptr %11, align 4
  %93 = load i32, ptr %11, align 4
  %94 = sub i32 0, %93
  store i32 %94, ptr %12, align 4
  %95 = load i32, ptr %9, align 4
  %96 = lshr i32 %95, 1
  %97 = xor i32 %96, 1424380689
  store i32 %97, ptr %13, align 4
  %98 = load i32, ptr %12, align 4
  %99 = xor i32 %98, 1732534814
  store i32 %99, ptr %14, align 4
  %100 = load i32, ptr %14, align 4
  %101 = and i32 -1963138754, %100
  %102 = load i32, ptr %14, align 4
  %103 = xor i32 -1963138754, %102
  %104 = and i32 %103, 1732534814
  %105 = xor i32 %101, %104
  store i32 %105, ptr %15, align 4
  %106 = load i32, ptr %13, align 4
  %107 = load i32, ptr %15, align 4
  %108 = xor i32 %106, %107
  %109 = xor i32 %108, 1732534814
  store i32 %109, ptr %16, align 4
  %110 = load i32, ptr %16, align 4
  %111 = xor i32 %110, 1732534814
  store i32 %111, ptr %17, align 4
  %112 = load i32, ptr %17, align 4
  %113 = and i32 %112, 1
  store i32 %113, ptr %18, align 4
  %114 = load i32, ptr %18, align 4
  %115 = sub i32 0, %114
  store i32 %115, ptr %19, align 4
  %116 = load i32, ptr %16, align 4
  %117 = lshr i32 %116, 1
  %118 = xor i32 %117, 1424380689
  store i32 %118, ptr %20, align 4
  %119 = load i32, ptr %19, align 4
  %120 = and i32 -306674912, %119
  store i32 %120, ptr %21, align 4
  %121 = load i32, ptr %21, align 4
  %122 = xor i32 %121, 1732534814
  store i32 %122, ptr %22, align 4
  %123 = load i32, ptr %20, align 4
  %124 = load i32, ptr %22, align 4
  %125 = xor i32 %123, %124
  %126 = xor i32 %125, 1732534814
  store i32 %126, ptr %23, align 4
  %127 = load i32, ptr %23, align 4
  %128 = xor i32 %127, 1732534814
  store i32 %128, ptr %24, align 4
  %129 = load i32, ptr %24, align 4
  %130 = and i32 %129, 1
  store i32 %130, ptr %25, align 4
  %131 = load i32, ptr %25, align 4
  %132 = sub i32 0, %131
  store i32 %132, ptr %26, align 4
  %133 = load i32, ptr %23, align 4
  %134 = lshr i32 %133, 1
  %135 = xor i32 %134, 1424380689
  store i32 %135, ptr %27, align 4
  %136 = load i32, ptr %26, align 4
  %137 = and i32 -306674912, %136
  store i32 %137, ptr %28, align 4
  %138 = load i32, ptr %28, align 4
  %139 = xor i32 %138, 1732534814
  store i32 %139, ptr %29, align 4
  %140 = load i32, ptr %27, align 4
  %141 = load i32, ptr %29, align 4
  %142 = xor i32 %140, %141
  %143 = xor i32 %142, 1732534814
  store i32 %143, ptr %30, align 4
  %144 = load i32, ptr %30, align 4
  %145 = xor i32 %144, 1732534814
  store i32 %145, ptr %31, align 4
  %146 = load i32, ptr %31, align 4
  %147 = and i32 %146, 1
  store i32 %147, ptr %32, align 4
  %148 = load i32, ptr %32, align 4
  %149 = sub i32 0, %148
  store i32 %149, ptr %33, align 4
  %150 = load i32, ptr %30, align 4
  %151 = lshr i32 %150, 1
  %152 = xor i32 %151, 1424380689
  store i32 %152, ptr %34, align 4
  %153 = load i32, ptr %33, align 4
  %154 = and i32 -306674912, %153
  store i32 %154, ptr %35, align 4
  %155 = load i32, ptr %35, align 4
  %156 = xor i32 %155, 1732534814
  store i32 %156, ptr %36, align 4
  %157 = load i32, ptr %34, align 4
  %158 = load i32, ptr %36, align 4
  %159 = xor i32 %157, %158
  %160 = xor i32 %159, 1732534814
  store i32 %160, ptr %37, align 4
  %161 = load i32, ptr %37, align 4
  %162 = xor i32 %161, 1732534814
  store i32 %162, ptr %38, align 4
  %163 = load i32, ptr %38, align 4
  %164 = and i32 %163, 1
  store i32 %164, ptr %39, align 4
  %165 = load i32, ptr %39, align 4
  %166 = sub i32 0, %165
  store i32 %166, ptr %40, align 4
  %167 = load i32, ptr %37, align 4
  %168 = lshr i32 %167, 1
  %169 = xor i32 %168, 1424380689
  store i32 %169, ptr %41, align 4
  %170 = load i32, ptr %40, align 4
  %171 = and i32 -306674912, %170
  store i32 %171, ptr %42, align 4
  %172 = load i32, ptr %42, align 4
  %173 = xor i32 %172, 1732534814
  store i32 %173, ptr %43, align 4
  %174 = load i32, ptr %41, align 4
  %175 = load i32, ptr %43, align 4
  %176 = xor i32 %174, %175
  %177 = xor i32 %176, 1732534814
  store i32 %177, ptr %44, align 4
  %178 = load i32, ptr %44, align 4
  %179 = xor i32 %178, 1732534814
  store i32 %179, ptr %45, align 4
  %180 = load i32, ptr %45, align 4
  %181 = and i32 %180, 1
  store i32 %181, ptr %46, align 4
  %182 = load i32, ptr %46, align 4
  %183 = sub i32 0, %182
  store i32 %183, ptr %47, align 4
  %184 = load i32, ptr %44, align 4
  %185 = lshr i32 %184, 1
  %186 = xor i32 %185, 1424380689
  store i32 %186, ptr %48, align 4
  %187 = load i32, ptr %47, align 4
  %188 = and i32 -306674912, %187
  store i32 %188, ptr %49, align 4
  %189 = load i32, ptr %49, align 4
  %190 = xor i32 %189, 1732534814
  store i32 %190, ptr %50, align 4
  %191 = load i32, ptr %48, align 4
  %192 = load i32, ptr %50, align 4
  %193 = xor i32 %191, %192
  %194 = xor i32 %193, 1732534814
  store i32 %194, ptr %51, align 4
  %195 = load i32, ptr %51, align 4
  %196 = xor i32 %195, 1732534814
  store i32 %196, ptr %52, align 4
  %197 = load i32, ptr %52, align 4
  %198 = and i32 %197, 1
  store i32 %198, ptr %53, align 4
  %199 = load i32, ptr %53, align 4
  %200 = sub i32 0, %199
  store i32 %200, ptr %54, align 4
  %201 = load i32, ptr %51, align 4
  %202 = lshr i32 %201, 1
  %203 = xor i32 %202, 1424380689
  store i32 %203, ptr %55, align 4
  %204 = load i32, ptr %54, align 4
  %205 = and i32 -306674912, %204
  store i32 %205, ptr %56, align 4
  %206 = load i32, ptr %56, align 4
  %207 = xor i32 %206, 1732534814
  store i32 %207, ptr %57, align 4
  %208 = load i32, ptr %55, align 4
  %209 = load i32, ptr %57, align 4
  %210 = xor i32 %208, %209
  %211 = xor i32 %210, 1732534814
  store i32 %211, ptr %58, align 4
  %212 = load i32, ptr %58, align 4
  %213 = xor i32 %212, 1732534814
  store i32 %213, ptr %59, align 4
  %214 = load i32, ptr %59, align 4
  %215 = and i32 %214, 1
  store i32 %215, ptr %60, align 4
  %216 = load i32, ptr %60, align 4
  %217 = sub i32 0, %216
  store i32 %217, ptr %61, align 4
  %218 = load i32, ptr %58, align 4
  %219 = lshr i32 %218, 1
  %220 = xor i32 %219, 1424380689
  store i32 %220, ptr %62, align 4
  %221 = load i32, ptr %61, align 4
  %222 = and i32 -306674912, %221
  store i32 %222, ptr %63, align 4
  %223 = load i32, ptr %63, align 4
  %224 = xor i32 %223, 1732534814
  store i32 %224, ptr %64, align 4
  %225 = load i32, ptr %62, align 4
  %226 = load i32, ptr %64, align 4
  %227 = xor i32 %225, %226
  %228 = xor i32 %227, 1732534814
  store i32 %228, ptr %65, align 4
  %229 = load i32, ptr %65, align 4
  %230 = xor i32 %229, -1732534815
  %231 = xor i32 %230, 1732534814
  store i32 %231, ptr %66, align 4
  %232 = load i32, ptr %66, align 4
  %233 = xor i32 %232, 1732534814
  store i32 %233, ptr %67, align 4
  %234 = load i32, ptr %67, align 4
  ret i32 %234
}

attributes #0 = { noinline nounwind optnone uwtable "frame-pointer"="non-leaf" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+fp-armv8,+neon,+outline-atomics,+v8a,-fmv" }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 1, !"wchar_size", i32 4}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 1}
!5 = !{!"Ubuntu clang version 18.1.3 (1ubuntu1)"}
