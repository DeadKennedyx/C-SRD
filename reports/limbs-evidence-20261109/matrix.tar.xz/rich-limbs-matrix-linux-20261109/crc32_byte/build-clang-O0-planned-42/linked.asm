
/work/experiments/runs/rich-limbs-matrix-linux-20261109/crc32_byte/build-clang-O0-planned-42/program:	file format elf64-littleaarch64

Disassembly of section .init:

0000000000000678 <_init>:
     678:      	nop
     67c:      	stp	x29, x30, [sp, #-0x10]!
     680:      	mov	x29, sp
     684:      	bl	0x774 <call_weak_fn>
     688:      	ldp	x29, x30, [sp], #0x10
     68c:      	ret

Disassembly of section .plt:

0000000000000690 <.plt>:
     690:      	stp	x16, x30, [sp, #-0x10]!
     694:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1dfec>
     698:      	ldr	x17, [x16, #0xff8]
     69c:      	add	x16, x16, #0xff8
     6a0:      	br	x17
     6a4:      	nop
     6a8:      	nop
     6ac:      	nop

00000000000006b0 <strtoul@plt>:
     6b0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6b4:      	ldr	x17, [x16]
     6b8:      	add	x16, x16, #0x0
     6bc:      	br	x17

00000000000006c0 <__libc_start_main@plt>:
     6c0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6c4:      	ldr	x17, [x16, #0x8]
     6c8:      	add	x16, x16, #0x8
     6cc:      	br	x17

00000000000006d0 <__cxa_finalize@plt>:
     6d0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6d4:      	ldr	x17, [x16, #0x10]
     6d8:      	add	x16, x16, #0x10
     6dc:      	br	x17

00000000000006e0 <clock_gettime@plt>:
     6e0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6e4:      	ldr	x17, [x16, #0x18]
     6e8:      	add	x16, x16, #0x18
     6ec:      	br	x17

00000000000006f0 <__gmon_start__@plt>:
     6f0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6f4:      	ldr	x17, [x16, #0x20]
     6f8:      	add	x16, x16, #0x20
     6fc:      	br	x17

0000000000000700 <abort@plt>:
     700:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     704:      	ldr	x17, [x16, #0x28]
     708:      	add	x16, x16, #0x28
     70c:      	br	x17

0000000000000710 <__isoc99_scanf@plt>:
     710:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     714:      	ldr	x17, [x16, #0x30]
     718:      	add	x16, x16, #0x30
     71c:      	br	x17

0000000000000720 <printf@plt>:
     720:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     724:      	ldr	x17, [x16, #0x38]
     728:      	add	x16, x16, #0x38
     72c:      	br	x17

Disassembly of section .text:

0000000000000740 <_start>:
     740:      	nop
     744:      	mov	x29, #0x0               // =0
     748:      	mov	x30, #0x0               // =0
     74c:      	mov	x5, x0
     750:      	ldr	x1, [sp]
     754:      	add	x2, sp, #0x8
     758:      	mov	x6, sp
     75c:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1dfec>
     760:      	ldr	x0, [x0, #0xfd8]
     764:      	mov	x3, #0x0                // =0
     768:      	mov	x4, #0x0                // =0
     76c:      	bl	0x6c0 <__libc_start_main@plt>
     770:      	bl	0x700 <abort@plt>

0000000000000774 <call_weak_fn>:
     774:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1dfec>
     778:      	ldr	x0, [x0, #0xfd0]
     77c:      	cbz	x0, 0x784 <call_weak_fn+0x10>
     780:      	b	0x6f0 <__gmon_start__@plt>
     784:      	ret
     788:      	nop
     78c:      	nop

0000000000000790 <deregister_tm_clones>:
     790:      	adrp	x0, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     794:      	add	x0, x0, #0x50
     798:      	adrp	x1, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     79c:      	add	x1, x1, #0x50
     7a0:      	cmp	x1, x0
     7a4:      	b.eq	0x7bc <deregister_tm_clones+0x2c>
     7a8:      	adrp	x1, 0x1f000 <__FRAME_END__+0x1dfec>
     7ac:      	ldr	x1, [x1, #0xfc0]
     7b0:      	cbz	x1, 0x7bc <deregister_tm_clones+0x2c>
     7b4:      	mov	x16, x1
     7b8:      	br	x16
     7bc:      	ret

00000000000007c0 <register_tm_clones>:
     7c0:      	adrp	x0, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     7c4:      	add	x0, x0, #0x50
     7c8:      	adrp	x1, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     7cc:      	add	x1, x1, #0x50
     7d0:      	sub	x1, x1, x0
     7d4:      	lsr	x2, x1, #63
     7d8:      	add	x1, x2, x1, asr #3
     7dc:      	asr	x1, x1, #1
     7e0:      	cbz	x1, 0x7f8 <register_tm_clones+0x38>
     7e4:      	adrp	x2, 0x1f000 <__FRAME_END__+0x1dfec>
     7e8:      	ldr	x2, [x2, #0xfe0]
     7ec:      	cbz	x2, 0x7f8 <register_tm_clones+0x38>
     7f0:      	mov	x16, x2
     7f4:      	br	x16
     7f8:      	ret
     7fc:      	nop

0000000000000800 <__do_global_dtors_aux>:
     800:      	paciasp
     804:      	stp	x29, x30, [sp, #-0x20]!
     808:      	mov	x29, sp
     80c:      	str	x19, [sp, #0x10]
     810:      	adrp	x19, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     814:      	ldrb	w0, [x19, #0x50]
     818:      	tbnz	w0, #0x0, 0x840 <__do_global_dtors_aux+0x40>
     81c:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1dfec>
     820:      	ldr	x0, [x0, #0xfc8]
     824:      	cbz	x0, 0x834 <__do_global_dtors_aux+0x34>
     828:      	adrp	x0, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     82c:      	ldr	x0, [x0, #0x48]
     830:      	bl	0x6d0 <__cxa_finalize@plt>
     834:      	bl	0x790 <deregister_tm_clones>
     838:      	mov	w0, #0x1                // =1
     83c:      	strb	w0, [x19, #0x50]
     840:      	ldr	x19, [sp, #0x10]
     844:      	ldp	x29, x30, [sp], #0x20
     848:      	autiasp
     84c:      	ret

0000000000000850 <frame_dummy>:
     850:      	bti	c
     854:      	b	0x7c0 <register_tm_clones>

0000000000000858 <kernel>:
     858:      	sub	sp, sp, #0x120
     85c:      	str	x29, [sp, #0x110]
     860:      	mov	w9, #0x621e             // =25118
     864:      	movk	w9, #0x6744, lsl #16
     868:      	mov	w11, #0x5311            // =21265
     86c:      	movk	w11, #0x54e6, lsl #16
     870:      	mov	w8, #0x8320             // =33568
     874:      	movk	w8, #0xedb8, lsl #16
     878:      	str	w0, [sp, #0x10c]
     87c:      	str	w1, [sp, #0x108]
     880:      	ldr	w10, [sp, #0x10c]
     884:      	eor	w10, w10, w9
     888:      	str	w10, [sp, #0x104]
     88c:      	ldr	w12, [sp, #0x104]
     890:      	mov	w10, #0x9de1            // =40417
     894:      	movk	w10, #0x98bb, lsl #16
     898:      	eor	w12, w12, w10
     89c:      	eor	w12, w12, w9
     8a0:      	str	w12, [sp, #0x100]
     8a4:      	ldr	w12, [sp, #0x108]
     8a8:      	eor	w12, w12, w9
     8ac:      	str	w12, [sp, #0xfc]
     8b0:      	ldr	w12, [sp, #0xfc]
     8b4:      	mov	w14, #0x62e1            // =25313
     8b8:      	movk	w14, #0x6744, lsl #16
     8bc:      	and	w12, w12, w14
     8c0:      	ldr	w13, [sp, #0xfc]
     8c4:      	eor	w13, w13, w14
     8c8:      	and	w13, w13, w9
     8cc:      	eor	w12, w12, w13
     8d0:      	str	w12, [sp, #0xf8]
     8d4:      	ldr	w12, [sp, #0x100]
     8d8:      	ldr	w13, [sp, #0xf8]
     8dc:      	eor	w12, w12, w13
     8e0:      	eor	w12, w12, w9
     8e4:      	str	w12, [sp, #0xf4]
     8e8:      	ldr	w12, [sp, #0xf4]
     8ec:      	mov	w14, #0x621f            // =25119
     8f0:      	movk	w14, #0x6744, lsl #16
     8f4:      	and	w12, w12, w14
     8f8:      	ldr	w13, [sp, #0xf4]
     8fc:      	eor	w13, w13, w14
     900:      	and	w13, w13, w9
     904:      	eor	w12, w12, w13
     908:      	str	w12, [sp, #0xf0]
     90c:      	ldr	w12, [sp, #0xf0]
     910:      	eor	w12, w12, w9
     914:      	str	w12, [sp, #0xec]
     918:      	ldr	w13, [sp, #0xec]
     91c:      	mov	w12, wzr
     920:      	subs	w13, w12, w13
     924:      	str	w13, [sp, #0xe8]
     928:      	ldr	w13, [sp, #0xf4]
     92c:      	eor	w13, w11, w13, lsr #1
     930:      	str	w13, [sp, #0xe4]
     934:      	ldr	w13, [sp, #0xe8]
     938:      	eor	w13, w13, w9
     93c:      	str	w13, [sp, #0xe0]
     940:      	ldr	w13, [sp, #0xe0]
     944:      	mov	w14, #0xe13e            // =57662
     948:      	movk	w14, #0x8afc, lsl #16
     94c:      	and	w13, w14, w13
     950:      	ldr	w15, [sp, #0xe0]
     954:      	eor	w14, w14, w15
     958:      	and	w14, w14, w9
     95c:      	eor	w13, w13, w14
     960:      	str	w13, [sp, #0xdc]
     964:      	ldr	w13, [sp, #0xe4]
     968:      	ldr	w14, [sp, #0xdc]
     96c:      	eor	w13, w13, w14
     970:      	eor	w13, w13, w9
     974:      	str	w13, [sp, #0xd8]
     978:      	ldr	w13, [sp, #0xd8]
     97c:      	eor	w13, w13, w9
     980:      	str	w13, [sp, #0xd4]
     984:      	ldr	w13, [sp, #0xd4]
     988:      	and	w13, w13, #0x1
     98c:      	str	w13, [sp, #0xd0]
     990:      	ldr	w13, [sp, #0xd0]
     994:      	subs	w13, w12, w13
     998:      	str	w13, [sp, #0xcc]
     99c:      	ldr	w13, [sp, #0xd8]
     9a0:      	eor	w13, w11, w13, lsr #1
     9a4:      	str	w13, [sp, #0xc8]
     9a8:      	ldr	w13, [sp, #0xcc]
     9ac:      	and	w13, w8, w13
     9b0:      	str	w13, [sp, #0xc4]
     9b4:      	ldr	w13, [sp, #0xc4]
     9b8:      	eor	w13, w13, w9
     9bc:      	str	w13, [sp, #0xc0]
     9c0:      	ldr	w13, [sp, #0xc8]
     9c4:      	ldr	w14, [sp, #0xc0]
     9c8:      	eor	w13, w13, w14
     9cc:      	eor	w13, w13, w9
     9d0:      	str	w13, [sp, #0xbc]
     9d4:      	ldr	w13, [sp, #0xbc]
     9d8:      	eor	w13, w13, w9
     9dc:      	str	w13, [sp, #0xb8]
     9e0:      	ldr	w13, [sp, #0xb8]
     9e4:      	and	w13, w13, #0x1
     9e8:      	str	w13, [sp, #0xb4]
     9ec:      	ldr	w13, [sp, #0xb4]
     9f0:      	subs	w13, w12, w13
     9f4:      	str	w13, [sp, #0xb0]
     9f8:      	ldr	w13, [sp, #0xbc]
     9fc:      	eor	w13, w11, w13, lsr #1
     a00:      	str	w13, [sp, #0xac]
     a04:      	ldr	w13, [sp, #0xb0]
     a08:      	and	w13, w8, w13
     a0c:      	str	w13, [sp, #0xa8]
     a10:      	ldr	w13, [sp, #0xa8]
     a14:      	eor	w13, w13, w9
     a18:      	str	w13, [sp, #0xa4]
     a1c:      	ldr	w13, [sp, #0xac]
     a20:      	ldr	w14, [sp, #0xa4]
     a24:      	eor	w13, w13, w14
     a28:      	eor	w13, w13, w9
     a2c:      	str	w13, [sp, #0xa0]
     a30:      	ldr	w13, [sp, #0xa0]
     a34:      	eor	w13, w13, w9
     a38:      	str	w13, [sp, #0x9c]
     a3c:      	ldr	w13, [sp, #0x9c]
     a40:      	and	w13, w13, #0x1
     a44:      	str	w13, [sp, #0x98]
     a48:      	ldr	w13, [sp, #0x98]
     a4c:      	subs	w13, w12, w13
     a50:      	str	w13, [sp, #0x94]
     a54:      	ldr	w13, [sp, #0xa0]
     a58:      	eor	w13, w11, w13, lsr #1
     a5c:      	str	w13, [sp, #0x90]
     a60:      	ldr	w13, [sp, #0x94]
     a64:      	and	w13, w8, w13
     a68:      	str	w13, [sp, #0x8c]
     a6c:      	ldr	w13, [sp, #0x8c]
     a70:      	eor	w13, w13, w9
     a74:      	str	w13, [sp, #0x88]
     a78:      	ldr	w13, [sp, #0x90]
     a7c:      	ldr	w14, [sp, #0x88]
     a80:      	eor	w13, w13, w14
     a84:      	eor	w13, w13, w9
     a88:      	str	w13, [sp, #0x84]
     a8c:      	ldr	w13, [sp, #0x84]
     a90:      	eor	w13, w13, w9
     a94:      	str	w13, [sp, #0x80]
     a98:      	ldr	w13, [sp, #0x80]
     a9c:      	and	w13, w13, #0x1
     aa0:      	str	w13, [sp, #0x7c]
     aa4:      	ldr	w13, [sp, #0x7c]
     aa8:      	subs	w13, w12, w13
     aac:      	str	w13, [sp, #0x78]
     ab0:      	ldr	w13, [sp, #0x84]
     ab4:      	eor	w13, w11, w13, lsr #1
     ab8:      	str	w13, [sp, #0x74]
     abc:      	ldr	w13, [sp, #0x78]
     ac0:      	and	w13, w8, w13
     ac4:      	str	w13, [sp, #0x70]
     ac8:      	ldr	w13, [sp, #0x70]
     acc:      	eor	w13, w13, w9
     ad0:      	str	w13, [sp, #0x6c]
     ad4:      	ldr	w13, [sp, #0x74]
     ad8:      	ldr	w14, [sp, #0x6c]
     adc:      	eor	w13, w13, w14
     ae0:      	eor	w13, w13, w9
     ae4:      	str	w13, [sp, #0x68]
     ae8:      	ldr	w13, [sp, #0x68]
     aec:      	eor	w13, w13, w9
     af0:      	str	w13, [sp, #0x64]
     af4:      	ldr	w13, [sp, #0x64]
     af8:      	and	w13, w13, #0x1
     afc:      	str	w13, [sp, #0x60]
     b00:      	ldr	w13, [sp, #0x60]
     b04:      	subs	w13, w12, w13
     b08:      	str	w13, [sp, #0x5c]
     b0c:      	ldr	w13, [sp, #0x68]
     b10:      	eor	w13, w11, w13, lsr #1
     b14:      	str	w13, [sp, #0x58]
     b18:      	ldr	w13, [sp, #0x5c]
     b1c:      	and	w13, w8, w13
     b20:      	str	w13, [sp, #0x54]
     b24:      	ldr	w13, [sp, #0x54]
     b28:      	eor	w13, w13, w9
     b2c:      	str	w13, [sp, #0x50]
     b30:      	ldr	w13, [sp, #0x58]
     b34:      	ldr	w14, [sp, #0x50]
     b38:      	eor	w13, w13, w14
     b3c:      	eor	w13, w13, w9
     b40:      	str	w13, [sp, #0x4c]
     b44:      	ldr	w13, [sp, #0x4c]
     b48:      	eor	w13, w13, w9
     b4c:      	str	w13, [sp, #0x48]
     b50:      	ldr	w13, [sp, #0x48]
     b54:      	and	w13, w13, #0x1
     b58:      	str	w13, [sp, #0x44]
     b5c:      	ldr	w13, [sp, #0x44]
     b60:      	subs	w13, w12, w13
     b64:      	str	w13, [sp, #0x40]
     b68:      	ldr	w13, [sp, #0x4c]
     b6c:      	eor	w13, w11, w13, lsr #1
     b70:      	str	w13, [sp, #0x3c]
     b74:      	ldr	w13, [sp, #0x40]
     b78:      	and	w13, w8, w13
     b7c:      	str	w13, [sp, #0x38]
     b80:      	ldr	w13, [sp, #0x38]
     b84:      	eor	w13, w13, w9
     b88:      	str	w13, [sp, #0x34]
     b8c:      	ldr	w13, [sp, #0x3c]
     b90:      	ldr	w14, [sp, #0x34]
     b94:      	eor	w13, w13, w14
     b98:      	eor	w13, w13, w9
     b9c:      	str	w13, [sp, #0x30]
     ba0:      	ldr	w13, [sp, #0x30]
     ba4:      	eor	w13, w13, w9
     ba8:      	str	w13, [sp, #0x2c]
     bac:      	ldr	w13, [sp, #0x2c]
     bb0:      	and	w13, w13, #0x1
     bb4:      	str	w13, [sp, #0x28]
     bb8:      	ldr	w13, [sp, #0x28]
     bbc:      	subs	w12, w12, w13
     bc0:      	str	w12, [sp, #0x24]
     bc4:      	ldr	w12, [sp, #0x30]
     bc8:      	eor	w11, w11, w12, lsr #1
     bcc:      	str	w11, [sp, #0x20]
     bd0:      	ldr	w11, [sp, #0x24]
     bd4:      	and	w8, w8, w11
     bd8:      	str	w8, [sp, #0x1c]
     bdc:      	ldr	w8, [sp, #0x1c]
     be0:      	eor	w8, w8, w9
     be4:      	str	w8, [sp, #0x18]
     be8:      	ldr	w8, [sp, #0x20]
     bec:      	ldr	w11, [sp, #0x18]
     bf0:      	eor	w8, w8, w11
     bf4:      	eor	w8, w8, w9
     bf8:      	str	w8, [sp, #0x14]
     bfc:      	ldr	w8, [sp, #0x14]
     c00:      	eor	w8, w8, w10
     c04:      	eor	w8, w8, w9
     c08:      	str	w8, [sp, #0x10]
     c0c:      	ldr	w8, [sp, #0x10]
     c10:      	eor	w8, w8, w9
     c14:      	str	w8, [sp, #0xc]
     c18:      	ldr	w0, [sp, #0xc]
     c1c:      	ldr	x29, [sp, #0x110]
     c20:      	add	sp, sp, #0x120
     c24:      	ret

0000000000000c28 <main>:
     c28:      	sub	sp, sp, #0x90
     c2c:      	stp	x29, x30, [sp, #0x80]
     c30:      	add	x29, sp, #0x80
     c34:      	stur	wzr, [x29, #-0x4]
     c38:      	stur	w0, [x29, #-0x8]
     c3c:      	stur	x1, [x29, #-0x10]
     c40:      	ldur	w8, [x29, #-0x8]
     c44:      	subs	w8, w8, #0x1
     c48:      	b.ne	0xc9c <main+0x74>
     c4c:      	b	0xc50 <main+0x28>
     c50:      	b	0xc54 <main+0x2c>
     c54:      	sub	x1, x29, #0x18
     c58:      	add	x2, x1, #0x4
     c5c:      	adrp	x0, 0x0 <strtoul@GLIBC_2.17>
     c60:      	add	x0, x0, #0xea8
     c64:      	bl	0x710 <__isoc99_scanf@plt>
     c68:      	subs	w8, w0, #0x2
     c6c:      	b.ne	0xc94 <main+0x6c>
     c70:      	b	0xc74 <main+0x4c>
     c74:      	ldur	w0, [x29, #-0x18]
     c78:      	ldur	w1, [x29, #-0x14]
     c7c:      	bl	0x858 <kernel>
     c80:      	mov	w1, w0
     c84:      	adrp	x0, 0x0 <strtoul@GLIBC_2.17>
     c88:      	add	x0, x0, #0xead
     c8c:      	bl	0x720 <printf@plt>
     c90:      	b	0xc54 <main+0x2c>
     c94:      	stur	wzr, [x29, #-0x4]
     c98:      	b	0xe10 <main+0x1e8>
     c9c:      	ldur	w8, [x29, #-0x8]
     ca0:      	subs	w8, w8, #0x3
     ca4:      	b.eq	0xcb8 <main+0x90>
     ca8:      	b	0xcac <main+0x84>
     cac:      	mov	w8, #0x3                // =3
     cb0:      	stur	w8, [x29, #-0x4]
     cb4:      	b	0xe10 <main+0x1e8>
     cb8:      	ldur	x8, [x29, #-0x10]
     cbc:      	ldr	x0, [x8, #0x8]
     cc0:      	mov	x1, xzr
     cc4:      	str	x1, [sp, #0x8]
     cc8:      	mov	w2, #0xa                // =10
     ccc:      	str	w2, [sp, #0x14]
     cd0:      	bl	0x6b0 <strtoul@plt>
     cd4:      	ldr	x1, [sp, #0x8]
     cd8:      	ldr	w2, [sp, #0x14]
     cdc:      	stur	x0, [x29, #-0x20]
     ce0:      	ldur	x8, [x29, #-0x10]
     ce4:      	ldr	x0, [x8, #0x10]
     ce8:      	bl	0x6b0 <strtoul@plt>
     cec:      	mov	w8, w0
     cf0:      	stur	w8, [x29, #-0x24]
     cf4:      	stur	xzr, [x29, #-0x30]
     cf8:      	mov	w0, #0x1                // =1
     cfc:      	add	x1, sp, #0x40
     d00:      	bl	0x6e0 <clock_gettime@plt>
     d04:      	cbz	w0, 0xd18 <main+0xf0>
     d08:      	b	0xd0c <main+0xe4>
     d0c:      	mov	w8, #0x2                // =2
     d10:      	stur	w8, [x29, #-0x4]
     d14:      	b	0xe10 <main+0x1e8>
     d18:      	str	xzr, [sp, #0x28]
     d1c:      	b	0xd20 <main+0xf8>
     d20:      	ldr	x8, [sp, #0x28]
     d24:      	ldur	x9, [x29, #-0x20]
     d28:      	subs	x8, x8, x9
     d2c:      	b.hs	0xda4 <main+0x17c>
     d30:      	b	0xd34 <main+0x10c>
     d34:      	str	wzr, [sp, #0x24]
     d38:      	b	0xd3c <main+0x114>
     d3c:      	ldr	w8, [sp, #0x24]
     d40:      	subs	w8, w8, #0x2
     d44:      	b.hs	0xd78 <main+0x150>
     d48:      	b	0xd4c <main+0x124>
     d4c:      	sub	x0, x29, #0x24
     d50:      	bl	0xe20 <csrd_matrix_next_value>
     d54:      	ldr	w8, [sp, #0x24]
     d58:      	mov	w9, w8
     d5c:      	sub	x8, x29, #0x18
     d60:      	str	w0, [x8, x9, lsl #2]
     d64:      	b	0xd68 <main+0x140>
     d68:      	ldr	w8, [sp, #0x24]
     d6c:      	add	w8, w8, #0x1
     d70:      	str	w8, [sp, #0x24]
     d74:      	b	0xd3c <main+0x114>
     d78:      	ldur	w0, [x29, #-0x18]
     d7c:      	ldur	w1, [x29, #-0x14]
     d80:      	bl	0x858 <kernel>
     d84:      	ldur	x8, [x29, #-0x30]
     d88:      	add	x8, x8, w0, uxtw
     d8c:      	stur	x8, [x29, #-0x30]
     d90:      	b	0xd94 <main+0x16c>
     d94:      	ldr	x8, [sp, #0x28]
     d98:      	add	x8, x8, #0x1
     d9c:      	str	x8, [sp, #0x28]
     da0:      	b	0xd20 <main+0xf8>
     da4:      	mov	w0, #0x1                // =1
     da8:      	add	x1, sp, #0x30
     dac:      	bl	0x6e0 <clock_gettime@plt>
     db0:      	cbz	w0, 0xdc4 <main+0x19c>
     db4:      	b	0xdb8 <main+0x190>
     db8:      	mov	w8, #0x2                // =2
     dbc:      	stur	w8, [x29, #-0x4]
     dc0:      	b	0xe10 <main+0x1e8>
     dc4:      	ldr	x8, [sp, #0x30]
     dc8:      	ldr	x9, [sp, #0x40]
     dcc:      	subs	x8, x8, x9
     dd0:      	scvtf	d2, x8
     dd4:      	ldr	x8, [sp, #0x38]
     dd8:      	ldr	x9, [sp, #0x48]
     ddc:      	subs	x8, x8, x9
     de0:      	scvtf	d0, x8
     de4:      	adrp	x8, 0x0 <strtoul@GLIBC_2.17>
     de8:      	ldr	d1, [x8, #0xea0]
     dec:      	fmadd	d0, d0, d1, d2
     df0:      	str	d0, [sp, #0x18]
     df4:      	ldr	d0, [sp, #0x18]
     df8:      	ldur	x1, [x29, #-0x30]
     dfc:      	adrp	x0, 0x0 <strtoul@GLIBC_2.17>
     e00:      	add	x0, x0, #0xeb1
     e04:      	bl	0x720 <printf@plt>
     e08:      	stur	wzr, [x29, #-0x4]
     e0c:      	b	0xe10 <main+0x1e8>
     e10:      	ldur	w0, [x29, #-0x4]
     e14:      	ldp	x29, x30, [sp, #0x80]
     e18:      	add	sp, sp, #0x90
     e1c:      	ret

0000000000000e20 <csrd_matrix_next_value>:
     e20:      	sub	sp, sp, #0x10
     e24:      	str	x0, [sp, #0x8]
     e28:      	ldr	x8, [sp, #0x8]
     e2c:      	ldr	w10, [x8]
     e30:      	ldr	x9, [sp, #0x8]
     e34:      	ldr	w8, [x9]
     e38:      	eor	w8, w8, w10, lsl #13
     e3c:      	str	w8, [x9]
     e40:      	ldr	x8, [sp, #0x8]
     e44:      	ldr	w10, [x8]
     e48:      	ldr	x9, [sp, #0x8]
     e4c:      	ldr	w8, [x9]
     e50:      	eor	w8, w8, w10, lsr #17
     e54:      	str	w8, [x9]
     e58:      	ldr	x8, [sp, #0x8]
     e5c:      	ldr	w10, [x8]
     e60:      	ldr	x9, [sp, #0x8]
     e64:      	ldr	w8, [x9]
     e68:      	eor	w8, w8, w10, lsl #5
     e6c:      	str	w8, [x9]
     e70:      	ldr	x8, [sp, #0x8]
     e74:      	ldr	w0, [x8]
     e78:      	add	sp, sp, #0x10
     e7c:      	ret

Disassembly of section .fini:

0000000000000e80 <_fini>:
     e80:      	nop
     e84:      	stp	x29, x30, [sp, #-0x10]!
     e88:      	mov	x29, sp
     e8c:      	ldp	x29, x30, [sp], #0x10
     e90:      	ret
