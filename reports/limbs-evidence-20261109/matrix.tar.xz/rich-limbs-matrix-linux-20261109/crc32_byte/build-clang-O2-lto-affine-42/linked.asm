
/work/experiments/runs/rich-limbs-matrix-linux-20261109/crc32_byte/build-clang-O2-lto-affine-42/program:	file format elf64-littleaarch64

Disassembly of section .init:

0000000000000678 <_init>:
     678:      	nop
     67c:      	stp	x29, x30, [sp, #-0x10]!
     680:      	mov	x29, sp
     684:      	bl	0x774 <call_weak_fn>
     688:      	ldp	x29, x30, [sp], #0x10
     68c:      	ret

Disassembly of section .plt:

0000000000000690 <.plt>:
     690:      	stp	x16, x30, [sp, #-0x10]!
     694:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e3b4>
     698:      	ldr	x17, [x16, #0xff8]
     69c:      	add	x16, x16, #0xff8
     6a0:      	br	x17
     6a4:      	nop
     6a8:      	nop
     6ac:      	nop

00000000000006b0 <strtoul@plt>:
     6b0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6b4:      	ldr	x17, [x16]
     6b8:      	add	x16, x16, #0x0
     6bc:      	br	x17

00000000000006c0 <__libc_start_main@plt>:
     6c0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6c4:      	ldr	x17, [x16, #0x8]
     6c8:      	add	x16, x16, #0x8
     6cc:      	br	x17

00000000000006d0 <__cxa_finalize@plt>:
     6d0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6d4:      	ldr	x17, [x16, #0x10]
     6d8:      	add	x16, x16, #0x10
     6dc:      	br	x17

00000000000006e0 <clock_gettime@plt>:
     6e0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6e4:      	ldr	x17, [x16, #0x18]
     6e8:      	add	x16, x16, #0x18
     6ec:      	br	x17

00000000000006f0 <__gmon_start__@plt>:
     6f0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6f4:      	ldr	x17, [x16, #0x20]
     6f8:      	add	x16, x16, #0x20
     6fc:      	br	x17

0000000000000700 <abort@plt>:
     700:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     704:      	ldr	x17, [x16, #0x28]
     708:      	add	x16, x16, #0x28
     70c:      	br	x17

0000000000000710 <__isoc99_scanf@plt>:
     710:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     714:      	ldr	x17, [x16, #0x30]
     718:      	add	x16, x16, #0x30
     71c:      	br	x17

0000000000000720 <printf@plt>:
     720:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     724:      	ldr	x17, [x16, #0x38]
     728:      	add	x16, x16, #0x38
     72c:      	br	x17

Disassembly of section .text:

0000000000000740 <_start>:
     740:      	nop
     744:      	mov	x29, #0x0               // =0
     748:      	mov	x30, #0x0               // =0
     74c:      	mov	x5, x0
     750:      	ldr	x1, [sp]
     754:      	add	x2, sp, #0x8
     758:      	mov	x6, sp
     75c:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e3b4>
     760:      	ldr	x0, [x0, #0xfd8]
     764:      	mov	x3, #0x0                // =0
     768:      	mov	x4, #0x0                // =0
     76c:      	bl	0x6c0 <__libc_start_main@plt>
     770:      	bl	0x700 <abort@plt>

0000000000000774 <call_weak_fn>:
     774:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e3b4>
     778:      	ldr	x0, [x0, #0xfd0]
     77c:      	cbz	x0, 0x784 <call_weak_fn+0x10>
     780:      	b	0x6f0 <__gmon_start__@plt>
     784:      	ret
     788:      	nop
     78c:      	nop

0000000000000790 <deregister_tm_clones>:
     790:      	adrp	x0, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     794:      	add	x0, x0, #0x50
     798:      	adrp	x1, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     79c:      	add	x1, x1, #0x50
     7a0:      	cmp	x1, x0
     7a4:      	b.eq	0x7bc <deregister_tm_clones+0x2c>
     7a8:      	adrp	x1, 0x1f000 <__FRAME_END__+0x1e3b4>
     7ac:      	ldr	x1, [x1, #0xfc0]
     7b0:      	cbz	x1, 0x7bc <deregister_tm_clones+0x2c>
     7b4:      	mov	x16, x1
     7b8:      	br	x16
     7bc:      	ret

00000000000007c0 <register_tm_clones>:
     7c0:      	adrp	x0, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     7c4:      	add	x0, x0, #0x50
     7c8:      	adrp	x1, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     7cc:      	add	x1, x1, #0x50
     7d0:      	sub	x1, x1, x0
     7d4:      	lsr	x2, x1, #63
     7d8:      	add	x1, x2, x1, asr #3
     7dc:      	asr	x1, x1, #1
     7e0:      	cbz	x1, 0x7f8 <register_tm_clones+0x38>
     7e4:      	adrp	x2, 0x1f000 <__FRAME_END__+0x1e3b4>
     7e8:      	ldr	x2, [x2, #0xfe0]
     7ec:      	cbz	x2, 0x7f8 <register_tm_clones+0x38>
     7f0:      	mov	x16, x2
     7f4:      	br	x16
     7f8:      	ret
     7fc:      	nop

0000000000000800 <__do_global_dtors_aux>:
     800:      	paciasp
     804:      	stp	x29, x30, [sp, #-0x20]!
     808:      	mov	x29, sp
     80c:      	str	x19, [sp, #0x10]
     810:      	adrp	x19, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     814:      	ldrb	w0, [x19, #0x50]
     818:      	tbnz	w0, #0x0, 0x840 <__do_global_dtors_aux+0x40>
     81c:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e3b4>
     820:      	ldr	x0, [x0, #0xfc8]
     824:      	cbz	x0, 0x834 <__do_global_dtors_aux+0x34>
     828:      	adrp	x0, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     82c:      	ldr	x0, [x0, #0x48]
     830:      	bl	0x6d0 <__cxa_finalize@plt>
     834:      	bl	0x790 <deregister_tm_clones>
     838:      	mov	w0, #0x1                // =1
     83c:      	strb	w0, [x19, #0x50]
     840:      	ldr	x19, [sp, #0x10]
     844:      	ldp	x29, x30, [sp], #0x20
     848:      	autiasp
     84c:      	ret

0000000000000850 <frame_dummy>:
     850:      	bti	c
     854:      	b	0x7c0 <register_tm_clones>

0000000000000858 <main>:
     858:      	sub	sp, sp, #0x90
     85c:      	stp	x29, x30, [sp, #0x40]
     860:      	str	x25, [sp, #0x50]
     864:      	stp	x24, x23, [sp, #0x60]
     868:      	stp	x22, x21, [sp, #0x70]
     86c:      	stp	x20, x19, [sp, #0x80]
     870:      	add	x29, sp, #0x40
     874:      	cmp	w0, #0x3
     878:      	b.eq	0x95c <main+0x104>
     87c:      	cmp	w0, #0x1
     880:      	b.ne	0xa70 <main+0x218>
     884:      	adrp	x8, 0x0 <strtoul@GLIBC_2.17>
     888:      	adrp	x9, 0x0 <strtoul@GLIBC_2.17>
     88c:      	mov	w21, #0x4190            // =16784
     890:      	ldr	q0, [x8, #0xaf0]
     894:      	mov	w22, #0x7cdf            // =31967
     898:      	mov	w23, #0x8832            // =34866
     89c:      	mov	w24, #0xc419            // =50201
     8a0:      	movk	w21, #0x76dc, lsl #16
     8a4:      	movk	w22, #0x1247, lsl #16
     8a8:      	str	q0, [sp, #0x10]
     8ac:      	ldr	q0, [x9, #0xb00]
     8b0:      	adrp	x19, 0x0 <strtoul@GLIBC_2.17>
     8b4:      	add	x19, x19, #0xb18
     8b8:      	movk	w23, #0xedb, lsl #16
     8bc:      	movk	w24, #0x76d, lsl #16
     8c0:      	sub	x25, x29, #0x10
     8c4:      	adrp	x20, 0x0 <strtoul@GLIBC_2.17>
     8c8:      	add	x20, x20, #0xb1d
     8cc:      	str	q0, [sp]
     8d0:      	sub	x1, x29, #0x10
     8d4:      	add	x2, x25, #0x4
     8d8:      	mov	x0, x19
     8dc:      	bl	0x710 <__isoc99_scanf@plt>
     8e0:      	cmp	w0, #0x2
     8e4:      	b.ne	0xaac <main+0x254>
     8e8:      	ldur	w8, [x29, #-0x10]
     8ec:      	ldurb	w9, [x29, #-0xc]
     8f0:      	mov	x0, x20
     8f4:      	ldp	q1, q2, [sp]
     8f8:      	eon	w8, w9, w8
     8fc:      	dup	v0.4s, w8
     900:      	lsl	w9, w8, #30
     904:      	sbfx	w10, w8, #0, #1
     908:      	and	w9, w23, w9, asr #31
     90c:      	and	v0.16b, v0.16b, v2.16b
     910:      	eor	w8, w9, w8, lsr #6
     914:      	and	w9, w10, w24
     918:      	cmeq	v0.4s, v0.4s, #0
     91c:      	eor	w9, w8, w9
     920:      	tst	w8, #0x2
     924:      	sbfx	w12, w9, #0, #1
     928:      	csinv	w8, w22, wzr, ne
     92c:      	bic	v0.16b, v1.16b, v0.16b
     930:      	ext	v1.16b, v0.16b, v0.16b, #0x8
     934:      	eor	v0.8b, v0.8b, v1.8b
     938:      	fmov	x10, d0
     93c:      	lsr	x11, x10, #32
     940:      	eor	w9, w10, w9
     944:      	and	w10, w12, w21
     948:      	eor	w9, w9, w11
     94c:      	eor	w9, w10, w9, lsr #2
     950:      	eor	w1, w9, w8
     954:      	bl	0x720 <printf@plt>
     958:      	b	0x8d0 <main+0x78>
     95c:      	ldr	x0, [x1, #0x8]
     960:      	mov	x19, x1
     964:      	mov	x1, xzr
     968:      	mov	w2, #0xa                // =10
     96c:      	bl	0x6b0 <strtoul@plt>
     970:      	ldr	x8, [x19, #0x10]
     974:      	mov	x20, x0
     978:      	mov	x1, xzr
     97c:      	mov	w2, #0xa                // =10
     980:      	mov	x0, x8
     984:      	bl	0x6b0 <strtoul@plt>
     988:      	mov	x21, x0
     98c:      	sub	x1, x29, #0x10
     990:      	mov	w0, #0x1                // =1
     994:      	bl	0x6e0 <clock_gettime@plt>
     998:      	cbnz	w0, 0xa68 <main+0x210>
     99c:      	mov	x19, xzr
     9a0:      	cbz	x20, 0xa58 <main+0x200>
     9a4:      	adrp	x9, 0x0 <strtoul@GLIBC_2.17>
     9a8:      	adrp	x10, 0x0 <strtoul@GLIBC_2.17>
     9ac:      	mov	w8, #0x4190             // =16784
     9b0:      	ldr	q0, [x9, #0xaf0]
     9b4:      	ldr	q1, [x10, #0xb00]
     9b8:      	mov	w9, #0x7cdf             // =31967
     9bc:      	mov	w10, #0x8832            // =34866
     9c0:      	mov	w11, #0xc419            // =50201
     9c4:      	movk	w8, #0x76dc, lsl #16
     9c8:      	movk	w9, #0x1247, lsl #16
     9cc:      	movk	w10, #0xedb, lsl #16
     9d0:      	movk	w11, #0x76d, lsl #16
     9d4:      	eor	w12, w21, w21, lsl #13
     9d8:      	eor	w12, w12, w12, lsr #17
     9dc:      	eor	w12, w12, w12, lsl #5
     9e0:      	eor	w13, w12, w12, lsl #13
     9e4:      	eor	w13, w13, w13, lsr #17
     9e8:      	eor	w21, w13, w13, lsl #5
     9ec:      	and	w13, w21, #0xff
     9f0:      	eon	w12, w13, w12
     9f4:      	dup	v2.4s, w12
     9f8:      	lsl	w13, w12, #30
     9fc:      	sbfx	w14, w12, #0, #1
     a00:      	and	w13, w10, w13, asr #31
     a04:      	and	v2.16b, v2.16b, v0.16b
     a08:      	eor	w12, w13, w12, lsr #6
     a0c:      	and	w13, w14, w11
     a10:      	cmeq	v2.4s, v2.4s, #0
     a14:      	eor	w13, w12, w13
     a18:      	tst	w12, #0x2
     a1c:      	sbfx	w16, w13, #0, #1
     a20:      	csinv	w12, w9, wzr, ne
     a24:      	subs	x20, x20, #0x1
     a28:      	bic	v2.16b, v1.16b, v2.16b
     a2c:      	ext	v3.16b, v2.16b, v2.16b, #0x8
     a30:      	eor	v2.8b, v2.8b, v3.8b
     a34:      	fmov	x14, d2
     a38:      	lsr	x15, x14, #32
     a3c:      	eor	w13, w14, w13
     a40:      	and	w14, w16, w8
     a44:      	eor	w13, w13, w15
     a48:      	eor	w13, w14, w13, lsr #2
     a4c:      	eor	w12, w13, w12
     a50:      	add	x19, x19, x12
     a54:      	b.ne	0x9d4 <main+0x17c>
     a58:      	add	x1, sp, #0x20
     a5c:      	mov	w0, #0x1                // =1
     a60:      	bl	0x6e0 <clock_gettime@plt>
     a64:      	cbz	w0, 0xa78 <main+0x220>
     a68:      	mov	w0, #0x2                // =2
     a6c:      	b	0xab0 <main+0x258>
     a70:      	mov	w0, #0x3                // =3
     a74:      	b	0xab0 <main+0x258>
     a78:      	ldp	x8, x9, [sp, #0x20]
     a7c:      	adrp	x0, 0x0 <strtoul@GLIBC_2.17>
     a80:      	add	x0, x0, #0xb21
     a84:      	ldp	x10, x11, [x29, #-0x10]
     a88:      	mov	x1, x19
     a8c:      	sub	x8, x8, x10
     a90:      	sub	x9, x9, x11
     a94:      	scvtf	d0, x8
     a98:      	scvtf	d1, x9
     a9c:      	adrp	x8, 0x0 <strtoul@GLIBC_2.17>
     aa0:      	ldr	d2, [x8, #0xb10]
     aa4:      	fmadd	d0, d1, d2, d0
     aa8:      	bl	0x720 <printf@plt>
     aac:      	mov	w0, wzr
     ab0:      	ldp	x20, x19, [sp, #0x80]
     ab4:      	ldr	x25, [sp, #0x50]
     ab8:      	ldp	x22, x21, [sp, #0x70]
     abc:      	ldp	x24, x23, [sp, #0x60]
     ac0:      	ldp	x29, x30, [sp, #0x40]
     ac4:      	add	sp, sp, #0x90
     ac8:      	ret

Disassembly of section .fini:

0000000000000acc <_fini>:
     acc:      	nop
     ad0:      	stp	x29, x30, [sp, #-0x10]!
     ad4:      	mov	x29, sp
     ad8:      	ldp	x29, x30, [sp], #0x10
     adc:      	ret
