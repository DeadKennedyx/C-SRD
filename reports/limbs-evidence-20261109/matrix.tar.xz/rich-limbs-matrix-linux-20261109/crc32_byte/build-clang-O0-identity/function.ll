; ModuleID = '/work/experiments/runs/rich-limbs-matrix-linux-20261109/crc32_byte/build-clang-O0-identity/validation/compiler-0-O0/candidate.i'
source_filename = "/work/experiments/runs/rich-limbs-matrix-linux-20261109/crc32_byte/build-clang-O0-identity/validation/compiler-0-O0/candidate.i"
target datalayout = "e-m:e-i8:8:32-i16:16:32-i64:64-i128:128-n32:64-S128"
target triple = "aarch64-unknown-linux-gnu"

; Function Attrs: noinline nounwind optnone uwtable
define dso_local i32 @kernel(i32 noundef %0, i32 noundef %1) #0 {
  %3 = alloca i32, align 4
  %4 = alloca i32, align 4
  %5 = alloca i32, align 4
  %6 = alloca i32, align 4
  %7 = alloca i32, align 4
  %8 = alloca i32, align 4
  %9 = alloca i32, align 4
  %10 = alloca i32, align 4
  %11 = alloca i32, align 4
  %12 = alloca i32, align 4
  %13 = alloca i32, align 4
  %14 = alloca i32, align 4
  %15 = alloca i32, align 4
  %16 = alloca i32, align 4
  %17 = alloca i32, align 4
  %18 = alloca i32, align 4
  %19 = alloca i32, align 4
  %20 = alloca i32, align 4
  %21 = alloca i32, align 4
  %22 = alloca i32, align 4
  %23 = alloca i32, align 4
  %24 = alloca i32, align 4
  %25 = alloca i32, align 4
  %26 = alloca i32, align 4
  %27 = alloca i32, align 4
  %28 = alloca i32, align 4
  %29 = alloca i32, align 4
  %30 = alloca i32, align 4
  %31 = alloca i32, align 4
  %32 = alloca i32, align 4
  %33 = alloca i32, align 4
  %34 = alloca i32, align 4
  %35 = alloca i32, align 4
  %36 = alloca i32, align 4
  %37 = alloca i32, align 4
  %38 = alloca i32, align 4
  %39 = alloca i32, align 4
  %40 = alloca i32, align 4
  %41 = alloca i32, align 4
  %42 = alloca i32, align 4
  %43 = alloca i32, align 4
  %44 = alloca i32, align 4
  %45 = alloca i32, align 4
  %46 = alloca i32, align 4
  %47 = alloca i32, align 4
  %48 = alloca i32, align 4
  store i32 %0, ptr %3, align 4
  store i32 %1, ptr %4, align 4
  %49 = load i32, ptr %3, align 4
  %50 = xor i32 %49, -1
  store i32 %50, ptr %5, align 4
  %51 = load i32, ptr %4, align 4
  %52 = and i32 %51, 255
  store i32 %52, ptr %6, align 4
  %53 = load i32, ptr %5, align 4
  %54 = load i32, ptr %6, align 4
  %55 = xor i32 %53, %54
  store i32 %55, ptr %7, align 4
  %56 = load i32, ptr %7, align 4
  %57 = and i32 %56, 1
  store i32 %57, ptr %8, align 4
  %58 = load i32, ptr %8, align 4
  %59 = sub i32 0, %58
  store i32 %59, ptr %9, align 4
  %60 = load i32, ptr %7, align 4
  %61 = lshr i32 %60, 1
  store i32 %61, ptr %10, align 4
  %62 = load i32, ptr %9, align 4
  %63 = and i32 -306674912, %62
  store i32 %63, ptr %11, align 4
  %64 = load i32, ptr %10, align 4
  %65 = load i32, ptr %11, align 4
  %66 = xor i32 %64, %65
  store i32 %66, ptr %12, align 4
  %67 = load i32, ptr %12, align 4
  %68 = and i32 %67, 1
  store i32 %68, ptr %13, align 4
  %69 = load i32, ptr %13, align 4
  %70 = sub i32 0, %69
  store i32 %70, ptr %14, align 4
  %71 = load i32, ptr %12, align 4
  %72 = lshr i32 %71, 1
  store i32 %72, ptr %15, align 4
  %73 = load i32, ptr %14, align 4
  %74 = and i32 -306674912, %73
  store i32 %74, ptr %16, align 4
  %75 = load i32, ptr %15, align 4
  %76 = load i32, ptr %16, align 4
  %77 = xor i32 %75, %76
  store i32 %77, ptr %17, align 4
  %78 = load i32, ptr %17, align 4
  %79 = and i32 %78, 1
  store i32 %79, ptr %18, align 4
  %80 = load i32, ptr %18, align 4
  %81 = sub i32 0, %80
  store i32 %81, ptr %19, align 4
  %82 = load i32, ptr %17, align 4
  %83 = lshr i32 %82, 1
  store i32 %83, ptr %20, align 4
  %84 = load i32, ptr %19, align 4
  %85 = and i32 -306674912, %84
  store i32 %85, ptr %21, align 4
  %86 = load i32, ptr %20, align 4
  %87 = load i32, ptr %21, align 4
  %88 = xor i32 %86, %87
  store i32 %88, ptr %22, align 4
  %89 = load i32, ptr %22, align 4
  %90 = and i32 %89, 1
  store i32 %90, ptr %23, align 4
  %91 = load i32, ptr %23, align 4
  %92 = sub i32 0, %91
  store i32 %92, ptr %24, align 4
  %93 = load i32, ptr %22, align 4
  %94 = lshr i32 %93, 1
  store i32 %94, ptr %25, align 4
  %95 = load i32, ptr %24, align 4
  %96 = and i32 -306674912, %95
  store i32 %96, ptr %26, align 4
  %97 = load i32, ptr %25, align 4
  %98 = load i32, ptr %26, align 4
  %99 = xor i32 %97, %98
  store i32 %99, ptr %27, align 4
  %100 = load i32, ptr %27, align 4
  %101 = and i32 %100, 1
  store i32 %101, ptr %28, align 4
  %102 = load i32, ptr %28, align 4
  %103 = sub i32 0, %102
  store i32 %103, ptr %29, align 4
  %104 = load i32, ptr %27, align 4
  %105 = lshr i32 %104, 1
  store i32 %105, ptr %30, align 4
  %106 = load i32, ptr %29, align 4
  %107 = and i32 -306674912, %106
  store i32 %107, ptr %31, align 4
  %108 = load i32, ptr %30, align 4
  %109 = load i32, ptr %31, align 4
  %110 = xor i32 %108, %109
  store i32 %110, ptr %32, align 4
  %111 = load i32, ptr %32, align 4
  %112 = and i32 %111, 1
  store i32 %112, ptr %33, align 4
  %113 = load i32, ptr %33, align 4
  %114 = sub i32 0, %113
  store i32 %114, ptr %34, align 4
  %115 = load i32, ptr %32, align 4
  %116 = lshr i32 %115, 1
  store i32 %116, ptr %35, align 4
  %117 = load i32, ptr %34, align 4
  %118 = and i32 -306674912, %117
  store i32 %118, ptr %36, align 4
  %119 = load i32, ptr %35, align 4
  %120 = load i32, ptr %36, align 4
  %121 = xor i32 %119, %120
  store i32 %121, ptr %37, align 4
  %122 = load i32, ptr %37, align 4
  %123 = and i32 %122, 1
  store i32 %123, ptr %38, align 4
  %124 = load i32, ptr %38, align 4
  %125 = sub i32 0, %124
  store i32 %125, ptr %39, align 4
  %126 = load i32, ptr %37, align 4
  %127 = lshr i32 %126, 1
  store i32 %127, ptr %40, align 4
  %128 = load i32, ptr %39, align 4
  %129 = and i32 -306674912, %128
  store i32 %129, ptr %41, align 4
  %130 = load i32, ptr %40, align 4
  %131 = load i32, ptr %41, align 4
  %132 = xor i32 %130, %131
  store i32 %132, ptr %42, align 4
  %133 = load i32, ptr %42, align 4
  %134 = and i32 %133, 1
  store i32 %134, ptr %43, align 4
  %135 = load i32, ptr %43, align 4
  %136 = sub i32 0, %135
  store i32 %136, ptr %44, align 4
  %137 = load i32, ptr %42, align 4
  %138 = lshr i32 %137, 1
  store i32 %138, ptr %45, align 4
  %139 = load i32, ptr %44, align 4
  %140 = and i32 -306674912, %139
  store i32 %140, ptr %46, align 4
  %141 = load i32, ptr %45, align 4
  %142 = load i32, ptr %46, align 4
  %143 = xor i32 %141, %142
  store i32 %143, ptr %47, align 4
  %144 = load i32, ptr %47, align 4
  %145 = xor i32 %144, -1
  store i32 %145, ptr %48, align 4
  %146 = load i32, ptr %48, align 4
  ret i32 %146
}

attributes #0 = { noinline nounwind optnone uwtable "frame-pointer"="non-leaf" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+fp-armv8,+neon,+outline-atomics,+v8a,-fmv" }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 1, !"wchar_size", i32 4}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 1}
!5 = !{!"Ubuntu clang version 18.1.3 (1ubuntu1)"}
