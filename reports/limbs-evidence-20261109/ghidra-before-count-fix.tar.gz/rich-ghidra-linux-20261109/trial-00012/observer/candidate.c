unsigned int kernel(unsigned int p0) {
    unsigned int v5 = (p0 & 255u);
    unsigned int v11 = (v5 * 29u);
    unsigned int v0 = (p0 >> 8u);
    unsigned int v3 = (v0 & 255u);
    unsigned int v13 = (v3 * 150u);
    unsigned int v15 = (v11 + v13);
    unsigned int v7 = (p0 >> 16u);
    unsigned int v9 = (v7 & 255u);
    unsigned int v16 = (v9 * 77u);
    unsigned int v18 = (v15 + v16);
    unsigned int v19 = (v18 >> 8u);
    unsigned int v22 = v19;
    (void)p0;
    return v22;
}
