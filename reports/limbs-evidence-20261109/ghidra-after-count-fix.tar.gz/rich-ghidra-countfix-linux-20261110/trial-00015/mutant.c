unsigned int kernel(unsigned int p0) {
    unsigned int v0 = (p0 & 255u);
    unsigned int v11 = (v0 * 29u);
    unsigned int v4 = (p0 >> 16u);
    unsigned int v3 = (v4 & 255u);
    unsigned int v13 = (v3 * 77u);
    unsigned int v15 = (v11 + v13);
    unsigned int v8 = (p0 >> 8u);
    unsigned int v7 = (v8 & 255u);
    unsigned int v16 = (v7 * 150u);
    unsigned int v18 = (v15 + v16);
    unsigned int v19 = (v18 >> 8u);
    unsigned int v22 = v19;
    (void)p0;
    return (v22 + 1u);
}
