#include <stdint.h>
uint32_t kernel(uint32_t x){return x*65535u;}
