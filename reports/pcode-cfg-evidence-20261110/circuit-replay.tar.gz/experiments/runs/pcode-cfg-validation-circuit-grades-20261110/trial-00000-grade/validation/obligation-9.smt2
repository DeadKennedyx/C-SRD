; 
(set-info :status unknown)
(declare-fun local_1 () Bool)
(declare-fun local_0 () Bool)
(declare-fun local_2 () Bool)
(assert
 (let (($x67874 (and true local_1)))
(let (($x67005 (or (or (or false (and true local_2)) (and true local_0)) $x67874)))
(and (distinct (or local_2 local_0 local_1) $x67005) true))))
(check-sat)
