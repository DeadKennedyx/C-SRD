; 
(set-info :status unknown)
(declare-fun local_2 () Bool)
(declare-fun local_0 () Bool)
(declare-fun local_1 () Bool)
(assert
 (let (($x68098 (and true local_2)))
(let (($x67847 (and true local_0)))
(let (($x68114 (or (or false (and true local_1)) $x67847)))
(and (distinct (or local_1 local_0 local_2) (or $x68114 $x68098)) true)))))
(check-sat)
