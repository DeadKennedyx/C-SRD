; 
(set-info :status unknown)
(declare-fun local_1 () Bool)
(declare-fun local_0 () Bool)
(declare-fun local_2 () Bool)
(assert
 (let (($x108078 (or (or false (and (and true local_0) local_2)) (and (and true (not local_0)) local_1))))
(let (($x108079 (ite local_0 local_2 local_1)))
(and (distinct $x108079 $x108078) true))))
(check-sat)
