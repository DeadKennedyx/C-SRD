; 
(set-info :status unknown)
(declare-fun local_1 () Bool)
(declare-fun local_0 () Bool)
(assert
 (let (($x67855 (or (or false (and (and true (not local_0)) (not local_1))) (and (and true local_0) local_1))))
(let (($x67856 (= local_0 local_1)))
(and (distinct $x67856 $x67855) true))))
(check-sat)
