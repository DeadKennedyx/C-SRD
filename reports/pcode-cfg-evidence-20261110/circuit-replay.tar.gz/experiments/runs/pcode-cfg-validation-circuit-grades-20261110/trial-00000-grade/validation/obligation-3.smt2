; 
(set-info :status unknown)
(declare-fun local_2 () Bool)
(declare-fun local_0 () Bool)
(declare-fun local_1 () Bool)
(assert
 (let (($x67862 (or (or false (and (and true local_0) local_1)) (and (and true (not local_0)) local_2))))
(let (($x67863 (ite local_0 local_1 local_2)))
(and (distinct $x67863 $x67862) true))))
(check-sat)
