; 
(set-info :status unknown)
(assert
 (let (($x66587 (or false true)))
(and (distinct true $x66587) true)))
(check-sat)
