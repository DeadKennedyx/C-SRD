; 
(set-info :status unknown)
(declare-fun local_1 () Bool)
(declare-fun local_0 () Bool)
(assert
 (let (($x67847 (and true local_0)))
(let (($x67851 (and $x67847 local_1)))
(let (($x67861 (or false $x67851)))
(let (($x108144 (and local_0 local_1)))
(and (distinct $x108144 $x67861) true))))))
(check-sat)
