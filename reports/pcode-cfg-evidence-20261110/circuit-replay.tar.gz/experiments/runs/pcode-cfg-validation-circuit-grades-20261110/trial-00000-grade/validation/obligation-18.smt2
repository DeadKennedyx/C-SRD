; 
(set-info :status unknown)
(declare-fun local_0 () Bool)
(assert
 (let (($x67847 (and true local_0)))
(let (($x67896 (or false $x67847)))
(and (distinct local_0 $x67896) true))))
(check-sat)
