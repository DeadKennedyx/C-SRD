; 
(set-info :status unknown)
(declare-fun local_0 () Bool)
(assert
 (let (($x67806 (not local_0)))
(and (distinct $x67806 (or false (and true $x67806))) true)))
(check-sat)
