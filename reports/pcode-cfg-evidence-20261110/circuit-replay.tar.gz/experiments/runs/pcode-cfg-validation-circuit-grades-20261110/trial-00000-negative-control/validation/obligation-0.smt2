; 
(set-info :status unknown)
(assert
 (let (($x5 (or false true)))
(and (distinct true $x5) true)))
(check-sat)
