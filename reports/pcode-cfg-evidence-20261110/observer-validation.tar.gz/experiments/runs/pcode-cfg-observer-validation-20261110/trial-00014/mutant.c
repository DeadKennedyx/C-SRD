unsigned int kernel(unsigned int p0, unsigned int p1) {
    unsigned int v0 = (p0 < p1);
    v0 = v0 & 255u;
    unsigned int v1 = (p1 - p0);
    unsigned int v2 = (p0 - p1);
    unsigned int v3 = ((v0 != 0u) ? v1 : v2);
    (void)p0;
    (void)p1;
    return (v3 + 1u);
}
