
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

uint kernel(uint p0,uint p1)

{
  uint uVar1;
  
  uVar1 = p0 * 0x19660d + 0x3c6ef35f;
  uVar1 = ((-(uVar1 & 1) & p1) + uVar1) * 0x19660d + 0x3c6ef35f;
  uVar1 = ((-(uVar1 & 1) & p1) + uVar1) * 0x19660d + 0x3c6ef35f;
  uVar1 = ((-(uVar1 & 1) & p1) + uVar1) * 0x19660d + 0x3c6ef35f;
  uVar1 = ((-(uVar1 & 1) & p1) + uVar1) * 0x19660d + 0x3c6ef35f;
  return (-(uVar1 & 1) & p1) + uVar1;
}

