
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

uint kernel(uint p0,uint p1)

{
  uint uVar1;
  int iVar2;
  
  iVar2 = 5;
  do {
    uVar1 = p0 * 0x19660d + 0x3c6ef35f;
    iVar2 = iVar2 + -1;
    p0 = (-(uVar1 & 1) & p1) + uVar1;
  } while (iVar2 != 0);
  return p0;
}

