
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

uint kernel(uint p0,uint p1)

{
  uint uVar1;
  
  uVar1 = p1 - p0;
  if (p1 <= p0) {
    uVar1 = p0 - p1;
  }
  return uVar1;
}

