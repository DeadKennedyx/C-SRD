unsigned int kernel(unsigned int p0, unsigned int p1) {
    unsigned int v0 = (p1 - p0);
    unsigned int v1 = (p1 <= p0);
    v1 = v1 & 255u;
    unsigned int v2 = (p0 - p1);
    unsigned int v3 = ((v1 != 0u) ? v2 : v0);
    (void)p0;
    (void)p1;
    return (v3 + 1u);
}
