
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

uint kernel(uint p0,uint p1)

{
  uint uVar1;
  uint uVar2;
  
  uVar2 = p0 * 0x19660d + 0x3c6ef35f;
  uVar1 = uVar2 + p1;
  if ((uVar2 & 1) == 0) {
    uVar1 = uVar2;
  }
  uVar2 = uVar1 * 0x19660d + 0x3c6ef35f;
  uVar1 = uVar2 + p1;
  if ((uVar2 & 1) == 0) {
    uVar1 = uVar2;
  }
  uVar2 = uVar1 * 0x19660d + 0x3c6ef35f;
  uVar1 = uVar2 + p1;
  if ((uVar2 & 1) == 0) {
    uVar1 = uVar2;
  }
  uVar2 = uVar1 * 0x19660d + 0x3c6ef35f;
  uVar1 = uVar2 + p1;
  if ((uVar2 & 1) == 0) {
    uVar1 = uVar2;
  }
  uVar2 = uVar1 * 0x19660d + 0x3c6ef35f;
  uVar1 = uVar2 + p1;
  if ((uVar2 & 1) == 0) {
    uVar1 = uVar2;
  }
  return uVar1;
}

