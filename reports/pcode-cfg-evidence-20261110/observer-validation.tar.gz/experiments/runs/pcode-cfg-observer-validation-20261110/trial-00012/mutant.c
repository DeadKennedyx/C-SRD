unsigned int kernel(unsigned int p0, unsigned int p1) {
    unsigned int v0 = (p1 - p0);
    unsigned int v1 = (p0 - p1);
    unsigned int v2 = (p0 < p1);
    v2 = v2 & 255u;
    unsigned int v3 = ((v2 != 0u) ? v0 : v1);
    (void)p0;
    (void)p1;
    return (v3 + 1u);
}
