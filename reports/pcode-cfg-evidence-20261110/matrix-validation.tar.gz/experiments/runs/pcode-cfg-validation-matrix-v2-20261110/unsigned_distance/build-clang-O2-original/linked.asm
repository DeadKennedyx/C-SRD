
/work/experiments/runs/pcode-cfg-validation-matrix-v2-20261110/unsigned_distance/build-clang-O2-original/program:	file format elf64-littleaarch64

Disassembly of section .init:

0000000000000678 <_init>:
     678:      	nop
     67c:      	stp	x29, x30, [sp, #-0x10]!
     680:      	mov	x29, sp
     684:      	bl	0x774 <call_weak_fn>
     688:      	ldp	x29, x30, [sp], #0x10
     68c:      	ret

Disassembly of section .plt:

0000000000000690 <.plt>:
     690:      	stp	x16, x30, [sp, #-0x10]!
     694:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e4d0>
     698:      	ldr	x17, [x16, #0xff8]
     69c:      	add	x16, x16, #0xff8
     6a0:      	br	x17
     6a4:      	nop
     6a8:      	nop
     6ac:      	nop

00000000000006b0 <strtoul@plt>:
     6b0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6b4:      	ldr	x17, [x16]
     6b8:      	add	x16, x16, #0x0
     6bc:      	br	x17

00000000000006c0 <__libc_start_main@plt>:
     6c0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6c4:      	ldr	x17, [x16, #0x8]
     6c8:      	add	x16, x16, #0x8
     6cc:      	br	x17

00000000000006d0 <__cxa_finalize@plt>:
     6d0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6d4:      	ldr	x17, [x16, #0x10]
     6d8:      	add	x16, x16, #0x10
     6dc:      	br	x17

00000000000006e0 <clock_gettime@plt>:
     6e0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6e4:      	ldr	x17, [x16, #0x18]
     6e8:      	add	x16, x16, #0x18
     6ec:      	br	x17

00000000000006f0 <__gmon_start__@plt>:
     6f0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6f4:      	ldr	x17, [x16, #0x20]
     6f8:      	add	x16, x16, #0x20
     6fc:      	br	x17

0000000000000700 <abort@plt>:
     700:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     704:      	ldr	x17, [x16, #0x28]
     708:      	add	x16, x16, #0x28
     70c:      	br	x17

0000000000000710 <__isoc99_scanf@plt>:
     710:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     714:      	ldr	x17, [x16, #0x30]
     718:      	add	x16, x16, #0x30
     71c:      	br	x17

0000000000000720 <printf@plt>:
     720:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     724:      	ldr	x17, [x16, #0x38]
     728:      	add	x16, x16, #0x38
     72c:      	br	x17

Disassembly of section .text:

0000000000000740 <_start>:
     740:      	nop
     744:      	mov	x29, #0x0               // =0
     748:      	mov	x30, #0x0               // =0
     74c:      	mov	x5, x0
     750:      	ldr	x1, [sp]
     754:      	add	x2, sp, #0x8
     758:      	mov	x6, sp
     75c:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e4d0>
     760:      	ldr	x0, [x0, #0xfd8]
     764:      	mov	x3, #0x0                // =0
     768:      	mov	x4, #0x0                // =0
     76c:      	bl	0x6c0 <__libc_start_main@plt>
     770:      	bl	0x700 <abort@plt>

0000000000000774 <call_weak_fn>:
     774:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e4d0>
     778:      	ldr	x0, [x0, #0xfd0]
     77c:      	cbz	x0, 0x784 <call_weak_fn+0x10>
     780:      	b	0x6f0 <__gmon_start__@plt>
     784:      	ret
     788:      	nop
     78c:      	nop

0000000000000790 <deregister_tm_clones>:
     790:      	adrp	x0, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     794:      	add	x0, x0, #0x50
     798:      	adrp	x1, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     79c:      	add	x1, x1, #0x50
     7a0:      	cmp	x1, x0
     7a4:      	b.eq	0x7bc <deregister_tm_clones+0x2c>
     7a8:      	adrp	x1, 0x1f000 <__FRAME_END__+0x1e4d0>
     7ac:      	ldr	x1, [x1, #0xfc0]
     7b0:      	cbz	x1, 0x7bc <deregister_tm_clones+0x2c>
     7b4:      	mov	x16, x1
     7b8:      	br	x16
     7bc:      	ret

00000000000007c0 <register_tm_clones>:
     7c0:      	adrp	x0, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     7c4:      	add	x0, x0, #0x50
     7c8:      	adrp	x1, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     7cc:      	add	x1, x1, #0x50
     7d0:      	sub	x1, x1, x0
     7d4:      	lsr	x2, x1, #63
     7d8:      	add	x1, x2, x1, asr #3
     7dc:      	asr	x1, x1, #1
     7e0:      	cbz	x1, 0x7f8 <register_tm_clones+0x38>
     7e4:      	adrp	x2, 0x1f000 <__FRAME_END__+0x1e4d0>
     7e8:      	ldr	x2, [x2, #0xfe0]
     7ec:      	cbz	x2, 0x7f8 <register_tm_clones+0x38>
     7f0:      	mov	x16, x2
     7f4:      	br	x16
     7f8:      	ret
     7fc:      	nop

0000000000000800 <__do_global_dtors_aux>:
     800:      	paciasp
     804:      	stp	x29, x30, [sp, #-0x20]!
     808:      	mov	x29, sp
     80c:      	str	x19, [sp, #0x10]
     810:      	adrp	x19, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     814:      	ldrb	w0, [x19, #0x50]
     818:      	tbnz	w0, #0x0, 0x840 <__do_global_dtors_aux+0x40>
     81c:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e4d0>
     820:      	ldr	x0, [x0, #0xfc8]
     824:      	cbz	x0, 0x834 <__do_global_dtors_aux+0x34>
     828:      	adrp	x0, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     82c:      	ldr	x0, [x0, #0x48]
     830:      	bl	0x6d0 <__cxa_finalize@plt>
     834:      	bl	0x790 <deregister_tm_clones>
     838:      	mov	w0, #0x1                // =1
     83c:      	strb	w0, [x19, #0x50]
     840:      	ldr	x19, [sp, #0x10]
     844:      	ldp	x29, x30, [sp], #0x20
     848:      	autiasp
     84c:      	ret

0000000000000850 <frame_dummy>:
     850:      	bti	c
     854:      	b	0x7c0 <register_tm_clones>

0000000000000858 <kernel>:
     858:      	sub	w8, w1, w0
     85c:      	subs	w9, w0, w1
     860:      	csel	w0, w8, w9, lo
     864:      	ret

0000000000000868 <main>:
     868:      	sub	sp, sp, #0x50
     86c:      	stp	x29, x30, [sp, #0x20]
     870:      	str	x21, [sp, #0x30]
     874:      	stp	x20, x19, [sp, #0x40]
     878:      	add	x29, sp, #0x20
     87c:      	cmp	w0, #0x3
     880:      	b.eq	0x8ec <main+0x84>
     884:      	cmp	w0, #0x1
     888:      	b.ne	0x978 <main+0x110>
     88c:      	add	x21, sp, #0x10
     890:      	adrp	x0, 0x0 <strtoul@GLIBC_2.17>
     894:      	add	x0, x0, #0x9f0
     898:      	add	x1, sp, #0x10
     89c:      	add	x2, x21, #0x4
     8a0:      	bl	0x710 <__isoc99_scanf@plt>
     8a4:      	cmp	w0, #0x2
     8a8:      	b.ne	0x9b4 <main+0x14c>
     8ac:      	adrp	x19, 0x0 <strtoul@GLIBC_2.17>
     8b0:      	add	x19, x19, #0x9f5
     8b4:      	adrp	x20, 0x0 <strtoul@GLIBC_2.17>
     8b8:      	add	x20, x20, #0x9f0
     8bc:      	ldp	w0, w1, [sp, #0x10]
     8c0:      	bl	0x858 <kernel>
     8c4:      	mov	w1, w0
     8c8:      	mov	x0, x19
     8cc:      	bl	0x720 <printf@plt>
     8d0:      	add	x1, sp, #0x10
     8d4:      	add	x2, x21, #0x4
     8d8:      	mov	x0, x20
     8dc:      	bl	0x710 <__isoc99_scanf@plt>
     8e0:      	cmp	w0, #0x2
     8e4:      	b.eq	0x8bc <main+0x54>
     8e8:      	b	0x9b4 <main+0x14c>
     8ec:      	ldr	x0, [x1, #0x8]
     8f0:      	mov	x19, x1
     8f4:      	mov	x1, xzr
     8f8:      	mov	w2, #0xa                // =10
     8fc:      	bl	0x6b0 <strtoul@plt>
     900:      	ldr	x8, [x19, #0x10]
     904:      	mov	x20, x0
     908:      	mov	x1, xzr
     90c:      	mov	w2, #0xa                // =10
     910:      	mov	x0, x8
     914:      	bl	0x6b0 <strtoul@plt>
     918:      	mov	x21, x0
     91c:      	add	x1, sp, #0x10
     920:      	mov	w0, #0x1                // =1
     924:      	bl	0x6e0 <clock_gettime@plt>
     928:      	cbnz	w0, 0x970 <main+0x108>
     92c:      	mov	x19, xzr
     930:      	cbz	x20, 0x960 <main+0xf8>
     934:      	eor	w8, w21, w21, lsl #13
     938:      	eor	w8, w8, w8, lsr #17
     93c:      	eor	w0, w8, w8, lsl #5
     940:      	eor	w8, w0, w0, lsl #13
     944:      	eor	w8, w8, w8, lsr #17
     948:      	eor	w21, w8, w8, lsl #5
     94c:      	mov	w1, w21
     950:      	bl	0x858 <kernel>
     954:      	add	x19, x19, w0, uxtw
     958:      	subs	x20, x20, #0x1
     95c:      	b.ne	0x934 <main+0xcc>
     960:      	mov	x1, sp
     964:      	mov	w0, #0x1                // =1
     968:      	bl	0x6e0 <clock_gettime@plt>
     96c:      	cbz	w0, 0x980 <main+0x118>
     970:      	mov	w0, #0x2                // =2
     974:      	b	0x9b8 <main+0x150>
     978:      	mov	w0, #0x3                // =3
     97c:      	b	0x9b8 <main+0x150>
     980:      	ldp	x8, x9, [sp]
     984:      	adrp	x0, 0x0 <strtoul@GLIBC_2.17>
     988:      	add	x0, x0, #0x9f9
     98c:      	ldp	x10, x11, [sp, #0x10]
     990:      	mov	x1, x19
     994:      	sub	x8, x8, x10
     998:      	sub	x9, x9, x11
     99c:      	scvtf	d0, x8
     9a0:      	scvtf	d1, x9
     9a4:      	adrp	x8, 0x0 <strtoul@GLIBC_2.17>
     9a8:      	ldr	d2, [x8, #0x9e8]
     9ac:      	fmadd	d0, d1, d2, d0
     9b0:      	bl	0x720 <printf@plt>
     9b4:      	mov	w0, wzr
     9b8:      	ldp	x20, x19, [sp, #0x40]
     9bc:      	ldr	x21, [sp, #0x30]
     9c0:      	ldp	x29, x30, [sp, #0x20]
     9c4:      	add	sp, sp, #0x50
     9c8:      	ret

Disassembly of section .fini:

00000000000009cc <_fini>:
     9cc:      	nop
     9d0:      	stp	x29, x30, [sp, #-0x10]!
     9d4:      	mov	x29, sp
     9d8:      	ldp	x29, x30, [sp], #0x10
     9dc:      	ret
