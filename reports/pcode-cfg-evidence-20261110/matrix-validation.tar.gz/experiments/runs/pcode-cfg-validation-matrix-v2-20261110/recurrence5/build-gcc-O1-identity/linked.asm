
/work/experiments/runs/pcode-cfg-validation-matrix-v2-20261110/recurrence5/build-gcc-O1-identity/program:	file format elf64-littleaarch64

Disassembly of section .init:

0000000000000738 <_init>:
     738:      	nop
     73c:      	stp	x29, x30, [sp, #-0x10]!
     740:      	mov	x29, sp
     744:      	bl	0x834 <call_weak_fn>
     748:      	ldp	x29, x30, [sp], #0x10
     74c:      	ret

Disassembly of section .plt:

0000000000000750 <.plt>:
     750:      	stp	x16, x30, [sp, #-0x10]!
     754:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e304>
     758:      	ldr	x17, [x16, #0xf78]
     75c:      	add	x16, x16, #0xf78
     760:      	br	x17
     764:      	nop
     768:      	nop
     76c:      	nop

0000000000000770 <strtoul@plt>:
     770:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e304>
     774:      	ldr	x17, [x16, #0xf80]
     778:      	add	x16, x16, #0xf80
     77c:      	br	x17

0000000000000780 <__libc_start_main@plt>:
     780:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e304>
     784:      	ldr	x17, [x16, #0xf88]
     788:      	add	x16, x16, #0xf88
     78c:      	br	x17

0000000000000790 <__cxa_finalize@plt>:
     790:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e304>
     794:      	ldr	x17, [x16, #0xf90]
     798:      	add	x16, x16, #0xf90
     79c:      	br	x17

00000000000007a0 <clock_gettime@plt>:
     7a0:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e304>
     7a4:      	ldr	x17, [x16, #0xf98]
     7a8:      	add	x16, x16, #0xf98
     7ac:      	br	x17

00000000000007b0 <__printf_chk@plt>:
     7b0:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e304>
     7b4:      	ldr	x17, [x16, #0xfa0]
     7b8:      	add	x16, x16, #0xfa0
     7bc:      	br	x17

00000000000007c0 <__stack_chk_fail@plt>:
     7c0:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e304>
     7c4:      	ldr	x17, [x16, #0xfa8]
     7c8:      	add	x16, x16, #0xfa8
     7cc:      	br	x17

00000000000007d0 <__gmon_start__@plt>:
     7d0:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e304>
     7d4:      	ldr	x17, [x16, #0xfb0]
     7d8:      	add	x16, x16, #0xfb0
     7dc:      	br	x17

00000000000007e0 <abort@plt>:
     7e0:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e304>
     7e4:      	ldr	x17, [x16, #0xfb8]
     7e8:      	add	x16, x16, #0xfb8
     7ec:      	br	x17

00000000000007f0 <__isoc99_scanf@plt>:
     7f0:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e304>
     7f4:      	ldr	x17, [x16, #0xfc0]
     7f8:      	add	x16, x16, #0xfc0
     7fc:      	br	x17

Disassembly of section .text:

0000000000000800 <_start>:
     800:      	nop
     804:      	mov	x29, #0x0               // =0
     808:      	mov	x30, #0x0               // =0
     80c:      	mov	x5, x0
     810:      	ldr	x1, [sp]
     814:      	add	x2, sp, #0x8
     818:      	mov	x6, sp
     81c:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e304>
     820:      	ldr	x0, [x0, #0xff0]
     824:      	mov	x3, #0x0                // =0
     828:      	mov	x4, #0x0                // =0
     82c:      	bl	0x780 <__libc_start_main@plt>
     830:      	bl	0x7e0 <abort@plt>

0000000000000834 <call_weak_fn>:
     834:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e304>
     838:      	ldr	x0, [x0, #0xfe0]
     83c:      	cbz	x0, 0x844 <call_weak_fn+0x10>
     840:      	b	0x7d0 <__gmon_start__@plt>
     844:      	ret
     848:      	nop
     84c:      	nop

0000000000000850 <deregister_tm_clones>:
     850:      	adrp	x0, 0x20000 <data_start>
     854:      	add	x0, x0, #0x10
     858:      	adrp	x1, 0x20000 <data_start>
     85c:      	add	x1, x1, #0x10
     860:      	cmp	x1, x0
     864:      	b.eq	0x87c <deregister_tm_clones+0x2c>
     868:      	adrp	x1, 0x1f000 <__FRAME_END__+0x1e304>
     86c:      	ldr	x1, [x1, #0xfd0]
     870:      	cbz	x1, 0x87c <deregister_tm_clones+0x2c>
     874:      	mov	x16, x1
     878:      	br	x16
     87c:      	ret

0000000000000880 <register_tm_clones>:
     880:      	adrp	x0, 0x20000 <data_start>
     884:      	add	x0, x0, #0x10
     888:      	adrp	x1, 0x20000 <data_start>
     88c:      	add	x1, x1, #0x10
     890:      	sub	x1, x1, x0
     894:      	lsr	x2, x1, #63
     898:      	add	x1, x2, x1, asr #3
     89c:      	asr	x1, x1, #1
     8a0:      	cbz	x1, 0x8b8 <register_tm_clones+0x38>
     8a4:      	adrp	x2, 0x1f000 <__FRAME_END__+0x1e304>
     8a8:      	ldr	x2, [x2, #0xff8]
     8ac:      	cbz	x2, 0x8b8 <register_tm_clones+0x38>
     8b0:      	mov	x16, x2
     8b4:      	br	x16
     8b8:      	ret
     8bc:      	nop

00000000000008c0 <__do_global_dtors_aux>:
     8c0:      	paciasp
     8c4:      	stp	x29, x30, [sp, #-0x20]!
     8c8:      	mov	x29, sp
     8cc:      	str	x19, [sp, #0x10]
     8d0:      	adrp	x19, 0x20000 <data_start>
     8d4:      	ldrb	w0, [x19, #0x10]
     8d8:      	tbnz	w0, #0x0, 0x900 <__do_global_dtors_aux+0x40>
     8dc:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e304>
     8e0:      	ldr	x0, [x0, #0xfd8]
     8e4:      	cbz	x0, 0x8f4 <__do_global_dtors_aux+0x34>
     8e8:      	adrp	x0, 0x20000 <data_start>
     8ec:      	ldr	x0, [x0, #0x8]
     8f0:      	bl	0x790 <__cxa_finalize@plt>
     8f4:      	bl	0x850 <deregister_tm_clones>
     8f8:      	mov	w0, #0x1                // =1
     8fc:      	strb	w0, [x19, #0x10]
     900:      	ldr	x19, [sp, #0x10]
     904:      	ldp	x29, x30, [sp], #0x20
     908:      	autiasp
     90c:      	ret

0000000000000910 <frame_dummy>:
     910:      	bti	c
     914:      	b	0x880 <register_tm_clones>

0000000000000918 <kernel>:
     918:      	mov	w3, #0x660d             // =26125
     91c:      	movk	w3, #0x19, lsl #16
     920:      	mov	w2, #0xf35f             // =62303
     924:      	movk	w2, #0x3c6e, lsl #16
     928:      	madd	w2, w0, w3, w2
     92c:      	add	w0, w2, w1
     930:      	tst	x2, #0x1
     934:      	csel	w2, w0, w2, ne
     938:      	mov	w0, #0xf35f             // =62303
     93c:      	movk	w0, #0x3c6e, lsl #16
     940:      	madd	w2, w2, w3, w0
     944:      	add	w0, w2, w1
     948:      	tst	x2, #0x1
     94c:      	csel	w2, w0, w2, ne
     950:      	mov	w0, #0xf35f             // =62303
     954:      	movk	w0, #0x3c6e, lsl #16
     958:      	madd	w2, w2, w3, w0
     95c:      	add	w0, w2, w1
     960:      	tst	x2, #0x1
     964:      	csel	w2, w0, w2, ne
     968:      	mov	w0, #0xf35f             // =62303
     96c:      	movk	w0, #0x3c6e, lsl #16
     970:      	madd	w2, w2, w3, w0
     974:      	add	w0, w2, w1
     978:      	tst	x2, #0x1
     97c:      	csel	w2, w0, w2, ne
     980:      	mov	w0, #0xf35f             // =62303
     984:      	movk	w0, #0x3c6e, lsl #16
     988:      	madd	w0, w2, w3, w0
     98c:      	add	w1, w0, w1
     990:      	tst	x0, #0x1
     994:      	csel	w0, w1, w0, ne
     998:      	ret

000000000000099c <main>:
     99c:      	sub	sp, sp, #0x60
     9a0:      	stp	x29, x30, [sp, #0x30]
     9a4:      	add	x29, sp, #0x30
     9a8:      	stp	x19, x20, [sp, #0x40]
     9ac:      	mov	x19, x1
     9b0:      	adrp	x1, 0x1f000 <__FRAME_END__+0x1e304>
     9b4:      	ldr	x1, [x1, #0xfe8]
     9b8:      	ldr	x2, [x1]
     9bc:      	str	x2, [sp, #0x28]
     9c0:      	mov	x2, #0x0                // =0
     9c4:      	cmp	w0, #0x1
     9c8:      	b.eq	0xa08 <main+0x6c>
     9cc:      	mov	w20, #0x3               // =3
     9d0:      	cmp	w0, w20
     9d4:      	b.eq	0xa68 <main+0xcc>
     9d8:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e304>
     9dc:      	ldr	x0, [x0, #0xfe8]
     9e0:      	ldr	x2, [sp, #0x28]
     9e4:      	ldr	x1, [x0]
     9e8:      	subs	x2, x2, x1
     9ec:      	mov	x1, #0x0                // =0
     9f0:      	b.ne	0xb70 <main+0x1d4>
     9f4:      	mov	w0, w20
     9f8:      	ldp	x19, x20, [sp, #0x40]
     9fc:      	ldp	x29, x30, [sp, #0x30]
     a00:      	add	sp, sp, #0x60
     a04:      	ret
     a08:      	stp	x21, x22, [sp, #0x50]
     a0c:      	add	x22, sp, #0x20
     a10:      	add	x21, sp, #0x24
     a14:      	adrp	x19, 0x0 <strtoul@GLIBC_2.17>
     a18:      	add	x19, x19, #0xba0
     a1c:      	adrp	x20, 0x0 <strtoul@GLIBC_2.17>
     a20:      	add	x20, x20, #0xb98
     a24:      	b	0xa44 <main+0xa8>
     a28:      	ldr	w1, [sp, #0x24]
     a2c:      	ldr	w0, [sp, #0x20]
     a30:      	bl	0x918 <kernel>
     a34:      	mov	w2, w0
     a38:      	mov	x1, x20
     a3c:      	mov	w0, #0x2                // =2
     a40:      	bl	0x7b0 <__printf_chk@plt>
     a44:      	mov	x2, x21
     a48:      	mov	x1, x22
     a4c:      	mov	x0, x19
     a50:      	bl	0x7f0 <__isoc99_scanf@plt>
     a54:      	cmp	w0, #0x2
     a58:      	b.eq	0xa28 <main+0x8c>
     a5c:      	mov	w20, #0x0               // =0
     a60:      	ldp	x21, x22, [sp, #0x50]
     a64:      	b	0x9d8 <main+0x3c>
     a68:      	stp	x21, x22, [sp, #0x50]
     a6c:      	mov	w2, #0xa                // =10
     a70:      	mov	x1, #0x0                // =0
     a74:      	ldr	x0, [x19, #0x8]
     a78:      	bl	0x770 <strtoul@plt>
     a7c:      	mov	x21, x0
     a80:      	mov	w2, #0xa                // =10
     a84:      	mov	x1, #0x0                // =0
     a88:      	ldr	x0, [x19, #0x10]
     a8c:      	bl	0x770 <strtoul@plt>
     a90:      	mov	x19, x0
     a94:      	mov	x1, sp
     a98:      	mov	w0, #0x1                // =1
     a9c:      	bl	0x7a0 <clock_gettime@plt>
     aa0:      	cbnz	w0, 0xb58 <main+0x1bc>
     aa4:      	cbz	x21, 0xb50 <main+0x1b4>
     aa8:      	mov	x20, #0x0               // =0
     aac:      	mov	x22, #0x0               // =0
     ab0:      	eor	w19, w19, w19, lsl #13
     ab4:      	eor	w19, w19, w19, lsr #17
     ab8:      	eor	w0, w19, w19, lsl #5
     abc:      	str	w0, [sp, #0x20]
     ac0:      	eor	w19, w0, w0, lsl #13
     ac4:      	eor	w19, w19, w19, lsr #17
     ac8:      	eor	w19, w19, w19, lsl #5
     acc:      	str	w19, [sp, #0x24]
     ad0:      	mov	w1, w19
     ad4:      	bl	0x918 <kernel>
     ad8:      	add	x22, x22, w0, uxtw
     adc:      	add	x20, x20, #0x1
     ae0:      	cmp	x21, x20
     ae4:      	b.ne	0xab0 <main+0x114>
     ae8:      	add	x1, sp, #0x10
     aec:      	mov	w0, #0x1                // =1
     af0:      	bl	0x7a0 <clock_gettime@plt>
     af4:      	mov	w20, w0
     af8:      	cbnz	w0, 0xb64 <main+0x1c8>
     afc:      	ldr	x0, [sp, #0x18]
     b00:      	ldr	x1, [sp, #0x8]
     b04:      	sub	x0, x0, x1
     b08:      	fmov	d1, x0
     b0c:      	scvtf	d1, d1
     b10:      	adrp	x0, 0x0 <strtoul@GLIBC_2.17>
     b14:      	ldr	d0, [x0, #0xbb8]
     b18:      	fmul	d1, d1, d0
     b1c:      	ldr	x0, [sp, #0x10]
     b20:      	ldr	x1, [sp]
     b24:      	sub	x0, x0, x1
     b28:      	fmov	d0, x0
     b2c:      	scvtf	d0, d0
     b30:      	mov	x2, x22
     b34:      	fadd	d0, d1, d0
     b38:      	adrp	x1, 0x0 <strtoul@GLIBC_2.17>
     b3c:      	add	x1, x1, #0xba8
     b40:      	mov	w0, #0x2                // =2
     b44:      	bl	0x7b0 <__printf_chk@plt>
     b48:      	ldp	x21, x22, [sp, #0x50]
     b4c:      	b	0x9d8 <main+0x3c>
     b50:      	mov	x22, x21
     b54:      	b	0xae8 <main+0x14c>
     b58:      	mov	w20, #0x2               // =2
     b5c:      	ldp	x21, x22, [sp, #0x50]
     b60:      	b	0x9d8 <main+0x3c>
     b64:      	mov	w20, #0x2               // =2
     b68:      	ldp	x21, x22, [sp, #0x50]
     b6c:      	b	0x9d8 <main+0x3c>
     b70:      	stp	x21, x22, [sp, #0x50]
     b74:      	bl	0x7c0 <__stack_chk_fail@plt>

Disassembly of section .fini:

0000000000000b78 <_fini>:
     b78:      	nop
     b7c:      	stp	x29, x30, [sp, #-0x10]!
     b80:      	mov	x29, sp
     b84:      	ldp	x29, x30, [sp], #0x10
     b88:      	ret
