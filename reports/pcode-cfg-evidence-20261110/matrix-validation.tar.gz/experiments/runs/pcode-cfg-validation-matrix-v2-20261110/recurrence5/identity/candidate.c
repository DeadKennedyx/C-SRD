#include <stdint.h>

/* Reserved observer check: five recurrence steps, with a data-dependent add. */
uint32_t kernel(uint32_t x, uint32_t y)
{ unsigned int csrd_value_0 = (1664525u * (x)); unsigned int csrd_value_1 = ((csrd_value_0) + (1013904223u)); unsigned int csrd_value_2 = ((csrd_value_1) & (1u)); unsigned int csrd_value_3 = (csrd_value_2 != 0u); unsigned int csrd_value_4 = ((csrd_value_1) + (y)); unsigned int csrd_value_5 = ((csrd_value_3) ? (csrd_value_4) : (csrd_value_1)); unsigned int csrd_value_6 = (1664525u * (csrd_value_5)); unsigned int csrd_value_7 = ((csrd_value_6) + (1013904223u)); unsigned int csrd_value_8 = ((csrd_value_7) & (1u)); unsigned int csrd_value_9 = (csrd_value_8 != 0u); unsigned int csrd_value_10 = ((csrd_value_7) + (y)); unsigned int csrd_value_11 = ((csrd_value_9) ? (csrd_value_10) : (csrd_value_7)); unsigned int csrd_value_12 = (1664525u * (csrd_value_11)); unsigned int csrd_value_13 = ((csrd_value_12) + (1013904223u)); unsigned int csrd_value_14 = ((csrd_value_13) & (1u)); unsigned int csrd_value_15 = (csrd_value_14 != 0u); unsigned int csrd_value_16 = ((csrd_value_13) + (y)); unsigned int csrd_value_17 = ((csrd_value_15) ? (csrd_value_16) : (csrd_value_13)); unsigned int csrd_value_18 = (1664525u * (csrd_value_17)); unsigned int csrd_value_19 = ((csrd_value_18) + (1013904223u)); unsigned int csrd_value_20 = ((csrd_value_19) & (1u)); unsigned int csrd_value_21 = (csrd_value_20 != 0u); unsigned int csrd_value_22 = ((csrd_value_19) + (y)); unsigned int csrd_value_23 = ((csrd_value_21) ? (csrd_value_22) : (csrd_value_19)); unsigned int csrd_value_24 = (1664525u * (csrd_value_23)); unsigned int csrd_value_25 = ((csrd_value_24) + (1013904223u)); unsigned int csrd_value_26 = ((csrd_value_25) & (1u)); unsigned int csrd_value_27 = (csrd_value_26 != 0u); unsigned int csrd_value_28 = ((csrd_value_25) + (y)); unsigned int csrd_value_29 = ((csrd_value_27) ? (csrd_value_28) : (csrd_value_25)); return csrd_value_29;








}
