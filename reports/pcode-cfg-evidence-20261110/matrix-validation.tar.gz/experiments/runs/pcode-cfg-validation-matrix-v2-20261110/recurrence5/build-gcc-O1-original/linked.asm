
/work/experiments/runs/pcode-cfg-validation-matrix-v2-20261110/recurrence5/build-gcc-O1-original/program:	file format elf64-littleaarch64

Disassembly of section .init:

0000000000000738 <_init>:
     738:      	nop
     73c:      	stp	x29, x30, [sp, #-0x10]!
     740:      	mov	x29, sp
     744:      	bl	0x834 <call_weak_fn>
     748:      	ldp	x29, x30, [sp], #0x10
     74c:      	ret

Disassembly of section .plt:

0000000000000750 <.plt>:
     750:      	stp	x16, x30, [sp, #-0x10]!
     754:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e35c>
     758:      	ldr	x17, [x16, #0xf78]
     75c:      	add	x16, x16, #0xf78
     760:      	br	x17
     764:      	nop
     768:      	nop
     76c:      	nop

0000000000000770 <strtoul@plt>:
     770:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e35c>
     774:      	ldr	x17, [x16, #0xf80]
     778:      	add	x16, x16, #0xf80
     77c:      	br	x17

0000000000000780 <__libc_start_main@plt>:
     780:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e35c>
     784:      	ldr	x17, [x16, #0xf88]
     788:      	add	x16, x16, #0xf88
     78c:      	br	x17

0000000000000790 <__cxa_finalize@plt>:
     790:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e35c>
     794:      	ldr	x17, [x16, #0xf90]
     798:      	add	x16, x16, #0xf90
     79c:      	br	x17

00000000000007a0 <clock_gettime@plt>:
     7a0:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e35c>
     7a4:      	ldr	x17, [x16, #0xf98]
     7a8:      	add	x16, x16, #0xf98
     7ac:      	br	x17

00000000000007b0 <__printf_chk@plt>:
     7b0:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e35c>
     7b4:      	ldr	x17, [x16, #0xfa0]
     7b8:      	add	x16, x16, #0xfa0
     7bc:      	br	x17

00000000000007c0 <__stack_chk_fail@plt>:
     7c0:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e35c>
     7c4:      	ldr	x17, [x16, #0xfa8]
     7c8:      	add	x16, x16, #0xfa8
     7cc:      	br	x17

00000000000007d0 <__gmon_start__@plt>:
     7d0:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e35c>
     7d4:      	ldr	x17, [x16, #0xfb0]
     7d8:      	add	x16, x16, #0xfb0
     7dc:      	br	x17

00000000000007e0 <abort@plt>:
     7e0:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e35c>
     7e4:      	ldr	x17, [x16, #0xfb8]
     7e8:      	add	x16, x16, #0xfb8
     7ec:      	br	x17

00000000000007f0 <__isoc99_scanf@plt>:
     7f0:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e35c>
     7f4:      	ldr	x17, [x16, #0xfc0]
     7f8:      	add	x16, x16, #0xfc0
     7fc:      	br	x17

Disassembly of section .text:

0000000000000800 <_start>:
     800:      	nop
     804:      	mov	x29, #0x0               // =0
     808:      	mov	x30, #0x0               // =0
     80c:      	mov	x5, x0
     810:      	ldr	x1, [sp]
     814:      	add	x2, sp, #0x8
     818:      	mov	x6, sp
     81c:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e35c>
     820:      	ldr	x0, [x0, #0xff0]
     824:      	mov	x3, #0x0                // =0
     828:      	mov	x4, #0x0                // =0
     82c:      	bl	0x780 <__libc_start_main@plt>
     830:      	bl	0x7e0 <abort@plt>

0000000000000834 <call_weak_fn>:
     834:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e35c>
     838:      	ldr	x0, [x0, #0xfe0]
     83c:      	cbz	x0, 0x844 <call_weak_fn+0x10>
     840:      	b	0x7d0 <__gmon_start__@plt>
     844:      	ret
     848:      	nop
     84c:      	nop

0000000000000850 <deregister_tm_clones>:
     850:      	adrp	x0, 0x20000 <data_start>
     854:      	add	x0, x0, #0x10
     858:      	adrp	x1, 0x20000 <data_start>
     85c:      	add	x1, x1, #0x10
     860:      	cmp	x1, x0
     864:      	b.eq	0x87c <deregister_tm_clones+0x2c>
     868:      	adrp	x1, 0x1f000 <__FRAME_END__+0x1e35c>
     86c:      	ldr	x1, [x1, #0xfd0]
     870:      	cbz	x1, 0x87c <deregister_tm_clones+0x2c>
     874:      	mov	x16, x1
     878:      	br	x16
     87c:      	ret

0000000000000880 <register_tm_clones>:
     880:      	adrp	x0, 0x20000 <data_start>
     884:      	add	x0, x0, #0x10
     888:      	adrp	x1, 0x20000 <data_start>
     88c:      	add	x1, x1, #0x10
     890:      	sub	x1, x1, x0
     894:      	lsr	x2, x1, #63
     898:      	add	x1, x2, x1, asr #3
     89c:      	asr	x1, x1, #1
     8a0:      	cbz	x1, 0x8b8 <register_tm_clones+0x38>
     8a4:      	adrp	x2, 0x1f000 <__FRAME_END__+0x1e35c>
     8a8:      	ldr	x2, [x2, #0xff8]
     8ac:      	cbz	x2, 0x8b8 <register_tm_clones+0x38>
     8b0:      	mov	x16, x2
     8b4:      	br	x16
     8b8:      	ret
     8bc:      	nop

00000000000008c0 <__do_global_dtors_aux>:
     8c0:      	paciasp
     8c4:      	stp	x29, x30, [sp, #-0x20]!
     8c8:      	mov	x29, sp
     8cc:      	str	x19, [sp, #0x10]
     8d0:      	adrp	x19, 0x20000 <data_start>
     8d4:      	ldrb	w0, [x19, #0x10]
     8d8:      	tbnz	w0, #0x0, 0x900 <__do_global_dtors_aux+0x40>
     8dc:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e35c>
     8e0:      	ldr	x0, [x0, #0xfd8]
     8e4:      	cbz	x0, 0x8f4 <__do_global_dtors_aux+0x34>
     8e8:      	adrp	x0, 0x20000 <data_start>
     8ec:      	ldr	x0, [x0, #0x8]
     8f0:      	bl	0x790 <__cxa_finalize@plt>
     8f4:      	bl	0x850 <deregister_tm_clones>
     8f8:      	mov	w0, #0x1                // =1
     8fc:      	strb	w0, [x19, #0x10]
     900:      	ldr	x19, [sp, #0x10]
     904:      	ldp	x29, x30, [sp], #0x20
     908:      	autiasp
     90c:      	ret

0000000000000910 <frame_dummy>:
     910:      	bti	c
     914:      	b	0x880 <register_tm_clones>

0000000000000918 <kernel>:
     918:      	mov	w2, #0x5                // =5
     91c:      	mov	w5, #0x660d             // =26125
     920:      	movk	w5, #0x19, lsl #16
     924:      	mov	w4, #0xf35f             // =62303
     928:      	movk	w4, #0x3c6e, lsl #16
     92c:      	madd	w0, w0, w5, w4
     930:      	add	w3, w0, w1
     934:      	tst	x0, #0x1
     938:      	csel	w0, w3, w0, ne
     93c:      	subs	w2, w2, #0x1
     940:      	b.ne	0x92c <kernel+0x14>
     944:      	ret

0000000000000948 <main>:
     948:      	sub	sp, sp, #0x60
     94c:      	stp	x29, x30, [sp, #0x30]
     950:      	add	x29, sp, #0x30
     954:      	stp	x19, x20, [sp, #0x40]
     958:      	mov	x19, x1
     95c:      	adrp	x1, 0x1f000 <__FRAME_END__+0x1e35c>
     960:      	ldr	x1, [x1, #0xfe8]
     964:      	ldr	x2, [x1]
     968:      	str	x2, [sp, #0x28]
     96c:      	mov	x2, #0x0                // =0
     970:      	cmp	w0, #0x1
     974:      	b.eq	0x9b4 <main+0x6c>
     978:      	mov	w20, #0x3               // =3
     97c:      	cmp	w0, w20
     980:      	b.eq	0xa14 <main+0xcc>
     984:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e35c>
     988:      	ldr	x0, [x0, #0xfe8]
     98c:      	ldr	x2, [sp, #0x28]
     990:      	ldr	x1, [x0]
     994:      	subs	x2, x2, x1
     998:      	mov	x1, #0x0                // =0
     99c:      	b.ne	0xb1c <main+0x1d4>
     9a0:      	mov	w0, w20
     9a4:      	ldp	x19, x20, [sp, #0x40]
     9a8:      	ldp	x29, x30, [sp, #0x30]
     9ac:      	add	sp, sp, #0x60
     9b0:      	ret
     9b4:      	stp	x21, x22, [sp, #0x50]
     9b8:      	add	x22, sp, #0x20
     9bc:      	add	x21, sp, #0x24
     9c0:      	adrp	x19, 0x0 <strtoul@GLIBC_2.17>
     9c4:      	add	x19, x19, #0xb48
     9c8:      	adrp	x20, 0x0 <strtoul@GLIBC_2.17>
     9cc:      	add	x20, x20, #0xb40
     9d0:      	b	0x9f0 <main+0xa8>
     9d4:      	ldr	w1, [sp, #0x24]
     9d8:      	ldr	w0, [sp, #0x20]
     9dc:      	bl	0x918 <kernel>
     9e0:      	mov	w2, w0
     9e4:      	mov	x1, x20
     9e8:      	mov	w0, #0x2                // =2
     9ec:      	bl	0x7b0 <__printf_chk@plt>
     9f0:      	mov	x2, x21
     9f4:      	mov	x1, x22
     9f8:      	mov	x0, x19
     9fc:      	bl	0x7f0 <__isoc99_scanf@plt>
     a00:      	cmp	w0, #0x2
     a04:      	b.eq	0x9d4 <main+0x8c>
     a08:      	mov	w20, #0x0               // =0
     a0c:      	ldp	x21, x22, [sp, #0x50]
     a10:      	b	0x984 <main+0x3c>
     a14:      	stp	x21, x22, [sp, #0x50]
     a18:      	mov	w2, #0xa                // =10
     a1c:      	mov	x1, #0x0                // =0
     a20:      	ldr	x0, [x19, #0x8]
     a24:      	bl	0x770 <strtoul@plt>
     a28:      	mov	x21, x0
     a2c:      	mov	w2, #0xa                // =10
     a30:      	mov	x1, #0x0                // =0
     a34:      	ldr	x0, [x19, #0x10]
     a38:      	bl	0x770 <strtoul@plt>
     a3c:      	mov	x19, x0
     a40:      	mov	x1, sp
     a44:      	mov	w0, #0x1                // =1
     a48:      	bl	0x7a0 <clock_gettime@plt>
     a4c:      	cbnz	w0, 0xb04 <main+0x1bc>
     a50:      	cbz	x21, 0xafc <main+0x1b4>
     a54:      	mov	x20, #0x0               // =0
     a58:      	mov	x22, #0x0               // =0
     a5c:      	eor	w19, w19, w19, lsl #13
     a60:      	eor	w19, w19, w19, lsr #17
     a64:      	eor	w0, w19, w19, lsl #5
     a68:      	str	w0, [sp, #0x20]
     a6c:      	eor	w19, w0, w0, lsl #13
     a70:      	eor	w19, w19, w19, lsr #17
     a74:      	eor	w19, w19, w19, lsl #5
     a78:      	str	w19, [sp, #0x24]
     a7c:      	mov	w1, w19
     a80:      	bl	0x918 <kernel>
     a84:      	add	x22, x22, w0, uxtw
     a88:      	add	x20, x20, #0x1
     a8c:      	cmp	x21, x20
     a90:      	b.ne	0xa5c <main+0x114>
     a94:      	add	x1, sp, #0x10
     a98:      	mov	w0, #0x1                // =1
     a9c:      	bl	0x7a0 <clock_gettime@plt>
     aa0:      	mov	w20, w0
     aa4:      	cbnz	w0, 0xb10 <main+0x1c8>
     aa8:      	ldr	x0, [sp, #0x18]
     aac:      	ldr	x1, [sp, #0x8]
     ab0:      	sub	x0, x0, x1
     ab4:      	fmov	d1, x0
     ab8:      	scvtf	d1, d1
     abc:      	adrp	x0, 0x0 <strtoul@GLIBC_2.17>
     ac0:      	ldr	d0, [x0, #0xb60]
     ac4:      	fmul	d1, d1, d0
     ac8:      	ldr	x0, [sp, #0x10]
     acc:      	ldr	x1, [sp]
     ad0:      	sub	x0, x0, x1
     ad4:      	fmov	d0, x0
     ad8:      	scvtf	d0, d0
     adc:      	mov	x2, x22
     ae0:      	fadd	d0, d1, d0
     ae4:      	adrp	x1, 0x0 <strtoul@GLIBC_2.17>
     ae8:      	add	x1, x1, #0xb50
     aec:      	mov	w0, #0x2                // =2
     af0:      	bl	0x7b0 <__printf_chk@plt>
     af4:      	ldp	x21, x22, [sp, #0x50]
     af8:      	b	0x984 <main+0x3c>
     afc:      	mov	x22, x21
     b00:      	b	0xa94 <main+0x14c>
     b04:      	mov	w20, #0x2               // =2
     b08:      	ldp	x21, x22, [sp, #0x50]
     b0c:      	b	0x984 <main+0x3c>
     b10:      	mov	w20, #0x2               // =2
     b14:      	ldp	x21, x22, [sp, #0x50]
     b18:      	b	0x984 <main+0x3c>
     b1c:      	stp	x21, x22, [sp, #0x50]
     b20:      	bl	0x7c0 <__stack_chk_fail@plt>

Disassembly of section .fini:

0000000000000b24 <_fini>:
     b24:      	nop
     b28:      	stp	x29, x30, [sp, #-0x10]!
     b2c:      	mov	x29, sp
     b30:      	ldp	x29, x30, [sp], #0x10
     b34:      	ret
