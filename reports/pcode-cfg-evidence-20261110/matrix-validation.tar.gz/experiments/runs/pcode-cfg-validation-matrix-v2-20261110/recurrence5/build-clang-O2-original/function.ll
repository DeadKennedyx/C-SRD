; ModuleID = '/work/experiments/runs/pcode-cfg-validation-matrix-v2-20261110/recurrence5/build-clang-O2-original/validation/compiler-0-O2/candidate.i'
source_filename = "/work/experiments/runs/pcode-cfg-validation-matrix-v2-20261110/recurrence5/build-clang-O2-original/validation/compiler-0-O2/candidate.i"
target datalayout = "e-m:e-i8:8:32-i16:16:32-i64:64-i128:128-n32:64-S128"
target triple = "aarch64-unknown-linux-gnu"

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local i32 @kernel(i32 noundef %0, i32 noundef %1) local_unnamed_addr #0 {
  %3 = mul i32 %0, 1664525
  %4 = add i32 %3, 1013904223
  %5 = and i32 %4, 1
  %6 = icmp eq i32 %5, 0
  %7 = select i1 %6, i32 0, i32 %1
  %8 = add i32 %7, %4
  %9 = mul i32 %8, 1664525
  %10 = add i32 %9, 1013904223
  %11 = and i32 %10, 1
  %12 = icmp eq i32 %11, 0
  %13 = select i1 %12, i32 0, i32 %1
  %14 = add i32 %13, %10
  %15 = mul i32 %14, 1664525
  %16 = add i32 %15, 1013904223
  %17 = and i32 %16, 1
  %18 = icmp eq i32 %17, 0
  %19 = select i1 %18, i32 0, i32 %1
  %20 = add i32 %19, %16
  %21 = mul i32 %20, 1664525
  %22 = add i32 %21, 1013904223
  %23 = and i32 %22, 1
  %24 = icmp eq i32 %23, 0
  %25 = select i1 %24, i32 0, i32 %1
  %26 = add i32 %25, %22
  %27 = mul i32 %26, 1664525
  %28 = add i32 %27, 1013904223
  %29 = and i32 %28, 1
  %30 = icmp eq i32 %29, 0
  %31 = select i1 %30, i32 0, i32 %1
  %32 = add i32 %31, %28
  ret i32 %32
}

attributes #0 = { mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable "frame-pointer"="non-leaf" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+fp-armv8,+neon,+outline-atomics,+v8a,-fmv" }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 1, !"wchar_size", i32 4}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 1}
!5 = !{!"Ubuntu clang version 18.1.3 (1ubuntu1)"}
