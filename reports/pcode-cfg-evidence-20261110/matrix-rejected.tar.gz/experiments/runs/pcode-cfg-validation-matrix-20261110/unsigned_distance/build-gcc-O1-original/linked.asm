
/work/experiments/runs/pcode-cfg-validation-matrix-20261110/unsigned_distance/build-gcc-O1-original/program:	file format elf64-littleaarch64

Disassembly of section .init:

0000000000000738 <_init>:
     738:      	nop
     73c:      	stp	x29, x30, [sp, #-0x10]!
     740:      	mov	x29, sp
     744:      	bl	0x834 <call_weak_fn>
     748:      	ldp	x29, x30, [sp], #0x10
     74c:      	ret

Disassembly of section .plt:

0000000000000750 <.plt>:
     750:      	stp	x16, x30, [sp, #-0x10]!
     754:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e374>
     758:      	ldr	x17, [x16, #0xf78]
     75c:      	add	x16, x16, #0xf78
     760:      	br	x17
     764:      	nop
     768:      	nop
     76c:      	nop

0000000000000770 <strtoul@plt>:
     770:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e374>
     774:      	ldr	x17, [x16, #0xf80]
     778:      	add	x16, x16, #0xf80
     77c:      	br	x17

0000000000000780 <__libc_start_main@plt>:
     780:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e374>
     784:      	ldr	x17, [x16, #0xf88]
     788:      	add	x16, x16, #0xf88
     78c:      	br	x17

0000000000000790 <__cxa_finalize@plt>:
     790:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e374>
     794:      	ldr	x17, [x16, #0xf90]
     798:      	add	x16, x16, #0xf90
     79c:      	br	x17

00000000000007a0 <clock_gettime@plt>:
     7a0:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e374>
     7a4:      	ldr	x17, [x16, #0xf98]
     7a8:      	add	x16, x16, #0xf98
     7ac:      	br	x17

00000000000007b0 <__printf_chk@plt>:
     7b0:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e374>
     7b4:      	ldr	x17, [x16, #0xfa0]
     7b8:      	add	x16, x16, #0xfa0
     7bc:      	br	x17

00000000000007c0 <__stack_chk_fail@plt>:
     7c0:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e374>
     7c4:      	ldr	x17, [x16, #0xfa8]
     7c8:      	add	x16, x16, #0xfa8
     7cc:      	br	x17

00000000000007d0 <__gmon_start__@plt>:
     7d0:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e374>
     7d4:      	ldr	x17, [x16, #0xfb0]
     7d8:      	add	x16, x16, #0xfb0
     7dc:      	br	x17

00000000000007e0 <abort@plt>:
     7e0:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e374>
     7e4:      	ldr	x17, [x16, #0xfb8]
     7e8:      	add	x16, x16, #0xfb8
     7ec:      	br	x17

00000000000007f0 <__isoc99_scanf@plt>:
     7f0:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e374>
     7f4:      	ldr	x17, [x16, #0xfc0]
     7f8:      	add	x16, x16, #0xfc0
     7fc:      	br	x17

Disassembly of section .text:

0000000000000800 <_start>:
     800:      	nop
     804:      	mov	x29, #0x0               // =0
     808:      	mov	x30, #0x0               // =0
     80c:      	mov	x5, x0
     810:      	ldr	x1, [sp]
     814:      	add	x2, sp, #0x8
     818:      	mov	x6, sp
     81c:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e374>
     820:      	ldr	x0, [x0, #0xff0]
     824:      	mov	x3, #0x0                // =0
     828:      	mov	x4, #0x0                // =0
     82c:      	bl	0x780 <__libc_start_main@plt>
     830:      	bl	0x7e0 <abort@plt>

0000000000000834 <call_weak_fn>:
     834:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e374>
     838:      	ldr	x0, [x0, #0xfe0]
     83c:      	cbz	x0, 0x844 <call_weak_fn+0x10>
     840:      	b	0x7d0 <__gmon_start__@plt>
     844:      	ret
     848:      	nop
     84c:      	nop

0000000000000850 <deregister_tm_clones>:
     850:      	adrp	x0, 0x20000 <data_start>
     854:      	add	x0, x0, #0x10
     858:      	adrp	x1, 0x20000 <data_start>
     85c:      	add	x1, x1, #0x10
     860:      	cmp	x1, x0
     864:      	b.eq	0x87c <deregister_tm_clones+0x2c>
     868:      	adrp	x1, 0x1f000 <__FRAME_END__+0x1e374>
     86c:      	ldr	x1, [x1, #0xfd0]
     870:      	cbz	x1, 0x87c <deregister_tm_clones+0x2c>
     874:      	mov	x16, x1
     878:      	br	x16
     87c:      	ret

0000000000000880 <register_tm_clones>:
     880:      	adrp	x0, 0x20000 <data_start>
     884:      	add	x0, x0, #0x10
     888:      	adrp	x1, 0x20000 <data_start>
     88c:      	add	x1, x1, #0x10
     890:      	sub	x1, x1, x0
     894:      	lsr	x2, x1, #63
     898:      	add	x1, x2, x1, asr #3
     89c:      	asr	x1, x1, #1
     8a0:      	cbz	x1, 0x8b8 <register_tm_clones+0x38>
     8a4:      	adrp	x2, 0x1f000 <__FRAME_END__+0x1e374>
     8a8:      	ldr	x2, [x2, #0xff8]
     8ac:      	cbz	x2, 0x8b8 <register_tm_clones+0x38>
     8b0:      	mov	x16, x2
     8b4:      	br	x16
     8b8:      	ret
     8bc:      	nop

00000000000008c0 <__do_global_dtors_aux>:
     8c0:      	paciasp
     8c4:      	stp	x29, x30, [sp, #-0x20]!
     8c8:      	mov	x29, sp
     8cc:      	str	x19, [sp, #0x10]
     8d0:      	adrp	x19, 0x20000 <data_start>
     8d4:      	ldrb	w0, [x19, #0x10]
     8d8:      	tbnz	w0, #0x0, 0x900 <__do_global_dtors_aux+0x40>
     8dc:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e374>
     8e0:      	ldr	x0, [x0, #0xfd8]
     8e4:      	cbz	x0, 0x8f4 <__do_global_dtors_aux+0x34>
     8e8:      	adrp	x0, 0x20000 <data_start>
     8ec:      	ldr	x0, [x0, #0x8]
     8f0:      	bl	0x790 <__cxa_finalize@plt>
     8f4:      	bl	0x850 <deregister_tm_clones>
     8f8:      	mov	w0, #0x1                // =1
     8fc:      	strb	w0, [x19, #0x10]
     900:      	ldr	x19, [sp, #0x10]
     904:      	ldp	x29, x30, [sp], #0x20
     908:      	autiasp
     90c:      	ret

0000000000000910 <frame_dummy>:
     910:      	bti	c
     914:      	b	0x880 <register_tm_clones>

0000000000000918 <kernel>:
     918:      	sub	w2, w1, w0
     91c:      	sub	w3, w0, w1
     920:      	cmp	w0, w1
     924:      	csel	w0, w3, w2, hs
     928:      	ret

000000000000092c <main>:
     92c:      	sub	sp, sp, #0x60
     930:      	stp	x29, x30, [sp, #0x30]
     934:      	add	x29, sp, #0x30
     938:      	stp	x19, x20, [sp, #0x40]
     93c:      	mov	x19, x1
     940:      	adrp	x1, 0x1f000 <__FRAME_END__+0x1e374>
     944:      	ldr	x1, [x1, #0xfe8]
     948:      	ldr	x2, [x1]
     94c:      	str	x2, [sp, #0x28]
     950:      	mov	x2, #0x0                // =0
     954:      	cmp	w0, #0x1
     958:      	b.eq	0x998 <main+0x6c>
     95c:      	mov	w20, #0x3               // =3
     960:      	cmp	w0, w20
     964:      	b.eq	0x9f8 <main+0xcc>
     968:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e374>
     96c:      	ldr	x0, [x0, #0xfe8]
     970:      	ldr	x2, [sp, #0x28]
     974:      	ldr	x1, [x0]
     978:      	subs	x2, x2, x1
     97c:      	mov	x1, #0x0                // =0
     980:      	b.ne	0xb00 <main+0x1d4>
     984:      	mov	w0, w20
     988:      	ldp	x19, x20, [sp, #0x40]
     98c:      	ldp	x29, x30, [sp, #0x30]
     990:      	add	sp, sp, #0x60
     994:      	ret
     998:      	stp	x21, x22, [sp, #0x50]
     99c:      	add	x22, sp, #0x20
     9a0:      	add	x21, sp, #0x24
     9a4:      	adrp	x19, 0x0 <strtoul@GLIBC_2.17>
     9a8:      	add	x19, x19, #0xb30
     9ac:      	adrp	x20, 0x0 <strtoul@GLIBC_2.17>
     9b0:      	add	x20, x20, #0xb28
     9b4:      	b	0x9d4 <main+0xa8>
     9b8:      	ldr	w1, [sp, #0x24]
     9bc:      	ldr	w0, [sp, #0x20]
     9c0:      	bl	0x918 <kernel>
     9c4:      	mov	w2, w0
     9c8:      	mov	x1, x20
     9cc:      	mov	w0, #0x2                // =2
     9d0:      	bl	0x7b0 <__printf_chk@plt>
     9d4:      	mov	x2, x21
     9d8:      	mov	x1, x22
     9dc:      	mov	x0, x19
     9e0:      	bl	0x7f0 <__isoc99_scanf@plt>
     9e4:      	cmp	w0, #0x2
     9e8:      	b.eq	0x9b8 <main+0x8c>
     9ec:      	mov	w20, #0x0               // =0
     9f0:      	ldp	x21, x22, [sp, #0x50]
     9f4:      	b	0x968 <main+0x3c>
     9f8:      	stp	x21, x22, [sp, #0x50]
     9fc:      	mov	w2, #0xa                // =10
     a00:      	mov	x1, #0x0                // =0
     a04:      	ldr	x0, [x19, #0x8]
     a08:      	bl	0x770 <strtoul@plt>
     a0c:      	mov	x21, x0
     a10:      	mov	w2, #0xa                // =10
     a14:      	mov	x1, #0x0                // =0
     a18:      	ldr	x0, [x19, #0x10]
     a1c:      	bl	0x770 <strtoul@plt>
     a20:      	mov	x19, x0
     a24:      	mov	x1, sp
     a28:      	mov	w0, #0x1                // =1
     a2c:      	bl	0x7a0 <clock_gettime@plt>
     a30:      	cbnz	w0, 0xae8 <main+0x1bc>
     a34:      	cbz	x21, 0xae0 <main+0x1b4>
     a38:      	mov	x20, #0x0               // =0
     a3c:      	mov	x22, #0x0               // =0
     a40:      	eor	w19, w19, w19, lsl #13
     a44:      	eor	w19, w19, w19, lsr #17
     a48:      	eor	w0, w19, w19, lsl #5
     a4c:      	str	w0, [sp, #0x20]
     a50:      	eor	w19, w0, w0, lsl #13
     a54:      	eor	w19, w19, w19, lsr #17
     a58:      	eor	w19, w19, w19, lsl #5
     a5c:      	str	w19, [sp, #0x24]
     a60:      	mov	w1, w19
     a64:      	bl	0x918 <kernel>
     a68:      	add	x22, x22, w0, uxtw
     a6c:      	add	x20, x20, #0x1
     a70:      	cmp	x21, x20
     a74:      	b.ne	0xa40 <main+0x114>
     a78:      	add	x1, sp, #0x10
     a7c:      	mov	w0, #0x1                // =1
     a80:      	bl	0x7a0 <clock_gettime@plt>
     a84:      	mov	w20, w0
     a88:      	cbnz	w0, 0xaf4 <main+0x1c8>
     a8c:      	ldr	x0, [sp, #0x18]
     a90:      	ldr	x1, [sp, #0x8]
     a94:      	sub	x0, x0, x1
     a98:      	fmov	d1, x0
     a9c:      	scvtf	d1, d1
     aa0:      	adrp	x0, 0x0 <strtoul@GLIBC_2.17>
     aa4:      	ldr	d0, [x0, #0xb48]
     aa8:      	fmul	d1, d1, d0
     aac:      	ldr	x0, [sp, #0x10]
     ab0:      	ldr	x1, [sp]
     ab4:      	sub	x0, x0, x1
     ab8:      	fmov	d0, x0
     abc:      	scvtf	d0, d0
     ac0:      	mov	x2, x22
     ac4:      	fadd	d0, d1, d0
     ac8:      	adrp	x1, 0x0 <strtoul@GLIBC_2.17>
     acc:      	add	x1, x1, #0xb38
     ad0:      	mov	w0, #0x2                // =2
     ad4:      	bl	0x7b0 <__printf_chk@plt>
     ad8:      	ldp	x21, x22, [sp, #0x50]
     adc:      	b	0x968 <main+0x3c>
     ae0:      	mov	x22, x21
     ae4:      	b	0xa78 <main+0x14c>
     ae8:      	mov	w20, #0x2               // =2
     aec:      	ldp	x21, x22, [sp, #0x50]
     af0:      	b	0x968 <main+0x3c>
     af4:      	mov	w20, #0x2               // =2
     af8:      	ldp	x21, x22, [sp, #0x50]
     afc:      	b	0x968 <main+0x3c>
     b00:      	stp	x21, x22, [sp, #0x50]
     b04:      	bl	0x7c0 <__stack_chk_fail@plt>

Disassembly of section .fini:

0000000000000b08 <_fini>:
     b08:      	nop
     b0c:      	stp	x29, x30, [sp, #-0x10]!
     b10:      	mov	x29, sp
     b14:      	ldp	x29, x30, [sp], #0x10
     b18:      	ret
