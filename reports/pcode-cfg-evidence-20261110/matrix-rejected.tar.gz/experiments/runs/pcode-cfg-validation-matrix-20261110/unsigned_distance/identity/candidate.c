#include <stdint.h>

/* Reserved observer check; public contract is unsigned absolute difference. */
uint32_t kernel(uint32_t x, uint32_t y)
{ unsigned int csrd_value_0 = (x < y); unsigned int csrd_value_1 = ((y) - (x)); unsigned int csrd_value_2 = ((x) - (y)); unsigned int csrd_value_3 = ((csrd_value_0) ? (csrd_value_1) : (csrd_value_2)); return csrd_value_3;

}
