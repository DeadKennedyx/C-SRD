#include <stdint.h>
uint32_t f(uint32_t*p,uint32_t*q,uint32_t x){p[1]=x;return q[0];}