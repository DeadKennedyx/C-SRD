#define f csrd_candidate_f
#include "/Users/admin/C-SRD/build/buffer-cbmc-final/test_alias_order_control_and_disjoint_positive/0/candidate.c"
