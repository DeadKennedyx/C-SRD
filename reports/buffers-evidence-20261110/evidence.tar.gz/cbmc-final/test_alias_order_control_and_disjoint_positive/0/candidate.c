#include <stdint.h>
uint32_t f(uint32_t*p,uint32_t*q,uint32_t x){uint32_t v=q[0];p[1]=x;return v;}