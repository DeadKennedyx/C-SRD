#define buffer_mix csrd_original_buffer_mix
#define buffer_store csrd_original_buffer_store
#define buffer_snapshot csrd_original_buffer_snapshot
#define buffer_boundary csrd_original_buffer_boundary
#define buffer_unused csrd_original_buffer_unused
#define buffer_const csrd_original_buffer_const
#include "/Users/admin/C-SRD/tests/fixtures/buffers.c"
