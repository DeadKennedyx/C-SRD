#include <stdint.h>
uint32_t f(uint32_t*p,uint32_t x){p[0]=x+1u;return x;}