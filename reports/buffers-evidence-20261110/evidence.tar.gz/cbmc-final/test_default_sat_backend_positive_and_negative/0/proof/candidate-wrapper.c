#define f csrd_candidate_f
#include "/Users/admin/C-SRD/build/buffer-cbmc-final/test_default_sat_backend_positive_and_negative/0/candidate.c"
