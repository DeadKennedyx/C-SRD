#define f csrd_original_f
#include "/Users/admin/C-SRD/build/buffer-cbmc-final/test_negative_store_and_untouched_cell/1/original.c"
