#include <stdint.h>
uint32_t f(uint32_t*p,uint32_t x){uint32_t a=p[2];*p=x;return a;}