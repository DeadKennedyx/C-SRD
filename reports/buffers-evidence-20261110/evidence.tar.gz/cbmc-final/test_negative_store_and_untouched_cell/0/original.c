#include <stdint.h>
uint32_t f(uint32_t*p,uint32_t x){*p=x+1u;return 7u;}