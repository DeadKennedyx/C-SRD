#define f csrd_candidate_f
#include "/Users/admin/C-SRD/build/buffer-cbmc-final/test_negative_store_and_untouched_cell/0/candidate.c"
