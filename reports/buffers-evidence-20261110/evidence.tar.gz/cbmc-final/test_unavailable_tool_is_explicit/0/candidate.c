#include <stdint.h>
uint32_t f(uint32_t*p){return *p;}