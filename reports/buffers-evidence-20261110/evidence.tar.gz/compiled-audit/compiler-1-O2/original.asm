
/Users/admin/C-SRD/build/buffer-compiled-audit/compiler-1-O2/original.o:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000000000000 <ltmp0>:
       0:      	ldr	w1, [x1]
       4:      	add	w2, w2, w1
       8:      	add	w2, w2, w2, lsl #1
       c:      	add	w2, w2, #0xb
      10:      	str	w2, [x0, #0x4]
      14:      	ldr	w0, [x0]
      18:      	add	w0, w2, w0
      1c:      	ret
