
/Users/admin/C-SRD/build/buffer-compiled-audit/compiler-1-O2/candidate.o:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000000000000 <ltmp0>:
       0:      	ldr	w1, [x1]
       4:      	mov	w4, #0x8e73             ; =36467
       8:      	mov	w3, #0x63aa             ; =25514
       c:      	movk	w4, #0xb018, lsl #16
      10:      	movk	w3, #0xd97e, lsl #16
      14:      	add	w2, w2, w1
      18:      	mov	w1, #0xaf31             ; =44849
      1c:      	movk	w1, #0xd8af, lsl #16
      20:      	madd	w2, w2, w4, w1
      24:      	mov	w1, #0x5431             ; =21553
      28:      	movk	w1, #0xd675, lsl #16
      2c:      	madd	w1, w2, w1, w3
      30:      	add	w2, w2, w2, lsl #1
      34:      	str	w1, [x0, #0x4]
      38:      	ldr	w1, [x0]
      3c:      	mov	w0, #0xc6bb             ; =50875
      40:      	movk	w0, #0x9cd1, lsl #16
      44:      	madd	w1, w1, w4, w2
      48:      	madd	w0, w1, w0, w3
      4c:      	ret
