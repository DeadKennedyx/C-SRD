
/Users/admin/C-SRD/build/buffer-compiled-audit/compiler-0-O0/original.o:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000000000000 <ltmp0>:
       0:      	sub	sp, sp, #0x20
       4:      	str	x0, [sp, #0x18]
       8:      	str	x1, [sp, #0x10]
       c:      	str	w2, [sp, #0xc]
      10:      	ldr	x8, [sp, #0x10]
      14:      	ldr	w8, [x8]
      18:      	ldr	w9, [sp, #0xc]
      1c:      	add	w8, w8, w9
      20:      	str	w8, [sp, #0x8]
      24:      	ldr	w9, [sp, #0x8]
      28:      	mov	w8, #0x3                ; =3
      2c:      	mul	w8, w8, w9
      30:      	add	w8, w8, #0xb
      34:      	str	w8, [sp, #0x4]
      38:      	ldr	w8, [sp, #0x4]
      3c:      	ldr	x9, [sp, #0x18]
      40:      	str	w8, [x9, #0x4]
      44:      	ldr	x8, [sp, #0x18]
      48:      	ldr	w8, [x8]
      4c:      	ldr	w9, [sp, #0x4]
      50:      	add	w0, w8, w9
      54:      	add	sp, sp, #0x20
      58:      	ret
