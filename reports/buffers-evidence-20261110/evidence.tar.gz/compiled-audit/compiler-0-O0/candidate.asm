
/Users/admin/C-SRD/build/buffer-compiled-audit/compiler-0-O0/candidate.o:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000000000000 <ltmp0>:
       0:      	sub	sp, sp, #0x20
       4:      	mov	w9, #0x8e73             ; =36467
       8:      	movk	w9, #0xb018, lsl #16
       c:      	mov	w10, #0xeea2            ; =61090
      10:      	movk	w10, #0xf900, lsl #16
      14:      	str	x0, [sp, #0x18]
      18:      	str	x1, [sp, #0x10]
      1c:      	str	w2, [sp, #0xc]
      20:      	ldr	w8, [sp, #0xc]
      24:      	mul	w8, w9, w8
      28:      	add	w8, w8, w10
      2c:      	str	w8, [sp, #0x8]
      30:      	ldr	x8, [sp, #0x10]
      34:      	ldr	w8, [x8]
      38:      	mul	w8, w9, w8
      3c:      	add	w8, w8, w10
      40:      	ldr	w11, [sp, #0x8]
      44:      	add	w8, w8, w11
      48:      	mov	w11, #0x115e            ; =4446
      4c:      	movk	w11, #0x6ff, lsl #16
      50:      	add	w8, w8, w11
      54:      	str	w8, [sp, #0x4]
      58:      	ldr	w11, [sp, #0x4]
      5c:      	mov	w8, #0x3                ; =3
      60:      	mul	w8, w8, w11
      64:      	mov	w11, #0x22bc            ; =8892
      68:      	movk	w11, #0xdfe, lsl #16
      6c:      	add	w8, w8, w11
      70:      	mov	w11, #0xd93             ; =3475
      74:      	movk	w11, #0x8a0f, lsl #16
      78:      	add	w8, w8, w11
      7c:      	mov	w11, #0x115e            ; =4446
      80:      	movk	w11, #0x6ff, lsl #16
      84:      	add	w8, w8, w11
      88:      	str	w8, [sp]
      8c:      	ldr	w8, [sp]
      90:      	mov	w11, #0x115e            ; =4446
      94:      	movk	w11, #0x6ff, lsl #16
      98:      	add	w11, w8, w11
      9c:      	mov	w8, #0xc6bb             ; =50875
      a0:      	movk	w8, #0x9cd1, lsl #16
      a4:      	mul	w11, w8, w11
      a8:      	ldr	x12, [sp, #0x18]
      ac:      	str	w11, [x12, #0x4]
      b0:      	ldr	x11, [sp, #0x18]
      b4:      	ldr	w11, [x11]
      b8:      	mul	w9, w9, w11
      bc:      	add	w9, w9, w10
      c0:      	ldr	w10, [sp]
      c4:      	add	w9, w9, w10
      c8:      	mov	w10, #0x115e            ; =4446
      cc:      	movk	w10, #0x6ff, lsl #16
      d0:      	add	w9, w9, w10
      d4:      	mov	w10, #0x115e            ; =4446
      d8:      	movk	w10, #0x6ff, lsl #16
      dc:      	add	w9, w9, w10
      e0:      	mul	w0, w8, w9
      e4:      	add	sp, sp, #0x20
      e8:      	ret
