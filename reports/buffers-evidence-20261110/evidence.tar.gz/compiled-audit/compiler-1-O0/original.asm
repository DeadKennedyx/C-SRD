
/Users/admin/C-SRD/build/buffer-compiled-audit/compiler-1-O0/original.o:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000000000000 <ltmp0>:
       0:      	sub	sp, sp, #0x30
       4:      	str	x0, [sp, #0x18]
       8:      	str	x1, [sp, #0x10]
       c:      	str	w2, [sp, #0xc]
      10:      	ldr	x0, [sp, #0x10]
      14:      	ldr	w0, [x0]
      18:      	ldr	w1, [sp, #0xc]
      1c:      	add	w0, w1, w0
      20:      	str	w0, [sp, #0x2c]
      24:      	ldr	w1, [sp, #0x2c]
      28:      	mov	w0, w1
      2c:      	lsl	w0, w0, #1
      30:      	add	w0, w0, w1
      34:      	add	w0, w0, #0xb
      38:      	str	w0, [sp, #0x28]
      3c:      	ldr	x0, [sp, #0x18]
      40:      	add	x0, x0, #0x4
      44:      	ldr	w1, [sp, #0x28]
      48:      	str	w1, [x0]
      4c:      	ldr	x0, [sp, #0x18]
      50:      	ldr	w1, [x0]
      54:      	ldr	w0, [sp, #0x28]
      58:      	add	w0, w1, w0
      5c:      	add	sp, sp, #0x30
      60:      	ret
