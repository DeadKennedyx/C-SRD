
/Users/admin/C-SRD/build/buffer-compiled-audit/compiler-1-O0/candidate.o:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000000000000 <ltmp0>:
       0:      	sub	sp, sp, #0x30
       4:      	str	x0, [sp, #0x18]
       8:      	str	x1, [sp, #0x10]
       c:      	str	w2, [sp, #0xc]
      10:      	ldr	w1, [sp, #0xc]
      14:      	mov	w0, #0x8e73             ; =36467
      18:      	movk	w0, #0xb018, lsl #16
      1c:      	mul	w1, w1, w0
      20:      	mov	w0, #0xeea2             ; =61090
      24:      	movk	w0, #0xf900, lsl #16
      28:      	add	w0, w1, w0
      2c:      	str	w0, [sp, #0x2c]
      30:      	ldr	x0, [sp, #0x10]
      34:      	ldr	w1, [x0]
      38:      	mov	w0, #0x8e73             ; =36467
      3c:      	movk	w0, #0xb018, lsl #16
      40:      	mul	w0, w1, w0
      44:      	ldr	w1, [sp, #0x2c]
      48:      	add	w0, w1, w0
      4c:      	str	w0, [sp, #0x28]
      50:      	ldr	w1, [sp, #0x28]
      54:      	mov	w0, #0xc08f             ; =49295
      58:      	movk	w0, #0xdfae, lsl #16
      5c:      	add	w1, w1, w0
      60:      	mov	w0, w1
      64:      	lsl	w0, w0, #1
      68:      	add	w0, w0, w1
      6c:      	str	w0, [sp, #0x24]
      70:      	ldr	w1, [sp, #0x24]
      74:      	mov	w0, #0xc6bb             ; =50875
      78:      	movk	w0, #0x9cd1, lsl #16
      7c:      	mul	w2, w1, w0
      80:      	ldr	x0, [sp, #0x18]
      84:      	add	x0, x0, #0x4
      88:      	mov	w1, #0x63aa             ; =25514
      8c:      	movk	w1, #0xd97e, lsl #16
      90:      	add	w1, w2, w1
      94:      	str	w1, [x0]
      98:      	ldr	x0, [sp, #0x18]
      9c:      	ldr	w1, [x0]
      a0:      	mov	w0, #0x8e73             ; =36467
      a4:      	movk	w0, #0xb018, lsl #16
      a8:      	mul	w1, w1, w0
      ac:      	ldr	w0, [sp, #0x24]
      b0:      	add	w1, w1, w0
      b4:      	mov	w0, #0xc6bb             ; =50875
      b8:      	movk	w0, #0x9cd1, lsl #16
      bc:      	mul	w1, w1, w0
      c0:      	mov	w0, #0x63aa             ; =25514
      c4:      	movk	w0, #0xd97e, lsl #16
      c8:      	add	w0, w1, w0
      cc:      	add	sp, sp, #0x30
      d0:      	ret
