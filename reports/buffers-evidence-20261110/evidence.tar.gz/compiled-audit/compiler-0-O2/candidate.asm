
/Users/admin/C-SRD/build/buffer-compiled-audit/compiler-0-O2/candidate.o:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000000000000 <ltmp0>:
       0:      	ldr	w8, [x1]
       4:      	add	w8, w8, w2
       8:      	mov	w9, #0xab59             ; =43865
       c:      	movk	w9, #0x1049, lsl #16
      10:      	mul	w9, w8, w9
      14:      	add	w8, w8, w8, lsl #1
      18:      	add	w8, w8, #0xb
      1c:      	str	w8, [x0, #0x4]
      20:      	ldr	w8, [x0]
      24:      	mov	w10, #0x8e73            ; =36467
      28:      	movk	w10, #0xb018, lsl #16
      2c:      	madd	w8, w8, w10, w9
      30:      	mov	w9, #0xc6bb             ; =50875
      34:      	movk	w9, #0x9cd1, lsl #16
      38:      	mov	w10, #0xb               ; =11
      3c:      	madd	w0, w8, w9, w10
      40:      	ret
