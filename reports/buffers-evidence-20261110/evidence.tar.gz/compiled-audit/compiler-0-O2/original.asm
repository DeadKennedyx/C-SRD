
/Users/admin/C-SRD/build/buffer-compiled-audit/compiler-0-O2/original.o:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000000000000 <ltmp0>:
       0:      	ldr	w8, [x1]
       4:      	add	w8, w8, w2
       8:      	add	w8, w8, w8, lsl #1
       c:      	add	w8, w8, #0xb
      10:      	str	w8, [x0, #0x4]
      14:      	ldr	w9, [x0]
      18:      	add	w0, w8, w9
      1c:      	ret
