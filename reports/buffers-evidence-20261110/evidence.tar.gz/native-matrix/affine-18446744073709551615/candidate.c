#include <stdint.h>

uint32_t buffer_mix(uint32_t *p, uint32_t *q, uint32_t x)
{ (void)p; (void)q; unsigned int csrd_mem_0 = ((570378735u * (x)) + 2168897476u); (void)csrd_mem_0; unsigned int csrd_mem_1 = (((((570378735u * (p[0u])) + 2168897476u)) + (csrd_mem_0)) - 2168897476u); (void)csrd_mem_1; unsigned int csrd_mem_2 = (((((3u * (csrd_mem_1)) + 4252139640u)) + (4148096265u)) - 2168897476u); (void)csrd_mem_2; p[1u] = (1358365967u * ((csrd_mem_2) - 2168897476u)); unsigned int csrd_mem_3 = (((((570378735u * (q[0u])) + 2168897476u)) - (((570378735u * (p[1u])) + 2168897476u))) + 2168897476u); (void)csrd_mem_3; q[1u] = (1358365967u * (((((csrd_mem_3) + (csrd_mem_0)) - 2168897476u)) - 2168897476u)); return (1358365967u * (((((((570378735u * (p[0u])) + 2168897476u)) + (((570378735u * (q[1u])) + 2168897476u))) - 2168897476u)) - 2168897476u));






}

uint32_t buffer_store(uint32_t *p, uint32_t *q, uint32_t x)
{ (void)p; (void)q; unsigned int csrd_mem_0 = ((2743143813u * (x)) + 3674549034u); (void)csrd_mem_0; p[0u] = (738911053u * (((((csrd_mem_0) + (2122725551u)) - 3674549034u)) - 3674549034u)); q[0u] = (738911053u * (((((((7u * (((2743143813u * (p[0u])) + 3674549034u))) + 3722509572u)) - (3314045881u)) + 3674549034u)) - 3674549034u)); return (738911053u * ((4254673929u) - 3674549034u));



}

uint32_t buffer_snapshot(uint32_t *p, uint32_t *q, uint32_t x)
{ (void)p; (void)q; unsigned int csrd_mem_0 = ((1876720615u * (x)) + 1072588598u); (void)csrd_mem_0; unsigned int csrd_mem_1 = ((1876720615u * (p[0u])) + 1072588598u); (void)csrd_mem_1; q[0u] = (2029414359u * ((csrd_mem_0) - 1072588598u)); csrd_mem_0 = ((3u * (csrd_mem_1)) + 2149790100u); return (2029414359u * (((((csrd_mem_0) + (((1876720615u * (p[0u])) + 1072588598u))) - 1072588598u)) - 1072588598u));




}

uint32_t buffer_boundary(uint32_t *p, uint32_t *q, uint32_t x)
{ (void)p; (void)q; unsigned int csrd_mem_0 = ((1609917519u * (x)) + 3076068675u); (void)csrd_mem_0; unsigned int csrd_mem_1 = (((((1609917519u * (p[15u])) + 3076068675u)) + (csrd_mem_0)) - 3076068675u); (void)csrd_mem_1; q[15u] = (747057839u * (((((((4294967295u * (csrd_mem_1)) + 1857170054u)) - (391018898u)) + 3076068675u)) - 3076068675u)); return (747057839u * (((((((1609917519u * (q[15u])) + 3076068675u)) + (((1609917519u * (p[15u])) + 3076068675u))) - 3076068675u)) - 3076068675u));



}

uint32_t buffer_unused(uint32_t *p, uint32_t *q, uint32_t x)
{ (void)p; (void)q; unsigned int csrd_mem_0 = ((2985764429u * (x)) + 2005878707u); (void)csrd_mem_0; return (213811845u * (((((((3u * (csrd_mem_0)) + 283209882u)) + (489549058u)) - 2005878707u)) - 2005878707u));



}

uint32_t buffer_const(const uint32_t *p, uint32_t *q, uint32_t x)
{ (void)p; (void)q; unsigned int csrd_mem_0 = ((3346880641u * (x)) + 3471425162u); (void)csrd_mem_0; unsigned int csrd_mem_1 = (((((3346880641u * (p[0u])) + 3471425162u)) + (csrd_mem_0)) - 3471425162u); (void)csrd_mem_1; q[0u] = (1912268673u * ((((17u * (csrd_mem_1)) + 291772256u)) - 3471425162u)); return (1912268673u * (((((csrd_mem_1) + (((3346880641u * (p[0u])) + 3471425162u))) - 3471425162u)) - 3471425162u));



}
