#include <stdint.h>

uint32_t buffer_mix(uint32_t *p, uint32_t *q, uint32_t x)
{ (void)p; (void)q; unsigned int csrd_mem_0 = ((3524787525u * (x)) + 975857554u); (void)csrd_mem_0; unsigned int csrd_mem_1 = (((((3524787525u * (p[0u])) + 975857554u)) + (csrd_mem_0)) - 975857554u); (void)csrd_mem_1; unsigned int csrd_mem_2 = (((((3u * (csrd_mem_1)) + 2343252188u)) + (1093814665u)) - 975857554u); (void)csrd_mem_2; p[1u] = (1535708557u * ((csrd_mem_2) - 975857554u)); unsigned int csrd_mem_3 = (((((3524787525u * (q[0u])) + 975857554u)) - (((3524787525u * (p[1u])) + 975857554u))) + 975857554u); (void)csrd_mem_3; q[1u] = (1535708557u * (((((csrd_mem_3) + (csrd_mem_0)) - 975857554u)) - 975857554u)); return (1535708557u * (((((((3524787525u * (p[0u])) + 975857554u)) + (((3524787525u * (q[1u])) + 975857554u))) - 975857554u)) - 975857554u));






}

uint32_t buffer_store(uint32_t *p, uint32_t *q, uint32_t x)
{ (void)p; (void)q; unsigned int csrd_mem_0 = ((1494641301u * (x)) + 2173942464u); (void)csrd_mem_0; p[0u] = (4230090941u * (((((csrd_mem_0) + (3668583765u)) - 2173942464u)) - 2173942464u)); q[0u] = (4230090941u * (((((((7u * (((1494641301u * (p[0u])) + 2173942464u))) + 4136214400u)) - (2362899071u)) + 2173942464u)) - 2173942464u)); return (4230090941u * ((507356111u) - 2173942464u));



}

uint32_t buffer_snapshot(uint32_t *p, uint32_t *q, uint32_t x)
{ (void)p; (void)q; unsigned int csrd_mem_0 = ((2923574099u * (x)) + 1735491442u); (void)csrd_mem_0; unsigned int csrd_mem_1 = ((2923574099u * (p[0u])) + 1735491442u); (void)csrd_mem_1; q[0u] = (3695085787u * ((csrd_mem_0) - 1735491442u)); csrd_mem_0 = ((3u * (csrd_mem_1)) + 823984412u); return (3695085787u * (((((csrd_mem_0) + (((2923574099u * (p[0u])) + 1735491442u))) - 1735491442u)) - 1735491442u));




}

uint32_t buffer_boundary(uint32_t *p, uint32_t *q, uint32_t x)
{ (void)p; (void)q; unsigned int csrd_mem_0 = ((3279823561u * (x)) + 1378538994u); (void)csrd_mem_0; unsigned int csrd_mem_1 = (((((3279823561u * (p[15u])) + 1378538994u)) + (csrd_mem_0)) - 1378538994u); (void)csrd_mem_1; q[15u] = (1702205305u * (((((((4294967295u * (csrd_mem_1)) + 2757077988u)) - (363395259u)) + 1378538994u)) - 1378538994u)); return (1702205305u * (((((((3279823561u * (q[15u])) + 1378538994u)) + (((3279823561u * (p[15u])) + 1378538994u))) - 1378538994u)) - 1378538994u));



}

uint32_t buffer_unused(uint32_t *p, uint32_t *q, uint32_t x)
{ (void)p; (void)q; unsigned int csrd_mem_0 = ((961600465u * (x)) + 1457263u); (void)csrd_mem_0; return (918248753u * (((((((3u * (csrd_mem_0)) + 4292052770u)) + (1989127786u)) - 1457263u)) - 1457263u));



}

uint32_t buffer_const(const uint32_t *p, uint32_t *q, uint32_t x)
{ (void)p; (void)q; unsigned int csrd_mem_0 = ((2803688269u * (x)) + 2847453020u); (void)csrd_mem_0; unsigned int csrd_mem_1 = (((((2803688269u * (p[0u])) + 2847453020u)) + (csrd_mem_0)) - 2847453020u); (void)csrd_mem_1; q[0u] = (2696875397u * ((((17u * (csrd_mem_1)) + 1685391936u)) - 2847453020u)); return (2696875397u * (((((csrd_mem_1) + (((2803688269u * (p[0u])) + 2847453020u))) - 2847453020u)) - 2847453020u));



}
