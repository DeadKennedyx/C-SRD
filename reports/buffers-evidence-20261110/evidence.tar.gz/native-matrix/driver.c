#include <stdint.h>
#include <stdio.h>
#include <string.h>
uint32_t original_buffer_mix(uint32_t*,uint32_t*,uint32_t);
uint32_t candidate_buffer_mix(uint32_t*,uint32_t*,uint32_t);
uint32_t original_buffer_store(uint32_t*,uint32_t*,uint32_t);
uint32_t candidate_buffer_store(uint32_t*,uint32_t*,uint32_t);
uint32_t original_buffer_snapshot(uint32_t*,uint32_t*,uint32_t);
uint32_t candidate_buffer_snapshot(uint32_t*,uint32_t*,uint32_t);
uint32_t original_buffer_boundary(uint32_t*,uint32_t*,uint32_t);
uint32_t candidate_buffer_boundary(uint32_t*,uint32_t*,uint32_t);
uint32_t original_buffer_unused(uint32_t*,uint32_t*,uint32_t);
uint32_t candidate_buffer_unused(uint32_t*,uint32_t*,uint32_t);
uint32_t original_buffer_const(const uint32_t*,uint32_t*,uint32_t);
uint32_t candidate_buffer_const(const uint32_t*,uint32_t*,uint32_t);
static uint32_t state=0x43535244u;
static uint32_t next(void){state^=state<<13;state^=state>>17;state^=state<<5;return state;}
int main(void){
    const uint32_t edges[]={0u,1u,2u,3u,2147483647u,2147483648u,2147483649u,4294967294u,4294967295u};
    const unsigned offsets[][2]={{4,4},{4,5},{5,4},{4,20},{20,4},{12,19},{0,48},{48,0}};
    uint32_t initial[64],a[64],b[64];
    for(unsigned layout=0;layout<8;layout++) for(unsigned iteration=0;iteration<1033;iteration++){
        uint32_t x=iteration<9 ? edges[iteration] : next();
        for(unsigned i=0;i<64;i++) initial[i]=iteration<9 ? edges[(i+iteration)%9] : next();
        unsigned po=offsets[layout][0],qo=offsets[layout][1];
        memcpy(a,initial,sizeof a);memcpy(b,initial,sizeof b);
        if(original_buffer_mix(a+po,a+qo,x)!=candidate_buffer_mix(b+po,b+qo,x) || memcmp(a,b,sizeof a)) {
            fprintf(stderr,"mismatch buffer_mix layout=%u iteration=%u\n",layout,iteration); return 1;
        }
memcpy(a,initial,sizeof a);memcpy(b,initial,sizeof b);
        if(original_buffer_store(a+po,a+qo,x)!=candidate_buffer_store(b+po,b+qo,x) || memcmp(a,b,sizeof a)) {
            fprintf(stderr,"mismatch buffer_store layout=%u iteration=%u\n",layout,iteration); return 1;
        }
memcpy(a,initial,sizeof a);memcpy(b,initial,sizeof b);
        if(original_buffer_snapshot(a+po,a+qo,x)!=candidate_buffer_snapshot(b+po,b+qo,x) || memcmp(a,b,sizeof a)) {
            fprintf(stderr,"mismatch buffer_snapshot layout=%u iteration=%u\n",layout,iteration); return 1;
        }
memcpy(a,initial,sizeof a);memcpy(b,initial,sizeof b);
        if(original_buffer_boundary(a+po,a+qo,x)!=candidate_buffer_boundary(b+po,b+qo,x) || memcmp(a,b,sizeof a)) {
            fprintf(stderr,"mismatch buffer_boundary layout=%u iteration=%u\n",layout,iteration); return 1;
        }
memcpy(a,initial,sizeof a);memcpy(b,initial,sizeof b);
        if(original_buffer_unused(a+po,a+qo,x)!=candidate_buffer_unused(b+po,b+qo,x) || memcmp(a,b,sizeof a)) {
            fprintf(stderr,"mismatch buffer_unused layout=%u iteration=%u\n",layout,iteration); return 1;
        }
memcpy(a,initial,sizeof a);memcpy(b,initial,sizeof b);
        if(original_buffer_const(a+po,a+qo,x)!=candidate_buffer_const(b+po,b+qo,x) || memcmp(a,b,sizeof a)) {
            fprintf(stderr,"mismatch buffer_const layout=%u iteration=%u\n",layout,iteration); return 1;
        }
    }
    if(original_buffer_unused(0,0,4294967295u)!=candidate_buffer_unused(0,0,4294967295u)) return 1;
    puts("PASS memory and return differential");return 0;
}
