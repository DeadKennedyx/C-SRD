#define buffer_mix csrd_candidate_buffer_mix
#define buffer_store csrd_candidate_buffer_store
#define buffer_snapshot csrd_candidate_buffer_snapshot
#define buffer_boundary csrd_candidate_buffer_boundary
#define buffer_unused csrd_candidate_buffer_unused
#define buffer_const csrd_candidate_buffer_const
#include "/Users/admin/C-SRD/build/buffer-evidence/affine-42/candidate.c"
