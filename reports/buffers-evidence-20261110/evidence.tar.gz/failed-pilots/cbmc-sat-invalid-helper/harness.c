#include <stdint.h>
_Static_assert(sizeof(unsigned int)*8==32,"u32 model");
_Static_assert(_Generic((uint32_t)0,unsigned int:1,default:0),"uint32 type");
extern uint32_t csrd_nondet_u32(void);
uint32_t csrd_original_buffer_store(uint32_t*,uint32_t*,uint32_t);
uint32_t csrd_candidate_buffer_store(uint32_t*,uint32_t*,uint32_t);
int main(void){uint32_t a[3],b[3];
a[0]=csrd_nondet_u32();b[0]=a[0];
a[1]=csrd_nondet_u32();b[1]=a[1];
a[2]=csrd_nondet_u32();b[2]=a[2];
uint32_t scalar_2=csrd_nondet_u32();
uint32_t original_result=csrd_original_buffer_store(a+0,a+0,scalar_2);
uint32_t candidate_result=csrd_candidate_buffer_store(b+0,b+0,scalar_2);
__CPROVER_assert(original_result==candidate_result,"return equality");
__CPROVER_assert(a[0]==b[0],"memory cell 0");
__CPROVER_assert(a[1]==b[1],"memory cell 1");
__CPROVER_assert(a[2]==b[2],"memory cell 2");
return 0;}
