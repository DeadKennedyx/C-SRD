#define _POSIX_C_SOURCE 200809L
#ifdef __APPLE__
#define _DARWIN_C_SOURCE
#endif
#include <stdint.h>
#include <inttypes.h>
#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <sys/resource.h>
uint32_t buffer_update(uint32_t*,const uint32_t*,uint32_t);
static uint32_t next(uint32_t *s){*s^=*s<<13;*s^=*s>>17;*s^=*s<<5;return *s;}
static double seconds(struct timespec a,struct timespec b){return (double)(b.tv_sec-a.tv_sec)+(double)(b.tv_nsec-a.tv_nsec)*1e-9;}
int main(int argc,char**argv){
    if(argc!=3)return 3;
    unsigned long n=strtoul(argv[1],0,10);
    uint32_t state=(uint32_t)strtoul(argv[2],0,10),p[4]={0,0,7,9},q[4]={0,0,3,5};
    uint64_t sum=0;
    struct timespec wall_a,wall_b,cpu_a,cpu_b;
    if(clock_gettime(CLOCK_MONOTONIC,&wall_a)||clock_gettime(CLOCK_PROCESS_CPUTIME_ID,&cpu_a))return 2;
    for(unsigned long i=0;i<n;++i){
        p[0]=next(&state);q[0]=next(&state);uint32_t x=next(&state);
        sum+=buffer_update(p,(i&1u)?p:q,x);sum+=p[1];
    }
    if(clock_gettime(CLOCK_PROCESS_CPUTIME_ID,&cpu_b)||clock_gettime(CLOCK_MONOTONIC,&wall_b))return 2;
    if(p[2]!=7||p[3]!=9||q[2]!=3||q[3]!=5)return 4;
    struct rusage usage;if(getrusage(RUSAGE_SELF,&usage))return 2;
    uint64_t rss=(uint64_t)usage.ru_maxrss;
#ifndef __APPLE__
    rss*=1024u;
#endif
    printf("%.9f %" PRIu64 " %.9f %" PRIu64 "\n",seconds(wall_a,wall_b),sum,seconds(cpu_a,cpu_b),rss);
    return 0;
}
