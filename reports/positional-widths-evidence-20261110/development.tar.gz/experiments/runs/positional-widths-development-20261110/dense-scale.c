#include <stdint.h>
uint32_t f(uint32_t x,uint32_t y){(void)y;return x*2186250713u;}
