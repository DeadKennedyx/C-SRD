#include <stdint.h>
uint32_t f(uint32_t x,uint32_t y){(void)y;return x*3521782525u;}
