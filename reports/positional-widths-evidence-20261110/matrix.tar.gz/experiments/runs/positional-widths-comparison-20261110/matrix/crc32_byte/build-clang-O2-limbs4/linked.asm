
/work/experiments/runs/positional-widths-comparison-20261110/matrix/crc32_byte/build-clang-O2-limbs4/program:	file format elf64-littleaarch64

Disassembly of section .init:

0000000000000678 <_init>:
     678:      	nop
     67c:      	stp	x29, x30, [sp, #-0x10]!
     680:      	mov	x29, sp
     684:      	bl	0x774 <call_weak_fn>
     688:      	ldp	x29, x30, [sp], #0x10
     68c:      	ret

Disassembly of section .plt:

0000000000000690 <.plt>:
     690:      	stp	x16, x30, [sp, #-0x10]!
     694:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e060>
     698:      	ldr	x17, [x16, #0xff8]
     69c:      	add	x16, x16, #0xff8
     6a0:      	br	x17
     6a4:      	nop
     6a8:      	nop
     6ac:      	nop

00000000000006b0 <strtoul@plt>:
     6b0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6b4:      	ldr	x17, [x16]
     6b8:      	add	x16, x16, #0x0
     6bc:      	br	x17

00000000000006c0 <__libc_start_main@plt>:
     6c0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6c4:      	ldr	x17, [x16, #0x8]
     6c8:      	add	x16, x16, #0x8
     6cc:      	br	x17

00000000000006d0 <__cxa_finalize@plt>:
     6d0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6d4:      	ldr	x17, [x16, #0x10]
     6d8:      	add	x16, x16, #0x10
     6dc:      	br	x17

00000000000006e0 <clock_gettime@plt>:
     6e0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6e4:      	ldr	x17, [x16, #0x18]
     6e8:      	add	x16, x16, #0x18
     6ec:      	br	x17

00000000000006f0 <__gmon_start__@plt>:
     6f0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6f4:      	ldr	x17, [x16, #0x20]
     6f8:      	add	x16, x16, #0x20
     6fc:      	br	x17

0000000000000700 <abort@plt>:
     700:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     704:      	ldr	x17, [x16, #0x28]
     708:      	add	x16, x16, #0x28
     70c:      	br	x17

0000000000000710 <__isoc99_scanf@plt>:
     710:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     714:      	ldr	x17, [x16, #0x30]
     718:      	add	x16, x16, #0x30
     71c:      	br	x17

0000000000000720 <printf@plt>:
     720:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     724:      	ldr	x17, [x16, #0x38]
     728:      	add	x16, x16, #0x38
     72c:      	br	x17

Disassembly of section .text:

0000000000000740 <_start>:
     740:      	nop
     744:      	mov	x29, #0x0               // =0
     748:      	mov	x30, #0x0               // =0
     74c:      	mov	x5, x0
     750:      	ldr	x1, [sp]
     754:      	add	x2, sp, #0x8
     758:      	mov	x6, sp
     75c:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e060>
     760:      	ldr	x0, [x0, #0xfd8]
     764:      	mov	x3, #0x0                // =0
     768:      	mov	x4, #0x0                // =0
     76c:      	bl	0x6c0 <__libc_start_main@plt>
     770:      	bl	0x700 <abort@plt>

0000000000000774 <call_weak_fn>:
     774:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e060>
     778:      	ldr	x0, [x0, #0xfd0]
     77c:      	cbz	x0, 0x784 <call_weak_fn+0x10>
     780:      	b	0x6f0 <__gmon_start__@plt>
     784:      	ret
     788:      	nop
     78c:      	nop

0000000000000790 <deregister_tm_clones>:
     790:      	adrp	x0, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     794:      	add	x0, x0, #0x50
     798:      	adrp	x1, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     79c:      	add	x1, x1, #0x50
     7a0:      	cmp	x1, x0
     7a4:      	b.eq	0x7bc <deregister_tm_clones+0x2c>
     7a8:      	adrp	x1, 0x1f000 <__FRAME_END__+0x1e060>
     7ac:      	ldr	x1, [x1, #0xfc0]
     7b0:      	cbz	x1, 0x7bc <deregister_tm_clones+0x2c>
     7b4:      	mov	x16, x1
     7b8:      	br	x16
     7bc:      	ret

00000000000007c0 <register_tm_clones>:
     7c0:      	adrp	x0, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     7c4:      	add	x0, x0, #0x50
     7c8:      	adrp	x1, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     7cc:      	add	x1, x1, #0x50
     7d0:      	sub	x1, x1, x0
     7d4:      	lsr	x2, x1, #63
     7d8:      	add	x1, x2, x1, asr #3
     7dc:      	asr	x1, x1, #1
     7e0:      	cbz	x1, 0x7f8 <register_tm_clones+0x38>
     7e4:      	adrp	x2, 0x1f000 <__FRAME_END__+0x1e060>
     7e8:      	ldr	x2, [x2, #0xfe0]
     7ec:      	cbz	x2, 0x7f8 <register_tm_clones+0x38>
     7f0:      	mov	x16, x2
     7f4:      	br	x16
     7f8:      	ret
     7fc:      	nop

0000000000000800 <__do_global_dtors_aux>:
     800:      	paciasp
     804:      	stp	x29, x30, [sp, #-0x20]!
     808:      	mov	x29, sp
     80c:      	str	x19, [sp, #0x10]
     810:      	adrp	x19, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     814:      	ldrb	w0, [x19, #0x50]
     818:      	tbnz	w0, #0x0, 0x840 <__do_global_dtors_aux+0x40>
     81c:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e060>
     820:      	ldr	x0, [x0, #0xfc8]
     824:      	cbz	x0, 0x834 <__do_global_dtors_aux+0x34>
     828:      	adrp	x0, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     82c:      	ldr	x0, [x0, #0x48]
     830:      	bl	0x6d0 <__cxa_finalize@plt>
     834:      	bl	0x790 <deregister_tm_clones>
     838:      	mov	w0, #0x1                // =1
     83c:      	strb	w0, [x19, #0x50]
     840:      	ldr	x19, [sp, #0x10]
     844:      	ldp	x29, x30, [sp], #0x20
     848:      	autiasp
     84c:      	ret

0000000000000850 <frame_dummy>:
     850:      	bti	c
     854:      	b	0x7c0 <register_tm_clones>

0000000000000858 <kernel>:
     858:      	str	x27, [sp, #-0x50]!
     85c:      	stp	x26, x25, [sp, #0x10]
     860:      	stp	x24, x23, [sp, #0x20]
     864:      	stp	x22, x21, [sp, #0x30]
     868:      	stp	x20, x19, [sp, #0x40]
     86c:      	mov	w10, #-0x1              // =-1
     870:      	eon	w13, w1, w0
     874:      	eor	w18, w1, w0
     878:      	eor	w11, w10, w0, lsr #8
     87c:      	eor	w14, w10, w0, lsr #12
     880:      	sbfx	w2, w13, #0, #1
     884:      	eor	w6, w10, w0, lsr #16
     888:      	sbfx	w3, w13, #1, #1
     88c:      	mvn	w5, w0
     890:      	ubfx	w16, w11, #1, #3
     894:      	and	w1, w2, #0x3
     898:      	lsr	w19, w5, #25
     89c:      	lsr	w20, w5, #26
     8a0:      	lsr	w21, w5, #30
     8a4:      	and	w22, w2, #0x8
     8a8:      	bfi	w16, w14, #3, #1
     8ac:      	and	w5, w3, #0x3
     8b0:      	eor	w4, w10, w0, lsr #20
     8b4:      	eor	w12, w10, w0, lsr #24
     8b8:      	eor	w10, w10, w18, lsr #4
     8bc:      	ubfiz	w11, w11, #3, #1
     8c0:      	eor	w16, w1, w16
     8c4:      	lsr	w1, w14, #1
     8c8:      	ubfx	w14, w14, #1, #3
     8cc:      	lsr	w7, w16, #1
     8d0:      	ubfx	w24, w4, #1, #3
     8d4:      	bfxil	w11, w10, #1, #3
     8d8:      	bfi	w14, w6, #3, #1
     8dc:      	mov	w8, #0xb                // =11
     8e0:      	and	w19, w19, #0x8
     8e4:      	bfi	w7, w1, #3, #1
     8e8:      	lsr	w1, w6, #1
     8ec:      	ubfx	w6, w6, #1, #3
     8f0:      	eor	w14, w22, w14
     8f4:      	bfi	w24, w12, #3, #1
     8f8:      	and	w27, w3, #0x8
     8fc:      	eor	w5, w7, w5
     900:      	lsr	w7, w14, #1
     904:      	bfi	w6, w4, #3, #1
     908:      	lsr	w23, w5, #1
     90c:      	and	w26, w2, w8
     910:      	bfxil	w19, w12, #1, #3
     914:      	mov	w9, #0xd                // =13
     918:      	and	w25, w2, #0xe
     91c:      	and	w20, w20, #0x8
     920:      	orr	w4, w23, w7, lsl #3
     924:      	bfi	w7, w1, #3, #1
     928:      	and	w23, w2, #0x2
     92c:      	eor	w12, w23, w11
     930:      	eor	w1, w22, w6
     934:      	eor	w6, w26, w24
     938:      	eor	w11, w7, w27
     93c:      	lsr	w7, w1, #1
     940:      	and	w2, w2, w9
     944:      	lsr	w11, w11, #1
     948:      	lsr	w22, w6, #1
     94c:      	eor	w2, w2, w19
     950:      	lsr	w19, w12, #1
     954:      	and	w23, w3, #0xf
     958:      	sbfx	w13, w13, #2, #1
     95c:      	orr	w24, w11, w7, lsl #3
     960:      	bfi	w7, w6, #3, #1
     964:      	bfi	w22, w2, #3, #1
     968:      	bfi	w19, w16, #3, #1
     96c:      	orr	w16, w20, w2, lsr #1
     970:      	and	w6, w3, w8
     974:      	eor	w7, w7, w27
     978:      	and	w11, w3, #0x2
     97c:      	and	w3, w3, w9
     980:      	eor	w6, w22, w6
     984:      	lsr	w7, w7, #1
     988:      	eor	w16, w16, w3
     98c:      	lsr	w20, w6, #1
     990:      	eor	w2, w21, w25, lsr #1
     994:      	eor	w11, w19, w11
     998:      	lsr	w21, w16, #1
     99c:      	orr	w6, w7, w6, lsl #3
     9a0:      	lsr	w19, w11, #1
     9a4:      	orr	w16, w20, w16, lsl #3
     9a8:      	eor	w3, w2, w23
     9ac:      	and	w20, w24, #0xf
     9b0:      	orr	w2, w21, w2, lsl #3
     9b4:      	and	w6, w6, #0xe
     9b8:      	and	w24, w13, #0x8
     9bc:      	and	w23, w13, #0xf
     9c0:      	orr	w5, w19, w5, lsl #3
     9c4:      	and	w7, w4, #0xf
     9c8:      	and	w21, w16, #0xf
     9cc:      	and	w16, w13, #0x3
     9d0:      	and	w25, w13, w8
     9d4:      	and	w26, w13, w9
     9d8:      	eor	w4, w19, w13
     9dc:      	eor	w13, w6, w24
     9e0:      	mov	w6, #0x8                // =8
     9e4:      	mov	w15, #0xf               // =15
     9e8:      	and	w2, w2, #0xf
     9ec:      	bics	wzr, w6, w18
     9f0:      	bic	w17, w15, w18, lsr #4
     9f4:      	eor	w7, w7, w16
     9f8:      	eor	w16, w20, w24
     9fc:      	lsr	w5, w5, #1
     a00:      	eor	w20, w2, w26
     a04:      	csel	w2, w15, wzr, ne
     a08:      	bic	w15, w6, w0, lsr #12
     a0c:      	bic	w0, w6, w0, lsr #16
     a10:      	eor	w19, w21, w25
     a14:      	and	w18, w5, #0x6
     a18:      	lsr	w22, w3, #1
     a1c:      	orr	w6, w15, w7, lsr #1
     a20:      	orr	w15, w0, w16, lsr #1
     a24:      	eor	w3, w23, w3, lsr #1
     a28:      	lsr	w21, w13, #1
     a2c:      	bfi	w18, w7, #3, #1
     a30:      	lsr	w23, w19, #1
     a34:      	lsr	w24, w20, #1
     a38:      	and	w7, w2, #0x8
     a3c:      	and	w0, w2, #0x3
     a40:      	eor	w15, w15, w7
     a44:      	bfi	w21, w19, #3, #1
     a48:      	bfi	w23, w20, #3, #1
     a4c:      	bfi	w24, w22, #3, #1
     a50:      	eor	w22, w6, w0
     a54:      	sbfx	w6, w17, #0, #1
     a58:      	lsr	w0, w15, #1
     a5c:      	and	w19, w2, #0xfffffffb
     a60:      	and	w20, w2, #0xfffffffd
     a64:      	and	w1, w1, #0x8
     a68:      	eor	w17, w21, w7
     a6c:      	eor	w7, w23, w19
     a70:      	eor	w19, w24, w20
     a74:      	orr	w1, w0, w1
     a78:      	and	w20, w6, #0x8
     a7c:      	lsr	w23, w18, #1
     a80:      	eor	w1, w1, w20
     a84:      	and	w18, w4, #0x2
     a88:      	lsr	w4, w17, #1
     a8c:      	lsr	w1, w1, #1
     a90:      	and	w14, w14, #0x8
     a94:      	lsl	w24, w3, #2
     a98:      	bfi	w23, w22, #3, #1
     a9c:      	orr	w14, w14, w22, lsr #1
     aa0:      	ubfiz	w22, w19, #3, #1
     aa4:      	eor	w5, w5, w2
     aa8:      	orr	w1, w1, w4, lsl #3
     aac:      	and	w24, w24, #0x8
     ab0:      	lsr	w3, w3, #2
     ab4:      	bfi	w4, w7, #3, #1
     ab8:      	lsr	w5, w5, #1
     abc:      	orr	w7, w22, w7, lsr #1
     ac0:      	orr	w19, w24, w19, lsr #1
     ac4:      	and	w22, w6, #0x3
     ac8:      	and	w21, w6, #0xf
     acc:      	eor	w2, w3, w2, lsr #1
     ad0:      	and	w3, w6, #0x2
     ad4:      	and	w24, w6, w8
     ad8:      	and	w6, w6, w9
     adc:      	eor	w14, w14, w22
     ae0:      	eor	w4, w4, w20
     ae4:      	eor	w7, w7, w24
     ae8:      	eor	w6, w19, w6
     aec:      	bfi	w18, w5, #2, #1
     af0:      	lsr	w5, w14, #1
     af4:      	lsr	w4, w4, #1
     af8:      	eor	w3, w23, w3
     afc:      	eor	w20, w2, w21
     b00:      	lsr	w21, w7, #1
     b04:      	lsr	w23, w6, #1
     b08:      	lsr	w3, w3, #1
     b0c:      	sbfx	w22, w10, #1, #1
     b10:      	orr	w0, w5, w0, lsl #3
     b14:      	orr	w4, w4, w7, lsl #3
     b18:      	orr	w5, w21, w6, lsl #3
     b1c:      	orr	w2, w23, w2, lsl #3
     b20:      	bfi	w18, w3, #3, #1
     b24:      	eor	w24, w3, w22
     b28:      	bfi	w3, w14, #3, #1
     b2c:      	and	w14, w0, #0xf
     b30:      	and	w0, w1, #0xc
     b34:      	and	w1, w4, #0xc
     b38:      	and	w6, w22, #0x8
     b3c:      	and	w4, w5, #0xf
     b40:      	and	w2, w2, #0xf
     b44:      	and	w5, w22, #0x3
     b48:      	and	w7, w22, w8
     b4c:      	and	w21, w22, w9
     b50:      	eor	w1, w1, w6
     b54:      	and	w19, w22, #0xf
     b58:      	eor	w5, w14, w5
     b5c:      	eor	w4, w4, w7
     b60:      	eor	w2, w2, w21
     b64:      	sbfx	w12, w12, #1, #1
     b68:      	and	w16, w16, #0x8
     b6c:      	lsr	w1, w1, #1
     b70:      	lsr	w10, w20, #1
     b74:      	eor	w0, w0, w6
     b78:      	eor	w14, w19, w20, lsr #1
     b7c:      	ubfiz	w19, w5, #3, #1
     b80:      	lsr	w7, w4, #1
     b84:      	orr	w16, w16, w5, lsr #1
     b88:      	and	w13, w13, #0x8
     b8c:      	lsr	w5, w2, #1
     b90:      	orr	w13, w13, w0, lsr #1
     b94:      	bfi	w1, w4, #3, #1
     b98:      	and	w0, w12, #0x3
     b9c:      	orr	w3, w19, w3, lsr #1
     ba0:      	bfi	w7, w2, #3, #1
     ba4:      	bfi	w5, w10, #3, #1
     ba8:      	and	w2, w12, #0x8
     bac:      	eor	w16, w16, w0
     bb0:      	and	w10, w12, #0x2
     bb4:      	and	w19, w12, w9
     bb8:      	eor	w0, w1, w2
     bbc:      	ubfiz	w1, w16, #3, #1
     bc0:      	eor	w10, w3, w10
     bc4:      	eor	w3, w5, w19
     bc8:      	lsr	w6, w14, #1
     bcc:      	orr	w10, w1, w10, lsr #1
     bd0:      	lsr	w1, w3, #1
     bd4:      	and	w4, w12, w8
     bd8:      	sbfx	w11, w11, #1, #1
     bdc:      	eor	w13, w13, w2
     be0:      	eor	w2, w7, w4
     be4:      	and	w15, w15, #0x8
     be8:      	ubfx	w12, w12, #1, #3
     bec:      	bfi	w1, w6, #3, #1
     bf0:      	orr	w15, w15, w16, lsr #1
     bf4:      	lsr	w16, w0, #1
     bf8:      	lsr	w0, w2, #1
     bfc:      	and	w9, w11, w9
     c00:      	and	w17, w17, #0x8
     c04:      	eor	w12, w12, w14, lsr #2
     c08:      	eor	w9, w1, w9
     c0c:      	lsr	w22, w24, #1
     c10:      	lsr	w18, w18, #1
     c14:      	orr	w13, w17, w13, lsr #1
     c18:      	bfi	w16, w2, #3, #1
     c1c:      	bfi	w0, w3, #3, #1
     c20:      	and	w14, w11, #0x2
     c24:      	and	w17, w11, #0x3
     c28:      	and	w2, w11, #0x8
     c2c:      	and	w8, w11, w8
     c30:      	and	w11, w11, #0xe
     c34:      	lsl	w9, w9, #24
     c38:      	eor	w10, w10, w14
     c3c:      	eor	w14, w15, w17
     c40:      	eon	w11, w11, w12
     c44:      	bfi	w18, w22, #3, #1
     c48:      	eor	w13, w13, w2
     c4c:      	eor	w8, w0, w8
     c50:      	lsl	w12, w14, #8
     c54:      	orr	w9, w9, w11, lsl #28
     c58:      	lsl	w13, w13, #12
     c5c:      	lsl	w8, w8, #20
     c60:      	eor	w11, w16, w2
     c64:      	orr	w10, w18, w10, lsl #4
     c68:      	eor	w12, w12, #0xf00
     c6c:      	eor	w9, w9, #0xf000000
     c70:      	eor	w13, w13, #0xf000
     c74:      	lsl	w11, w11, #16
     c78:      	eor	w8, w8, #0xf00000
     c7c:      	orr	w9, w9, w12
     c80:      	orr	w8, w9, w8
     c84:      	orr	w9, w10, w13
     c88:      	eor	w10, w11, #0xf0000
     c8c:      	orr	w8, w8, w9
     c90:      	ldp	x20, x19, [sp, #0x40]
     c94:      	orr	w8, w8, w10
     c98:      	ldp	x22, x21, [sp, #0x30]
     c9c:      	eor	w0, w8, #0xff
     ca0:      	ldp	x24, x23, [sp, #0x20]
     ca4:      	ldp	x26, x25, [sp, #0x10]
     ca8:      	ldr	x27, [sp], #0x50
     cac:      	ret

0000000000000cb0 <main>:
     cb0:      	sub	sp, sp, #0x50
     cb4:      	stp	x29, x30, [sp, #0x20]
     cb8:      	str	x21, [sp, #0x30]
     cbc:      	stp	x20, x19, [sp, #0x40]
     cc0:      	add	x29, sp, #0x20
     cc4:      	cmp	w0, #0x3
     cc8:      	b.eq	0xd34 <main+0x84>
     ccc:      	cmp	w0, #0x1
     cd0:      	b.ne	0xdc0 <main+0x110>
     cd4:      	add	x21, sp, #0x10
     cd8:      	adrp	x0, 0x0 <strtoul@GLIBC_2.17>
     cdc:      	add	x0, x0, #0xe38
     ce0:      	add	x1, sp, #0x10
     ce4:      	add	x2, x21, #0x4
     ce8:      	bl	0x710 <__isoc99_scanf@plt>
     cec:      	cmp	w0, #0x2
     cf0:      	b.ne	0xdfc <main+0x14c>
     cf4:      	adrp	x19, 0x0 <strtoul@GLIBC_2.17>
     cf8:      	add	x19, x19, #0xe3d
     cfc:      	adrp	x20, 0x0 <strtoul@GLIBC_2.17>
     d00:      	add	x20, x20, #0xe38
     d04:      	ldp	w0, w1, [sp, #0x10]
     d08:      	bl	0x858 <kernel>
     d0c:      	mov	w1, w0
     d10:      	mov	x0, x19
     d14:      	bl	0x720 <printf@plt>
     d18:      	add	x1, sp, #0x10
     d1c:      	add	x2, x21, #0x4
     d20:      	mov	x0, x20
     d24:      	bl	0x710 <__isoc99_scanf@plt>
     d28:      	cmp	w0, #0x2
     d2c:      	b.eq	0xd04 <main+0x54>
     d30:      	b	0xdfc <main+0x14c>
     d34:      	ldr	x0, [x1, #0x8]
     d38:      	mov	x19, x1
     d3c:      	mov	x1, xzr
     d40:      	mov	w2, #0xa                // =10
     d44:      	bl	0x6b0 <strtoul@plt>
     d48:      	ldr	x8, [x19, #0x10]
     d4c:      	mov	x20, x0
     d50:      	mov	x1, xzr
     d54:      	mov	w2, #0xa                // =10
     d58:      	mov	x0, x8
     d5c:      	bl	0x6b0 <strtoul@plt>
     d60:      	mov	x21, x0
     d64:      	add	x1, sp, #0x10
     d68:      	mov	w0, #0x1                // =1
     d6c:      	bl	0x6e0 <clock_gettime@plt>
     d70:      	cbnz	w0, 0xdb8 <main+0x108>
     d74:      	mov	x19, xzr
     d78:      	cbz	x20, 0xda8 <main+0xf8>
     d7c:      	eor	w8, w21, w21, lsl #13
     d80:      	eor	w8, w8, w8, lsr #17
     d84:      	eor	w0, w8, w8, lsl #5
     d88:      	eor	w8, w0, w0, lsl #13
     d8c:      	eor	w8, w8, w8, lsr #17
     d90:      	eor	w21, w8, w8, lsl #5
     d94:      	mov	w1, w21
     d98:      	bl	0x858 <kernel>
     d9c:      	add	x19, x19, w0, uxtw
     da0:      	subs	x20, x20, #0x1
     da4:      	b.ne	0xd7c <main+0xcc>
     da8:      	mov	x1, sp
     dac:      	mov	w0, #0x1                // =1
     db0:      	bl	0x6e0 <clock_gettime@plt>
     db4:      	cbz	w0, 0xdc8 <main+0x118>
     db8:      	mov	w0, #0x2                // =2
     dbc:      	b	0xe00 <main+0x150>
     dc0:      	mov	w0, #0x3                // =3
     dc4:      	b	0xe00 <main+0x150>
     dc8:      	ldp	x8, x9, [sp]
     dcc:      	adrp	x0, 0x0 <strtoul@GLIBC_2.17>
     dd0:      	add	x0, x0, #0xe41
     dd4:      	ldp	x10, x11, [sp, #0x10]
     dd8:      	mov	x1, x19
     ddc:      	sub	x8, x8, x10
     de0:      	sub	x9, x9, x11
     de4:      	scvtf	d0, x8
     de8:      	scvtf	d1, x9
     dec:      	adrp	x8, 0x0 <strtoul@GLIBC_2.17>
     df0:      	ldr	d2, [x8, #0xe30]
     df4:      	fmadd	d0, d1, d2, d0
     df8:      	bl	0x720 <printf@plt>
     dfc:      	mov	w0, wzr
     e00:      	ldp	x20, x19, [sp, #0x40]
     e04:      	ldr	x21, [sp, #0x30]
     e08:      	ldp	x29, x30, [sp, #0x20]
     e0c:      	add	sp, sp, #0x50
     e10:      	ret

Disassembly of section .fini:

0000000000000e14 <_fini>:
     e14:      	nop
     e18:      	stp	x29, x30, [sp, #-0x10]!
     e1c:      	mov	x29, sp
     e20:      	ldp	x29, x30, [sp], #0x10
     e24:      	ret
