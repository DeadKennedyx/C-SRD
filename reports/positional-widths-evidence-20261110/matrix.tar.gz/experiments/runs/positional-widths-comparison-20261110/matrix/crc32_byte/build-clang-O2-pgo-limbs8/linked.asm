
/work/experiments/runs/positional-widths-comparison-20261110/matrix/crc32_byte/build-clang-O2-pgo-limbs8/program:	file format elf64-littleaarch64

Disassembly of section .init:

0000000000000678 <_init>:
     678:      	nop
     67c:      	stp	x29, x30, [sp, #-0x10]!
     680:      	mov	x29, sp
     684:      	bl	0x9f4 <call_weak_fn>
     688:      	ldp	x29, x30, [sp], #0x10
     68c:      	ret

Disassembly of section .plt:

0000000000000690 <.plt>:
     690:      	stp	x16, x30, [sp, #-0x10]!
     694:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e25c>
     698:      	ldr	x17, [x16, #0xff8]
     69c:      	add	x16, x16, #0xff8
     6a0:      	br	x17
     6a4:      	nop
     6a8:      	nop
     6ac:      	nop

00000000000006b0 <strtoul@plt>:
     6b0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6b4:      	ldr	x17, [x16]
     6b8:      	add	x16, x16, #0x0
     6bc:      	br	x17

00000000000006c0 <__libc_start_main@plt>:
     6c0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6c4:      	ldr	x17, [x16, #0x8]
     6c8:      	add	x16, x16, #0x8
     6cc:      	br	x17

00000000000006d0 <__cxa_finalize@plt>:
     6d0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6d4:      	ldr	x17, [x16, #0x10]
     6d8:      	add	x16, x16, #0x10
     6dc:      	br	x17

00000000000006e0 <clock_gettime@plt>:
     6e0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6e4:      	ldr	x17, [x16, #0x18]
     6e8:      	add	x16, x16, #0x18
     6ec:      	br	x17

00000000000006f0 <__gmon_start__@plt>:
     6f0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6f4:      	ldr	x17, [x16, #0x20]
     6f8:      	add	x16, x16, #0x20
     6fc:      	br	x17

0000000000000700 <abort@plt>:
     700:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     704:      	ldr	x17, [x16, #0x28]
     708:      	add	x16, x16, #0x28
     70c:      	br	x17

0000000000000710 <__isoc99_scanf@plt>:
     710:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     714:      	ldr	x17, [x16, #0x30]
     718:      	add	x16, x16, #0x30
     71c:      	br	x17

0000000000000720 <printf@plt>:
     720:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     724:      	ldr	x17, [x16, #0x38]
     728:      	add	x16, x16, #0x38
     72c:      	br	x17

Disassembly of section .text:

0000000000000740 <kernel>:
     740:      	mov	w10, #-0x1              // =-1
     744:      	eon	w13, w0, w1
     748:      	mvn	w16, w0
     74c:      	eor	w12, w10, w0, lsr #8
     750:      	eor	w11, w10, w0, lsr #16
     754:      	and	w14, w13, #0xff
     758:      	sbfx	w14, w14, #0, #1
     75c:      	ubfiz	w17, w13, #5, #1
     760:      	mov	w9, #0x83               // =131
     764:      	ubfiz	w15, w12, #7, #1
     768:      	ubfx	w12, w12, #1, #7
     76c:      	lsr	w18, w16, #17
     770:      	and	w1, w14, w9
     774:      	lsl	w0, w13, #4
     778:      	lsr	w2, w11, #1
     77c:      	bfxil	w15, w13, #1, #7
     780:      	bfi	w12, w11, #7, #1
     784:      	mov	w8, #0xb8               // =184
     788:      	sbfx	w13, w13, #1, #1
     78c:      	mov	w10, #0xed              // =237
     790:      	and	w0, w0, #0x20
     794:      	eor	w15, w15, w17
     798:      	eor	w12, w1, w12
     79c:      	and	w17, w18, #0x80
     7a0:      	lsr	w18, w15, #1
     7a4:      	lsr	w1, w12, #1
     7a8:      	bfxil	w17, w11, #1, #7
     7ac:      	and	w3, w14, w8
     7b0:      	and	w14, w14, w10
     7b4:      	lsr	w11, w11, #3
     7b8:      	bfi	w18, w12, #7, #1
     7bc:      	bfi	w1, w2, #7, #1
     7c0:      	and	w2, w13, w9
     7c4:      	eor	w12, w3, w17
     7c8:      	eor	w14, w14, w16, lsr #25
     7cc:      	eor	w18, w18, w0
     7d0:      	lsr	w17, w12, #1
     7d4:      	eor	w0, w1, w2
     7d8:      	lsr	w16, w18, #1
     7dc:      	lsr	w1, w0, #1
     7e0:      	mov	w2, w17
     7e4:      	orr	w16, w16, w0, lsl #7
     7e8:      	orr	w17, w1, w17, lsl #7
     7ec:      	bfi	w2, w14, #7, #1
     7f0:      	ubfx	w1, w15, #1, #1
     7f4:      	and	w0, w13, w8
     7f8:      	and	w13, w13, w10
     7fc:      	sbfx	w15, w15, #1, #1
     800:      	and	w16, w16, #0xfe
     804:      	eor	w0, w2, w0
     808:      	eor	w13, w13, w14, lsr #1
     80c:      	eor	w14, w16, w1, lsl #5
     810:      	lsr	w16, w0, #1
     814:      	and	w0, w15, w9
     818:      	and	w17, w17, #0xff
     81c:      	ubfx	w2, w18, #1, #1
     820:      	eor	w17, w17, w0
     824:      	lsr	w0, w14, #1
     828:      	orr	w16, w16, w13, lsl #7
     82c:      	lsr	w3, w17, #1
     830:      	and	w1, w15, w8
     834:      	and	w15, w15, w10
     838:      	bfi	w0, w17, #7, #1
     83c:      	and	w16, w16, #0xff
     840:      	sbfx	w18, w18, #1, #1
     844:      	bfi	w3, w11, #7, #1
     848:      	eor	w11, w16, w1
     84c:      	eor	w13, w15, w13, lsr #1
     850:      	eor	w15, w0, w2, lsl #5
     854:      	lsr	w16, w11, #1
     858:      	and	w17, w18, w9
     85c:      	eor	w17, w3, w17
     860:      	lsr	w1, w12, #3
     864:      	and	w12, w18, w8
     868:      	lsr	w0, w15, #1
     86c:      	bfi	w16, w13, #7, #1
     870:      	lsr	w2, w17, #1
     874:      	sbfx	w3, w14, #1, #1
     878:      	ubfx	w14, w14, #1, #1
     87c:      	lsr	w11, w11, #3
     880:      	orr	w17, w0, w17, lsl #7
     884:      	eor	w12, w16, w12
     888:      	and	w16, w18, w10
     88c:      	lsr	w18, w12, #1
     890:      	eor	w13, w16, w13, lsr #1
     894:      	bfi	w2, w1, #7, #1
     898:      	and	w16, w17, #0xfe
     89c:      	and	w17, w3, w9
     8a0:      	and	w0, w3, w8
     8a4:      	eor	w14, w16, w14, lsl #5
     8a8:      	mov	w16, w18
     8ac:      	eor	w17, w2, w17
     8b0:      	bfi	w16, w13, #7, #1
     8b4:      	and	w1, w3, w10
     8b8:      	lsr	w3, w17, #1
     8bc:      	lsr	w2, w14, #1
     8c0:      	eor	w13, w1, w13, lsr #1
     8c4:      	lsr	w12, w12, #3
     8c8:      	eor	w16, w16, w0
     8cc:      	ubfx	w0, w15, #1, #1
     8d0:      	sbfx	w15, w15, #1, #1
     8d4:      	bfi	w2, w17, #7, #1
     8d8:      	lsr	w16, w16, #1
     8dc:      	orr	w17, w3, w18, lsl #7
     8e0:      	eor	w18, w2, w0, lsl #5
     8e4:      	orr	w16, w16, w13, lsl #7
     8e8:      	and	w0, w15, w9
     8ec:      	and	w17, w17, #0xff
     8f0:      	and	w2, w15, w8
     8f4:      	and	w15, w15, w10
     8f8:      	lsr	w1, w18, #1
     8fc:      	eor	w17, w17, w0
     900:      	and	w16, w16, #0xfc
     904:      	eor	w13, w15, w13, lsr #1
     908:      	eor	w16, w16, w2
     90c:      	ubfx	w0, w14, #1, #1
     910:      	orr	w15, w1, w17, lsl #7
     914:      	lsr	w17, w17, #1
     918:      	lsr	w16, w16, #1
     91c:      	sbfx	w14, w14, #1, #1
     920:      	and	w15, w15, #0xfe
     924:      	bfi	w17, w11, #7, #1
     928:      	bfi	w16, w13, #7, #1
     92c:      	eor	w11, w15, w0, lsl #5
     930:      	and	w15, w14, w9
     934:      	and	w0, w14, w8
     938:      	eor	w15, w17, w15
     93c:      	and	w14, w14, w10
     940:      	eor	w16, w16, w0
     944:      	lsr	w11, w11, #1
     948:      	lsr	w17, w15, #1
     94c:      	eor	w13, w14, w13, lsr #1
     950:      	ubfx	w14, w18, #1, #1
     954:      	sbfx	w18, w18, #1, #1
     958:      	bfi	w11, w15, #7, #1
     95c:      	lsr	w15, w16, #1
     960:      	bfi	w17, w12, #7, #1
     964:      	and	w9, w18, w9
     968:      	and	w8, w18, w8
     96c:      	and	w10, w18, w10
     970:      	bfi	w15, w13, #7, #1
     974:      	eor	w11, w11, w14, lsl #5
     978:      	eor	w9, w17, w9
     97c:      	eon	w10, w10, w13, lsr #1
     980:      	eor	w8, w15, w8
     984:      	orr	w9, w11, w9, lsl #8
     988:      	lsl	w8, w8, #16
     98c:      	orr	w9, w9, w10, lsl #24
     990:      	eor	w8, w8, #0xff0000
     994:      	orr	w8, w9, w8
     998:      	eor	w0, w8, #0xffff
     99c:      	ret
     9a0:      	nop
     9a4:      	nop
     9a8:      	nop
     9ac:      	nop
     9b0:      	nop
     9b4:      	nop
     9b8:      	nop
     9bc:      	nop

00000000000009c0 <_start>:
     9c0:      	nop
     9c4:      	mov	x29, #0x0               // =0
     9c8:      	mov	x30, #0x0               // =0
     9cc:      	mov	x5, x0
     9d0:      	ldr	x1, [sp]
     9d4:      	add	x2, sp, #0x8
     9d8:      	mov	x6, sp
     9dc:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e25c>
     9e0:      	ldr	x0, [x0, #0xfd8]
     9e4:      	mov	x3, #0x0                // =0
     9e8:      	mov	x4, #0x0                // =0
     9ec:      	bl	0x6c0 <__libc_start_main@plt>
     9f0:      	bl	0x700 <abort@plt>

00000000000009f4 <call_weak_fn>:
     9f4:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e25c>
     9f8:      	ldr	x0, [x0, #0xfd0]
     9fc:      	cbz	x0, 0xa04 <call_weak_fn+0x10>
     a00:      	b	0x6f0 <__gmon_start__@plt>
     a04:      	ret
     a08:      	nop
     a0c:      	nop

0000000000000a10 <deregister_tm_clones>:
     a10:      	adrp	x0, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     a14:      	add	x0, x0, #0x50
     a18:      	adrp	x1, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     a1c:      	add	x1, x1, #0x50
     a20:      	cmp	x1, x0
     a24:      	b.eq	0xa3c <deregister_tm_clones+0x2c>
     a28:      	adrp	x1, 0x1f000 <__FRAME_END__+0x1e25c>
     a2c:      	ldr	x1, [x1, #0xfc0]
     a30:      	cbz	x1, 0xa3c <deregister_tm_clones+0x2c>
     a34:      	mov	x16, x1
     a38:      	br	x16
     a3c:      	ret

0000000000000a40 <register_tm_clones>:
     a40:      	adrp	x0, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     a44:      	add	x0, x0, #0x50
     a48:      	adrp	x1, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     a4c:      	add	x1, x1, #0x50
     a50:      	sub	x1, x1, x0
     a54:      	lsr	x2, x1, #63
     a58:      	add	x1, x2, x1, asr #3
     a5c:      	asr	x1, x1, #1
     a60:      	cbz	x1, 0xa78 <register_tm_clones+0x38>
     a64:      	adrp	x2, 0x1f000 <__FRAME_END__+0x1e25c>
     a68:      	ldr	x2, [x2, #0xfe0]
     a6c:      	cbz	x2, 0xa78 <register_tm_clones+0x38>
     a70:      	mov	x16, x2
     a74:      	br	x16
     a78:      	ret
     a7c:      	nop

0000000000000a80 <__do_global_dtors_aux>:
     a80:      	paciasp
     a84:      	stp	x29, x30, [sp, #-0x20]!
     a88:      	mov	x29, sp
     a8c:      	str	x19, [sp, #0x10]
     a90:      	adrp	x19, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     a94:      	ldrb	w0, [x19, #0x50]
     a98:      	tbnz	w0, #0x0, 0xac0 <__do_global_dtors_aux+0x40>
     a9c:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e25c>
     aa0:      	ldr	x0, [x0, #0xfc8]
     aa4:      	cbz	x0, 0xab4 <__do_global_dtors_aux+0x34>
     aa8:      	adrp	x0, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     aac:      	ldr	x0, [x0, #0x48]
     ab0:      	bl	0x6d0 <__cxa_finalize@plt>
     ab4:      	bl	0xa10 <deregister_tm_clones>
     ab8:      	mov	w0, #0x1                // =1
     abc:      	strb	w0, [x19, #0x50]
     ac0:      	ldr	x19, [sp, #0x10]
     ac4:      	ldp	x29, x30, [sp], #0x20
     ac8:      	autiasp
     acc:      	ret

0000000000000ad0 <frame_dummy>:
     ad0:      	bti	c
     ad4:      	b	0xa40 <register_tm_clones>

0000000000000ad8 <main>:
     ad8:      	sub	sp, sp, #0x50
     adc:      	stp	x29, x30, [sp, #0x20]
     ae0:      	str	x21, [sp, #0x30]
     ae4:      	stp	x20, x19, [sp, #0x40]
     ae8:      	add	x29, sp, #0x20
     aec:      	cmp	w0, #0x1
     af0:      	b.ne	0xb68 <main+0x90>
     af4:      	add	x21, sp, #0x10
     af8:      	adrp	x0, 0x0 <strtoul@GLIBC_2.17>
     afc:      	add	x0, x0, #0xc60
     b00:      	add	x1, sp, #0x10
     b04:      	add	x2, x21, #0x4
     b08:      	bl	0x710 <__isoc99_scanf@plt>
     b0c:      	cmp	w0, #0x2
     b10:      	b.ne	0xb50 <main+0x78>
     b14:      	adrp	x19, 0x0 <strtoul@GLIBC_2.17>
     b18:      	add	x19, x19, #0xc65
     b1c:      	adrp	x20, 0x0 <strtoul@GLIBC_2.17>
     b20:      	add	x20, x20, #0xc60
     b24:      	ldp	w0, w1, [sp, #0x10]
     b28:      	bl	0x740 <kernel>
     b2c:      	mov	w1, w0
     b30:      	mov	x0, x19
     b34:      	bl	0x720 <printf@plt>
     b38:      	add	x1, sp, #0x10
     b3c:      	add	x2, x21, #0x4
     b40:      	mov	x0, x20
     b44:      	bl	0x710 <__isoc99_scanf@plt>
     b48:      	cmp	w0, #0x2
     b4c:      	b.eq	0xb24 <main+0x4c>
     b50:      	mov	w0, wzr
     b54:      	ldp	x20, x19, [sp, #0x40]
     b58:      	ldr	x21, [sp, #0x30]
     b5c:      	ldp	x29, x30, [sp, #0x20]
     b60:      	add	sp, sp, #0x50
     b64:      	ret
     b68:      	cmp	w0, #0x3
     b6c:      	b.ne	0xbb8 <main+0xe0>
     b70:      	ldr	x0, [x1, #0x8]
     b74:      	mov	x19, x1
     b78:      	mov	x1, xzr
     b7c:      	mov	w2, #0xa                // =10
     b80:      	bl	0x6b0 <strtoul@plt>
     b84:      	ldr	x8, [x19, #0x10]
     b88:      	mov	x20, x0
     b8c:      	mov	x1, xzr
     b90:      	mov	w2, #0xa                // =10
     b94:      	mov	x0, x8
     b98:      	bl	0x6b0 <strtoul@plt>
     b9c:      	mov	x21, x0
     ba0:      	add	x1, sp, #0x10
     ba4:      	mov	w0, #0x1                // =1
     ba8:      	bl	0x6e0 <clock_gettime@plt>
     bac:      	cbz	w0, 0xbc0 <main+0xe8>
     bb0:      	mov	w0, #0x2                // =2
     bb4:      	b	0xb54 <main+0x7c>
     bb8:      	mov	w0, #0x3                // =3
     bbc:      	b	0xb54 <main+0x7c>
     bc0:      	mov	x19, xzr
     bc4:      	cbz	x20, 0xbf4 <main+0x11c>
     bc8:      	eor	w8, w21, w21, lsl #13
     bcc:      	eor	w8, w8, w8, lsr #17
     bd0:      	eor	w0, w8, w8, lsl #5
     bd4:      	eor	w8, w0, w0, lsl #13
     bd8:      	eor	w8, w8, w8, lsr #17
     bdc:      	eor	w21, w8, w8, lsl #5
     be0:      	mov	w1, w21
     be4:      	bl	0x740 <kernel>
     be8:      	add	x19, x19, w0, uxtw
     bec:      	subs	x20, x20, #0x1
     bf0:      	b.ne	0xbc8 <main+0xf0>
     bf4:      	mov	x1, sp
     bf8:      	mov	w0, #0x1                // =1
     bfc:      	bl	0x6e0 <clock_gettime@plt>
     c00:      	cbnz	w0, 0xbb0 <main+0xd8>
     c04:      	ldp	x8, x9, [sp]
     c08:      	adrp	x0, 0x0 <strtoul@GLIBC_2.17>
     c0c:      	add	x0, x0, #0xc69
     c10:      	ldp	x10, x11, [sp, #0x10]
     c14:      	mov	x1, x19
     c18:      	sub	x8, x8, x10
     c1c:      	sub	x9, x9, x11
     c20:      	scvtf	d0, x8
     c24:      	scvtf	d1, x9
     c28:      	adrp	x8, 0x0 <strtoul@GLIBC_2.17>
     c2c:      	ldr	d2, [x8, #0xc58]
     c30:      	fmadd	d0, d1, d2, d0
     c34:      	bl	0x720 <printf@plt>
     c38:      	b	0xb50 <main+0x78>

Disassembly of section .fini:

0000000000000c3c <_fini>:
     c3c:      	nop
     c40:      	stp	x29, x30, [sp, #-0x10]!
     c44:      	mov	x29, sp
     c48:      	ldp	x29, x30, [sp], #0x10
     c4c:      	ret
