
/work/experiments/runs/positional-widths-comparison-20261110/matrix/crc32_byte/build-clang-O3-thinlto-identity/program:	file format elf64-littleaarch64

Disassembly of section .init:

0000000000000678 <_init>:
     678:      	nop
     67c:      	stp	x29, x30, [sp, #-0x10]!
     680:      	mov	x29, sp
     684:      	bl	0x774 <call_weak_fn>
     688:      	ldp	x29, x30, [sp], #0x10
     68c:      	ret

Disassembly of section .plt:

0000000000000690 <.plt>:
     690:      	stp	x16, x30, [sp, #-0x10]!
     694:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e2b4>
     698:      	ldr	x17, [x16, #0xff8]
     69c:      	add	x16, x16, #0xff8
     6a0:      	br	x17
     6a4:      	nop
     6a8:      	nop
     6ac:      	nop

00000000000006b0 <strtoul@plt>:
     6b0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6b4:      	ldr	x17, [x16]
     6b8:      	add	x16, x16, #0x0
     6bc:      	br	x17

00000000000006c0 <__libc_start_main@plt>:
     6c0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6c4:      	ldr	x17, [x16, #0x8]
     6c8:      	add	x16, x16, #0x8
     6cc:      	br	x17

00000000000006d0 <__cxa_finalize@plt>:
     6d0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6d4:      	ldr	x17, [x16, #0x10]
     6d8:      	add	x16, x16, #0x10
     6dc:      	br	x17

00000000000006e0 <clock_gettime@plt>:
     6e0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6e4:      	ldr	x17, [x16, #0x18]
     6e8:      	add	x16, x16, #0x18
     6ec:      	br	x17

00000000000006f0 <__gmon_start__@plt>:
     6f0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6f4:      	ldr	x17, [x16, #0x20]
     6f8:      	add	x16, x16, #0x20
     6fc:      	br	x17

0000000000000700 <abort@plt>:
     700:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     704:      	ldr	x17, [x16, #0x28]
     708:      	add	x16, x16, #0x28
     70c:      	br	x17

0000000000000710 <__isoc99_scanf@plt>:
     710:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     714:      	ldr	x17, [x16, #0x30]
     718:      	add	x16, x16, #0x30
     71c:      	br	x17

0000000000000720 <printf@plt>:
     720:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     724:      	ldr	x17, [x16, #0x38]
     728:      	add	x16, x16, #0x38
     72c:      	br	x17

Disassembly of section .text:

0000000000000740 <_start>:
     740:      	nop
     744:      	mov	x29, #0x0               // =0
     748:      	mov	x30, #0x0               // =0
     74c:      	mov	x5, x0
     750:      	ldr	x1, [sp]
     754:      	add	x2, sp, #0x8
     758:      	mov	x6, sp
     75c:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e2b4>
     760:      	ldr	x0, [x0, #0xfd8]
     764:      	mov	x3, #0x0                // =0
     768:      	mov	x4, #0x0                // =0
     76c:      	bl	0x6c0 <__libc_start_main@plt>
     770:      	bl	0x700 <abort@plt>

0000000000000774 <call_weak_fn>:
     774:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e2b4>
     778:      	ldr	x0, [x0, #0xfd0]
     77c:      	cbz	x0, 0x784 <call_weak_fn+0x10>
     780:      	b	0x6f0 <__gmon_start__@plt>
     784:      	ret
     788:      	nop
     78c:      	nop

0000000000000790 <deregister_tm_clones>:
     790:      	adrp	x0, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     794:      	add	x0, x0, #0x50
     798:      	adrp	x1, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     79c:      	add	x1, x1, #0x50
     7a0:      	cmp	x1, x0
     7a4:      	b.eq	0x7bc <deregister_tm_clones+0x2c>
     7a8:      	adrp	x1, 0x1f000 <__FRAME_END__+0x1e2b4>
     7ac:      	ldr	x1, [x1, #0xfc0]
     7b0:      	cbz	x1, 0x7bc <deregister_tm_clones+0x2c>
     7b4:      	mov	x16, x1
     7b8:      	br	x16
     7bc:      	ret

00000000000007c0 <register_tm_clones>:
     7c0:      	adrp	x0, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     7c4:      	add	x0, x0, #0x50
     7c8:      	adrp	x1, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     7cc:      	add	x1, x1, #0x50
     7d0:      	sub	x1, x1, x0
     7d4:      	lsr	x2, x1, #63
     7d8:      	add	x1, x2, x1, asr #3
     7dc:      	asr	x1, x1, #1
     7e0:      	cbz	x1, 0x7f8 <register_tm_clones+0x38>
     7e4:      	adrp	x2, 0x1f000 <__FRAME_END__+0x1e2b4>
     7e8:      	ldr	x2, [x2, #0xfe0]
     7ec:      	cbz	x2, 0x7f8 <register_tm_clones+0x38>
     7f0:      	mov	x16, x2
     7f4:      	br	x16
     7f8:      	ret
     7fc:      	nop

0000000000000800 <__do_global_dtors_aux>:
     800:      	paciasp
     804:      	stp	x29, x30, [sp, #-0x20]!
     808:      	mov	x29, sp
     80c:      	str	x19, [sp, #0x10]
     810:      	adrp	x19, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     814:      	ldrb	w0, [x19, #0x50]
     818:      	tbnz	w0, #0x0, 0x840 <__do_global_dtors_aux+0x40>
     81c:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e2b4>
     820:      	ldr	x0, [x0, #0xfc8]
     824:      	cbz	x0, 0x834 <__do_global_dtors_aux+0x34>
     828:      	adrp	x0, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     82c:      	ldr	x0, [x0, #0x48]
     830:      	bl	0x6d0 <__cxa_finalize@plt>
     834:      	bl	0x790 <deregister_tm_clones>
     838:      	mov	w0, #0x1                // =1
     83c:      	strb	w0, [x19, #0x50]
     840:      	ldr	x19, [sp, #0x10]
     844:      	ldp	x29, x30, [sp], #0x20
     848:      	autiasp
     84c:      	ret

0000000000000850 <frame_dummy>:
     850:      	bti	c
     854:      	b	0x7c0 <register_tm_clones>

0000000000000858 <kernel>:
     858:      	and	w9, w1, #0xff
     85c:      	adrp	x8, 0x0 <strtoul@GLIBC_2.17>
     860:      	mov	w10, #0x8320            // =33568
     864:      	eon	w9, w9, w0
     868:      	ldr	q1, [x8, #0xbb0]
     86c:      	adrp	x8, 0x0 <strtoul@GLIBC_2.17>
     870:      	dup	v0.4s, w9
     874:      	movk	w10, #0xedb8, lsl #16
     878:      	lsl	w11, w9, #30
     87c:      	and	v0.16b, v0.16b, v1.16b
     880:      	ldr	q1, [x8, #0xbc0]
     884:      	sbfx	w8, w9, #0, #1
     888:      	and	w8, w8, w10
     88c:      	cmeq	v0.4s, v0.4s, #0
     890:      	eor	w8, w8, w9, lsr #1
     894:      	and	w9, w10, w11, asr #31
     898:      	mov	w10, #0x4190            // =16784
     89c:      	mov	w11, #0x7cdf            // =31967
     8a0:      	eor	w9, w9, w8, lsr #1
     8a4:      	lsl	w8, w8, #26
     8a8:      	movk	w10, #0x76dc, lsl #16
     8ac:      	bic	v0.16b, v1.16b, v0.16b
     8b0:      	movk	w11, #0x1247, lsl #16
     8b4:      	tst	w9, #0x20
     8b8:      	and	w8, w10, w8, asr #31
     8bc:      	csinv	w10, w11, wzr, ne
     8c0:      	ext	v1.16b, v0.16b, v0.16b, #0x8
     8c4:      	eor	w9, w10, w9, lsr #6
     8c8:      	eor	v0.8b, v0.8b, v1.8b
     8cc:      	fmov	x11, d0
     8d0:      	lsr	x10, x11, #32
     8d4:      	eor	w8, w11, w8
     8d8:      	eor	w8, w8, w9
     8dc:      	eor	w0, w8, w10
     8e0:      	ret

00000000000008e4 <main>:
     8e4:      	sub	sp, sp, #0x80
     8e8:      	stp	x29, x30, [sp, #0x40]
     8ec:      	stp	x24, x23, [sp, #0x50]
     8f0:      	stp	x22, x21, [sp, #0x60]
     8f4:      	stp	x20, x19, [sp, #0x70]
     8f8:      	add	x29, sp, #0x40
     8fc:      	cmp	w0, #0x3
     900:      	b.eq	0x9f8 <main+0x114>
     904:      	cmp	w0, #0x1
     908:      	b.ne	0xb18 <main+0x234>
     90c:      	sub	x21, x29, #0x10
     910:      	adrp	x0, 0x0 <strtoul@GLIBC_2.17>
     914:      	add	x0, x0, #0xbd8
     918:      	sub	x1, x29, #0x10
     91c:      	add	x2, x21, #0x4
     920:      	bl	0x710 <__isoc99_scanf@plt>
     924:      	cmp	w0, #0x2
     928:      	b.ne	0xb68 <main+0x284>
     92c:      	adrp	x8, 0x0 <strtoul@GLIBC_2.17>
     930:      	adrp	x9, 0x0 <strtoul@GLIBC_2.17>
     934:      	mov	w22, #0x8320            // =33568
     938:      	ldr	q0, [x8, #0xbb0]
     93c:      	mov	w23, #0x4190            // =16784
     940:      	mov	w24, #0x7cdf            // =31967
     944:      	movk	w22, #0xedb8, lsl #16
     948:      	movk	w23, #0x76dc, lsl #16
     94c:      	adrp	x19, 0x0 <strtoul@GLIBC_2.17>
     950:      	add	x19, x19, #0xbdd
     954:      	str	q0, [sp, #0x10]
     958:      	ldr	q0, [x9, #0xbc0]
     95c:      	movk	w24, #0x1247, lsl #16
     960:      	adrp	x20, 0x0 <strtoul@GLIBC_2.17>
     964:      	add	x20, x20, #0xbd8
     968:      	str	q0, [sp]
     96c:      	ldur	w8, [x29, #-0x10]
     970:      	ldurb	w9, [x29, #-0xc]
     974:      	mov	x0, x19
     978:      	ldp	q1, q2, [sp]
     97c:      	eon	w8, w8, w9
     980:      	dup	v0.4s, w8
     984:      	sbfx	w9, w8, #0, #1
     988:      	lsl	w10, w8, #30
     98c:      	and	w9, w9, w22
     990:      	and	v0.16b, v0.16b, v2.16b
     994:      	eor	w8, w9, w8, lsr #1
     998:      	and	w9, w22, w10, asr #31
     99c:      	eor	w9, w9, w8, lsr #1
     9a0:      	lsl	w8, w8, #26
     9a4:      	cmeq	v0.4s, v0.4s, #0
     9a8:      	tst	w9, #0x20
     9ac:      	and	w8, w23, w8, asr #31
     9b0:      	csinv	w10, w24, wzr, ne
     9b4:      	bic	v0.16b, v1.16b, v0.16b
     9b8:      	eor	w9, w10, w9, lsr #6
     9bc:      	ext	v1.16b, v0.16b, v0.16b, #0x8
     9c0:      	eor	v0.8b, v0.8b, v1.8b
     9c4:      	fmov	x11, d0
     9c8:      	lsr	x10, x11, #32
     9cc:      	eor	w8, w11, w8
     9d0:      	eor	w8, w8, w9
     9d4:      	eor	w1, w8, w10
     9d8:      	bl	0x720 <printf@plt>
     9dc:      	sub	x1, x29, #0x10
     9e0:      	add	x2, x21, #0x4
     9e4:      	mov	x0, x20
     9e8:      	bl	0x710 <__isoc99_scanf@plt>
     9ec:      	cmp	w0, #0x2
     9f0:      	b.eq	0x96c <main+0x88>
     9f4:      	b	0xb68 <main+0x284>
     9f8:      	ldr	x0, [x1, #0x8]
     9fc:      	mov	x19, x1
     a00:      	mov	x1, xzr
     a04:      	mov	w2, #0xa                // =10
     a08:      	bl	0x6b0 <strtoul@plt>
     a0c:      	ldr	x8, [x19, #0x10]
     a10:      	mov	x20, x0
     a14:      	mov	x1, xzr
     a18:      	mov	w2, #0xa                // =10
     a1c:      	mov	x0, x8
     a20:      	bl	0x6b0 <strtoul@plt>
     a24:      	mov	x21, x0
     a28:      	sub	x1, x29, #0x10
     a2c:      	mov	w0, #0x1                // =1
     a30:      	bl	0x6e0 <clock_gettime@plt>
     a34:      	cbnz	w0, 0xafc <main+0x218>
     a38:      	mov	x19, xzr
     a3c:      	cbz	x20, 0xaec <main+0x208>
     a40:      	adrp	x8, 0x0 <strtoul@GLIBC_2.17>
     a44:      	adrp	x9, 0x0 <strtoul@GLIBC_2.17>
     a48:      	mov	w10, #0x7cdf            // =31967
     a4c:      	ldr	q0, [x8, #0xbb0]
     a50:      	ldr	q1, [x9, #0xbc0]
     a54:      	mov	w8, #0x8320             // =33568
     a58:      	mov	w9, #0x4190             // =16784
     a5c:      	movk	w8, #0xedb8, lsl #16
     a60:      	movk	w10, #0x1247, lsl #16
     a64:      	movk	w9, #0x76dc, lsl #16
     a68:      	eor	w11, w21, w21, lsl #13
     a6c:      	eor	w11, w11, w11, lsr #17
     a70:      	eor	w11, w11, w11, lsl #5
     a74:      	eor	w12, w11, w11, lsl #13
     a78:      	eor	w12, w12, w12, lsr #17
     a7c:      	eor	w21, w12, w12, lsl #5
     a80:      	and	w12, w21, #0xff
     a84:      	eon	w11, w11, w12
     a88:      	dup	v2.4s, w11
     a8c:      	sbfx	w12, w11, #0, #1
     a90:      	lsl	w13, w11, #30
     a94:      	and	w12, w12, w8
     a98:      	and	v2.16b, v2.16b, v0.16b
     a9c:      	eor	w11, w12, w11, lsr #1
     aa0:      	and	w12, w8, w13, asr #31
     aa4:      	eor	w12, w12, w11, lsr #1
     aa8:      	lsl	w11, w11, #26
     aac:      	cmeq	v2.4s, v2.4s, #0
     ab0:      	tst	w12, #0x20
     ab4:      	and	w11, w9, w11, asr #31
     ab8:      	csinv	w13, w10, wzr, ne
     abc:      	subs	x20, x20, #0x1
     ac0:      	bic	v2.16b, v1.16b, v2.16b
     ac4:      	eor	w12, w13, w12, lsr #6
     ac8:      	ext	v3.16b, v2.16b, v2.16b, #0x8
     acc:      	eor	v2.8b, v2.8b, v3.8b
     ad0:      	fmov	x14, d2
     ad4:      	lsr	x13, x14, #32
     ad8:      	eor	w11, w14, w11
     adc:      	eor	w11, w11, w12
     ae0:      	eor	w11, w11, w13
     ae4:      	add	x19, x19, x11
     ae8:      	b.ne	0xa68 <main+0x184>
     aec:      	add	x1, sp, #0x20
     af0:      	mov	w0, #0x1                // =1
     af4:      	bl	0x6e0 <clock_gettime@plt>
     af8:      	cbz	w0, 0xb34 <main+0x250>
     afc:      	mov	w0, #0x2                // =2
     b00:      	ldp	x20, x19, [sp, #0x70]
     b04:      	ldp	x22, x21, [sp, #0x60]
     b08:      	ldp	x24, x23, [sp, #0x50]
     b0c:      	ldp	x29, x30, [sp, #0x40]
     b10:      	add	sp, sp, #0x80
     b14:      	ret
     b18:      	mov	w0, #0x3                // =3
     b1c:      	ldp	x20, x19, [sp, #0x70]
     b20:      	ldp	x22, x21, [sp, #0x60]
     b24:      	ldp	x24, x23, [sp, #0x50]
     b28:      	ldp	x29, x30, [sp, #0x40]
     b2c:      	add	sp, sp, #0x80
     b30:      	ret
     b34:      	ldp	x8, x9, [sp, #0x20]
     b38:      	adrp	x0, 0x0 <strtoul@GLIBC_2.17>
     b3c:      	add	x0, x0, #0xbe1
     b40:      	ldp	x10, x11, [x29, #-0x10]
     b44:      	mov	x1, x19
     b48:      	sub	x8, x8, x10
     b4c:      	sub	x9, x9, x11
     b50:      	scvtf	d0, x8
     b54:      	scvtf	d1, x9
     b58:      	adrp	x8, 0x0 <strtoul@GLIBC_2.17>
     b5c:      	ldr	d2, [x8, #0xbd0]
     b60:      	fmadd	d0, d1, d2, d0
     b64:      	bl	0x720 <printf@plt>
     b68:      	mov	w0, wzr
     b6c:      	ldp	x20, x19, [sp, #0x70]
     b70:      	ldp	x22, x21, [sp, #0x60]
     b74:      	ldp	x24, x23, [sp, #0x50]
     b78:      	ldp	x29, x30, [sp, #0x40]
     b7c:      	add	sp, sp, #0x80
     b80:      	ret

Disassembly of section .fini:

0000000000000b84 <_fini>:
     b84:      	nop
     b88:      	stp	x29, x30, [sp, #-0x10]!
     b8c:      	mov	x29, sp
     b90:      	ldp	x29, x30, [sp], #0x10
     b94:      	ret
