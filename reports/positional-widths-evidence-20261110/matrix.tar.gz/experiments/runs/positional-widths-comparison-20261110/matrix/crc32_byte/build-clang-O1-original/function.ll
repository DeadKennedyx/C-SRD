; ModuleID = '/work/experiments/runs/positional-widths-comparison-20261110/matrix/crc32_byte/build-clang-O1-original/validation/compiler-0-O1/candidate.i'
source_filename = "/work/experiments/runs/positional-widths-comparison-20261110/matrix/crc32_byte/build-clang-O1-original/validation/compiler-0-O1/candidate.i"
target datalayout = "e-m:e-i8:8:32-i16:16:32-i64:64-i128:128-n32:64-S128"
target triple = "aarch64-unknown-linux-gnu"

; Function Attrs: nofree norecurse nosync nounwind memory(none) uwtable
define dso_local i32 @kernel(i32 noundef %0, i32 noundef %1) local_unnamed_addr #0 {
  %3 = and i32 %1, 255
  %4 = xor i32 %3, %0
  %5 = xor i32 %4, -1
  br label %8

6:                                                ; preds = %8
  %7 = xor i32 %15, -1
  ret i32 %7

8:                                                ; preds = %2, %8
  %9 = phi i32 [ 0, %2 ], [ %16, %8 ]
  %10 = phi i32 [ %5, %2 ], [ %15, %8 ]
  %11 = and i32 %10, 1
  %12 = lshr i32 %10, 1
  %13 = icmp eq i32 %11, 0
  %14 = select i1 %13, i32 0, i32 -306674912
  %15 = xor i32 %14, %12
  %16 = add nuw nsw i32 %9, 1
  %17 = icmp eq i32 %16, 8
  br i1 %17, label %6, label %8, !llvm.loop !6
}

attributes #0 = { nofree norecurse nosync nounwind memory(none) uwtable "frame-pointer"="non-leaf" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+fp-armv8,+neon,+outline-atomics,+v8a,-fmv" }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 1, !"wchar_size", i32 4}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 1}
!5 = !{!"Ubuntu clang version 18.1.3 (1ubuntu1)"}
!6 = distinct !{!6, !7, !8}
!7 = !{!"llvm.loop.mustprogress"}
!8 = !{!"llvm.loop.unroll.disable"}
