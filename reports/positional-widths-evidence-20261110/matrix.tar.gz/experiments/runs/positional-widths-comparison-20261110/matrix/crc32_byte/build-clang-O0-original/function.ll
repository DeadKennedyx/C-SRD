; ModuleID = '/work/experiments/runs/positional-widths-comparison-20261110/matrix/crc32_byte/build-clang-O0-original/validation/compiler-0-O0/candidate.i'
source_filename = "/work/experiments/runs/positional-widths-comparison-20261110/matrix/crc32_byte/build-clang-O0-original/validation/compiler-0-O0/candidate.i"
target datalayout = "e-m:e-i8:8:32-i16:16:32-i64:64-i128:128-n32:64-S128"
target triple = "aarch64-unknown-linux-gnu"

; Function Attrs: noinline nounwind optnone uwtable
define dso_local i32 @kernel(i32 noundef %0, i32 noundef %1) #0 {
  %3 = alloca i32, align 4
  %4 = alloca i32, align 4
  %5 = alloca i32, align 4
  %6 = alloca i32, align 4
  %7 = alloca i32, align 4
  store i32 %0, ptr %3, align 4
  store i32 %1, ptr %4, align 4
  %8 = load i32, ptr %3, align 4
  %9 = xor i32 %8, -1
  %10 = load i32, ptr %4, align 4
  %11 = and i32 %10, 255
  %12 = xor i32 %9, %11
  store i32 %12, ptr %5, align 4
  store i32 0, ptr %6, align 4
  store i32 0, ptr %7, align 4
  br label %13

13:                                               ; preds = %25, %2
  %14 = load i32, ptr %7, align 4
  %15 = icmp ult i32 %14, 8
  br i1 %15, label %16, label %28

16:                                               ; preds = %13
  %17 = load i32, ptr %5, align 4
  %18 = and i32 %17, 1
  %19 = sub i32 0, %18
  store i32 %19, ptr %6, align 4
  %20 = load i32, ptr %5, align 4
  %21 = lshr i32 %20, 1
  %22 = load i32, ptr %6, align 4
  %23 = and i32 -306674912, %22
  %24 = xor i32 %21, %23
  store i32 %24, ptr %5, align 4
  br label %25

25:                                               ; preds = %16
  %26 = load i32, ptr %7, align 4
  %27 = add i32 %26, 1
  store i32 %27, ptr %7, align 4
  br label %13, !llvm.loop !6

28:                                               ; preds = %13
  %29 = load i32, ptr %5, align 4
  %30 = xor i32 %29, -1
  ret i32 %30
}

attributes #0 = { noinline nounwind optnone uwtable "frame-pointer"="non-leaf" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+fp-armv8,+neon,+outline-atomics,+v8a,-fmv" }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 1, !"wchar_size", i32 4}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 1}
!5 = !{!"Ubuntu clang version 18.1.3 (1ubuntu1)"}
!6 = distinct !{!6, !7}
!7 = !{!"llvm.loop.mustprogress"}
