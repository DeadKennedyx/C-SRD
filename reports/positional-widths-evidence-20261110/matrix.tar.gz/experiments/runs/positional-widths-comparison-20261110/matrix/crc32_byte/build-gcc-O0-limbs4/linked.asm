
/work/experiments/runs/positional-widths-comparison-20261110/matrix/crc32_byte/build-gcc-O0-limbs4/program:	file format elf64-littleaarch64

Disassembly of section .init:

0000000000000730 <_init>:
     730:      	nop
     734:      	stp	x29, x30, [sp, #-0x10]!
     738:      	mov	x29, sp
     73c:      	bl	0x834 <call_weak_fn>
     740:      	ldp	x29, x30, [sp], #0x10
     744:      	ret

Disassembly of section .plt:

0000000000000750 <.plt>:
     750:      	stp	x16, x30, [sp, #-0x10]!
     754:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1c548>
     758:      	ldr	x17, [x16, #0xf78]
     75c:      	add	x16, x16, #0xf78
     760:      	br	x17
     764:      	nop
     768:      	nop
     76c:      	nop

0000000000000770 <strtoul@plt>:
     770:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1c548>
     774:      	ldr	x17, [x16, #0xf80]
     778:      	add	x16, x16, #0xf80
     77c:      	br	x17

0000000000000780 <__libc_start_main@plt>:
     780:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1c548>
     784:      	ldr	x17, [x16, #0xf88]
     788:      	add	x16, x16, #0xf88
     78c:      	br	x17

0000000000000790 <__cxa_finalize@plt>:
     790:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1c548>
     794:      	ldr	x17, [x16, #0xf90]
     798:      	add	x16, x16, #0xf90
     79c:      	br	x17

00000000000007a0 <clock_gettime@plt>:
     7a0:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1c548>
     7a4:      	ldr	x17, [x16, #0xf98]
     7a8:      	add	x16, x16, #0xf98
     7ac:      	br	x17

00000000000007b0 <__stack_chk_fail@plt>:
     7b0:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1c548>
     7b4:      	ldr	x17, [x16, #0xfa0]
     7b8:      	add	x16, x16, #0xfa0
     7bc:      	br	x17

00000000000007c0 <__gmon_start__@plt>:
     7c0:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1c548>
     7c4:      	ldr	x17, [x16, #0xfa8]
     7c8:      	add	x16, x16, #0xfa8
     7cc:      	br	x17

00000000000007d0 <abort@plt>:
     7d0:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1c548>
     7d4:      	ldr	x17, [x16, #0xfb0]
     7d8:      	add	x16, x16, #0xfb0
     7dc:      	br	x17

00000000000007e0 <__isoc99_scanf@plt>:
     7e0:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1c548>
     7e4:      	ldr	x17, [x16, #0xfb8]
     7e8:      	add	x16, x16, #0xfb8
     7ec:      	br	x17

00000000000007f0 <printf@plt>:
     7f0:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1c548>
     7f4:      	ldr	x17, [x16, #0xfc0]
     7f8:      	add	x16, x16, #0xfc0
     7fc:      	br	x17

Disassembly of section .text:

0000000000000800 <_start>:
     800:      	nop
     804:      	mov	x29, #0x0               // =0
     808:      	mov	x30, #0x0               // =0
     80c:      	mov	x5, x0
     810:      	ldr	x1, [sp]
     814:      	add	x2, sp, #0x8
     818:      	mov	x6, sp
     81c:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1c548>
     820:      	ldr	x0, [x0, #0xff0]
     824:      	mov	x3, #0x0                // =0
     828:      	mov	x4, #0x0                // =0
     82c:      	bl	0x780 <__libc_start_main@plt>
     830:      	bl	0x7d0 <abort@plt>

0000000000000834 <call_weak_fn>:
     834:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1c548>
     838:      	ldr	x0, [x0, #0xfe0]
     83c:      	cbz	x0, 0x844 <call_weak_fn+0x10>
     840:      	b	0x7c0 <__gmon_start__@plt>
     844:      	ret
     848:      	nop
     84c:      	nop

0000000000000850 <deregister_tm_clones>:
     850:      	adrp	x0, 0x20000 <data_start>
     854:      	add	x0, x0, #0x10
     858:      	adrp	x1, 0x20000 <data_start>
     85c:      	add	x1, x1, #0x10
     860:      	cmp	x1, x0
     864:      	b.eq	0x87c <deregister_tm_clones+0x2c>
     868:      	adrp	x1, 0x1f000 <__FRAME_END__+0x1c548>
     86c:      	ldr	x1, [x1, #0xfd0]
     870:      	cbz	x1, 0x87c <deregister_tm_clones+0x2c>
     874:      	mov	x16, x1
     878:      	br	x16
     87c:      	ret

0000000000000880 <register_tm_clones>:
     880:      	adrp	x0, 0x20000 <data_start>
     884:      	add	x0, x0, #0x10
     888:      	adrp	x1, 0x20000 <data_start>
     88c:      	add	x1, x1, #0x10
     890:      	sub	x1, x1, x0
     894:      	lsr	x2, x1, #63
     898:      	add	x1, x2, x1, asr #3
     89c:      	asr	x1, x1, #1
     8a0:      	cbz	x1, 0x8b8 <register_tm_clones+0x38>
     8a4:      	adrp	x2, 0x1f000 <__FRAME_END__+0x1c548>
     8a8:      	ldr	x2, [x2, #0xff8]
     8ac:      	cbz	x2, 0x8b8 <register_tm_clones+0x38>
     8b0:      	mov	x16, x2
     8b4:      	br	x16
     8b8:      	ret
     8bc:      	nop

00000000000008c0 <__do_global_dtors_aux>:
     8c0:      	paciasp
     8c4:      	stp	x29, x30, [sp, #-0x20]!
     8c8:      	mov	x29, sp
     8cc:      	str	x19, [sp, #0x10]
     8d0:      	adrp	x19, 0x20000 <data_start>
     8d4:      	ldrb	w0, [x19, #0x10]
     8d8:      	tbnz	w0, #0x0, 0x900 <__do_global_dtors_aux+0x40>
     8dc:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1c548>
     8e0:      	ldr	x0, [x0, #0xfd8]
     8e4:      	cbz	x0, 0x8f4 <__do_global_dtors_aux+0x34>
     8e8:      	adrp	x0, 0x20000 <data_start>
     8ec:      	ldr	x0, [x0, #0x8]
     8f0:      	bl	0x790 <__cxa_finalize@plt>
     8f4:      	bl	0x850 <deregister_tm_clones>
     8f8:      	mov	w0, #0x1                // =1
     8fc:      	strb	w0, [x19, #0x10]
     900:      	ldr	x19, [sp, #0x10]
     904:      	ldp	x29, x30, [sp], #0x20
     908:      	autiasp
     90c:      	ret

0000000000000910 <frame_dummy>:
     910:      	bti	c
     914:      	b	0x880 <register_tm_clones>

0000000000000918 <kernel>:
     918:      	sub	sp, sp, #0x7a0
     91c:      	str	w0, [sp, #0xc]
     920:      	str	w1, [sp, #0x8]
     924:      	ldr	w0, [sp, #0xc]
     928:      	and	w0, w0, #0xf
     92c:      	str	w0, [sp, #0x1c]
     930:      	ldr	w0, [sp, #0xc]
     934:      	lsr	w0, w0, #4
     938:      	and	w0, w0, #0xf
     93c:      	str	w0, [sp, #0x20]
     940:      	ldr	w0, [sp, #0xc]
     944:      	lsr	w0, w0, #8
     948:      	and	w0, w0, #0xf
     94c:      	str	w0, [sp, #0x24]
     950:      	ldr	w0, [sp, #0xc]
     954:      	lsr	w0, w0, #12
     958:      	and	w0, w0, #0xf
     95c:      	str	w0, [sp, #0x28]
     960:      	ldr	w0, [sp, #0xc]
     964:      	lsr	w0, w0, #16
     968:      	and	w0, w0, #0xf
     96c:      	str	w0, [sp, #0x2c]
     970:      	ldr	w0, [sp, #0xc]
     974:      	lsr	w0, w0, #20
     978:      	and	w0, w0, #0xf
     97c:      	str	w0, [sp, #0x30]
     980:      	ldr	w0, [sp, #0xc]
     984:      	lsr	w0, w0, #24
     988:      	and	w0, w0, #0xf
     98c:      	str	w0, [sp, #0x34]
     990:      	ldr	w0, [sp, #0xc]
     994:      	lsr	w0, w0, #28
     998:      	str	w0, [sp, #0x38]
     99c:      	ldr	w0, [sp, #0x8]
     9a0:      	and	w0, w0, #0xf
     9a4:      	str	w0, [sp, #0x3c]
     9a8:      	ldr	w0, [sp, #0x8]
     9ac:      	lsr	w0, w0, #4
     9b0:      	and	w0, w0, #0xf
     9b4:      	str	w0, [sp, #0x40]
     9b8:      	ldr	w0, [sp, #0x8]
     9bc:      	lsr	w0, w0, #8
     9c0:      	and	w0, w0, #0xf
     9c4:      	str	w0, [sp, #0x44]
     9c8:      	ldr	w0, [sp, #0x8]
     9cc:      	lsr	w0, w0, #12
     9d0:      	and	w0, w0, #0xf
     9d4:      	str	w0, [sp, #0x48]
     9d8:      	ldr	w0, [sp, #0x8]
     9dc:      	lsr	w0, w0, #16
     9e0:      	and	w0, w0, #0xf
     9e4:      	str	w0, [sp, #0x4c]
     9e8:      	ldr	w0, [sp, #0x8]
     9ec:      	lsr	w0, w0, #20
     9f0:      	and	w0, w0, #0xf
     9f4:      	str	w0, [sp, #0x50]
     9f8:      	ldr	w0, [sp, #0x8]
     9fc:      	lsr	w0, w0, #24
     a00:      	and	w0, w0, #0xf
     a04:      	str	w0, [sp, #0x54]
     a08:      	ldr	w0, [sp, #0x8]
     a0c:      	lsr	w0, w0, #28
     a10:      	str	w0, [sp, #0x58]
     a14:      	ldr	w0, [sp, #0x1c]
     a18:      	eor	w0, w0, #0xf
     a1c:      	str	w0, [sp, #0x5c]
     a20:      	ldr	w0, [sp, #0x20]
     a24:      	eor	w0, w0, #0xf
     a28:      	str	w0, [sp, #0x60]
     a2c:      	ldr	w0, [sp, #0x24]
     a30:      	eor	w0, w0, #0xf
     a34:      	str	w0, [sp, #0x64]
     a38:      	ldr	w0, [sp, #0x28]
     a3c:      	eor	w0, w0, #0xf
     a40:      	str	w0, [sp, #0x68]
     a44:      	ldr	w0, [sp, #0x2c]
     a48:      	eor	w0, w0, #0xf
     a4c:      	str	w0, [sp, #0x6c]
     a50:      	ldr	w0, [sp, #0x30]
     a54:      	eor	w0, w0, #0xf
     a58:      	str	w0, [sp, #0x70]
     a5c:      	ldr	w0, [sp, #0x34]
     a60:      	eor	w0, w0, #0xf
     a64:      	str	w0, [sp, #0x74]
     a68:      	ldr	w0, [sp, #0x38]
     a6c:      	eor	w0, w0, #0xf
     a70:      	str	w0, [sp, #0x78]
     a74:      	ldr	w0, [sp, #0x3c]
     a78:      	and	w0, w0, #0xf
     a7c:      	str	w0, [sp, #0x7c]
     a80:      	ldr	w0, [sp, #0x40]
     a84:      	and	w0, w0, #0xf
     a88:      	str	w0, [sp, #0x80]
     a8c:      	str	wzr, [sp, #0x84]
     a90:      	str	wzr, [sp, #0x88]
     a94:      	str	wzr, [sp, #0x8c]
     a98:      	str	wzr, [sp, #0x90]
     a9c:      	str	wzr, [sp, #0x94]
     aa0:      	str	wzr, [sp, #0x98]
     aa4:      	ldr	w1, [sp, #0x5c]
     aa8:      	ldr	w0, [sp, #0x7c]
     aac:      	eor	w0, w1, w0
     ab0:      	str	w0, [sp, #0x9c]
     ab4:      	ldr	w1, [sp, #0x60]
     ab8:      	ldr	w0, [sp, #0x80]
     abc:      	eor	w0, w1, w0
     ac0:      	str	w0, [sp, #0xa0]
     ac4:      	ldr	w1, [sp, #0x64]
     ac8:      	ldr	w0, [sp, #0x84]
     acc:      	eor	w0, w1, w0
     ad0:      	str	w0, [sp, #0xa4]
     ad4:      	ldr	w1, [sp, #0x68]
     ad8:      	ldr	w0, [sp, #0x88]
     adc:      	eor	w0, w1, w0
     ae0:      	str	w0, [sp, #0xa8]
     ae4:      	ldr	w1, [sp, #0x6c]
     ae8:      	ldr	w0, [sp, #0x8c]
     aec:      	eor	w0, w1, w0
     af0:      	str	w0, [sp, #0xac]
     af4:      	ldr	w1, [sp, #0x70]
     af8:      	ldr	w0, [sp, #0x90]
     afc:      	eor	w0, w1, w0
     b00:      	str	w0, [sp, #0xb0]
     b04:      	ldr	w1, [sp, #0x74]
     b08:      	ldr	w0, [sp, #0x94]
     b0c:      	eor	w0, w1, w0
     b10:      	str	w0, [sp, #0xb4]
     b14:      	ldr	w1, [sp, #0x78]
     b18:      	ldr	w0, [sp, #0x98]
     b1c:      	eor	w0, w1, w0
     b20:      	str	w0, [sp, #0xb8]
     b24:      	ldr	w0, [sp, #0x9c]
     b28:      	and	w0, w0, #0x1
     b2c:      	str	w0, [sp, #0xbc]
     b30:      	str	wzr, [sp, #0xc0]
     b34:      	str	wzr, [sp, #0xc4]
     b38:      	str	wzr, [sp, #0xc8]
     b3c:      	str	wzr, [sp, #0xcc]
     b40:      	str	wzr, [sp, #0xd0]
     b44:      	str	wzr, [sp, #0xd4]
     b48:      	str	wzr, [sp, #0xd8]
     b4c:      	ldr	w0, [sp, #0xbc]
     b50:      	neg	w0, w0
     b54:      	and	w0, w0, #0xf
     b58:      	str	w0, [sp, #0xdc]
     b5c:      	ldr	w0, [sp, #0xbc]
     b60:      	cmp	w0, #0x0
     b64:      	cset	w0, ne
     b68:      	and	w0, w0, #0xff
     b6c:      	str	w0, [sp, #0xe0]
     b70:      	ldr	w1, [sp, #0xc0]
     b74:      	ldr	w0, [sp, #0xe0]
     b78:      	add	w0, w1, w0
     b7c:      	str	w0, [sp, #0xe4]
     b80:      	ldr	w0, [sp, #0xe4]
     b84:      	neg	w0, w0
     b88:      	and	w0, w0, #0xf
     b8c:      	str	w0, [sp, #0xe8]
     b90:      	ldr	w0, [sp, #0xe4]
     b94:      	cmp	w0, #0x0
     b98:      	cset	w0, ne
     b9c:      	and	w0, w0, #0xff
     ba0:      	str	w0, [sp, #0xec]
     ba4:      	ldr	w1, [sp, #0xc4]
     ba8:      	ldr	w0, [sp, #0xec]
     bac:      	add	w0, w1, w0
     bb0:      	str	w0, [sp, #0xf0]
     bb4:      	ldr	w0, [sp, #0xf0]
     bb8:      	neg	w0, w0
     bbc:      	and	w0, w0, #0xf
     bc0:      	str	w0, [sp, #0xf4]
     bc4:      	ldr	w0, [sp, #0xf0]
     bc8:      	cmp	w0, #0x0
     bcc:      	cset	w0, ne
     bd0:      	and	w0, w0, #0xff
     bd4:      	str	w0, [sp, #0xf8]
     bd8:      	ldr	w1, [sp, #0xc8]
     bdc:      	ldr	w0, [sp, #0xf8]
     be0:      	add	w0, w1, w0
     be4:      	str	w0, [sp, #0xfc]
     be8:      	ldr	w0, [sp, #0xfc]
     bec:      	neg	w0, w0
     bf0:      	and	w0, w0, #0xf
     bf4:      	str	w0, [sp, #0x100]
     bf8:      	ldr	w0, [sp, #0xfc]
     bfc:      	cmp	w0, #0x0
     c00:      	cset	w0, ne
     c04:      	and	w0, w0, #0xff
     c08:      	str	w0, [sp, #0x104]
     c0c:      	ldr	w1, [sp, #0xcc]
     c10:      	ldr	w0, [sp, #0x104]
     c14:      	add	w0, w1, w0
     c18:      	str	w0, [sp, #0x108]
     c1c:      	ldr	w0, [sp, #0x108]
     c20:      	neg	w0, w0
     c24:      	and	w0, w0, #0xf
     c28:      	str	w0, [sp, #0x10c]
     c2c:      	ldr	w0, [sp, #0x108]
     c30:      	cmp	w0, #0x0
     c34:      	cset	w0, ne
     c38:      	and	w0, w0, #0xff
     c3c:      	str	w0, [sp, #0x110]
     c40:      	ldr	w1, [sp, #0xd0]
     c44:      	ldr	w0, [sp, #0x110]
     c48:      	add	w0, w1, w0
     c4c:      	str	w0, [sp, #0x114]
     c50:      	ldr	w0, [sp, #0x114]
     c54:      	neg	w0, w0
     c58:      	and	w0, w0, #0xf
     c5c:      	str	w0, [sp, #0x118]
     c60:      	ldr	w0, [sp, #0x114]
     c64:      	cmp	w0, #0x0
     c68:      	cset	w0, ne
     c6c:      	and	w0, w0, #0xff
     c70:      	str	w0, [sp, #0x11c]
     c74:      	ldr	w1, [sp, #0xd4]
     c78:      	ldr	w0, [sp, #0x11c]
     c7c:      	add	w0, w1, w0
     c80:      	str	w0, [sp, #0x120]
     c84:      	ldr	w0, [sp, #0x120]
     c88:      	neg	w0, w0
     c8c:      	and	w0, w0, #0xf
     c90:      	str	w0, [sp, #0x124]
     c94:      	ldr	w0, [sp, #0x120]
     c98:      	cmp	w0, #0x0
     c9c:      	cset	w0, ne
     ca0:      	and	w0, w0, #0xff
     ca4:      	str	w0, [sp, #0x128]
     ca8:      	ldr	w1, [sp, #0xd8]
     cac:      	ldr	w0, [sp, #0x128]
     cb0:      	add	w0, w1, w0
     cb4:      	str	w0, [sp, #0x12c]
     cb8:      	ldr	w0, [sp, #0x12c]
     cbc:      	neg	w0, w0
     cc0:      	and	w0, w0, #0xf
     cc4:      	str	w0, [sp, #0x130]
     cc8:      	ldr	w0, [sp, #0x9c]
     ccc:      	lsr	w1, w0, #1
     cd0:      	ldr	w0, [sp, #0xa0]
     cd4:      	lsl	w0, w0, #3
     cd8:      	orr	w0, w1, w0
     cdc:      	and	w0, w0, #0xf
     ce0:      	str	w0, [sp, #0x134]
     ce4:      	ldr	w0, [sp, #0xa0]
     ce8:      	lsr	w1, w0, #1
     cec:      	ldr	w0, [sp, #0xa4]
     cf0:      	lsl	w0, w0, #3
     cf4:      	orr	w0, w1, w0
     cf8:      	and	w0, w0, #0xf
     cfc:      	str	w0, [sp, #0x138]
     d00:      	ldr	w0, [sp, #0xa4]
     d04:      	lsr	w1, w0, #1
     d08:      	ldr	w0, [sp, #0xa8]
     d0c:      	lsl	w0, w0, #3
     d10:      	orr	w0, w1, w0
     d14:      	and	w0, w0, #0xf
     d18:      	str	w0, [sp, #0x13c]
     d1c:      	ldr	w0, [sp, #0xa8]
     d20:      	lsr	w1, w0, #1
     d24:      	ldr	w0, [sp, #0xac]
     d28:      	lsl	w0, w0, #3
     d2c:      	orr	w0, w1, w0
     d30:      	and	w0, w0, #0xf
     d34:      	str	w0, [sp, #0x140]
     d38:      	ldr	w0, [sp, #0xac]
     d3c:      	lsr	w1, w0, #1
     d40:      	ldr	w0, [sp, #0xb0]
     d44:      	lsl	w0, w0, #3
     d48:      	orr	w0, w1, w0
     d4c:      	and	w0, w0, #0xf
     d50:      	str	w0, [sp, #0x144]
     d54:      	ldr	w0, [sp, #0xb0]
     d58:      	lsr	w1, w0, #1
     d5c:      	ldr	w0, [sp, #0xb4]
     d60:      	lsl	w0, w0, #3
     d64:      	orr	w0, w1, w0
     d68:      	and	w0, w0, #0xf
     d6c:      	str	w0, [sp, #0x148]
     d70:      	ldr	w0, [sp, #0xb4]
     d74:      	lsr	w1, w0, #1
     d78:      	ldr	w0, [sp, #0xb8]
     d7c:      	lsl	w0, w0, #3
     d80:      	orr	w0, w1, w0
     d84:      	and	w0, w0, #0xf
     d88:      	str	w0, [sp, #0x14c]
     d8c:      	ldr	w0, [sp, #0xb8]
     d90:      	lsr	w0, w0, #1
     d94:      	and	w0, w0, #0xf
     d98:      	str	w0, [sp, #0x150]
     d9c:      	str	wzr, [sp, #0x154]
     da0:      	ldr	w0, [sp, #0xe8]
     da4:      	and	w0, w0, #0x2
     da8:      	str	w0, [sp, #0x158]
     dac:      	ldr	w0, [sp, #0xf4]
     db0:      	and	w0, w0, #0x3
     db4:      	str	w0, [sp, #0x15c]
     db8:      	ldr	w0, [sp, #0x100]
     dbc:      	and	w0, w0, #0x8
     dc0:      	str	w0, [sp, #0x160]
     dc4:      	ldr	w0, [sp, #0x10c]
     dc8:      	and	w0, w0, #0x8
     dcc:      	str	w0, [sp, #0x164]
     dd0:      	ldr	w1, [sp, #0x118]
     dd4:      	mov	w0, #0xb                // =11
     dd8:      	and	w0, w1, w0
     ddc:      	str	w0, [sp, #0x168]
     de0:      	ldr	w1, [sp, #0x124]
     de4:      	mov	w0, #0xd                // =13
     de8:      	and	w0, w1, w0
     dec:      	str	w0, [sp, #0x16c]
     df0:      	ldr	w0, [sp, #0x130]
     df4:      	and	w0, w0, #0xe
     df8:      	str	w0, [sp, #0x170]
     dfc:      	ldr	w1, [sp, #0x134]
     e00:      	ldr	w0, [sp, #0x154]
     e04:      	eor	w0, w1, w0
     e08:      	str	w0, [sp, #0x174]
     e0c:      	ldr	w1, [sp, #0x138]
     e10:      	ldr	w0, [sp, #0x158]
     e14:      	eor	w0, w1, w0
     e18:      	str	w0, [sp, #0x178]
     e1c:      	ldr	w1, [sp, #0x13c]
     e20:      	ldr	w0, [sp, #0x15c]
     e24:      	eor	w0, w1, w0
     e28:      	str	w0, [sp, #0x17c]
     e2c:      	ldr	w1, [sp, #0x140]
     e30:      	ldr	w0, [sp, #0x160]
     e34:      	eor	w0, w1, w0
     e38:      	str	w0, [sp, #0x180]
     e3c:      	ldr	w1, [sp, #0x144]
     e40:      	ldr	w0, [sp, #0x164]
     e44:      	eor	w0, w1, w0
     e48:      	str	w0, [sp, #0x184]
     e4c:      	ldr	w1, [sp, #0x148]
     e50:      	ldr	w0, [sp, #0x168]
     e54:      	eor	w0, w1, w0
     e58:      	str	w0, [sp, #0x188]
     e5c:      	ldr	w1, [sp, #0x14c]
     e60:      	ldr	w0, [sp, #0x16c]
     e64:      	eor	w0, w1, w0
     e68:      	str	w0, [sp, #0x18c]
     e6c:      	ldr	w1, [sp, #0x150]
     e70:      	ldr	w0, [sp, #0x170]
     e74:      	eor	w0, w1, w0
     e78:      	str	w0, [sp, #0x190]
     e7c:      	ldr	w0, [sp, #0x174]
     e80:      	and	w0, w0, #0x1
     e84:      	str	w0, [sp, #0x194]
     e88:      	str	wzr, [sp, #0x198]
     e8c:      	str	wzr, [sp, #0x19c]
     e90:      	str	wzr, [sp, #0x1a0]
     e94:      	str	wzr, [sp, #0x1a4]
     e98:      	str	wzr, [sp, #0x1a8]
     e9c:      	str	wzr, [sp, #0x1ac]
     ea0:      	str	wzr, [sp, #0x1b0]
     ea4:      	ldr	w0, [sp, #0x194]
     ea8:      	neg	w0, w0
     eac:      	and	w0, w0, #0xf
     eb0:      	str	w0, [sp, #0x1b4]
     eb4:      	ldr	w0, [sp, #0x194]
     eb8:      	cmp	w0, #0x0
     ebc:      	cset	w0, ne
     ec0:      	and	w0, w0, #0xff
     ec4:      	str	w0, [sp, #0x1b8]
     ec8:      	ldr	w1, [sp, #0x198]
     ecc:      	ldr	w0, [sp, #0x1b8]
     ed0:      	add	w0, w1, w0
     ed4:      	str	w0, [sp, #0x1bc]
     ed8:      	ldr	w0, [sp, #0x1bc]
     edc:      	neg	w0, w0
     ee0:      	and	w0, w0, #0xf
     ee4:      	str	w0, [sp, #0x1c0]
     ee8:      	ldr	w0, [sp, #0x1bc]
     eec:      	cmp	w0, #0x0
     ef0:      	cset	w0, ne
     ef4:      	and	w0, w0, #0xff
     ef8:      	str	w0, [sp, #0x1c4]
     efc:      	ldr	w1, [sp, #0x19c]
     f00:      	ldr	w0, [sp, #0x1c4]
     f04:      	add	w0, w1, w0
     f08:      	str	w0, [sp, #0x1c8]
     f0c:      	ldr	w0, [sp, #0x1c8]
     f10:      	neg	w0, w0
     f14:      	and	w0, w0, #0xf
     f18:      	str	w0, [sp, #0x1cc]
     f1c:      	ldr	w0, [sp, #0x1c8]
     f20:      	cmp	w0, #0x0
     f24:      	cset	w0, ne
     f28:      	and	w0, w0, #0xff
     f2c:      	str	w0, [sp, #0x1d0]
     f30:      	ldr	w1, [sp, #0x1a0]
     f34:      	ldr	w0, [sp, #0x1d0]
     f38:      	add	w0, w1, w0
     f3c:      	str	w0, [sp, #0x1d4]
     f40:      	ldr	w0, [sp, #0x1d4]
     f44:      	neg	w0, w0
     f48:      	and	w0, w0, #0xf
     f4c:      	str	w0, [sp, #0x1d8]
     f50:      	ldr	w0, [sp, #0x1d4]
     f54:      	cmp	w0, #0x0
     f58:      	cset	w0, ne
     f5c:      	and	w0, w0, #0xff
     f60:      	str	w0, [sp, #0x1dc]
     f64:      	ldr	w1, [sp, #0x1a4]
     f68:      	ldr	w0, [sp, #0x1dc]
     f6c:      	add	w0, w1, w0
     f70:      	str	w0, [sp, #0x1e0]
     f74:      	ldr	w0, [sp, #0x1e0]
     f78:      	neg	w0, w0
     f7c:      	and	w0, w0, #0xf
     f80:      	str	w0, [sp, #0x1e4]
     f84:      	ldr	w0, [sp, #0x1e0]
     f88:      	cmp	w0, #0x0
     f8c:      	cset	w0, ne
     f90:      	and	w0, w0, #0xff
     f94:      	str	w0, [sp, #0x1e8]
     f98:      	ldr	w1, [sp, #0x1a8]
     f9c:      	ldr	w0, [sp, #0x1e8]
     fa0:      	add	w0, w1, w0
     fa4:      	str	w0, [sp, #0x1ec]
     fa8:      	ldr	w0, [sp, #0x1ec]
     fac:      	neg	w0, w0
     fb0:      	and	w0, w0, #0xf
     fb4:      	str	w0, [sp, #0x1f0]
     fb8:      	ldr	w0, [sp, #0x1ec]
     fbc:      	cmp	w0, #0x0
     fc0:      	cset	w0, ne
     fc4:      	and	w0, w0, #0xff
     fc8:      	str	w0, [sp, #0x1f4]
     fcc:      	ldr	w1, [sp, #0x1ac]
     fd0:      	ldr	w0, [sp, #0x1f4]
     fd4:      	add	w0, w1, w0
     fd8:      	str	w0, [sp, #0x1f8]
     fdc:      	ldr	w0, [sp, #0x1f8]
     fe0:      	neg	w0, w0
     fe4:      	and	w0, w0, #0xf
     fe8:      	str	w0, [sp, #0x1fc]
     fec:      	ldr	w0, [sp, #0x1f8]
     ff0:      	cmp	w0, #0x0
     ff4:      	cset	w0, ne
     ff8:      	and	w0, w0, #0xff
     ffc:      	str	w0, [sp, #0x200]
    1000:      	ldr	w1, [sp, #0x1b0]
    1004:      	ldr	w0, [sp, #0x200]
    1008:      	add	w0, w1, w0
    100c:      	str	w0, [sp, #0x204]
    1010:      	ldr	w0, [sp, #0x204]
    1014:      	neg	w0, w0
    1018:      	and	w0, w0, #0xf
    101c:      	str	w0, [sp, #0x208]
    1020:      	ldr	w0, [sp, #0x174]
    1024:      	lsr	w1, w0, #1
    1028:      	ldr	w0, [sp, #0x178]
    102c:      	lsl	w0, w0, #3
    1030:      	orr	w0, w1, w0
    1034:      	and	w0, w0, #0xf
    1038:      	str	w0, [sp, #0x20c]
    103c:      	ldr	w0, [sp, #0x178]
    1040:      	lsr	w1, w0, #1
    1044:      	ldr	w0, [sp, #0x17c]
    1048:      	lsl	w0, w0, #3
    104c:      	orr	w0, w1, w0
    1050:      	and	w0, w0, #0xf
    1054:      	str	w0, [sp, #0x210]
    1058:      	ldr	w0, [sp, #0x17c]
    105c:      	lsr	w1, w0, #1
    1060:      	ldr	w0, [sp, #0x180]
    1064:      	lsl	w0, w0, #3
    1068:      	orr	w0, w1, w0
    106c:      	and	w0, w0, #0xf
    1070:      	str	w0, [sp, #0x214]
    1074:      	ldr	w0, [sp, #0x180]
    1078:      	lsr	w1, w0, #1
    107c:      	ldr	w0, [sp, #0x184]
    1080:      	lsl	w0, w0, #3
    1084:      	orr	w0, w1, w0
    1088:      	and	w0, w0, #0xf
    108c:      	str	w0, [sp, #0x218]
    1090:      	ldr	w0, [sp, #0x184]
    1094:      	lsr	w1, w0, #1
    1098:      	ldr	w0, [sp, #0x188]
    109c:      	lsl	w0, w0, #3
    10a0:      	orr	w0, w1, w0
    10a4:      	and	w0, w0, #0xf
    10a8:      	str	w0, [sp, #0x21c]
    10ac:      	ldr	w0, [sp, #0x188]
    10b0:      	lsr	w1, w0, #1
    10b4:      	ldr	w0, [sp, #0x18c]
    10b8:      	lsl	w0, w0, #3
    10bc:      	orr	w0, w1, w0
    10c0:      	and	w0, w0, #0xf
    10c4:      	str	w0, [sp, #0x220]
    10c8:      	ldr	w0, [sp, #0x18c]
    10cc:      	lsr	w1, w0, #1
    10d0:      	ldr	w0, [sp, #0x190]
    10d4:      	lsl	w0, w0, #3
    10d8:      	orr	w0, w1, w0
    10dc:      	and	w0, w0, #0xf
    10e0:      	str	w0, [sp, #0x224]
    10e4:      	ldr	w0, [sp, #0x190]
    10e8:      	lsr	w0, w0, #1
    10ec:      	and	w0, w0, #0xf
    10f0:      	str	w0, [sp, #0x228]
    10f4:      	str	wzr, [sp, #0x22c]
    10f8:      	ldr	w0, [sp, #0x1c0]
    10fc:      	and	w0, w0, #0x2
    1100:      	str	w0, [sp, #0x230]
    1104:      	ldr	w0, [sp, #0x1cc]
    1108:      	and	w0, w0, #0x3
    110c:      	str	w0, [sp, #0x234]
    1110:      	ldr	w0, [sp, #0x1d8]
    1114:      	and	w0, w0, #0x8
    1118:      	str	w0, [sp, #0x238]
    111c:      	ldr	w0, [sp, #0x1e4]
    1120:      	and	w0, w0, #0x8
    1124:      	str	w0, [sp, #0x23c]
    1128:      	ldr	w1, [sp, #0x1f0]
    112c:      	mov	w0, #0xb                // =11
    1130:      	and	w0, w1, w0
    1134:      	str	w0, [sp, #0x240]
    1138:      	ldr	w1, [sp, #0x1fc]
    113c:      	mov	w0, #0xd                // =13
    1140:      	and	w0, w1, w0
    1144:      	str	w0, [sp, #0x244]
    1148:      	ldr	w0, [sp, #0x208]
    114c:      	and	w0, w0, #0xe
    1150:      	str	w0, [sp, #0x248]
    1154:      	ldr	w1, [sp, #0x20c]
    1158:      	ldr	w0, [sp, #0x22c]
    115c:      	eor	w0, w1, w0
    1160:      	str	w0, [sp, #0x24c]
    1164:      	ldr	w1, [sp, #0x210]
    1168:      	ldr	w0, [sp, #0x230]
    116c:      	eor	w0, w1, w0
    1170:      	str	w0, [sp, #0x250]
    1174:      	ldr	w1, [sp, #0x214]
    1178:      	ldr	w0, [sp, #0x234]
    117c:      	eor	w0, w1, w0
    1180:      	str	w0, [sp, #0x254]
    1184:      	ldr	w1, [sp, #0x218]
    1188:      	ldr	w0, [sp, #0x238]
    118c:      	eor	w0, w1, w0
    1190:      	str	w0, [sp, #0x258]
    1194:      	ldr	w1, [sp, #0x21c]
    1198:      	ldr	w0, [sp, #0x23c]
    119c:      	eor	w0, w1, w0
    11a0:      	str	w0, [sp, #0x25c]
    11a4:      	ldr	w1, [sp, #0x220]
    11a8:      	ldr	w0, [sp, #0x240]
    11ac:      	eor	w0, w1, w0
    11b0:      	str	w0, [sp, #0x260]
    11b4:      	ldr	w1, [sp, #0x224]
    11b8:      	ldr	w0, [sp, #0x244]
    11bc:      	eor	w0, w1, w0
    11c0:      	str	w0, [sp, #0x264]
    11c4:      	ldr	w1, [sp, #0x228]
    11c8:      	ldr	w0, [sp, #0x248]
    11cc:      	eor	w0, w1, w0
    11d0:      	str	w0, [sp, #0x268]
    11d4:      	ldr	w0, [sp, #0x24c]
    11d8:      	and	w0, w0, #0x1
    11dc:      	str	w0, [sp, #0x26c]
    11e0:      	str	wzr, [sp, #0x270]
    11e4:      	str	wzr, [sp, #0x274]
    11e8:      	str	wzr, [sp, #0x278]
    11ec:      	str	wzr, [sp, #0x27c]
    11f0:      	str	wzr, [sp, #0x280]
    11f4:      	str	wzr, [sp, #0x284]
    11f8:      	str	wzr, [sp, #0x288]
    11fc:      	ldr	w0, [sp, #0x26c]
    1200:      	neg	w0, w0
    1204:      	and	w0, w0, #0xf
    1208:      	str	w0, [sp, #0x28c]
    120c:      	ldr	w0, [sp, #0x26c]
    1210:      	cmp	w0, #0x0
    1214:      	cset	w0, ne
    1218:      	and	w0, w0, #0xff
    121c:      	str	w0, [sp, #0x290]
    1220:      	ldr	w1, [sp, #0x270]
    1224:      	ldr	w0, [sp, #0x290]
    1228:      	add	w0, w1, w0
    122c:      	str	w0, [sp, #0x294]
    1230:      	ldr	w0, [sp, #0x294]
    1234:      	neg	w0, w0
    1238:      	and	w0, w0, #0xf
    123c:      	str	w0, [sp, #0x298]
    1240:      	ldr	w0, [sp, #0x294]
    1244:      	cmp	w0, #0x0
    1248:      	cset	w0, ne
    124c:      	and	w0, w0, #0xff
    1250:      	str	w0, [sp, #0x29c]
    1254:      	ldr	w1, [sp, #0x274]
    1258:      	ldr	w0, [sp, #0x29c]
    125c:      	add	w0, w1, w0
    1260:      	str	w0, [sp, #0x2a0]
    1264:      	ldr	w0, [sp, #0x2a0]
    1268:      	neg	w0, w0
    126c:      	and	w0, w0, #0xf
    1270:      	str	w0, [sp, #0x2a4]
    1274:      	ldr	w0, [sp, #0x2a0]
    1278:      	cmp	w0, #0x0
    127c:      	cset	w0, ne
    1280:      	and	w0, w0, #0xff
    1284:      	str	w0, [sp, #0x2a8]
    1288:      	ldr	w1, [sp, #0x278]
    128c:      	ldr	w0, [sp, #0x2a8]
    1290:      	add	w0, w1, w0
    1294:      	str	w0, [sp, #0x2ac]
    1298:      	ldr	w0, [sp, #0x2ac]
    129c:      	neg	w0, w0
    12a0:      	and	w0, w0, #0xf
    12a4:      	str	w0, [sp, #0x2b0]
    12a8:      	ldr	w0, [sp, #0x2ac]
    12ac:      	cmp	w0, #0x0
    12b0:      	cset	w0, ne
    12b4:      	and	w0, w0, #0xff
    12b8:      	str	w0, [sp, #0x2b4]
    12bc:      	ldr	w1, [sp, #0x27c]
    12c0:      	ldr	w0, [sp, #0x2b4]
    12c4:      	add	w0, w1, w0
    12c8:      	str	w0, [sp, #0x2b8]
    12cc:      	ldr	w0, [sp, #0x2b8]
    12d0:      	neg	w0, w0
    12d4:      	and	w0, w0, #0xf
    12d8:      	str	w0, [sp, #0x2bc]
    12dc:      	ldr	w0, [sp, #0x2b8]
    12e0:      	cmp	w0, #0x0
    12e4:      	cset	w0, ne
    12e8:      	and	w0, w0, #0xff
    12ec:      	str	w0, [sp, #0x2c0]
    12f0:      	ldr	w1, [sp, #0x280]
    12f4:      	ldr	w0, [sp, #0x2c0]
    12f8:      	add	w0, w1, w0
    12fc:      	str	w0, [sp, #0x2c4]
    1300:      	ldr	w0, [sp, #0x2c4]
    1304:      	neg	w0, w0
    1308:      	and	w0, w0, #0xf
    130c:      	str	w0, [sp, #0x2c8]
    1310:      	ldr	w0, [sp, #0x2c4]
    1314:      	cmp	w0, #0x0
    1318:      	cset	w0, ne
    131c:      	and	w0, w0, #0xff
    1320:      	str	w0, [sp, #0x2cc]
    1324:      	ldr	w1, [sp, #0x284]
    1328:      	ldr	w0, [sp, #0x2cc]
    132c:      	add	w0, w1, w0
    1330:      	str	w0, [sp, #0x2d0]
    1334:      	ldr	w0, [sp, #0x2d0]
    1338:      	neg	w0, w0
    133c:      	and	w0, w0, #0xf
    1340:      	str	w0, [sp, #0x2d4]
    1344:      	ldr	w0, [sp, #0x2d0]
    1348:      	cmp	w0, #0x0
    134c:      	cset	w0, ne
    1350:      	and	w0, w0, #0xff
    1354:      	str	w0, [sp, #0x2d8]
    1358:      	ldr	w1, [sp, #0x288]
    135c:      	ldr	w0, [sp, #0x2d8]
    1360:      	add	w0, w1, w0
    1364:      	str	w0, [sp, #0x2dc]
    1368:      	ldr	w0, [sp, #0x2dc]
    136c:      	neg	w0, w0
    1370:      	and	w0, w0, #0xf
    1374:      	str	w0, [sp, #0x2e0]
    1378:      	ldr	w0, [sp, #0x24c]
    137c:      	lsr	w1, w0, #1
    1380:      	ldr	w0, [sp, #0x250]
    1384:      	lsl	w0, w0, #3
    1388:      	orr	w0, w1, w0
    138c:      	and	w0, w0, #0xf
    1390:      	str	w0, [sp, #0x2e4]
    1394:      	ldr	w0, [sp, #0x250]
    1398:      	lsr	w1, w0, #1
    139c:      	ldr	w0, [sp, #0x254]
    13a0:      	lsl	w0, w0, #3
    13a4:      	orr	w0, w1, w0
    13a8:      	and	w0, w0, #0xf
    13ac:      	str	w0, [sp, #0x2e8]
    13b0:      	ldr	w0, [sp, #0x254]
    13b4:      	lsr	w1, w0, #1
    13b8:      	ldr	w0, [sp, #0x258]
    13bc:      	lsl	w0, w0, #3
    13c0:      	orr	w0, w1, w0
    13c4:      	and	w0, w0, #0xf
    13c8:      	str	w0, [sp, #0x2ec]
    13cc:      	ldr	w0, [sp, #0x258]
    13d0:      	lsr	w1, w0, #1
    13d4:      	ldr	w0, [sp, #0x25c]
    13d8:      	lsl	w0, w0, #3
    13dc:      	orr	w0, w1, w0
    13e0:      	and	w0, w0, #0xf
    13e4:      	str	w0, [sp, #0x2f0]
    13e8:      	ldr	w0, [sp, #0x25c]
    13ec:      	lsr	w1, w0, #1
    13f0:      	ldr	w0, [sp, #0x260]
    13f4:      	lsl	w0, w0, #3
    13f8:      	orr	w0, w1, w0
    13fc:      	and	w0, w0, #0xf
    1400:      	str	w0, [sp, #0x2f4]
    1404:      	ldr	w0, [sp, #0x260]
    1408:      	lsr	w1, w0, #1
    140c:      	ldr	w0, [sp, #0x264]
    1410:      	lsl	w0, w0, #3
    1414:      	orr	w0, w1, w0
    1418:      	and	w0, w0, #0xf
    141c:      	str	w0, [sp, #0x2f8]
    1420:      	ldr	w0, [sp, #0x264]
    1424:      	lsr	w1, w0, #1
    1428:      	ldr	w0, [sp, #0x268]
    142c:      	lsl	w0, w0, #3
    1430:      	orr	w0, w1, w0
    1434:      	and	w0, w0, #0xf
    1438:      	str	w0, [sp, #0x2fc]
    143c:      	ldr	w0, [sp, #0x268]
    1440:      	lsr	w0, w0, #1
    1444:      	and	w0, w0, #0xf
    1448:      	str	w0, [sp, #0x300]
    144c:      	str	wzr, [sp, #0x304]
    1450:      	ldr	w0, [sp, #0x298]
    1454:      	and	w0, w0, #0x2
    1458:      	str	w0, [sp, #0x308]
    145c:      	ldr	w0, [sp, #0x2a4]
    1460:      	and	w0, w0, #0x3
    1464:      	str	w0, [sp, #0x30c]
    1468:      	ldr	w0, [sp, #0x2b0]
    146c:      	and	w0, w0, #0x8
    1470:      	str	w0, [sp, #0x310]
    1474:      	ldr	w0, [sp, #0x2bc]
    1478:      	and	w0, w0, #0x8
    147c:      	str	w0, [sp, #0x314]
    1480:      	ldr	w1, [sp, #0x2c8]
    1484:      	mov	w0, #0xb                // =11
    1488:      	and	w0, w1, w0
    148c:      	str	w0, [sp, #0x318]
    1490:      	ldr	w1, [sp, #0x2d4]
    1494:      	mov	w0, #0xd                // =13
    1498:      	and	w0, w1, w0
    149c:      	str	w0, [sp, #0x31c]
    14a0:      	ldr	w0, [sp, #0x2e0]
    14a4:      	and	w0, w0, #0xe
    14a8:      	str	w0, [sp, #0x320]
    14ac:      	ldr	w1, [sp, #0x2e4]
    14b0:      	ldr	w0, [sp, #0x304]
    14b4:      	eor	w0, w1, w0
    14b8:      	str	w0, [sp, #0x324]
    14bc:      	ldr	w1, [sp, #0x2e8]
    14c0:      	ldr	w0, [sp, #0x308]
    14c4:      	eor	w0, w1, w0
    14c8:      	str	w0, [sp, #0x328]
    14cc:      	ldr	w1, [sp, #0x2ec]
    14d0:      	ldr	w0, [sp, #0x30c]
    14d4:      	eor	w0, w1, w0
    14d8:      	str	w0, [sp, #0x32c]
    14dc:      	ldr	w1, [sp, #0x2f0]
    14e0:      	ldr	w0, [sp, #0x310]
    14e4:      	eor	w0, w1, w0
    14e8:      	str	w0, [sp, #0x330]
    14ec:      	ldr	w1, [sp, #0x2f4]
    14f0:      	ldr	w0, [sp, #0x314]
    14f4:      	eor	w0, w1, w0
    14f8:      	str	w0, [sp, #0x334]
    14fc:      	ldr	w1, [sp, #0x2f8]
    1500:      	ldr	w0, [sp, #0x318]
    1504:      	eor	w0, w1, w0
    1508:      	str	w0, [sp, #0x338]
    150c:      	ldr	w1, [sp, #0x2fc]
    1510:      	ldr	w0, [sp, #0x31c]
    1514:      	eor	w0, w1, w0
    1518:      	str	w0, [sp, #0x33c]
    151c:      	ldr	w1, [sp, #0x300]
    1520:      	ldr	w0, [sp, #0x320]
    1524:      	eor	w0, w1, w0
    1528:      	str	w0, [sp, #0x340]
    152c:      	ldr	w0, [sp, #0x324]
    1530:      	and	w0, w0, #0x1
    1534:      	str	w0, [sp, #0x344]
    1538:      	str	wzr, [sp, #0x348]
    153c:      	str	wzr, [sp, #0x34c]
    1540:      	str	wzr, [sp, #0x350]
    1544:      	str	wzr, [sp, #0x354]
    1548:      	str	wzr, [sp, #0x358]
    154c:      	str	wzr, [sp, #0x35c]
    1550:      	str	wzr, [sp, #0x360]
    1554:      	ldr	w0, [sp, #0x344]
    1558:      	neg	w0, w0
    155c:      	and	w0, w0, #0xf
    1560:      	str	w0, [sp, #0x364]
    1564:      	ldr	w0, [sp, #0x344]
    1568:      	cmp	w0, #0x0
    156c:      	cset	w0, ne
    1570:      	and	w0, w0, #0xff
    1574:      	str	w0, [sp, #0x368]
    1578:      	ldr	w1, [sp, #0x348]
    157c:      	ldr	w0, [sp, #0x368]
    1580:      	add	w0, w1, w0
    1584:      	str	w0, [sp, #0x36c]
    1588:      	ldr	w0, [sp, #0x36c]
    158c:      	neg	w0, w0
    1590:      	and	w0, w0, #0xf
    1594:      	str	w0, [sp, #0x370]
    1598:      	ldr	w0, [sp, #0x36c]
    159c:      	cmp	w0, #0x0
    15a0:      	cset	w0, ne
    15a4:      	and	w0, w0, #0xff
    15a8:      	str	w0, [sp, #0x374]
    15ac:      	ldr	w1, [sp, #0x34c]
    15b0:      	ldr	w0, [sp, #0x374]
    15b4:      	add	w0, w1, w0
    15b8:      	str	w0, [sp, #0x378]
    15bc:      	ldr	w0, [sp, #0x378]
    15c0:      	neg	w0, w0
    15c4:      	and	w0, w0, #0xf
    15c8:      	str	w0, [sp, #0x37c]
    15cc:      	ldr	w0, [sp, #0x378]
    15d0:      	cmp	w0, #0x0
    15d4:      	cset	w0, ne
    15d8:      	and	w0, w0, #0xff
    15dc:      	str	w0, [sp, #0x380]
    15e0:      	ldr	w1, [sp, #0x350]
    15e4:      	ldr	w0, [sp, #0x380]
    15e8:      	add	w0, w1, w0
    15ec:      	str	w0, [sp, #0x384]
    15f0:      	ldr	w0, [sp, #0x384]
    15f4:      	neg	w0, w0
    15f8:      	and	w0, w0, #0xf
    15fc:      	str	w0, [sp, #0x388]
    1600:      	ldr	w0, [sp, #0x384]
    1604:      	cmp	w0, #0x0
    1608:      	cset	w0, ne
    160c:      	and	w0, w0, #0xff
    1610:      	str	w0, [sp, #0x38c]
    1614:      	ldr	w1, [sp, #0x354]
    1618:      	ldr	w0, [sp, #0x38c]
    161c:      	add	w0, w1, w0
    1620:      	str	w0, [sp, #0x390]
    1624:      	ldr	w0, [sp, #0x390]
    1628:      	neg	w0, w0
    162c:      	and	w0, w0, #0xf
    1630:      	str	w0, [sp, #0x394]
    1634:      	ldr	w0, [sp, #0x390]
    1638:      	cmp	w0, #0x0
    163c:      	cset	w0, ne
    1640:      	and	w0, w0, #0xff
    1644:      	str	w0, [sp, #0x398]
    1648:      	ldr	w1, [sp, #0x358]
    164c:      	ldr	w0, [sp, #0x398]
    1650:      	add	w0, w1, w0
    1654:      	str	w0, [sp, #0x39c]
    1658:      	ldr	w0, [sp, #0x39c]
    165c:      	neg	w0, w0
    1660:      	and	w0, w0, #0xf
    1664:      	str	w0, [sp, #0x3a0]
    1668:      	ldr	w0, [sp, #0x39c]
    166c:      	cmp	w0, #0x0
    1670:      	cset	w0, ne
    1674:      	and	w0, w0, #0xff
    1678:      	str	w0, [sp, #0x3a4]
    167c:      	ldr	w1, [sp, #0x35c]
    1680:      	ldr	w0, [sp, #0x3a4]
    1684:      	add	w0, w1, w0
    1688:      	str	w0, [sp, #0x3a8]
    168c:      	ldr	w0, [sp, #0x3a8]
    1690:      	neg	w0, w0
    1694:      	and	w0, w0, #0xf
    1698:      	str	w0, [sp, #0x3ac]
    169c:      	ldr	w0, [sp, #0x3a8]
    16a0:      	cmp	w0, #0x0
    16a4:      	cset	w0, ne
    16a8:      	and	w0, w0, #0xff
    16ac:      	str	w0, [sp, #0x3b0]
    16b0:      	ldr	w1, [sp, #0x360]
    16b4:      	ldr	w0, [sp, #0x3b0]
    16b8:      	add	w0, w1, w0
    16bc:      	str	w0, [sp, #0x3b4]
    16c0:      	ldr	w0, [sp, #0x3b4]
    16c4:      	neg	w0, w0
    16c8:      	and	w0, w0, #0xf
    16cc:      	str	w0, [sp, #0x3b8]
    16d0:      	ldr	w0, [sp, #0x324]
    16d4:      	lsr	w1, w0, #1
    16d8:      	ldr	w0, [sp, #0x328]
    16dc:      	lsl	w0, w0, #3
    16e0:      	orr	w0, w1, w0
    16e4:      	and	w0, w0, #0xf
    16e8:      	str	w0, [sp, #0x3bc]
    16ec:      	ldr	w0, [sp, #0x328]
    16f0:      	lsr	w1, w0, #1
    16f4:      	ldr	w0, [sp, #0x32c]
    16f8:      	lsl	w0, w0, #3
    16fc:      	orr	w0, w1, w0
    1700:      	and	w0, w0, #0xf
    1704:      	str	w0, [sp, #0x3c0]
    1708:      	ldr	w0, [sp, #0x32c]
    170c:      	lsr	w1, w0, #1
    1710:      	ldr	w0, [sp, #0x330]
    1714:      	lsl	w0, w0, #3
    1718:      	orr	w0, w1, w0
    171c:      	and	w0, w0, #0xf
    1720:      	str	w0, [sp, #0x3c4]
    1724:      	ldr	w0, [sp, #0x330]
    1728:      	lsr	w1, w0, #1
    172c:      	ldr	w0, [sp, #0x334]
    1730:      	lsl	w0, w0, #3
    1734:      	orr	w0, w1, w0
    1738:      	and	w0, w0, #0xf
    173c:      	str	w0, [sp, #0x3c8]
    1740:      	ldr	w0, [sp, #0x334]
    1744:      	lsr	w1, w0, #1
    1748:      	ldr	w0, [sp, #0x338]
    174c:      	lsl	w0, w0, #3
    1750:      	orr	w0, w1, w0
    1754:      	and	w0, w0, #0xf
    1758:      	str	w0, [sp, #0x3cc]
    175c:      	ldr	w0, [sp, #0x338]
    1760:      	lsr	w1, w0, #1
    1764:      	ldr	w0, [sp, #0x33c]
    1768:      	lsl	w0, w0, #3
    176c:      	orr	w0, w1, w0
    1770:      	and	w0, w0, #0xf
    1774:      	str	w0, [sp, #0x3d0]
    1778:      	ldr	w0, [sp, #0x33c]
    177c:      	lsr	w1, w0, #1
    1780:      	ldr	w0, [sp, #0x340]
    1784:      	lsl	w0, w0, #3
    1788:      	orr	w0, w1, w0
    178c:      	and	w0, w0, #0xf
    1790:      	str	w0, [sp, #0x3d4]
    1794:      	ldr	w0, [sp, #0x340]
    1798:      	lsr	w0, w0, #1
    179c:      	and	w0, w0, #0xf
    17a0:      	str	w0, [sp, #0x3d8]
    17a4:      	str	wzr, [sp, #0x3dc]
    17a8:      	ldr	w0, [sp, #0x370]
    17ac:      	and	w0, w0, #0x2
    17b0:      	str	w0, [sp, #0x3e0]
    17b4:      	ldr	w0, [sp, #0x37c]
    17b8:      	and	w0, w0, #0x3
    17bc:      	str	w0, [sp, #0x3e4]
    17c0:      	ldr	w0, [sp, #0x388]
    17c4:      	and	w0, w0, #0x8
    17c8:      	str	w0, [sp, #0x3e8]
    17cc:      	ldr	w0, [sp, #0x394]
    17d0:      	and	w0, w0, #0x8
    17d4:      	str	w0, [sp, #0x3ec]
    17d8:      	ldr	w1, [sp, #0x3a0]
    17dc:      	mov	w0, #0xb                // =11
    17e0:      	and	w0, w1, w0
    17e4:      	str	w0, [sp, #0x3f0]
    17e8:      	ldr	w1, [sp, #0x3ac]
    17ec:      	mov	w0, #0xd                // =13
    17f0:      	and	w0, w1, w0
    17f4:      	str	w0, [sp, #0x3f4]
    17f8:      	ldr	w0, [sp, #0x3b8]
    17fc:      	and	w0, w0, #0xe
    1800:      	str	w0, [sp, #0x3f8]
    1804:      	ldr	w1, [sp, #0x3bc]
    1808:      	ldr	w0, [sp, #0x3dc]
    180c:      	eor	w0, w1, w0
    1810:      	str	w0, [sp, #0x3fc]
    1814:      	ldr	w1, [sp, #0x3c0]
    1818:      	ldr	w0, [sp, #0x3e0]
    181c:      	eor	w0, w1, w0
    1820:      	str	w0, [sp, #0x400]
    1824:      	ldr	w1, [sp, #0x3c4]
    1828:      	ldr	w0, [sp, #0x3e4]
    182c:      	eor	w0, w1, w0
    1830:      	str	w0, [sp, #0x404]
    1834:      	ldr	w1, [sp, #0x3c8]
    1838:      	ldr	w0, [sp, #0x3e8]
    183c:      	eor	w0, w1, w0
    1840:      	str	w0, [sp, #0x408]
    1844:      	ldr	w1, [sp, #0x3cc]
    1848:      	ldr	w0, [sp, #0x3ec]
    184c:      	eor	w0, w1, w0
    1850:      	str	w0, [sp, #0x40c]
    1854:      	ldr	w1, [sp, #0x3d0]
    1858:      	ldr	w0, [sp, #0x3f0]
    185c:      	eor	w0, w1, w0
    1860:      	str	w0, [sp, #0x410]
    1864:      	ldr	w1, [sp, #0x3d4]
    1868:      	ldr	w0, [sp, #0x3f4]
    186c:      	eor	w0, w1, w0
    1870:      	str	w0, [sp, #0x414]
    1874:      	ldr	w1, [sp, #0x3d8]
    1878:      	ldr	w0, [sp, #0x3f8]
    187c:      	eor	w0, w1, w0
    1880:      	str	w0, [sp, #0x418]
    1884:      	ldr	w0, [sp, #0x3fc]
    1888:      	and	w0, w0, #0x1
    188c:      	str	w0, [sp, #0x41c]
    1890:      	str	wzr, [sp, #0x420]
    1894:      	str	wzr, [sp, #0x424]
    1898:      	str	wzr, [sp, #0x428]
    189c:      	str	wzr, [sp, #0x42c]
    18a0:      	str	wzr, [sp, #0x430]
    18a4:      	str	wzr, [sp, #0x434]
    18a8:      	str	wzr, [sp, #0x438]
    18ac:      	ldr	w0, [sp, #0x41c]
    18b0:      	neg	w0, w0
    18b4:      	and	w0, w0, #0xf
    18b8:      	str	w0, [sp, #0x43c]
    18bc:      	ldr	w0, [sp, #0x41c]
    18c0:      	cmp	w0, #0x0
    18c4:      	cset	w0, ne
    18c8:      	and	w0, w0, #0xff
    18cc:      	str	w0, [sp, #0x440]
    18d0:      	ldr	w1, [sp, #0x420]
    18d4:      	ldr	w0, [sp, #0x440]
    18d8:      	add	w0, w1, w0
    18dc:      	str	w0, [sp, #0x444]
    18e0:      	ldr	w0, [sp, #0x444]
    18e4:      	neg	w0, w0
    18e8:      	and	w0, w0, #0xf
    18ec:      	str	w0, [sp, #0x448]
    18f0:      	ldr	w0, [sp, #0x444]
    18f4:      	cmp	w0, #0x0
    18f8:      	cset	w0, ne
    18fc:      	and	w0, w0, #0xff
    1900:      	str	w0, [sp, #0x44c]
    1904:      	ldr	w1, [sp, #0x424]
    1908:      	ldr	w0, [sp, #0x44c]
    190c:      	add	w0, w1, w0
    1910:      	str	w0, [sp, #0x450]
    1914:      	ldr	w0, [sp, #0x450]
    1918:      	neg	w0, w0
    191c:      	and	w0, w0, #0xf
    1920:      	str	w0, [sp, #0x454]
    1924:      	ldr	w0, [sp, #0x450]
    1928:      	cmp	w0, #0x0
    192c:      	cset	w0, ne
    1930:      	and	w0, w0, #0xff
    1934:      	str	w0, [sp, #0x458]
    1938:      	ldr	w1, [sp, #0x428]
    193c:      	ldr	w0, [sp, #0x458]
    1940:      	add	w0, w1, w0
    1944:      	str	w0, [sp, #0x45c]
    1948:      	ldr	w0, [sp, #0x45c]
    194c:      	neg	w0, w0
    1950:      	and	w0, w0, #0xf
    1954:      	str	w0, [sp, #0x460]
    1958:      	ldr	w0, [sp, #0x45c]
    195c:      	cmp	w0, #0x0
    1960:      	cset	w0, ne
    1964:      	and	w0, w0, #0xff
    1968:      	str	w0, [sp, #0x464]
    196c:      	ldr	w1, [sp, #0x42c]
    1970:      	ldr	w0, [sp, #0x464]
    1974:      	add	w0, w1, w0
    1978:      	str	w0, [sp, #0x468]
    197c:      	ldr	w0, [sp, #0x468]
    1980:      	neg	w0, w0
    1984:      	and	w0, w0, #0xf
    1988:      	str	w0, [sp, #0x46c]
    198c:      	ldr	w0, [sp, #0x468]
    1990:      	cmp	w0, #0x0
    1994:      	cset	w0, ne
    1998:      	and	w0, w0, #0xff
    199c:      	str	w0, [sp, #0x470]
    19a0:      	ldr	w1, [sp, #0x430]
    19a4:      	ldr	w0, [sp, #0x470]
    19a8:      	add	w0, w1, w0
    19ac:      	str	w0, [sp, #0x474]
    19b0:      	ldr	w0, [sp, #0x474]
    19b4:      	neg	w0, w0
    19b8:      	and	w0, w0, #0xf
    19bc:      	str	w0, [sp, #0x478]
    19c0:      	ldr	w0, [sp, #0x474]
    19c4:      	cmp	w0, #0x0
    19c8:      	cset	w0, ne
    19cc:      	and	w0, w0, #0xff
    19d0:      	str	w0, [sp, #0x47c]
    19d4:      	ldr	w1, [sp, #0x434]
    19d8:      	ldr	w0, [sp, #0x47c]
    19dc:      	add	w0, w1, w0
    19e0:      	str	w0, [sp, #0x480]
    19e4:      	ldr	w0, [sp, #0x480]
    19e8:      	neg	w0, w0
    19ec:      	and	w0, w0, #0xf
    19f0:      	str	w0, [sp, #0x484]
    19f4:      	ldr	w0, [sp, #0x480]
    19f8:      	cmp	w0, #0x0
    19fc:      	cset	w0, ne
    1a00:      	and	w0, w0, #0xff
    1a04:      	str	w0, [sp, #0x488]
    1a08:      	ldr	w1, [sp, #0x438]
    1a0c:      	ldr	w0, [sp, #0x488]
    1a10:      	add	w0, w1, w0
    1a14:      	str	w0, [sp, #0x48c]
    1a18:      	ldr	w0, [sp, #0x48c]
    1a1c:      	neg	w0, w0
    1a20:      	and	w0, w0, #0xf
    1a24:      	str	w0, [sp, #0x490]
    1a28:      	ldr	w0, [sp, #0x3fc]
    1a2c:      	lsr	w1, w0, #1
    1a30:      	ldr	w0, [sp, #0x400]
    1a34:      	lsl	w0, w0, #3
    1a38:      	orr	w0, w1, w0
    1a3c:      	and	w0, w0, #0xf
    1a40:      	str	w0, [sp, #0x494]
    1a44:      	ldr	w0, [sp, #0x400]
    1a48:      	lsr	w1, w0, #1
    1a4c:      	ldr	w0, [sp, #0x404]
    1a50:      	lsl	w0, w0, #3
    1a54:      	orr	w0, w1, w0
    1a58:      	and	w0, w0, #0xf
    1a5c:      	str	w0, [sp, #0x498]
    1a60:      	ldr	w0, [sp, #0x404]
    1a64:      	lsr	w1, w0, #1
    1a68:      	ldr	w0, [sp, #0x408]
    1a6c:      	lsl	w0, w0, #3
    1a70:      	orr	w0, w1, w0
    1a74:      	and	w0, w0, #0xf
    1a78:      	str	w0, [sp, #0x49c]
    1a7c:      	ldr	w0, [sp, #0x408]
    1a80:      	lsr	w1, w0, #1
    1a84:      	ldr	w0, [sp, #0x40c]
    1a88:      	lsl	w0, w0, #3
    1a8c:      	orr	w0, w1, w0
    1a90:      	and	w0, w0, #0xf
    1a94:      	str	w0, [sp, #0x4a0]
    1a98:      	ldr	w0, [sp, #0x40c]
    1a9c:      	lsr	w1, w0, #1
    1aa0:      	ldr	w0, [sp, #0x410]
    1aa4:      	lsl	w0, w0, #3
    1aa8:      	orr	w0, w1, w0
    1aac:      	and	w0, w0, #0xf
    1ab0:      	str	w0, [sp, #0x4a4]
    1ab4:      	ldr	w0, [sp, #0x410]
    1ab8:      	lsr	w1, w0, #1
    1abc:      	ldr	w0, [sp, #0x414]
    1ac0:      	lsl	w0, w0, #3
    1ac4:      	orr	w0, w1, w0
    1ac8:      	and	w0, w0, #0xf
    1acc:      	str	w0, [sp, #0x4a8]
    1ad0:      	ldr	w0, [sp, #0x414]
    1ad4:      	lsr	w1, w0, #1
    1ad8:      	ldr	w0, [sp, #0x418]
    1adc:      	lsl	w0, w0, #3
    1ae0:      	orr	w0, w1, w0
    1ae4:      	and	w0, w0, #0xf
    1ae8:      	str	w0, [sp, #0x4ac]
    1aec:      	ldr	w0, [sp, #0x418]
    1af0:      	lsr	w0, w0, #1
    1af4:      	and	w0, w0, #0xf
    1af8:      	str	w0, [sp, #0x4b0]
    1afc:      	str	wzr, [sp, #0x4b4]
    1b00:      	ldr	w0, [sp, #0x448]
    1b04:      	and	w0, w0, #0x2
    1b08:      	str	w0, [sp, #0x4b8]
    1b0c:      	ldr	w0, [sp, #0x454]
    1b10:      	and	w0, w0, #0x3
    1b14:      	str	w0, [sp, #0x4bc]
    1b18:      	ldr	w0, [sp, #0x460]
    1b1c:      	and	w0, w0, #0x8
    1b20:      	str	w0, [sp, #0x4c0]
    1b24:      	ldr	w0, [sp, #0x46c]
    1b28:      	and	w0, w0, #0x8
    1b2c:      	str	w0, [sp, #0x4c4]
    1b30:      	ldr	w1, [sp, #0x478]
    1b34:      	mov	w0, #0xb                // =11
    1b38:      	and	w0, w1, w0
    1b3c:      	str	w0, [sp, #0x4c8]
    1b40:      	ldr	w1, [sp, #0x484]
    1b44:      	mov	w0, #0xd                // =13
    1b48:      	and	w0, w1, w0
    1b4c:      	str	w0, [sp, #0x4cc]
    1b50:      	ldr	w0, [sp, #0x490]
    1b54:      	and	w0, w0, #0xe
    1b58:      	str	w0, [sp, #0x4d0]
    1b5c:      	ldr	w1, [sp, #0x494]
    1b60:      	ldr	w0, [sp, #0x4b4]
    1b64:      	eor	w0, w1, w0
    1b68:      	str	w0, [sp, #0x4d4]
    1b6c:      	ldr	w1, [sp, #0x498]
    1b70:      	ldr	w0, [sp, #0x4b8]
    1b74:      	eor	w0, w1, w0
    1b78:      	str	w0, [sp, #0x4d8]
    1b7c:      	ldr	w1, [sp, #0x49c]
    1b80:      	ldr	w0, [sp, #0x4bc]
    1b84:      	eor	w0, w1, w0
    1b88:      	str	w0, [sp, #0x4dc]
    1b8c:      	ldr	w1, [sp, #0x4a0]
    1b90:      	ldr	w0, [sp, #0x4c0]
    1b94:      	eor	w0, w1, w0
    1b98:      	str	w0, [sp, #0x4e0]
    1b9c:      	ldr	w1, [sp, #0x4a4]
    1ba0:      	ldr	w0, [sp, #0x4c4]
    1ba4:      	eor	w0, w1, w0
    1ba8:      	str	w0, [sp, #0x4e4]
    1bac:      	ldr	w1, [sp, #0x4a8]
    1bb0:      	ldr	w0, [sp, #0x4c8]
    1bb4:      	eor	w0, w1, w0
    1bb8:      	str	w0, [sp, #0x4e8]
    1bbc:      	ldr	w1, [sp, #0x4ac]
    1bc0:      	ldr	w0, [sp, #0x4cc]
    1bc4:      	eor	w0, w1, w0
    1bc8:      	str	w0, [sp, #0x4ec]
    1bcc:      	ldr	w1, [sp, #0x4b0]
    1bd0:      	ldr	w0, [sp, #0x4d0]
    1bd4:      	eor	w0, w1, w0
    1bd8:      	str	w0, [sp, #0x4f0]
    1bdc:      	ldr	w0, [sp, #0x4d4]
    1be0:      	and	w0, w0, #0x1
    1be4:      	str	w0, [sp, #0x4f4]
    1be8:      	str	wzr, [sp, #0x4f8]
    1bec:      	str	wzr, [sp, #0x4fc]
    1bf0:      	str	wzr, [sp, #0x500]
    1bf4:      	str	wzr, [sp, #0x504]
    1bf8:      	str	wzr, [sp, #0x508]
    1bfc:      	str	wzr, [sp, #0x50c]
    1c00:      	str	wzr, [sp, #0x510]
    1c04:      	ldr	w0, [sp, #0x4f4]
    1c08:      	neg	w0, w0
    1c0c:      	and	w0, w0, #0xf
    1c10:      	str	w0, [sp, #0x514]
    1c14:      	ldr	w0, [sp, #0x4f4]
    1c18:      	cmp	w0, #0x0
    1c1c:      	cset	w0, ne
    1c20:      	and	w0, w0, #0xff
    1c24:      	str	w0, [sp, #0x518]
    1c28:      	ldr	w1, [sp, #0x4f8]
    1c2c:      	ldr	w0, [sp, #0x518]
    1c30:      	add	w0, w1, w0
    1c34:      	str	w0, [sp, #0x51c]
    1c38:      	ldr	w0, [sp, #0x51c]
    1c3c:      	neg	w0, w0
    1c40:      	and	w0, w0, #0xf
    1c44:      	str	w0, [sp, #0x520]
    1c48:      	ldr	w0, [sp, #0x51c]
    1c4c:      	cmp	w0, #0x0
    1c50:      	cset	w0, ne
    1c54:      	and	w0, w0, #0xff
    1c58:      	str	w0, [sp, #0x524]
    1c5c:      	ldr	w1, [sp, #0x4fc]
    1c60:      	ldr	w0, [sp, #0x524]
    1c64:      	add	w0, w1, w0
    1c68:      	str	w0, [sp, #0x528]
    1c6c:      	ldr	w0, [sp, #0x528]
    1c70:      	neg	w0, w0
    1c74:      	and	w0, w0, #0xf
    1c78:      	str	w0, [sp, #0x52c]
    1c7c:      	ldr	w0, [sp, #0x528]
    1c80:      	cmp	w0, #0x0
    1c84:      	cset	w0, ne
    1c88:      	and	w0, w0, #0xff
    1c8c:      	str	w0, [sp, #0x530]
    1c90:      	ldr	w1, [sp, #0x500]
    1c94:      	ldr	w0, [sp, #0x530]
    1c98:      	add	w0, w1, w0
    1c9c:      	str	w0, [sp, #0x534]
    1ca0:      	ldr	w0, [sp, #0x534]
    1ca4:      	neg	w0, w0
    1ca8:      	and	w0, w0, #0xf
    1cac:      	str	w0, [sp, #0x538]
    1cb0:      	ldr	w0, [sp, #0x534]
    1cb4:      	cmp	w0, #0x0
    1cb8:      	cset	w0, ne
    1cbc:      	and	w0, w0, #0xff
    1cc0:      	str	w0, [sp, #0x53c]
    1cc4:      	ldr	w1, [sp, #0x504]
    1cc8:      	ldr	w0, [sp, #0x53c]
    1ccc:      	add	w0, w1, w0
    1cd0:      	str	w0, [sp, #0x540]
    1cd4:      	ldr	w0, [sp, #0x540]
    1cd8:      	neg	w0, w0
    1cdc:      	and	w0, w0, #0xf
    1ce0:      	str	w0, [sp, #0x544]
    1ce4:      	ldr	w0, [sp, #0x540]
    1ce8:      	cmp	w0, #0x0
    1cec:      	cset	w0, ne
    1cf0:      	and	w0, w0, #0xff
    1cf4:      	str	w0, [sp, #0x548]
    1cf8:      	ldr	w1, [sp, #0x508]
    1cfc:      	ldr	w0, [sp, #0x548]
    1d00:      	add	w0, w1, w0
    1d04:      	str	w0, [sp, #0x54c]
    1d08:      	ldr	w0, [sp, #0x54c]
    1d0c:      	neg	w0, w0
    1d10:      	and	w0, w0, #0xf
    1d14:      	str	w0, [sp, #0x550]
    1d18:      	ldr	w0, [sp, #0x54c]
    1d1c:      	cmp	w0, #0x0
    1d20:      	cset	w0, ne
    1d24:      	and	w0, w0, #0xff
    1d28:      	str	w0, [sp, #0x554]
    1d2c:      	ldr	w1, [sp, #0x50c]
    1d30:      	ldr	w0, [sp, #0x554]
    1d34:      	add	w0, w1, w0
    1d38:      	str	w0, [sp, #0x558]
    1d3c:      	ldr	w0, [sp, #0x558]
    1d40:      	neg	w0, w0
    1d44:      	and	w0, w0, #0xf
    1d48:      	str	w0, [sp, #0x55c]
    1d4c:      	ldr	w0, [sp, #0x558]
    1d50:      	cmp	w0, #0x0
    1d54:      	cset	w0, ne
    1d58:      	and	w0, w0, #0xff
    1d5c:      	str	w0, [sp, #0x560]
    1d60:      	ldr	w1, [sp, #0x510]
    1d64:      	ldr	w0, [sp, #0x560]
    1d68:      	add	w0, w1, w0
    1d6c:      	str	w0, [sp, #0x564]
    1d70:      	ldr	w0, [sp, #0x564]
    1d74:      	neg	w0, w0
    1d78:      	and	w0, w0, #0xf
    1d7c:      	str	w0, [sp, #0x568]
    1d80:      	ldr	w0, [sp, #0x4d4]
    1d84:      	lsr	w1, w0, #1
    1d88:      	ldr	w0, [sp, #0x4d8]
    1d8c:      	lsl	w0, w0, #3
    1d90:      	orr	w0, w1, w0
    1d94:      	and	w0, w0, #0xf
    1d98:      	str	w0, [sp, #0x56c]
    1d9c:      	ldr	w0, [sp, #0x4d8]
    1da0:      	lsr	w1, w0, #1
    1da4:      	ldr	w0, [sp, #0x4dc]
    1da8:      	lsl	w0, w0, #3
    1dac:      	orr	w0, w1, w0
    1db0:      	and	w0, w0, #0xf
    1db4:      	str	w0, [sp, #0x570]
    1db8:      	ldr	w0, [sp, #0x4dc]
    1dbc:      	lsr	w1, w0, #1
    1dc0:      	ldr	w0, [sp, #0x4e0]
    1dc4:      	lsl	w0, w0, #3
    1dc8:      	orr	w0, w1, w0
    1dcc:      	and	w0, w0, #0xf
    1dd0:      	str	w0, [sp, #0x574]
    1dd4:      	ldr	w0, [sp, #0x4e0]
    1dd8:      	lsr	w1, w0, #1
    1ddc:      	ldr	w0, [sp, #0x4e4]
    1de0:      	lsl	w0, w0, #3
    1de4:      	orr	w0, w1, w0
    1de8:      	and	w0, w0, #0xf
    1dec:      	str	w0, [sp, #0x578]
    1df0:      	ldr	w0, [sp, #0x4e4]
    1df4:      	lsr	w1, w0, #1
    1df8:      	ldr	w0, [sp, #0x4e8]
    1dfc:      	lsl	w0, w0, #3
    1e00:      	orr	w0, w1, w0
    1e04:      	and	w0, w0, #0xf
    1e08:      	str	w0, [sp, #0x57c]
    1e0c:      	ldr	w0, [sp, #0x4e8]
    1e10:      	lsr	w1, w0, #1
    1e14:      	ldr	w0, [sp, #0x4ec]
    1e18:      	lsl	w0, w0, #3
    1e1c:      	orr	w0, w1, w0
    1e20:      	and	w0, w0, #0xf
    1e24:      	str	w0, [sp, #0x580]
    1e28:      	ldr	w0, [sp, #0x4ec]
    1e2c:      	lsr	w1, w0, #1
    1e30:      	ldr	w0, [sp, #0x4f0]
    1e34:      	lsl	w0, w0, #3
    1e38:      	orr	w0, w1, w0
    1e3c:      	and	w0, w0, #0xf
    1e40:      	str	w0, [sp, #0x584]
    1e44:      	ldr	w0, [sp, #0x4f0]
    1e48:      	lsr	w0, w0, #1
    1e4c:      	and	w0, w0, #0xf
    1e50:      	str	w0, [sp, #0x588]
    1e54:      	str	wzr, [sp, #0x58c]
    1e58:      	ldr	w0, [sp, #0x520]
    1e5c:      	and	w0, w0, #0x2
    1e60:      	str	w0, [sp, #0x590]
    1e64:      	ldr	w0, [sp, #0x52c]
    1e68:      	and	w0, w0, #0x3
    1e6c:      	str	w0, [sp, #0x594]
    1e70:      	ldr	w0, [sp, #0x538]
    1e74:      	and	w0, w0, #0x8
    1e78:      	str	w0, [sp, #0x598]
    1e7c:      	ldr	w0, [sp, #0x544]
    1e80:      	and	w0, w0, #0x8
    1e84:      	str	w0, [sp, #0x59c]
    1e88:      	ldr	w1, [sp, #0x550]
    1e8c:      	mov	w0, #0xb                // =11
    1e90:      	and	w0, w1, w0
    1e94:      	str	w0, [sp, #0x5a0]
    1e98:      	ldr	w1, [sp, #0x55c]
    1e9c:      	mov	w0, #0xd                // =13
    1ea0:      	and	w0, w1, w0
    1ea4:      	str	w0, [sp, #0x5a4]
    1ea8:      	ldr	w0, [sp, #0x568]
    1eac:      	and	w0, w0, #0xe
    1eb0:      	str	w0, [sp, #0x5a8]
    1eb4:      	ldr	w1, [sp, #0x56c]
    1eb8:      	ldr	w0, [sp, #0x58c]
    1ebc:      	eor	w0, w1, w0
    1ec0:      	str	w0, [sp, #0x5ac]
    1ec4:      	ldr	w1, [sp, #0x570]
    1ec8:      	ldr	w0, [sp, #0x590]
    1ecc:      	eor	w0, w1, w0
    1ed0:      	str	w0, [sp, #0x5b0]
    1ed4:      	ldr	w1, [sp, #0x574]
    1ed8:      	ldr	w0, [sp, #0x594]
    1edc:      	eor	w0, w1, w0
    1ee0:      	str	w0, [sp, #0x5b4]
    1ee4:      	ldr	w1, [sp, #0x578]
    1ee8:      	ldr	w0, [sp, #0x598]
    1eec:      	eor	w0, w1, w0
    1ef0:      	str	w0, [sp, #0x5b8]
    1ef4:      	ldr	w1, [sp, #0x57c]
    1ef8:      	ldr	w0, [sp, #0x59c]
    1efc:      	eor	w0, w1, w0
    1f00:      	str	w0, [sp, #0x5bc]
    1f04:      	ldr	w1, [sp, #0x580]
    1f08:      	ldr	w0, [sp, #0x5a0]
    1f0c:      	eor	w0, w1, w0
    1f10:      	str	w0, [sp, #0x5c0]
    1f14:      	ldr	w1, [sp, #0x584]
    1f18:      	ldr	w0, [sp, #0x5a4]
    1f1c:      	eor	w0, w1, w0
    1f20:      	str	w0, [sp, #0x5c4]
    1f24:      	ldr	w1, [sp, #0x588]
    1f28:      	ldr	w0, [sp, #0x5a8]
    1f2c:      	eor	w0, w1, w0
    1f30:      	str	w0, [sp, #0x5c8]
    1f34:      	ldr	w0, [sp, #0x5ac]
    1f38:      	and	w0, w0, #0x1
    1f3c:      	str	w0, [sp, #0x5cc]
    1f40:      	str	wzr, [sp, #0x5d0]
    1f44:      	str	wzr, [sp, #0x5d4]
    1f48:      	str	wzr, [sp, #0x5d8]
    1f4c:      	str	wzr, [sp, #0x5dc]
    1f50:      	str	wzr, [sp, #0x5e0]
    1f54:      	str	wzr, [sp, #0x5e4]
    1f58:      	str	wzr, [sp, #0x5e8]
    1f5c:      	ldr	w0, [sp, #0x5cc]
    1f60:      	neg	w0, w0
    1f64:      	and	w0, w0, #0xf
    1f68:      	str	w0, [sp, #0x5ec]
    1f6c:      	ldr	w0, [sp, #0x5cc]
    1f70:      	cmp	w0, #0x0
    1f74:      	cset	w0, ne
    1f78:      	and	w0, w0, #0xff
    1f7c:      	str	w0, [sp, #0x5f0]
    1f80:      	ldr	w1, [sp, #0x5d0]
    1f84:      	ldr	w0, [sp, #0x5f0]
    1f88:      	add	w0, w1, w0
    1f8c:      	str	w0, [sp, #0x5f4]
    1f90:      	ldr	w0, [sp, #0x5f4]
    1f94:      	neg	w0, w0
    1f98:      	and	w0, w0, #0xf
    1f9c:      	str	w0, [sp, #0x5f8]
    1fa0:      	ldr	w0, [sp, #0x5f4]
    1fa4:      	cmp	w0, #0x0
    1fa8:      	cset	w0, ne
    1fac:      	and	w0, w0, #0xff
    1fb0:      	str	w0, [sp, #0x5fc]
    1fb4:      	ldr	w1, [sp, #0x5d4]
    1fb8:      	ldr	w0, [sp, #0x5fc]
    1fbc:      	add	w0, w1, w0
    1fc0:      	str	w0, [sp, #0x600]
    1fc4:      	ldr	w0, [sp, #0x600]
    1fc8:      	neg	w0, w0
    1fcc:      	and	w0, w0, #0xf
    1fd0:      	str	w0, [sp, #0x604]
    1fd4:      	ldr	w0, [sp, #0x600]
    1fd8:      	cmp	w0, #0x0
    1fdc:      	cset	w0, ne
    1fe0:      	and	w0, w0, #0xff
    1fe4:      	str	w0, [sp, #0x608]
    1fe8:      	ldr	w1, [sp, #0x5d8]
    1fec:      	ldr	w0, [sp, #0x608]
    1ff0:      	add	w0, w1, w0
    1ff4:      	str	w0, [sp, #0x60c]
    1ff8:      	ldr	w0, [sp, #0x60c]
    1ffc:      	neg	w0, w0
    2000:      	and	w0, w0, #0xf
    2004:      	str	w0, [sp, #0x610]
    2008:      	ldr	w0, [sp, #0x60c]
    200c:      	cmp	w0, #0x0
    2010:      	cset	w0, ne
    2014:      	and	w0, w0, #0xff
    2018:      	str	w0, [sp, #0x614]
    201c:      	ldr	w1, [sp, #0x5dc]
    2020:      	ldr	w0, [sp, #0x614]
    2024:      	add	w0, w1, w0
    2028:      	str	w0, [sp, #0x618]
    202c:      	ldr	w0, [sp, #0x618]
    2030:      	neg	w0, w0
    2034:      	and	w0, w0, #0xf
    2038:      	str	w0, [sp, #0x61c]
    203c:      	ldr	w0, [sp, #0x618]
    2040:      	cmp	w0, #0x0
    2044:      	cset	w0, ne
    2048:      	and	w0, w0, #0xff
    204c:      	str	w0, [sp, #0x620]
    2050:      	ldr	w1, [sp, #0x5e0]
    2054:      	ldr	w0, [sp, #0x620]
    2058:      	add	w0, w1, w0
    205c:      	str	w0, [sp, #0x624]
    2060:      	ldr	w0, [sp, #0x624]
    2064:      	neg	w0, w0
    2068:      	and	w0, w0, #0xf
    206c:      	str	w0, [sp, #0x628]
    2070:      	ldr	w0, [sp, #0x624]
    2074:      	cmp	w0, #0x0
    2078:      	cset	w0, ne
    207c:      	and	w0, w0, #0xff
    2080:      	str	w0, [sp, #0x62c]
    2084:      	ldr	w1, [sp, #0x5e4]
    2088:      	ldr	w0, [sp, #0x62c]
    208c:      	add	w0, w1, w0
    2090:      	str	w0, [sp, #0x630]
    2094:      	ldr	w0, [sp, #0x630]
    2098:      	neg	w0, w0
    209c:      	and	w0, w0, #0xf
    20a0:      	str	w0, [sp, #0x634]
    20a4:      	ldr	w0, [sp, #0x630]
    20a8:      	cmp	w0, #0x0
    20ac:      	cset	w0, ne
    20b0:      	and	w0, w0, #0xff
    20b4:      	str	w0, [sp, #0x638]
    20b8:      	ldr	w1, [sp, #0x5e8]
    20bc:      	ldr	w0, [sp, #0x638]
    20c0:      	add	w0, w1, w0
    20c4:      	str	w0, [sp, #0x63c]
    20c8:      	ldr	w0, [sp, #0x63c]
    20cc:      	neg	w0, w0
    20d0:      	and	w0, w0, #0xf
    20d4:      	str	w0, [sp, #0x640]
    20d8:      	ldr	w0, [sp, #0x5ac]
    20dc:      	lsr	w1, w0, #1
    20e0:      	ldr	w0, [sp, #0x5b0]
    20e4:      	lsl	w0, w0, #3
    20e8:      	orr	w0, w1, w0
    20ec:      	and	w0, w0, #0xf
    20f0:      	str	w0, [sp, #0x644]
    20f4:      	ldr	w0, [sp, #0x5b0]
    20f8:      	lsr	w1, w0, #1
    20fc:      	ldr	w0, [sp, #0x5b4]
    2100:      	lsl	w0, w0, #3
    2104:      	orr	w0, w1, w0
    2108:      	and	w0, w0, #0xf
    210c:      	str	w0, [sp, #0x648]
    2110:      	ldr	w0, [sp, #0x5b4]
    2114:      	lsr	w1, w0, #1
    2118:      	ldr	w0, [sp, #0x5b8]
    211c:      	lsl	w0, w0, #3
    2120:      	orr	w0, w1, w0
    2124:      	and	w0, w0, #0xf
    2128:      	str	w0, [sp, #0x64c]
    212c:      	ldr	w0, [sp, #0x5b8]
    2130:      	lsr	w1, w0, #1
    2134:      	ldr	w0, [sp, #0x5bc]
    2138:      	lsl	w0, w0, #3
    213c:      	orr	w0, w1, w0
    2140:      	and	w0, w0, #0xf
    2144:      	str	w0, [sp, #0x650]
    2148:      	ldr	w0, [sp, #0x5bc]
    214c:      	lsr	w1, w0, #1
    2150:      	ldr	w0, [sp, #0x5c0]
    2154:      	lsl	w0, w0, #3
    2158:      	orr	w0, w1, w0
    215c:      	and	w0, w0, #0xf
    2160:      	str	w0, [sp, #0x654]
    2164:      	ldr	w0, [sp, #0x5c0]
    2168:      	lsr	w1, w0, #1
    216c:      	ldr	w0, [sp, #0x5c4]
    2170:      	lsl	w0, w0, #3
    2174:      	orr	w0, w1, w0
    2178:      	and	w0, w0, #0xf
    217c:      	str	w0, [sp, #0x658]
    2180:      	ldr	w0, [sp, #0x5c4]
    2184:      	lsr	w1, w0, #1
    2188:      	ldr	w0, [sp, #0x5c8]
    218c:      	lsl	w0, w0, #3
    2190:      	orr	w0, w1, w0
    2194:      	and	w0, w0, #0xf
    2198:      	str	w0, [sp, #0x65c]
    219c:      	ldr	w0, [sp, #0x5c8]
    21a0:      	lsr	w0, w0, #1
    21a4:      	and	w0, w0, #0xf
    21a8:      	str	w0, [sp, #0x660]
    21ac:      	str	wzr, [sp, #0x664]
    21b0:      	ldr	w0, [sp, #0x5f8]
    21b4:      	and	w0, w0, #0x2
    21b8:      	str	w0, [sp, #0x668]
    21bc:      	ldr	w0, [sp, #0x604]
    21c0:      	and	w0, w0, #0x3
    21c4:      	str	w0, [sp, #0x66c]
    21c8:      	ldr	w0, [sp, #0x610]
    21cc:      	and	w0, w0, #0x8
    21d0:      	str	w0, [sp, #0x670]
    21d4:      	ldr	w0, [sp, #0x61c]
    21d8:      	and	w0, w0, #0x8
    21dc:      	str	w0, [sp, #0x674]
    21e0:      	ldr	w1, [sp, #0x628]
    21e4:      	mov	w0, #0xb                // =11
    21e8:      	and	w0, w1, w0
    21ec:      	str	w0, [sp, #0x678]
    21f0:      	ldr	w1, [sp, #0x634]
    21f4:      	mov	w0, #0xd                // =13
    21f8:      	and	w0, w1, w0
    21fc:      	str	w0, [sp, #0x67c]
    2200:      	ldr	w0, [sp, #0x640]
    2204:      	and	w0, w0, #0xe
    2208:      	str	w0, [sp, #0x680]
    220c:      	ldr	w1, [sp, #0x644]
    2210:      	ldr	w0, [sp, #0x664]
    2214:      	eor	w0, w1, w0
    2218:      	str	w0, [sp, #0x684]
    221c:      	ldr	w1, [sp, #0x648]
    2220:      	ldr	w0, [sp, #0x668]
    2224:      	eor	w0, w1, w0
    2228:      	str	w0, [sp, #0x688]
    222c:      	ldr	w1, [sp, #0x64c]
    2230:      	ldr	w0, [sp, #0x66c]
    2234:      	eor	w0, w1, w0
    2238:      	str	w0, [sp, #0x68c]
    223c:      	ldr	w1, [sp, #0x650]
    2240:      	ldr	w0, [sp, #0x670]
    2244:      	eor	w0, w1, w0
    2248:      	str	w0, [sp, #0x690]
    224c:      	ldr	w1, [sp, #0x654]
    2250:      	ldr	w0, [sp, #0x674]
    2254:      	eor	w0, w1, w0
    2258:      	str	w0, [sp, #0x694]
    225c:      	ldr	w1, [sp, #0x658]
    2260:      	ldr	w0, [sp, #0x678]
    2264:      	eor	w0, w1, w0
    2268:      	str	w0, [sp, #0x698]
    226c:      	ldr	w1, [sp, #0x65c]
    2270:      	ldr	w0, [sp, #0x67c]
    2274:      	eor	w0, w1, w0
    2278:      	str	w0, [sp, #0x69c]
    227c:      	ldr	w1, [sp, #0x660]
    2280:      	ldr	w0, [sp, #0x680]
    2284:      	eor	w0, w1, w0
    2288:      	str	w0, [sp, #0x6a0]
    228c:      	ldr	w0, [sp, #0x684]
    2290:      	and	w0, w0, #0x1
    2294:      	str	w0, [sp, #0x6a4]
    2298:      	str	wzr, [sp, #0x6a8]
    229c:      	str	wzr, [sp, #0x6ac]
    22a0:      	str	wzr, [sp, #0x6b0]
    22a4:      	str	wzr, [sp, #0x6b4]
    22a8:      	str	wzr, [sp, #0x6b8]
    22ac:      	str	wzr, [sp, #0x6bc]
    22b0:      	str	wzr, [sp, #0x6c0]
    22b4:      	ldr	w0, [sp, #0x6a4]
    22b8:      	neg	w0, w0
    22bc:      	and	w0, w0, #0xf
    22c0:      	str	w0, [sp, #0x6c4]
    22c4:      	ldr	w0, [sp, #0x6a4]
    22c8:      	cmp	w0, #0x0
    22cc:      	cset	w0, ne
    22d0:      	and	w0, w0, #0xff
    22d4:      	str	w0, [sp, #0x6c8]
    22d8:      	ldr	w1, [sp, #0x6a8]
    22dc:      	ldr	w0, [sp, #0x6c8]
    22e0:      	add	w0, w1, w0
    22e4:      	str	w0, [sp, #0x6cc]
    22e8:      	ldr	w0, [sp, #0x6cc]
    22ec:      	neg	w0, w0
    22f0:      	and	w0, w0, #0xf
    22f4:      	str	w0, [sp, #0x6d0]
    22f8:      	ldr	w0, [sp, #0x6cc]
    22fc:      	cmp	w0, #0x0
    2300:      	cset	w0, ne
    2304:      	and	w0, w0, #0xff
    2308:      	str	w0, [sp, #0x6d4]
    230c:      	ldr	w1, [sp, #0x6ac]
    2310:      	ldr	w0, [sp, #0x6d4]
    2314:      	add	w0, w1, w0
    2318:      	str	w0, [sp, #0x6d8]
    231c:      	ldr	w0, [sp, #0x6d8]
    2320:      	neg	w0, w0
    2324:      	and	w0, w0, #0xf
    2328:      	str	w0, [sp, #0x6dc]
    232c:      	ldr	w0, [sp, #0x6d8]
    2330:      	cmp	w0, #0x0
    2334:      	cset	w0, ne
    2338:      	and	w0, w0, #0xff
    233c:      	str	w0, [sp, #0x6e0]
    2340:      	ldr	w1, [sp, #0x6b0]
    2344:      	ldr	w0, [sp, #0x6e0]
    2348:      	add	w0, w1, w0
    234c:      	str	w0, [sp, #0x6e4]
    2350:      	ldr	w0, [sp, #0x6e4]
    2354:      	neg	w0, w0
    2358:      	and	w0, w0, #0xf
    235c:      	str	w0, [sp, #0x6e8]
    2360:      	ldr	w0, [sp, #0x6e4]
    2364:      	cmp	w0, #0x0
    2368:      	cset	w0, ne
    236c:      	and	w0, w0, #0xff
    2370:      	str	w0, [sp, #0x6ec]
    2374:      	ldr	w1, [sp, #0x6b4]
    2378:      	ldr	w0, [sp, #0x6ec]
    237c:      	add	w0, w1, w0
    2380:      	str	w0, [sp, #0x6f0]
    2384:      	ldr	w0, [sp, #0x6f0]
    2388:      	neg	w0, w0
    238c:      	and	w0, w0, #0xf
    2390:      	str	w0, [sp, #0x6f4]
    2394:      	ldr	w0, [sp, #0x6f0]
    2398:      	cmp	w0, #0x0
    239c:      	cset	w0, ne
    23a0:      	and	w0, w0, #0xff
    23a4:      	str	w0, [sp, #0x6f8]
    23a8:      	ldr	w1, [sp, #0x6b8]
    23ac:      	ldr	w0, [sp, #0x6f8]
    23b0:      	add	w0, w1, w0
    23b4:      	str	w0, [sp, #0x6fc]
    23b8:      	ldr	w0, [sp, #0x6fc]
    23bc:      	neg	w0, w0
    23c0:      	and	w0, w0, #0xf
    23c4:      	str	w0, [sp, #0x700]
    23c8:      	ldr	w0, [sp, #0x6fc]
    23cc:      	cmp	w0, #0x0
    23d0:      	cset	w0, ne
    23d4:      	and	w0, w0, #0xff
    23d8:      	str	w0, [sp, #0x704]
    23dc:      	ldr	w1, [sp, #0x6bc]
    23e0:      	ldr	w0, [sp, #0x704]
    23e4:      	add	w0, w1, w0
    23e8:      	str	w0, [sp, #0x708]
    23ec:      	ldr	w0, [sp, #0x708]
    23f0:      	neg	w0, w0
    23f4:      	and	w0, w0, #0xf
    23f8:      	str	w0, [sp, #0x70c]
    23fc:      	ldr	w0, [sp, #0x708]
    2400:      	cmp	w0, #0x0
    2404:      	cset	w0, ne
    2408:      	and	w0, w0, #0xff
    240c:      	str	w0, [sp, #0x710]
    2410:      	ldr	w1, [sp, #0x6c0]
    2414:      	ldr	w0, [sp, #0x710]
    2418:      	add	w0, w1, w0
    241c:      	str	w0, [sp, #0x714]
    2420:      	ldr	w0, [sp, #0x714]
    2424:      	neg	w0, w0
    2428:      	and	w0, w0, #0xf
    242c:      	str	w0, [sp, #0x718]
    2430:      	ldr	w0, [sp, #0x684]
    2434:      	lsr	w1, w0, #1
    2438:      	ldr	w0, [sp, #0x688]
    243c:      	lsl	w0, w0, #3
    2440:      	orr	w0, w1, w0
    2444:      	and	w0, w0, #0xf
    2448:      	str	w0, [sp, #0x71c]
    244c:      	ldr	w0, [sp, #0x688]
    2450:      	lsr	w1, w0, #1
    2454:      	ldr	w0, [sp, #0x68c]
    2458:      	lsl	w0, w0, #3
    245c:      	orr	w0, w1, w0
    2460:      	and	w0, w0, #0xf
    2464:      	str	w0, [sp, #0x720]
    2468:      	ldr	w0, [sp, #0x68c]
    246c:      	lsr	w1, w0, #1
    2470:      	ldr	w0, [sp, #0x690]
    2474:      	lsl	w0, w0, #3
    2478:      	orr	w0, w1, w0
    247c:      	and	w0, w0, #0xf
    2480:      	str	w0, [sp, #0x724]
    2484:      	ldr	w0, [sp, #0x690]
    2488:      	lsr	w1, w0, #1
    248c:      	ldr	w0, [sp, #0x694]
    2490:      	lsl	w0, w0, #3
    2494:      	orr	w0, w1, w0
    2498:      	and	w0, w0, #0xf
    249c:      	str	w0, [sp, #0x728]
    24a0:      	ldr	w0, [sp, #0x694]
    24a4:      	lsr	w1, w0, #1
    24a8:      	ldr	w0, [sp, #0x698]
    24ac:      	lsl	w0, w0, #3
    24b0:      	orr	w0, w1, w0
    24b4:      	and	w0, w0, #0xf
    24b8:      	str	w0, [sp, #0x72c]
    24bc:      	ldr	w0, [sp, #0x698]
    24c0:      	lsr	w1, w0, #1
    24c4:      	ldr	w0, [sp, #0x69c]
    24c8:      	lsl	w0, w0, #3
    24cc:      	orr	w0, w1, w0
    24d0:      	and	w0, w0, #0xf
    24d4:      	str	w0, [sp, #0x730]
    24d8:      	ldr	w0, [sp, #0x69c]
    24dc:      	lsr	w1, w0, #1
    24e0:      	ldr	w0, [sp, #0x6a0]
    24e4:      	lsl	w0, w0, #3
    24e8:      	orr	w0, w1, w0
    24ec:      	and	w0, w0, #0xf
    24f0:      	str	w0, [sp, #0x734]
    24f4:      	ldr	w0, [sp, #0x6a0]
    24f8:      	lsr	w0, w0, #1
    24fc:      	and	w0, w0, #0xf
    2500:      	str	w0, [sp, #0x738]
    2504:      	str	wzr, [sp, #0x73c]
    2508:      	ldr	w0, [sp, #0x6d0]
    250c:      	and	w0, w0, #0x2
    2510:      	str	w0, [sp, #0x740]
    2514:      	ldr	w0, [sp, #0x6dc]
    2518:      	and	w0, w0, #0x3
    251c:      	str	w0, [sp, #0x744]
    2520:      	ldr	w0, [sp, #0x6e8]
    2524:      	and	w0, w0, #0x8
    2528:      	str	w0, [sp, #0x748]
    252c:      	ldr	w0, [sp, #0x6f4]
    2530:      	and	w0, w0, #0x8
    2534:      	str	w0, [sp, #0x74c]
    2538:      	ldr	w1, [sp, #0x700]
    253c:      	mov	w0, #0xb                // =11
    2540:      	and	w0, w1, w0
    2544:      	str	w0, [sp, #0x750]
    2548:      	ldr	w1, [sp, #0x70c]
    254c:      	mov	w0, #0xd                // =13
    2550:      	and	w0, w1, w0
    2554:      	str	w0, [sp, #0x754]
    2558:      	ldr	w0, [sp, #0x718]
    255c:      	and	w0, w0, #0xe
    2560:      	str	w0, [sp, #0x758]
    2564:      	ldr	w1, [sp, #0x71c]
    2568:      	ldr	w0, [sp, #0x73c]
    256c:      	eor	w0, w1, w0
    2570:      	str	w0, [sp, #0x75c]
    2574:      	ldr	w1, [sp, #0x720]
    2578:      	ldr	w0, [sp, #0x740]
    257c:      	eor	w0, w1, w0
    2580:      	str	w0, [sp, #0x760]
    2584:      	ldr	w1, [sp, #0x724]
    2588:      	ldr	w0, [sp, #0x744]
    258c:      	eor	w0, w1, w0
    2590:      	str	w0, [sp, #0x764]
    2594:      	ldr	w1, [sp, #0x728]
    2598:      	ldr	w0, [sp, #0x748]
    259c:      	eor	w0, w1, w0
    25a0:      	str	w0, [sp, #0x768]
    25a4:      	ldr	w1, [sp, #0x72c]
    25a8:      	ldr	w0, [sp, #0x74c]
    25ac:      	eor	w0, w1, w0
    25b0:      	str	w0, [sp, #0x76c]
    25b4:      	ldr	w1, [sp, #0x730]
    25b8:      	ldr	w0, [sp, #0x750]
    25bc:      	eor	w0, w1, w0
    25c0:      	str	w0, [sp, #0x770]
    25c4:      	ldr	w1, [sp, #0x734]
    25c8:      	ldr	w0, [sp, #0x754]
    25cc:      	eor	w0, w1, w0
    25d0:      	str	w0, [sp, #0x774]
    25d4:      	ldr	w1, [sp, #0x738]
    25d8:      	ldr	w0, [sp, #0x758]
    25dc:      	eor	w0, w1, w0
    25e0:      	str	w0, [sp, #0x778]
    25e4:      	ldr	w0, [sp, #0x75c]
    25e8:      	eor	w0, w0, #0xf
    25ec:      	str	w0, [sp, #0x77c]
    25f0:      	ldr	w0, [sp, #0x760]
    25f4:      	eor	w0, w0, #0xf
    25f8:      	str	w0, [sp, #0x780]
    25fc:      	ldr	w0, [sp, #0x764]
    2600:      	eor	w0, w0, #0xf
    2604:      	str	w0, [sp, #0x784]
    2608:      	ldr	w0, [sp, #0x768]
    260c:      	eor	w0, w0, #0xf
    2610:      	str	w0, [sp, #0x788]
    2614:      	ldr	w0, [sp, #0x76c]
    2618:      	eor	w0, w0, #0xf
    261c:      	str	w0, [sp, #0x78c]
    2620:      	ldr	w0, [sp, #0x770]
    2624:      	eor	w0, w0, #0xf
    2628:      	str	w0, [sp, #0x790]
    262c:      	ldr	w0, [sp, #0x774]
    2630:      	eor	w0, w0, #0xf
    2634:      	str	w0, [sp, #0x794]
    2638:      	ldr	w0, [sp, #0x778]
    263c:      	eor	w0, w0, #0xf
    2640:      	str	w0, [sp, #0x798]
    2644:      	ldr	w0, [sp, #0x780]
    2648:      	lsl	w1, w0, #4
    264c:      	ldr	w0, [sp, #0x77c]
    2650:      	orr	w1, w1, w0
    2654:      	ldr	w0, [sp, #0x784]
    2658:      	lsl	w0, w0, #8
    265c:      	orr	w1, w1, w0
    2660:      	ldr	w0, [sp, #0x788]
    2664:      	lsl	w0, w0, #12
    2668:      	orr	w1, w1, w0
    266c:      	ldr	w0, [sp, #0x78c]
    2670:      	lsl	w0, w0, #16
    2674:      	orr	w1, w1, w0
    2678:      	ldr	w0, [sp, #0x790]
    267c:      	lsl	w0, w0, #20
    2680:      	orr	w1, w1, w0
    2684:      	ldr	w0, [sp, #0x794]
    2688:      	lsl	w0, w0, #24
    268c:      	orr	w1, w1, w0
    2690:      	ldr	w0, [sp, #0x798]
    2694:      	lsl	w0, w0, #28
    2698:      	orr	w0, w1, w0
    269c:      	str	w0, [sp, #0x79c]
    26a0:      	ldr	w0, [sp, #0x79c]
    26a4:      	add	sp, sp, #0x7a0
    26a8:      	ret

00000000000026ac <csrd_matrix_next_value>:
    26ac:      	sub	sp, sp, #0x10
    26b0:      	str	x0, [sp, #0x8]
    26b4:      	ldr	x0, [sp, #0x8]
    26b8:      	ldr	w1, [x0]
    26bc:      	ldr	x0, [sp, #0x8]
    26c0:      	ldr	w0, [x0]
    26c4:      	lsl	w0, w0, #13
    26c8:      	eor	w1, w1, w0
    26cc:      	ldr	x0, [sp, #0x8]
    26d0:      	str	w1, [x0]
    26d4:      	ldr	x0, [sp, #0x8]
    26d8:      	ldr	w1, [x0]
    26dc:      	ldr	x0, [sp, #0x8]
    26e0:      	ldr	w0, [x0]
    26e4:      	lsr	w0, w0, #17
    26e8:      	eor	w1, w1, w0
    26ec:      	ldr	x0, [sp, #0x8]
    26f0:      	str	w1, [x0]
    26f4:      	ldr	x0, [sp, #0x8]
    26f8:      	ldr	w1, [x0]
    26fc:      	ldr	x0, [sp, #0x8]
    2700:      	ldr	w0, [x0]
    2704:      	lsl	w0, w0, #5
    2708:      	eor	w1, w1, w0
    270c:      	ldr	x0, [sp, #0x8]
    2710:      	str	w1, [x0]
    2714:      	ldr	x0, [sp, #0x8]
    2718:      	ldr	w0, [x0]
    271c:      	add	sp, sp, #0x10
    2720:      	ret

0000000000002724 <main>:
    2724:      	sub	sp, sp, #0x80
    2728:      	stp	x29, x30, [sp, #0x70]
    272c:      	add	x29, sp, #0x70
    2730:      	str	w0, [sp, #0xc]
    2734:      	str	x1, [sp]
    2738:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1c548>
    273c:      	ldr	x0, [x0, #0xfe8]
    2740:      	ldr	x1, [x0]
    2744:      	str	x1, [sp, #0x68]
    2748:      	mov	x1, #0x0                // =0
    274c:      	ldr	w0, [sp, #0xc]
    2750:      	cmp	w0, #0x1
    2754:      	b.ne	0x27a8 <main+0x84>
    2758:      	b	0x2778 <main+0x54>
    275c:      	ldr	w0, [sp, #0x60]
    2760:      	ldr	w1, [sp, #0x64]
    2764:      	bl	0x918 <kernel>
    2768:      	mov	w1, w0
    276c:      	adrp	x0, 0x2000 <kernel+0x16e8>
    2770:      	add	x0, x0, #0x958
    2774:      	bl	0x7f0 <printf@plt>
    2778:      	add	x0, sp, #0x60
    277c:      	add	x1, x0, #0x4
    2780:      	add	x0, sp, #0x60
    2784:      	mov	x2, x1
    2788:      	mov	x1, x0
    278c:      	adrp	x0, 0x2000 <kernel+0x16e8>
    2790:      	add	x0, x0, #0x960
    2794:      	bl	0x7e0 <__isoc99_scanf@plt>
    2798:      	cmp	w0, #0x2
    279c:      	b.eq	0x275c <main+0x38>
    27a0:      	mov	w0, #0x0                // =0
    27a4:      	b	0x2908 <main+0x1e4>
    27a8:      	ldr	w0, [sp, #0xc]
    27ac:      	cmp	w0, #0x3
    27b0:      	b.eq	0x27bc <main+0x98>
    27b4:      	mov	w0, #0x3                // =3
    27b8:      	b	0x2908 <main+0x1e4>
    27bc:      	ldr	x0, [sp]
    27c0:      	add	x0, x0, #0x8
    27c4:      	ldr	x0, [x0]
    27c8:      	mov	w2, #0xa                // =10
    27cc:      	mov	x1, #0x0                // =0
    27d0:      	bl	0x770 <strtoul@plt>
    27d4:      	str	x0, [sp, #0x30]
    27d8:      	ldr	x0, [sp]
    27dc:      	add	x0, x0, #0x10
    27e0:      	ldr	x0, [x0]
    27e4:      	mov	w2, #0xa                // =10
    27e8:      	mov	x1, #0x0                // =0
    27ec:      	bl	0x770 <strtoul@plt>
    27f0:      	str	w0, [sp, #0x18]
    27f4:      	str	xzr, [sp, #0x20]
    27f8:      	add	x0, sp, #0x40
    27fc:      	mov	x1, x0
    2800:      	mov	w0, #0x1                // =1
    2804:      	bl	0x7a0 <clock_gettime@plt>
    2808:      	cmp	w0, #0x0
    280c:      	b.eq	0x2818 <main+0xf4>
    2810:      	mov	w0, #0x2                // =2
    2814:      	b	0x2908 <main+0x1e4>
    2818:      	str	xzr, [sp, #0x28]
    281c:      	b	0x2884 <main+0x160>
    2820:      	str	wzr, [sp, #0x1c]
    2824:      	b	0x2850 <main+0x12c>
    2828:      	add	x0, sp, #0x18
    282c:      	bl	0x26ac <csrd_matrix_next_value>
    2830:      	mov	w2, w0
    2834:      	ldr	w0, [sp, #0x1c]
    2838:      	lsl	x0, x0, #2
    283c:      	add	x1, sp, #0x60
    2840:      	str	w2, [x1, x0]
    2844:      	ldr	w0, [sp, #0x1c]
    2848:      	add	w0, w0, #0x1
    284c:      	str	w0, [sp, #0x1c]
    2850:      	ldr	w0, [sp, #0x1c]
    2854:      	cmp	w0, #0x1
    2858:      	b.ls	0x2828 <main+0x104>
    285c:      	ldr	w0, [sp, #0x60]
    2860:      	ldr	w1, [sp, #0x64]
    2864:      	bl	0x918 <kernel>
    2868:      	mov	w0, w0
    286c:      	ldr	x1, [sp, #0x20]
    2870:      	add	x0, x1, x0
    2874:      	str	x0, [sp, #0x20]
    2878:      	ldr	x0, [sp, #0x28]
    287c:      	add	x0, x0, #0x1
    2880:      	str	x0, [sp, #0x28]
    2884:      	ldr	x1, [sp, #0x28]
    2888:      	ldr	x0, [sp, #0x30]
    288c:      	cmp	x1, x0
    2890:      	b.lo	0x2820 <main+0xfc>
    2894:      	add	x0, sp, #0x50
    2898:      	mov	x1, x0
    289c:      	mov	w0, #0x1                // =1
    28a0:      	bl	0x7a0 <clock_gettime@plt>
    28a4:      	cmp	w0, #0x0
    28a8:      	b.eq	0x28b4 <main+0x190>
    28ac:      	mov	w0, #0x2                // =2
    28b0:      	b	0x2908 <main+0x1e4>
    28b4:      	ldr	x1, [sp, #0x50]
    28b8:      	ldr	x0, [sp, #0x40]
    28bc:      	sub	x0, x1, x0
    28c0:      	fmov	d0, x0
    28c4:      	scvtf	d1, d0
    28c8:      	ldr	x1, [sp, #0x58]
    28cc:      	ldr	x0, [sp, #0x48]
    28d0:      	sub	x0, x1, x0
    28d4:      	fmov	d0, x0
    28d8:      	scvtf	d0, d0
    28dc:      	adrp	x0, 0x2000 <kernel+0x16e8>
    28e0:      	ldr	d2, [x0, #0x978]
    28e4:      	fmul	d0, d0, d2
    28e8:      	fadd	d0, d1, d0
    28ec:      	str	d0, [sp, #0x38]
    28f0:      	ldr	x1, [sp, #0x20]
    28f4:      	ldr	d0, [sp, #0x38]
    28f8:      	adrp	x0, 0x2000 <kernel+0x16e8>
    28fc:      	add	x0, x0, #0x968
    2900:      	bl	0x7f0 <printf@plt>
    2904:      	mov	w0, #0x0                // =0
    2908:      	mov	w1, w0
    290c:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1c548>
    2910:      	ldr	x0, [x0, #0xfe8]
    2914:      	ldr	x3, [sp, #0x68]
    2918:      	ldr	x2, [x0]
    291c:      	subs	x3, x3, x2
    2920:      	mov	x2, #0x0                // =0
    2924:      	b.eq	0x292c <main+0x208>
    2928:      	bl	0x7b0 <__stack_chk_fail@plt>
    292c:      	mov	w0, w1
    2930:      	ldp	x29, x30, [sp, #0x70]
    2934:      	add	sp, sp, #0x80
    2938:      	ret

Disassembly of section .fini:

000000000000293c <_fini>:
    293c:      	nop
    2940:      	stp	x29, x30, [sp, #-0x10]!
    2944:      	mov	x29, sp
    2948:      	ldp	x29, x30, [sp], #0x10
    294c:      	ret
