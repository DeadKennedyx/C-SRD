
/work/experiments/runs/positional-widths-comparison-20261110/matrix/crc32_byte/build-clang-O0-limbs8/program:	file format elf64-littleaarch64

Disassembly of section .init:

0000000000000678 <_init>:
     678:      	nop
     67c:      	stp	x29, x30, [sp, #-0x10]!
     680:      	mov	x29, sp
     684:      	bl	0x774 <call_weak_fn>
     688:      	ldp	x29, x30, [sp], #0x10
     68c:      	ret

Disassembly of section .plt:

0000000000000690 <.plt>:
     690:      	stp	x16, x30, [sp, #-0x10]!
     694:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1d56c>
     698:      	ldr	x17, [x16, #0xff8]
     69c:      	add	x16, x16, #0xff8
     6a0:      	br	x17
     6a4:      	nop
     6a8:      	nop
     6ac:      	nop

00000000000006b0 <strtoul@plt>:
     6b0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6b4:      	ldr	x17, [x16]
     6b8:      	add	x16, x16, #0x0
     6bc:      	br	x17

00000000000006c0 <__libc_start_main@plt>:
     6c0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6c4:      	ldr	x17, [x16, #0x8]
     6c8:      	add	x16, x16, #0x8
     6cc:      	br	x17

00000000000006d0 <__cxa_finalize@plt>:
     6d0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6d4:      	ldr	x17, [x16, #0x10]
     6d8:      	add	x16, x16, #0x10
     6dc:      	br	x17

00000000000006e0 <clock_gettime@plt>:
     6e0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6e4:      	ldr	x17, [x16, #0x18]
     6e8:      	add	x16, x16, #0x18
     6ec:      	br	x17

00000000000006f0 <__gmon_start__@plt>:
     6f0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6f4:      	ldr	x17, [x16, #0x20]
     6f8:      	add	x16, x16, #0x20
     6fc:      	br	x17

0000000000000700 <abort@plt>:
     700:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     704:      	ldr	x17, [x16, #0x28]
     708:      	add	x16, x16, #0x28
     70c:      	br	x17

0000000000000710 <__isoc99_scanf@plt>:
     710:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     714:      	ldr	x17, [x16, #0x30]
     718:      	add	x16, x16, #0x30
     71c:      	br	x17

0000000000000720 <printf@plt>:
     720:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     724:      	ldr	x17, [x16, #0x38]
     728:      	add	x16, x16, #0x38
     72c:      	br	x17

Disassembly of section .text:

0000000000000740 <_start>:
     740:      	nop
     744:      	mov	x29, #0x0               // =0
     748:      	mov	x30, #0x0               // =0
     74c:      	mov	x5, x0
     750:      	ldr	x1, [sp]
     754:      	add	x2, sp, #0x8
     758:      	mov	x6, sp
     75c:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1d56c>
     760:      	ldr	x0, [x0, #0xfd8]
     764:      	mov	x3, #0x0                // =0
     768:      	mov	x4, #0x0                // =0
     76c:      	bl	0x6c0 <__libc_start_main@plt>
     770:      	bl	0x700 <abort@plt>

0000000000000774 <call_weak_fn>:
     774:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1d56c>
     778:      	ldr	x0, [x0, #0xfd0]
     77c:      	cbz	x0, 0x784 <call_weak_fn+0x10>
     780:      	b	0x6f0 <__gmon_start__@plt>
     784:      	ret
     788:      	nop
     78c:      	nop

0000000000000790 <deregister_tm_clones>:
     790:      	adrp	x0, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     794:      	add	x0, x0, #0x50
     798:      	adrp	x1, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     79c:      	add	x1, x1, #0x50
     7a0:      	cmp	x1, x0
     7a4:      	b.eq	0x7bc <deregister_tm_clones+0x2c>
     7a8:      	adrp	x1, 0x1f000 <__FRAME_END__+0x1d56c>
     7ac:      	ldr	x1, [x1, #0xfc0]
     7b0:      	cbz	x1, 0x7bc <deregister_tm_clones+0x2c>
     7b4:      	mov	x16, x1
     7b8:      	br	x16
     7bc:      	ret

00000000000007c0 <register_tm_clones>:
     7c0:      	adrp	x0, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     7c4:      	add	x0, x0, #0x50
     7c8:      	adrp	x1, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     7cc:      	add	x1, x1, #0x50
     7d0:      	sub	x1, x1, x0
     7d4:      	lsr	x2, x1, #63
     7d8:      	add	x1, x2, x1, asr #3
     7dc:      	asr	x1, x1, #1
     7e0:      	cbz	x1, 0x7f8 <register_tm_clones+0x38>
     7e4:      	adrp	x2, 0x1f000 <__FRAME_END__+0x1d56c>
     7e8:      	ldr	x2, [x2, #0xfe0]
     7ec:      	cbz	x2, 0x7f8 <register_tm_clones+0x38>
     7f0:      	mov	x16, x2
     7f4:      	br	x16
     7f8:      	ret
     7fc:      	nop

0000000000000800 <__do_global_dtors_aux>:
     800:      	paciasp
     804:      	stp	x29, x30, [sp, #-0x20]!
     808:      	mov	x29, sp
     80c:      	str	x19, [sp, #0x10]
     810:      	adrp	x19, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     814:      	ldrb	w0, [x19, #0x50]
     818:      	tbnz	w0, #0x0, 0x840 <__do_global_dtors_aux+0x40>
     81c:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1d56c>
     820:      	ldr	x0, [x0, #0xfc8]
     824:      	cbz	x0, 0x834 <__do_global_dtors_aux+0x34>
     828:      	adrp	x0, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     82c:      	ldr	x0, [x0, #0x48]
     830:      	bl	0x6d0 <__cxa_finalize@plt>
     834:      	bl	0x790 <deregister_tm_clones>
     838:      	mov	w0, #0x1                // =1
     83c:      	strb	w0, [x19, #0x50]
     840:      	ldr	x19, [sp, #0x10]
     844:      	ldp	x29, x30, [sp], #0x20
     848:      	autiasp
     84c:      	ret

0000000000000850 <frame_dummy>:
     850:      	bti	c
     854:      	b	0x7c0 <register_tm_clones>

0000000000000858 <kernel>:
     858:      	str	x29, [sp, #-0x10]!
     85c:      	sub	sp, sp, #0x3b0
     860:      	str	w0, [sp, #0x3ac]
     864:      	str	w1, [sp, #0x3a8]
     868:      	ldrb	w8, [sp, #0x3ac]
     86c:      	str	w8, [sp, #0x3a4]
     870:      	ldr	w8, [sp, #0x3ac]
     874:      	lsr	w8, w8, #8
     878:      	and	w8, w8, #0xff
     87c:      	str	w8, [sp, #0x3a0]
     880:      	ldr	w8, [sp, #0x3ac]
     884:      	lsr	w8, w8, #16
     888:      	and	w8, w8, #0xff
     88c:      	str	w8, [sp, #0x39c]
     890:      	ldr	w8, [sp, #0x3ac]
     894:      	lsr	w8, w8, #24
     898:      	and	w8, w8, #0xff
     89c:      	str	w8, [sp, #0x398]
     8a0:      	ldrb	w8, [sp, #0x3a8]
     8a4:      	str	w8, [sp, #0x394]
     8a8:      	ldr	w8, [sp, #0x3a8]
     8ac:      	lsr	w8, w8, #8
     8b0:      	and	w8, w8, #0xff
     8b4:      	str	w8, [sp, #0x390]
     8b8:      	ldr	w8, [sp, #0x3a8]
     8bc:      	lsr	w8, w8, #16
     8c0:      	and	w8, w8, #0xff
     8c4:      	str	w8, [sp, #0x38c]
     8c8:      	ldr	w8, [sp, #0x3a8]
     8cc:      	lsr	w8, w8, #24
     8d0:      	and	w8, w8, #0xff
     8d4:      	str	w8, [sp, #0x388]
     8d8:      	ldr	w8, [sp, #0x3a4]
     8dc:      	eor	w8, w8, #0xff
     8e0:      	str	w8, [sp, #0x384]
     8e4:      	ldr	w8, [sp, #0x3a0]
     8e8:      	eor	w8, w8, #0xff
     8ec:      	str	w8, [sp, #0x380]
     8f0:      	ldr	w8, [sp, #0x39c]
     8f4:      	eor	w8, w8, #0xff
     8f8:      	str	w8, [sp, #0x37c]
     8fc:      	ldr	w8, [sp, #0x398]
     900:      	eor	w8, w8, #0xff
     904:      	str	w8, [sp, #0x378]
     908:      	ldrb	w8, [sp, #0x394]
     90c:      	str	w8, [sp, #0x374]
     910:      	ldr	w8, [sp, #0x390]
     914:      	mov	w12, wzr
     918:      	and	w8, w8, w12
     91c:      	str	w8, [sp, #0x370]
     920:      	ldr	w8, [sp, #0x38c]
     924:      	and	w8, w8, w12
     928:      	str	w8, [sp, #0x36c]
     92c:      	ldr	w8, [sp, #0x388]
     930:      	and	w8, w8, w12
     934:      	str	w8, [sp, #0x368]
     938:      	ldr	w8, [sp, #0x384]
     93c:      	ldr	w9, [sp, #0x374]
     940:      	eor	w8, w8, w9
     944:      	str	w8, [sp, #0x364]
     948:      	ldr	w8, [sp, #0x380]
     94c:      	ldr	w9, [sp, #0x370]
     950:      	eor	w8, w8, w9
     954:      	str	w8, [sp, #0x360]
     958:      	ldr	w8, [sp, #0x37c]
     95c:      	ldr	w9, [sp, #0x36c]
     960:      	eor	w8, w8, w9
     964:      	str	w8, [sp, #0x35c]
     968:      	ldr	w8, [sp, #0x378]
     96c:      	ldr	w9, [sp, #0x368]
     970:      	eor	w8, w8, w9
     974:      	str	w8, [sp, #0x358]
     978:      	ldr	w8, [sp, #0x364]
     97c:      	and	w8, w8, #0x1
     980:      	str	w8, [sp, #0x354]
     984:      	ldr	w8, [sp, #0x360]
     988:      	and	w8, w8, w12
     98c:      	str	w8, [sp, #0x350]
     990:      	ldr	w8, [sp, #0x35c]
     994:      	and	w8, w8, w12
     998:      	str	w8, [sp, #0x34c]
     99c:      	ldr	w8, [sp, #0x358]
     9a0:      	and	w8, w8, w12
     9a4:      	str	w8, [sp, #0x348]
     9a8:      	ldr	w8, [sp, #0x354]
     9ac:      	subs	w8, w12, w8
     9b0:      	and	w8, w8, #0xff
     9b4:      	str	w8, [sp, #0x344]
     9b8:      	ldr	w8, [sp, #0x354]
     9bc:      	subs	w8, w12, w8
     9c0:      	cset	w8, lo
     9c4:      	str	w8, [sp, #0x340]
     9c8:      	ldr	w8, [sp, #0x350]
     9cc:      	ldr	w9, [sp, #0x340]
     9d0:      	add	w8, w8, w9
     9d4:      	str	w8, [sp, #0x33c]
     9d8:      	ldr	w8, [sp, #0x33c]
     9dc:      	subs	w8, w12, w8
     9e0:      	and	w8, w8, #0xff
     9e4:      	str	w8, [sp, #0x338]
     9e8:      	ldr	w8, [sp, #0x33c]
     9ec:      	subs	w8, w12, w8
     9f0:      	cset	w8, lo
     9f4:      	str	w8, [sp, #0x334]
     9f8:      	ldr	w8, [sp, #0x34c]
     9fc:      	ldr	w9, [sp, #0x334]
     a00:      	add	w8, w8, w9
     a04:      	str	w8, [sp, #0x330]
     a08:      	ldr	w8, [sp, #0x330]
     a0c:      	subs	w8, w12, w8
     a10:      	and	w8, w8, #0xff
     a14:      	str	w8, [sp, #0x32c]
     a18:      	ldr	w8, [sp, #0x330]
     a1c:      	subs	w8, w12, w8
     a20:      	cset	w8, lo
     a24:      	str	w8, [sp, #0x328]
     a28:      	ldr	w8, [sp, #0x348]
     a2c:      	ldr	w9, [sp, #0x328]
     a30:      	add	w8, w8, w9
     a34:      	str	w8, [sp, #0x324]
     a38:      	ldr	w8, [sp, #0x324]
     a3c:      	subs	w8, w12, w8
     a40:      	and	w8, w8, #0xff
     a44:      	str	w8, [sp, #0x320]
     a48:      	ldr	w9, [sp, #0x364]
     a4c:      	ldr	w8, [sp, #0x360]
     a50:      	lsl	w8, w8, #7
     a54:      	orr	w8, w8, w9, lsr #1
     a58:      	and	w8, w8, #0xff
     a5c:      	str	w8, [sp, #0x31c]
     a60:      	ldr	w9, [sp, #0x360]
     a64:      	ldr	w8, [sp, #0x35c]
     a68:      	lsl	w8, w8, #7
     a6c:      	orr	w8, w8, w9, lsr #1
     a70:      	and	w8, w8, #0xff
     a74:      	str	w8, [sp, #0x318]
     a78:      	ldr	w9, [sp, #0x35c]
     a7c:      	ldr	w8, [sp, #0x358]
     a80:      	lsl	w8, w8, #7
     a84:      	orr	w8, w8, w9, lsr #1
     a88:      	and	w8, w8, #0xff
     a8c:      	str	w8, [sp, #0x314]
     a90:      	ldr	w8, [sp, #0x358]
     a94:      	lsr	w8, w8, #1
     a98:      	and	w8, w8, #0xff
     a9c:      	str	w8, [sp, #0x310]
     aa0:      	ldr	w8, [sp, #0x344]
     aa4:      	mov	w11, #0x20              // =32
     aa8:      	and	w8, w11, w8
     aac:      	str	w8, [sp, #0x30c]
     ab0:      	ldr	w8, [sp, #0x338]
     ab4:      	mov	w10, #0x83              // =131
     ab8:      	and	w8, w10, w8
     abc:      	str	w8, [sp, #0x308]
     ac0:      	ldr	w8, [sp, #0x32c]
     ac4:      	mov	w9, #0xb8               // =184
     ac8:      	and	w8, w9, w8
     acc:      	str	w8, [sp, #0x304]
     ad0:      	ldr	w13, [sp, #0x320]
     ad4:      	mov	w8, #0xed               // =237
     ad8:      	and	w13, w8, w13
     adc:      	str	w13, [sp, #0x300]
     ae0:      	ldr	w13, [sp, #0x31c]
     ae4:      	ldr	w14, [sp, #0x30c]
     ae8:      	eor	w13, w13, w14
     aec:      	str	w13, [sp, #0x2fc]
     af0:      	ldr	w13, [sp, #0x318]
     af4:      	ldr	w14, [sp, #0x308]
     af8:      	eor	w13, w13, w14
     afc:      	str	w13, [sp, #0x2f8]
     b00:      	ldr	w13, [sp, #0x314]
     b04:      	ldr	w14, [sp, #0x304]
     b08:      	eor	w13, w13, w14
     b0c:      	str	w13, [sp, #0x2f4]
     b10:      	ldr	w13, [sp, #0x310]
     b14:      	ldr	w14, [sp, #0x300]
     b18:      	eor	w13, w13, w14
     b1c:      	str	w13, [sp, #0x2f0]
     b20:      	ldr	w13, [sp, #0x2fc]
     b24:      	and	w13, w13, #0x1
     b28:      	str	w13, [sp, #0x2ec]
     b2c:      	ldr	w13, [sp, #0x2f8]
     b30:      	and	w13, w13, w12
     b34:      	str	w13, [sp, #0x2e8]
     b38:      	ldr	w13, [sp, #0x2f4]
     b3c:      	and	w13, w13, w12
     b40:      	str	w13, [sp, #0x2e4]
     b44:      	ldr	w13, [sp, #0x2f0]
     b48:      	and	w13, w13, w12
     b4c:      	str	w13, [sp, #0x2e0]
     b50:      	ldr	w13, [sp, #0x2ec]
     b54:      	subs	w13, w12, w13
     b58:      	and	w13, w13, #0xff
     b5c:      	str	w13, [sp, #0x2dc]
     b60:      	ldr	w13, [sp, #0x2ec]
     b64:      	subs	w13, w12, w13
     b68:      	cset	w13, lo
     b6c:      	str	w13, [sp, #0x2d8]
     b70:      	ldr	w13, [sp, #0x2e8]
     b74:      	ldr	w14, [sp, #0x2d8]
     b78:      	add	w13, w13, w14
     b7c:      	str	w13, [sp, #0x2d4]
     b80:      	ldr	w13, [sp, #0x2d4]
     b84:      	subs	w13, w12, w13
     b88:      	and	w13, w13, #0xff
     b8c:      	str	w13, [sp, #0x2d0]
     b90:      	ldr	w13, [sp, #0x2d4]
     b94:      	subs	w13, w12, w13
     b98:      	cset	w13, lo
     b9c:      	str	w13, [sp, #0x2cc]
     ba0:      	ldr	w13, [sp, #0x2e4]
     ba4:      	ldr	w14, [sp, #0x2cc]
     ba8:      	add	w13, w13, w14
     bac:      	str	w13, [sp, #0x2c8]
     bb0:      	ldr	w13, [sp, #0x2c8]
     bb4:      	subs	w13, w12, w13
     bb8:      	and	w13, w13, #0xff
     bbc:      	str	w13, [sp, #0x2c4]
     bc0:      	ldr	w13, [sp, #0x2c8]
     bc4:      	subs	w13, w12, w13
     bc8:      	cset	w13, lo
     bcc:      	str	w13, [sp, #0x2c0]
     bd0:      	ldr	w13, [sp, #0x2e0]
     bd4:      	ldr	w14, [sp, #0x2c0]
     bd8:      	add	w13, w13, w14
     bdc:      	str	w13, [sp, #0x2bc]
     be0:      	ldr	w13, [sp, #0x2bc]
     be4:      	subs	w13, w12, w13
     be8:      	and	w13, w13, #0xff
     bec:      	str	w13, [sp, #0x2b8]
     bf0:      	ldr	w14, [sp, #0x2fc]
     bf4:      	ldr	w13, [sp, #0x2f8]
     bf8:      	lsl	w13, w13, #7
     bfc:      	orr	w13, w13, w14, lsr #1
     c00:      	and	w13, w13, #0xff
     c04:      	str	w13, [sp, #0x2b4]
     c08:      	ldr	w14, [sp, #0x2f8]
     c0c:      	ldr	w13, [sp, #0x2f4]
     c10:      	lsl	w13, w13, #7
     c14:      	orr	w13, w13, w14, lsr #1
     c18:      	and	w13, w13, #0xff
     c1c:      	str	w13, [sp, #0x2b0]
     c20:      	ldr	w14, [sp, #0x2f4]
     c24:      	ldr	w13, [sp, #0x2f0]
     c28:      	lsl	w13, w13, #7
     c2c:      	orr	w13, w13, w14, lsr #1
     c30:      	and	w13, w13, #0xff
     c34:      	str	w13, [sp, #0x2ac]
     c38:      	ldr	w13, [sp, #0x2f0]
     c3c:      	lsr	w13, w13, #1
     c40:      	and	w13, w13, #0xff
     c44:      	str	w13, [sp, #0x2a8]
     c48:      	ldr	w13, [sp, #0x2dc]
     c4c:      	and	w13, w11, w13
     c50:      	str	w13, [sp, #0x2a4]
     c54:      	ldr	w13, [sp, #0x2d0]
     c58:      	and	w13, w10, w13
     c5c:      	str	w13, [sp, #0x2a0]
     c60:      	ldr	w13, [sp, #0x2c4]
     c64:      	and	w13, w9, w13
     c68:      	str	w13, [sp, #0x29c]
     c6c:      	ldr	w13, [sp, #0x2b8]
     c70:      	and	w13, w8, w13
     c74:      	str	w13, [sp, #0x298]
     c78:      	ldr	w13, [sp, #0x2b4]
     c7c:      	ldr	w14, [sp, #0x2a4]
     c80:      	eor	w13, w13, w14
     c84:      	str	w13, [sp, #0x294]
     c88:      	ldr	w13, [sp, #0x2b0]
     c8c:      	ldr	w14, [sp, #0x2a0]
     c90:      	eor	w13, w13, w14
     c94:      	str	w13, [sp, #0x290]
     c98:      	ldr	w13, [sp, #0x2ac]
     c9c:      	ldr	w14, [sp, #0x29c]
     ca0:      	eor	w13, w13, w14
     ca4:      	str	w13, [sp, #0x28c]
     ca8:      	ldr	w13, [sp, #0x2a8]
     cac:      	ldr	w14, [sp, #0x298]
     cb0:      	eor	w13, w13, w14
     cb4:      	str	w13, [sp, #0x288]
     cb8:      	ldr	w13, [sp, #0x294]
     cbc:      	and	w13, w13, #0x1
     cc0:      	str	w13, [sp, #0x284]
     cc4:      	ldr	w13, [sp, #0x290]
     cc8:      	and	w13, w13, w12
     ccc:      	str	w13, [sp, #0x280]
     cd0:      	ldr	w13, [sp, #0x28c]
     cd4:      	and	w13, w13, w12
     cd8:      	str	w13, [sp, #0x27c]
     cdc:      	ldr	w13, [sp, #0x288]
     ce0:      	and	w13, w13, w12
     ce4:      	str	w13, [sp, #0x278]
     ce8:      	ldr	w13, [sp, #0x284]
     cec:      	subs	w13, w12, w13
     cf0:      	and	w13, w13, #0xff
     cf4:      	str	w13, [sp, #0x274]
     cf8:      	ldr	w13, [sp, #0x284]
     cfc:      	subs	w13, w12, w13
     d00:      	cset	w13, lo
     d04:      	str	w13, [sp, #0x270]
     d08:      	ldr	w13, [sp, #0x280]
     d0c:      	ldr	w14, [sp, #0x270]
     d10:      	add	w13, w13, w14
     d14:      	str	w13, [sp, #0x26c]
     d18:      	ldr	w13, [sp, #0x26c]
     d1c:      	subs	w13, w12, w13
     d20:      	and	w13, w13, #0xff
     d24:      	str	w13, [sp, #0x268]
     d28:      	ldr	w13, [sp, #0x26c]
     d2c:      	subs	w13, w12, w13
     d30:      	cset	w13, lo
     d34:      	str	w13, [sp, #0x264]
     d38:      	ldr	w13, [sp, #0x27c]
     d3c:      	ldr	w14, [sp, #0x264]
     d40:      	add	w13, w13, w14
     d44:      	str	w13, [sp, #0x260]
     d48:      	ldr	w13, [sp, #0x260]
     d4c:      	subs	w13, w12, w13
     d50:      	and	w13, w13, #0xff
     d54:      	str	w13, [sp, #0x25c]
     d58:      	ldr	w13, [sp, #0x260]
     d5c:      	subs	w13, w12, w13
     d60:      	cset	w13, lo
     d64:      	str	w13, [sp, #0x258]
     d68:      	ldr	w13, [sp, #0x278]
     d6c:      	ldr	w14, [sp, #0x258]
     d70:      	add	w13, w13, w14
     d74:      	str	w13, [sp, #0x254]
     d78:      	ldr	w13, [sp, #0x254]
     d7c:      	subs	w13, w12, w13
     d80:      	and	w13, w13, #0xff
     d84:      	str	w13, [sp, #0x250]
     d88:      	ldr	w14, [sp, #0x294]
     d8c:      	ldr	w13, [sp, #0x290]
     d90:      	lsl	w13, w13, #7
     d94:      	orr	w13, w13, w14, lsr #1
     d98:      	and	w13, w13, #0xff
     d9c:      	str	w13, [sp, #0x24c]
     da0:      	ldr	w14, [sp, #0x290]
     da4:      	ldr	w13, [sp, #0x28c]
     da8:      	lsl	w13, w13, #7
     dac:      	orr	w13, w13, w14, lsr #1
     db0:      	and	w13, w13, #0xff
     db4:      	str	w13, [sp, #0x248]
     db8:      	ldr	w14, [sp, #0x28c]
     dbc:      	ldr	w13, [sp, #0x288]
     dc0:      	lsl	w13, w13, #7
     dc4:      	orr	w13, w13, w14, lsr #1
     dc8:      	and	w13, w13, #0xff
     dcc:      	str	w13, [sp, #0x244]
     dd0:      	ldr	w13, [sp, #0x288]
     dd4:      	lsr	w13, w13, #1
     dd8:      	and	w13, w13, #0xff
     ddc:      	str	w13, [sp, #0x240]
     de0:      	ldr	w13, [sp, #0x274]
     de4:      	and	w13, w11, w13
     de8:      	str	w13, [sp, #0x23c]
     dec:      	ldr	w13, [sp, #0x268]
     df0:      	and	w13, w10, w13
     df4:      	str	w13, [sp, #0x238]
     df8:      	ldr	w13, [sp, #0x25c]
     dfc:      	and	w13, w9, w13
     e00:      	str	w13, [sp, #0x234]
     e04:      	ldr	w13, [sp, #0x250]
     e08:      	and	w13, w8, w13
     e0c:      	str	w13, [sp, #0x230]
     e10:      	ldr	w13, [sp, #0x24c]
     e14:      	ldr	w14, [sp, #0x23c]
     e18:      	eor	w13, w13, w14
     e1c:      	str	w13, [sp, #0x22c]
     e20:      	ldr	w13, [sp, #0x248]
     e24:      	ldr	w14, [sp, #0x238]
     e28:      	eor	w13, w13, w14
     e2c:      	str	w13, [sp, #0x228]
     e30:      	ldr	w13, [sp, #0x244]
     e34:      	ldr	w14, [sp, #0x234]
     e38:      	eor	w13, w13, w14
     e3c:      	str	w13, [sp, #0x224]
     e40:      	ldr	w13, [sp, #0x240]
     e44:      	ldr	w14, [sp, #0x230]
     e48:      	eor	w13, w13, w14
     e4c:      	str	w13, [sp, #0x220]
     e50:      	ldr	w13, [sp, #0x22c]
     e54:      	and	w13, w13, #0x1
     e58:      	str	w13, [sp, #0x21c]
     e5c:      	ldr	w13, [sp, #0x228]
     e60:      	and	w13, w13, w12
     e64:      	str	w13, [sp, #0x218]
     e68:      	ldr	w13, [sp, #0x224]
     e6c:      	and	w13, w13, w12
     e70:      	str	w13, [sp, #0x214]
     e74:      	ldr	w13, [sp, #0x220]
     e78:      	and	w13, w13, w12
     e7c:      	str	w13, [sp, #0x210]
     e80:      	ldr	w13, [sp, #0x21c]
     e84:      	subs	w13, w12, w13
     e88:      	and	w13, w13, #0xff
     e8c:      	str	w13, [sp, #0x20c]
     e90:      	ldr	w13, [sp, #0x21c]
     e94:      	subs	w13, w12, w13
     e98:      	cset	w13, lo
     e9c:      	str	w13, [sp, #0x208]
     ea0:      	ldr	w13, [sp, #0x218]
     ea4:      	ldr	w14, [sp, #0x208]
     ea8:      	add	w13, w13, w14
     eac:      	str	w13, [sp, #0x204]
     eb0:      	ldr	w13, [sp, #0x204]
     eb4:      	subs	w13, w12, w13
     eb8:      	and	w13, w13, #0xff
     ebc:      	str	w13, [sp, #0x200]
     ec0:      	ldr	w13, [sp, #0x204]
     ec4:      	subs	w13, w12, w13
     ec8:      	cset	w13, lo
     ecc:      	str	w13, [sp, #0x1fc]
     ed0:      	ldr	w13, [sp, #0x214]
     ed4:      	ldr	w14, [sp, #0x1fc]
     ed8:      	add	w13, w13, w14
     edc:      	str	w13, [sp, #0x1f8]
     ee0:      	ldr	w13, [sp, #0x1f8]
     ee4:      	subs	w13, w12, w13
     ee8:      	and	w13, w13, #0xff
     eec:      	str	w13, [sp, #0x1f4]
     ef0:      	ldr	w13, [sp, #0x1f8]
     ef4:      	subs	w13, w12, w13
     ef8:      	cset	w13, lo
     efc:      	str	w13, [sp, #0x1f0]
     f00:      	ldr	w13, [sp, #0x210]
     f04:      	ldr	w14, [sp, #0x1f0]
     f08:      	add	w13, w13, w14
     f0c:      	str	w13, [sp, #0x1ec]
     f10:      	ldr	w13, [sp, #0x1ec]
     f14:      	subs	w13, w12, w13
     f18:      	and	w13, w13, #0xff
     f1c:      	str	w13, [sp, #0x1e8]
     f20:      	ldr	w14, [sp, #0x22c]
     f24:      	ldr	w13, [sp, #0x228]
     f28:      	lsl	w13, w13, #7
     f2c:      	orr	w13, w13, w14, lsr #1
     f30:      	and	w13, w13, #0xff
     f34:      	str	w13, [sp, #0x1e4]
     f38:      	ldr	w14, [sp, #0x228]
     f3c:      	ldr	w13, [sp, #0x224]
     f40:      	lsl	w13, w13, #7
     f44:      	orr	w13, w13, w14, lsr #1
     f48:      	and	w13, w13, #0xff
     f4c:      	str	w13, [sp, #0x1e0]
     f50:      	ldr	w14, [sp, #0x224]
     f54:      	ldr	w13, [sp, #0x220]
     f58:      	lsl	w13, w13, #7
     f5c:      	orr	w13, w13, w14, lsr #1
     f60:      	and	w13, w13, #0xff
     f64:      	str	w13, [sp, #0x1dc]
     f68:      	ldr	w13, [sp, #0x220]
     f6c:      	lsr	w13, w13, #1
     f70:      	and	w13, w13, #0xff
     f74:      	str	w13, [sp, #0x1d8]
     f78:      	ldr	w13, [sp, #0x20c]
     f7c:      	and	w13, w11, w13
     f80:      	str	w13, [sp, #0x1d4]
     f84:      	ldr	w13, [sp, #0x200]
     f88:      	and	w13, w10, w13
     f8c:      	str	w13, [sp, #0x1d0]
     f90:      	ldr	w13, [sp, #0x1f4]
     f94:      	and	w13, w9, w13
     f98:      	str	w13, [sp, #0x1cc]
     f9c:      	ldr	w13, [sp, #0x1e8]
     fa0:      	and	w13, w8, w13
     fa4:      	str	w13, [sp, #0x1c8]
     fa8:      	ldr	w13, [sp, #0x1e4]
     fac:      	ldr	w14, [sp, #0x1d4]
     fb0:      	eor	w13, w13, w14
     fb4:      	str	w13, [sp, #0x1c4]
     fb8:      	ldr	w13, [sp, #0x1e0]
     fbc:      	ldr	w14, [sp, #0x1d0]
     fc0:      	eor	w13, w13, w14
     fc4:      	str	w13, [sp, #0x1c0]
     fc8:      	ldr	w13, [sp, #0x1dc]
     fcc:      	ldr	w14, [sp, #0x1cc]
     fd0:      	eor	w13, w13, w14
     fd4:      	str	w13, [sp, #0x1bc]
     fd8:      	ldr	w13, [sp, #0x1d8]
     fdc:      	ldr	w14, [sp, #0x1c8]
     fe0:      	eor	w13, w13, w14
     fe4:      	str	w13, [sp, #0x1b8]
     fe8:      	ldr	w13, [sp, #0x1c4]
     fec:      	and	w13, w13, #0x1
     ff0:      	str	w13, [sp, #0x1b4]
     ff4:      	ldr	w13, [sp, #0x1c0]
     ff8:      	and	w13, w13, w12
     ffc:      	str	w13, [sp, #0x1b0]
    1000:      	ldr	w13, [sp, #0x1bc]
    1004:      	and	w13, w13, w12
    1008:      	str	w13, [sp, #0x1ac]
    100c:      	ldr	w13, [sp, #0x1b8]
    1010:      	and	w13, w13, w12
    1014:      	str	w13, [sp, #0x1a8]
    1018:      	ldr	w13, [sp, #0x1b4]
    101c:      	subs	w13, w12, w13
    1020:      	and	w13, w13, #0xff
    1024:      	str	w13, [sp, #0x1a4]
    1028:      	ldr	w13, [sp, #0x1b4]
    102c:      	subs	w13, w12, w13
    1030:      	cset	w13, lo
    1034:      	str	w13, [sp, #0x1a0]
    1038:      	ldr	w13, [sp, #0x1b0]
    103c:      	ldr	w14, [sp, #0x1a0]
    1040:      	add	w13, w13, w14
    1044:      	str	w13, [sp, #0x19c]
    1048:      	ldr	w13, [sp, #0x19c]
    104c:      	subs	w13, w12, w13
    1050:      	and	w13, w13, #0xff
    1054:      	str	w13, [sp, #0x198]
    1058:      	ldr	w13, [sp, #0x19c]
    105c:      	subs	w13, w12, w13
    1060:      	cset	w13, lo
    1064:      	str	w13, [sp, #0x194]
    1068:      	ldr	w13, [sp, #0x1ac]
    106c:      	ldr	w14, [sp, #0x194]
    1070:      	add	w13, w13, w14
    1074:      	str	w13, [sp, #0x190]
    1078:      	ldr	w13, [sp, #0x190]
    107c:      	subs	w13, w12, w13
    1080:      	and	w13, w13, #0xff
    1084:      	str	w13, [sp, #0x18c]
    1088:      	ldr	w13, [sp, #0x190]
    108c:      	subs	w13, w12, w13
    1090:      	cset	w13, lo
    1094:      	str	w13, [sp, #0x188]
    1098:      	ldr	w13, [sp, #0x1a8]
    109c:      	ldr	w14, [sp, #0x188]
    10a0:      	add	w13, w13, w14
    10a4:      	str	w13, [sp, #0x184]
    10a8:      	ldr	w13, [sp, #0x184]
    10ac:      	subs	w13, w12, w13
    10b0:      	and	w13, w13, #0xff
    10b4:      	str	w13, [sp, #0x180]
    10b8:      	ldr	w14, [sp, #0x1c4]
    10bc:      	ldr	w13, [sp, #0x1c0]
    10c0:      	lsl	w13, w13, #7
    10c4:      	orr	w13, w13, w14, lsr #1
    10c8:      	and	w13, w13, #0xff
    10cc:      	str	w13, [sp, #0x17c]
    10d0:      	ldr	w14, [sp, #0x1c0]
    10d4:      	ldr	w13, [sp, #0x1bc]
    10d8:      	lsl	w13, w13, #7
    10dc:      	orr	w13, w13, w14, lsr #1
    10e0:      	and	w13, w13, #0xff
    10e4:      	str	w13, [sp, #0x178]
    10e8:      	ldr	w14, [sp, #0x1bc]
    10ec:      	ldr	w13, [sp, #0x1b8]
    10f0:      	lsl	w13, w13, #7
    10f4:      	orr	w13, w13, w14, lsr #1
    10f8:      	and	w13, w13, #0xff
    10fc:      	str	w13, [sp, #0x174]
    1100:      	ldr	w13, [sp, #0x1b8]
    1104:      	lsr	w13, w13, #1
    1108:      	and	w13, w13, #0xff
    110c:      	str	w13, [sp, #0x170]
    1110:      	ldr	w13, [sp, #0x1a4]
    1114:      	and	w13, w11, w13
    1118:      	str	w13, [sp, #0x16c]
    111c:      	ldr	w13, [sp, #0x198]
    1120:      	and	w13, w10, w13
    1124:      	str	w13, [sp, #0x168]
    1128:      	ldr	w13, [sp, #0x18c]
    112c:      	and	w13, w9, w13
    1130:      	str	w13, [sp, #0x164]
    1134:      	ldr	w13, [sp, #0x180]
    1138:      	and	w13, w8, w13
    113c:      	str	w13, [sp, #0x160]
    1140:      	ldr	w13, [sp, #0x17c]
    1144:      	ldr	w14, [sp, #0x16c]
    1148:      	eor	w13, w13, w14
    114c:      	str	w13, [sp, #0x15c]
    1150:      	ldr	w13, [sp, #0x178]
    1154:      	ldr	w14, [sp, #0x168]
    1158:      	eor	w13, w13, w14
    115c:      	str	w13, [sp, #0x158]
    1160:      	ldr	w13, [sp, #0x174]
    1164:      	ldr	w14, [sp, #0x164]
    1168:      	eor	w13, w13, w14
    116c:      	str	w13, [sp, #0x154]
    1170:      	ldr	w13, [sp, #0x170]
    1174:      	ldr	w14, [sp, #0x160]
    1178:      	eor	w13, w13, w14
    117c:      	str	w13, [sp, #0x150]
    1180:      	ldr	w13, [sp, #0x15c]
    1184:      	and	w13, w13, #0x1
    1188:      	str	w13, [sp, #0x14c]
    118c:      	ldr	w13, [sp, #0x158]
    1190:      	and	w13, w13, w12
    1194:      	str	w13, [sp, #0x148]
    1198:      	ldr	w13, [sp, #0x154]
    119c:      	and	w13, w13, w12
    11a0:      	str	w13, [sp, #0x144]
    11a4:      	ldr	w13, [sp, #0x150]
    11a8:      	and	w13, w13, w12
    11ac:      	str	w13, [sp, #0x140]
    11b0:      	ldr	w13, [sp, #0x14c]
    11b4:      	subs	w13, w12, w13
    11b8:      	and	w13, w13, #0xff
    11bc:      	str	w13, [sp, #0x13c]
    11c0:      	ldr	w13, [sp, #0x14c]
    11c4:      	subs	w13, w12, w13
    11c8:      	cset	w13, lo
    11cc:      	str	w13, [sp, #0x138]
    11d0:      	ldr	w13, [sp, #0x148]
    11d4:      	ldr	w14, [sp, #0x138]
    11d8:      	add	w13, w13, w14
    11dc:      	str	w13, [sp, #0x134]
    11e0:      	ldr	w13, [sp, #0x134]
    11e4:      	subs	w13, w12, w13
    11e8:      	and	w13, w13, #0xff
    11ec:      	str	w13, [sp, #0x130]
    11f0:      	ldr	w13, [sp, #0x134]
    11f4:      	subs	w13, w12, w13
    11f8:      	cset	w13, lo
    11fc:      	str	w13, [sp, #0x12c]
    1200:      	ldr	w13, [sp, #0x144]
    1204:      	ldr	w14, [sp, #0x12c]
    1208:      	add	w13, w13, w14
    120c:      	str	w13, [sp, #0x128]
    1210:      	ldr	w13, [sp, #0x128]
    1214:      	subs	w13, w12, w13
    1218:      	and	w13, w13, #0xff
    121c:      	str	w13, [sp, #0x124]
    1220:      	ldr	w13, [sp, #0x128]
    1224:      	subs	w13, w12, w13
    1228:      	cset	w13, lo
    122c:      	str	w13, [sp, #0x120]
    1230:      	ldr	w13, [sp, #0x140]
    1234:      	ldr	w14, [sp, #0x120]
    1238:      	add	w13, w13, w14
    123c:      	str	w13, [sp, #0x11c]
    1240:      	ldr	w13, [sp, #0x11c]
    1244:      	subs	w13, w12, w13
    1248:      	and	w13, w13, #0xff
    124c:      	str	w13, [sp, #0x118]
    1250:      	ldr	w14, [sp, #0x15c]
    1254:      	ldr	w13, [sp, #0x158]
    1258:      	lsl	w13, w13, #7
    125c:      	orr	w13, w13, w14, lsr #1
    1260:      	and	w13, w13, #0xff
    1264:      	str	w13, [sp, #0x114]
    1268:      	ldr	w14, [sp, #0x158]
    126c:      	ldr	w13, [sp, #0x154]
    1270:      	lsl	w13, w13, #7
    1274:      	orr	w13, w13, w14, lsr #1
    1278:      	and	w13, w13, #0xff
    127c:      	str	w13, [sp, #0x110]
    1280:      	ldr	w14, [sp, #0x154]
    1284:      	ldr	w13, [sp, #0x150]
    1288:      	lsl	w13, w13, #7
    128c:      	orr	w13, w13, w14, lsr #1
    1290:      	and	w13, w13, #0xff
    1294:      	str	w13, [sp, #0x10c]
    1298:      	ldr	w13, [sp, #0x150]
    129c:      	lsr	w13, w13, #1
    12a0:      	and	w13, w13, #0xff
    12a4:      	str	w13, [sp, #0x108]
    12a8:      	ldr	w13, [sp, #0x13c]
    12ac:      	and	w13, w11, w13
    12b0:      	str	w13, [sp, #0x104]
    12b4:      	ldr	w13, [sp, #0x130]
    12b8:      	and	w13, w10, w13
    12bc:      	str	w13, [sp, #0x100]
    12c0:      	ldr	w13, [sp, #0x124]
    12c4:      	and	w13, w9, w13
    12c8:      	str	w13, [sp, #0xfc]
    12cc:      	ldr	w13, [sp, #0x118]
    12d0:      	and	w13, w8, w13
    12d4:      	str	w13, [sp, #0xf8]
    12d8:      	ldr	w13, [sp, #0x114]
    12dc:      	ldr	w14, [sp, #0x104]
    12e0:      	eor	w13, w13, w14
    12e4:      	str	w13, [sp, #0xf4]
    12e8:      	ldr	w13, [sp, #0x110]
    12ec:      	ldr	w14, [sp, #0x100]
    12f0:      	eor	w13, w13, w14
    12f4:      	str	w13, [sp, #0xf0]
    12f8:      	ldr	w13, [sp, #0x10c]
    12fc:      	ldr	w14, [sp, #0xfc]
    1300:      	eor	w13, w13, w14
    1304:      	str	w13, [sp, #0xec]
    1308:      	ldr	w13, [sp, #0x108]
    130c:      	ldr	w14, [sp, #0xf8]
    1310:      	eor	w13, w13, w14
    1314:      	str	w13, [sp, #0xe8]
    1318:      	ldr	w13, [sp, #0xf4]
    131c:      	and	w13, w13, #0x1
    1320:      	str	w13, [sp, #0xe4]
    1324:      	ldr	w13, [sp, #0xf0]
    1328:      	and	w13, w13, w12
    132c:      	str	w13, [sp, #0xe0]
    1330:      	ldr	w13, [sp, #0xec]
    1334:      	and	w13, w13, w12
    1338:      	str	w13, [sp, #0xdc]
    133c:      	ldr	w13, [sp, #0xe8]
    1340:      	and	w13, w13, w12
    1344:      	str	w13, [sp, #0xd8]
    1348:      	ldr	w13, [sp, #0xe4]
    134c:      	subs	w13, w12, w13
    1350:      	and	w13, w13, #0xff
    1354:      	str	w13, [sp, #0xd4]
    1358:      	ldr	w13, [sp, #0xe4]
    135c:      	subs	w13, w12, w13
    1360:      	cset	w13, lo
    1364:      	str	w13, [sp, #0xd0]
    1368:      	ldr	w13, [sp, #0xe0]
    136c:      	ldr	w14, [sp, #0xd0]
    1370:      	add	w13, w13, w14
    1374:      	str	w13, [sp, #0xcc]
    1378:      	ldr	w13, [sp, #0xcc]
    137c:      	subs	w13, w12, w13
    1380:      	and	w13, w13, #0xff
    1384:      	str	w13, [sp, #0xc8]
    1388:      	ldr	w13, [sp, #0xcc]
    138c:      	subs	w13, w12, w13
    1390:      	cset	w13, lo
    1394:      	str	w13, [sp, #0xc4]
    1398:      	ldr	w13, [sp, #0xdc]
    139c:      	ldr	w14, [sp, #0xc4]
    13a0:      	add	w13, w13, w14
    13a4:      	str	w13, [sp, #0xc0]
    13a8:      	ldr	w13, [sp, #0xc0]
    13ac:      	subs	w13, w12, w13
    13b0:      	and	w13, w13, #0xff
    13b4:      	str	w13, [sp, #0xbc]
    13b8:      	ldr	w13, [sp, #0xc0]
    13bc:      	subs	w13, w12, w13
    13c0:      	cset	w13, lo
    13c4:      	str	w13, [sp, #0xb8]
    13c8:      	ldr	w13, [sp, #0xd8]
    13cc:      	ldr	w14, [sp, #0xb8]
    13d0:      	add	w13, w13, w14
    13d4:      	str	w13, [sp, #0xb4]
    13d8:      	ldr	w13, [sp, #0xb4]
    13dc:      	subs	w13, w12, w13
    13e0:      	and	w13, w13, #0xff
    13e4:      	str	w13, [sp, #0xb0]
    13e8:      	ldr	w14, [sp, #0xf4]
    13ec:      	ldr	w13, [sp, #0xf0]
    13f0:      	lsl	w13, w13, #7
    13f4:      	orr	w13, w13, w14, lsr #1
    13f8:      	and	w13, w13, #0xff
    13fc:      	str	w13, [sp, #0xac]
    1400:      	ldr	w14, [sp, #0xf0]
    1404:      	ldr	w13, [sp, #0xec]
    1408:      	lsl	w13, w13, #7
    140c:      	orr	w13, w13, w14, lsr #1
    1410:      	and	w13, w13, #0xff
    1414:      	str	w13, [sp, #0xa8]
    1418:      	ldr	w14, [sp, #0xec]
    141c:      	ldr	w13, [sp, #0xe8]
    1420:      	lsl	w13, w13, #7
    1424:      	orr	w13, w13, w14, lsr #1
    1428:      	and	w13, w13, #0xff
    142c:      	str	w13, [sp, #0xa4]
    1430:      	ldr	w13, [sp, #0xe8]
    1434:      	lsr	w13, w13, #1
    1438:      	and	w13, w13, #0xff
    143c:      	str	w13, [sp, #0xa0]
    1440:      	ldr	w13, [sp, #0xd4]
    1444:      	and	w13, w11, w13
    1448:      	str	w13, [sp, #0x9c]
    144c:      	ldr	w13, [sp, #0xc8]
    1450:      	and	w13, w10, w13
    1454:      	str	w13, [sp, #0x98]
    1458:      	ldr	w13, [sp, #0xbc]
    145c:      	and	w13, w9, w13
    1460:      	str	w13, [sp, #0x94]
    1464:      	ldr	w13, [sp, #0xb0]
    1468:      	and	w13, w8, w13
    146c:      	str	w13, [sp, #0x90]
    1470:      	ldr	w13, [sp, #0xac]
    1474:      	ldr	w14, [sp, #0x9c]
    1478:      	eor	w13, w13, w14
    147c:      	str	w13, [sp, #0x8c]
    1480:      	ldr	w13, [sp, #0xa8]
    1484:      	ldr	w14, [sp, #0x98]
    1488:      	eor	w13, w13, w14
    148c:      	str	w13, [sp, #0x88]
    1490:      	ldr	w13, [sp, #0xa4]
    1494:      	ldr	w14, [sp, #0x94]
    1498:      	eor	w13, w13, w14
    149c:      	str	w13, [sp, #0x84]
    14a0:      	ldr	w13, [sp, #0xa0]
    14a4:      	ldr	w14, [sp, #0x90]
    14a8:      	eor	w13, w13, w14
    14ac:      	str	w13, [sp, #0x80]
    14b0:      	ldr	w13, [sp, #0x8c]
    14b4:      	and	w13, w13, #0x1
    14b8:      	str	w13, [sp, #0x7c]
    14bc:      	ldr	w13, [sp, #0x88]
    14c0:      	and	w13, w13, w12
    14c4:      	str	w13, [sp, #0x78]
    14c8:      	ldr	w13, [sp, #0x84]
    14cc:      	and	w13, w13, w12
    14d0:      	str	w13, [sp, #0x74]
    14d4:      	ldr	w13, [sp, #0x80]
    14d8:      	and	w13, w13, w12
    14dc:      	str	w13, [sp, #0x70]
    14e0:      	ldr	w13, [sp, #0x7c]
    14e4:      	subs	w13, w12, w13
    14e8:      	and	w13, w13, #0xff
    14ec:      	str	w13, [sp, #0x6c]
    14f0:      	ldr	w13, [sp, #0x7c]
    14f4:      	subs	w13, w12, w13
    14f8:      	cset	w13, lo
    14fc:      	str	w13, [sp, #0x68]
    1500:      	ldr	w13, [sp, #0x78]
    1504:      	ldr	w14, [sp, #0x68]
    1508:      	add	w13, w13, w14
    150c:      	str	w13, [sp, #0x64]
    1510:      	ldr	w13, [sp, #0x64]
    1514:      	subs	w13, w12, w13
    1518:      	and	w13, w13, #0xff
    151c:      	str	w13, [sp, #0x60]
    1520:      	ldr	w13, [sp, #0x64]
    1524:      	subs	w13, w12, w13
    1528:      	cset	w13, lo
    152c:      	str	w13, [sp, #0x5c]
    1530:      	ldr	w13, [sp, #0x74]
    1534:      	ldr	w14, [sp, #0x5c]
    1538:      	add	w13, w13, w14
    153c:      	str	w13, [sp, #0x58]
    1540:      	ldr	w13, [sp, #0x58]
    1544:      	subs	w13, w12, w13
    1548:      	and	w13, w13, #0xff
    154c:      	str	w13, [sp, #0x54]
    1550:      	ldr	w13, [sp, #0x58]
    1554:      	subs	w13, w12, w13
    1558:      	cset	w13, lo
    155c:      	str	w13, [sp, #0x50]
    1560:      	ldr	w13, [sp, #0x70]
    1564:      	ldr	w14, [sp, #0x50]
    1568:      	add	w13, w13, w14
    156c:      	str	w13, [sp, #0x4c]
    1570:      	ldr	w13, [sp, #0x4c]
    1574:      	subs	w12, w12, w13
    1578:      	and	w12, w12, #0xff
    157c:      	str	w12, [sp, #0x48]
    1580:      	ldr	w13, [sp, #0x8c]
    1584:      	ldr	w12, [sp, #0x88]
    1588:      	lsl	w12, w12, #7
    158c:      	orr	w12, w12, w13, lsr #1
    1590:      	and	w12, w12, #0xff
    1594:      	str	w12, [sp, #0x44]
    1598:      	ldr	w13, [sp, #0x88]
    159c:      	ldr	w12, [sp, #0x84]
    15a0:      	lsl	w12, w12, #7
    15a4:      	orr	w12, w12, w13, lsr #1
    15a8:      	and	w12, w12, #0xff
    15ac:      	str	w12, [sp, #0x40]
    15b0:      	ldr	w13, [sp, #0x84]
    15b4:      	ldr	w12, [sp, #0x80]
    15b8:      	lsl	w12, w12, #7
    15bc:      	orr	w12, w12, w13, lsr #1
    15c0:      	and	w12, w12, #0xff
    15c4:      	str	w12, [sp, #0x3c]
    15c8:      	ldr	w12, [sp, #0x80]
    15cc:      	lsr	w12, w12, #1
    15d0:      	and	w12, w12, #0xff
    15d4:      	str	w12, [sp, #0x38]
    15d8:      	ldr	w12, [sp, #0x6c]
    15dc:      	and	w11, w11, w12
    15e0:      	str	w11, [sp, #0x34]
    15e4:      	ldr	w11, [sp, #0x60]
    15e8:      	and	w10, w10, w11
    15ec:      	str	w10, [sp, #0x30]
    15f0:      	ldr	w10, [sp, #0x54]
    15f4:      	and	w9, w9, w10
    15f8:      	str	w9, [sp, #0x2c]
    15fc:      	ldr	w9, [sp, #0x48]
    1600:      	and	w8, w8, w9
    1604:      	str	w8, [sp, #0x28]
    1608:      	ldr	w8, [sp, #0x44]
    160c:      	ldr	w9, [sp, #0x34]
    1610:      	eor	w8, w8, w9
    1614:      	str	w8, [sp, #0x24]
    1618:      	ldr	w8, [sp, #0x40]
    161c:      	ldr	w9, [sp, #0x30]
    1620:      	eor	w8, w8, w9
    1624:      	str	w8, [sp, #0x20]
    1628:      	ldr	w8, [sp, #0x3c]
    162c:      	ldr	w9, [sp, #0x2c]
    1630:      	eor	w8, w8, w9
    1634:      	str	w8, [sp, #0x1c]
    1638:      	ldr	w8, [sp, #0x38]
    163c:      	ldr	w9, [sp, #0x28]
    1640:      	eor	w8, w8, w9
    1644:      	str	w8, [sp, #0x18]
    1648:      	ldr	w8, [sp, #0x24]
    164c:      	eor	w8, w8, #0xff
    1650:      	str	w8, [sp, #0x14]
    1654:      	ldr	w8, [sp, #0x20]
    1658:      	eor	w8, w8, #0xff
    165c:      	str	w8, [sp, #0x10]
    1660:      	ldr	w8, [sp, #0x1c]
    1664:      	eor	w8, w8, #0xff
    1668:      	str	w8, [sp, #0xc]
    166c:      	ldr	w8, [sp, #0x18]
    1670:      	eor	w8, w8, #0xff
    1674:      	str	w8, [sp, #0x8]
    1678:      	ldr	w8, [sp, #0x14]
    167c:      	ldr	w9, [sp, #0x10]
    1680:      	orr	w8, w8, w9, lsl #8
    1684:      	ldr	w9, [sp, #0xc]
    1688:      	orr	w8, w8, w9, lsl #16
    168c:      	ldr	w9, [sp, #0x8]
    1690:      	orr	w8, w8, w9, lsl #24
    1694:      	str	w8, [sp, #0x4]
    1698:      	ldr	w0, [sp, #0x4]
    169c:      	add	sp, sp, #0x3b0
    16a0:      	ldr	x29, [sp], #0x10
    16a4:      	ret

00000000000016a8 <main>:
    16a8:      	sub	sp, sp, #0x90
    16ac:      	stp	x29, x30, [sp, #0x80]
    16b0:      	add	x29, sp, #0x80
    16b4:      	stur	wzr, [x29, #-0x4]
    16b8:      	stur	w0, [x29, #-0x8]
    16bc:      	stur	x1, [x29, #-0x10]
    16c0:      	ldur	w8, [x29, #-0x8]
    16c4:      	subs	w8, w8, #0x1
    16c8:      	b.ne	0x171c <main+0x74>
    16cc:      	b	0x16d0 <main+0x28>
    16d0:      	b	0x16d4 <main+0x2c>
    16d4:      	sub	x1, x29, #0x18
    16d8:      	add	x2, x1, #0x4
    16dc:      	adrp	x0, 0x1000 <kernel+0x7a8>
    16e0:      	add	x0, x0, #0x928
    16e4:      	bl	0x710 <__isoc99_scanf@plt>
    16e8:      	subs	w8, w0, #0x2
    16ec:      	b.ne	0x1714 <main+0x6c>
    16f0:      	b	0x16f4 <main+0x4c>
    16f4:      	ldur	w0, [x29, #-0x18]
    16f8:      	ldur	w1, [x29, #-0x14]
    16fc:      	bl	0x858 <kernel>
    1700:      	mov	w1, w0
    1704:      	adrp	x0, 0x1000 <kernel+0x7a8>
    1708:      	add	x0, x0, #0x92d
    170c:      	bl	0x720 <printf@plt>
    1710:      	b	0x16d4 <main+0x2c>
    1714:      	stur	wzr, [x29, #-0x4]
    1718:      	b	0x1890 <main+0x1e8>
    171c:      	ldur	w8, [x29, #-0x8]
    1720:      	subs	w8, w8, #0x3
    1724:      	b.eq	0x1738 <main+0x90>
    1728:      	b	0x172c <main+0x84>
    172c:      	mov	w8, #0x3                // =3
    1730:      	stur	w8, [x29, #-0x4]
    1734:      	b	0x1890 <main+0x1e8>
    1738:      	ldur	x8, [x29, #-0x10]
    173c:      	ldr	x0, [x8, #0x8]
    1740:      	mov	x1, xzr
    1744:      	str	x1, [sp, #0x8]
    1748:      	mov	w2, #0xa                // =10
    174c:      	str	w2, [sp, #0x14]
    1750:      	bl	0x6b0 <strtoul@plt>
    1754:      	ldr	x1, [sp, #0x8]
    1758:      	ldr	w2, [sp, #0x14]
    175c:      	stur	x0, [x29, #-0x20]
    1760:      	ldur	x8, [x29, #-0x10]
    1764:      	ldr	x0, [x8, #0x10]
    1768:      	bl	0x6b0 <strtoul@plt>
    176c:      	mov	w8, w0
    1770:      	stur	w8, [x29, #-0x24]
    1774:      	stur	xzr, [x29, #-0x30]
    1778:      	mov	w0, #0x1                // =1
    177c:      	add	x1, sp, #0x40
    1780:      	bl	0x6e0 <clock_gettime@plt>
    1784:      	cbz	w0, 0x1798 <main+0xf0>
    1788:      	b	0x178c <main+0xe4>
    178c:      	mov	w8, #0x2                // =2
    1790:      	stur	w8, [x29, #-0x4]
    1794:      	b	0x1890 <main+0x1e8>
    1798:      	str	xzr, [sp, #0x28]
    179c:      	b	0x17a0 <main+0xf8>
    17a0:      	ldr	x8, [sp, #0x28]
    17a4:      	ldur	x9, [x29, #-0x20]
    17a8:      	subs	x8, x8, x9
    17ac:      	b.hs	0x1824 <main+0x17c>
    17b0:      	b	0x17b4 <main+0x10c>
    17b4:      	str	wzr, [sp, #0x24]
    17b8:      	b	0x17bc <main+0x114>
    17bc:      	ldr	w8, [sp, #0x24]
    17c0:      	subs	w8, w8, #0x2
    17c4:      	b.hs	0x17f8 <main+0x150>
    17c8:      	b	0x17cc <main+0x124>
    17cc:      	sub	x0, x29, #0x24
    17d0:      	bl	0x18a0 <csrd_matrix_next_value>
    17d4:      	ldr	w8, [sp, #0x24]
    17d8:      	mov	w9, w8
    17dc:      	sub	x8, x29, #0x18
    17e0:      	str	w0, [x8, x9, lsl #2]
    17e4:      	b	0x17e8 <main+0x140>
    17e8:      	ldr	w8, [sp, #0x24]
    17ec:      	add	w8, w8, #0x1
    17f0:      	str	w8, [sp, #0x24]
    17f4:      	b	0x17bc <main+0x114>
    17f8:      	ldur	w0, [x29, #-0x18]
    17fc:      	ldur	w1, [x29, #-0x14]
    1800:      	bl	0x858 <kernel>
    1804:      	ldur	x8, [x29, #-0x30]
    1808:      	add	x8, x8, w0, uxtw
    180c:      	stur	x8, [x29, #-0x30]
    1810:      	b	0x1814 <main+0x16c>
    1814:      	ldr	x8, [sp, #0x28]
    1818:      	add	x8, x8, #0x1
    181c:      	str	x8, [sp, #0x28]
    1820:      	b	0x17a0 <main+0xf8>
    1824:      	mov	w0, #0x1                // =1
    1828:      	add	x1, sp, #0x30
    182c:      	bl	0x6e0 <clock_gettime@plt>
    1830:      	cbz	w0, 0x1844 <main+0x19c>
    1834:      	b	0x1838 <main+0x190>
    1838:      	mov	w8, #0x2                // =2
    183c:      	stur	w8, [x29, #-0x4]
    1840:      	b	0x1890 <main+0x1e8>
    1844:      	ldr	x8, [sp, #0x30]
    1848:      	ldr	x9, [sp, #0x40]
    184c:      	subs	x8, x8, x9
    1850:      	scvtf	d2, x8
    1854:      	ldr	x8, [sp, #0x38]
    1858:      	ldr	x9, [sp, #0x48]
    185c:      	subs	x8, x8, x9
    1860:      	scvtf	d0, x8
    1864:      	adrp	x8, 0x1000 <kernel+0x7a8>
    1868:      	ldr	d1, [x8, #0x920]
    186c:      	fmadd	d0, d0, d1, d2
    1870:      	str	d0, [sp, #0x18]
    1874:      	ldr	d0, [sp, #0x18]
    1878:      	ldur	x1, [x29, #-0x30]
    187c:      	adrp	x0, 0x1000 <kernel+0x7a8>
    1880:      	add	x0, x0, #0x931
    1884:      	bl	0x720 <printf@plt>
    1888:      	stur	wzr, [x29, #-0x4]
    188c:      	b	0x1890 <main+0x1e8>
    1890:      	ldur	w0, [x29, #-0x4]
    1894:      	ldp	x29, x30, [sp, #0x80]
    1898:      	add	sp, sp, #0x90
    189c:      	ret

00000000000018a0 <csrd_matrix_next_value>:
    18a0:      	sub	sp, sp, #0x10
    18a4:      	str	x0, [sp, #0x8]
    18a8:      	ldr	x8, [sp, #0x8]
    18ac:      	ldr	w10, [x8]
    18b0:      	ldr	x9, [sp, #0x8]
    18b4:      	ldr	w8, [x9]
    18b8:      	eor	w8, w8, w10, lsl #13
    18bc:      	str	w8, [x9]
    18c0:      	ldr	x8, [sp, #0x8]
    18c4:      	ldr	w10, [x8]
    18c8:      	ldr	x9, [sp, #0x8]
    18cc:      	ldr	w8, [x9]
    18d0:      	eor	w8, w8, w10, lsr #17
    18d4:      	str	w8, [x9]
    18d8:      	ldr	x8, [sp, #0x8]
    18dc:      	ldr	w10, [x8]
    18e0:      	ldr	x9, [sp, #0x8]
    18e4:      	ldr	w8, [x9]
    18e8:      	eor	w8, w8, w10, lsl #5
    18ec:      	str	w8, [x9]
    18f0:      	ldr	x8, [sp, #0x8]
    18f4:      	ldr	w0, [x8]
    18f8:      	add	sp, sp, #0x10
    18fc:      	ret

Disassembly of section .fini:

0000000000001900 <_fini>:
    1900:      	nop
    1904:      	stp	x29, x30, [sp, #-0x10]!
    1908:      	mov	x29, sp
    190c:      	ldp	x29, x30, [sp], #0x10
    1910:      	ret
