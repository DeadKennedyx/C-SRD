; ModuleID = '/work/experiments/runs/positional-widths-comparison-20261110/matrix/crc32_byte/build-clang-O1-sanitizers-original/validation/compiler-0-O1/candidate.i'
source_filename = "/work/experiments/runs/positional-widths-comparison-20261110/matrix/crc32_byte/build-clang-O1-sanitizers-original/validation/compiler-0-O1/candidate.i"
target datalayout = "e-m:e-i8:8:32-i16:16:32-i64:64-i128:128-n32:64-S128"
target triple = "aarch64-unknown-linux-gnu"

$asan.module_ctor = comdat any

@llvm.used = appending global [1 x ptr] [ptr @asan.module_ctor], section "llvm.metadata"
@___asan_globals_registered = common hidden global i64 0
@__start_asan_globals = extern_weak hidden global i64
@__stop_asan_globals = extern_weak hidden global i64
@llvm.global_ctors = appending global [1 x { i32, ptr, ptr }] [{ i32, ptr, ptr } { i32 1, ptr @asan.module_ctor, ptr @asan.module_ctor }]

; Function Attrs: nofree norecurse nosync nounwind sanitize_address memory(none) uwtable
define dso_local i32 @kernel(i32 noundef %state, i32 noundef %byte) local_unnamed_addr #0 !func_sanitize !6 {
entry:
  %and = and i32 %byte, 255
  %0 = xor i32 %and, %state
  %xor1 = xor i32 %0, -1
  br label %for.body

for.cond.cleanup:                                 ; preds = %for.body
  %xor5 = xor i32 %xor4, -1
  ret i32 %xor5

for.body:                                         ; preds = %entry, %for.body
  %i.010 = phi i32 [ 0, %entry ], [ %inc, %for.body ]
  %crc.09 = phi i32 [ %xor1, %entry ], [ %xor4, %for.body ]
  %and2 = and i32 %crc.09, 1
  %shr = lshr i32 %crc.09, 1
  %1 = icmp eq i32 %and2, 0
  %and3 = select i1 %1, i32 0, i32 -306674912
  %xor4 = xor i32 %and3, %shr
  %inc = add nuw nsw i32 %i.010, 1
  %exitcond.not = icmp eq i32 %inc, 8
  br i1 %exitcond.not, label %for.cond.cleanup, label %for.body, !llvm.loop !7
}

declare void @__asan_register_elf_globals(i64, i64, i64)

declare void @__asan_init()

; Function Attrs: nounwind uwtable
define internal void @asan.module_ctor() #1 comdat {
  call void @__asan_init()
  call void @__asan_version_mismatch_check_v8()
  call void @__asan_register_elf_globals(i64 ptrtoint (ptr @___asan_globals_registered to i64), i64 ptrtoint (ptr @__start_asan_globals to i64), i64 ptrtoint (ptr @__stop_asan_globals to i64))
  ret void
}

declare void @__asan_version_mismatch_check_v8()

attributes #0 = { nofree norecurse nosync nounwind sanitize_address memory(none) uwtable "frame-pointer"="non-leaf" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+fp-armv8,+neon,+outline-atomics,+v8a,-fmv" }
attributes #1 = { nounwind uwtable "frame-pointer"="non-leaf" }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 1, !"wchar_size", i32 4}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 1}
!5 = !{!"Ubuntu clang version 18.1.3 (1ubuntu1)"}
!6 = !{i32 -1056584962, i32 -455559067}
!7 = distinct !{!7, !8, !9}
!8 = !{!"llvm.loop.mustprogress"}
!9 = !{!"llvm.loop.unroll.disable"}
