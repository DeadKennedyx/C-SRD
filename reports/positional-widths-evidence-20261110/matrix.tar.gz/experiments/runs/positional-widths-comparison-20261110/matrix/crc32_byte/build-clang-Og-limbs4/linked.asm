
/work/experiments/runs/positional-widths-comparison-20261110/matrix/crc32_byte/build-clang-Og-limbs4/program:	file format elf64-littleaarch64

Disassembly of section .init:

0000000000000678 <_init>:
     678:      	nop
     67c:      	stp	x29, x30, [sp, #-0x10]!
     680:      	mov	x29, sp
     684:      	bl	0x774 <call_weak_fn>
     688:      	ldp	x29, x30, [sp], #0x10
     68c:      	ret

Disassembly of section .plt:

0000000000000690 <.plt>:
     690:      	stp	x16, x30, [sp, #-0x10]!
     694:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e038>
     698:      	ldr	x17, [x16, #0xff8]
     69c:      	add	x16, x16, #0xff8
     6a0:      	br	x17
     6a4:      	nop
     6a8:      	nop
     6ac:      	nop

00000000000006b0 <strtoul@plt>:
     6b0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6b4:      	ldr	x17, [x16]
     6b8:      	add	x16, x16, #0x0
     6bc:      	br	x17

00000000000006c0 <__libc_start_main@plt>:
     6c0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6c4:      	ldr	x17, [x16, #0x8]
     6c8:      	add	x16, x16, #0x8
     6cc:      	br	x17

00000000000006d0 <__cxa_finalize@plt>:
     6d0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6d4:      	ldr	x17, [x16, #0x10]
     6d8:      	add	x16, x16, #0x10
     6dc:      	br	x17

00000000000006e0 <clock_gettime@plt>:
     6e0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6e4:      	ldr	x17, [x16, #0x18]
     6e8:      	add	x16, x16, #0x18
     6ec:      	br	x17

00000000000006f0 <__gmon_start__@plt>:
     6f0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6f4:      	ldr	x17, [x16, #0x20]
     6f8:      	add	x16, x16, #0x20
     6fc:      	br	x17

0000000000000700 <abort@plt>:
     700:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     704:      	ldr	x17, [x16, #0x28]
     708:      	add	x16, x16, #0x28
     70c:      	br	x17

0000000000000710 <__isoc99_scanf@plt>:
     710:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     714:      	ldr	x17, [x16, #0x30]
     718:      	add	x16, x16, #0x30
     71c:      	br	x17

0000000000000720 <printf@plt>:
     720:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     724:      	ldr	x17, [x16, #0x38]
     728:      	add	x16, x16, #0x38
     72c:      	br	x17

Disassembly of section .text:

0000000000000740 <_start>:
     740:      	nop
     744:      	mov	x29, #0x0               // =0
     748:      	mov	x30, #0x0               // =0
     74c:      	mov	x5, x0
     750:      	ldr	x1, [sp]
     754:      	add	x2, sp, #0x8
     758:      	mov	x6, sp
     75c:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e038>
     760:      	ldr	x0, [x0, #0xfd8]
     764:      	mov	x3, #0x0                // =0
     768:      	mov	x4, #0x0                // =0
     76c:      	bl	0x6c0 <__libc_start_main@plt>
     770:      	bl	0x700 <abort@plt>

0000000000000774 <call_weak_fn>:
     774:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e038>
     778:      	ldr	x0, [x0, #0xfd0]
     77c:      	cbz	x0, 0x784 <call_weak_fn+0x10>
     780:      	b	0x6f0 <__gmon_start__@plt>
     784:      	ret
     788:      	nop
     78c:      	nop

0000000000000790 <deregister_tm_clones>:
     790:      	adrp	x0, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     794:      	add	x0, x0, #0x50
     798:      	adrp	x1, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     79c:      	add	x1, x1, #0x50
     7a0:      	cmp	x1, x0
     7a4:      	b.eq	0x7bc <deregister_tm_clones+0x2c>
     7a8:      	adrp	x1, 0x1f000 <__FRAME_END__+0x1e038>
     7ac:      	ldr	x1, [x1, #0xfc0]
     7b0:      	cbz	x1, 0x7bc <deregister_tm_clones+0x2c>
     7b4:      	mov	x16, x1
     7b8:      	br	x16
     7bc:      	ret

00000000000007c0 <register_tm_clones>:
     7c0:      	adrp	x0, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     7c4:      	add	x0, x0, #0x50
     7c8:      	adrp	x1, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     7cc:      	add	x1, x1, #0x50
     7d0:      	sub	x1, x1, x0
     7d4:      	lsr	x2, x1, #63
     7d8:      	add	x1, x2, x1, asr #3
     7dc:      	asr	x1, x1, #1
     7e0:      	cbz	x1, 0x7f8 <register_tm_clones+0x38>
     7e4:      	adrp	x2, 0x1f000 <__FRAME_END__+0x1e038>
     7e8:      	ldr	x2, [x2, #0xfe0]
     7ec:      	cbz	x2, 0x7f8 <register_tm_clones+0x38>
     7f0:      	mov	x16, x2
     7f4:      	br	x16
     7f8:      	ret
     7fc:      	nop

0000000000000800 <__do_global_dtors_aux>:
     800:      	paciasp
     804:      	stp	x29, x30, [sp, #-0x20]!
     808:      	mov	x29, sp
     80c:      	str	x19, [sp, #0x10]
     810:      	adrp	x19, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     814:      	ldrb	w0, [x19, #0x50]
     818:      	tbnz	w0, #0x0, 0x840 <__do_global_dtors_aux+0x40>
     81c:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e038>
     820:      	ldr	x0, [x0, #0xfc8]
     824:      	cbz	x0, 0x834 <__do_global_dtors_aux+0x34>
     828:      	adrp	x0, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     82c:      	ldr	x0, [x0, #0x48]
     830:      	bl	0x6d0 <__cxa_finalize@plt>
     834:      	bl	0x790 <deregister_tm_clones>
     838:      	mov	w0, #0x1                // =1
     83c:      	strb	w0, [x19, #0x50]
     840:      	ldr	x19, [sp, #0x10]
     844:      	ldp	x29, x30, [sp], #0x20
     848:      	autiasp
     84c:      	ret

0000000000000850 <frame_dummy>:
     850:      	bti	c
     854:      	b	0x7c0 <register_tm_clones>

0000000000000858 <kernel>:
     858:      	stp	x26, x25, [sp, #-0x40]!
     85c:      	stp	x24, x23, [sp, #0x10]
     860:      	stp	x22, x21, [sp, #0x20]
     864:      	stp	x20, x19, [sp, #0x30]
     868:      	mov	w11, #-0x1              // =-1
     86c:      	eon	w13, w1, w0
     870:      	eor	w17, w1, w0
     874:      	eor	w18, w11, w0, lsr #8
     878:      	eor	w4, w11, w0, lsr #12
     87c:      	sbfx	w10, w13, #0, #1
     880:      	eor	w5, w11, w0, lsr #16
     884:      	sbfx	w15, w13, #1, #1
     888:      	eor	w3, w11, w0, lsr #20
     88c:      	ubfx	w2, w18, #1, #3
     890:      	and	w1, w10, #0x3
     894:      	mvn	w6, w0
     898:      	lsr	w21, w5, #1
     89c:      	and	w23, w15, #0x3
     8a0:      	ubfiz	w22, w18, #3, #1
     8a4:      	bfi	w2, w4, #3, #1
     8a8:      	eor	w12, w11, w0, lsr #24
     8ac:      	eor	w11, w11, w17, lsr #4
     8b0:      	lsr	w7, w6, #25
     8b4:      	ubfx	w24, w3, #1, #3
     8b8:      	mov	w8, #0xb                // =11
     8bc:      	eor	w2, w1, w2
     8c0:      	lsr	w1, w4, #1
     8c4:      	ubfx	w4, w4, #1, #3
     8c8:      	lsr	w19, w2, #1
     8cc:      	and	w7, w7, #0x8
     8d0:      	bfxil	w22, w11, #1, #3
     8d4:      	bfi	w4, w5, #3, #1
     8d8:      	bfi	w24, w12, #3, #1
     8dc:      	mov	w9, #0xd                // =13
     8e0:      	bfi	w19, w1, #3, #1
     8e4:      	ubfx	w1, w5, #1, #3
     8e8:      	and	w5, w10, #0x8
     8ec:      	eor	w18, w5, w4
     8f0:      	and	w25, w10, #0x2
     8f4:      	bfxil	w7, w12, #1, #3
     8f8:      	eor	w4, w19, w23
     8fc:      	lsr	w19, w18, #1
     900:      	bfi	w1, w3, #3, #1
     904:      	lsr	w23, w4, #1
     908:      	and	w3, w10, w8
     90c:      	and	w26, w15, #0x8
     910:      	eor	w12, w25, w22
     914:      	eor	w1, w5, w1
     918:      	eor	w3, w3, w24
     91c:      	orr	w23, w23, w19, lsl #3
     920:      	bfi	w19, w21, #3, #1
     924:      	and	w21, w10, w9
     928:      	lsr	w20, w6, #26
     92c:      	lsr	w22, w1, #1
     930:      	eor	w7, w21, w7
     934:      	eor	w5, w19, w26
     938:      	lsr	w19, w12, #1
     93c:      	lsr	w21, w3, #1
     940:      	lsr	w5, w5, #1
     944:      	lsr	w6, w6, #30
     948:      	and	w10, w10, #0xe
     94c:      	bfi	w19, w2, #3, #1
     950:      	bfi	w21, w7, #3, #1
     954:      	and	w24, w15, #0xf
     958:      	orr	w2, w5, w22, lsl #3
     95c:      	and	w5, w20, #0x8
     960:      	bfi	w22, w3, #3, #1
     964:      	eor	w3, w6, w10, lsr #1
     968:      	orr	w5, w5, w7, lsr #1
     96c:      	and	w6, w15, w8
     970:      	and	w10, w15, #0x2
     974:      	and	w15, w15, w9
     978:      	eor	w7, w22, w26
     97c:      	eor	w6, w21, w6
     980:      	eor	w10, w19, w10
     984:      	eor	w15, w5, w15
     988:      	lsr	w7, w7, #1
     98c:      	lsr	w19, w6, #1
     990:      	lsr	w20, w15, #1
     994:      	eor	w5, w3, w24
     998:      	sbfx	w13, w13, #2, #1
     99c:      	lsr	w24, w10, #1
     9a0:      	orr	w6, w7, w6, lsl #3
     9a4:      	orr	w15, w19, w15, lsl #3
     9a8:      	orr	w3, w20, w3, lsl #3
     9ac:      	orr	w7, w24, w4, lsl #3
     9b0:      	and	w19, w23, #0xf
     9b4:      	and	w2, w2, #0xf
     9b8:      	and	w6, w6, #0xe
     9bc:      	and	w20, w15, #0xf
     9c0:      	and	w15, w13, #0x3
     9c4:      	and	w23, w13, #0x8
     9c8:      	mov	w14, #0xf               // =15
     9cc:      	and	w22, w13, #0xf
     9d0:      	and	w3, w3, #0xf
     9d4:      	and	w25, w13, w8
     9d8:      	and	w26, w13, w9
     9dc:      	eor	w4, w24, w13
     9e0:      	eor	w19, w19, w15
     9e4:      	eor	w15, w2, w23
     9e8:      	eor	w13, w6, w23
     9ec:      	mov	w23, #0x8               // =8
     9f0:      	bic	w16, w14, w17, lsr #4
     9f4:      	lsr	w2, w7, #1
     9f8:      	eor	w7, w20, w25
     9fc:      	eor	w20, w3, w26
     a00:      	eor	w3, w22, w5, lsr #1
     a04:      	bics	wzr, w23, w17
     a08:      	bic	w17, w23, w0, lsr #16
     a0c:      	csel	w22, w14, wzr, ne
     a10:      	bic	w14, w23, w0, lsr #12
     a14:      	lsr	w0, w13, #1
     a18:      	lsr	w23, w7, #1
     a1c:      	lsr	w21, w5, #1
     a20:      	and	w6, w2, #0x6
     a24:      	lsr	w5, w3, #1
     a28:      	orr	w17, w17, w15, lsr #1
     a2c:      	bfi	w6, w19, #3, #1
     a30:      	orr	w14, w14, w19, lsr #1
     a34:      	lsr	w19, w20, #1
     a38:      	bfi	w0, w7, #3, #1
     a3c:      	bfi	w23, w20, #3, #1
     a40:      	and	w20, w22, #0x8
     a44:      	and	w7, w5, #0xe
     a48:      	and	w5, w22, #0x3
     a4c:      	eor	w17, w17, w20
     a50:      	bfi	w19, w21, #3, #1
     a54:      	eor	w25, w14, w5
     a58:      	eor	w14, w0, w20
     a5c:      	sbfx	w5, w16, #0, #1
     a60:      	lsr	w0, w17, #1
     a64:      	and	w1, w1, #0x8
     a68:      	and	w24, w22, #0xfffffffd
     a6c:      	and	w16, w4, #0x2
     a70:      	and	w4, w5, #0x8
     a74:      	and	w21, w22, #0xfffffffb
     a78:      	orr	w1, w0, w1
     a7c:      	eor	w19, w19, w24
     a80:      	lsl	w3, w3, #2
     a84:      	eor	w1, w1, w4
     a88:      	eor	w2, w2, w22
     a8c:      	eor	w20, w23, w21
     a90:      	eor	w7, w7, w22
     a94:      	lsr	w22, w14, #1
     a98:      	lsr	w1, w1, #1
     a9c:      	ubfiz	w23, w19, #3, #1
     aa0:      	and	w18, w18, #0x8
     aa4:      	and	w3, w3, #0x8
     aa8:      	lsr	w6, w6, #1
     aac:      	orr	w18, w18, w25, lsr #1
     ab0:      	orr	w1, w1, w22, lsl #3
     ab4:      	bfi	w22, w20, #3, #1
     ab8:      	orr	w20, w23, w20, lsr #1
     abc:      	orr	w3, w3, w19, lsr #1
     ac0:      	lsr	w2, w2, #1
     ac4:      	and	w21, w5, #0xf
     ac8:      	and	w19, w5, #0x2
     acc:      	and	w23, w5, #0x3
     ad0:      	and	w24, w5, w8
     ad4:      	and	w5, w5, w9
     ad8:      	bfi	w6, w25, #3, #1
     adc:      	eor	w18, w18, w23
     ae0:      	eor	w4, w22, w4
     ae4:      	eor	w20, w20, w24
     ae8:      	eor	w3, w3, w5
     aec:      	lsr	w7, w7, #1
     af0:      	bfi	w16, w2, #2, #1
     af4:      	lsr	w2, w18, #1
     af8:      	lsr	w4, w4, #1
     afc:      	lsr	w22, w20, #1
     b00:      	lsr	w23, w3, #1
     b04:      	eor	w6, w6, w19
     b08:      	lsr	w6, w6, #1
     b0c:      	sbfx	w19, w11, #1, #1
     b10:      	orr	w0, w2, w0, lsl #3
     b14:      	orr	w2, w4, w20, lsl #3
     b18:      	orr	w3, w22, w3, lsl #3
     b1c:      	orr	w4, w23, w7, lsl #3
     b20:      	eor	w24, w6, w19
     b24:      	bfi	w16, w6, #3, #1
     b28:      	bfi	w6, w18, #3, #1
     b2c:      	and	w18, w0, #0xf
     b30:      	and	w0, w1, #0xc
     b34:      	and	w1, w2, #0xc
     b38:      	and	w2, w3, #0xf
     b3c:      	and	w3, w4, #0xf
     b40:      	and	w4, w19, #0x3
     b44:      	eor	w21, w7, w21
     b48:      	and	w5, w19, #0xf
     b4c:      	and	w7, w19, #0x8
     b50:      	and	w20, w19, w8
     b54:      	and	w19, w19, w9
     b58:      	eor	w18, w18, w4
     b5c:      	eor	w4, w5, w21, lsr #1
     b60:      	ubfiz	w5, w18, #3, #1
     b64:      	eor	w3, w3, w19
     b68:      	and	w15, w15, #0x8
     b6c:      	lsr	w11, w21, #1
     b70:      	eor	w1, w1, w7
     b74:      	eor	w2, w2, w20
     b78:      	orr	w15, w15, w18, lsr #1
     b7c:      	lsr	w18, w3, #1
     b80:      	sbfx	w12, w12, #1, #1
     b84:      	orr	w5, w5, w6, lsr #1
     b88:      	lsr	w1, w1, #1
     b8c:      	lsr	w6, w2, #1
     b90:      	eor	w0, w0, w7
     b94:      	and	w13, w13, #0x8
     b98:      	bfi	w18, w11, #3, #1
     b9c:      	orr	w13, w13, w0, lsr #1
     ba0:      	bfi	w1, w2, #3, #1
     ba4:      	bfi	w6, w3, #3, #1
     ba8:      	and	w0, w12, #0x3
     bac:      	and	w19, w12, w9
     bb0:      	and	w2, w12, #0x8
     bb4:      	and	w3, w12, w8
     bb8:      	eor	w15, w15, w0
     bbc:      	eor	w18, w18, w19
     bc0:      	lsr	w7, w4, #1
     bc4:      	and	w11, w12, #0x2
     bc8:      	eor	w13, w13, w2
     bcc:      	eor	w0, w1, w2
     bd0:      	eor	w1, w6, w3
     bd4:      	ubfiz	w2, w15, #3, #1
     bd8:      	lsr	w3, w18, #1
     bdc:      	eor	w11, w5, w11
     be0:      	sbfx	w10, w10, #1, #1
     be4:      	eor	w12, w12, w4, lsr #1
     be8:      	and	w17, w17, #0x8
     bec:      	orr	w11, w2, w11, lsr #1
     bf0:      	lsr	w2, w1, #1
     bf4:      	bfi	w3, w7, #3, #1
     bf8:      	and	w14, w14, #0x8
     bfc:      	and	w9, w10, w9
     c00:      	and	w12, w12, #0xe
     c04:      	orr	w15, w17, w15, lsr #1
     c08:      	orr	w13, w14, w13, lsr #1
     c0c:      	bfi	w2, w18, #3, #1
     c10:      	and	w14, w10, #0x2
     c14:      	and	w17, w10, #0x3
     c18:      	and	w18, w10, #0x8
     c1c:      	and	w8, w10, w8
     c20:      	and	w10, w10, #0xe
     c24:      	eor	w9, w3, w9
     c28:      	lsr	w22, w24, #1
     c2c:      	lsr	w16, w16, #1
     c30:      	lsr	w0, w0, #1
     c34:      	lsl	w9, w9, #24
     c38:      	eon	w10, w10, w12, lsr #1
     c3c:      	eor	w12, w15, w17
     c40:      	bfi	w16, w22, #3, #1
     c44:      	bfi	w0, w1, #3, #1
     c48:      	eor	w13, w13, w18
     c4c:      	eor	w8, w2, w8
     c50:      	lsl	w12, w12, #8
     c54:      	orr	w9, w9, w10, lsl #28
     c58:      	eor	w11, w11, w14
     c5c:      	lsl	w13, w13, #12
     c60:      	lsl	w8, w8, #20
     c64:      	eor	w10, w0, w18
     c68:      	orr	w11, w16, w11, lsl #4
     c6c:      	eor	w12, w12, #0xf00
     c70:      	eor	w9, w9, #0xf000000
     c74:      	eor	w13, w13, #0xf000
     c78:      	lsl	w10, w10, #16
     c7c:      	eor	w8, w8, #0xf00000
     c80:      	orr	w9, w9, w12
     c84:      	orr	w8, w9, w8
     c88:      	orr	w9, w11, w13
     c8c:      	eor	w10, w10, #0xf0000
     c90:      	orr	w8, w8, w9
     c94:      	ldp	x20, x19, [sp, #0x30]
     c98:      	ldp	x22, x21, [sp, #0x20]
     c9c:      	orr	w8, w8, w10
     ca0:      	ldp	x24, x23, [sp, #0x10]
     ca4:      	eor	w0, w8, #0xff
     ca8:      	ldp	x26, x25, [sp], #0x40
     cac:      	ret

0000000000000cb0 <main>:
     cb0:      	sub	sp, sp, #0x60
     cb4:      	stp	x29, x30, [sp, #0x20]
     cb8:      	str	x23, [sp, #0x30]
     cbc:      	stp	x22, x21, [sp, #0x40]
     cc0:      	stp	x20, x19, [sp, #0x50]
     cc4:      	add	x29, sp, #0x20
     cc8:      	cmp	w0, #0x3
     ccc:      	b.eq	0xd38 <main+0x88>
     cd0:      	cmp	w0, #0x1
     cd4:      	b.ne	0xdc4 <main+0x114>
     cd8:      	add	x21, x29, #0x18
     cdc:      	adrp	x0, 0x0 <strtoul@GLIBC_2.17>
     ce0:      	add	x0, x0, #0xe60
     ce4:      	add	x1, x29, #0x18
     ce8:      	add	x2, x21, #0x4
     cec:      	bl	0x710 <__isoc99_scanf@plt>
     cf0:      	cmp	w0, #0x2
     cf4:      	b.ne	0xe1c <main+0x16c>
     cf8:      	adrp	x19, 0x0 <strtoul@GLIBC_2.17>
     cfc:      	add	x19, x19, #0xe65
     d00:      	adrp	x20, 0x0 <strtoul@GLIBC_2.17>
     d04:      	add	x20, x20, #0xe60
     d08:      	ldp	w0, w1, [x29, #0x18]
     d0c:      	bl	0x858 <kernel>
     d10:      	mov	w1, w0
     d14:      	mov	x0, x19
     d18:      	bl	0x720 <printf@plt>
     d1c:      	add	x1, x29, #0x18
     d20:      	add	x2, x21, #0x4
     d24:      	mov	x0, x20
     d28:      	bl	0x710 <__isoc99_scanf@plt>
     d2c:      	cmp	w0, #0x2
     d30:      	b.eq	0xd08 <main+0x58>
     d34:      	b	0xe1c <main+0x16c>
     d38:      	ldr	x0, [x1, #0x8]
     d3c:      	mov	x19, x1
     d40:      	mov	x1, xzr
     d44:      	mov	w2, #0xa                // =10
     d48:      	bl	0x6b0 <strtoul@plt>
     d4c:      	ldr	x8, [x19, #0x10]
     d50:      	mov	x20, x0
     d54:      	mov	x1, xzr
     d58:      	mov	w2, #0xa                // =10
     d5c:      	mov	x0, x8
     d60:      	bl	0x6b0 <strtoul@plt>
     d64:      	mov	x21, x0
     d68:      	add	x1, sp, #0x10
     d6c:      	mov	w0, #0x1                // =1
     d70:      	bl	0x6e0 <clock_gettime@plt>
     d74:      	cbnz	w0, 0xde0 <main+0x130>
     d78:      	cbz	x20, 0xdcc <main+0x11c>
     d7c:      	mov	x22, xzr
     d80:      	mov	x19, xzr
     d84:      	add	x23, x29, #0x18
     d88:      	mov	x8, xzr
     d8c:      	eor	w9, w21, w21, lsl #13
     d90:      	eor	w9, w9, w9, lsr #17
     d94:      	eor	w21, w9, w9, lsl #5
     d98:      	str	w21, [x23, x8]
     d9c:      	add	x8, x8, #0x4
     da0:      	cmp	x8, #0x4
     da4:      	b.eq	0xd8c <main+0xdc>
     da8:      	ldp	w0, w1, [x29, #0x18]
     dac:      	bl	0x858 <kernel>
     db0:      	add	x22, x22, #0x1
     db4:      	add	x19, x19, w0, uxtw
     db8:      	cmp	x22, x20
     dbc:      	b.ne	0xd88 <main+0xd8>
     dc0:      	b	0xdd0 <main+0x120>
     dc4:      	mov	w0, #0x3                // =3
     dc8:      	b	0xe20 <main+0x170>
     dcc:      	mov	x19, xzr
     dd0:      	mov	x1, sp
     dd4:      	mov	w0, #0x1                // =1
     dd8:      	bl	0x6e0 <clock_gettime@plt>
     ddc:      	cbz	w0, 0xde8 <main+0x138>
     de0:      	mov	w0, #0x2                // =2
     de4:      	b	0xe20 <main+0x170>
     de8:      	ldp	x8, x9, [sp]
     dec:      	adrp	x0, 0x0 <strtoul@GLIBC_2.17>
     df0:      	add	x0, x0, #0xe69
     df4:      	ldp	x10, x11, [sp, #0x10]
     df8:      	mov	x1, x19
     dfc:      	sub	x8, x8, x10
     e00:      	sub	x9, x9, x11
     e04:      	scvtf	d0, x8
     e08:      	scvtf	d1, x9
     e0c:      	adrp	x8, 0x0 <strtoul@GLIBC_2.17>
     e10:      	ldr	d2, [x8, #0xe58]
     e14:      	fmadd	d0, d1, d2, d0
     e18:      	bl	0x720 <printf@plt>
     e1c:      	mov	w0, wzr
     e20:      	ldp	x20, x19, [sp, #0x50]
     e24:      	ldr	x23, [sp, #0x30]
     e28:      	ldp	x22, x21, [sp, #0x40]
     e2c:      	ldp	x29, x30, [sp, #0x20]
     e30:      	add	sp, sp, #0x60
     e34:      	ret

Disassembly of section .fini:

0000000000000e38 <_fini>:
     e38:      	nop
     e3c:      	stp	x29, x30, [sp, #-0x10]!
     e40:      	mov	x29, sp
     e44:      	ldp	x29, x30, [sp], #0x10
     e48:      	ret
