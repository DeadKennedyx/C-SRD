
/work/experiments/runs/positional-widths-comparison-20261110/matrix/crc32_byte/build-gcc-O1-limbs4/program:	file format elf64-littleaarch64

Disassembly of section .init:

0000000000000738 <_init>:
     738:      	nop
     73c:      	stp	x29, x30, [sp, #-0x10]!
     740:      	mov	x29, sp
     744:      	bl	0x834 <call_weak_fn>
     748:      	ldp	x29, x30, [sp], #0x10
     74c:      	ret

Disassembly of section .plt:

0000000000000750 <.plt>:
     750:      	stp	x16, x30, [sp, #-0x10]!
     754:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1de8c>
     758:      	ldr	x17, [x16, #0xf78]
     75c:      	add	x16, x16, #0xf78
     760:      	br	x17
     764:      	nop
     768:      	nop
     76c:      	nop

0000000000000770 <strtoul@plt>:
     770:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1de8c>
     774:      	ldr	x17, [x16, #0xf80]
     778:      	add	x16, x16, #0xf80
     77c:      	br	x17

0000000000000780 <__libc_start_main@plt>:
     780:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1de8c>
     784:      	ldr	x17, [x16, #0xf88]
     788:      	add	x16, x16, #0xf88
     78c:      	br	x17

0000000000000790 <__cxa_finalize@plt>:
     790:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1de8c>
     794:      	ldr	x17, [x16, #0xf90]
     798:      	add	x16, x16, #0xf90
     79c:      	br	x17

00000000000007a0 <clock_gettime@plt>:
     7a0:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1de8c>
     7a4:      	ldr	x17, [x16, #0xf98]
     7a8:      	add	x16, x16, #0xf98
     7ac:      	br	x17

00000000000007b0 <__printf_chk@plt>:
     7b0:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1de8c>
     7b4:      	ldr	x17, [x16, #0xfa0]
     7b8:      	add	x16, x16, #0xfa0
     7bc:      	br	x17

00000000000007c0 <__stack_chk_fail@plt>:
     7c0:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1de8c>
     7c4:      	ldr	x17, [x16, #0xfa8]
     7c8:      	add	x16, x16, #0xfa8
     7cc:      	br	x17

00000000000007d0 <__gmon_start__@plt>:
     7d0:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1de8c>
     7d4:      	ldr	x17, [x16, #0xfb0]
     7d8:      	add	x16, x16, #0xfb0
     7dc:      	br	x17

00000000000007e0 <abort@plt>:
     7e0:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1de8c>
     7e4:      	ldr	x17, [x16, #0xfb8]
     7e8:      	add	x16, x16, #0xfb8
     7ec:      	br	x17

00000000000007f0 <__isoc99_scanf@plt>:
     7f0:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1de8c>
     7f4:      	ldr	x17, [x16, #0xfc0]
     7f8:      	add	x16, x16, #0xfc0
     7fc:      	br	x17

Disassembly of section .text:

0000000000000800 <_start>:
     800:      	nop
     804:      	mov	x29, #0x0               // =0
     808:      	mov	x30, #0x0               // =0
     80c:      	mov	x5, x0
     810:      	ldr	x1, [sp]
     814:      	add	x2, sp, #0x8
     818:      	mov	x6, sp
     81c:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1de8c>
     820:      	ldr	x0, [x0, #0xff0]
     824:      	mov	x3, #0x0                // =0
     828:      	mov	x4, #0x0                // =0
     82c:      	bl	0x780 <__libc_start_main@plt>
     830:      	bl	0x7e0 <abort@plt>

0000000000000834 <call_weak_fn>:
     834:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1de8c>
     838:      	ldr	x0, [x0, #0xfe0]
     83c:      	cbz	x0, 0x844 <call_weak_fn+0x10>
     840:      	b	0x7d0 <__gmon_start__@plt>
     844:      	ret
     848:      	nop
     84c:      	nop

0000000000000850 <deregister_tm_clones>:
     850:      	adrp	x0, 0x20000 <data_start>
     854:      	add	x0, x0, #0x10
     858:      	adrp	x1, 0x20000 <data_start>
     85c:      	add	x1, x1, #0x10
     860:      	cmp	x1, x0
     864:      	b.eq	0x87c <deregister_tm_clones+0x2c>
     868:      	adrp	x1, 0x1f000 <__FRAME_END__+0x1de8c>
     86c:      	ldr	x1, [x1, #0xfd0]
     870:      	cbz	x1, 0x87c <deregister_tm_clones+0x2c>
     874:      	mov	x16, x1
     878:      	br	x16
     87c:      	ret

0000000000000880 <register_tm_clones>:
     880:      	adrp	x0, 0x20000 <data_start>
     884:      	add	x0, x0, #0x10
     888:      	adrp	x1, 0x20000 <data_start>
     88c:      	add	x1, x1, #0x10
     890:      	sub	x1, x1, x0
     894:      	lsr	x2, x1, #63
     898:      	add	x1, x2, x1, asr #3
     89c:      	asr	x1, x1, #1
     8a0:      	cbz	x1, 0x8b8 <register_tm_clones+0x38>
     8a4:      	adrp	x2, 0x1f000 <__FRAME_END__+0x1de8c>
     8a8:      	ldr	x2, [x2, #0xff8]
     8ac:      	cbz	x2, 0x8b8 <register_tm_clones+0x38>
     8b0:      	mov	x16, x2
     8b4:      	br	x16
     8b8:      	ret
     8bc:      	nop

00000000000008c0 <__do_global_dtors_aux>:
     8c0:      	paciasp
     8c4:      	stp	x29, x30, [sp, #-0x20]!
     8c8:      	mov	x29, sp
     8cc:      	str	x19, [sp, #0x10]
     8d0:      	adrp	x19, 0x20000 <data_start>
     8d4:      	ldrb	w0, [x19, #0x10]
     8d8:      	tbnz	w0, #0x0, 0x900 <__do_global_dtors_aux+0x40>
     8dc:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1de8c>
     8e0:      	ldr	x0, [x0, #0xfd8]
     8e4:      	cbz	x0, 0x8f4 <__do_global_dtors_aux+0x34>
     8e8:      	adrp	x0, 0x20000 <data_start>
     8ec:      	ldr	x0, [x0, #0x8]
     8f0:      	bl	0x790 <__cxa_finalize@plt>
     8f4:      	bl	0x850 <deregister_tm_clones>
     8f8:      	mov	w0, #0x1                // =1
     8fc:      	strb	w0, [x19, #0x10]
     900:      	ldr	x19, [sp, #0x10]
     904:      	ldp	x29, x30, [sp], #0x20
     908:      	autiasp
     90c:      	ret

0000000000000910 <frame_dummy>:
     910:      	bti	c
     914:      	b	0x880 <register_tm_clones>

0000000000000918 <kernel>:
     918:      	mvn	w3, w0, lsr #8
     91c:      	mvn	w8, w0, lsr #12
     920:      	mvn	w7, w0, lsr #16
     924:      	mvn	w6, w0, lsr #20
     928:      	mvn	w4, w0, lsr #24
     92c:      	lsr	w11, w0, #28
     930:      	eor	w11, w11, #0xf
     934:      	eor	w2, w0, w1
     938:      	eon	w0, w0, w1
     93c:      	mvn	w1, w2, lsr #4
     940:      	and	w2, w0, #0x1
     944:      	ubfx	x14, x0, #1, #3
     948:      	ubfiz	w10, w1, #3, #4
     94c:      	orr	w10, w14, w10
     950:      	ubfiz	w12, w0, #3, #1
     954:      	ubfx	x1, x1, #1, #3
     958:      	ubfiz	w5, w3, #3, #1
     95c:      	orr	w5, w5, w1
     960:      	ubfiz	w0, w0, #1, #1
     964:      	eor	w5, w5, w0
     968:      	ubfx	x3, x3, #1, #3
     96c:      	ubfiz	w0, w8, #3, #1
     970:      	orr	w3, w0, w3
     974:      	mov	w9, #0x3                // =3
     978:      	cmp	w2, #0x0
     97c:      	csel	w0, w9, wzr, ne
     980:      	eor	w3, w3, w0
     984:      	ubfx	x8, x8, #1, #3
     988:      	ubfiz	w2, w7, #3, #1
     98c:      	orr	w2, w2, w8
     990:      	eor	w2, w2, w12
     994:      	ubfx	x7, x7, #1, #3
     998:      	ubfiz	w0, w6, #3, #1
     99c:      	orr	w0, w0, w7
     9a0:      	eor	w0, w0, w12
     9a4:      	ubfx	x6, x6, #1, #3
     9a8:      	ubfiz	w13, w4, #3, #1
     9ac:      	orr	w13, w13, w6
     9b0:      	mov	w8, #0xb                // =11
     9b4:      	csel	w1, w8, wzr, ne
     9b8:      	eor	w13, w13, w1
     9bc:      	ubfx	x1, x4, #1, #3
     9c0:      	orr	w1, w1, w11, lsl #3
     9c4:      	and	w1, w1, #0xf
     9c8:      	mov	w7, #0xd                // =13
     9cc:      	csel	w4, w7, wzr, ne
     9d0:      	eor	w1, w1, w4
     9d4:      	mov	w6, #0xe                // =14
     9d8:      	csel	w4, w6, wzr, ne
     9dc:      	eor	w11, w4, w11, lsr #1
     9e0:      	and	w16, w14, #0x1
     9e4:      	ubfx	x10, x10, #1, #3
     9e8:      	orr	w12, w10, w5, lsl #3
     9ec:      	ubfiz	w15, w14, #3, #1
     9f0:      	lsl	w4, w3, #3
     9f4:      	orr	w5, w4, w5, lsr #1
     9f8:      	and	w5, w5, #0xf
     9fc:      	ubfiz	w4, w14, #1, #1
     a00:      	eor	w5, w5, w4
     a04:      	lsl	w4, w2, #3
     a08:      	orr	w3, w4, w3, lsr #1
     a0c:      	and	w3, w3, #0xf
     a10:      	cmp	w16, #0x0
     a14:      	csel	w4, w9, wzr, ne
     a18:      	eor	w3, w3, w4
     a1c:      	lsl	w4, w0, #3
     a20:      	orr	w2, w4, w2, lsr #1
     a24:      	and	w2, w2, #0xf
     a28:      	eor	w2, w2, w15
     a2c:      	lsl	w4, w13, #3
     a30:      	orr	w0, w4, w0, lsr #1
     a34:      	and	w0, w0, #0xf
     a38:      	eor	w0, w0, w15
     a3c:      	lsl	w4, w1, #3
     a40:      	orr	w13, w4, w13, lsr #1
     a44:      	and	w13, w13, #0xf
     a48:      	csel	w4, w8, wzr, ne
     a4c:      	eor	w13, w13, w4
     a50:      	lsl	w4, w11, #3
     a54:      	orr	w1, w4, w1, lsr #1
     a58:      	and	w1, w1, #0xf
     a5c:      	csel	w4, w7, wzr, ne
     a60:      	eor	w1, w1, w4
     a64:      	csel	w4, w6, wzr, ne
     a68:      	eor	w11, w4, w11, lsr #1
     a6c:      	and	w15, w10, #0x1
     a70:      	ubfx	x12, x12, #1, #3
     a74:      	orr	w4, w12, w5, lsl #3
     a78:      	ubfiz	w14, w10, #3, #1
     a7c:      	lsl	w16, w3, #3
     a80:      	orr	w5, w16, w5, lsr #1
     a84:      	and	w5, w5, #0xf
     a88:      	ubfiz	w10, w10, #1, #1
     a8c:      	eor	w5, w5, w10
     a90:      	lsl	w10, w2, #3
     a94:      	orr	w3, w10, w3, lsr #1
     a98:      	and	w3, w3, #0xf
     a9c:      	cmp	w15, #0x0
     aa0:      	csel	w10, w9, wzr, ne
     aa4:      	eor	w3, w3, w10
     aa8:      	lsl	w10, w0, #3
     aac:      	orr	w2, w10, w2, lsr #1
     ab0:      	and	w2, w2, #0xf
     ab4:      	eor	w2, w2, w14
     ab8:      	lsl	w10, w13, #3
     abc:      	orr	w0, w10, w0, lsr #1
     ac0:      	and	w0, w0, #0xf
     ac4:      	eor	w0, w0, w14
     ac8:      	lsl	w10, w1, #3
     acc:      	orr	w13, w10, w13, lsr #1
     ad0:      	and	w13, w13, #0xf
     ad4:      	csel	w10, w8, wzr, ne
     ad8:      	eor	w13, w13, w10
     adc:      	lsl	w10, w11, #3
     ae0:      	orr	w1, w10, w1, lsr #1
     ae4:      	and	w1, w1, #0xf
     ae8:      	csel	w10, w7, wzr, ne
     aec:      	eor	w1, w1, w10
     af0:      	csel	w10, w6, wzr, ne
     af4:      	eor	w11, w10, w11, lsr #1
     af8:      	and	w15, w12, #0x1
     afc:      	ubfx	x4, x4, #1, #3
     b00:      	orr	w10, w4, w5, lsl #3
     b04:      	ubfiz	w14, w12, #3, #1
     b08:      	lsl	w16, w3, #3
     b0c:      	orr	w5, w16, w5, lsr #1
     b10:      	and	w5, w5, #0xf
     b14:      	ubfiz	w12, w12, #1, #1
     b18:      	eor	w5, w5, w12
     b1c:      	lsl	w12, w2, #3
     b20:      	orr	w3, w12, w3, lsr #1
     b24:      	and	w3, w3, #0xf
     b28:      	cmp	w15, #0x0
     b2c:      	csel	w12, w9, wzr, ne
     b30:      	eor	w3, w3, w12
     b34:      	lsl	w12, w0, #3
     b38:      	orr	w2, w12, w2, lsr #1
     b3c:      	and	w2, w2, #0xf
     b40:      	eor	w2, w2, w14
     b44:      	lsl	w12, w13, #3
     b48:      	orr	w0, w12, w0, lsr #1
     b4c:      	and	w0, w0, #0xf
     b50:      	eor	w0, w0, w14
     b54:      	lsl	w12, w1, #3
     b58:      	orr	w13, w12, w13, lsr #1
     b5c:      	and	w13, w13, #0xf
     b60:      	csel	w12, w8, wzr, ne
     b64:      	eor	w13, w13, w12
     b68:      	lsl	w12, w11, #3
     b6c:      	orr	w1, w12, w1, lsr #1
     b70:      	and	w1, w1, #0xf
     b74:      	csel	w12, w7, wzr, ne
     b78:      	eor	w1, w1, w12
     b7c:      	csel	w12, w6, wzr, ne
     b80:      	eor	w11, w12, w11, lsr #1
     b84:      	and	w15, w4, #0x1
     b88:      	ubfx	x10, x10, #1, #3
     b8c:      	orr	w12, w10, w5, lsl #3
     b90:      	ubfiz	w14, w4, #3, #1
     b94:      	lsl	w16, w3, #3
     b98:      	orr	w5, w16, w5, lsr #1
     b9c:      	and	w5, w5, #0xf
     ba0:      	ubfiz	w4, w4, #1, #1
     ba4:      	eor	w5, w5, w4
     ba8:      	lsl	w4, w2, #3
     bac:      	orr	w4, w4, w3, lsr #1
     bb0:      	and	w4, w4, #0xf
     bb4:      	cmp	w15, #0x0
     bb8:      	csel	w3, w9, wzr, ne
     bbc:      	eor	w4, w4, w3
     bc0:      	lsl	w3, w0, #3
     bc4:      	orr	w2, w3, w2, lsr #1
     bc8:      	and	w2, w2, #0xf
     bcc:      	eor	w2, w2, w14
     bd0:      	lsl	w3, w13, #3
     bd4:      	orr	w0, w3, w0, lsr #1
     bd8:      	and	w0, w0, #0xf
     bdc:      	eor	w0, w0, w14
     be0:      	lsl	w3, w1, #3
     be4:      	orr	w13, w3, w13, lsr #1
     be8:      	and	w13, w13, #0xf
     bec:      	csel	w3, w8, wzr, ne
     bf0:      	eor	w13, w13, w3
     bf4:      	lsl	w3, w11, #3
     bf8:      	orr	w1, w3, w1, lsr #1
     bfc:      	and	w1, w1, #0xf
     c00:      	csel	w3, w7, wzr, ne
     c04:      	eor	w1, w1, w3
     c08:      	csel	w3, w6, wzr, ne
     c0c:      	eor	w11, w3, w11, lsr #1
     c10:      	and	w3, w10, #0x1
     c14:      	ubfx	x12, x12, #1, #3
     c18:      	orr	w14, w12, w5, lsl #3
     c1c:      	ubfiz	w15, w10, #3, #1
     c20:      	lsl	w16, w4, #3
     c24:      	orr	w5, w16, w5, lsr #1
     c28:      	and	w5, w5, #0xf
     c2c:      	ubfiz	w10, w10, #1, #1
     c30:      	eor	w5, w5, w10
     c34:      	lsl	w10, w2, #3
     c38:      	orr	w4, w10, w4, lsr #1
     c3c:      	and	w4, w4, #0xf
     c40:      	cmp	w3, #0x0
     c44:      	csel	w3, w9, wzr, ne
     c48:      	eor	w4, w4, w3
     c4c:      	lsl	w3, w0, #3
     c50:      	orr	w3, w3, w2, lsr #1
     c54:      	and	w3, w3, #0xf
     c58:      	eor	w3, w3, w15
     c5c:      	lsl	w2, w13, #3
     c60:      	orr	w0, w2, w0, lsr #1
     c64:      	and	w0, w0, #0xf
     c68:      	eor	w0, w0, w15
     c6c:      	lsl	w2, w1, #3
     c70:      	orr	w2, w2, w13, lsr #1
     c74:      	and	w2, w2, #0xf
     c78:      	csel	w10, w8, wzr, ne
     c7c:      	eor	w2, w2, w10
     c80:      	lsl	w10, w11, #3
     c84:      	orr	w1, w10, w1, lsr #1
     c88:      	and	w1, w1, #0xf
     c8c:      	csel	w10, w7, wzr, ne
     c90:      	eor	w1, w1, w10
     c94:      	csel	w10, w6, wzr, ne
     c98:      	eor	w11, w10, w11, lsr #1
     c9c:      	and	w15, w12, #0x1
     ca0:      	ubfx	x14, x14, #1, #3
     ca4:      	orr	w10, w14, w5, lsl #3
     ca8:      	ubfiz	w13, w12, #3, #1
     cac:      	lsl	w16, w4, #3
     cb0:      	orr	w5, w16, w5, lsr #1
     cb4:      	and	w5, w5, #0xf
     cb8:      	ubfiz	w12, w12, #1, #1
     cbc:      	eor	w5, w5, w12
     cc0:      	lsl	w12, w3, #3
     cc4:      	orr	w4, w12, w4, lsr #1
     cc8:      	and	w4, w4, #0xf
     ccc:      	cmp	w15, #0x0
     cd0:      	csel	w12, w9, wzr, ne
     cd4:      	eor	w4, w4, w12
     cd8:      	lsl	w12, w0, #3
     cdc:      	orr	w3, w12, w3, lsr #1
     ce0:      	and	w3, w3, #0xf
     ce4:      	eor	w3, w3, w13
     ce8:      	lsl	w12, w2, #3
     cec:      	orr	w12, w12, w0, lsr #1
     cf0:      	and	w12, w12, #0xf
     cf4:      	eor	w12, w12, w13
     cf8:      	lsl	w0, w1, #3
     cfc:      	orr	w2, w0, w2, lsr #1
     d00:      	and	w2, w2, #0xf
     d04:      	csel	w0, w8, wzr, ne
     d08:      	eor	w2, w2, w0
     d0c:      	lsl	w0, w11, #3
     d10:      	orr	w1, w0, w1, lsr #1
     d14:      	and	w1, w1, #0xf
     d18:      	csel	w0, w7, wzr, ne
     d1c:      	eor	w1, w1, w0
     d20:      	csel	w0, w6, wzr, ne
     d24:      	eor	w11, w0, w11, lsr #1
     d28:      	and	w15, w14, #0x1
     d2c:      	ubfiz	w13, w14, #3, #1
     d30:      	lsl	w0, w4, #3
     d34:      	orr	w0, w0, w5, lsr #1
     d38:      	and	w0, w0, #0xf
     d3c:      	ubfiz	w14, w14, #1, #1
     d40:      	eor	w0, w0, w14
     d44:      	lsl	w0, w0, #4
     d48:      	eor	w0, w0, #0xf0
     d4c:      	lsl	w14, w3, #3
     d50:      	orr	w4, w14, w4, lsr #1
     d54:      	and	w4, w4, #0xf
     d58:      	cmp	w15, #0x0
     d5c:      	csel	w9, w9, wzr, ne
     d60:      	eor	w4, w4, w9
     d64:      	lsl	w4, w4, #8
     d68:      	eor	w4, w4, #0xf00
     d6c:      	orr	w0, w0, w4
     d70:      	lsl	w4, w12, #3
     d74:      	orr	w3, w4, w3, lsr #1
     d78:      	and	w3, w3, #0xf
     d7c:      	eor	w3, w3, w13
     d80:      	lsl	w3, w3, #12
     d84:      	eor	w3, w3, #0xf000
     d88:      	lsl	w4, w2, #3
     d8c:      	orr	w4, w4, w12, lsr #1
     d90:      	and	w4, w4, #0xf
     d94:      	eor	w4, w4, w13
     d98:      	lsl	w4, w4, #16
     d9c:      	eor	w4, w4, #0xf0000
     da0:      	orr	w3, w3, w4
     da4:      	orr	w0, w0, w3
     da8:      	lsl	w3, w1, #3
     dac:      	orr	w2, w3, w2, lsr #1
     db0:      	and	w2, w2, #0xf
     db4:      	csel	w8, w8, wzr, ne
     db8:      	eor	w2, w2, w8
     dbc:      	lsl	w2, w2, #20
     dc0:      	eor	w2, w2, #0xf00000
     dc4:      	lsl	w3, w11, #3
     dc8:      	orr	w1, w3, w1, lsr #1
     dcc:      	and	w1, w1, #0xf
     dd0:      	csel	w7, w7, wzr, ne
     dd4:      	eor	w1, w1, w7
     dd8:      	lsl	w1, w1, #24
     ddc:      	eor	w1, w1, #0xf000000
     de0:      	orr	w1, w2, w1
     de4:      	orr	w1, w0, w1
     de8:      	ubfx	x10, x10, #1, #3
     dec:      	orr	w0, w10, w5, lsl #3
     df0:      	mvn	w0, w0
     df4:      	and	w0, w0, #0xf
     df8:      	csel	w6, w6, wzr, ne
     dfc:      	eor	w11, w6, w11, lsr #1
     e00:      	lsl	w11, w11, #28
     e04:      	eor	w11, w11, #0xf0000000
     e08:      	orr	w0, w0, w11
     e0c:      	orr	w0, w1, w0
     e10:      	ret

0000000000000e14 <main>:
     e14:      	sub	sp, sp, #0x60
     e18:      	stp	x29, x30, [sp, #0x30]
     e1c:      	add	x29, sp, #0x30
     e20:      	stp	x19, x20, [sp, #0x40]
     e24:      	mov	x19, x1
     e28:      	adrp	x1, 0x1f000 <__FRAME_END__+0x1de8c>
     e2c:      	ldr	x1, [x1, #0xfe8]
     e30:      	ldr	x2, [x1]
     e34:      	str	x2, [sp, #0x28]
     e38:      	mov	x2, #0x0                // =0
     e3c:      	cmp	w0, #0x1
     e40:      	b.eq	0xe80 <main+0x6c>
     e44:      	mov	w20, #0x3               // =3
     e48:      	cmp	w0, w20
     e4c:      	b.eq	0xee0 <main+0xcc>
     e50:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1de8c>
     e54:      	ldr	x0, [x0, #0xfe8]
     e58:      	ldr	x2, [sp, #0x28]
     e5c:      	ldr	x1, [x0]
     e60:      	subs	x2, x2, x1
     e64:      	mov	x1, #0x0                // =0
     e68:      	b.ne	0xfe8 <main+0x1d4>
     e6c:      	mov	w0, w20
     e70:      	ldp	x19, x20, [sp, #0x40]
     e74:      	ldp	x29, x30, [sp, #0x30]
     e78:      	add	sp, sp, #0x60
     e7c:      	ret
     e80:      	stp	x21, x22, [sp, #0x50]
     e84:      	add	x22, sp, #0x20
     e88:      	add	x21, sp, #0x24
     e8c:      	adrp	x19, 0x1000 <_fini+0x10>
     e90:      	add	x19, x19, #0x18
     e94:      	adrp	x20, 0x1000 <_fini+0x10>
     e98:      	add	x20, x20, #0x10
     e9c:      	b	0xebc <main+0xa8>
     ea0:      	ldr	w1, [sp, #0x24]
     ea4:      	ldr	w0, [sp, #0x20]
     ea8:      	bl	0x918 <kernel>
     eac:      	mov	w2, w0
     eb0:      	mov	x1, x20
     eb4:      	mov	w0, #0x2                // =2
     eb8:      	bl	0x7b0 <__printf_chk@plt>
     ebc:      	mov	x2, x21
     ec0:      	mov	x1, x22
     ec4:      	mov	x0, x19
     ec8:      	bl	0x7f0 <__isoc99_scanf@plt>
     ecc:      	cmp	w0, #0x2
     ed0:      	b.eq	0xea0 <main+0x8c>
     ed4:      	mov	w20, #0x0               // =0
     ed8:      	ldp	x21, x22, [sp, #0x50]
     edc:      	b	0xe50 <main+0x3c>
     ee0:      	stp	x21, x22, [sp, #0x50]
     ee4:      	mov	w2, #0xa                // =10
     ee8:      	mov	x1, #0x0                // =0
     eec:      	ldr	x0, [x19, #0x8]
     ef0:      	bl	0x770 <strtoul@plt>
     ef4:      	mov	x21, x0
     ef8:      	mov	w2, #0xa                // =10
     efc:      	mov	x1, #0x0                // =0
     f00:      	ldr	x0, [x19, #0x10]
     f04:      	bl	0x770 <strtoul@plt>
     f08:      	mov	x19, x0
     f0c:      	mov	x1, sp
     f10:      	mov	w0, #0x1                // =1
     f14:      	bl	0x7a0 <clock_gettime@plt>
     f18:      	cbnz	w0, 0xfd0 <main+0x1bc>
     f1c:      	cbz	x21, 0xfc8 <main+0x1b4>
     f20:      	mov	x20, #0x0               // =0
     f24:      	mov	x22, #0x0               // =0
     f28:      	eor	w19, w19, w19, lsl #13
     f2c:      	eor	w19, w19, w19, lsr #17
     f30:      	eor	w0, w19, w19, lsl #5
     f34:      	str	w0, [sp, #0x20]
     f38:      	eor	w19, w0, w0, lsl #13
     f3c:      	eor	w19, w19, w19, lsr #17
     f40:      	eor	w19, w19, w19, lsl #5
     f44:      	str	w19, [sp, #0x24]
     f48:      	mov	w1, w19
     f4c:      	bl	0x918 <kernel>
     f50:      	add	x22, x22, w0, uxtw
     f54:      	add	x20, x20, #0x1
     f58:      	cmp	x21, x20
     f5c:      	b.ne	0xf28 <main+0x114>
     f60:      	add	x1, sp, #0x10
     f64:      	mov	w0, #0x1                // =1
     f68:      	bl	0x7a0 <clock_gettime@plt>
     f6c:      	mov	w20, w0
     f70:      	cbnz	w0, 0xfdc <main+0x1c8>
     f74:      	ldr	x0, [sp, #0x18]
     f78:      	ldr	x1, [sp, #0x8]
     f7c:      	sub	x0, x0, x1
     f80:      	fmov	d1, x0
     f84:      	scvtf	d1, d1
     f88:      	adrp	x0, 0x1000 <_fini+0x10>
     f8c:      	ldr	d0, [x0, #0x30]
     f90:      	fmul	d1, d1, d0
     f94:      	ldr	x0, [sp, #0x10]
     f98:      	ldr	x1, [sp]
     f9c:      	sub	x0, x0, x1
     fa0:      	fmov	d0, x0
     fa4:      	scvtf	d0, d0
     fa8:      	mov	x2, x22
     fac:      	fadd	d0, d1, d0
     fb0:      	adrp	x1, 0x1000 <_fini+0x10>
     fb4:      	add	x1, x1, #0x20
     fb8:      	mov	w0, #0x2                // =2
     fbc:      	bl	0x7b0 <__printf_chk@plt>
     fc0:      	ldp	x21, x22, [sp, #0x50]
     fc4:      	b	0xe50 <main+0x3c>
     fc8:      	mov	x22, x21
     fcc:      	b	0xf60 <main+0x14c>
     fd0:      	mov	w20, #0x2               // =2
     fd4:      	ldp	x21, x22, [sp, #0x50]
     fd8:      	b	0xe50 <main+0x3c>
     fdc:      	mov	w20, #0x2               // =2
     fe0:      	ldp	x21, x22, [sp, #0x50]
     fe4:      	b	0xe50 <main+0x3c>
     fe8:      	stp	x21, x22, [sp, #0x50]
     fec:      	bl	0x7c0 <__stack_chk_fail@plt>

Disassembly of section .fini:

0000000000000ff0 <_fini>:
     ff0:      	nop
     ff4:      	stp	x29, x30, [sp, #-0x10]!
     ff8:      	mov	x29, sp
     ffc:      	ldp	x29, x30, [sp], #0x10
    1000:      	ret
