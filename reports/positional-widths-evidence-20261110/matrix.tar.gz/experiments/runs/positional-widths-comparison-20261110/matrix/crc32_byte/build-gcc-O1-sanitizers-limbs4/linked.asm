
/work/experiments/runs/positional-widths-comparison-20261110/matrix/crc32_byte/build-gcc-O1-sanitizers-limbs4/program:	file format elf64-littleaarch64

Disassembly of section .init:

00000000000011c0 <_init>:
    11c0:      	nop
    11c4:      	stp	x29, x30, [sp, #-0x10]!
    11c8:      	mov	x29, sp
    11cc:      	bl	0x13b4 <call_weak_fn>
    11d0:      	ldp	x29, x30, [sp], #0x10
    11d4:      	ret

Disassembly of section .plt:

00000000000011e0 <.plt>:
    11e0:      	stp	x16, x30, [sp, #-0x10]!
    11e4:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1cbbc>
    11e8:      	ldr	x17, [x16, #0xf08]
    11ec:      	add	x16, x16, #0xf08
    11f0:      	br	x17
    11f4:      	nop
    11f8:      	nop
    11fc:      	nop

0000000000001200 <__asan_report_store4@plt>:
    1200:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1cbbc>
    1204:      	ldr	x17, [x16, #0xf10]
    1208:      	add	x16, x16, #0xf10
    120c:      	br	x17

0000000000001210 <__ubsan_handle_type_mismatch_v1_abort@plt>:
    1210:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1cbbc>
    1214:      	ldr	x17, [x16, #0xf18]
    1218:      	add	x16, x16, #0xf18
    121c:      	br	x17

0000000000001220 <__asan_register_globals@plt>:
    1220:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1cbbc>
    1224:      	ldr	x17, [x16, #0xf20]
    1228:      	add	x16, x16, #0xf20
    122c:      	br	x17

0000000000001230 <__stack_chk_fail@plt>:
    1230:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1cbbc>
    1234:      	ldr	x17, [x16, #0xf28]
    1238:      	add	x16, x16, #0xf28
    123c:      	br	x17

0000000000001240 <__ubsan_handle_nonnull_arg_abort@plt>:
    1240:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1cbbc>
    1244:      	ldr	x17, [x16, #0xf30]
    1248:      	add	x16, x16, #0xf30
    124c:      	br	x17

0000000000001250 <__ubsan_handle_sub_overflow_abort@plt>:
    1250:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1cbbc>
    1254:      	ldr	x17, [x16, #0xf38]
    1258:      	add	x16, x16, #0xf38
    125c:      	br	x17

0000000000001260 <__asan_report_load4@plt>:
    1260:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1cbbc>
    1264:      	ldr	x17, [x16, #0xf40]
    1268:      	add	x16, x16, #0xf40
    126c:      	br	x17

0000000000001270 <__cxa_finalize@plt>:
    1270:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1cbbc>
    1274:      	ldr	x17, [x16, #0xf48]
    1278:      	add	x16, x16, #0xf48
    127c:      	br	x17

0000000000001280 <__libc_start_main@plt>:
    1280:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1cbbc>
    1284:      	ldr	x17, [x16, #0xf50]
    1288:      	add	x16, x16, #0xf50
    128c:      	br	x17

0000000000001290 <__asan_unregister_globals@plt>:
    1290:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1cbbc>
    1294:      	ldr	x17, [x16, #0xf58]
    1298:      	add	x16, x16, #0xf58
    129c:      	br	x17

00000000000012a0 <__asan_handle_no_return@plt>:
    12a0:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1cbbc>
    12a4:      	ldr	x17, [x16, #0xf60]
    12a8:      	add	x16, x16, #0xf60
    12ac:      	br	x17

00000000000012b0 <__asan_init@plt>:
    12b0:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1cbbc>
    12b4:      	ldr	x17, [x16, #0xf68]
    12b8:      	add	x16, x16, #0xf68
    12bc:      	br	x17

00000000000012c0 <strtoul@plt>:
    12c0:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1cbbc>
    12c4:      	ldr	x17, [x16, #0xf70]
    12c8:      	add	x16, x16, #0xf70
    12cc:      	br	x17

00000000000012d0 <clock_gettime@plt>:
    12d0:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1cbbc>
    12d4:      	ldr	x17, [x16, #0xf78]
    12d8:      	add	x16, x16, #0xf78
    12dc:      	br	x17

00000000000012e0 <__asan_report_load8@plt>:
    12e0:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1cbbc>
    12e4:      	ldr	x17, [x16, #0xf80]
    12e8:      	add	x16, x16, #0xf80
    12ec:      	br	x17

00000000000012f0 <abort@plt>:
    12f0:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1cbbc>
    12f4:      	ldr	x17, [x16, #0xf88]
    12f8:      	add	x16, x16, #0xf88
    12fc:      	br	x17

0000000000001300 <__asan_stack_malloc_2@plt>:
    1300:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1cbbc>
    1304:      	ldr	x17, [x16, #0xf90]
    1308:      	add	x16, x16, #0xf90
    130c:      	br	x17

0000000000001310 <__asan_version_mismatch_check_v8@plt>:
    1310:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1cbbc>
    1314:      	ldr	x17, [x16, #0xf98]
    1318:      	add	x16, x16, #0xf98
    131c:      	br	x17

0000000000001320 <__isoc99_scanf@plt>:
    1320:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1cbbc>
    1324:      	ldr	x17, [x16, #0xfa0]
    1328:      	add	x16, x16, #0xfa0
    132c:      	br	x17

0000000000001330 <__printf_chk@plt>:
    1330:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1cbbc>
    1334:      	ldr	x17, [x16, #0xfa8]
    1338:      	add	x16, x16, #0xfa8
    133c:      	br	x17

0000000000001340 <__gmon_start__@plt>:
    1340:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1cbbc>
    1344:      	ldr	x17, [x16, #0xfb0]
    1348:      	add	x16, x16, #0xfb0
    134c:      	br	x17

0000000000001350 <__ubsan_handle_pointer_overflow_abort@plt>:
    1350:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1cbbc>
    1354:      	ldr	x17, [x16, #0xfb8]
    1358:      	add	x16, x16, #0xfb8
    135c:      	br	x17

Disassembly of section .text:

0000000000001380 <_start>:
    1380:      	nop
    1384:      	mov	x29, #0x0               // =0
    1388:      	mov	x30, #0x0               // =0
    138c:      	mov	x5, x0
    1390:      	ldr	x1, [sp]
    1394:      	add	x2, sp, #0x8
    1398:      	mov	x6, sp
    139c:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1cbbc>
    13a0:      	ldr	x0, [x0, #0xfd0]
    13a4:      	mov	x3, #0x0                // =0
    13a8:      	mov	x4, #0x0                // =0
    13ac:      	bl	0x1280 <__libc_start_main@plt>
    13b0:      	bl	0x12f0 <abort@plt>

00000000000013b4 <call_weak_fn>:
    13b4:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1cbbc>
    13b8:      	ldr	x0, [x0, #0xff0]
    13bc:      	cbz	x0, 0x13c4 <call_weak_fn+0x10>
    13c0:      	b	0x1340 <__gmon_start__@plt>
    13c4:      	ret
    13c8:      	nop
    13cc:      	nop

00000000000013d0 <deregister_tm_clones>:
    13d0:      	adrp	x0, 0x20000 <data_start>
    13d4:      	add	x0, x0, #0x780
    13d8:      	adrp	x1, 0x20000 <data_start>
    13dc:      	add	x1, x1, #0x780
    13e0:      	cmp	x1, x0
    13e4:      	b.eq	0x13fc <deregister_tm_clones+0x2c>
    13e8:      	adrp	x1, 0x1f000 <__FRAME_END__+0x1cbbc>
    13ec:      	ldr	x1, [x1, #0xfe8]
    13f0:      	cbz	x1, 0x13fc <deregister_tm_clones+0x2c>
    13f4:      	mov	x16, x1
    13f8:      	br	x16
    13fc:      	ret

0000000000001400 <register_tm_clones>:
    1400:      	adrp	x0, 0x20000 <data_start>
    1404:      	add	x0, x0, #0x780
    1408:      	adrp	x1, 0x20000 <data_start>
    140c:      	add	x1, x1, #0x780
    1410:      	sub	x1, x1, x0
    1414:      	lsr	x2, x1, #63
    1418:      	add	x1, x2, x1, asr #3
    141c:      	asr	x1, x1, #1
    1420:      	cbz	x1, 0x1438 <register_tm_clones+0x38>
    1424:      	adrp	x2, 0x1f000 <__FRAME_END__+0x1cbbc>
    1428:      	ldr	x2, [x2, #0xff8]
    142c:      	cbz	x2, 0x1438 <register_tm_clones+0x38>
    1430:      	mov	x16, x2
    1434:      	br	x16
    1438:      	ret
    143c:      	nop

0000000000001440 <__do_global_dtors_aux>:
    1440:      	paciasp
    1444:      	stp	x29, x30, [sp, #-0x20]!
    1448:      	mov	x29, sp
    144c:      	str	x19, [sp, #0x10]
    1450:      	adrp	x19, 0x20000 <data_start>
    1454:      	ldrb	w0, [x19, #0x780]
    1458:      	tbnz	w0, #0x0, 0x1480 <__do_global_dtors_aux+0x40>
    145c:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1cbbc>
    1460:      	ldr	x0, [x0, #0xfd8]
    1464:      	cbz	x0, 0x1474 <__do_global_dtors_aux+0x34>
    1468:      	adrp	x0, 0x20000 <data_start>
    146c:      	ldr	x0, [x0, #0x8]
    1470:      	bl	0x1270 <__cxa_finalize@plt>
    1474:      	bl	0x13d0 <deregister_tm_clones>
    1478:      	mov	w0, #0x1                // =1
    147c:      	strb	w0, [x19, #0x780]
    1480:      	ldr	x19, [sp, #0x10]
    1484:      	ldp	x29, x30, [sp], #0x20
    1488:      	autiasp
    148c:      	ret

0000000000001490 <frame_dummy>:
    1490:      	bti	c
    1494:      	b	0x1400 <register_tm_clones>

0000000000001498 <kernel>:
    1498:      	mvn	w3, w0, lsr #8
    149c:      	mvn	w8, w0, lsr #12
    14a0:      	mvn	w7, w0, lsr #16
    14a4:      	mvn	w6, w0, lsr #20
    14a8:      	mvn	w4, w0, lsr #24
    14ac:      	lsr	w11, w0, #28
    14b0:      	eor	w11, w11, #0xf
    14b4:      	eor	w2, w0, w1
    14b8:      	eon	w0, w0, w1
    14bc:      	mvn	w1, w2, lsr #4
    14c0:      	and	w2, w0, #0x1
    14c4:      	ubfx	x14, x0, #1, #3
    14c8:      	ubfiz	w10, w1, #3, #4
    14cc:      	orr	w10, w14, w10
    14d0:      	ubfiz	w12, w0, #3, #1
    14d4:      	ubfx	x1, x1, #1, #3
    14d8:      	ubfiz	w5, w3, #3, #1
    14dc:      	orr	w5, w5, w1
    14e0:      	ubfiz	w0, w0, #1, #1
    14e4:      	eor	w5, w5, w0
    14e8:      	ubfx	x3, x3, #1, #3
    14ec:      	ubfiz	w0, w8, #3, #1
    14f0:      	orr	w3, w0, w3
    14f4:      	mov	w9, #0x3                // =3
    14f8:      	cmp	w2, #0x0
    14fc:      	csel	w0, w9, wzr, ne
    1500:      	eor	w3, w3, w0
    1504:      	ubfx	x8, x8, #1, #3
    1508:      	ubfiz	w2, w7, #3, #1
    150c:      	orr	w2, w2, w8
    1510:      	eor	w2, w2, w12
    1514:      	ubfx	x7, x7, #1, #3
    1518:      	ubfiz	w0, w6, #3, #1
    151c:      	orr	w0, w0, w7
    1520:      	eor	w0, w0, w12
    1524:      	ubfx	x6, x6, #1, #3
    1528:      	ubfiz	w13, w4, #3, #1
    152c:      	orr	w13, w13, w6
    1530:      	mov	w8, #0xb                // =11
    1534:      	csel	w1, w8, wzr, ne
    1538:      	eor	w13, w13, w1
    153c:      	ubfx	x1, x4, #1, #3
    1540:      	orr	w1, w1, w11, lsl #3
    1544:      	and	w1, w1, #0xf
    1548:      	mov	w7, #0xd                // =13
    154c:      	csel	w4, w7, wzr, ne
    1550:      	eor	w1, w1, w4
    1554:      	mov	w6, #0xe                // =14
    1558:      	csel	w4, w6, wzr, ne
    155c:      	eor	w11, w4, w11, lsr #1
    1560:      	and	w16, w14, #0x1
    1564:      	ubfx	x10, x10, #1, #3
    1568:      	orr	w12, w10, w5, lsl #3
    156c:      	ubfiz	w15, w14, #3, #1
    1570:      	lsl	w4, w3, #3
    1574:      	orr	w5, w4, w5, lsr #1
    1578:      	and	w5, w5, #0xf
    157c:      	ubfiz	w4, w14, #1, #1
    1580:      	eor	w5, w5, w4
    1584:      	lsl	w4, w2, #3
    1588:      	orr	w3, w4, w3, lsr #1
    158c:      	and	w3, w3, #0xf
    1590:      	cmp	w16, #0x0
    1594:      	csel	w4, w9, wzr, ne
    1598:      	eor	w3, w3, w4
    159c:      	lsl	w4, w0, #3
    15a0:      	orr	w2, w4, w2, lsr #1
    15a4:      	and	w2, w2, #0xf
    15a8:      	eor	w2, w2, w15
    15ac:      	lsl	w4, w13, #3
    15b0:      	orr	w0, w4, w0, lsr #1
    15b4:      	and	w0, w0, #0xf
    15b8:      	eor	w0, w0, w15
    15bc:      	lsl	w4, w1, #3
    15c0:      	orr	w13, w4, w13, lsr #1
    15c4:      	and	w13, w13, #0xf
    15c8:      	csel	w4, w8, wzr, ne
    15cc:      	eor	w13, w13, w4
    15d0:      	lsl	w4, w11, #3
    15d4:      	orr	w1, w4, w1, lsr #1
    15d8:      	and	w1, w1, #0xf
    15dc:      	csel	w4, w7, wzr, ne
    15e0:      	eor	w1, w1, w4
    15e4:      	csel	w4, w6, wzr, ne
    15e8:      	eor	w11, w4, w11, lsr #1
    15ec:      	and	w15, w10, #0x1
    15f0:      	ubfx	x12, x12, #1, #3
    15f4:      	orr	w4, w12, w5, lsl #3
    15f8:      	ubfiz	w14, w10, #3, #1
    15fc:      	lsl	w16, w3, #3
    1600:      	orr	w5, w16, w5, lsr #1
    1604:      	and	w5, w5, #0xf
    1608:      	ubfiz	w10, w10, #1, #1
    160c:      	eor	w5, w5, w10
    1610:      	lsl	w10, w2, #3
    1614:      	orr	w3, w10, w3, lsr #1
    1618:      	and	w3, w3, #0xf
    161c:      	cmp	w15, #0x0
    1620:      	csel	w10, w9, wzr, ne
    1624:      	eor	w3, w3, w10
    1628:      	lsl	w10, w0, #3
    162c:      	orr	w2, w10, w2, lsr #1
    1630:      	and	w2, w2, #0xf
    1634:      	eor	w2, w2, w14
    1638:      	lsl	w10, w13, #3
    163c:      	orr	w0, w10, w0, lsr #1
    1640:      	and	w0, w0, #0xf
    1644:      	eor	w0, w0, w14
    1648:      	lsl	w10, w1, #3
    164c:      	orr	w13, w10, w13, lsr #1
    1650:      	and	w13, w13, #0xf
    1654:      	csel	w10, w8, wzr, ne
    1658:      	eor	w13, w13, w10
    165c:      	lsl	w10, w11, #3
    1660:      	orr	w1, w10, w1, lsr #1
    1664:      	and	w1, w1, #0xf
    1668:      	csel	w10, w7, wzr, ne
    166c:      	eor	w1, w1, w10
    1670:      	csel	w10, w6, wzr, ne
    1674:      	eor	w11, w10, w11, lsr #1
    1678:      	and	w15, w12, #0x1
    167c:      	ubfx	x4, x4, #1, #3
    1680:      	orr	w10, w4, w5, lsl #3
    1684:      	ubfiz	w14, w12, #3, #1
    1688:      	lsl	w16, w3, #3
    168c:      	orr	w5, w16, w5, lsr #1
    1690:      	and	w5, w5, #0xf
    1694:      	ubfiz	w12, w12, #1, #1
    1698:      	eor	w5, w5, w12
    169c:      	lsl	w12, w2, #3
    16a0:      	orr	w3, w12, w3, lsr #1
    16a4:      	and	w3, w3, #0xf
    16a8:      	cmp	w15, #0x0
    16ac:      	csel	w12, w9, wzr, ne
    16b0:      	eor	w3, w3, w12
    16b4:      	lsl	w12, w0, #3
    16b8:      	orr	w2, w12, w2, lsr #1
    16bc:      	and	w2, w2, #0xf
    16c0:      	eor	w2, w2, w14
    16c4:      	lsl	w12, w13, #3
    16c8:      	orr	w0, w12, w0, lsr #1
    16cc:      	and	w0, w0, #0xf
    16d0:      	eor	w0, w0, w14
    16d4:      	lsl	w12, w1, #3
    16d8:      	orr	w13, w12, w13, lsr #1
    16dc:      	and	w13, w13, #0xf
    16e0:      	csel	w12, w8, wzr, ne
    16e4:      	eor	w13, w13, w12
    16e8:      	lsl	w12, w11, #3
    16ec:      	orr	w1, w12, w1, lsr #1
    16f0:      	and	w1, w1, #0xf
    16f4:      	csel	w12, w7, wzr, ne
    16f8:      	eor	w1, w1, w12
    16fc:      	csel	w12, w6, wzr, ne
    1700:      	eor	w11, w12, w11, lsr #1
    1704:      	and	w15, w4, #0x1
    1708:      	ubfx	x10, x10, #1, #3
    170c:      	orr	w12, w10, w5, lsl #3
    1710:      	ubfiz	w14, w4, #3, #1
    1714:      	lsl	w16, w3, #3
    1718:      	orr	w5, w16, w5, lsr #1
    171c:      	and	w5, w5, #0xf
    1720:      	ubfiz	w4, w4, #1, #1
    1724:      	eor	w5, w5, w4
    1728:      	lsl	w4, w2, #3
    172c:      	orr	w4, w4, w3, lsr #1
    1730:      	and	w4, w4, #0xf
    1734:      	cmp	w15, #0x0
    1738:      	csel	w3, w9, wzr, ne
    173c:      	eor	w4, w4, w3
    1740:      	lsl	w3, w0, #3
    1744:      	orr	w2, w3, w2, lsr #1
    1748:      	and	w2, w2, #0xf
    174c:      	eor	w2, w2, w14
    1750:      	lsl	w3, w13, #3
    1754:      	orr	w0, w3, w0, lsr #1
    1758:      	and	w0, w0, #0xf
    175c:      	eor	w0, w0, w14
    1760:      	lsl	w3, w1, #3
    1764:      	orr	w13, w3, w13, lsr #1
    1768:      	and	w13, w13, #0xf
    176c:      	csel	w3, w8, wzr, ne
    1770:      	eor	w13, w13, w3
    1774:      	lsl	w3, w11, #3
    1778:      	orr	w1, w3, w1, lsr #1
    177c:      	and	w1, w1, #0xf
    1780:      	csel	w3, w7, wzr, ne
    1784:      	eor	w1, w1, w3
    1788:      	csel	w3, w6, wzr, ne
    178c:      	eor	w11, w3, w11, lsr #1
    1790:      	and	w3, w10, #0x1
    1794:      	ubfx	x12, x12, #1, #3
    1798:      	orr	w14, w12, w5, lsl #3
    179c:      	ubfiz	w15, w10, #3, #1
    17a0:      	lsl	w16, w4, #3
    17a4:      	orr	w5, w16, w5, lsr #1
    17a8:      	and	w5, w5, #0xf
    17ac:      	ubfiz	w10, w10, #1, #1
    17b0:      	eor	w5, w5, w10
    17b4:      	lsl	w10, w2, #3
    17b8:      	orr	w4, w10, w4, lsr #1
    17bc:      	and	w4, w4, #0xf
    17c0:      	cmp	w3, #0x0
    17c4:      	csel	w3, w9, wzr, ne
    17c8:      	eor	w4, w4, w3
    17cc:      	lsl	w3, w0, #3
    17d0:      	orr	w3, w3, w2, lsr #1
    17d4:      	and	w3, w3, #0xf
    17d8:      	eor	w3, w3, w15
    17dc:      	lsl	w2, w13, #3
    17e0:      	orr	w0, w2, w0, lsr #1
    17e4:      	and	w0, w0, #0xf
    17e8:      	eor	w0, w0, w15
    17ec:      	lsl	w2, w1, #3
    17f0:      	orr	w2, w2, w13, lsr #1
    17f4:      	and	w2, w2, #0xf
    17f8:      	csel	w10, w8, wzr, ne
    17fc:      	eor	w2, w2, w10
    1800:      	lsl	w10, w11, #3
    1804:      	orr	w1, w10, w1, lsr #1
    1808:      	and	w1, w1, #0xf
    180c:      	csel	w10, w7, wzr, ne
    1810:      	eor	w1, w1, w10
    1814:      	csel	w10, w6, wzr, ne
    1818:      	eor	w11, w10, w11, lsr #1
    181c:      	and	w15, w12, #0x1
    1820:      	ubfx	x14, x14, #1, #3
    1824:      	orr	w10, w14, w5, lsl #3
    1828:      	ubfiz	w13, w12, #3, #1
    182c:      	lsl	w16, w4, #3
    1830:      	orr	w5, w16, w5, lsr #1
    1834:      	and	w5, w5, #0xf
    1838:      	ubfiz	w12, w12, #1, #1
    183c:      	eor	w5, w5, w12
    1840:      	lsl	w12, w3, #3
    1844:      	orr	w4, w12, w4, lsr #1
    1848:      	and	w4, w4, #0xf
    184c:      	cmp	w15, #0x0
    1850:      	csel	w12, w9, wzr, ne
    1854:      	eor	w4, w4, w12
    1858:      	lsl	w12, w0, #3
    185c:      	orr	w3, w12, w3, lsr #1
    1860:      	and	w3, w3, #0xf
    1864:      	eor	w3, w3, w13
    1868:      	lsl	w12, w2, #3
    186c:      	orr	w12, w12, w0, lsr #1
    1870:      	and	w12, w12, #0xf
    1874:      	eor	w12, w12, w13
    1878:      	lsl	w0, w1, #3
    187c:      	orr	w2, w0, w2, lsr #1
    1880:      	and	w2, w2, #0xf
    1884:      	csel	w0, w8, wzr, ne
    1888:      	eor	w2, w2, w0
    188c:      	lsl	w0, w11, #3
    1890:      	orr	w1, w0, w1, lsr #1
    1894:      	and	w1, w1, #0xf
    1898:      	csel	w0, w7, wzr, ne
    189c:      	eor	w1, w1, w0
    18a0:      	csel	w0, w6, wzr, ne
    18a4:      	eor	w11, w0, w11, lsr #1
    18a8:      	and	w15, w14, #0x1
    18ac:      	ubfiz	w13, w14, #3, #1
    18b0:      	lsl	w0, w4, #3
    18b4:      	orr	w0, w0, w5, lsr #1
    18b8:      	and	w0, w0, #0xf
    18bc:      	ubfiz	w14, w14, #1, #1
    18c0:      	eor	w0, w0, w14
    18c4:      	lsl	w0, w0, #4
    18c8:      	eor	w0, w0, #0xf0
    18cc:      	lsl	w14, w3, #3
    18d0:      	orr	w4, w14, w4, lsr #1
    18d4:      	and	w4, w4, #0xf
    18d8:      	cmp	w15, #0x0
    18dc:      	csel	w9, w9, wzr, ne
    18e0:      	eor	w4, w4, w9
    18e4:      	lsl	w4, w4, #8
    18e8:      	eor	w4, w4, #0xf00
    18ec:      	orr	w0, w0, w4
    18f0:      	lsl	w4, w12, #3
    18f4:      	orr	w3, w4, w3, lsr #1
    18f8:      	and	w3, w3, #0xf
    18fc:      	eor	w3, w3, w13
    1900:      	lsl	w3, w3, #12
    1904:      	eor	w3, w3, #0xf000
    1908:      	lsl	w4, w2, #3
    190c:      	orr	w4, w4, w12, lsr #1
    1910:      	and	w4, w4, #0xf
    1914:      	eor	w4, w4, w13
    1918:      	lsl	w4, w4, #16
    191c:      	eor	w4, w4, #0xf0000
    1920:      	orr	w3, w3, w4
    1924:      	orr	w0, w0, w3
    1928:      	lsl	w3, w1, #3
    192c:      	orr	w2, w3, w2, lsr #1
    1930:      	and	w2, w2, #0xf
    1934:      	csel	w8, w8, wzr, ne
    1938:      	eor	w2, w2, w8
    193c:      	lsl	w2, w2, #20
    1940:      	eor	w2, w2, #0xf00000
    1944:      	lsl	w3, w11, #3
    1948:      	orr	w1, w3, w1, lsr #1
    194c:      	and	w1, w1, #0xf
    1950:      	csel	w7, w7, wzr, ne
    1954:      	eor	w1, w1, w7
    1958:      	lsl	w1, w1, #24
    195c:      	eor	w1, w1, #0xf000000
    1960:      	orr	w1, w2, w1
    1964:      	orr	w1, w0, w1
    1968:      	ubfx	x10, x10, #1, #3
    196c:      	orr	w0, w10, w5, lsl #3
    1970:      	mvn	w0, w0
    1974:      	and	w0, w0, #0xf
    1978:      	csel	w6, w6, wzr, ne
    197c:      	eor	w11, w6, w11, lsr #1
    1980:      	lsl	w11, w11, #28
    1984:      	eor	w11, w11, #0xf0000000
    1988:      	orr	w0, w0, w11
    198c:      	orr	w0, w1, w0
    1990:      	ret

0000000000001994 <_sub_I_00099_0>:
    1994:      	stp	x29, x30, [sp, #-0x10]!
    1998:      	mov	x29, sp
    199c:      	bl	0x12b0 <__asan_init@plt>
    19a0:      	bl	0x1310 <__asan_version_mismatch_check_v8@plt>
    19a4:      	ldp	x29, x30, [sp], #0x10
    19a8:      	ret

00000000000019ac <main>:
    19ac:      	sub	sp, sp, #0x130
    19b0:      	stp	x29, x30, [sp, #0xd0]
    19b4:      	add	x29, sp, #0xd0
    19b8:      	stp	x19, x20, [sp, #0xe0]
    19bc:      	stp	x21, x22, [sp, #0xf0]
    19c0:      	stp	x23, x24, [sp, #0x100]
    19c4:      	stp	x27, x28, [sp, #0x120]
    19c8:      	mov	w21, w0
    19cc:      	mov	x20, x1
    19d0:      	add	x23, sp, #0x10
    19d4:      	mov	x28, x23
    19d8:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1cbbc>
    19dc:      	ldr	x0, [x0, #0xfe0]
    19e0:      	ldr	w0, [x0]
    19e4:      	cbnz	w0, 0x1cf0 <main+0x344>
    19e8:      	mov	x19, x23
    19ec:      	mov	x0, #0x8ab3             // =35507
    19f0:      	movk	x0, #0x41b5, lsl #16
    19f4:      	str	x0, [x19], #0xc0
    19f8:      	adrp	x0, 0x1000 <strtoul@GLIBC_2.17+0x1000>
    19fc:      	add	x0, x0, #0xfc8
    1a00:      	str	x0, [x23, #0x8]
    1a04:      	adrp	x0, 0x1000 <strtoul@GLIBC_2.17+0x1000>
    1a08:      	add	x0, x0, #0x9ac
    1a0c:      	str	x0, [x23, #0x10]
    1a10:      	lsr	x24, x23, #3
    1a14:      	mov	x0, #0x1000000000       // =68719476736
    1a18:      	add	x1, x24, x0
    1a1c:      	mov	w2, #-0xe0e0e0f         // =-235802127
    1a20:      	str	w2, [x24, x0]
    1a24:      	add	w2, w2, #0x130, lsl #12 // =0x130000
    1a28:      	str	w2, [x1, #0x4]
    1a2c:      	mov	w0, #-0xd0e0000         // =-219021312
    1a30:      	str	w0, [x1, #0x8]
    1a34:      	str	w0, [x1, #0xc]
    1a38:      	mov	w0, #0xf300             // =62208
    1a3c:      	movk	w0, #0xf3f3, lsl #16
    1a40:      	str	w0, [x1, #0x10]
    1a44:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1cbbc>
    1a48:      	ldr	x0, [x0, #0xfc8]
    1a4c:      	ldr	x1, [x0]
    1a50:      	str	x1, [sp, #0xc8]
    1a54:      	mov	x1, #0x0                // =0
    1a58:      	cmp	w21, #0x1
    1a5c:      	b.eq	0x1d04 <main+0x358>
    1a60:      	cmp	w21, #0x3
    1a64:      	b.ne	0x1eac <main+0x500>
    1a68:      	stp	x25, x26, [sp, #0x110]
    1a6c:      	add	x2, x20, #0x8
    1a70:      	cmn	x20, #0x8
    1a74:      	b.hs	0x1da8 <main+0x3fc>
    1a78:      	adds	x1, x20, #0x8
    1a7c:      	b.eq	0x1db8 <main+0x40c>
    1a80:      	tst	x1, #0x7
    1a84:      	b.ne	0x1db8 <main+0x40c>
    1a88:      	add	x0, x20, #0x8
    1a8c:      	lsr	x2, x0, #3
    1a90:      	mov	x1, #0x1000000000       // =68719476736
    1a94:      	ldrsb	w1, [x2, x1]
    1a98:      	cbnz	w1, 0x1dc8 <main+0x41c>
    1a9c:      	ldr	x0, [x20, #0x8]
    1aa0:      	cbz	x0, 0x1dcc <main+0x420>
    1aa4:      	mov	w2, #0xa                // =10
    1aa8:      	mov	x1, #0x0                // =0
    1aac:      	bl	0x12c0 <strtoul@plt>
    1ab0:      	mov	x25, x0
    1ab4:      	add	x2, x20, #0x10
    1ab8:      	cmn	x20, #0x10
    1abc:      	b.hs	0x1de0 <main+0x434>
    1ac0:      	adds	x1, x20, #0x10
    1ac4:      	b.eq	0x1df4 <main+0x448>
    1ac8:      	tst	x1, #0x7
    1acc:      	b.ne	0x1df4 <main+0x448>
    1ad0:      	add	x0, x20, #0x10
    1ad4:      	lsr	x2, x0, #3
    1ad8:      	mov	x1, #0x1000000000       // =68719476736
    1adc:      	ldrsb	w1, [x2, x1]
    1ae0:      	cbnz	w1, 0x1e04 <main+0x458>
    1ae4:      	ldr	x0, [x20, #0x10]
    1ae8:      	cbz	x0, 0x1e08 <main+0x45c>
    1aec:      	mov	w2, #0xa                // =10
    1af0:      	mov	x1, #0x0                // =0
    1af4:      	bl	0x12c0 <strtoul@plt>
    1af8:      	sub	x2, x19, #0x90
    1afc:      	lsr	x3, x2, #3
    1b00:      	mov	x1, #0x1000000000       // =68719476736
    1b04:      	ldrsb	w1, [x3, x1]
    1b08:      	cmp	w1, #0x0
    1b0c:      	mov	w3, #0x3                // =3
    1b10:      	ccmp	w3, w1, #0x1, ne
    1b14:      	b.ge	0x1e1c <main+0x470>
    1b18:      	stur	w0, [x19, #-0x90]
    1b1c:      	sub	x1, x19, #0x80
    1b20:      	mov	w0, #0x1                // =1
    1b24:      	bl	0x12d0 <clock_gettime@plt>
    1b28:      	cbnz	w0, 0x1f04 <main+0x558>
    1b2c:      	cbz	x25, 0x1e6c <main+0x4c0>
    1b30:      	mov	x21, #0x0               // =0
    1b34:      	mov	x22, #0x0               // =0
    1b38:      	sub	x0, x19, #0x90
    1b3c:      	str	x0, [sp, #0x8]
    1b40:      	lsr	x27, x0, #3
    1b44:      	sub	x20, x19, #0x40
    1b48:      	and	x26, x19, #0x7
    1b4c:      	add	w26, w26, #0x3
    1b50:      	mov	x0, #0x1000000000       // =68719476736
    1b54:      	ldrsb	w0, [x27, x0]
    1b58:      	cmp	w0, #0x0
    1b5c:      	mov	w1, #0x3                // =3
    1b60:      	ccmp	w1, w0, #0x1, ne
    1b64:      	b.ge	0x1e24 <main+0x478>
    1b68:      	ldur	w0, [x19, #-0x90]
    1b6c:      	eor	w0, w0, w0, lsl #13
    1b70:      	eor	w0, w0, w0, lsr #17
    1b74:      	eor	w0, w0, w0, lsl #5
    1b78:      	stur	w0, [x19, #-0x90]
    1b7c:      	lsr	x1, x20, #3
    1b80:      	mov	x2, #0x1000000000       // =68719476736
    1b84:      	ldrsb	w1, [x1, x2]
    1b88:      	cmp	w1, #0x0
    1b8c:      	ccmp	w26, w1, #0x1, ne
    1b90:      	b.ge	0x1e2c <main+0x480>
    1b94:      	stur	w0, [x19, #-0x40]
    1b98:      	eor	w1, w0, w0, lsl #13
    1b9c:      	eor	w1, w1, w1, lsr #17
    1ba0:      	eor	w1, w1, w1, lsl #5
    1ba4:      	stur	w1, [x19, #-0x90]
    1ba8:      	sub	x2, x19, #0x38
    1bac:      	sub	x2, x2, x20
    1bb0:      	cmp	x2, #0x8
    1bb4:      	b.hi	0x1e34 <main+0x488>
    1bb8:      	sub	x3, x19, #0x3c
    1bbc:      	lsr	x4, x3, #3
    1bc0:      	mov	x2, #0x1000000000       // =68719476736
    1bc4:      	ldrsb	w4, [x4, x2]
    1bc8:      	and	x2, x3, #0x7
    1bcc:      	add	w2, w2, #0x3
    1bd0:      	cmp	w4, #0x0
    1bd4:      	ccmp	w2, w4, #0x1, ne
    1bd8:      	b.ge	0x1e54 <main+0x4a8>
    1bdc:      	stur	w1, [x19, #-0x3c]
    1be0:      	lsr	x2, x20, #3
    1be4:      	mov	x3, #0x1000000000       // =68719476736
    1be8:      	ldrsb	w2, [x2, x3]
    1bec:      	cmp	w2, #0x0
    1bf0:      	mov	w3, #0x3                // =3
    1bf4:      	ccmp	w3, w2, #0x1, ne
    1bf8:      	b.ge	0x1e5c <main+0x4b0>
    1bfc:      	sub	x3, x19, #0x3c
    1c00:      	lsr	x4, x3, #3
    1c04:      	mov	x2, #0x1000000000       // =68719476736
    1c08:      	ldrsb	w4, [x4, x2]
    1c0c:      	and	x2, x3, #0x7
    1c10:      	add	w2, w2, #0x3
    1c14:      	cmp	w4, #0x0
    1c18:      	ccmp	w2, w4, #0x1, ne
    1c1c:      	b.ge	0x1e64 <main+0x4b8>
    1c20:      	bl	0x1498 <kernel>
    1c24:      	add	x22, x22, w0, uxtw
    1c28:      	add	x21, x21, #0x1
    1c2c:      	cmp	x25, x21
    1c30:      	b.ne	0x1b50 <main+0x1a4>
    1c34:      	sub	x1, x19, #0x60
    1c38:      	mov	w0, #0x1                // =1
    1c3c:      	bl	0x12d0 <clock_gettime@plt>
    1c40:      	mov	w20, w0
    1c44:      	cbnz	w0, 0x1f10 <main+0x564>
    1c48:      	sub	x0, x19, #0x60
    1c4c:      	lsr	x2, x0, #3
    1c50:      	mov	x1, #0x1000000000       // =68719476736
    1c54:      	ldrsb	w1, [x2, x1]
    1c58:      	cbnz	w1, 0x1e74 <main+0x4c8>
    1c5c:      	ldur	x1, [x19, #-0x60]
    1c60:      	sub	x0, x19, #0x80
    1c64:      	lsr	x3, x0, #3
    1c68:      	mov	x2, #0x1000000000       // =68719476736
    1c6c:      	ldrsb	w2, [x3, x2]
    1c70:      	cbnz	w2, 0x1e78 <main+0x4cc>
    1c74:      	ldur	x0, [x19, #-0x80]
    1c78:      	subs	x0, x1, x0
    1c7c:      	b.vs	0x1e7c <main+0x4d0>
    1c80:      	scvtf	d1, x0
    1c84:      	sub	x0, x19, #0x58
    1c88:      	lsr	x2, x0, #3
    1c8c:      	mov	x1, #0x1000000000       // =68719476736
    1c90:      	ldrsb	w1, [x2, x1]
    1c94:      	cbnz	w1, 0x1e90 <main+0x4e4>
    1c98:      	ldur	x1, [x19, #-0x58]
    1c9c:      	sub	x0, x19, #0x78
    1ca0:      	lsr	x3, x0, #3
    1ca4:      	mov	x2, #0x1000000000       // =68719476736
    1ca8:      	ldrsb	w2, [x3, x2]
    1cac:      	cbnz	w2, 0x1e94 <main+0x4e8>
    1cb0:      	ldur	x0, [x19, #-0x78]
    1cb4:      	subs	x0, x1, x0
    1cb8:      	b.vs	0x1e98 <main+0x4ec>
    1cbc:      	scvtf	d0, x0
    1cc0:      	adrp	x0, 0x2000 <_IO_stdin_used+0x40>
    1cc4:      	ldr	d2, [x0, #0xf0]
    1cc8:      	fmul	d0, d0, d2
    1ccc:      	mov	x2, x22
    1cd0:      	fadd	d0, d0, d1
    1cd4:      	adrp	x1, 0x2000 <_IO_stdin_used+0x40>
    1cd8:      	add	x1, x1, #0x100
    1cdc:      	add	x1, x1, #0x80
    1ce0:      	mov	w0, #0x2                // =2
    1ce4:      	bl	0x1330 <__printf_chk@plt>
    1ce8:      	ldp	x25, x26, [sp, #0x110]
    1cec:      	b	0x1eb0 <main+0x504>
    1cf0:      	mov	x0, #0xa0               // =160
    1cf4:      	bl	0x1300 <__asan_stack_malloc_2@plt>
    1cf8:      	cmp	x0, #0x0
    1cfc:      	csel	x23, x23, x0, eq
    1d00:      	b	0x19e8 <main+0x3c>
    1d04:      	stp	x25, x26, [sp, #0x110]
    1d08:      	sub	x20, x19, #0x3c
    1d0c:      	adrp	x21, 0x2000 <_IO_stdin_used+0x40>
    1d10:      	add	x21, x21, #0x100
    1d14:      	add	x25, x21, #0x40
    1d18:      	and	x22, x20, #0x7
    1d1c:      	add	w22, w22, #0x3
    1d20:      	b	0x1d40 <main+0x394>
    1d24:      	bl	0x1260 <__asan_report_load4@plt>
    1d28:      	ldur	w1, [x19, #-0x3c]
    1d2c:      	bl	0x1498 <kernel>
    1d30:      	mov	w2, w0
    1d34:      	mov	x1, x21
    1d38:      	mov	w0, #0x2                // =2
    1d3c:      	bl	0x1330 <__printf_chk@plt>
    1d40:      	mov	x2, x20
    1d44:      	sub	x1, x19, #0x40
    1d48:      	mov	x0, x25
    1d4c:      	bl	0x1320 <__isoc99_scanf@plt>
    1d50:      	cmp	w0, #0x2
    1d54:      	b.ne	0x1d9c <main+0x3f0>
    1d58:      	sub	x0, x19, #0x40
    1d5c:      	lsr	x2, x0, #3
    1d60:      	mov	x1, #0x1000000000       // =68719476736
    1d64:      	ldrsb	w1, [x2, x1]
    1d68:      	cmp	w1, #0x0
    1d6c:      	mov	w2, #0x3                // =3
    1d70:      	ccmp	w2, w1, #0x1, ne
    1d74:      	b.ge	0x1d24 <main+0x378>
    1d78:      	ldur	w0, [x19, #-0x40]
    1d7c:      	lsr	x1, x20, #3
    1d80:      	mov	x2, #0x1000000000       // =68719476736
    1d84:      	ldrsb	w1, [x1, x2]
    1d88:      	cmp	w1, #0x0
    1d8c:      	ccmp	w22, w1, #0x1, ne
    1d90:      	b.lt	0x1d28 <main+0x37c>
    1d94:      	mov	x0, x20
    1d98:      	bl	0x1260 <__asan_report_load4@plt>
    1d9c:      	mov	w20, #0x0               // =0
    1da0:      	ldp	x25, x26, [sp, #0x110]
    1da4:      	b	0x1eb0 <main+0x504>
    1da8:      	mov	x1, x20
    1dac:      	adrp	x0, 0x20000 <data_start>
    1db0:      	add	x0, x0, #0xe0
    1db4:      	bl	0x1350 <__ubsan_handle_pointer_overflow_abort@plt>
    1db8:      	adrp	x0, 0x20000 <data_start>
    1dbc:      	add	x0, x0, #0xe0
    1dc0:      	add	x0, x0, #0x40
    1dc4:      	bl	0x1210 <__ubsan_handle_type_mismatch_v1_abort@plt>
    1dc8:      	bl	0x12e0 <__asan_report_load8@plt>
    1dcc:      	bl	0x12a0 <__asan_handle_no_return@plt>
    1dd0:      	adrp	x0, 0x20000 <data_start>
    1dd4:      	add	x0, x0, #0xe0
    1dd8:      	add	x0, x0, #0x80
    1ddc:      	bl	0x1240 <__ubsan_handle_nonnull_arg_abort@plt>
    1de0:      	mov	x1, x20
    1de4:      	adrp	x0, 0x20000 <data_start>
    1de8:      	add	x0, x0, #0xe0
    1dec:      	add	x0, x0, #0xe0
    1df0:      	bl	0x1350 <__ubsan_handle_pointer_overflow_abort@plt>
    1df4:      	adrp	x0, 0x20000 <data_start>
    1df8:      	add	x0, x0, #0xe0
    1dfc:      	add	x0, x0, #0x120
    1e00:      	bl	0x1210 <__ubsan_handle_type_mismatch_v1_abort@plt>
    1e04:      	bl	0x12e0 <__asan_report_load8@plt>
    1e08:      	bl	0x12a0 <__asan_handle_no_return@plt>
    1e0c:      	adrp	x0, 0x20000 <data_start>
    1e10:      	add	x0, x0, #0xe0
    1e14:      	add	x0, x0, #0x160
    1e18:      	bl	0x1240 <__ubsan_handle_nonnull_arg_abort@plt>
    1e1c:      	mov	x0, x2
    1e20:      	bl	0x1200 <__asan_report_store4@plt>
    1e24:      	ldr	x0, [sp, #0x8]
    1e28:      	bl	0x1260 <__asan_report_load4@plt>
    1e2c:      	mov	x0, x20
    1e30:      	bl	0x1200 <__asan_report_store4@plt>
    1e34:      	sub	x3, x19, #0x3c
    1e38:      	cmn	x3, x2
    1e3c:      	b.hs	0x1bb8 <main+0x20c>
    1e40:      	mov	x1, x3
    1e44:      	adrp	x0, 0x20000 <data_start>
    1e48:      	add	x0, x0, #0xe0
    1e4c:      	add	x0, x0, #0x1c0
    1e50:      	bl	0x1210 <__ubsan_handle_type_mismatch_v1_abort@plt>
    1e54:      	mov	x0, x3
    1e58:      	bl	0x1200 <__asan_report_store4@plt>
    1e5c:      	mov	x0, x20
    1e60:      	bl	0x1260 <__asan_report_load4@plt>
    1e64:      	mov	x0, x3
    1e68:      	bl	0x1260 <__asan_report_load4@plt>
    1e6c:      	mov	x22, x25
    1e70:      	b	0x1c34 <main+0x288>
    1e74:      	bl	0x12e0 <__asan_report_load8@plt>
    1e78:      	bl	0x12e0 <__asan_report_load8@plt>
    1e7c:      	ldur	x2, [x19, #-0x80]
    1e80:      	adrp	x0, 0x20000 <data_start>
    1e84:      	add	x0, x0, #0xe0
    1e88:      	add	x0, x0, #0x200
    1e8c:      	bl	0x1250 <__ubsan_handle_sub_overflow_abort@plt>
    1e90:      	bl	0x12e0 <__asan_report_load8@plt>
    1e94:      	bl	0x12e0 <__asan_report_load8@plt>
    1e98:      	ldur	x2, [x19, #-0x78]
    1e9c:      	adrp	x0, 0x20000 <data_start>
    1ea0:      	add	x0, x0, #0xe0
    1ea4:      	add	x0, x0, #0x240
    1ea8:      	bl	0x1250 <__ubsan_handle_sub_overflow_abort@plt>
    1eac:      	mov	w20, #0x3               // =3
    1eb0:      	cmp	x28, x23
    1eb4:      	b.ne	0x1f1c <main+0x570>
    1eb8:      	mov	x0, #0x1000000000       // =68719476736
    1ebc:      	add	x24, x24, x0
    1ec0:      	stp	xzr, xzr, [x24]
    1ec4:      	str	wzr, [x24, #0x10]
    1ec8:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1cbbc>
    1ecc:      	ldr	x0, [x0, #0xfc8]
    1ed0:      	ldr	x2, [sp, #0xc8]
    1ed4:      	ldr	x1, [x0]
    1ed8:      	subs	x2, x2, x1
    1edc:      	mov	x1, #0x0                // =0
    1ee0:      	b.ne	0x1f40 <main+0x594>
    1ee4:      	mov	w0, w20
    1ee8:      	ldp	x19, x20, [sp, #0xe0]
    1eec:      	ldp	x21, x22, [sp, #0xf0]
    1ef0:      	ldp	x23, x24, [sp, #0x100]
    1ef4:      	ldp	x27, x28, [sp, #0x120]
    1ef8:      	ldp	x29, x30, [sp, #0xd0]
    1efc:      	add	sp, sp, #0x130
    1f00:      	ret
    1f04:      	mov	w20, #0x2               // =2
    1f08:      	ldp	x25, x26, [sp, #0x110]
    1f0c:      	b	0x1eb0 <main+0x504>
    1f10:      	mov	w20, #0x2               // =2
    1f14:      	ldp	x25, x26, [sp, #0x110]
    1f18:      	b	0x1eb0 <main+0x504>
    1f1c:      	mov	x0, #0x360e             // =13838
    1f20:      	movk	x0, #0x45e0, lsl #16
    1f24:      	str	x0, [x23]
    1f28:      	mov	x0, #0x1000000000       // =68719476736
    1f2c:      	add	x1, x24, x0
    1f30:      	movi	v0.16b, #0xf5
    1f34:      	str	q0, [x24, x0]
    1f38:      	str	s0, [x1, #0x10]
    1f3c:      	b	0x1ec8 <main+0x51c>
    1f40:      	stp	x25, x26, [sp, #0x110]
    1f44:      	bl	0x1230 <__stack_chk_fail@plt>

0000000000001f48 <_sub_D_00099_0>:
    1f48:      	stp	x29, x30, [sp, #-0x10]!
    1f4c:      	mov	x29, sp
    1f50:      	mov	x1, #0x10               // =16
    1f54:      	adrp	x0, 0x20000 <data_start>
    1f58:      	add	x0, x0, #0xe0
    1f5c:      	add	x0, x0, #0x280
    1f60:      	bl	0x1290 <__asan_unregister_globals@plt>
    1f64:      	ldp	x29, x30, [sp], #0x10
    1f68:      	ret

0000000000001f6c <_sub_I_00099_1>:
    1f6c:      	stp	x29, x30, [sp, #-0x10]!
    1f70:      	mov	x29, sp
    1f74:      	bl	0x12b0 <__asan_init@plt>
    1f78:      	bl	0x1310 <__asan_version_mismatch_check_v8@plt>
    1f7c:      	mov	x1, #0x10               // =16
    1f80:      	adrp	x0, 0x20000 <data_start>
    1f84:      	add	x0, x0, #0xe0
    1f88:      	add	x0, x0, #0x280
    1f8c:      	bl	0x1220 <__asan_register_globals@plt>
    1f90:      	ldp	x29, x30, [sp], #0x10
    1f94:      	ret

Disassembly of section .fini:

0000000000001f98 <_fini>:
    1f98:      	nop
    1f9c:      	stp	x29, x30, [sp, #-0x10]!
    1fa0:      	mov	x29, sp
    1fa4:      	ldp	x29, x30, [sp], #0x10
    1fa8:      	ret
