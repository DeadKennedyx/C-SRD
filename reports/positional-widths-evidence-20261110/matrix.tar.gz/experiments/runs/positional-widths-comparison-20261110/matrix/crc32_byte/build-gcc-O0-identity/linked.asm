
/work/experiments/runs/positional-widths-comparison-20261110/matrix/crc32_byte/build-gcc-O0-identity/program:	file format elf64-littleaarch64

Disassembly of section .init:

0000000000000730 <_init>:
     730:      	nop
     734:      	stp	x29, x30, [sp, #-0x10]!
     738:      	mov	x29, sp
     73c:      	bl	0x834 <call_weak_fn>
     740:      	ldp	x29, x30, [sp], #0x10
     744:      	ret

Disassembly of section .plt:

0000000000000750 <.plt>:
     750:      	stp	x16, x30, [sp, #-0x10]!
     754:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e050>
     758:      	ldr	x17, [x16, #0xf78]
     75c:      	add	x16, x16, #0xf78
     760:      	br	x17
     764:      	nop
     768:      	nop
     76c:      	nop

0000000000000770 <strtoul@plt>:
     770:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e050>
     774:      	ldr	x17, [x16, #0xf80]
     778:      	add	x16, x16, #0xf80
     77c:      	br	x17

0000000000000780 <__libc_start_main@plt>:
     780:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e050>
     784:      	ldr	x17, [x16, #0xf88]
     788:      	add	x16, x16, #0xf88
     78c:      	br	x17

0000000000000790 <__cxa_finalize@plt>:
     790:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e050>
     794:      	ldr	x17, [x16, #0xf90]
     798:      	add	x16, x16, #0xf90
     79c:      	br	x17

00000000000007a0 <clock_gettime@plt>:
     7a0:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e050>
     7a4:      	ldr	x17, [x16, #0xf98]
     7a8:      	add	x16, x16, #0xf98
     7ac:      	br	x17

00000000000007b0 <__stack_chk_fail@plt>:
     7b0:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e050>
     7b4:      	ldr	x17, [x16, #0xfa0]
     7b8:      	add	x16, x16, #0xfa0
     7bc:      	br	x17

00000000000007c0 <__gmon_start__@plt>:
     7c0:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e050>
     7c4:      	ldr	x17, [x16, #0xfa8]
     7c8:      	add	x16, x16, #0xfa8
     7cc:      	br	x17

00000000000007d0 <abort@plt>:
     7d0:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e050>
     7d4:      	ldr	x17, [x16, #0xfb0]
     7d8:      	add	x16, x16, #0xfb0
     7dc:      	br	x17

00000000000007e0 <__isoc99_scanf@plt>:
     7e0:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e050>
     7e4:      	ldr	x17, [x16, #0xfb8]
     7e8:      	add	x16, x16, #0xfb8
     7ec:      	br	x17

00000000000007f0 <printf@plt>:
     7f0:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e050>
     7f4:      	ldr	x17, [x16, #0xfc0]
     7f8:      	add	x16, x16, #0xfc0
     7fc:      	br	x17

Disassembly of section .text:

0000000000000800 <_start>:
     800:      	nop
     804:      	mov	x29, #0x0               // =0
     808:      	mov	x30, #0x0               // =0
     80c:      	mov	x5, x0
     810:      	ldr	x1, [sp]
     814:      	add	x2, sp, #0x8
     818:      	mov	x6, sp
     81c:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e050>
     820:      	ldr	x0, [x0, #0xff0]
     824:      	mov	x3, #0x0                // =0
     828:      	mov	x4, #0x0                // =0
     82c:      	bl	0x780 <__libc_start_main@plt>
     830:      	bl	0x7d0 <abort@plt>

0000000000000834 <call_weak_fn>:
     834:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e050>
     838:      	ldr	x0, [x0, #0xfe0]
     83c:      	cbz	x0, 0x844 <call_weak_fn+0x10>
     840:      	b	0x7c0 <__gmon_start__@plt>
     844:      	ret
     848:      	nop
     84c:      	nop

0000000000000850 <deregister_tm_clones>:
     850:      	adrp	x0, 0x20000 <data_start>
     854:      	add	x0, x0, #0x10
     858:      	adrp	x1, 0x20000 <data_start>
     85c:      	add	x1, x1, #0x10
     860:      	cmp	x1, x0
     864:      	b.eq	0x87c <deregister_tm_clones+0x2c>
     868:      	adrp	x1, 0x1f000 <__FRAME_END__+0x1e050>
     86c:      	ldr	x1, [x1, #0xfd0]
     870:      	cbz	x1, 0x87c <deregister_tm_clones+0x2c>
     874:      	mov	x16, x1
     878:      	br	x16
     87c:      	ret

0000000000000880 <register_tm_clones>:
     880:      	adrp	x0, 0x20000 <data_start>
     884:      	add	x0, x0, #0x10
     888:      	adrp	x1, 0x20000 <data_start>
     88c:      	add	x1, x1, #0x10
     890:      	sub	x1, x1, x0
     894:      	lsr	x2, x1, #63
     898:      	add	x1, x2, x1, asr #3
     89c:      	asr	x1, x1, #1
     8a0:      	cbz	x1, 0x8b8 <register_tm_clones+0x38>
     8a4:      	adrp	x2, 0x1f000 <__FRAME_END__+0x1e050>
     8a8:      	ldr	x2, [x2, #0xff8]
     8ac:      	cbz	x2, 0x8b8 <register_tm_clones+0x38>
     8b0:      	mov	x16, x2
     8b4:      	br	x16
     8b8:      	ret
     8bc:      	nop

00000000000008c0 <__do_global_dtors_aux>:
     8c0:      	paciasp
     8c4:      	stp	x29, x30, [sp, #-0x20]!
     8c8:      	mov	x29, sp
     8cc:      	str	x19, [sp, #0x10]
     8d0:      	adrp	x19, 0x20000 <data_start>
     8d4:      	ldrb	w0, [x19, #0x10]
     8d8:      	tbnz	w0, #0x0, 0x900 <__do_global_dtors_aux+0x40>
     8dc:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e050>
     8e0:      	ldr	x0, [x0, #0xfd8]
     8e4:      	cbz	x0, 0x8f4 <__do_global_dtors_aux+0x34>
     8e8:      	adrp	x0, 0x20000 <data_start>
     8ec:      	ldr	x0, [x0, #0x8]
     8f0:      	bl	0x790 <__cxa_finalize@plt>
     8f4:      	bl	0x850 <deregister_tm_clones>
     8f8:      	mov	w0, #0x1                // =1
     8fc:      	strb	w0, [x19, #0x10]
     900:      	ldr	x19, [sp, #0x10]
     904:      	ldp	x29, x30, [sp], #0x20
     908:      	autiasp
     90c:      	ret

0000000000000910 <frame_dummy>:
     910:      	bti	c
     914:      	b	0x880 <register_tm_clones>

0000000000000918 <kernel>:
     918:      	sub	sp, sp, #0xc0
     91c:      	str	w0, [sp, #0xc]
     920:      	str	w1, [sp, #0x8]
     924:      	ldr	w0, [sp, #0xc]
     928:      	mvn	w0, w0
     92c:      	str	w0, [sp, #0x10]
     930:      	ldr	w0, [sp, #0x8]
     934:      	and	w0, w0, #0xff
     938:      	str	w0, [sp, #0x14]
     93c:      	ldr	w1, [sp, #0x10]
     940:      	ldr	w0, [sp, #0x14]
     944:      	eor	w0, w1, w0
     948:      	str	w0, [sp, #0x18]
     94c:      	ldr	w0, [sp, #0x18]
     950:      	and	w0, w0, #0x1
     954:      	str	w0, [sp, #0x1c]
     958:      	ldr	w0, [sp, #0x1c]
     95c:      	neg	w0, w0
     960:      	str	w0, [sp, #0x20]
     964:      	ldr	w0, [sp, #0x18]
     968:      	lsr	w0, w0, #1
     96c:      	str	w0, [sp, #0x24]
     970:      	ldr	w1, [sp, #0x20]
     974:      	mov	w0, #0x8320             // =33568
     978:      	movk	w0, #0xedb8, lsl #16
     97c:      	and	w0, w1, w0
     980:      	str	w0, [sp, #0x28]
     984:      	ldr	w1, [sp, #0x24]
     988:      	ldr	w0, [sp, #0x28]
     98c:      	eor	w0, w1, w0
     990:      	str	w0, [sp, #0x2c]
     994:      	ldr	w0, [sp, #0x2c]
     998:      	and	w0, w0, #0x1
     99c:      	str	w0, [sp, #0x30]
     9a0:      	ldr	w0, [sp, #0x30]
     9a4:      	neg	w0, w0
     9a8:      	str	w0, [sp, #0x34]
     9ac:      	ldr	w0, [sp, #0x2c]
     9b0:      	lsr	w0, w0, #1
     9b4:      	str	w0, [sp, #0x38]
     9b8:      	ldr	w1, [sp, #0x34]
     9bc:      	mov	w0, #0x8320             // =33568
     9c0:      	movk	w0, #0xedb8, lsl #16
     9c4:      	and	w0, w1, w0
     9c8:      	str	w0, [sp, #0x3c]
     9cc:      	ldr	w1, [sp, #0x38]
     9d0:      	ldr	w0, [sp, #0x3c]
     9d4:      	eor	w0, w1, w0
     9d8:      	str	w0, [sp, #0x40]
     9dc:      	ldr	w0, [sp, #0x40]
     9e0:      	and	w0, w0, #0x1
     9e4:      	str	w0, [sp, #0x44]
     9e8:      	ldr	w0, [sp, #0x44]
     9ec:      	neg	w0, w0
     9f0:      	str	w0, [sp, #0x48]
     9f4:      	ldr	w0, [sp, #0x40]
     9f8:      	lsr	w0, w0, #1
     9fc:      	str	w0, [sp, #0x4c]
     a00:      	ldr	w1, [sp, #0x48]
     a04:      	mov	w0, #0x8320             // =33568
     a08:      	movk	w0, #0xedb8, lsl #16
     a0c:      	and	w0, w1, w0
     a10:      	str	w0, [sp, #0x50]
     a14:      	ldr	w1, [sp, #0x4c]
     a18:      	ldr	w0, [sp, #0x50]
     a1c:      	eor	w0, w1, w0
     a20:      	str	w0, [sp, #0x54]
     a24:      	ldr	w0, [sp, #0x54]
     a28:      	and	w0, w0, #0x1
     a2c:      	str	w0, [sp, #0x58]
     a30:      	ldr	w0, [sp, #0x58]
     a34:      	neg	w0, w0
     a38:      	str	w0, [sp, #0x5c]
     a3c:      	ldr	w0, [sp, #0x54]
     a40:      	lsr	w0, w0, #1
     a44:      	str	w0, [sp, #0x60]
     a48:      	ldr	w1, [sp, #0x5c]
     a4c:      	mov	w0, #0x8320             // =33568
     a50:      	movk	w0, #0xedb8, lsl #16
     a54:      	and	w0, w1, w0
     a58:      	str	w0, [sp, #0x64]
     a5c:      	ldr	w1, [sp, #0x60]
     a60:      	ldr	w0, [sp, #0x64]
     a64:      	eor	w0, w1, w0
     a68:      	str	w0, [sp, #0x68]
     a6c:      	ldr	w0, [sp, #0x68]
     a70:      	and	w0, w0, #0x1
     a74:      	str	w0, [sp, #0x6c]
     a78:      	ldr	w0, [sp, #0x6c]
     a7c:      	neg	w0, w0
     a80:      	str	w0, [sp, #0x70]
     a84:      	ldr	w0, [sp, #0x68]
     a88:      	lsr	w0, w0, #1
     a8c:      	str	w0, [sp, #0x74]
     a90:      	ldr	w1, [sp, #0x70]
     a94:      	mov	w0, #0x8320             // =33568
     a98:      	movk	w0, #0xedb8, lsl #16
     a9c:      	and	w0, w1, w0
     aa0:      	str	w0, [sp, #0x78]
     aa4:      	ldr	w1, [sp, #0x74]
     aa8:      	ldr	w0, [sp, #0x78]
     aac:      	eor	w0, w1, w0
     ab0:      	str	w0, [sp, #0x7c]
     ab4:      	ldr	w0, [sp, #0x7c]
     ab8:      	and	w0, w0, #0x1
     abc:      	str	w0, [sp, #0x80]
     ac0:      	ldr	w0, [sp, #0x80]
     ac4:      	neg	w0, w0
     ac8:      	str	w0, [sp, #0x84]
     acc:      	ldr	w0, [sp, #0x7c]
     ad0:      	lsr	w0, w0, #1
     ad4:      	str	w0, [sp, #0x88]
     ad8:      	ldr	w1, [sp, #0x84]
     adc:      	mov	w0, #0x8320             // =33568
     ae0:      	movk	w0, #0xedb8, lsl #16
     ae4:      	and	w0, w1, w0
     ae8:      	str	w0, [sp, #0x8c]
     aec:      	ldr	w1, [sp, #0x88]
     af0:      	ldr	w0, [sp, #0x8c]
     af4:      	eor	w0, w1, w0
     af8:      	str	w0, [sp, #0x90]
     afc:      	ldr	w0, [sp, #0x90]
     b00:      	and	w0, w0, #0x1
     b04:      	str	w0, [sp, #0x94]
     b08:      	ldr	w0, [sp, #0x94]
     b0c:      	neg	w0, w0
     b10:      	str	w0, [sp, #0x98]
     b14:      	ldr	w0, [sp, #0x90]
     b18:      	lsr	w0, w0, #1
     b1c:      	str	w0, [sp, #0x9c]
     b20:      	ldr	w1, [sp, #0x98]
     b24:      	mov	w0, #0x8320             // =33568
     b28:      	movk	w0, #0xedb8, lsl #16
     b2c:      	and	w0, w1, w0
     b30:      	str	w0, [sp, #0xa0]
     b34:      	ldr	w1, [sp, #0x9c]
     b38:      	ldr	w0, [sp, #0xa0]
     b3c:      	eor	w0, w1, w0
     b40:      	str	w0, [sp, #0xa4]
     b44:      	ldr	w0, [sp, #0xa4]
     b48:      	and	w0, w0, #0x1
     b4c:      	str	w0, [sp, #0xa8]
     b50:      	ldr	w0, [sp, #0xa8]
     b54:      	neg	w0, w0
     b58:      	str	w0, [sp, #0xac]
     b5c:      	ldr	w0, [sp, #0xa4]
     b60:      	lsr	w0, w0, #1
     b64:      	str	w0, [sp, #0xb0]
     b68:      	ldr	w1, [sp, #0xac]
     b6c:      	mov	w0, #0x8320             // =33568
     b70:      	movk	w0, #0xedb8, lsl #16
     b74:      	and	w0, w1, w0
     b78:      	str	w0, [sp, #0xb4]
     b7c:      	ldr	w1, [sp, #0xb0]
     b80:      	ldr	w0, [sp, #0xb4]
     b84:      	eor	w0, w1, w0
     b88:      	str	w0, [sp, #0xb8]
     b8c:      	ldr	w0, [sp, #0xb8]
     b90:      	mvn	w0, w0
     b94:      	str	w0, [sp, #0xbc]
     b98:      	ldr	w0, [sp, #0xbc]
     b9c:      	add	sp, sp, #0xc0
     ba0:      	ret

0000000000000ba4 <csrd_matrix_next_value>:
     ba4:      	sub	sp, sp, #0x10
     ba8:      	str	x0, [sp, #0x8]
     bac:      	ldr	x0, [sp, #0x8]
     bb0:      	ldr	w1, [x0]
     bb4:      	ldr	x0, [sp, #0x8]
     bb8:      	ldr	w0, [x0]
     bbc:      	lsl	w0, w0, #13
     bc0:      	eor	w1, w1, w0
     bc4:      	ldr	x0, [sp, #0x8]
     bc8:      	str	w1, [x0]
     bcc:      	ldr	x0, [sp, #0x8]
     bd0:      	ldr	w1, [x0]
     bd4:      	ldr	x0, [sp, #0x8]
     bd8:      	ldr	w0, [x0]
     bdc:      	lsr	w0, w0, #17
     be0:      	eor	w1, w1, w0
     be4:      	ldr	x0, [sp, #0x8]
     be8:      	str	w1, [x0]
     bec:      	ldr	x0, [sp, #0x8]
     bf0:      	ldr	w1, [x0]
     bf4:      	ldr	x0, [sp, #0x8]
     bf8:      	ldr	w0, [x0]
     bfc:      	lsl	w0, w0, #5
     c00:      	eor	w1, w1, w0
     c04:      	ldr	x0, [sp, #0x8]
     c08:      	str	w1, [x0]
     c0c:      	ldr	x0, [sp, #0x8]
     c10:      	ldr	w0, [x0]
     c14:      	add	sp, sp, #0x10
     c18:      	ret

0000000000000c1c <main>:
     c1c:      	sub	sp, sp, #0x80
     c20:      	stp	x29, x30, [sp, #0x70]
     c24:      	add	x29, sp, #0x70
     c28:      	str	w0, [sp, #0xc]
     c2c:      	str	x1, [sp]
     c30:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e050>
     c34:      	ldr	x0, [x0, #0xfe8]
     c38:      	ldr	x1, [x0]
     c3c:      	str	x1, [sp, #0x68]
     c40:      	mov	x1, #0x0                // =0
     c44:      	ldr	w0, [sp, #0xc]
     c48:      	cmp	w0, #0x1
     c4c:      	b.ne	0xca0 <main+0x84>
     c50:      	b	0xc70 <main+0x54>
     c54:      	ldr	w0, [sp, #0x60]
     c58:      	ldr	w1, [sp, #0x64]
     c5c:      	bl	0x918 <kernel>
     c60:      	mov	w1, w0
     c64:      	adrp	x0, 0x0 <strtoul@GLIBC_2.17>
     c68:      	add	x0, x0, #0xe50
     c6c:      	bl	0x7f0 <printf@plt>
     c70:      	add	x0, sp, #0x60
     c74:      	add	x1, x0, #0x4
     c78:      	add	x0, sp, #0x60
     c7c:      	mov	x2, x1
     c80:      	mov	x1, x0
     c84:      	adrp	x0, 0x0 <strtoul@GLIBC_2.17>
     c88:      	add	x0, x0, #0xe58
     c8c:      	bl	0x7e0 <__isoc99_scanf@plt>
     c90:      	cmp	w0, #0x2
     c94:      	b.eq	0xc54 <main+0x38>
     c98:      	mov	w0, #0x0                // =0
     c9c:      	b	0xe00 <main+0x1e4>
     ca0:      	ldr	w0, [sp, #0xc]
     ca4:      	cmp	w0, #0x3
     ca8:      	b.eq	0xcb4 <main+0x98>
     cac:      	mov	w0, #0x3                // =3
     cb0:      	b	0xe00 <main+0x1e4>
     cb4:      	ldr	x0, [sp]
     cb8:      	add	x0, x0, #0x8
     cbc:      	ldr	x0, [x0]
     cc0:      	mov	w2, #0xa                // =10
     cc4:      	mov	x1, #0x0                // =0
     cc8:      	bl	0x770 <strtoul@plt>
     ccc:      	str	x0, [sp, #0x30]
     cd0:      	ldr	x0, [sp]
     cd4:      	add	x0, x0, #0x10
     cd8:      	ldr	x0, [x0]
     cdc:      	mov	w2, #0xa                // =10
     ce0:      	mov	x1, #0x0                // =0
     ce4:      	bl	0x770 <strtoul@plt>
     ce8:      	str	w0, [sp, #0x18]
     cec:      	str	xzr, [sp, #0x20]
     cf0:      	add	x0, sp, #0x40
     cf4:      	mov	x1, x0
     cf8:      	mov	w0, #0x1                // =1
     cfc:      	bl	0x7a0 <clock_gettime@plt>
     d00:      	cmp	w0, #0x0
     d04:      	b.eq	0xd10 <main+0xf4>
     d08:      	mov	w0, #0x2                // =2
     d0c:      	b	0xe00 <main+0x1e4>
     d10:      	str	xzr, [sp, #0x28]
     d14:      	b	0xd7c <main+0x160>
     d18:      	str	wzr, [sp, #0x1c]
     d1c:      	b	0xd48 <main+0x12c>
     d20:      	add	x0, sp, #0x18
     d24:      	bl	0xba4 <csrd_matrix_next_value>
     d28:      	mov	w2, w0
     d2c:      	ldr	w0, [sp, #0x1c]
     d30:      	lsl	x0, x0, #2
     d34:      	add	x1, sp, #0x60
     d38:      	str	w2, [x1, x0]
     d3c:      	ldr	w0, [sp, #0x1c]
     d40:      	add	w0, w0, #0x1
     d44:      	str	w0, [sp, #0x1c]
     d48:      	ldr	w0, [sp, #0x1c]
     d4c:      	cmp	w0, #0x1
     d50:      	b.ls	0xd20 <main+0x104>
     d54:      	ldr	w0, [sp, #0x60]
     d58:      	ldr	w1, [sp, #0x64]
     d5c:      	bl	0x918 <kernel>
     d60:      	mov	w0, w0
     d64:      	ldr	x1, [sp, #0x20]
     d68:      	add	x0, x1, x0
     d6c:      	str	x0, [sp, #0x20]
     d70:      	ldr	x0, [sp, #0x28]
     d74:      	add	x0, x0, #0x1
     d78:      	str	x0, [sp, #0x28]
     d7c:      	ldr	x1, [sp, #0x28]
     d80:      	ldr	x0, [sp, #0x30]
     d84:      	cmp	x1, x0
     d88:      	b.lo	0xd18 <main+0xfc>
     d8c:      	add	x0, sp, #0x50
     d90:      	mov	x1, x0
     d94:      	mov	w0, #0x1                // =1
     d98:      	bl	0x7a0 <clock_gettime@plt>
     d9c:      	cmp	w0, #0x0
     da0:      	b.eq	0xdac <main+0x190>
     da4:      	mov	w0, #0x2                // =2
     da8:      	b	0xe00 <main+0x1e4>
     dac:      	ldr	x1, [sp, #0x50]
     db0:      	ldr	x0, [sp, #0x40]
     db4:      	sub	x0, x1, x0
     db8:      	fmov	d0, x0
     dbc:      	scvtf	d1, d0
     dc0:      	ldr	x1, [sp, #0x58]
     dc4:      	ldr	x0, [sp, #0x48]
     dc8:      	sub	x0, x1, x0
     dcc:      	fmov	d0, x0
     dd0:      	scvtf	d0, d0
     dd4:      	adrp	x0, 0x0 <strtoul@GLIBC_2.17>
     dd8:      	ldr	d2, [x0, #0xe70]
     ddc:      	fmul	d0, d0, d2
     de0:      	fadd	d0, d1, d0
     de4:      	str	d0, [sp, #0x38]
     de8:      	ldr	x1, [sp, #0x20]
     dec:      	ldr	d0, [sp, #0x38]
     df0:      	adrp	x0, 0x0 <strtoul@GLIBC_2.17>
     df4:      	add	x0, x0, #0xe60
     df8:      	bl	0x7f0 <printf@plt>
     dfc:      	mov	w0, #0x0                // =0
     e00:      	mov	w1, w0
     e04:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e050>
     e08:      	ldr	x0, [x0, #0xfe8]
     e0c:      	ldr	x3, [sp, #0x68]
     e10:      	ldr	x2, [x0]
     e14:      	subs	x3, x3, x2
     e18:      	mov	x2, #0x0                // =0
     e1c:      	b.eq	0xe24 <main+0x208>
     e20:      	bl	0x7b0 <__stack_chk_fail@plt>
     e24:      	mov	w0, w1
     e28:      	ldp	x29, x30, [sp, #0x70]
     e2c:      	add	sp, sp, #0x80
     e30:      	ret

Disassembly of section .fini:

0000000000000e34 <_fini>:
     e34:      	nop
     e38:      	stp	x29, x30, [sp, #-0x10]!
     e3c:      	mov	x29, sp
     e40:      	ldp	x29, x30, [sp], #0x10
     e44:      	ret
