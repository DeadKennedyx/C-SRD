
/work/experiments/runs/positional-widths-comparison-20261110/matrix/crc32_byte/build-clang-O2-lto-original/program:	file format elf64-littleaarch64

Disassembly of section .init:

0000000000000678 <_init>:
     678:      	nop
     67c:      	stp	x29, x30, [sp, #-0x10]!
     680:      	mov	x29, sp
     684:      	bl	0x774 <call_weak_fn>
     688:      	ldp	x29, x30, [sp], #0x10
     68c:      	ret

Disassembly of section .plt:

0000000000000690 <.plt>:
     690:      	stp	x16, x30, [sp, #-0x10]!
     694:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e3c8>
     698:      	ldr	x17, [x16, #0xff8]
     69c:      	add	x16, x16, #0xff8
     6a0:      	br	x17
     6a4:      	nop
     6a8:      	nop
     6ac:      	nop

00000000000006b0 <strtoul@plt>:
     6b0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6b4:      	ldr	x17, [x16]
     6b8:      	add	x16, x16, #0x0
     6bc:      	br	x17

00000000000006c0 <__libc_start_main@plt>:
     6c0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6c4:      	ldr	x17, [x16, #0x8]
     6c8:      	add	x16, x16, #0x8
     6cc:      	br	x17

00000000000006d0 <__cxa_finalize@plt>:
     6d0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6d4:      	ldr	x17, [x16, #0x10]
     6d8:      	add	x16, x16, #0x10
     6dc:      	br	x17

00000000000006e0 <clock_gettime@plt>:
     6e0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6e4:      	ldr	x17, [x16, #0x18]
     6e8:      	add	x16, x16, #0x18
     6ec:      	br	x17

00000000000006f0 <__gmon_start__@plt>:
     6f0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6f4:      	ldr	x17, [x16, #0x20]
     6f8:      	add	x16, x16, #0x20
     6fc:      	br	x17

0000000000000700 <abort@plt>:
     700:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     704:      	ldr	x17, [x16, #0x28]
     708:      	add	x16, x16, #0x28
     70c:      	br	x17

0000000000000710 <__isoc99_scanf@plt>:
     710:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     714:      	ldr	x17, [x16, #0x30]
     718:      	add	x16, x16, #0x30
     71c:      	br	x17

0000000000000720 <printf@plt>:
     720:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     724:      	ldr	x17, [x16, #0x38]
     728:      	add	x16, x16, #0x38
     72c:      	br	x17

Disassembly of section .text:

0000000000000740 <_start>:
     740:      	nop
     744:      	mov	x29, #0x0               // =0
     748:      	mov	x30, #0x0               // =0
     74c:      	mov	x5, x0
     750:      	ldr	x1, [sp]
     754:      	add	x2, sp, #0x8
     758:      	mov	x6, sp
     75c:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e3c8>
     760:      	ldr	x0, [x0, #0xfd8]
     764:      	mov	x3, #0x0                // =0
     768:      	mov	x4, #0x0                // =0
     76c:      	bl	0x6c0 <__libc_start_main@plt>
     770:      	bl	0x700 <abort@plt>

0000000000000774 <call_weak_fn>:
     774:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e3c8>
     778:      	ldr	x0, [x0, #0xfd0]
     77c:      	cbz	x0, 0x784 <call_weak_fn+0x10>
     780:      	b	0x6f0 <__gmon_start__@plt>
     784:      	ret
     788:      	nop
     78c:      	nop

0000000000000790 <deregister_tm_clones>:
     790:      	adrp	x0, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     794:      	add	x0, x0, #0x50
     798:      	adrp	x1, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     79c:      	add	x1, x1, #0x50
     7a0:      	cmp	x1, x0
     7a4:      	b.eq	0x7bc <deregister_tm_clones+0x2c>
     7a8:      	adrp	x1, 0x1f000 <__FRAME_END__+0x1e3c8>
     7ac:      	ldr	x1, [x1, #0xfc0]
     7b0:      	cbz	x1, 0x7bc <deregister_tm_clones+0x2c>
     7b4:      	mov	x16, x1
     7b8:      	br	x16
     7bc:      	ret

00000000000007c0 <register_tm_clones>:
     7c0:      	adrp	x0, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     7c4:      	add	x0, x0, #0x50
     7c8:      	adrp	x1, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     7cc:      	add	x1, x1, #0x50
     7d0:      	sub	x1, x1, x0
     7d4:      	lsr	x2, x1, #63
     7d8:      	add	x1, x2, x1, asr #3
     7dc:      	asr	x1, x1, #1
     7e0:      	cbz	x1, 0x7f8 <register_tm_clones+0x38>
     7e4:      	adrp	x2, 0x1f000 <__FRAME_END__+0x1e3c8>
     7e8:      	ldr	x2, [x2, #0xfe0]
     7ec:      	cbz	x2, 0x7f8 <register_tm_clones+0x38>
     7f0:      	mov	x16, x2
     7f4:      	br	x16
     7f8:      	ret
     7fc:      	nop

0000000000000800 <__do_global_dtors_aux>:
     800:      	paciasp
     804:      	stp	x29, x30, [sp, #-0x20]!
     808:      	mov	x29, sp
     80c:      	str	x19, [sp, #0x10]
     810:      	adrp	x19, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     814:      	ldrb	w0, [x19, #0x50]
     818:      	tbnz	w0, #0x0, 0x840 <__do_global_dtors_aux+0x40>
     81c:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e3c8>
     820:      	ldr	x0, [x0, #0xfc8]
     824:      	cbz	x0, 0x834 <__do_global_dtors_aux+0x34>
     828:      	adrp	x0, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     82c:      	ldr	x0, [x0, #0x48]
     830:      	bl	0x6d0 <__cxa_finalize@plt>
     834:      	bl	0x790 <deregister_tm_clones>
     838:      	mov	w0, #0x1                // =1
     83c:      	strb	w0, [x19, #0x50]
     840:      	ldr	x19, [sp, #0x10]
     844:      	ldp	x29, x30, [sp], #0x20
     848:      	autiasp
     84c:      	ret

0000000000000850 <frame_dummy>:
     850:      	bti	c
     854:      	b	0x7c0 <register_tm_clones>

0000000000000858 <main>:
     858:      	sub	sp, sp, #0x80
     85c:      	stp	x29, x30, [sp, #0x40]
     860:      	stp	x24, x23, [sp, #0x50]
     864:      	stp	x22, x21, [sp, #0x60]
     868:      	stp	x20, x19, [sp, #0x70]
     86c:      	add	x29, sp, #0x40
     870:      	cmp	w0, #0x3
     874:      	b.eq	0x950 <main+0xf8>
     878:      	cmp	w0, #0x1
     87c:      	b.ne	0xa5c <main+0x204>
     880:      	adrp	x8, 0x0 <strtoul@GLIBC_2.17>
     884:      	adrp	x9, 0x0 <strtoul@GLIBC_2.17>
     888:      	mov	w21, #0x8320            // =33568
     88c:      	ldr	q0, [x8, #0xae0]
     890:      	mov	w22, #0x4190            // =16784
     894:      	mov	w23, #0x7cdf            // =31967
     898:      	movk	w21, #0xedb8, lsl #16
     89c:      	adrp	x19, 0x0 <strtoul@GLIBC_2.17>
     8a0:      	add	x19, x19, #0xb08
     8a4:      	str	q0, [sp, #0x10]
     8a8:      	ldr	q0, [x9, #0xaf0]
     8ac:      	movk	w22, #0x76dc, lsl #16
     8b0:      	movk	w23, #0x1247, lsl #16
     8b4:      	sub	x24, x29, #0x10
     8b8:      	adrp	x20, 0x0 <strtoul@GLIBC_2.17>
     8bc:      	add	x20, x20, #0xb0d
     8c0:      	str	q0, [sp]
     8c4:      	sub	x1, x29, #0x10
     8c8:      	add	x2, x24, #0x4
     8cc:      	mov	x0, x19
     8d0:      	bl	0x710 <__isoc99_scanf@plt>
     8d4:      	cmp	w0, #0x2
     8d8:      	b.ne	0xa98 <main+0x240>
     8dc:      	ldur	w8, [x29, #-0x10]
     8e0:      	ldurb	w9, [x29, #-0xc]
     8e4:      	mov	x0, x20
     8e8:      	ldp	q1, q2, [sp]
     8ec:      	eon	w8, w9, w8
     8f0:      	dup	v0.4s, w8
     8f4:      	sbfx	w9, w8, #0, #1
     8f8:      	lsl	w10, w8, #30
     8fc:      	and	w9, w9, w21
     900:      	and	v0.16b, v0.16b, v2.16b
     904:      	eor	w8, w9, w8, lsr #1
     908:      	and	w9, w21, w10, asr #31
     90c:      	eor	w9, w9, w8, lsr #1
     910:      	lsl	w8, w8, #26
     914:      	cmeq	v0.4s, v0.4s, #0
     918:      	tst	w9, #0x20
     91c:      	and	w8, w22, w8, asr #31
     920:      	csinv	w10, w23, wzr, ne
     924:      	bic	v0.16b, v1.16b, v0.16b
     928:      	eor	w9, w10, w9, lsr #6
     92c:      	ext	v1.16b, v0.16b, v0.16b, #0x8
     930:      	eor	v0.8b, v0.8b, v1.8b
     934:      	fmov	x11, d0
     938:      	lsr	x10, x11, #32
     93c:      	eor	w8, w11, w8
     940:      	eor	w8, w8, w9
     944:      	eor	w1, w8, w10
     948:      	bl	0x720 <printf@plt>
     94c:      	b	0x8c4 <main+0x6c>
     950:      	ldr	x0, [x1, #0x8]
     954:      	mov	x19, x1
     958:      	mov	x1, xzr
     95c:      	mov	w2, #0xa                // =10
     960:      	bl	0x6b0 <strtoul@plt>
     964:      	ldr	x8, [x19, #0x10]
     968:      	mov	x20, x0
     96c:      	mov	x1, xzr
     970:      	mov	w2, #0xa                // =10
     974:      	mov	x0, x8
     978:      	bl	0x6b0 <strtoul@plt>
     97c:      	mov	x21, x0
     980:      	sub	x1, x29, #0x10
     984:      	mov	w0, #0x1                // =1
     988:      	bl	0x6e0 <clock_gettime@plt>
     98c:      	cbnz	w0, 0xa54 <main+0x1fc>
     990:      	mov	x19, xzr
     994:      	cbz	x20, 0xa44 <main+0x1ec>
     998:      	adrp	x8, 0x0 <strtoul@GLIBC_2.17>
     99c:      	adrp	x9, 0x0 <strtoul@GLIBC_2.17>
     9a0:      	mov	w10, #0x7cdf            // =31967
     9a4:      	ldr	q0, [x8, #0xae0]
     9a8:      	ldr	q1, [x9, #0xaf0]
     9ac:      	mov	w8, #0x8320             // =33568
     9b0:      	mov	w9, #0x4190             // =16784
     9b4:      	movk	w8, #0xedb8, lsl #16
     9b8:      	movk	w10, #0x1247, lsl #16
     9bc:      	movk	w9, #0x76dc, lsl #16
     9c0:      	eor	w11, w21, w21, lsl #13
     9c4:      	eor	w11, w11, w11, lsr #17
     9c8:      	eor	w11, w11, w11, lsl #5
     9cc:      	eor	w12, w11, w11, lsl #13
     9d0:      	eor	w12, w12, w12, lsr #17
     9d4:      	eor	w21, w12, w12, lsl #5
     9d8:      	and	w12, w21, #0xff
     9dc:      	eon	w11, w12, w11
     9e0:      	dup	v2.4s, w11
     9e4:      	sbfx	w12, w11, #0, #1
     9e8:      	lsl	w13, w11, #30
     9ec:      	and	w12, w12, w8
     9f0:      	and	v2.16b, v2.16b, v0.16b
     9f4:      	eor	w11, w12, w11, lsr #1
     9f8:      	and	w12, w8, w13, asr #31
     9fc:      	eor	w12, w12, w11, lsr #1
     a00:      	lsl	w11, w11, #26
     a04:      	cmeq	v2.4s, v2.4s, #0
     a08:      	tst	w12, #0x20
     a0c:      	and	w11, w9, w11, asr #31
     a10:      	csinv	w13, w10, wzr, ne
     a14:      	subs	x20, x20, #0x1
     a18:      	bic	v2.16b, v1.16b, v2.16b
     a1c:      	eor	w12, w13, w12, lsr #6
     a20:      	ext	v3.16b, v2.16b, v2.16b, #0x8
     a24:      	eor	v2.8b, v2.8b, v3.8b
     a28:      	fmov	x14, d2
     a2c:      	lsr	x13, x14, #32
     a30:      	eor	w11, w14, w11
     a34:      	eor	w11, w11, w12
     a38:      	eor	w11, w11, w13
     a3c:      	add	x19, x19, x11
     a40:      	b.ne	0x9c0 <main+0x168>
     a44:      	add	x1, sp, #0x20
     a48:      	mov	w0, #0x1                // =1
     a4c:      	bl	0x6e0 <clock_gettime@plt>
     a50:      	cbz	w0, 0xa64 <main+0x20c>
     a54:      	mov	w0, #0x2                // =2
     a58:      	b	0xa9c <main+0x244>
     a5c:      	mov	w0, #0x3                // =3
     a60:      	b	0xa9c <main+0x244>
     a64:      	ldp	x8, x9, [sp, #0x20]
     a68:      	adrp	x0, 0x0 <strtoul@GLIBC_2.17>
     a6c:      	add	x0, x0, #0xb11
     a70:      	ldp	x10, x11, [x29, #-0x10]
     a74:      	mov	x1, x19
     a78:      	sub	x8, x8, x10
     a7c:      	sub	x9, x9, x11
     a80:      	scvtf	d0, x8
     a84:      	scvtf	d1, x9
     a88:      	adrp	x8, 0x0 <strtoul@GLIBC_2.17>
     a8c:      	ldr	d2, [x8, #0xb00]
     a90:      	fmadd	d0, d1, d2, d0
     a94:      	bl	0x720 <printf@plt>
     a98:      	mov	w0, wzr
     a9c:      	ldp	x20, x19, [sp, #0x70]
     aa0:      	ldp	x22, x21, [sp, #0x60]
     aa4:      	ldp	x24, x23, [sp, #0x50]
     aa8:      	ldp	x29, x30, [sp, #0x40]
     aac:      	add	sp, sp, #0x80
     ab0:      	ret

Disassembly of section .fini:

0000000000000ab4 <_fini>:
     ab4:      	nop
     ab8:      	stp	x29, x30, [sp, #-0x10]!
     abc:      	mov	x29, sp
     ac0:      	ldp	x29, x30, [sp], #0x10
     ac4:      	ret
