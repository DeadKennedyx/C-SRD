
/work/experiments/runs/positional-widths-comparison-20261110/matrix/crc32_byte/build-gcc-O1-identity/program:	file format elf64-littleaarch64

Disassembly of section .init:

0000000000000738 <_init>:
     738:      	nop
     73c:      	stp	x29, x30, [sp, #-0x10]!
     740:      	mov	x29, sp
     744:      	bl	0x834 <call_weak_fn>
     748:      	ldp	x29, x30, [sp], #0x10
     74c:      	ret

Disassembly of section .plt:

0000000000000750 <.plt>:
     750:      	stp	x16, x30, [sp, #-0x10]!
     754:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e314>
     758:      	ldr	x17, [x16, #0xf78]
     75c:      	add	x16, x16, #0xf78
     760:      	br	x17
     764:      	nop
     768:      	nop
     76c:      	nop

0000000000000770 <strtoul@plt>:
     770:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e314>
     774:      	ldr	x17, [x16, #0xf80]
     778:      	add	x16, x16, #0xf80
     77c:      	br	x17

0000000000000780 <__libc_start_main@plt>:
     780:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e314>
     784:      	ldr	x17, [x16, #0xf88]
     788:      	add	x16, x16, #0xf88
     78c:      	br	x17

0000000000000790 <__cxa_finalize@plt>:
     790:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e314>
     794:      	ldr	x17, [x16, #0xf90]
     798:      	add	x16, x16, #0xf90
     79c:      	br	x17

00000000000007a0 <clock_gettime@plt>:
     7a0:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e314>
     7a4:      	ldr	x17, [x16, #0xf98]
     7a8:      	add	x16, x16, #0xf98
     7ac:      	br	x17

00000000000007b0 <__printf_chk@plt>:
     7b0:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e314>
     7b4:      	ldr	x17, [x16, #0xfa0]
     7b8:      	add	x16, x16, #0xfa0
     7bc:      	br	x17

00000000000007c0 <__stack_chk_fail@plt>:
     7c0:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e314>
     7c4:      	ldr	x17, [x16, #0xfa8]
     7c8:      	add	x16, x16, #0xfa8
     7cc:      	br	x17

00000000000007d0 <__gmon_start__@plt>:
     7d0:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e314>
     7d4:      	ldr	x17, [x16, #0xfb0]
     7d8:      	add	x16, x16, #0xfb0
     7dc:      	br	x17

00000000000007e0 <abort@plt>:
     7e0:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e314>
     7e4:      	ldr	x17, [x16, #0xfb8]
     7e8:      	add	x16, x16, #0xfb8
     7ec:      	br	x17

00000000000007f0 <__isoc99_scanf@plt>:
     7f0:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e314>
     7f4:      	ldr	x17, [x16, #0xfc0]
     7f8:      	add	x16, x16, #0xfc0
     7fc:      	br	x17

Disassembly of section .text:

0000000000000800 <_start>:
     800:      	nop
     804:      	mov	x29, #0x0               // =0
     808:      	mov	x30, #0x0               // =0
     80c:      	mov	x5, x0
     810:      	ldr	x1, [sp]
     814:      	add	x2, sp, #0x8
     818:      	mov	x6, sp
     81c:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e314>
     820:      	ldr	x0, [x0, #0xff0]
     824:      	mov	x3, #0x0                // =0
     828:      	mov	x4, #0x0                // =0
     82c:      	bl	0x780 <__libc_start_main@plt>
     830:      	bl	0x7e0 <abort@plt>

0000000000000834 <call_weak_fn>:
     834:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e314>
     838:      	ldr	x0, [x0, #0xfe0]
     83c:      	cbz	x0, 0x844 <call_weak_fn+0x10>
     840:      	b	0x7d0 <__gmon_start__@plt>
     844:      	ret
     848:      	nop
     84c:      	nop

0000000000000850 <deregister_tm_clones>:
     850:      	adrp	x0, 0x20000 <data_start>
     854:      	add	x0, x0, #0x10
     858:      	adrp	x1, 0x20000 <data_start>
     85c:      	add	x1, x1, #0x10
     860:      	cmp	x1, x0
     864:      	b.eq	0x87c <deregister_tm_clones+0x2c>
     868:      	adrp	x1, 0x1f000 <__FRAME_END__+0x1e314>
     86c:      	ldr	x1, [x1, #0xfd0]
     870:      	cbz	x1, 0x87c <deregister_tm_clones+0x2c>
     874:      	mov	x16, x1
     878:      	br	x16
     87c:      	ret

0000000000000880 <register_tm_clones>:
     880:      	adrp	x0, 0x20000 <data_start>
     884:      	add	x0, x0, #0x10
     888:      	adrp	x1, 0x20000 <data_start>
     88c:      	add	x1, x1, #0x10
     890:      	sub	x1, x1, x0
     894:      	lsr	x2, x1, #63
     898:      	add	x1, x2, x1, asr #3
     89c:      	asr	x1, x1, #1
     8a0:      	cbz	x1, 0x8b8 <register_tm_clones+0x38>
     8a4:      	adrp	x2, 0x1f000 <__FRAME_END__+0x1e314>
     8a8:      	ldr	x2, [x2, #0xff8]
     8ac:      	cbz	x2, 0x8b8 <register_tm_clones+0x38>
     8b0:      	mov	x16, x2
     8b4:      	br	x16
     8b8:      	ret
     8bc:      	nop

00000000000008c0 <__do_global_dtors_aux>:
     8c0:      	paciasp
     8c4:      	stp	x29, x30, [sp, #-0x20]!
     8c8:      	mov	x29, sp
     8cc:      	str	x19, [sp, #0x10]
     8d0:      	adrp	x19, 0x20000 <data_start>
     8d4:      	ldrb	w0, [x19, #0x10]
     8d8:      	tbnz	w0, #0x0, 0x900 <__do_global_dtors_aux+0x40>
     8dc:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e314>
     8e0:      	ldr	x0, [x0, #0xfd8]
     8e4:      	cbz	x0, 0x8f4 <__do_global_dtors_aux+0x34>
     8e8:      	adrp	x0, 0x20000 <data_start>
     8ec:      	ldr	x0, [x0, #0x8]
     8f0:      	bl	0x790 <__cxa_finalize@plt>
     8f4:      	bl	0x850 <deregister_tm_clones>
     8f8:      	mov	w0, #0x1                // =1
     8fc:      	strb	w0, [x19, #0x10]
     900:      	ldr	x19, [sp, #0x10]
     904:      	ldp	x29, x30, [sp], #0x20
     908:      	autiasp
     90c:      	ret

0000000000000910 <frame_dummy>:
     910:      	bti	c
     914:      	b	0x880 <register_tm_clones>

0000000000000918 <kernel>:
     918:      	and	w1, w1, #0xff
     91c:      	eon	w0, w1, w0
     920:      	sbfx	x2, x0, #0, #1
     924:      	mov	w3, #0x8320             // =33568
     928:      	movk	w3, #0xedb8, lsl #16
     92c:      	and	w2, w2, w3
     930:      	eor	w2, w2, w0, lsr #1
     934:      	sbfx	x1, x0, #1, #1
     938:      	and	w1, w1, w3
     93c:      	eor	w1, w1, w2, lsr #1
     940:      	sbfx	x0, x2, #1, #1
     944:      	and	w0, w0, w3
     948:      	eor	w0, w0, w1, lsr #1
     94c:      	sbfx	x1, x1, #1, #1
     950:      	and	w1, w1, w3
     954:      	eor	w1, w1, w0, lsr #1
     958:      	sbfx	x0, x0, #1, #1
     95c:      	and	w0, w0, w3
     960:      	eor	w0, w0, w1, lsr #1
     964:      	sbfx	x1, x1, #1, #1
     968:      	and	w1, w1, w3
     96c:      	eor	w1, w1, w0, lsr #1
     970:      	sbfx	x0, x0, #1, #1
     974:      	and	w0, w0, w3
     978:      	eor	w0, w0, w1, lsr #1
     97c:      	sbfx	x1, x1, #1, #1
     980:      	and	w1, w1, w3
     984:      	eon	w0, w1, w0, lsr #1
     988:      	ret

000000000000098c <main>:
     98c:      	sub	sp, sp, #0x60
     990:      	stp	x29, x30, [sp, #0x30]
     994:      	add	x29, sp, #0x30
     998:      	stp	x19, x20, [sp, #0x40]
     99c:      	mov	x19, x1
     9a0:      	adrp	x1, 0x1f000 <__FRAME_END__+0x1e314>
     9a4:      	ldr	x1, [x1, #0xfe8]
     9a8:      	ldr	x2, [x1]
     9ac:      	str	x2, [sp, #0x28]
     9b0:      	mov	x2, #0x0                // =0
     9b4:      	cmp	w0, #0x1
     9b8:      	b.eq	0x9f8 <main+0x6c>
     9bc:      	mov	w20, #0x3               // =3
     9c0:      	cmp	w0, w20
     9c4:      	b.eq	0xa58 <main+0xcc>
     9c8:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e314>
     9cc:      	ldr	x0, [x0, #0xfe8]
     9d0:      	ldr	x2, [sp, #0x28]
     9d4:      	ldr	x1, [x0]
     9d8:      	subs	x2, x2, x1
     9dc:      	mov	x1, #0x0                // =0
     9e0:      	b.ne	0xb60 <main+0x1d4>
     9e4:      	mov	w0, w20
     9e8:      	ldp	x19, x20, [sp, #0x40]
     9ec:      	ldp	x29, x30, [sp, #0x30]
     9f0:      	add	sp, sp, #0x60
     9f4:      	ret
     9f8:      	stp	x21, x22, [sp, #0x50]
     9fc:      	add	x22, sp, #0x20
     a00:      	add	x21, sp, #0x24
     a04:      	adrp	x19, 0x0 <strtoul@GLIBC_2.17>
     a08:      	add	x19, x19, #0xb90
     a0c:      	adrp	x20, 0x0 <strtoul@GLIBC_2.17>
     a10:      	add	x20, x20, #0xb88
     a14:      	b	0xa34 <main+0xa8>
     a18:      	ldr	w1, [sp, #0x24]
     a1c:      	ldr	w0, [sp, #0x20]
     a20:      	bl	0x918 <kernel>
     a24:      	mov	w2, w0
     a28:      	mov	x1, x20
     a2c:      	mov	w0, #0x2                // =2
     a30:      	bl	0x7b0 <__printf_chk@plt>
     a34:      	mov	x2, x21
     a38:      	mov	x1, x22
     a3c:      	mov	x0, x19
     a40:      	bl	0x7f0 <__isoc99_scanf@plt>
     a44:      	cmp	w0, #0x2
     a48:      	b.eq	0xa18 <main+0x8c>
     a4c:      	mov	w20, #0x0               // =0
     a50:      	ldp	x21, x22, [sp, #0x50]
     a54:      	b	0x9c8 <main+0x3c>
     a58:      	stp	x21, x22, [sp, #0x50]
     a5c:      	mov	w2, #0xa                // =10
     a60:      	mov	x1, #0x0                // =0
     a64:      	ldr	x0, [x19, #0x8]
     a68:      	bl	0x770 <strtoul@plt>
     a6c:      	mov	x21, x0
     a70:      	mov	w2, #0xa                // =10
     a74:      	mov	x1, #0x0                // =0
     a78:      	ldr	x0, [x19, #0x10]
     a7c:      	bl	0x770 <strtoul@plt>
     a80:      	mov	x19, x0
     a84:      	mov	x1, sp
     a88:      	mov	w0, #0x1                // =1
     a8c:      	bl	0x7a0 <clock_gettime@plt>
     a90:      	cbnz	w0, 0xb48 <main+0x1bc>
     a94:      	cbz	x21, 0xb40 <main+0x1b4>
     a98:      	mov	x20, #0x0               // =0
     a9c:      	mov	x22, #0x0               // =0
     aa0:      	eor	w19, w19, w19, lsl #13
     aa4:      	eor	w19, w19, w19, lsr #17
     aa8:      	eor	w0, w19, w19, lsl #5
     aac:      	str	w0, [sp, #0x20]
     ab0:      	eor	w19, w0, w0, lsl #13
     ab4:      	eor	w19, w19, w19, lsr #17
     ab8:      	eor	w19, w19, w19, lsl #5
     abc:      	str	w19, [sp, #0x24]
     ac0:      	mov	w1, w19
     ac4:      	bl	0x918 <kernel>
     ac8:      	add	x22, x22, w0, uxtw
     acc:      	add	x20, x20, #0x1
     ad0:      	cmp	x21, x20
     ad4:      	b.ne	0xaa0 <main+0x114>
     ad8:      	add	x1, sp, #0x10
     adc:      	mov	w0, #0x1                // =1
     ae0:      	bl	0x7a0 <clock_gettime@plt>
     ae4:      	mov	w20, w0
     ae8:      	cbnz	w0, 0xb54 <main+0x1c8>
     aec:      	ldr	x0, [sp, #0x18]
     af0:      	ldr	x1, [sp, #0x8]
     af4:      	sub	x0, x0, x1
     af8:      	fmov	d1, x0
     afc:      	scvtf	d1, d1
     b00:      	adrp	x0, 0x0 <strtoul@GLIBC_2.17>
     b04:      	ldr	d0, [x0, #0xba8]
     b08:      	fmul	d1, d1, d0
     b0c:      	ldr	x0, [sp, #0x10]
     b10:      	ldr	x1, [sp]
     b14:      	sub	x0, x0, x1
     b18:      	fmov	d0, x0
     b1c:      	scvtf	d0, d0
     b20:      	mov	x2, x22
     b24:      	fadd	d0, d1, d0
     b28:      	adrp	x1, 0x0 <strtoul@GLIBC_2.17>
     b2c:      	add	x1, x1, #0xb98
     b30:      	mov	w0, #0x2                // =2
     b34:      	bl	0x7b0 <__printf_chk@plt>
     b38:      	ldp	x21, x22, [sp, #0x50]
     b3c:      	b	0x9c8 <main+0x3c>
     b40:      	mov	x22, x21
     b44:      	b	0xad8 <main+0x14c>
     b48:      	mov	w20, #0x2               // =2
     b4c:      	ldp	x21, x22, [sp, #0x50]
     b50:      	b	0x9c8 <main+0x3c>
     b54:      	mov	w20, #0x2               // =2
     b58:      	ldp	x21, x22, [sp, #0x50]
     b5c:      	b	0x9c8 <main+0x3c>
     b60:      	stp	x21, x22, [sp, #0x50]
     b64:      	bl	0x7c0 <__stack_chk_fail@plt>

Disassembly of section .fini:

0000000000000b68 <_fini>:
     b68:      	nop
     b6c:      	stp	x29, x30, [sp, #-0x10]!
     b70:      	mov	x29, sp
     b74:      	ldp	x29, x30, [sp], #0x10
     b78:      	ret
