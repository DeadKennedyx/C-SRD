
/work/experiments/runs/positional-widths-comparison-20261110/matrix/crc32_byte/build-clang-Os-limbs4/program:	file format elf64-littleaarch64

Disassembly of section .init:

0000000000000678 <_init>:
     678:      	nop
     67c:      	stp	x29, x30, [sp, #-0x10]!
     680:      	mov	x29, sp
     684:      	bl	0x774 <call_weak_fn>
     688:      	ldp	x29, x30, [sp], #0x10
     68c:      	ret

Disassembly of section .plt:

0000000000000690 <.plt>:
     690:      	stp	x16, x30, [sp, #-0x10]!
     694:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e028>
     698:      	ldr	x17, [x16, #0xff8]
     69c:      	add	x16, x16, #0xff8
     6a0:      	br	x17
     6a4:      	nop
     6a8:      	nop
     6ac:      	nop

00000000000006b0 <strtoul@plt>:
     6b0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6b4:      	ldr	x17, [x16]
     6b8:      	add	x16, x16, #0x0
     6bc:      	br	x17

00000000000006c0 <__libc_start_main@plt>:
     6c0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6c4:      	ldr	x17, [x16, #0x8]
     6c8:      	add	x16, x16, #0x8
     6cc:      	br	x17

00000000000006d0 <__cxa_finalize@plt>:
     6d0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6d4:      	ldr	x17, [x16, #0x10]
     6d8:      	add	x16, x16, #0x10
     6dc:      	br	x17

00000000000006e0 <clock_gettime@plt>:
     6e0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6e4:      	ldr	x17, [x16, #0x18]
     6e8:      	add	x16, x16, #0x18
     6ec:      	br	x17

00000000000006f0 <__gmon_start__@plt>:
     6f0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6f4:      	ldr	x17, [x16, #0x20]
     6f8:      	add	x16, x16, #0x20
     6fc:      	br	x17

0000000000000700 <abort@plt>:
     700:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     704:      	ldr	x17, [x16, #0x28]
     708:      	add	x16, x16, #0x28
     70c:      	br	x17

0000000000000710 <__isoc99_scanf@plt>:
     710:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     714:      	ldr	x17, [x16, #0x30]
     718:      	add	x16, x16, #0x30
     71c:      	br	x17

0000000000000720 <printf@plt>:
     720:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     724:      	ldr	x17, [x16, #0x38]
     728:      	add	x16, x16, #0x38
     72c:      	br	x17

Disassembly of section .text:

0000000000000740 <_start>:
     740:      	nop
     744:      	mov	x29, #0x0               // =0
     748:      	mov	x30, #0x0               // =0
     74c:      	mov	x5, x0
     750:      	ldr	x1, [sp]
     754:      	add	x2, sp, #0x8
     758:      	mov	x6, sp
     75c:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e028>
     760:      	ldr	x0, [x0, #0xfd8]
     764:      	mov	x3, #0x0                // =0
     768:      	mov	x4, #0x0                // =0
     76c:      	bl	0x6c0 <__libc_start_main@plt>
     770:      	bl	0x700 <abort@plt>

0000000000000774 <call_weak_fn>:
     774:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e028>
     778:      	ldr	x0, [x0, #0xfd0]
     77c:      	cbz	x0, 0x784 <call_weak_fn+0x10>
     780:      	b	0x6f0 <__gmon_start__@plt>
     784:      	ret
     788:      	nop
     78c:      	nop

0000000000000790 <deregister_tm_clones>:
     790:      	adrp	x0, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     794:      	add	x0, x0, #0x50
     798:      	adrp	x1, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     79c:      	add	x1, x1, #0x50
     7a0:      	cmp	x1, x0
     7a4:      	b.eq	0x7bc <deregister_tm_clones+0x2c>
     7a8:      	adrp	x1, 0x1f000 <__FRAME_END__+0x1e028>
     7ac:      	ldr	x1, [x1, #0xfc0]
     7b0:      	cbz	x1, 0x7bc <deregister_tm_clones+0x2c>
     7b4:      	mov	x16, x1
     7b8:      	br	x16
     7bc:      	ret

00000000000007c0 <register_tm_clones>:
     7c0:      	adrp	x0, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     7c4:      	add	x0, x0, #0x50
     7c8:      	adrp	x1, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     7cc:      	add	x1, x1, #0x50
     7d0:      	sub	x1, x1, x0
     7d4:      	lsr	x2, x1, #63
     7d8:      	add	x1, x2, x1, asr #3
     7dc:      	asr	x1, x1, #1
     7e0:      	cbz	x1, 0x7f8 <register_tm_clones+0x38>
     7e4:      	adrp	x2, 0x1f000 <__FRAME_END__+0x1e028>
     7e8:      	ldr	x2, [x2, #0xfe0]
     7ec:      	cbz	x2, 0x7f8 <register_tm_clones+0x38>
     7f0:      	mov	x16, x2
     7f4:      	br	x16
     7f8:      	ret
     7fc:      	nop

0000000000000800 <__do_global_dtors_aux>:
     800:      	paciasp
     804:      	stp	x29, x30, [sp, #-0x20]!
     808:      	mov	x29, sp
     80c:      	str	x19, [sp, #0x10]
     810:      	adrp	x19, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     814:      	ldrb	w0, [x19, #0x50]
     818:      	tbnz	w0, #0x0, 0x840 <__do_global_dtors_aux+0x40>
     81c:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e028>
     820:      	ldr	x0, [x0, #0xfc8]
     824:      	cbz	x0, 0x834 <__do_global_dtors_aux+0x34>
     828:      	adrp	x0, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     82c:      	ldr	x0, [x0, #0x48]
     830:      	bl	0x6d0 <__cxa_finalize@plt>
     834:      	bl	0x790 <deregister_tm_clones>
     838:      	mov	w0, #0x1                // =1
     83c:      	strb	w0, [x19, #0x50]
     840:      	ldr	x19, [sp, #0x10]
     844:      	ldp	x29, x30, [sp], #0x20
     848:      	autiasp
     84c:      	ret

0000000000000850 <frame_dummy>:
     850:      	bti	c
     854:      	b	0x7c0 <register_tm_clones>

0000000000000858 <kernel>:
     858:      	stp	x26, x25, [sp, #-0x40]!
     85c:      	stp	x24, x23, [sp, #0x10]
     860:      	stp	x22, x21, [sp, #0x20]
     864:      	stp	x20, x19, [sp, #0x30]
     868:      	mov	w10, #-0x1              // =-1
     86c:      	eon	w13, w1, w0
     870:      	eor	w18, w1, w0
     874:      	eor	w17, w10, w0, lsr #8
     878:      	eor	w2, w10, w0, lsr #12
     87c:      	sbfx	w11, w13, #0, #1
     880:      	eor	w5, w10, w0, lsr #16
     884:      	eor	w4, w10, w0, lsr #20
     888:      	eor	w12, w10, w0, lsr #24
     88c:      	ubfx	w3, w17, #1, #3
     890:      	and	w7, w11, #0x3
     894:      	ubfx	w19, w2, #1, #3
     898:      	and	w23, w11, #0x8
     89c:      	lsr	w22, w5, #1
     8a0:      	ubfx	w25, w5, #1, #3
     8a4:      	bfi	w3, w2, #3, #1
     8a8:      	bfi	w19, w5, #3, #1
     8ac:      	mvn	w6, w0
     8b0:      	eor	w10, w10, w18, lsr #4
     8b4:      	lsr	w1, w6, #25
     8b8:      	mov	w8, #0xb                // =11
     8bc:      	eor	w3, w7, w3
     8c0:      	lsr	w7, w2, #1
     8c4:      	sbfx	w2, w13, #1, #1
     8c8:      	lsr	w20, w3, #1
     8cc:      	bfi	w25, w4, #3, #1
     8d0:      	and	w26, w1, #0x8
     8d4:      	and	w24, w2, #0x3
     8d8:      	and	w1, w11, #0x2
     8dc:      	bfxil	w26, w12, #1, #3
     8e0:      	bfi	w20, w7, #3, #1
     8e4:      	ubfiz	w7, w17, #3, #1
     8e8:      	eor	w17, w23, w19
     8ec:      	ubfx	w19, w4, #1, #3
     8f0:      	mov	w9, #0xd                // =13
     8f4:      	lsl	w14, w13, #30
     8f8:      	eor	w5, w20, w24
     8fc:      	lsr	w20, w17, #1
     900:      	bfxil	w7, w10, #1, #3
     904:      	lsr	w24, w5, #1
     908:      	bfi	w19, w12, #3, #1
     90c:      	lsr	w21, w6, #26
     910:      	eor	w12, w1, w7
     914:      	eor	w1, w23, w25
     918:      	lsr	w6, w6, #30
     91c:      	orr	w4, w24, w20, lsl #3
     920:      	bfi	w20, w22, #3, #1
     924:      	and	w22, w11, w8
     928:      	and	w24, w2, #0x8
     92c:      	eor	w7, w22, w19
     930:      	lsr	w22, w1, #1
     934:      	eor	w19, w20, w24
     938:      	lsr	w20, w12, #1
     93c:      	and	w23, w11, #0xe
     940:      	lsr	w19, w19, #1
     944:      	and	w11, w11, w9
     948:      	eor	w6, w6, w23, lsr #1
     94c:      	bfi	w20, w3, #3, #1
     950:      	eor	w11, w11, w26
     954:      	and	w23, w8, w14, asr #31
     958:      	orr	w3, w19, w22, lsl #3
     95c:      	lsr	w19, w7, #1
     960:      	bfi	w22, w7, #3, #1
     964:      	and	w21, w21, #0x8
     968:      	and	w7, w2, #0x2
     96c:      	and	w14, w9, w14, asr #31
     970:      	bfi	w19, w11, #3, #1
     974:      	orr	w21, w21, w11, lsr #1
     978:      	eor	w11, w20, w7
     97c:      	eor	w20, w22, w24
     980:      	and	w2, w2, #0xf
     984:      	lsr	w22, w11, #1
     988:      	eor	w19, w19, w23
     98c:      	lsr	w20, w20, #1
     990:      	eor	w14, w21, w14
     994:      	lsr	w23, w19, #1
     998:      	sbfx	w21, w13, #2, #1
     99c:      	lsr	w24, w14, #1
     9a0:      	orr	w19, w20, w19, lsl #3
     9a4:      	lsl	w13, w13, #29
     9a8:      	eor	w2, w6, w2
     9ac:      	orr	w14, w23, w14, lsl #3
     9b0:      	and	w25, w21, #0xf
     9b4:      	orr	w6, w24, w6, lsl #3
     9b8:      	and	w19, w19, #0xe
     9bc:      	orr	w5, w22, w5, lsl #3
     9c0:      	and	w20, w4, #0xf
     9c4:      	and	w23, w14, #0xf
     9c8:      	and	w14, w21, #0x3
     9cc:      	and	w21, w21, #0x8
     9d0:      	and	w24, w8, w13, asr #31
     9d4:      	and	w26, w9, w13, asr #31
     9d8:      	eor	w4, w22, w13, asr #31
     9dc:      	eor	w13, w19, w21
     9e0:      	mov	w19, #0x8               // =8
     9e4:      	mov	w15, #0xf               // =15
     9e8:      	and	w3, w3, #0xf
     9ec:      	and	w6, w6, #0xf
     9f0:      	bics	wzr, w19, w18
     9f4:      	bic	w16, w15, w18, lsr #4
     9f8:      	lsr	w7, w2, #1
     9fc:      	eor	w20, w20, w14
     a00:      	eor	w14, w3, w21
     a04:      	lsr	w21, w5, #1
     a08:      	eor	w22, w23, w24
     a0c:      	eor	w23, w6, w26
     a10:      	eor	w3, w25, w2, lsr #1
     a14:      	csel	w2, w15, wzr, ne
     a18:      	bic	w15, w19, w0, lsr #12
     a1c:      	bic	w18, w19, w0, lsr #16
     a20:      	lsr	w19, w13, #1
     a24:      	lsr	w24, w23, #1
     a28:      	and	w6, w21, #0x6
     a2c:      	lsr	w21, w22, #1
     a30:      	orr	w15, w15, w20, lsr #1
     a34:      	orr	w18, w18, w14, lsr #1
     a38:      	bfi	w19, w22, #3, #1
     a3c:      	bfi	w24, w7, #3, #1
     a40:      	eor	w0, w2, w5, lsr #1
     a44:      	and	w5, w2, #0x3
     a48:      	and	w7, w2, #0x8
     a4c:      	bfi	w6, w20, #3, #1
     a50:      	bfi	w21, w23, #3, #1
     a54:      	eor	w23, w15, w5
     a58:      	eor	w15, w18, w7
     a5c:      	sbfx	w5, w16, #0, #1
     a60:      	and	w18, w1, #0x8
     a64:      	and	w20, w2, #0xfffffffb
     a68:      	and	w22, w2, #0xfffffffd
     a6c:      	eor	w16, w19, w7
     a70:      	orr	w7, w18, w15, lsr #1
     a74:      	eor	w1, w21, w20
     a78:      	eor	w19, w24, w22
     a7c:      	and	w21, w5, #0x8
     a80:      	and	w18, w4, #0x2
     a84:      	lsr	w4, w6, #1
     a88:      	lsl	w22, w3, #2
     a8c:      	eor	w6, w7, w21
     a90:      	and	w17, w17, #0x8
     a94:      	lsr	w3, w3, #2
     a98:      	lsr	w7, w16, #1
     a9c:      	lsr	w6, w6, #1
     aa0:      	bfi	w4, w23, #3, #1
     aa4:      	orr	w17, w17, w23, lsr #1
     aa8:      	ubfiz	w24, w19, #3, #1
     aac:      	and	w22, w22, #0x8
     ab0:      	eor	w2, w3, w2, lsr #1
     ab4:      	orr	w19, w22, w19, lsr #1
     ab8:      	and	w3, w5, #0x2
     abc:      	and	w22, w5, #0x3
     ac0:      	and	w20, w5, #0xf
     ac4:      	orr	w6, w6, w7, lsl #3
     ac8:      	bfi	w7, w1, #3, #1
     acc:      	orr	w1, w24, w1, lsr #1
     ad0:      	and	w24, w5, w8
     ad4:      	and	w5, w5, w9
     ad8:      	eor	w3, w4, w3
     adc:      	eor	w4, w17, w22
     ae0:      	lsr	w0, w0, #1
     ae4:      	lsr	w23, w15, #1
     ae8:      	eor	w5, w19, w5
     aec:      	lsr	w19, w4, #1
     af0:      	eor	w7, w7, w21
     af4:      	eor	w1, w1, w24
     af8:      	bfi	w18, w0, #2, #1
     afc:      	orr	w0, w19, w23, lsl #3
     b00:      	lsr	w7, w7, #1
     b04:      	lsr	w23, w5, #1
     b08:      	lsr	w3, w3, #1
     b0c:      	sbfx	w21, w10, #1, #1
     b10:      	lsl	w10, w10, #30
     b14:      	lsr	w19, w1, #1
     b18:      	eor	w20, w2, w20
     b1c:      	orr	w1, w7, w1, lsl #3
     b20:      	orr	w2, w23, w2, lsl #3
     b24:      	and	w22, w21, #0xf
     b28:      	eor	w24, w3, w10, asr #31
     b2c:      	bfi	w18, w3, #3, #1
     b30:      	orr	w5, w19, w5, lsl #3
     b34:      	bfi	w3, w4, #3, #1
     b38:      	and	w4, w6, #0xc
     b3c:      	and	w6, w21, #0x3
     b40:      	and	w7, w21, #0x8
     b44:      	and	w21, w9, w10, asr #31
     b48:      	and	w1, w1, #0xc
     b4c:      	and	w2, w2, #0xf
     b50:      	and	w19, w8, w10, asr #31
     b54:      	and	w0, w0, #0xf
     b58:      	and	w5, w5, #0xf
     b5c:      	eor	w1, w1, w7
     b60:      	eor	w2, w2, w21
     b64:      	lsr	w17, w20, #1
     b68:      	eor	w6, w0, w6
     b6c:      	eor	w4, w4, w7
     b70:      	eor	w5, w5, w19
     b74:      	lsl	w7, w12, #30
     b78:      	lsr	w1, w1, #1
     b7c:      	lsr	w21, w2, #1
     b80:      	eor	w10, w22, w20, lsr #1
     b84:      	sbfx	w19, w12, #1, #1
     b88:      	ubfiz	w12, w6, #3, #1
     b8c:      	and	w14, w14, #0x8
     b90:      	and	w13, w13, #0x8
     b94:      	lsr	w20, w5, #1
     b98:      	orr	w14, w14, w6, lsr #1
     b9c:      	orr	w13, w13, w4, lsr #1
     ba0:      	bfi	w1, w5, #3, #1
     ba4:      	bfi	w21, w17, #3, #1
     ba8:      	and	w5, w9, w7, asr #31
     bac:      	orr	w12, w12, w3, lsr #1
     bb0:      	bfi	w20, w2, #3, #1
     bb4:      	and	w2, w19, #0x3
     bb8:      	and	w3, w19, #0x8
     bbc:      	and	w4, w8, w7, asr #31
     bc0:      	and	w17, w19, #0x2
     bc4:      	eor	w14, w14, w2
     bc8:      	eor	w13, w13, w3
     bcc:      	eor	w1, w1, w3
     bd0:      	eor	w3, w21, w5
     bd4:      	and	w15, w15, #0x8
     bd8:      	lsr	w0, w10, #1
     bdc:      	eor	w17, w12, w17
     be0:      	eor	w2, w20, w4
     be4:      	lsr	w12, w18, #1
     be8:      	ubfiz	w18, w14, #3, #1
     bec:      	lsl	w4, w11, #30
     bf0:      	orr	w14, w15, w14, lsr #1
     bf4:      	lsr	w15, w1, #1
     bf8:      	lsr	w1, w3, #1
     bfc:      	ubfx	w5, w19, #1, #3
     c00:      	sbfx	w11, w11, #1, #1
     c04:      	and	w9, w9, w4, asr #31
     c08:      	orr	w17, w18, w17, lsr #1
     c0c:      	lsr	w18, w2, #1
     c10:      	bfi	w1, w0, #3, #1
     c14:      	and	w16, w16, #0x8
     c18:      	eor	w10, w5, w10, lsr #2
     c1c:      	lsr	w23, w24, #1
     c20:      	orr	w13, w16, w13, lsr #1
     c24:      	bfi	w15, w2, #3, #1
     c28:      	eor	w9, w1, w9
     c2c:      	bfi	w18, w3, #3, #1
     c30:      	and	w16, w11, #0x2
     c34:      	and	w0, w11, #0x3
     c38:      	and	w2, w11, #0x8
     c3c:      	and	w8, w8, w4, asr #31
     c40:      	and	w11, w11, #0xe
     c44:      	lsl	w9, w9, #24
     c48:      	eor	w14, w14, w0
     c4c:      	eon	w10, w11, w10
     c50:      	bfi	w12, w23, #3, #1
     c54:      	eor	w13, w13, w2
     c58:      	eor	w8, w18, w8
     c5c:      	lsl	w11, w14, #8
     c60:      	orr	w9, w9, w10, lsl #28
     c64:      	eor	w16, w17, w16
     c68:      	lsl	w13, w13, #12
     c6c:      	lsl	w8, w8, #20
     c70:      	eor	w10, w15, w2
     c74:      	orr	w12, w12, w16, lsl #4
     c78:      	eor	w11, w11, #0xf00
     c7c:      	eor	w9, w9, #0xf000000
     c80:      	eor	w13, w13, #0xf000
     c84:      	lsl	w10, w10, #16
     c88:      	eor	w8, w8, #0xf00000
     c8c:      	orr	w9, w9, w11
     c90:      	orr	w8, w9, w8
     c94:      	orr	w9, w12, w13
     c98:      	eor	w10, w10, #0xf0000
     c9c:      	orr	w8, w8, w9
     ca0:      	ldp	x20, x19, [sp, #0x30]
     ca4:      	ldp	x22, x21, [sp, #0x20]
     ca8:      	orr	w8, w8, w10
     cac:      	ldp	x24, x23, [sp, #0x10]
     cb0:      	eor	w0, w8, #0xff
     cb4:      	ldp	x26, x25, [sp], #0x40
     cb8:      	ret

0000000000000cbc <main>:
     cbc:      	sub	sp, sp, #0x60
     cc0:      	stp	x29, x30, [sp, #0x20]
     cc4:      	str	x23, [sp, #0x30]
     cc8:      	stp	x22, x21, [sp, #0x40]
     ccc:      	stp	x20, x19, [sp, #0x50]
     cd0:      	add	x29, sp, #0x20
     cd4:      	cmp	w0, #0x3
     cd8:      	b.eq	0xd44 <main+0x88>
     cdc:      	cmp	w0, #0x1
     ce0:      	b.ne	0xdd8 <main+0x11c>
     ce4:      	add	x21, x29, #0x18
     ce8:      	adrp	x0, 0x0 <strtoul@GLIBC_2.17>
     cec:      	add	x0, x0, #0xe70
     cf0:      	add	x1, x29, #0x18
     cf4:      	add	x2, x21, #0x4
     cf8:      	bl	0x710 <__isoc99_scanf@plt>
     cfc:      	cmp	w0, #0x2
     d00:      	b.ne	0xe30 <main+0x174>
     d04:      	adrp	x19, 0x0 <strtoul@GLIBC_2.17>
     d08:      	add	x19, x19, #0xe75
     d0c:      	adrp	x20, 0x0 <strtoul@GLIBC_2.17>
     d10:      	add	x20, x20, #0xe70
     d14:      	ldp	w0, w1, [x29, #0x18]
     d18:      	bl	0x858 <kernel>
     d1c:      	mov	w1, w0
     d20:      	mov	x0, x19
     d24:      	bl	0x720 <printf@plt>
     d28:      	add	x1, x29, #0x18
     d2c:      	add	x2, x21, #0x4
     d30:      	mov	x0, x20
     d34:      	bl	0x710 <__isoc99_scanf@plt>
     d38:      	cmp	w0, #0x2
     d3c:      	b.eq	0xd14 <main+0x58>
     d40:      	b	0xe30 <main+0x174>
     d44:      	ldr	x0, [x1, #0x8]
     d48:      	mov	x19, x1
     d4c:      	mov	x1, xzr
     d50:      	mov	w2, #0xa                // =10
     d54:      	bl	0x6b0 <strtoul@plt>
     d58:      	ldr	x8, [x19, #0x10]
     d5c:      	mov	x20, x0
     d60:      	mov	x1, xzr
     d64:      	mov	w2, #0xa                // =10
     d68:      	mov	x0, x8
     d6c:      	bl	0x6b0 <strtoul@plt>
     d70:      	mov	x21, x0
     d74:      	add	x1, sp, #0x10
     d78:      	mov	w0, #0x1                // =1
     d7c:      	bl	0x6e0 <clock_gettime@plt>
     d80:      	cbnz	w0, 0xdf4 <main+0x138>
     d84:      	cbz	x20, 0xde0 <main+0x124>
     d88:      	mov	x22, xzr
     d8c:      	mov	x19, xzr
     d90:      	add	x23, x29, #0x18
     d94:      	mov	x8, xzr
     d98:      	mov	w9, #0x1                // =1
     d9c:      	eor	w10, w21, w21, lsl #13
     da0:      	mov	w11, w9
     da4:      	mov	w9, wzr
     da8:      	eor	w10, w10, w10, lsr #17
     dac:      	eor	w21, w10, w10, lsl #5
     db0:      	str	w21, [x23, x8, lsl #2]
     db4:      	mov	w8, #0x1                // =1
     db8:      	tbnz	w11, #0x0, 0xd9c <main+0xe0>
     dbc:      	ldp	w0, w1, [x29, #0x18]
     dc0:      	bl	0x858 <kernel>
     dc4:      	add	x22, x22, #0x1
     dc8:      	add	x19, x19, w0, uxtw
     dcc:      	cmp	x22, x20
     dd0:      	b.ne	0xd94 <main+0xd8>
     dd4:      	b	0xde4 <main+0x128>
     dd8:      	mov	w0, #0x3                // =3
     ddc:      	b	0xe34 <main+0x178>
     de0:      	mov	x19, xzr
     de4:      	mov	x1, sp
     de8:      	mov	w0, #0x1                // =1
     dec:      	bl	0x6e0 <clock_gettime@plt>
     df0:      	cbz	w0, 0xdfc <main+0x140>
     df4:      	mov	w0, #0x2                // =2
     df8:      	b	0xe34 <main+0x178>
     dfc:      	ldp	x8, x9, [sp]
     e00:      	adrp	x0, 0x0 <strtoul@GLIBC_2.17>
     e04:      	add	x0, x0, #0xe79
     e08:      	ldp	x10, x11, [sp, #0x10]
     e0c:      	mov	x1, x19
     e10:      	sub	x8, x8, x10
     e14:      	sub	x9, x9, x11
     e18:      	scvtf	d0, x8
     e1c:      	scvtf	d1, x9
     e20:      	adrp	x8, 0x0 <strtoul@GLIBC_2.17>
     e24:      	ldr	d2, [x8, #0xe68]
     e28:      	fmadd	d0, d1, d2, d0
     e2c:      	bl	0x720 <printf@plt>
     e30:      	mov	w0, wzr
     e34:      	ldp	x20, x19, [sp, #0x50]
     e38:      	ldr	x23, [sp, #0x30]
     e3c:      	ldp	x22, x21, [sp, #0x40]
     e40:      	ldp	x29, x30, [sp, #0x20]
     e44:      	add	sp, sp, #0x60
     e48:      	ret

Disassembly of section .fini:

0000000000000e4c <_fini>:
     e4c:      	nop
     e50:      	stp	x29, x30, [sp, #-0x10]!
     e54:      	mov	x29, sp
     e58:      	ldp	x29, x30, [sp], #0x10
     e5c:      	ret
