
/work/experiments/runs/positional-widths-comparison-20261110/matrix/crc32_byte/build-gcc-O0-limbs8/program:	file format elf64-littleaarch64

Disassembly of section .init:

0000000000000730 <_init>:
     730:      	nop
     734:      	stp	x29, x30, [sp, #-0x10]!
     738:      	mov	x29, sp
     73c:      	bl	0x834 <call_weak_fn>
     740:      	ldp	x29, x30, [sp], #0x10
     744:      	ret

Disassembly of section .plt:

0000000000000750 <.plt>:
     750:      	stp	x16, x30, [sp, #-0x10]!
     754:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1d450>
     758:      	ldr	x17, [x16, #0xf78]
     75c:      	add	x16, x16, #0xf78
     760:      	br	x17
     764:      	nop
     768:      	nop
     76c:      	nop

0000000000000770 <strtoul@plt>:
     770:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1d450>
     774:      	ldr	x17, [x16, #0xf80]
     778:      	add	x16, x16, #0xf80
     77c:      	br	x17

0000000000000780 <__libc_start_main@plt>:
     780:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1d450>
     784:      	ldr	x17, [x16, #0xf88]
     788:      	add	x16, x16, #0xf88
     78c:      	br	x17

0000000000000790 <__cxa_finalize@plt>:
     790:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1d450>
     794:      	ldr	x17, [x16, #0xf90]
     798:      	add	x16, x16, #0xf90
     79c:      	br	x17

00000000000007a0 <clock_gettime@plt>:
     7a0:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1d450>
     7a4:      	ldr	x17, [x16, #0xf98]
     7a8:      	add	x16, x16, #0xf98
     7ac:      	br	x17

00000000000007b0 <__stack_chk_fail@plt>:
     7b0:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1d450>
     7b4:      	ldr	x17, [x16, #0xfa0]
     7b8:      	add	x16, x16, #0xfa0
     7bc:      	br	x17

00000000000007c0 <__gmon_start__@plt>:
     7c0:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1d450>
     7c4:      	ldr	x17, [x16, #0xfa8]
     7c8:      	add	x16, x16, #0xfa8
     7cc:      	br	x17

00000000000007d0 <abort@plt>:
     7d0:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1d450>
     7d4:      	ldr	x17, [x16, #0xfb0]
     7d8:      	add	x16, x16, #0xfb0
     7dc:      	br	x17

00000000000007e0 <__isoc99_scanf@plt>:
     7e0:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1d450>
     7e4:      	ldr	x17, [x16, #0xfb8]
     7e8:      	add	x16, x16, #0xfb8
     7ec:      	br	x17

00000000000007f0 <printf@plt>:
     7f0:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1d450>
     7f4:      	ldr	x17, [x16, #0xfc0]
     7f8:      	add	x16, x16, #0xfc0
     7fc:      	br	x17

Disassembly of section .text:

0000000000000800 <_start>:
     800:      	nop
     804:      	mov	x29, #0x0               // =0
     808:      	mov	x30, #0x0               // =0
     80c:      	mov	x5, x0
     810:      	ldr	x1, [sp]
     814:      	add	x2, sp, #0x8
     818:      	mov	x6, sp
     81c:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1d450>
     820:      	ldr	x0, [x0, #0xff0]
     824:      	mov	x3, #0x0                // =0
     828:      	mov	x4, #0x0                // =0
     82c:      	bl	0x780 <__libc_start_main@plt>
     830:      	bl	0x7d0 <abort@plt>

0000000000000834 <call_weak_fn>:
     834:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1d450>
     838:      	ldr	x0, [x0, #0xfe0]
     83c:      	cbz	x0, 0x844 <call_weak_fn+0x10>
     840:      	b	0x7c0 <__gmon_start__@plt>
     844:      	ret
     848:      	nop
     84c:      	nop

0000000000000850 <deregister_tm_clones>:
     850:      	adrp	x0, 0x20000 <data_start>
     854:      	add	x0, x0, #0x10
     858:      	adrp	x1, 0x20000 <data_start>
     85c:      	add	x1, x1, #0x10
     860:      	cmp	x1, x0
     864:      	b.eq	0x87c <deregister_tm_clones+0x2c>
     868:      	adrp	x1, 0x1f000 <__FRAME_END__+0x1d450>
     86c:      	ldr	x1, [x1, #0xfd0]
     870:      	cbz	x1, 0x87c <deregister_tm_clones+0x2c>
     874:      	mov	x16, x1
     878:      	br	x16
     87c:      	ret

0000000000000880 <register_tm_clones>:
     880:      	adrp	x0, 0x20000 <data_start>
     884:      	add	x0, x0, #0x10
     888:      	adrp	x1, 0x20000 <data_start>
     88c:      	add	x1, x1, #0x10
     890:      	sub	x1, x1, x0
     894:      	lsr	x2, x1, #63
     898:      	add	x1, x2, x1, asr #3
     89c:      	asr	x1, x1, #1
     8a0:      	cbz	x1, 0x8b8 <register_tm_clones+0x38>
     8a4:      	adrp	x2, 0x1f000 <__FRAME_END__+0x1d450>
     8a8:      	ldr	x2, [x2, #0xff8]
     8ac:      	cbz	x2, 0x8b8 <register_tm_clones+0x38>
     8b0:      	mov	x16, x2
     8b4:      	br	x16
     8b8:      	ret
     8bc:      	nop

00000000000008c0 <__do_global_dtors_aux>:
     8c0:      	paciasp
     8c4:      	stp	x29, x30, [sp, #-0x20]!
     8c8:      	mov	x29, sp
     8cc:      	str	x19, [sp, #0x10]
     8d0:      	adrp	x19, 0x20000 <data_start>
     8d4:      	ldrb	w0, [x19, #0x10]
     8d8:      	tbnz	w0, #0x0, 0x900 <__do_global_dtors_aux+0x40>
     8dc:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1d450>
     8e0:      	ldr	x0, [x0, #0xfd8]
     8e4:      	cbz	x0, 0x8f4 <__do_global_dtors_aux+0x34>
     8e8:      	adrp	x0, 0x20000 <data_start>
     8ec:      	ldr	x0, [x0, #0x8]
     8f0:      	bl	0x790 <__cxa_finalize@plt>
     8f4:      	bl	0x850 <deregister_tm_clones>
     8f8:      	mov	w0, #0x1                // =1
     8fc:      	strb	w0, [x19, #0x10]
     900:      	ldr	x19, [sp, #0x10]
     904:      	ldp	x29, x30, [sp], #0x20
     908:      	autiasp
     90c:      	ret

0000000000000910 <frame_dummy>:
     910:      	bti	c
     914:      	b	0x880 <register_tm_clones>

0000000000000918 <kernel>:
     918:      	sub	sp, sp, #0x3c0
     91c:      	str	w0, [sp, #0xc]
     920:      	str	w1, [sp, #0x8]
     924:      	ldr	w0, [sp, #0xc]
     928:      	and	w0, w0, #0xff
     92c:      	str	w0, [sp, #0x1c]
     930:      	ldr	w0, [sp, #0xc]
     934:      	lsr	w0, w0, #8
     938:      	and	w0, w0, #0xff
     93c:      	str	w0, [sp, #0x20]
     940:      	ldr	w0, [sp, #0xc]
     944:      	lsr	w0, w0, #16
     948:      	and	w0, w0, #0xff
     94c:      	str	w0, [sp, #0x24]
     950:      	ldr	w0, [sp, #0xc]
     954:      	lsr	w0, w0, #24
     958:      	str	w0, [sp, #0x28]
     95c:      	ldr	w0, [sp, #0x8]
     960:      	and	w0, w0, #0xff
     964:      	str	w0, [sp, #0x2c]
     968:      	ldr	w0, [sp, #0x8]
     96c:      	lsr	w0, w0, #8
     970:      	and	w0, w0, #0xff
     974:      	str	w0, [sp, #0x30]
     978:      	ldr	w0, [sp, #0x8]
     97c:      	lsr	w0, w0, #16
     980:      	and	w0, w0, #0xff
     984:      	str	w0, [sp, #0x34]
     988:      	ldr	w0, [sp, #0x8]
     98c:      	lsr	w0, w0, #24
     990:      	str	w0, [sp, #0x38]
     994:      	ldr	w0, [sp, #0x1c]
     998:      	eor	w0, w0, #0xff
     99c:      	str	w0, [sp, #0x3c]
     9a0:      	ldr	w0, [sp, #0x20]
     9a4:      	eor	w0, w0, #0xff
     9a8:      	str	w0, [sp, #0x40]
     9ac:      	ldr	w0, [sp, #0x24]
     9b0:      	eor	w0, w0, #0xff
     9b4:      	str	w0, [sp, #0x44]
     9b8:      	ldr	w0, [sp, #0x28]
     9bc:      	eor	w0, w0, #0xff
     9c0:      	str	w0, [sp, #0x48]
     9c4:      	ldr	w0, [sp, #0x2c]
     9c8:      	and	w0, w0, #0xff
     9cc:      	str	w0, [sp, #0x4c]
     9d0:      	str	wzr, [sp, #0x50]
     9d4:      	str	wzr, [sp, #0x54]
     9d8:      	str	wzr, [sp, #0x58]
     9dc:      	ldr	w1, [sp, #0x3c]
     9e0:      	ldr	w0, [sp, #0x4c]
     9e4:      	eor	w0, w1, w0
     9e8:      	str	w0, [sp, #0x5c]
     9ec:      	ldr	w1, [sp, #0x40]
     9f0:      	ldr	w0, [sp, #0x50]
     9f4:      	eor	w0, w1, w0
     9f8:      	str	w0, [sp, #0x60]
     9fc:      	ldr	w1, [sp, #0x44]
     a00:      	ldr	w0, [sp, #0x54]
     a04:      	eor	w0, w1, w0
     a08:      	str	w0, [sp, #0x64]
     a0c:      	ldr	w1, [sp, #0x48]
     a10:      	ldr	w0, [sp, #0x58]
     a14:      	eor	w0, w1, w0
     a18:      	str	w0, [sp, #0x68]
     a1c:      	ldr	w0, [sp, #0x5c]
     a20:      	and	w0, w0, #0x1
     a24:      	str	w0, [sp, #0x6c]
     a28:      	str	wzr, [sp, #0x70]
     a2c:      	str	wzr, [sp, #0x74]
     a30:      	str	wzr, [sp, #0x78]
     a34:      	ldr	w0, [sp, #0x6c]
     a38:      	neg	w0, w0
     a3c:      	and	w0, w0, #0xff
     a40:      	str	w0, [sp, #0x7c]
     a44:      	ldr	w0, [sp, #0x6c]
     a48:      	cmp	w0, #0x0
     a4c:      	cset	w0, ne
     a50:      	and	w0, w0, #0xff
     a54:      	str	w0, [sp, #0x80]
     a58:      	ldr	w1, [sp, #0x70]
     a5c:      	ldr	w0, [sp, #0x80]
     a60:      	add	w0, w1, w0
     a64:      	str	w0, [sp, #0x84]
     a68:      	ldr	w0, [sp, #0x84]
     a6c:      	neg	w0, w0
     a70:      	and	w0, w0, #0xff
     a74:      	str	w0, [sp, #0x88]
     a78:      	ldr	w0, [sp, #0x84]
     a7c:      	cmp	w0, #0x0
     a80:      	cset	w0, ne
     a84:      	and	w0, w0, #0xff
     a88:      	str	w0, [sp, #0x8c]
     a8c:      	ldr	w1, [sp, #0x74]
     a90:      	ldr	w0, [sp, #0x8c]
     a94:      	add	w0, w1, w0
     a98:      	str	w0, [sp, #0x90]
     a9c:      	ldr	w0, [sp, #0x90]
     aa0:      	neg	w0, w0
     aa4:      	and	w0, w0, #0xff
     aa8:      	str	w0, [sp, #0x94]
     aac:      	ldr	w0, [sp, #0x90]
     ab0:      	cmp	w0, #0x0
     ab4:      	cset	w0, ne
     ab8:      	and	w0, w0, #0xff
     abc:      	str	w0, [sp, #0x98]
     ac0:      	ldr	w1, [sp, #0x78]
     ac4:      	ldr	w0, [sp, #0x98]
     ac8:      	add	w0, w1, w0
     acc:      	str	w0, [sp, #0x9c]
     ad0:      	ldr	w0, [sp, #0x9c]
     ad4:      	neg	w0, w0
     ad8:      	and	w0, w0, #0xff
     adc:      	str	w0, [sp, #0xa0]
     ae0:      	ldr	w0, [sp, #0x5c]
     ae4:      	lsr	w1, w0, #1
     ae8:      	ldr	w0, [sp, #0x60]
     aec:      	lsl	w0, w0, #7
     af0:      	orr	w0, w1, w0
     af4:      	and	w0, w0, #0xff
     af8:      	str	w0, [sp, #0xa4]
     afc:      	ldr	w0, [sp, #0x60]
     b00:      	lsr	w1, w0, #1
     b04:      	ldr	w0, [sp, #0x64]
     b08:      	lsl	w0, w0, #7
     b0c:      	orr	w0, w1, w0
     b10:      	and	w0, w0, #0xff
     b14:      	str	w0, [sp, #0xa8]
     b18:      	ldr	w0, [sp, #0x64]
     b1c:      	lsr	w1, w0, #1
     b20:      	ldr	w0, [sp, #0x68]
     b24:      	lsl	w0, w0, #7
     b28:      	orr	w0, w1, w0
     b2c:      	and	w0, w0, #0xff
     b30:      	str	w0, [sp, #0xac]
     b34:      	ldr	w0, [sp, #0x68]
     b38:      	lsr	w0, w0, #1
     b3c:      	and	w0, w0, #0xff
     b40:      	str	w0, [sp, #0xb0]
     b44:      	ldr	w0, [sp, #0x7c]
     b48:      	and	w0, w0, #0x20
     b4c:      	str	w0, [sp, #0xb4]
     b50:      	ldr	w1, [sp, #0x88]
     b54:      	mov	w0, #0x83               // =131
     b58:      	and	w0, w1, w0
     b5c:      	str	w0, [sp, #0xb8]
     b60:      	ldr	w1, [sp, #0x94]
     b64:      	mov	w0, #0xb8               // =184
     b68:      	and	w0, w1, w0
     b6c:      	str	w0, [sp, #0xbc]
     b70:      	ldr	w1, [sp, #0xa0]
     b74:      	mov	w0, #0xed               // =237
     b78:      	and	w0, w1, w0
     b7c:      	str	w0, [sp, #0xc0]
     b80:      	ldr	w1, [sp, #0xa4]
     b84:      	ldr	w0, [sp, #0xb4]
     b88:      	eor	w0, w1, w0
     b8c:      	str	w0, [sp, #0xc4]
     b90:      	ldr	w1, [sp, #0xa8]
     b94:      	ldr	w0, [sp, #0xb8]
     b98:      	eor	w0, w1, w0
     b9c:      	str	w0, [sp, #0xc8]
     ba0:      	ldr	w1, [sp, #0xac]
     ba4:      	ldr	w0, [sp, #0xbc]
     ba8:      	eor	w0, w1, w0
     bac:      	str	w0, [sp, #0xcc]
     bb0:      	ldr	w1, [sp, #0xb0]
     bb4:      	ldr	w0, [sp, #0xc0]
     bb8:      	eor	w0, w1, w0
     bbc:      	str	w0, [sp, #0xd0]
     bc0:      	ldr	w0, [sp, #0xc4]
     bc4:      	and	w0, w0, #0x1
     bc8:      	str	w0, [sp, #0xd4]
     bcc:      	str	wzr, [sp, #0xd8]
     bd0:      	str	wzr, [sp, #0xdc]
     bd4:      	str	wzr, [sp, #0xe0]
     bd8:      	ldr	w0, [sp, #0xd4]
     bdc:      	neg	w0, w0
     be0:      	and	w0, w0, #0xff
     be4:      	str	w0, [sp, #0xe4]
     be8:      	ldr	w0, [sp, #0xd4]
     bec:      	cmp	w0, #0x0
     bf0:      	cset	w0, ne
     bf4:      	and	w0, w0, #0xff
     bf8:      	str	w0, [sp, #0xe8]
     bfc:      	ldr	w1, [sp, #0xd8]
     c00:      	ldr	w0, [sp, #0xe8]
     c04:      	add	w0, w1, w0
     c08:      	str	w0, [sp, #0xec]
     c0c:      	ldr	w0, [sp, #0xec]
     c10:      	neg	w0, w0
     c14:      	and	w0, w0, #0xff
     c18:      	str	w0, [sp, #0xf0]
     c1c:      	ldr	w0, [sp, #0xec]
     c20:      	cmp	w0, #0x0
     c24:      	cset	w0, ne
     c28:      	and	w0, w0, #0xff
     c2c:      	str	w0, [sp, #0xf4]
     c30:      	ldr	w1, [sp, #0xdc]
     c34:      	ldr	w0, [sp, #0xf4]
     c38:      	add	w0, w1, w0
     c3c:      	str	w0, [sp, #0xf8]
     c40:      	ldr	w0, [sp, #0xf8]
     c44:      	neg	w0, w0
     c48:      	and	w0, w0, #0xff
     c4c:      	str	w0, [sp, #0xfc]
     c50:      	ldr	w0, [sp, #0xf8]
     c54:      	cmp	w0, #0x0
     c58:      	cset	w0, ne
     c5c:      	and	w0, w0, #0xff
     c60:      	str	w0, [sp, #0x100]
     c64:      	ldr	w1, [sp, #0xe0]
     c68:      	ldr	w0, [sp, #0x100]
     c6c:      	add	w0, w1, w0
     c70:      	str	w0, [sp, #0x104]
     c74:      	ldr	w0, [sp, #0x104]
     c78:      	neg	w0, w0
     c7c:      	and	w0, w0, #0xff
     c80:      	str	w0, [sp, #0x108]
     c84:      	ldr	w0, [sp, #0xc4]
     c88:      	lsr	w1, w0, #1
     c8c:      	ldr	w0, [sp, #0xc8]
     c90:      	lsl	w0, w0, #7
     c94:      	orr	w0, w1, w0
     c98:      	and	w0, w0, #0xff
     c9c:      	str	w0, [sp, #0x10c]
     ca0:      	ldr	w0, [sp, #0xc8]
     ca4:      	lsr	w1, w0, #1
     ca8:      	ldr	w0, [sp, #0xcc]
     cac:      	lsl	w0, w0, #7
     cb0:      	orr	w0, w1, w0
     cb4:      	and	w0, w0, #0xff
     cb8:      	str	w0, [sp, #0x110]
     cbc:      	ldr	w0, [sp, #0xcc]
     cc0:      	lsr	w1, w0, #1
     cc4:      	ldr	w0, [sp, #0xd0]
     cc8:      	lsl	w0, w0, #7
     ccc:      	orr	w0, w1, w0
     cd0:      	and	w0, w0, #0xff
     cd4:      	str	w0, [sp, #0x114]
     cd8:      	ldr	w0, [sp, #0xd0]
     cdc:      	lsr	w0, w0, #1
     ce0:      	and	w0, w0, #0xff
     ce4:      	str	w0, [sp, #0x118]
     ce8:      	ldr	w0, [sp, #0xe4]
     cec:      	and	w0, w0, #0x20
     cf0:      	str	w0, [sp, #0x11c]
     cf4:      	ldr	w1, [sp, #0xf0]
     cf8:      	mov	w0, #0x83               // =131
     cfc:      	and	w0, w1, w0
     d00:      	str	w0, [sp, #0x120]
     d04:      	ldr	w1, [sp, #0xfc]
     d08:      	mov	w0, #0xb8               // =184
     d0c:      	and	w0, w1, w0
     d10:      	str	w0, [sp, #0x124]
     d14:      	ldr	w1, [sp, #0x108]
     d18:      	mov	w0, #0xed               // =237
     d1c:      	and	w0, w1, w0
     d20:      	str	w0, [sp, #0x128]
     d24:      	ldr	w1, [sp, #0x10c]
     d28:      	ldr	w0, [sp, #0x11c]
     d2c:      	eor	w0, w1, w0
     d30:      	str	w0, [sp, #0x12c]
     d34:      	ldr	w1, [sp, #0x110]
     d38:      	ldr	w0, [sp, #0x120]
     d3c:      	eor	w0, w1, w0
     d40:      	str	w0, [sp, #0x130]
     d44:      	ldr	w1, [sp, #0x114]
     d48:      	ldr	w0, [sp, #0x124]
     d4c:      	eor	w0, w1, w0
     d50:      	str	w0, [sp, #0x134]
     d54:      	ldr	w1, [sp, #0x118]
     d58:      	ldr	w0, [sp, #0x128]
     d5c:      	eor	w0, w1, w0
     d60:      	str	w0, [sp, #0x138]
     d64:      	ldr	w0, [sp, #0x12c]
     d68:      	and	w0, w0, #0x1
     d6c:      	str	w0, [sp, #0x13c]
     d70:      	str	wzr, [sp, #0x140]
     d74:      	str	wzr, [sp, #0x144]
     d78:      	str	wzr, [sp, #0x148]
     d7c:      	ldr	w0, [sp, #0x13c]
     d80:      	neg	w0, w0
     d84:      	and	w0, w0, #0xff
     d88:      	str	w0, [sp, #0x14c]
     d8c:      	ldr	w0, [sp, #0x13c]
     d90:      	cmp	w0, #0x0
     d94:      	cset	w0, ne
     d98:      	and	w0, w0, #0xff
     d9c:      	str	w0, [sp, #0x150]
     da0:      	ldr	w1, [sp, #0x140]
     da4:      	ldr	w0, [sp, #0x150]
     da8:      	add	w0, w1, w0
     dac:      	str	w0, [sp, #0x154]
     db0:      	ldr	w0, [sp, #0x154]
     db4:      	neg	w0, w0
     db8:      	and	w0, w0, #0xff
     dbc:      	str	w0, [sp, #0x158]
     dc0:      	ldr	w0, [sp, #0x154]
     dc4:      	cmp	w0, #0x0
     dc8:      	cset	w0, ne
     dcc:      	and	w0, w0, #0xff
     dd0:      	str	w0, [sp, #0x15c]
     dd4:      	ldr	w1, [sp, #0x144]
     dd8:      	ldr	w0, [sp, #0x15c]
     ddc:      	add	w0, w1, w0
     de0:      	str	w0, [sp, #0x160]
     de4:      	ldr	w0, [sp, #0x160]
     de8:      	neg	w0, w0
     dec:      	and	w0, w0, #0xff
     df0:      	str	w0, [sp, #0x164]
     df4:      	ldr	w0, [sp, #0x160]
     df8:      	cmp	w0, #0x0
     dfc:      	cset	w0, ne
     e00:      	and	w0, w0, #0xff
     e04:      	str	w0, [sp, #0x168]
     e08:      	ldr	w1, [sp, #0x148]
     e0c:      	ldr	w0, [sp, #0x168]
     e10:      	add	w0, w1, w0
     e14:      	str	w0, [sp, #0x16c]
     e18:      	ldr	w0, [sp, #0x16c]
     e1c:      	neg	w0, w0
     e20:      	and	w0, w0, #0xff
     e24:      	str	w0, [sp, #0x170]
     e28:      	ldr	w0, [sp, #0x12c]
     e2c:      	lsr	w1, w0, #1
     e30:      	ldr	w0, [sp, #0x130]
     e34:      	lsl	w0, w0, #7
     e38:      	orr	w0, w1, w0
     e3c:      	and	w0, w0, #0xff
     e40:      	str	w0, [sp, #0x174]
     e44:      	ldr	w0, [sp, #0x130]
     e48:      	lsr	w1, w0, #1
     e4c:      	ldr	w0, [sp, #0x134]
     e50:      	lsl	w0, w0, #7
     e54:      	orr	w0, w1, w0
     e58:      	and	w0, w0, #0xff
     e5c:      	str	w0, [sp, #0x178]
     e60:      	ldr	w0, [sp, #0x134]
     e64:      	lsr	w1, w0, #1
     e68:      	ldr	w0, [sp, #0x138]
     e6c:      	lsl	w0, w0, #7
     e70:      	orr	w0, w1, w0
     e74:      	and	w0, w0, #0xff
     e78:      	str	w0, [sp, #0x17c]
     e7c:      	ldr	w0, [sp, #0x138]
     e80:      	lsr	w0, w0, #1
     e84:      	and	w0, w0, #0xff
     e88:      	str	w0, [sp, #0x180]
     e8c:      	ldr	w0, [sp, #0x14c]
     e90:      	and	w0, w0, #0x20
     e94:      	str	w0, [sp, #0x184]
     e98:      	ldr	w1, [sp, #0x158]
     e9c:      	mov	w0, #0x83               // =131
     ea0:      	and	w0, w1, w0
     ea4:      	str	w0, [sp, #0x188]
     ea8:      	ldr	w1, [sp, #0x164]
     eac:      	mov	w0, #0xb8               // =184
     eb0:      	and	w0, w1, w0
     eb4:      	str	w0, [sp, #0x18c]
     eb8:      	ldr	w1, [sp, #0x170]
     ebc:      	mov	w0, #0xed               // =237
     ec0:      	and	w0, w1, w0
     ec4:      	str	w0, [sp, #0x190]
     ec8:      	ldr	w1, [sp, #0x174]
     ecc:      	ldr	w0, [sp, #0x184]
     ed0:      	eor	w0, w1, w0
     ed4:      	str	w0, [sp, #0x194]
     ed8:      	ldr	w1, [sp, #0x178]
     edc:      	ldr	w0, [sp, #0x188]
     ee0:      	eor	w0, w1, w0
     ee4:      	str	w0, [sp, #0x198]
     ee8:      	ldr	w1, [sp, #0x17c]
     eec:      	ldr	w0, [sp, #0x18c]
     ef0:      	eor	w0, w1, w0
     ef4:      	str	w0, [sp, #0x19c]
     ef8:      	ldr	w1, [sp, #0x180]
     efc:      	ldr	w0, [sp, #0x190]
     f00:      	eor	w0, w1, w0
     f04:      	str	w0, [sp, #0x1a0]
     f08:      	ldr	w0, [sp, #0x194]
     f0c:      	and	w0, w0, #0x1
     f10:      	str	w0, [sp, #0x1a4]
     f14:      	str	wzr, [sp, #0x1a8]
     f18:      	str	wzr, [sp, #0x1ac]
     f1c:      	str	wzr, [sp, #0x1b0]
     f20:      	ldr	w0, [sp, #0x1a4]
     f24:      	neg	w0, w0
     f28:      	and	w0, w0, #0xff
     f2c:      	str	w0, [sp, #0x1b4]
     f30:      	ldr	w0, [sp, #0x1a4]
     f34:      	cmp	w0, #0x0
     f38:      	cset	w0, ne
     f3c:      	and	w0, w0, #0xff
     f40:      	str	w0, [sp, #0x1b8]
     f44:      	ldr	w1, [sp, #0x1a8]
     f48:      	ldr	w0, [sp, #0x1b8]
     f4c:      	add	w0, w1, w0
     f50:      	str	w0, [sp, #0x1bc]
     f54:      	ldr	w0, [sp, #0x1bc]
     f58:      	neg	w0, w0
     f5c:      	and	w0, w0, #0xff
     f60:      	str	w0, [sp, #0x1c0]
     f64:      	ldr	w0, [sp, #0x1bc]
     f68:      	cmp	w0, #0x0
     f6c:      	cset	w0, ne
     f70:      	and	w0, w0, #0xff
     f74:      	str	w0, [sp, #0x1c4]
     f78:      	ldr	w1, [sp, #0x1ac]
     f7c:      	ldr	w0, [sp, #0x1c4]
     f80:      	add	w0, w1, w0
     f84:      	str	w0, [sp, #0x1c8]
     f88:      	ldr	w0, [sp, #0x1c8]
     f8c:      	neg	w0, w0
     f90:      	and	w0, w0, #0xff
     f94:      	str	w0, [sp, #0x1cc]
     f98:      	ldr	w0, [sp, #0x1c8]
     f9c:      	cmp	w0, #0x0
     fa0:      	cset	w0, ne
     fa4:      	and	w0, w0, #0xff
     fa8:      	str	w0, [sp, #0x1d0]
     fac:      	ldr	w1, [sp, #0x1b0]
     fb0:      	ldr	w0, [sp, #0x1d0]
     fb4:      	add	w0, w1, w0
     fb8:      	str	w0, [sp, #0x1d4]
     fbc:      	ldr	w0, [sp, #0x1d4]
     fc0:      	neg	w0, w0
     fc4:      	and	w0, w0, #0xff
     fc8:      	str	w0, [sp, #0x1d8]
     fcc:      	ldr	w0, [sp, #0x194]
     fd0:      	lsr	w1, w0, #1
     fd4:      	ldr	w0, [sp, #0x198]
     fd8:      	lsl	w0, w0, #7
     fdc:      	orr	w0, w1, w0
     fe0:      	and	w0, w0, #0xff
     fe4:      	str	w0, [sp, #0x1dc]
     fe8:      	ldr	w0, [sp, #0x198]
     fec:      	lsr	w1, w0, #1
     ff0:      	ldr	w0, [sp, #0x19c]
     ff4:      	lsl	w0, w0, #7
     ff8:      	orr	w0, w1, w0
     ffc:      	and	w0, w0, #0xff
    1000:      	str	w0, [sp, #0x1e0]
    1004:      	ldr	w0, [sp, #0x19c]
    1008:      	lsr	w1, w0, #1
    100c:      	ldr	w0, [sp, #0x1a0]
    1010:      	lsl	w0, w0, #7
    1014:      	orr	w0, w1, w0
    1018:      	and	w0, w0, #0xff
    101c:      	str	w0, [sp, #0x1e4]
    1020:      	ldr	w0, [sp, #0x1a0]
    1024:      	lsr	w0, w0, #1
    1028:      	and	w0, w0, #0xff
    102c:      	str	w0, [sp, #0x1e8]
    1030:      	ldr	w0, [sp, #0x1b4]
    1034:      	and	w0, w0, #0x20
    1038:      	str	w0, [sp, #0x1ec]
    103c:      	ldr	w1, [sp, #0x1c0]
    1040:      	mov	w0, #0x83               // =131
    1044:      	and	w0, w1, w0
    1048:      	str	w0, [sp, #0x1f0]
    104c:      	ldr	w1, [sp, #0x1cc]
    1050:      	mov	w0, #0xb8               // =184
    1054:      	and	w0, w1, w0
    1058:      	str	w0, [sp, #0x1f4]
    105c:      	ldr	w1, [sp, #0x1d8]
    1060:      	mov	w0, #0xed               // =237
    1064:      	and	w0, w1, w0
    1068:      	str	w0, [sp, #0x1f8]
    106c:      	ldr	w1, [sp, #0x1dc]
    1070:      	ldr	w0, [sp, #0x1ec]
    1074:      	eor	w0, w1, w0
    1078:      	str	w0, [sp, #0x1fc]
    107c:      	ldr	w1, [sp, #0x1e0]
    1080:      	ldr	w0, [sp, #0x1f0]
    1084:      	eor	w0, w1, w0
    1088:      	str	w0, [sp, #0x200]
    108c:      	ldr	w1, [sp, #0x1e4]
    1090:      	ldr	w0, [sp, #0x1f4]
    1094:      	eor	w0, w1, w0
    1098:      	str	w0, [sp, #0x204]
    109c:      	ldr	w1, [sp, #0x1e8]
    10a0:      	ldr	w0, [sp, #0x1f8]
    10a4:      	eor	w0, w1, w0
    10a8:      	str	w0, [sp, #0x208]
    10ac:      	ldr	w0, [sp, #0x1fc]
    10b0:      	and	w0, w0, #0x1
    10b4:      	str	w0, [sp, #0x20c]
    10b8:      	str	wzr, [sp, #0x210]
    10bc:      	str	wzr, [sp, #0x214]
    10c0:      	str	wzr, [sp, #0x218]
    10c4:      	ldr	w0, [sp, #0x20c]
    10c8:      	neg	w0, w0
    10cc:      	and	w0, w0, #0xff
    10d0:      	str	w0, [sp, #0x21c]
    10d4:      	ldr	w0, [sp, #0x20c]
    10d8:      	cmp	w0, #0x0
    10dc:      	cset	w0, ne
    10e0:      	and	w0, w0, #0xff
    10e4:      	str	w0, [sp, #0x220]
    10e8:      	ldr	w1, [sp, #0x210]
    10ec:      	ldr	w0, [sp, #0x220]
    10f0:      	add	w0, w1, w0
    10f4:      	str	w0, [sp, #0x224]
    10f8:      	ldr	w0, [sp, #0x224]
    10fc:      	neg	w0, w0
    1100:      	and	w0, w0, #0xff
    1104:      	str	w0, [sp, #0x228]
    1108:      	ldr	w0, [sp, #0x224]
    110c:      	cmp	w0, #0x0
    1110:      	cset	w0, ne
    1114:      	and	w0, w0, #0xff
    1118:      	str	w0, [sp, #0x22c]
    111c:      	ldr	w1, [sp, #0x214]
    1120:      	ldr	w0, [sp, #0x22c]
    1124:      	add	w0, w1, w0
    1128:      	str	w0, [sp, #0x230]
    112c:      	ldr	w0, [sp, #0x230]
    1130:      	neg	w0, w0
    1134:      	and	w0, w0, #0xff
    1138:      	str	w0, [sp, #0x234]
    113c:      	ldr	w0, [sp, #0x230]
    1140:      	cmp	w0, #0x0
    1144:      	cset	w0, ne
    1148:      	and	w0, w0, #0xff
    114c:      	str	w0, [sp, #0x238]
    1150:      	ldr	w1, [sp, #0x218]
    1154:      	ldr	w0, [sp, #0x238]
    1158:      	add	w0, w1, w0
    115c:      	str	w0, [sp, #0x23c]
    1160:      	ldr	w0, [sp, #0x23c]
    1164:      	neg	w0, w0
    1168:      	and	w0, w0, #0xff
    116c:      	str	w0, [sp, #0x240]
    1170:      	ldr	w0, [sp, #0x1fc]
    1174:      	lsr	w1, w0, #1
    1178:      	ldr	w0, [sp, #0x200]
    117c:      	lsl	w0, w0, #7
    1180:      	orr	w0, w1, w0
    1184:      	and	w0, w0, #0xff
    1188:      	str	w0, [sp, #0x244]
    118c:      	ldr	w0, [sp, #0x200]
    1190:      	lsr	w1, w0, #1
    1194:      	ldr	w0, [sp, #0x204]
    1198:      	lsl	w0, w0, #7
    119c:      	orr	w0, w1, w0
    11a0:      	and	w0, w0, #0xff
    11a4:      	str	w0, [sp, #0x248]
    11a8:      	ldr	w0, [sp, #0x204]
    11ac:      	lsr	w1, w0, #1
    11b0:      	ldr	w0, [sp, #0x208]
    11b4:      	lsl	w0, w0, #7
    11b8:      	orr	w0, w1, w0
    11bc:      	and	w0, w0, #0xff
    11c0:      	str	w0, [sp, #0x24c]
    11c4:      	ldr	w0, [sp, #0x208]
    11c8:      	lsr	w0, w0, #1
    11cc:      	and	w0, w0, #0xff
    11d0:      	str	w0, [sp, #0x250]
    11d4:      	ldr	w0, [sp, #0x21c]
    11d8:      	and	w0, w0, #0x20
    11dc:      	str	w0, [sp, #0x254]
    11e0:      	ldr	w1, [sp, #0x228]
    11e4:      	mov	w0, #0x83               // =131
    11e8:      	and	w0, w1, w0
    11ec:      	str	w0, [sp, #0x258]
    11f0:      	ldr	w1, [sp, #0x234]
    11f4:      	mov	w0, #0xb8               // =184
    11f8:      	and	w0, w1, w0
    11fc:      	str	w0, [sp, #0x25c]
    1200:      	ldr	w1, [sp, #0x240]
    1204:      	mov	w0, #0xed               // =237
    1208:      	and	w0, w1, w0
    120c:      	str	w0, [sp, #0x260]
    1210:      	ldr	w1, [sp, #0x244]
    1214:      	ldr	w0, [sp, #0x254]
    1218:      	eor	w0, w1, w0
    121c:      	str	w0, [sp, #0x264]
    1220:      	ldr	w1, [sp, #0x248]
    1224:      	ldr	w0, [sp, #0x258]
    1228:      	eor	w0, w1, w0
    122c:      	str	w0, [sp, #0x268]
    1230:      	ldr	w1, [sp, #0x24c]
    1234:      	ldr	w0, [sp, #0x25c]
    1238:      	eor	w0, w1, w0
    123c:      	str	w0, [sp, #0x26c]
    1240:      	ldr	w1, [sp, #0x250]
    1244:      	ldr	w0, [sp, #0x260]
    1248:      	eor	w0, w1, w0
    124c:      	str	w0, [sp, #0x270]
    1250:      	ldr	w0, [sp, #0x264]
    1254:      	and	w0, w0, #0x1
    1258:      	str	w0, [sp, #0x274]
    125c:      	str	wzr, [sp, #0x278]
    1260:      	str	wzr, [sp, #0x27c]
    1264:      	str	wzr, [sp, #0x280]
    1268:      	ldr	w0, [sp, #0x274]
    126c:      	neg	w0, w0
    1270:      	and	w0, w0, #0xff
    1274:      	str	w0, [sp, #0x284]
    1278:      	ldr	w0, [sp, #0x274]
    127c:      	cmp	w0, #0x0
    1280:      	cset	w0, ne
    1284:      	and	w0, w0, #0xff
    1288:      	str	w0, [sp, #0x288]
    128c:      	ldr	w1, [sp, #0x278]
    1290:      	ldr	w0, [sp, #0x288]
    1294:      	add	w0, w1, w0
    1298:      	str	w0, [sp, #0x28c]
    129c:      	ldr	w0, [sp, #0x28c]
    12a0:      	neg	w0, w0
    12a4:      	and	w0, w0, #0xff
    12a8:      	str	w0, [sp, #0x290]
    12ac:      	ldr	w0, [sp, #0x28c]
    12b0:      	cmp	w0, #0x0
    12b4:      	cset	w0, ne
    12b8:      	and	w0, w0, #0xff
    12bc:      	str	w0, [sp, #0x294]
    12c0:      	ldr	w1, [sp, #0x27c]
    12c4:      	ldr	w0, [sp, #0x294]
    12c8:      	add	w0, w1, w0
    12cc:      	str	w0, [sp, #0x298]
    12d0:      	ldr	w0, [sp, #0x298]
    12d4:      	neg	w0, w0
    12d8:      	and	w0, w0, #0xff
    12dc:      	str	w0, [sp, #0x29c]
    12e0:      	ldr	w0, [sp, #0x298]
    12e4:      	cmp	w0, #0x0
    12e8:      	cset	w0, ne
    12ec:      	and	w0, w0, #0xff
    12f0:      	str	w0, [sp, #0x2a0]
    12f4:      	ldr	w1, [sp, #0x280]
    12f8:      	ldr	w0, [sp, #0x2a0]
    12fc:      	add	w0, w1, w0
    1300:      	str	w0, [sp, #0x2a4]
    1304:      	ldr	w0, [sp, #0x2a4]
    1308:      	neg	w0, w0
    130c:      	and	w0, w0, #0xff
    1310:      	str	w0, [sp, #0x2a8]
    1314:      	ldr	w0, [sp, #0x264]
    1318:      	lsr	w1, w0, #1
    131c:      	ldr	w0, [sp, #0x268]
    1320:      	lsl	w0, w0, #7
    1324:      	orr	w0, w1, w0
    1328:      	and	w0, w0, #0xff
    132c:      	str	w0, [sp, #0x2ac]
    1330:      	ldr	w0, [sp, #0x268]
    1334:      	lsr	w1, w0, #1
    1338:      	ldr	w0, [sp, #0x26c]
    133c:      	lsl	w0, w0, #7
    1340:      	orr	w0, w1, w0
    1344:      	and	w0, w0, #0xff
    1348:      	str	w0, [sp, #0x2b0]
    134c:      	ldr	w0, [sp, #0x26c]
    1350:      	lsr	w1, w0, #1
    1354:      	ldr	w0, [sp, #0x270]
    1358:      	lsl	w0, w0, #7
    135c:      	orr	w0, w1, w0
    1360:      	and	w0, w0, #0xff
    1364:      	str	w0, [sp, #0x2b4]
    1368:      	ldr	w0, [sp, #0x270]
    136c:      	lsr	w0, w0, #1
    1370:      	and	w0, w0, #0xff
    1374:      	str	w0, [sp, #0x2b8]
    1378:      	ldr	w0, [sp, #0x284]
    137c:      	and	w0, w0, #0x20
    1380:      	str	w0, [sp, #0x2bc]
    1384:      	ldr	w1, [sp, #0x290]
    1388:      	mov	w0, #0x83               // =131
    138c:      	and	w0, w1, w0
    1390:      	str	w0, [sp, #0x2c0]
    1394:      	ldr	w1, [sp, #0x29c]
    1398:      	mov	w0, #0xb8               // =184
    139c:      	and	w0, w1, w0
    13a0:      	str	w0, [sp, #0x2c4]
    13a4:      	ldr	w1, [sp, #0x2a8]
    13a8:      	mov	w0, #0xed               // =237
    13ac:      	and	w0, w1, w0
    13b0:      	str	w0, [sp, #0x2c8]
    13b4:      	ldr	w1, [sp, #0x2ac]
    13b8:      	ldr	w0, [sp, #0x2bc]
    13bc:      	eor	w0, w1, w0
    13c0:      	str	w0, [sp, #0x2cc]
    13c4:      	ldr	w1, [sp, #0x2b0]
    13c8:      	ldr	w0, [sp, #0x2c0]
    13cc:      	eor	w0, w1, w0
    13d0:      	str	w0, [sp, #0x2d0]
    13d4:      	ldr	w1, [sp, #0x2b4]
    13d8:      	ldr	w0, [sp, #0x2c4]
    13dc:      	eor	w0, w1, w0
    13e0:      	str	w0, [sp, #0x2d4]
    13e4:      	ldr	w1, [sp, #0x2b8]
    13e8:      	ldr	w0, [sp, #0x2c8]
    13ec:      	eor	w0, w1, w0
    13f0:      	str	w0, [sp, #0x2d8]
    13f4:      	ldr	w0, [sp, #0x2cc]
    13f8:      	and	w0, w0, #0x1
    13fc:      	str	w0, [sp, #0x2dc]
    1400:      	str	wzr, [sp, #0x2e0]
    1404:      	str	wzr, [sp, #0x2e4]
    1408:      	str	wzr, [sp, #0x2e8]
    140c:      	ldr	w0, [sp, #0x2dc]
    1410:      	neg	w0, w0
    1414:      	and	w0, w0, #0xff
    1418:      	str	w0, [sp, #0x2ec]
    141c:      	ldr	w0, [sp, #0x2dc]
    1420:      	cmp	w0, #0x0
    1424:      	cset	w0, ne
    1428:      	and	w0, w0, #0xff
    142c:      	str	w0, [sp, #0x2f0]
    1430:      	ldr	w1, [sp, #0x2e0]
    1434:      	ldr	w0, [sp, #0x2f0]
    1438:      	add	w0, w1, w0
    143c:      	str	w0, [sp, #0x2f4]
    1440:      	ldr	w0, [sp, #0x2f4]
    1444:      	neg	w0, w0
    1448:      	and	w0, w0, #0xff
    144c:      	str	w0, [sp, #0x2f8]
    1450:      	ldr	w0, [sp, #0x2f4]
    1454:      	cmp	w0, #0x0
    1458:      	cset	w0, ne
    145c:      	and	w0, w0, #0xff
    1460:      	str	w0, [sp, #0x2fc]
    1464:      	ldr	w1, [sp, #0x2e4]
    1468:      	ldr	w0, [sp, #0x2fc]
    146c:      	add	w0, w1, w0
    1470:      	str	w0, [sp, #0x300]
    1474:      	ldr	w0, [sp, #0x300]
    1478:      	neg	w0, w0
    147c:      	and	w0, w0, #0xff
    1480:      	str	w0, [sp, #0x304]
    1484:      	ldr	w0, [sp, #0x300]
    1488:      	cmp	w0, #0x0
    148c:      	cset	w0, ne
    1490:      	and	w0, w0, #0xff
    1494:      	str	w0, [sp, #0x308]
    1498:      	ldr	w1, [sp, #0x2e8]
    149c:      	ldr	w0, [sp, #0x308]
    14a0:      	add	w0, w1, w0
    14a4:      	str	w0, [sp, #0x30c]
    14a8:      	ldr	w0, [sp, #0x30c]
    14ac:      	neg	w0, w0
    14b0:      	and	w0, w0, #0xff
    14b4:      	str	w0, [sp, #0x310]
    14b8:      	ldr	w0, [sp, #0x2cc]
    14bc:      	lsr	w1, w0, #1
    14c0:      	ldr	w0, [sp, #0x2d0]
    14c4:      	lsl	w0, w0, #7
    14c8:      	orr	w0, w1, w0
    14cc:      	and	w0, w0, #0xff
    14d0:      	str	w0, [sp, #0x314]
    14d4:      	ldr	w0, [sp, #0x2d0]
    14d8:      	lsr	w1, w0, #1
    14dc:      	ldr	w0, [sp, #0x2d4]
    14e0:      	lsl	w0, w0, #7
    14e4:      	orr	w0, w1, w0
    14e8:      	and	w0, w0, #0xff
    14ec:      	str	w0, [sp, #0x318]
    14f0:      	ldr	w0, [sp, #0x2d4]
    14f4:      	lsr	w1, w0, #1
    14f8:      	ldr	w0, [sp, #0x2d8]
    14fc:      	lsl	w0, w0, #7
    1500:      	orr	w0, w1, w0
    1504:      	and	w0, w0, #0xff
    1508:      	str	w0, [sp, #0x31c]
    150c:      	ldr	w0, [sp, #0x2d8]
    1510:      	lsr	w0, w0, #1
    1514:      	and	w0, w0, #0xff
    1518:      	str	w0, [sp, #0x320]
    151c:      	ldr	w0, [sp, #0x2ec]
    1520:      	and	w0, w0, #0x20
    1524:      	str	w0, [sp, #0x324]
    1528:      	ldr	w1, [sp, #0x2f8]
    152c:      	mov	w0, #0x83               // =131
    1530:      	and	w0, w1, w0
    1534:      	str	w0, [sp, #0x328]
    1538:      	ldr	w1, [sp, #0x304]
    153c:      	mov	w0, #0xb8               // =184
    1540:      	and	w0, w1, w0
    1544:      	str	w0, [sp, #0x32c]
    1548:      	ldr	w1, [sp, #0x310]
    154c:      	mov	w0, #0xed               // =237
    1550:      	and	w0, w1, w0
    1554:      	str	w0, [sp, #0x330]
    1558:      	ldr	w1, [sp, #0x314]
    155c:      	ldr	w0, [sp, #0x324]
    1560:      	eor	w0, w1, w0
    1564:      	str	w0, [sp, #0x334]
    1568:      	ldr	w1, [sp, #0x318]
    156c:      	ldr	w0, [sp, #0x328]
    1570:      	eor	w0, w1, w0
    1574:      	str	w0, [sp, #0x338]
    1578:      	ldr	w1, [sp, #0x31c]
    157c:      	ldr	w0, [sp, #0x32c]
    1580:      	eor	w0, w1, w0
    1584:      	str	w0, [sp, #0x33c]
    1588:      	ldr	w1, [sp, #0x320]
    158c:      	ldr	w0, [sp, #0x330]
    1590:      	eor	w0, w1, w0
    1594:      	str	w0, [sp, #0x340]
    1598:      	ldr	w0, [sp, #0x334]
    159c:      	and	w0, w0, #0x1
    15a0:      	str	w0, [sp, #0x344]
    15a4:      	str	wzr, [sp, #0x348]
    15a8:      	str	wzr, [sp, #0x34c]
    15ac:      	str	wzr, [sp, #0x350]
    15b0:      	ldr	w0, [sp, #0x344]
    15b4:      	neg	w0, w0
    15b8:      	and	w0, w0, #0xff
    15bc:      	str	w0, [sp, #0x354]
    15c0:      	ldr	w0, [sp, #0x344]
    15c4:      	cmp	w0, #0x0
    15c8:      	cset	w0, ne
    15cc:      	and	w0, w0, #0xff
    15d0:      	str	w0, [sp, #0x358]
    15d4:      	ldr	w1, [sp, #0x348]
    15d8:      	ldr	w0, [sp, #0x358]
    15dc:      	add	w0, w1, w0
    15e0:      	str	w0, [sp, #0x35c]
    15e4:      	ldr	w0, [sp, #0x35c]
    15e8:      	neg	w0, w0
    15ec:      	and	w0, w0, #0xff
    15f0:      	str	w0, [sp, #0x360]
    15f4:      	ldr	w0, [sp, #0x35c]
    15f8:      	cmp	w0, #0x0
    15fc:      	cset	w0, ne
    1600:      	and	w0, w0, #0xff
    1604:      	str	w0, [sp, #0x364]
    1608:      	ldr	w1, [sp, #0x34c]
    160c:      	ldr	w0, [sp, #0x364]
    1610:      	add	w0, w1, w0
    1614:      	str	w0, [sp, #0x368]
    1618:      	ldr	w0, [sp, #0x368]
    161c:      	neg	w0, w0
    1620:      	and	w0, w0, #0xff
    1624:      	str	w0, [sp, #0x36c]
    1628:      	ldr	w0, [sp, #0x368]
    162c:      	cmp	w0, #0x0
    1630:      	cset	w0, ne
    1634:      	and	w0, w0, #0xff
    1638:      	str	w0, [sp, #0x370]
    163c:      	ldr	w1, [sp, #0x350]
    1640:      	ldr	w0, [sp, #0x370]
    1644:      	add	w0, w1, w0
    1648:      	str	w0, [sp, #0x374]
    164c:      	ldr	w0, [sp, #0x374]
    1650:      	neg	w0, w0
    1654:      	and	w0, w0, #0xff
    1658:      	str	w0, [sp, #0x378]
    165c:      	ldr	w0, [sp, #0x334]
    1660:      	lsr	w1, w0, #1
    1664:      	ldr	w0, [sp, #0x338]
    1668:      	lsl	w0, w0, #7
    166c:      	orr	w0, w1, w0
    1670:      	and	w0, w0, #0xff
    1674:      	str	w0, [sp, #0x37c]
    1678:      	ldr	w0, [sp, #0x338]
    167c:      	lsr	w1, w0, #1
    1680:      	ldr	w0, [sp, #0x33c]
    1684:      	lsl	w0, w0, #7
    1688:      	orr	w0, w1, w0
    168c:      	and	w0, w0, #0xff
    1690:      	str	w0, [sp, #0x380]
    1694:      	ldr	w0, [sp, #0x33c]
    1698:      	lsr	w1, w0, #1
    169c:      	ldr	w0, [sp, #0x340]
    16a0:      	lsl	w0, w0, #7
    16a4:      	orr	w0, w1, w0
    16a8:      	and	w0, w0, #0xff
    16ac:      	str	w0, [sp, #0x384]
    16b0:      	ldr	w0, [sp, #0x340]
    16b4:      	lsr	w0, w0, #1
    16b8:      	and	w0, w0, #0xff
    16bc:      	str	w0, [sp, #0x388]
    16c0:      	ldr	w0, [sp, #0x354]
    16c4:      	and	w0, w0, #0x20
    16c8:      	str	w0, [sp, #0x38c]
    16cc:      	ldr	w1, [sp, #0x360]
    16d0:      	mov	w0, #0x83               // =131
    16d4:      	and	w0, w1, w0
    16d8:      	str	w0, [sp, #0x390]
    16dc:      	ldr	w1, [sp, #0x36c]
    16e0:      	mov	w0, #0xb8               // =184
    16e4:      	and	w0, w1, w0
    16e8:      	str	w0, [sp, #0x394]
    16ec:      	ldr	w1, [sp, #0x378]
    16f0:      	mov	w0, #0xed               // =237
    16f4:      	and	w0, w1, w0
    16f8:      	str	w0, [sp, #0x398]
    16fc:      	ldr	w1, [sp, #0x37c]
    1700:      	ldr	w0, [sp, #0x38c]
    1704:      	eor	w0, w1, w0
    1708:      	str	w0, [sp, #0x39c]
    170c:      	ldr	w1, [sp, #0x380]
    1710:      	ldr	w0, [sp, #0x390]
    1714:      	eor	w0, w1, w0
    1718:      	str	w0, [sp, #0x3a0]
    171c:      	ldr	w1, [sp, #0x384]
    1720:      	ldr	w0, [sp, #0x394]
    1724:      	eor	w0, w1, w0
    1728:      	str	w0, [sp, #0x3a4]
    172c:      	ldr	w1, [sp, #0x388]
    1730:      	ldr	w0, [sp, #0x398]
    1734:      	eor	w0, w1, w0
    1738:      	str	w0, [sp, #0x3a8]
    173c:      	ldr	w0, [sp, #0x39c]
    1740:      	eor	w0, w0, #0xff
    1744:      	str	w0, [sp, #0x3ac]
    1748:      	ldr	w0, [sp, #0x3a0]
    174c:      	eor	w0, w0, #0xff
    1750:      	str	w0, [sp, #0x3b0]
    1754:      	ldr	w0, [sp, #0x3a4]
    1758:      	eor	w0, w0, #0xff
    175c:      	str	w0, [sp, #0x3b4]
    1760:      	ldr	w0, [sp, #0x3a8]
    1764:      	eor	w0, w0, #0xff
    1768:      	str	w0, [sp, #0x3b8]
    176c:      	ldr	w0, [sp, #0x3b0]
    1770:      	lsl	w1, w0, #8
    1774:      	ldr	w0, [sp, #0x3ac]
    1778:      	orr	w1, w1, w0
    177c:      	ldr	w0, [sp, #0x3b4]
    1780:      	lsl	w0, w0, #16
    1784:      	orr	w1, w1, w0
    1788:      	ldr	w0, [sp, #0x3b8]
    178c:      	lsl	w0, w0, #24
    1790:      	orr	w0, w1, w0
    1794:      	str	w0, [sp, #0x3bc]
    1798:      	ldr	w0, [sp, #0x3bc]
    179c:      	add	sp, sp, #0x3c0
    17a0:      	ret

00000000000017a4 <csrd_matrix_next_value>:
    17a4:      	sub	sp, sp, #0x10
    17a8:      	str	x0, [sp, #0x8]
    17ac:      	ldr	x0, [sp, #0x8]
    17b0:      	ldr	w1, [x0]
    17b4:      	ldr	x0, [sp, #0x8]
    17b8:      	ldr	w0, [x0]
    17bc:      	lsl	w0, w0, #13
    17c0:      	eor	w1, w1, w0
    17c4:      	ldr	x0, [sp, #0x8]
    17c8:      	str	w1, [x0]
    17cc:      	ldr	x0, [sp, #0x8]
    17d0:      	ldr	w1, [x0]
    17d4:      	ldr	x0, [sp, #0x8]
    17d8:      	ldr	w0, [x0]
    17dc:      	lsr	w0, w0, #17
    17e0:      	eor	w1, w1, w0
    17e4:      	ldr	x0, [sp, #0x8]
    17e8:      	str	w1, [x0]
    17ec:      	ldr	x0, [sp, #0x8]
    17f0:      	ldr	w1, [x0]
    17f4:      	ldr	x0, [sp, #0x8]
    17f8:      	ldr	w0, [x0]
    17fc:      	lsl	w0, w0, #5
    1800:      	eor	w1, w1, w0
    1804:      	ldr	x0, [sp, #0x8]
    1808:      	str	w1, [x0]
    180c:      	ldr	x0, [sp, #0x8]
    1810:      	ldr	w0, [x0]
    1814:      	add	sp, sp, #0x10
    1818:      	ret

000000000000181c <main>:
    181c:      	sub	sp, sp, #0x80
    1820:      	stp	x29, x30, [sp, #0x70]
    1824:      	add	x29, sp, #0x70
    1828:      	str	w0, [sp, #0xc]
    182c:      	str	x1, [sp]
    1830:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1d450>
    1834:      	ldr	x0, [x0, #0xfe8]
    1838:      	ldr	x1, [x0]
    183c:      	str	x1, [sp, #0x68]
    1840:      	mov	x1, #0x0                // =0
    1844:      	ldr	w0, [sp, #0xc]
    1848:      	cmp	w0, #0x1
    184c:      	b.ne	0x18a0 <main+0x84>
    1850:      	b	0x1870 <main+0x54>
    1854:      	ldr	w0, [sp, #0x60]
    1858:      	ldr	w1, [sp, #0x64]
    185c:      	bl	0x918 <kernel>
    1860:      	mov	w1, w0
    1864:      	adrp	x0, 0x1000 <kernel+0x6e8>
    1868:      	add	x0, x0, #0xa50
    186c:      	bl	0x7f0 <printf@plt>
    1870:      	add	x0, sp, #0x60
    1874:      	add	x1, x0, #0x4
    1878:      	add	x0, sp, #0x60
    187c:      	mov	x2, x1
    1880:      	mov	x1, x0
    1884:      	adrp	x0, 0x1000 <kernel+0x6e8>
    1888:      	add	x0, x0, #0xa58
    188c:      	bl	0x7e0 <__isoc99_scanf@plt>
    1890:      	cmp	w0, #0x2
    1894:      	b.eq	0x1854 <main+0x38>
    1898:      	mov	w0, #0x0                // =0
    189c:      	b	0x1a00 <main+0x1e4>
    18a0:      	ldr	w0, [sp, #0xc]
    18a4:      	cmp	w0, #0x3
    18a8:      	b.eq	0x18b4 <main+0x98>
    18ac:      	mov	w0, #0x3                // =3
    18b0:      	b	0x1a00 <main+0x1e4>
    18b4:      	ldr	x0, [sp]
    18b8:      	add	x0, x0, #0x8
    18bc:      	ldr	x0, [x0]
    18c0:      	mov	w2, #0xa                // =10
    18c4:      	mov	x1, #0x0                // =0
    18c8:      	bl	0x770 <strtoul@plt>
    18cc:      	str	x0, [sp, #0x30]
    18d0:      	ldr	x0, [sp]
    18d4:      	add	x0, x0, #0x10
    18d8:      	ldr	x0, [x0]
    18dc:      	mov	w2, #0xa                // =10
    18e0:      	mov	x1, #0x0                // =0
    18e4:      	bl	0x770 <strtoul@plt>
    18e8:      	str	w0, [sp, #0x18]
    18ec:      	str	xzr, [sp, #0x20]
    18f0:      	add	x0, sp, #0x40
    18f4:      	mov	x1, x0
    18f8:      	mov	w0, #0x1                // =1
    18fc:      	bl	0x7a0 <clock_gettime@plt>
    1900:      	cmp	w0, #0x0
    1904:      	b.eq	0x1910 <main+0xf4>
    1908:      	mov	w0, #0x2                // =2
    190c:      	b	0x1a00 <main+0x1e4>
    1910:      	str	xzr, [sp, #0x28]
    1914:      	b	0x197c <main+0x160>
    1918:      	str	wzr, [sp, #0x1c]
    191c:      	b	0x1948 <main+0x12c>
    1920:      	add	x0, sp, #0x18
    1924:      	bl	0x17a4 <csrd_matrix_next_value>
    1928:      	mov	w2, w0
    192c:      	ldr	w0, [sp, #0x1c]
    1930:      	lsl	x0, x0, #2
    1934:      	add	x1, sp, #0x60
    1938:      	str	w2, [x1, x0]
    193c:      	ldr	w0, [sp, #0x1c]
    1940:      	add	w0, w0, #0x1
    1944:      	str	w0, [sp, #0x1c]
    1948:      	ldr	w0, [sp, #0x1c]
    194c:      	cmp	w0, #0x1
    1950:      	b.ls	0x1920 <main+0x104>
    1954:      	ldr	w0, [sp, #0x60]
    1958:      	ldr	w1, [sp, #0x64]
    195c:      	bl	0x918 <kernel>
    1960:      	mov	w0, w0
    1964:      	ldr	x1, [sp, #0x20]
    1968:      	add	x0, x1, x0
    196c:      	str	x0, [sp, #0x20]
    1970:      	ldr	x0, [sp, #0x28]
    1974:      	add	x0, x0, #0x1
    1978:      	str	x0, [sp, #0x28]
    197c:      	ldr	x1, [sp, #0x28]
    1980:      	ldr	x0, [sp, #0x30]
    1984:      	cmp	x1, x0
    1988:      	b.lo	0x1918 <main+0xfc>
    198c:      	add	x0, sp, #0x50
    1990:      	mov	x1, x0
    1994:      	mov	w0, #0x1                // =1
    1998:      	bl	0x7a0 <clock_gettime@plt>
    199c:      	cmp	w0, #0x0
    19a0:      	b.eq	0x19ac <main+0x190>
    19a4:      	mov	w0, #0x2                // =2
    19a8:      	b	0x1a00 <main+0x1e4>
    19ac:      	ldr	x1, [sp, #0x50]
    19b0:      	ldr	x0, [sp, #0x40]
    19b4:      	sub	x0, x1, x0
    19b8:      	fmov	d0, x0
    19bc:      	scvtf	d1, d0
    19c0:      	ldr	x1, [sp, #0x58]
    19c4:      	ldr	x0, [sp, #0x48]
    19c8:      	sub	x0, x1, x0
    19cc:      	fmov	d0, x0
    19d0:      	scvtf	d0, d0
    19d4:      	adrp	x0, 0x1000 <kernel+0x6e8>
    19d8:      	ldr	d2, [x0, #0xa70]
    19dc:      	fmul	d0, d0, d2
    19e0:      	fadd	d0, d1, d0
    19e4:      	str	d0, [sp, #0x38]
    19e8:      	ldr	x1, [sp, #0x20]
    19ec:      	ldr	d0, [sp, #0x38]
    19f0:      	adrp	x0, 0x1000 <kernel+0x6e8>
    19f4:      	add	x0, x0, #0xa60
    19f8:      	bl	0x7f0 <printf@plt>
    19fc:      	mov	w0, #0x0                // =0
    1a00:      	mov	w1, w0
    1a04:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1d450>
    1a08:      	ldr	x0, [x0, #0xfe8]
    1a0c:      	ldr	x3, [sp, #0x68]
    1a10:      	ldr	x2, [x0]
    1a14:      	subs	x3, x3, x2
    1a18:      	mov	x2, #0x0                // =0
    1a1c:      	b.eq	0x1a24 <main+0x208>
    1a20:      	bl	0x7b0 <__stack_chk_fail@plt>
    1a24:      	mov	w0, w1
    1a28:      	ldp	x29, x30, [sp, #0x70]
    1a2c:      	add	sp, sp, #0x80
    1a30:      	ret

Disassembly of section .fini:

0000000000001a34 <_fini>:
    1a34:      	nop
    1a38:      	stp	x29, x30, [sp, #-0x10]!
    1a3c:      	mov	x29, sp
    1a40:      	ldp	x29, x30, [sp], #0x10
    1a44:      	ret
