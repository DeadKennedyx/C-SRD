
/work/experiments/runs/positional-widths-comparison-20261110/matrix/crc32_byte/build-clang-Og-limbs8/program:	file format elf64-littleaarch64

Disassembly of section .init:

0000000000000678 <_init>:
     678:      	nop
     67c:      	stp	x29, x30, [sp, #-0x10]!
     680:      	mov	x29, sp
     684:      	bl	0x774 <call_weak_fn>
     688:      	ldp	x29, x30, [sp], #0x10
     68c:      	ret

Disassembly of section .plt:

0000000000000690 <.plt>:
     690:      	stp	x16, x30, [sp, #-0x10]!
     694:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e250>
     698:      	ldr	x17, [x16, #0xff8]
     69c:      	add	x16, x16, #0xff8
     6a0:      	br	x17
     6a4:      	nop
     6a8:      	nop
     6ac:      	nop

00000000000006b0 <strtoul@plt>:
     6b0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6b4:      	ldr	x17, [x16]
     6b8:      	add	x16, x16, #0x0
     6bc:      	br	x17

00000000000006c0 <__libc_start_main@plt>:
     6c0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6c4:      	ldr	x17, [x16, #0x8]
     6c8:      	add	x16, x16, #0x8
     6cc:      	br	x17

00000000000006d0 <__cxa_finalize@plt>:
     6d0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6d4:      	ldr	x17, [x16, #0x10]
     6d8:      	add	x16, x16, #0x10
     6dc:      	br	x17

00000000000006e0 <clock_gettime@plt>:
     6e0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6e4:      	ldr	x17, [x16, #0x18]
     6e8:      	add	x16, x16, #0x18
     6ec:      	br	x17

00000000000006f0 <__gmon_start__@plt>:
     6f0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6f4:      	ldr	x17, [x16, #0x20]
     6f8:      	add	x16, x16, #0x20
     6fc:      	br	x17

0000000000000700 <abort@plt>:
     700:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     704:      	ldr	x17, [x16, #0x28]
     708:      	add	x16, x16, #0x28
     70c:      	br	x17

0000000000000710 <__isoc99_scanf@plt>:
     710:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     714:      	ldr	x17, [x16, #0x30]
     718:      	add	x16, x16, #0x30
     71c:      	br	x17

0000000000000720 <printf@plt>:
     720:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     724:      	ldr	x17, [x16, #0x38]
     728:      	add	x16, x16, #0x38
     72c:      	br	x17

Disassembly of section .text:

0000000000000740 <_start>:
     740:      	nop
     744:      	mov	x29, #0x0               // =0
     748:      	mov	x30, #0x0               // =0
     74c:      	mov	x5, x0
     750:      	ldr	x1, [sp]
     754:      	add	x2, sp, #0x8
     758:      	mov	x6, sp
     75c:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e250>
     760:      	ldr	x0, [x0, #0xfd8]
     764:      	mov	x3, #0x0                // =0
     768:      	mov	x4, #0x0                // =0
     76c:      	bl	0x6c0 <__libc_start_main@plt>
     770:      	bl	0x700 <abort@plt>

0000000000000774 <call_weak_fn>:
     774:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e250>
     778:      	ldr	x0, [x0, #0xfd0]
     77c:      	cbz	x0, 0x784 <call_weak_fn+0x10>
     780:      	b	0x6f0 <__gmon_start__@plt>
     784:      	ret
     788:      	nop
     78c:      	nop

0000000000000790 <deregister_tm_clones>:
     790:      	adrp	x0, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     794:      	add	x0, x0, #0x50
     798:      	adrp	x1, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     79c:      	add	x1, x1, #0x50
     7a0:      	cmp	x1, x0
     7a4:      	b.eq	0x7bc <deregister_tm_clones+0x2c>
     7a8:      	adrp	x1, 0x1f000 <__FRAME_END__+0x1e250>
     7ac:      	ldr	x1, [x1, #0xfc0]
     7b0:      	cbz	x1, 0x7bc <deregister_tm_clones+0x2c>
     7b4:      	mov	x16, x1
     7b8:      	br	x16
     7bc:      	ret

00000000000007c0 <register_tm_clones>:
     7c0:      	adrp	x0, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     7c4:      	add	x0, x0, #0x50
     7c8:      	adrp	x1, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     7cc:      	add	x1, x1, #0x50
     7d0:      	sub	x1, x1, x0
     7d4:      	lsr	x2, x1, #63
     7d8:      	add	x1, x2, x1, asr #3
     7dc:      	asr	x1, x1, #1
     7e0:      	cbz	x1, 0x7f8 <register_tm_clones+0x38>
     7e4:      	adrp	x2, 0x1f000 <__FRAME_END__+0x1e250>
     7e8:      	ldr	x2, [x2, #0xfe0]
     7ec:      	cbz	x2, 0x7f8 <register_tm_clones+0x38>
     7f0:      	mov	x16, x2
     7f4:      	br	x16
     7f8:      	ret
     7fc:      	nop

0000000000000800 <__do_global_dtors_aux>:
     800:      	paciasp
     804:      	stp	x29, x30, [sp, #-0x20]!
     808:      	mov	x29, sp
     80c:      	str	x19, [sp, #0x10]
     810:      	adrp	x19, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     814:      	ldrb	w0, [x19, #0x50]
     818:      	tbnz	w0, #0x0, 0x840 <__do_global_dtors_aux+0x40>
     81c:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e250>
     820:      	ldr	x0, [x0, #0xfc8]
     824:      	cbz	x0, 0x834 <__do_global_dtors_aux+0x34>
     828:      	adrp	x0, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     82c:      	ldr	x0, [x0, #0x48]
     830:      	bl	0x6d0 <__cxa_finalize@plt>
     834:      	bl	0x790 <deregister_tm_clones>
     838:      	mov	w0, #0x1                // =1
     83c:      	strb	w0, [x19, #0x50]
     840:      	ldr	x19, [sp, #0x10]
     844:      	ldp	x29, x30, [sp], #0x20
     848:      	autiasp
     84c:      	ret

0000000000000850 <frame_dummy>:
     850:      	bti	c
     854:      	b	0x7c0 <register_tm_clones>

0000000000000858 <kernel>:
     858:      	mov	w9, #-0x1               // =-1
     85c:      	eon	w11, w0, w1
     860:      	mov	w8, #0x83               // =131
     864:      	eor	w10, w9, w0, lsr #8
     868:      	eor	w12, w9, w0, lsr #16
     86c:      	and	w13, w11, #0xff
     870:      	sbfx	w13, w13, #0, #1
     874:      	mvn	w16, w0
     878:      	ubfiz	w17, w11, #5, #1
     87c:      	ubfx	w14, w10, #1, #7
     880:      	ubfiz	w15, w10, #7, #1
     884:      	lsr	w0, w16, #17
     888:      	and	w18, w13, w8
     88c:      	lsl	w1, w11, #4
     890:      	sbfx	w2, w11, #1, #1
     894:      	bfi	w14, w12, #7, #1
     898:      	bfxil	w15, w11, #1, #7
     89c:      	and	w11, w0, #0x80
     8a0:      	mov	w9, #0xb8               // =184
     8a4:      	mov	w10, #0xed              // =237
     8a8:      	and	w1, w1, #0x20
     8ac:      	eor	w14, w18, w14
     8b0:      	eor	w15, w15, w17
     8b4:      	lsr	w18, w12, #1
     8b8:      	lsr	w17, w14, #1
     8bc:      	lsr	w0, w15, #1
     8c0:      	bfxil	w11, w12, #1, #7
     8c4:      	and	w3, w13, w9
     8c8:      	and	w13, w13, w10
     8cc:      	lsr	w12, w12, #3
     8d0:      	bfi	w17, w18, #7, #1
     8d4:      	bfi	w0, w14, #7, #1
     8d8:      	and	w18, w2, w8
     8dc:      	eor	w11, w3, w11
     8e0:      	eor	w13, w13, w16, lsr #25
     8e4:      	eor	w14, w17, w18
     8e8:      	eor	w18, w0, w1
     8ec:      	lsr	w17, w11, #1
     8f0:      	lsr	w16, w18, #1
     8f4:      	lsr	w0, w14, #1
     8f8:      	and	w1, w2, w10
     8fc:      	lsr	w11, w11, #3
     900:      	orr	w14, w16, w14, lsl #7
     904:      	orr	w0, w0, w17, lsl #7
     908:      	bfi	w17, w13, #7, #1
     90c:      	and	w16, w2, w9
     910:      	ubfx	w2, w15, #1, #1
     914:      	sbfx	w15, w15, #1, #1
     918:      	and	w14, w14, #0xfe
     91c:      	eor	w16, w17, w16
     920:      	eor	w13, w1, w13, lsr #1
     924:      	eor	w14, w14, w2, lsl #5
     928:      	lsr	w16, w16, #1
     92c:      	and	w17, w15, w8
     930:      	and	w0, w0, #0xff
     934:      	ubfx	w2, w18, #1, #1
     938:      	and	w1, w15, w9
     93c:      	eor	w17, w0, w17
     940:      	lsr	w0, w14, #1
     944:      	orr	w16, w16, w13, lsl #7
     948:      	lsr	w3, w17, #1
     94c:      	sbfx	w18, w18, #1, #1
     950:      	and	w15, w15, w10
     954:      	bfi	w0, w17, #7, #1
     958:      	and	w16, w16, #0xff
     95c:      	eor	w13, w15, w13, lsr #1
     960:      	bfi	w3, w12, #7, #1
     964:      	eor	w12, w16, w1
     968:      	and	w15, w18, w8
     96c:      	eor	w16, w0, w2, lsl #5
     970:      	lsr	w17, w12, #1
     974:      	and	w2, w18, w9
     978:      	eor	w15, w3, w15
     97c:      	sbfx	w3, w14, #1, #1
     980:      	ubfx	w14, w14, #1, #1
     984:      	lsr	w1, w16, #1
     988:      	lsr	w0, w15, #1
     98c:      	bfi	w17, w13, #7, #1
     990:      	ubfx	w13, w13, #1, #8
     994:      	and	w18, w18, w10
     998:      	lsr	w12, w12, #3
     99c:      	orr	w15, w1, w15, lsl #7
     9a0:      	bfi	w0, w11, #7, #1
     9a4:      	eor	w11, w17, w2
     9a8:      	lsr	w17, w11, #1
     9ac:      	eor	w13, w18, w13
     9b0:      	and	w1, w3, w8
     9b4:      	and	w15, w15, #0xfe
     9b8:      	eor	w18, w0, w1
     9bc:      	and	w0, w3, w9
     9c0:      	eor	w14, w15, w14, lsl #5
     9c4:      	mov	w15, w17
     9c8:      	and	w1, w3, w10
     9cc:      	bfi	w15, w13, #7, #1
     9d0:      	lsr	w3, w18, #1
     9d4:      	eor	w13, w1, w13, lsr #1
     9d8:      	lsr	w2, w14, #1
     9dc:      	lsr	w11, w11, #3
     9e0:      	eor	w15, w15, w0
     9e4:      	ubfx	w0, w16, #1, #1
     9e8:      	sbfx	w16, w16, #1, #1
     9ec:      	bfi	w2, w18, #7, #1
     9f0:      	lsr	w15, w15, #1
     9f4:      	orr	w17, w3, w17, lsl #7
     9f8:      	eor	w18, w2, w0, lsl #5
     9fc:      	orr	w15, w15, w13, lsl #7
     a00:      	and	w0, w16, w8
     a04:      	and	w17, w17, #0xff
     a08:      	and	w2, w16, w9
     a0c:      	and	w16, w16, w10
     a10:      	lsr	w1, w18, #1
     a14:      	eor	w17, w17, w0
     a18:      	and	w15, w15, #0xfc
     a1c:      	eor	w13, w16, w13, lsr #1
     a20:      	eor	w15, w15, w2
     a24:      	ubfx	w0, w14, #1, #1
     a28:      	orr	w16, w1, w17, lsl #7
     a2c:      	lsr	w17, w17, #1
     a30:      	lsr	w15, w15, #1
     a34:      	sbfx	w14, w14, #1, #1
     a38:      	and	w16, w16, #0xfe
     a3c:      	bfi	w17, w12, #7, #1
     a40:      	bfi	w15, w13, #7, #1
     a44:      	eor	w12, w16, w0, lsl #5
     a48:      	and	w16, w14, w8
     a4c:      	and	w0, w14, w9
     a50:      	eor	w16, w17, w16
     a54:      	ubfx	w13, w13, #1, #8
     a58:      	eor	w15, w15, w0
     a5c:      	lsr	w12, w12, #1
     a60:      	lsr	w0, w16, #1
     a64:      	and	w14, w14, w10
     a68:      	ubfx	w17, w18, #1, #1
     a6c:      	sbfx	w18, w18, #1, #1
     a70:      	lsr	w15, w15, #1
     a74:      	bfi	w12, w16, #7, #1
     a78:      	eor	w13, w14, w13
     a7c:      	bfi	w0, w11, #7, #1
     a80:      	bfi	w15, w13, #7, #1
     a84:      	and	w8, w18, w8
     a88:      	and	w9, w18, w9
     a8c:      	eor	w11, w12, w17, lsl #5
     a90:      	and	w10, w18, w10
     a94:      	eor	w8, w0, w8
     a98:      	eor	w9, w15, w9
     a9c:      	eon	w10, w10, w13, lsr #1
     aa0:      	orr	w8, w11, w8, lsl #8
     aa4:      	lsl	w9, w9, #16
     aa8:      	orr	w8, w8, w10, lsl #24
     aac:      	eor	w9, w9, #0xff0000
     ab0:      	orr	w8, w8, w9
     ab4:      	eor	w0, w8, #0xffff
     ab8:      	ret

0000000000000abc <main>:
     abc:      	sub	sp, sp, #0x60
     ac0:      	stp	x29, x30, [sp, #0x20]
     ac4:      	str	x23, [sp, #0x30]
     ac8:      	stp	x22, x21, [sp, #0x40]
     acc:      	stp	x20, x19, [sp, #0x50]
     ad0:      	add	x29, sp, #0x20
     ad4:      	cmp	w0, #0x3
     ad8:      	b.eq	0xb44 <main+0x88>
     adc:      	cmp	w0, #0x1
     ae0:      	b.ne	0xbd0 <main+0x114>
     ae4:      	add	x21, x29, #0x18
     ae8:      	adrp	x0, 0x0 <strtoul@GLIBC_2.17>
     aec:      	add	x0, x0, #0xc68
     af0:      	add	x1, x29, #0x18
     af4:      	add	x2, x21, #0x4
     af8:      	bl	0x710 <__isoc99_scanf@plt>
     afc:      	cmp	w0, #0x2
     b00:      	b.ne	0xc28 <main+0x16c>
     b04:      	adrp	x19, 0x0 <strtoul@GLIBC_2.17>
     b08:      	add	x19, x19, #0xc6d
     b0c:      	adrp	x20, 0x0 <strtoul@GLIBC_2.17>
     b10:      	add	x20, x20, #0xc68
     b14:      	ldp	w0, w1, [x29, #0x18]
     b18:      	bl	0x858 <kernel>
     b1c:      	mov	w1, w0
     b20:      	mov	x0, x19
     b24:      	bl	0x720 <printf@plt>
     b28:      	add	x1, x29, #0x18
     b2c:      	add	x2, x21, #0x4
     b30:      	mov	x0, x20
     b34:      	bl	0x710 <__isoc99_scanf@plt>
     b38:      	cmp	w0, #0x2
     b3c:      	b.eq	0xb14 <main+0x58>
     b40:      	b	0xc28 <main+0x16c>
     b44:      	ldr	x0, [x1, #0x8]
     b48:      	mov	x19, x1
     b4c:      	mov	x1, xzr
     b50:      	mov	w2, #0xa                // =10
     b54:      	bl	0x6b0 <strtoul@plt>
     b58:      	ldr	x8, [x19, #0x10]
     b5c:      	mov	x20, x0
     b60:      	mov	x1, xzr
     b64:      	mov	w2, #0xa                // =10
     b68:      	mov	x0, x8
     b6c:      	bl	0x6b0 <strtoul@plt>
     b70:      	mov	x21, x0
     b74:      	add	x1, sp, #0x10
     b78:      	mov	w0, #0x1                // =1
     b7c:      	bl	0x6e0 <clock_gettime@plt>
     b80:      	cbnz	w0, 0xbec <main+0x130>
     b84:      	cbz	x20, 0xbd8 <main+0x11c>
     b88:      	mov	x22, xzr
     b8c:      	mov	x19, xzr
     b90:      	add	x23, x29, #0x18
     b94:      	mov	x8, xzr
     b98:      	eor	w9, w21, w21, lsl #13
     b9c:      	eor	w9, w9, w9, lsr #17
     ba0:      	eor	w21, w9, w9, lsl #5
     ba4:      	str	w21, [x23, x8]
     ba8:      	add	x8, x8, #0x4
     bac:      	cmp	x8, #0x4
     bb0:      	b.eq	0xb98 <main+0xdc>
     bb4:      	ldp	w0, w1, [x29, #0x18]
     bb8:      	bl	0x858 <kernel>
     bbc:      	add	x22, x22, #0x1
     bc0:      	add	x19, x19, w0, uxtw
     bc4:      	cmp	x22, x20
     bc8:      	b.ne	0xb94 <main+0xd8>
     bcc:      	b	0xbdc <main+0x120>
     bd0:      	mov	w0, #0x3                // =3
     bd4:      	b	0xc2c <main+0x170>
     bd8:      	mov	x19, xzr
     bdc:      	mov	x1, sp
     be0:      	mov	w0, #0x1                // =1
     be4:      	bl	0x6e0 <clock_gettime@plt>
     be8:      	cbz	w0, 0xbf4 <main+0x138>
     bec:      	mov	w0, #0x2                // =2
     bf0:      	b	0xc2c <main+0x170>
     bf4:      	ldp	x8, x9, [sp]
     bf8:      	adrp	x0, 0x0 <strtoul@GLIBC_2.17>
     bfc:      	add	x0, x0, #0xc71
     c00:      	ldp	x10, x11, [sp, #0x10]
     c04:      	mov	x1, x19
     c08:      	sub	x8, x8, x10
     c0c:      	sub	x9, x9, x11
     c10:      	scvtf	d0, x8
     c14:      	scvtf	d1, x9
     c18:      	adrp	x8, 0x0 <strtoul@GLIBC_2.17>
     c1c:      	ldr	d2, [x8, #0xc60]
     c20:      	fmadd	d0, d1, d2, d0
     c24:      	bl	0x720 <printf@plt>
     c28:      	mov	w0, wzr
     c2c:      	ldp	x20, x19, [sp, #0x50]
     c30:      	ldr	x23, [sp, #0x30]
     c34:      	ldp	x22, x21, [sp, #0x40]
     c38:      	ldp	x29, x30, [sp, #0x20]
     c3c:      	add	sp, sp, #0x60
     c40:      	ret

Disassembly of section .fini:

0000000000000c44 <_fini>:
     c44:      	nop
     c48:      	stp	x29, x30, [sp, #-0x10]!
     c4c:      	mov	x29, sp
     c50:      	ldp	x29, x30, [sp], #0x10
     c54:      	ret
