
/work/experiments/runs/positional-widths-comparison-20261110/matrix/crc32_byte/build-clang-O2-original/program:	file format elf64-littleaarch64

Disassembly of section .init:

0000000000000678 <_init>:
     678:      	nop
     67c:      	stp	x29, x30, [sp, #-0x10]!
     680:      	mov	x29, sp
     684:      	bl	0x774 <call_weak_fn>
     688:      	ldp	x29, x30, [sp], #0x10
     68c:      	ret

Disassembly of section .plt:

0000000000000690 <.plt>:
     690:      	stp	x16, x30, [sp, #-0x10]!
     694:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e428>
     698:      	ldr	x17, [x16, #0xff8]
     69c:      	add	x16, x16, #0xff8
     6a0:      	br	x17
     6a4:      	nop
     6a8:      	nop
     6ac:      	nop

00000000000006b0 <strtoul@plt>:
     6b0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6b4:      	ldr	x17, [x16]
     6b8:      	add	x16, x16, #0x0
     6bc:      	br	x17

00000000000006c0 <__libc_start_main@plt>:
     6c0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6c4:      	ldr	x17, [x16, #0x8]
     6c8:      	add	x16, x16, #0x8
     6cc:      	br	x17

00000000000006d0 <__cxa_finalize@plt>:
     6d0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6d4:      	ldr	x17, [x16, #0x10]
     6d8:      	add	x16, x16, #0x10
     6dc:      	br	x17

00000000000006e0 <clock_gettime@plt>:
     6e0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6e4:      	ldr	x17, [x16, #0x18]
     6e8:      	add	x16, x16, #0x18
     6ec:      	br	x17

00000000000006f0 <__gmon_start__@plt>:
     6f0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6f4:      	ldr	x17, [x16, #0x20]
     6f8:      	add	x16, x16, #0x20
     6fc:      	br	x17

0000000000000700 <abort@plt>:
     700:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     704:      	ldr	x17, [x16, #0x28]
     708:      	add	x16, x16, #0x28
     70c:      	br	x17

0000000000000710 <__isoc99_scanf@plt>:
     710:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     714:      	ldr	x17, [x16, #0x30]
     718:      	add	x16, x16, #0x30
     71c:      	br	x17

0000000000000720 <printf@plt>:
     720:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     724:      	ldr	x17, [x16, #0x38]
     728:      	add	x16, x16, #0x38
     72c:      	br	x17

Disassembly of section .text:

0000000000000740 <_start>:
     740:      	nop
     744:      	mov	x29, #0x0               // =0
     748:      	mov	x30, #0x0               // =0
     74c:      	mov	x5, x0
     750:      	ldr	x1, [sp]
     754:      	add	x2, sp, #0x8
     758:      	mov	x6, sp
     75c:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e428>
     760:      	ldr	x0, [x0, #0xfd8]
     764:      	mov	x3, #0x0                // =0
     768:      	mov	x4, #0x0                // =0
     76c:      	bl	0x6c0 <__libc_start_main@plt>
     770:      	bl	0x700 <abort@plt>

0000000000000774 <call_weak_fn>:
     774:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e428>
     778:      	ldr	x0, [x0, #0xfd0]
     77c:      	cbz	x0, 0x784 <call_weak_fn+0x10>
     780:      	b	0x6f0 <__gmon_start__@plt>
     784:      	ret
     788:      	nop
     78c:      	nop

0000000000000790 <deregister_tm_clones>:
     790:      	adrp	x0, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     794:      	add	x0, x0, #0x50
     798:      	adrp	x1, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     79c:      	add	x1, x1, #0x50
     7a0:      	cmp	x1, x0
     7a4:      	b.eq	0x7bc <deregister_tm_clones+0x2c>
     7a8:      	adrp	x1, 0x1f000 <__FRAME_END__+0x1e428>
     7ac:      	ldr	x1, [x1, #0xfc0]
     7b0:      	cbz	x1, 0x7bc <deregister_tm_clones+0x2c>
     7b4:      	mov	x16, x1
     7b8:      	br	x16
     7bc:      	ret

00000000000007c0 <register_tm_clones>:
     7c0:      	adrp	x0, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     7c4:      	add	x0, x0, #0x50
     7c8:      	adrp	x1, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     7cc:      	add	x1, x1, #0x50
     7d0:      	sub	x1, x1, x0
     7d4:      	lsr	x2, x1, #63
     7d8:      	add	x1, x2, x1, asr #3
     7dc:      	asr	x1, x1, #1
     7e0:      	cbz	x1, 0x7f8 <register_tm_clones+0x38>
     7e4:      	adrp	x2, 0x1f000 <__FRAME_END__+0x1e428>
     7e8:      	ldr	x2, [x2, #0xfe0]
     7ec:      	cbz	x2, 0x7f8 <register_tm_clones+0x38>
     7f0:      	mov	x16, x2
     7f4:      	br	x16
     7f8:      	ret
     7fc:      	nop

0000000000000800 <__do_global_dtors_aux>:
     800:      	paciasp
     804:      	stp	x29, x30, [sp, #-0x20]!
     808:      	mov	x29, sp
     80c:      	str	x19, [sp, #0x10]
     810:      	adrp	x19, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     814:      	ldrb	w0, [x19, #0x50]
     818:      	tbnz	w0, #0x0, 0x840 <__do_global_dtors_aux+0x40>
     81c:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e428>
     820:      	ldr	x0, [x0, #0xfc8]
     824:      	cbz	x0, 0x834 <__do_global_dtors_aux+0x34>
     828:      	adrp	x0, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     82c:      	ldr	x0, [x0, #0x48]
     830:      	bl	0x6d0 <__cxa_finalize@plt>
     834:      	bl	0x790 <deregister_tm_clones>
     838:      	mov	w0, #0x1                // =1
     83c:      	strb	w0, [x19, #0x50]
     840:      	ldr	x19, [sp, #0x10]
     844:      	ldp	x29, x30, [sp], #0x20
     848:      	autiasp
     84c:      	ret

0000000000000850 <frame_dummy>:
     850:      	bti	c
     854:      	b	0x7c0 <register_tm_clones>

0000000000000858 <kernel>:
     858:      	and	w9, w1, #0xff
     85c:      	adrp	x8, 0x0 <strtoul@GLIBC_2.17>
     860:      	mov	w10, #0x8320            // =33568
     864:      	eon	w9, w9, w0
     868:      	ldr	q1, [x8, #0xa70]
     86c:      	adrp	x8, 0x0 <strtoul@GLIBC_2.17>
     870:      	dup	v0.4s, w9
     874:      	movk	w10, #0xedb8, lsl #16
     878:      	lsl	w11, w9, #30
     87c:      	and	v0.16b, v0.16b, v1.16b
     880:      	ldr	q1, [x8, #0xa80]
     884:      	sbfx	w8, w9, #0, #1
     888:      	and	w8, w8, w10
     88c:      	cmeq	v0.4s, v0.4s, #0
     890:      	eor	w8, w8, w9, lsr #1
     894:      	and	w9, w10, w11, asr #31
     898:      	mov	w10, #0x4190            // =16784
     89c:      	mov	w11, #0x7cdf            // =31967
     8a0:      	eor	w9, w9, w8, lsr #1
     8a4:      	lsl	w8, w8, #26
     8a8:      	movk	w10, #0x76dc, lsl #16
     8ac:      	bic	v0.16b, v1.16b, v0.16b
     8b0:      	movk	w11, #0x1247, lsl #16
     8b4:      	tst	w9, #0x20
     8b8:      	and	w8, w10, w8, asr #31
     8bc:      	csinv	w10, w11, wzr, ne
     8c0:      	ext	v1.16b, v0.16b, v0.16b, #0x8
     8c4:      	eor	w9, w10, w9, lsr #6
     8c8:      	eor	v0.8b, v0.8b, v1.8b
     8cc:      	fmov	x11, d0
     8d0:      	lsr	x10, x11, #32
     8d4:      	eor	w8, w11, w8
     8d8:      	eor	w8, w8, w9
     8dc:      	eor	w0, w8, w10
     8e0:      	ret

00000000000008e4 <main>:
     8e4:      	sub	sp, sp, #0x50
     8e8:      	stp	x29, x30, [sp, #0x20]
     8ec:      	str	x21, [sp, #0x30]
     8f0:      	stp	x20, x19, [sp, #0x40]
     8f4:      	add	x29, sp, #0x20
     8f8:      	cmp	w0, #0x3
     8fc:      	b.eq	0x968 <main+0x84>
     900:      	cmp	w0, #0x1
     904:      	b.ne	0x9f4 <main+0x110>
     908:      	add	x21, sp, #0x10
     90c:      	adrp	x0, 0x0 <strtoul@GLIBC_2.17>
     910:      	add	x0, x0, #0xa98
     914:      	add	x1, sp, #0x10
     918:      	add	x2, x21, #0x4
     91c:      	bl	0x710 <__isoc99_scanf@plt>
     920:      	cmp	w0, #0x2
     924:      	b.ne	0xa30 <main+0x14c>
     928:      	adrp	x19, 0x0 <strtoul@GLIBC_2.17>
     92c:      	add	x19, x19, #0xa9d
     930:      	adrp	x20, 0x0 <strtoul@GLIBC_2.17>
     934:      	add	x20, x20, #0xa98
     938:      	ldp	w0, w1, [sp, #0x10]
     93c:      	bl	0x858 <kernel>
     940:      	mov	w1, w0
     944:      	mov	x0, x19
     948:      	bl	0x720 <printf@plt>
     94c:      	add	x1, sp, #0x10
     950:      	add	x2, x21, #0x4
     954:      	mov	x0, x20
     958:      	bl	0x710 <__isoc99_scanf@plt>
     95c:      	cmp	w0, #0x2
     960:      	b.eq	0x938 <main+0x54>
     964:      	b	0xa30 <main+0x14c>
     968:      	ldr	x0, [x1, #0x8]
     96c:      	mov	x19, x1
     970:      	mov	x1, xzr
     974:      	mov	w2, #0xa                // =10
     978:      	bl	0x6b0 <strtoul@plt>
     97c:      	ldr	x8, [x19, #0x10]
     980:      	mov	x20, x0
     984:      	mov	x1, xzr
     988:      	mov	w2, #0xa                // =10
     98c:      	mov	x0, x8
     990:      	bl	0x6b0 <strtoul@plt>
     994:      	mov	x21, x0
     998:      	add	x1, sp, #0x10
     99c:      	mov	w0, #0x1                // =1
     9a0:      	bl	0x6e0 <clock_gettime@plt>
     9a4:      	cbnz	w0, 0x9ec <main+0x108>
     9a8:      	mov	x19, xzr
     9ac:      	cbz	x20, 0x9dc <main+0xf8>
     9b0:      	eor	w8, w21, w21, lsl #13
     9b4:      	eor	w8, w8, w8, lsr #17
     9b8:      	eor	w0, w8, w8, lsl #5
     9bc:      	eor	w8, w0, w0, lsl #13
     9c0:      	eor	w8, w8, w8, lsr #17
     9c4:      	eor	w21, w8, w8, lsl #5
     9c8:      	mov	w1, w21
     9cc:      	bl	0x858 <kernel>
     9d0:      	add	x19, x19, w0, uxtw
     9d4:      	subs	x20, x20, #0x1
     9d8:      	b.ne	0x9b0 <main+0xcc>
     9dc:      	mov	x1, sp
     9e0:      	mov	w0, #0x1                // =1
     9e4:      	bl	0x6e0 <clock_gettime@plt>
     9e8:      	cbz	w0, 0x9fc <main+0x118>
     9ec:      	mov	w0, #0x2                // =2
     9f0:      	b	0xa34 <main+0x150>
     9f4:      	mov	w0, #0x3                // =3
     9f8:      	b	0xa34 <main+0x150>
     9fc:      	ldp	x8, x9, [sp]
     a00:      	adrp	x0, 0x0 <strtoul@GLIBC_2.17>
     a04:      	add	x0, x0, #0xaa1
     a08:      	ldp	x10, x11, [sp, #0x10]
     a0c:      	mov	x1, x19
     a10:      	sub	x8, x8, x10
     a14:      	sub	x9, x9, x11
     a18:      	scvtf	d0, x8
     a1c:      	scvtf	d1, x9
     a20:      	adrp	x8, 0x0 <strtoul@GLIBC_2.17>
     a24:      	ldr	d2, [x8, #0xa90]
     a28:      	fmadd	d0, d1, d2, d0
     a2c:      	bl	0x720 <printf@plt>
     a30:      	mov	w0, wzr
     a34:      	ldp	x20, x19, [sp, #0x40]
     a38:      	ldr	x21, [sp, #0x30]
     a3c:      	ldp	x29, x30, [sp, #0x20]
     a40:      	add	sp, sp, #0x50
     a44:      	ret

Disassembly of section .fini:

0000000000000a48 <_fini>:
     a48:      	nop
     a4c:      	stp	x29, x30, [sp, #-0x10]!
     a50:      	mov	x29, sp
     a54:      	ldp	x29, x30, [sp], #0x10
     a58:      	ret
