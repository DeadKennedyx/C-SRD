
/work/experiments/runs/positional-widths-comparison-20261110/matrix/crc32_byte/build-clang-O3-limbs16/program:	file format elf64-littleaarch64

Disassembly of section .init:

0000000000000678 <_init>:
     678:      	nop
     67c:      	stp	x29, x30, [sp, #-0x10]!
     680:      	mov	x29, sp
     684:      	bl	0x774 <call_weak_fn>
     688:      	ldp	x29, x30, [sp], #0x10
     68c:      	ret

Disassembly of section .plt:

0000000000000690 <.plt>:
     690:      	stp	x16, x30, [sp, #-0x10]!
     694:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e330>
     698:      	ldr	x17, [x16, #0xff8]
     69c:      	add	x16, x16, #0xff8
     6a0:      	br	x17
     6a4:      	nop
     6a8:      	nop
     6ac:      	nop

00000000000006b0 <strtoul@plt>:
     6b0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6b4:      	ldr	x17, [x16]
     6b8:      	add	x16, x16, #0x0
     6bc:      	br	x17

00000000000006c0 <__libc_start_main@plt>:
     6c0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6c4:      	ldr	x17, [x16, #0x8]
     6c8:      	add	x16, x16, #0x8
     6cc:      	br	x17

00000000000006d0 <__cxa_finalize@plt>:
     6d0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6d4:      	ldr	x17, [x16, #0x10]
     6d8:      	add	x16, x16, #0x10
     6dc:      	br	x17

00000000000006e0 <clock_gettime@plt>:
     6e0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6e4:      	ldr	x17, [x16, #0x18]
     6e8:      	add	x16, x16, #0x18
     6ec:      	br	x17

00000000000006f0 <__gmon_start__@plt>:
     6f0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6f4:      	ldr	x17, [x16, #0x20]
     6f8:      	add	x16, x16, #0x20
     6fc:      	br	x17

0000000000000700 <abort@plt>:
     700:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     704:      	ldr	x17, [x16, #0x28]
     708:      	add	x16, x16, #0x28
     70c:      	br	x17

0000000000000710 <__isoc99_scanf@plt>:
     710:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     714:      	ldr	x17, [x16, #0x30]
     718:      	add	x16, x16, #0x30
     71c:      	br	x17

0000000000000720 <printf@plt>:
     720:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     724:      	ldr	x17, [x16, #0x38]
     728:      	add	x16, x16, #0x38
     72c:      	br	x17

Disassembly of section .text:

0000000000000740 <_start>:
     740:      	nop
     744:      	mov	x29, #0x0               // =0
     748:      	mov	x30, #0x0               // =0
     74c:      	mov	x5, x0
     750:      	ldr	x1, [sp]
     754:      	add	x2, sp, #0x8
     758:      	mov	x6, sp
     75c:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e330>
     760:      	ldr	x0, [x0, #0xfd8]
     764:      	mov	x3, #0x0                // =0
     768:      	mov	x4, #0x0                // =0
     76c:      	bl	0x6c0 <__libc_start_main@plt>
     770:      	bl	0x700 <abort@plt>

0000000000000774 <call_weak_fn>:
     774:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e330>
     778:      	ldr	x0, [x0, #0xfd0]
     77c:      	cbz	x0, 0x784 <call_weak_fn+0x10>
     780:      	b	0x6f0 <__gmon_start__@plt>
     784:      	ret
     788:      	nop
     78c:      	nop

0000000000000790 <deregister_tm_clones>:
     790:      	adrp	x0, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     794:      	add	x0, x0, #0x50
     798:      	adrp	x1, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     79c:      	add	x1, x1, #0x50
     7a0:      	cmp	x1, x0
     7a4:      	b.eq	0x7bc <deregister_tm_clones+0x2c>
     7a8:      	adrp	x1, 0x1f000 <__FRAME_END__+0x1e330>
     7ac:      	ldr	x1, [x1, #0xfc0]
     7b0:      	cbz	x1, 0x7bc <deregister_tm_clones+0x2c>
     7b4:      	mov	x16, x1
     7b8:      	br	x16
     7bc:      	ret

00000000000007c0 <register_tm_clones>:
     7c0:      	adrp	x0, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     7c4:      	add	x0, x0, #0x50
     7c8:      	adrp	x1, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     7cc:      	add	x1, x1, #0x50
     7d0:      	sub	x1, x1, x0
     7d4:      	lsr	x2, x1, #63
     7d8:      	add	x1, x2, x1, asr #3
     7dc:      	asr	x1, x1, #1
     7e0:      	cbz	x1, 0x7f8 <register_tm_clones+0x38>
     7e4:      	adrp	x2, 0x1f000 <__FRAME_END__+0x1e330>
     7e8:      	ldr	x2, [x2, #0xfe0]
     7ec:      	cbz	x2, 0x7f8 <register_tm_clones+0x38>
     7f0:      	mov	x16, x2
     7f4:      	br	x16
     7f8:      	ret
     7fc:      	nop

0000000000000800 <__do_global_dtors_aux>:
     800:      	paciasp
     804:      	stp	x29, x30, [sp, #-0x20]!
     808:      	mov	x29, sp
     80c:      	str	x19, [sp, #0x10]
     810:      	adrp	x19, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     814:      	ldrb	w0, [x19, #0x50]
     818:      	tbnz	w0, #0x0, 0x840 <__do_global_dtors_aux+0x40>
     81c:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e330>
     820:      	ldr	x0, [x0, #0xfc8]
     824:      	cbz	x0, 0x834 <__do_global_dtors_aux+0x34>
     828:      	adrp	x0, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     82c:      	ldr	x0, [x0, #0x48]
     830:      	bl	0x6d0 <__cxa_finalize@plt>
     834:      	bl	0x790 <deregister_tm_clones>
     838:      	mov	w0, #0x1                // =1
     83c:      	strb	w0, [x19, #0x50]
     840:      	ldr	x19, [sp, #0x10]
     844:      	ldp	x29, x30, [sp], #0x20
     848:      	autiasp
     84c:      	ret

0000000000000850 <frame_dummy>:
     850:      	bti	c
     854:      	b	0x7c0 <register_tm_clones>

0000000000000858 <kernel>:
     858:      	and	w8, w0, #0xffff
     85c:      	and	w9, w1, #0xff
     860:      	mov	w12, #0x10000           // =65536
     864:      	eor	w9, w8, w9
     868:      	mov	w8, #0x76dc             // =30428
     86c:      	mov	w11, #0x832             // =2098
     870:      	eor	w10, w9, #0xffff
     874:      	mvn	w16, w0
     878:      	bic	w12, w12, w0
     87c:      	sbfx	w14, w10, #0, #1
     880:      	lsr	w17, w16, #5
     884:      	orr	w12, w10, w12
     888:      	sbfx	w0, w10, #1, #1
     88c:      	mov	w13, #0x1064            // =4196
     890:      	mov	w9, #0xedb8             // =60856
     894:      	and	w18, w14, w8
     898:      	and	w11, w14, w11
     89c:      	mov	w15, #0x20c8            // =8392
     8a0:      	eor	w14, w18, w16, lsr #18
     8a4:      	eor	w12, w11, w12, lsr #5
     8a8:      	and	w16, w17, #0x1000
     8ac:      	sbfx	w17, w10, #2, #1
     8b0:      	and	w11, w0, w13
     8b4:      	and	w0, w0, w9
     8b8:      	lsl	w13, w14, #13
     8bc:      	orr	w16, w12, w16
     8c0:      	eor	w14, w14, w0
     8c4:      	and	w1, w17, w9
     8c8:      	eor	w11, w16, w11
     8cc:      	sbfx	w18, w10, #3, #1
     8d0:      	and	w16, w13, #0x2000
     8d4:      	and	w15, w17, w15
     8d8:      	eor	w17, w1, w14, lsr #1
     8dc:      	orr	w16, w16, w11
     8e0:      	mov	w0, #0x4190             // =16784
     8e4:      	and	w13, w13, #0x4000
     8e8:      	eor	w15, w16, w15
     8ec:      	and	w16, w18, w0
     8f0:      	lsr	w0, w17, #1
     8f4:      	orr	w13, w15, w13
     8f8:      	sbfx	w15, w10, #4, #1
     8fc:      	lsr	w14, w14, #3
     900:      	eor	w13, w13, w16
     904:      	mov	w16, #0x8320            // =33568
     908:      	sbfx	w10, w10, #5, #1
     90c:      	orr	w13, w13, w0, lsl #15
     910:      	and	w1, w15, w16
     914:      	sbfx	w12, w12, #1, #1
     918:      	and	w8, w10, w8
     91c:      	tst	w11, #0x4
     920:      	and	w13, w13, #0xfffc
     924:      	eor	w13, w13, w1
     928:      	lsr	w13, w13, #1
     92c:      	bfi	w13, w14, #15, #1
     930:      	and	w14, w10, w16
     934:      	lsl	w10, w11, #29
     938:      	mov	w11, #0x1247            // =4679
     93c:      	eor	w13, w13, w14
     940:      	lsr	w14, w17, #3
     944:      	mov	w17, #0x3b6e            // =15214
     948:      	lsr	w13, w13, #1
     94c:      	and	w15, w17, w15, lsr #2
     950:      	and	w17, w12, w16
     954:      	and	w10, w16, w10, asr #31
     958:      	bfi	w13, w14, #15, #1
     95c:      	and	w14, w18, w9
     960:      	and	w9, w12, w9
     964:      	eor	w14, w0, w14
     968:      	eor	w8, w8, w9
     96c:      	mov	w12, #0xffff            // =65535
     970:      	eor	w13, w13, w17
     974:      	eor	w14, w15, w14, lsr #3
     978:      	csel	w11, w12, w11, eq
     97c:      	lsr	w13, w13, #1
     980:      	eor	w8, w14, w8
     984:      	orr	w9, w13, w14, lsl #15
     988:      	eor	w8, w11, w8, lsr #1
     98c:      	and	w9, w9, #0xffff
     990:      	eor	w9, w9, w10
     994:      	orr	w8, w9, w8, lsl #16
     998:      	eor	w0, w8, #0xffff
     99c:      	ret

00000000000009a0 <main>:
     9a0:      	sub	sp, sp, #0x50
     9a4:      	stp	x29, x30, [sp, #0x20]
     9a8:      	str	x21, [sp, #0x30]
     9ac:      	stp	x20, x19, [sp, #0x40]
     9b0:      	add	x29, sp, #0x20
     9b4:      	cmp	w0, #0x3
     9b8:      	b.eq	0xa24 <main+0x84>
     9bc:      	cmp	w0, #0x1
     9c0:      	b.ne	0xa7c <main+0xdc>
     9c4:      	add	x21, sp, #0x10
     9c8:      	adrp	x0, 0x0 <strtoul@GLIBC_2.17>
     9cc:      	add	x0, x0, #0xb60
     9d0:      	add	x1, sp, #0x10
     9d4:      	add	x2, x21, #0x4
     9d8:      	bl	0x710 <__isoc99_scanf@plt>
     9dc:      	cmp	w0, #0x2
     9e0:      	b.ne	0xb24 <main+0x184>
     9e4:      	adrp	x19, 0x0 <strtoul@GLIBC_2.17>
     9e8:      	add	x19, x19, #0xb65
     9ec:      	adrp	x20, 0x0 <strtoul@GLIBC_2.17>
     9f0:      	add	x20, x20, #0xb60
     9f4:      	ldp	w0, w1, [sp, #0x10]
     9f8:      	bl	0x858 <kernel>
     9fc:      	mov	w1, w0
     a00:      	mov	x0, x19
     a04:      	bl	0x720 <printf@plt>
     a08:      	add	x1, sp, #0x10
     a0c:      	add	x2, x21, #0x4
     a10:      	mov	x0, x20
     a14:      	bl	0x710 <__isoc99_scanf@plt>
     a18:      	cmp	w0, #0x2
     a1c:      	b.eq	0x9f4 <main+0x54>
     a20:      	b	0xb24 <main+0x184>
     a24:      	ldr	x0, [x1, #0x8]
     a28:      	mov	x19, x1
     a2c:      	mov	x1, xzr
     a30:      	mov	w2, #0xa                // =10
     a34:      	bl	0x6b0 <strtoul@plt>
     a38:      	ldr	x8, [x19, #0x10]
     a3c:      	mov	x20, x0
     a40:      	mov	x1, xzr
     a44:      	mov	w2, #0xa                // =10
     a48:      	mov	x0, x8
     a4c:      	bl	0x6b0 <strtoul@plt>
     a50:      	mov	x21, x0
     a54:      	add	x1, sp, #0x10
     a58:      	mov	w0, #0x1                // =1
     a5c:      	bl	0x6e0 <clock_gettime@plt>
     a60:      	cbz	w0, 0xa94 <main+0xf4>
     a64:      	mov	w0, #0x2                // =2
     a68:      	ldp	x20, x19, [sp, #0x40]
     a6c:      	ldr	x21, [sp, #0x30]
     a70:      	ldp	x29, x30, [sp, #0x20]
     a74:      	add	sp, sp, #0x50
     a78:      	ret
     a7c:      	mov	w0, #0x3                // =3
     a80:      	ldp	x20, x19, [sp, #0x40]
     a84:      	ldr	x21, [sp, #0x30]
     a88:      	ldp	x29, x30, [sp, #0x20]
     a8c:      	add	sp, sp, #0x50
     a90:      	ret
     a94:      	mov	x19, xzr
     a98:      	cbz	x20, 0xac8 <main+0x128>
     a9c:      	eor	w8, w21, w21, lsl #13
     aa0:      	eor	w8, w8, w8, lsr #17
     aa4:      	eor	w0, w8, w8, lsl #5
     aa8:      	eor	w8, w0, w0, lsl #13
     aac:      	eor	w8, w8, w8, lsr #17
     ab0:      	eor	w21, w8, w8, lsl #5
     ab4:      	mov	w1, w21
     ab8:      	bl	0x858 <kernel>
     abc:      	add	x19, x19, w0, uxtw
     ac0:      	subs	x20, x20, #0x1
     ac4:      	b.ne	0xa9c <main+0xfc>
     ac8:      	mov	x1, sp
     acc:      	mov	w0, #0x1                // =1
     ad0:      	bl	0x6e0 <clock_gettime@plt>
     ad4:      	cbz	w0, 0xaf0 <main+0x150>
     ad8:      	mov	w0, #0x2                // =2
     adc:      	ldp	x20, x19, [sp, #0x40]
     ae0:      	ldr	x21, [sp, #0x30]
     ae4:      	ldp	x29, x30, [sp, #0x20]
     ae8:      	add	sp, sp, #0x50
     aec:      	ret
     af0:      	ldp	x8, x9, [sp]
     af4:      	adrp	x0, 0x0 <strtoul@GLIBC_2.17>
     af8:      	add	x0, x0, #0xb69
     afc:      	ldp	x10, x11, [sp, #0x10]
     b00:      	mov	x1, x19
     b04:      	sub	x8, x8, x10
     b08:      	sub	x9, x9, x11
     b0c:      	scvtf	d0, x8
     b10:      	scvtf	d1, x9
     b14:      	adrp	x8, 0x0 <strtoul@GLIBC_2.17>
     b18:      	ldr	d2, [x8, #0xb58]
     b1c:      	fmadd	d0, d1, d2, d0
     b20:      	bl	0x720 <printf@plt>
     b24:      	mov	w0, wzr
     b28:      	ldp	x20, x19, [sp, #0x40]
     b2c:      	ldr	x21, [sp, #0x30]
     b30:      	ldp	x29, x30, [sp, #0x20]
     b34:      	add	sp, sp, #0x50
     b38:      	ret

Disassembly of section .fini:

0000000000000b3c <_fini>:
     b3c:      	nop
     b40:      	stp	x29, x30, [sp, #-0x10]!
     b44:      	mov	x29, sp
     b48:      	ldp	x29, x30, [sp], #0x10
     b4c:      	ret
