
/work/experiments/runs/positional-widths-comparison-20261110/matrix/crc32_byte/build-clang-O0-original/program:	file format elf64-littleaarch64

Disassembly of section .init:

0000000000000678 <_init>:
     678:      	nop
     67c:      	stp	x29, x30, [sp, #-0x10]!
     680:      	mov	x29, sp
     684:      	bl	0x774 <call_weak_fn>
     688:      	ldp	x29, x30, [sp], #0x10
     68c:      	ret

Disassembly of section .plt:

0000000000000690 <.plt>:
     690:      	stp	x16, x30, [sp, #-0x10]!
     694:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e33c>
     698:      	ldr	x17, [x16, #0xff8]
     69c:      	add	x16, x16, #0xff8
     6a0:      	br	x17
     6a4:      	nop
     6a8:      	nop
     6ac:      	nop

00000000000006b0 <strtoul@plt>:
     6b0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6b4:      	ldr	x17, [x16]
     6b8:      	add	x16, x16, #0x0
     6bc:      	br	x17

00000000000006c0 <__libc_start_main@plt>:
     6c0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6c4:      	ldr	x17, [x16, #0x8]
     6c8:      	add	x16, x16, #0x8
     6cc:      	br	x17

00000000000006d0 <__cxa_finalize@plt>:
     6d0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6d4:      	ldr	x17, [x16, #0x10]
     6d8:      	add	x16, x16, #0x10
     6dc:      	br	x17

00000000000006e0 <clock_gettime@plt>:
     6e0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6e4:      	ldr	x17, [x16, #0x18]
     6e8:      	add	x16, x16, #0x18
     6ec:      	br	x17

00000000000006f0 <__gmon_start__@plt>:
     6f0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6f4:      	ldr	x17, [x16, #0x20]
     6f8:      	add	x16, x16, #0x20
     6fc:      	br	x17

0000000000000700 <abort@plt>:
     700:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     704:      	ldr	x17, [x16, #0x28]
     708:      	add	x16, x16, #0x28
     70c:      	br	x17

0000000000000710 <__isoc99_scanf@plt>:
     710:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     714:      	ldr	x17, [x16, #0x30]
     718:      	add	x16, x16, #0x30
     71c:      	br	x17

0000000000000720 <printf@plt>:
     720:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     724:      	ldr	x17, [x16, #0x38]
     728:      	add	x16, x16, #0x38
     72c:      	br	x17

Disassembly of section .text:

0000000000000740 <_start>:
     740:      	nop
     744:      	mov	x29, #0x0               // =0
     748:      	mov	x30, #0x0               // =0
     74c:      	mov	x5, x0
     750:      	ldr	x1, [sp]
     754:      	add	x2, sp, #0x8
     758:      	mov	x6, sp
     75c:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e33c>
     760:      	ldr	x0, [x0, #0xfd8]
     764:      	mov	x3, #0x0                // =0
     768:      	mov	x4, #0x0                // =0
     76c:      	bl	0x6c0 <__libc_start_main@plt>
     770:      	bl	0x700 <abort@plt>

0000000000000774 <call_weak_fn>:
     774:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e33c>
     778:      	ldr	x0, [x0, #0xfd0]
     77c:      	cbz	x0, 0x784 <call_weak_fn+0x10>
     780:      	b	0x6f0 <__gmon_start__@plt>
     784:      	ret
     788:      	nop
     78c:      	nop

0000000000000790 <deregister_tm_clones>:
     790:      	adrp	x0, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     794:      	add	x0, x0, #0x50
     798:      	adrp	x1, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     79c:      	add	x1, x1, #0x50
     7a0:      	cmp	x1, x0
     7a4:      	b.eq	0x7bc <deregister_tm_clones+0x2c>
     7a8:      	adrp	x1, 0x1f000 <__FRAME_END__+0x1e33c>
     7ac:      	ldr	x1, [x1, #0xfc0]
     7b0:      	cbz	x1, 0x7bc <deregister_tm_clones+0x2c>
     7b4:      	mov	x16, x1
     7b8:      	br	x16
     7bc:      	ret

00000000000007c0 <register_tm_clones>:
     7c0:      	adrp	x0, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     7c4:      	add	x0, x0, #0x50
     7c8:      	adrp	x1, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     7cc:      	add	x1, x1, #0x50
     7d0:      	sub	x1, x1, x0
     7d4:      	lsr	x2, x1, #63
     7d8:      	add	x1, x2, x1, asr #3
     7dc:      	asr	x1, x1, #1
     7e0:      	cbz	x1, 0x7f8 <register_tm_clones+0x38>
     7e4:      	adrp	x2, 0x1f000 <__FRAME_END__+0x1e33c>
     7e8:      	ldr	x2, [x2, #0xfe0]
     7ec:      	cbz	x2, 0x7f8 <register_tm_clones+0x38>
     7f0:      	mov	x16, x2
     7f4:      	br	x16
     7f8:      	ret
     7fc:      	nop

0000000000000800 <__do_global_dtors_aux>:
     800:      	paciasp
     804:      	stp	x29, x30, [sp, #-0x20]!
     808:      	mov	x29, sp
     80c:      	str	x19, [sp, #0x10]
     810:      	adrp	x19, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     814:      	ldrb	w0, [x19, #0x50]
     818:      	tbnz	w0, #0x0, 0x840 <__do_global_dtors_aux+0x40>
     81c:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e33c>
     820:      	ldr	x0, [x0, #0xfc8]
     824:      	cbz	x0, 0x834 <__do_global_dtors_aux+0x34>
     828:      	adrp	x0, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     82c:      	ldr	x0, [x0, #0x48]
     830:      	bl	0x6d0 <__cxa_finalize@plt>
     834:      	bl	0x790 <deregister_tm_clones>
     838:      	mov	w0, #0x1                // =1
     83c:      	strb	w0, [x19, #0x50]
     840:      	ldr	x19, [sp, #0x10]
     844:      	ldp	x29, x30, [sp], #0x20
     848:      	autiasp
     84c:      	ret

0000000000000850 <frame_dummy>:
     850:      	bti	c
     854:      	b	0x7c0 <register_tm_clones>

0000000000000858 <kernel>:
     858:      	sub	sp, sp, #0x20
     85c:      	str	w0, [sp, #0x1c]
     860:      	str	w1, [sp, #0x18]
     864:      	ldr	w8, [sp, #0x1c]
     868:      	ldrb	w9, [sp, #0x18]
     86c:      	eon	w8, w8, w9
     870:      	str	w8, [sp, #0x14]
     874:      	str	wzr, [sp, #0x10]
     878:      	str	wzr, [sp, #0xc]
     87c:      	b	0x880 <kernel+0x28>
     880:      	ldr	w8, [sp, #0xc]
     884:      	subs	w8, w8, #0x8
     888:      	b.hs	0x8d4 <kernel+0x7c>
     88c:      	b	0x890 <kernel+0x38>
     890:      	ldr	w8, [sp, #0x14]
     894:      	and	w9, w8, #0x1
     898:      	mov	w8, wzr
     89c:      	subs	w8, w8, w9
     8a0:      	str	w8, [sp, #0x10]
     8a4:      	ldr	w9, [sp, #0x14]
     8a8:      	ldr	w10, [sp, #0x10]
     8ac:      	mov	w8, #0x8320             // =33568
     8b0:      	movk	w8, #0xedb8, lsl #16
     8b4:      	and	w8, w8, w10
     8b8:      	eor	w8, w8, w9, lsr #1
     8bc:      	str	w8, [sp, #0x14]
     8c0:      	b	0x8c4 <kernel+0x6c>
     8c4:      	ldr	w8, [sp, #0xc]
     8c8:      	add	w8, w8, #0x1
     8cc:      	str	w8, [sp, #0xc]
     8d0:      	b	0x880 <kernel+0x28>
     8d4:      	ldr	w8, [sp, #0x14]
     8d8:      	mvn	w0, w8
     8dc:      	add	sp, sp, #0x20
     8e0:      	ret

00000000000008e4 <main>:
     8e4:      	sub	sp, sp, #0x90
     8e8:      	stp	x29, x30, [sp, #0x80]
     8ec:      	add	x29, sp, #0x80
     8f0:      	stur	wzr, [x29, #-0x4]
     8f4:      	stur	w0, [x29, #-0x8]
     8f8:      	stur	x1, [x29, #-0x10]
     8fc:      	ldur	w8, [x29, #-0x8]
     900:      	subs	w8, w8, #0x1
     904:      	b.ne	0x958 <main+0x74>
     908:      	b	0x90c <main+0x28>
     90c:      	b	0x910 <main+0x2c>
     910:      	sub	x1, x29, #0x18
     914:      	add	x2, x1, #0x4
     918:      	adrp	x0, 0x0 <strtoul@GLIBC_2.17>
     91c:      	add	x0, x0, #0xb60
     920:      	bl	0x710 <__isoc99_scanf@plt>
     924:      	subs	w8, w0, #0x2
     928:      	b.ne	0x950 <main+0x6c>
     92c:      	b	0x930 <main+0x4c>
     930:      	ldur	w0, [x29, #-0x18]
     934:      	ldur	w1, [x29, #-0x14]
     938:      	bl	0x858 <kernel>
     93c:      	mov	w1, w0
     940:      	adrp	x0, 0x0 <strtoul@GLIBC_2.17>
     944:      	add	x0, x0, #0xb65
     948:      	bl	0x720 <printf@plt>
     94c:      	b	0x910 <main+0x2c>
     950:      	stur	wzr, [x29, #-0x4]
     954:      	b	0xacc <main+0x1e8>
     958:      	ldur	w8, [x29, #-0x8]
     95c:      	subs	w8, w8, #0x3
     960:      	b.eq	0x974 <main+0x90>
     964:      	b	0x968 <main+0x84>
     968:      	mov	w8, #0x3                // =3
     96c:      	stur	w8, [x29, #-0x4]
     970:      	b	0xacc <main+0x1e8>
     974:      	ldur	x8, [x29, #-0x10]
     978:      	ldr	x0, [x8, #0x8]
     97c:      	mov	x1, xzr
     980:      	str	x1, [sp, #0x8]
     984:      	mov	w2, #0xa                // =10
     988:      	str	w2, [sp, #0x14]
     98c:      	bl	0x6b0 <strtoul@plt>
     990:      	ldr	x1, [sp, #0x8]
     994:      	ldr	w2, [sp, #0x14]
     998:      	stur	x0, [x29, #-0x20]
     99c:      	ldur	x8, [x29, #-0x10]
     9a0:      	ldr	x0, [x8, #0x10]
     9a4:      	bl	0x6b0 <strtoul@plt>
     9a8:      	mov	w8, w0
     9ac:      	stur	w8, [x29, #-0x24]
     9b0:      	stur	xzr, [x29, #-0x30]
     9b4:      	mov	w0, #0x1                // =1
     9b8:      	add	x1, sp, #0x40
     9bc:      	bl	0x6e0 <clock_gettime@plt>
     9c0:      	cbz	w0, 0x9d4 <main+0xf0>
     9c4:      	b	0x9c8 <main+0xe4>
     9c8:      	mov	w8, #0x2                // =2
     9cc:      	stur	w8, [x29, #-0x4]
     9d0:      	b	0xacc <main+0x1e8>
     9d4:      	str	xzr, [sp, #0x28]
     9d8:      	b	0x9dc <main+0xf8>
     9dc:      	ldr	x8, [sp, #0x28]
     9e0:      	ldur	x9, [x29, #-0x20]
     9e4:      	subs	x8, x8, x9
     9e8:      	b.hs	0xa60 <main+0x17c>
     9ec:      	b	0x9f0 <main+0x10c>
     9f0:      	str	wzr, [sp, #0x24]
     9f4:      	b	0x9f8 <main+0x114>
     9f8:      	ldr	w8, [sp, #0x24]
     9fc:      	subs	w8, w8, #0x2
     a00:      	b.hs	0xa34 <main+0x150>
     a04:      	b	0xa08 <main+0x124>
     a08:      	sub	x0, x29, #0x24
     a0c:      	bl	0xadc <csrd_matrix_next_value>
     a10:      	ldr	w8, [sp, #0x24]
     a14:      	mov	w9, w8
     a18:      	sub	x8, x29, #0x18
     a1c:      	str	w0, [x8, x9, lsl #2]
     a20:      	b	0xa24 <main+0x140>
     a24:      	ldr	w8, [sp, #0x24]
     a28:      	add	w8, w8, #0x1
     a2c:      	str	w8, [sp, #0x24]
     a30:      	b	0x9f8 <main+0x114>
     a34:      	ldur	w0, [x29, #-0x18]
     a38:      	ldur	w1, [x29, #-0x14]
     a3c:      	bl	0x858 <kernel>
     a40:      	ldur	x8, [x29, #-0x30]
     a44:      	add	x8, x8, w0, uxtw
     a48:      	stur	x8, [x29, #-0x30]
     a4c:      	b	0xa50 <main+0x16c>
     a50:      	ldr	x8, [sp, #0x28]
     a54:      	add	x8, x8, #0x1
     a58:      	str	x8, [sp, #0x28]
     a5c:      	b	0x9dc <main+0xf8>
     a60:      	mov	w0, #0x1                // =1
     a64:      	add	x1, sp, #0x30
     a68:      	bl	0x6e0 <clock_gettime@plt>
     a6c:      	cbz	w0, 0xa80 <main+0x19c>
     a70:      	b	0xa74 <main+0x190>
     a74:      	mov	w8, #0x2                // =2
     a78:      	stur	w8, [x29, #-0x4]
     a7c:      	b	0xacc <main+0x1e8>
     a80:      	ldr	x8, [sp, #0x30]
     a84:      	ldr	x9, [sp, #0x40]
     a88:      	subs	x8, x8, x9
     a8c:      	scvtf	d2, x8
     a90:      	ldr	x8, [sp, #0x38]
     a94:      	ldr	x9, [sp, #0x48]
     a98:      	subs	x8, x8, x9
     a9c:      	scvtf	d0, x8
     aa0:      	adrp	x8, 0x0 <strtoul@GLIBC_2.17>
     aa4:      	ldr	d1, [x8, #0xb58]
     aa8:      	fmadd	d0, d0, d1, d2
     aac:      	str	d0, [sp, #0x18]
     ab0:      	ldr	d0, [sp, #0x18]
     ab4:      	ldur	x1, [x29, #-0x30]
     ab8:      	adrp	x0, 0x0 <strtoul@GLIBC_2.17>
     abc:      	add	x0, x0, #0xb69
     ac0:      	bl	0x720 <printf@plt>
     ac4:      	stur	wzr, [x29, #-0x4]
     ac8:      	b	0xacc <main+0x1e8>
     acc:      	ldur	w0, [x29, #-0x4]
     ad0:      	ldp	x29, x30, [sp, #0x80]
     ad4:      	add	sp, sp, #0x90
     ad8:      	ret

0000000000000adc <csrd_matrix_next_value>:
     adc:      	sub	sp, sp, #0x10
     ae0:      	str	x0, [sp, #0x8]
     ae4:      	ldr	x8, [sp, #0x8]
     ae8:      	ldr	w10, [x8]
     aec:      	ldr	x9, [sp, #0x8]
     af0:      	ldr	w8, [x9]
     af4:      	eor	w8, w8, w10, lsl #13
     af8:      	str	w8, [x9]
     afc:      	ldr	x8, [sp, #0x8]
     b00:      	ldr	w10, [x8]
     b04:      	ldr	x9, [sp, #0x8]
     b08:      	ldr	w8, [x9]
     b0c:      	eor	w8, w8, w10, lsr #17
     b10:      	str	w8, [x9]
     b14:      	ldr	x8, [sp, #0x8]
     b18:      	ldr	w10, [x8]
     b1c:      	ldr	x9, [sp, #0x8]
     b20:      	ldr	w8, [x9]
     b24:      	eor	w8, w8, w10, lsl #5
     b28:      	str	w8, [x9]
     b2c:      	ldr	x8, [sp, #0x8]
     b30:      	ldr	w0, [x8]
     b34:      	add	sp, sp, #0x10
     b38:      	ret

Disassembly of section .fini:

0000000000000b3c <_fini>:
     b3c:      	nop
     b40:      	stp	x29, x30, [sp, #-0x10]!
     b44:      	mov	x29, sp
     b48:      	ldp	x29, x30, [sp], #0x10
     b4c:      	ret
