; ModuleID = '/work/experiments/runs/positional-widths-comparison-20261110/matrix/crc32_byte/build-clang-O3-thinlto-original/validation/compiler-0-O3/candidate.i'
source_filename = "/work/experiments/runs/positional-widths-comparison-20261110/matrix/crc32_byte/build-clang-O3-thinlto-original/validation/compiler-0-O3/candidate.i"
target datalayout = "e-m:e-i8:8:32-i16:16:32-i64:64-i128:128-n32:64-S128"
target triple = "aarch64-unknown-linux-gnu"

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local i32 @kernel(i32 noundef %0, i32 noundef %1) local_unnamed_addr #0 {
  %3 = and i32 %1, 255
  %4 = xor i32 %3, %0
  %5 = xor i32 %4, -1
  %6 = and i32 %5, 1
  %7 = lshr i32 %5, 1
  %8 = icmp eq i32 %6, 0
  %9 = select i1 %8, i32 0, i32 -306674912
  %10 = xor i32 %9, %7
  %11 = lshr i32 %10, 1
  %12 = and i32 %5, 2
  %13 = icmp eq i32 %12, 0
  %14 = select i1 %13, i32 0, i32 -306674912
  %15 = xor i32 %14, %11
  %16 = lshr i32 %15, 6
  %17 = and i32 %5, 4
  %18 = icmp eq i32 %17, 0
  %19 = select i1 %18, i32 0, i32 124634137
  %20 = xor i32 %19, %16
  %21 = and i32 %5, 8
  %22 = icmp eq i32 %21, 0
  %23 = select i1 %22, i32 0, i32 249268274
  %24 = xor i32 %23, %20
  %25 = and i32 %5, 16
  %26 = icmp eq i32 %25, 0
  %27 = select i1 %26, i32 0, i32 498536548
  %28 = xor i32 %27, %24
  %29 = and i32 %5, 32
  %30 = icmp eq i32 %29, 0
  %31 = select i1 %30, i32 0, i32 997073096
  %32 = xor i32 %31, %28
  %33 = and i32 %10, 32
  %34 = icmp eq i32 %33, 0
  %35 = select i1 %34, i32 0, i32 1994146192
  %36 = xor i32 %35, %32
  %37 = and i32 %15, 32
  %38 = icmp eq i32 %37, 0
  %39 = select i1 %38, i32 -1, i32 306674911
  %40 = xor i32 %39, %36
  ret i32 %40
}

attributes #0 = { mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable "frame-pointer"="non-leaf" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+fp-armv8,+neon,+outline-atomics,+v8a,-fmv" }

!llvm.module.flags = !{!0, !1, !2, !3, !4, !5}
!llvm.ident = !{!6}

!0 = !{i32 1, !"wchar_size", i32 4}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 1}
!5 = !{i32 1, !"EnableSplitLTOUnit", i32 0}
!6 = !{!"Ubuntu clang version 18.1.3 (1ubuntu1)"}

^0 = module: (path: "[Regular LTO]", hash: (0, 0, 0, 0, 0))
^1 = gv: (name: "kernel", summaries: (function: (module: ^0, flags: (linkage: external, visibility: default, notEligibleToImport: 0, live: 0, dsoLocal: 1, canAutoHide: 0), insts: 39, funcFlags: (readNone: 1, readOnly: 0, noRecurse: 1, returnDoesNotAlias: 0, noInline: 0, alwaysInline: 0, noUnwind: 1, mayThrow: 0, hasUnknownCall: 0, mustBeUnreachable: 0)))) ; guid = 17571550346185820240
^2 = blockcount: 0
