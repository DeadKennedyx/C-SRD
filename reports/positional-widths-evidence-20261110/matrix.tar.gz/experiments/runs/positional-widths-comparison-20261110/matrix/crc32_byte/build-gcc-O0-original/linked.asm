
/work/experiments/runs/positional-widths-comparison-20261110/matrix/crc32_byte/build-gcc-O0-original/program:	file format elf64-littleaarch64

Disassembly of section .init:

0000000000000730 <_init>:
     730:      	nop
     734:      	stp	x29, x30, [sp, #-0x10]!
     738:      	mov	x29, sp
     73c:      	bl	0x834 <call_weak_fn>
     740:      	ldp	x29, x30, [sp], #0x10
     744:      	ret

Disassembly of section .plt:

0000000000000750 <.plt>:
     750:      	stp	x16, x30, [sp, #-0x10]!
     754:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e258>
     758:      	ldr	x17, [x16, #0xf78]
     75c:      	add	x16, x16, #0xf78
     760:      	br	x17
     764:      	nop
     768:      	nop
     76c:      	nop

0000000000000770 <strtoul@plt>:
     770:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e258>
     774:      	ldr	x17, [x16, #0xf80]
     778:      	add	x16, x16, #0xf80
     77c:      	br	x17

0000000000000780 <__libc_start_main@plt>:
     780:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e258>
     784:      	ldr	x17, [x16, #0xf88]
     788:      	add	x16, x16, #0xf88
     78c:      	br	x17

0000000000000790 <__cxa_finalize@plt>:
     790:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e258>
     794:      	ldr	x17, [x16, #0xf90]
     798:      	add	x16, x16, #0xf90
     79c:      	br	x17

00000000000007a0 <clock_gettime@plt>:
     7a0:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e258>
     7a4:      	ldr	x17, [x16, #0xf98]
     7a8:      	add	x16, x16, #0xf98
     7ac:      	br	x17

00000000000007b0 <__stack_chk_fail@plt>:
     7b0:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e258>
     7b4:      	ldr	x17, [x16, #0xfa0]
     7b8:      	add	x16, x16, #0xfa0
     7bc:      	br	x17

00000000000007c0 <__gmon_start__@plt>:
     7c0:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e258>
     7c4:      	ldr	x17, [x16, #0xfa8]
     7c8:      	add	x16, x16, #0xfa8
     7cc:      	br	x17

00000000000007d0 <abort@plt>:
     7d0:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e258>
     7d4:      	ldr	x17, [x16, #0xfb0]
     7d8:      	add	x16, x16, #0xfb0
     7dc:      	br	x17

00000000000007e0 <__isoc99_scanf@plt>:
     7e0:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e258>
     7e4:      	ldr	x17, [x16, #0xfb8]
     7e8:      	add	x16, x16, #0xfb8
     7ec:      	br	x17

00000000000007f0 <printf@plt>:
     7f0:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e258>
     7f4:      	ldr	x17, [x16, #0xfc0]
     7f8:      	add	x16, x16, #0xfc0
     7fc:      	br	x17

Disassembly of section .text:

0000000000000800 <_start>:
     800:      	nop
     804:      	mov	x29, #0x0               // =0
     808:      	mov	x30, #0x0               // =0
     80c:      	mov	x5, x0
     810:      	ldr	x1, [sp]
     814:      	add	x2, sp, #0x8
     818:      	mov	x6, sp
     81c:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e258>
     820:      	ldr	x0, [x0, #0xff0]
     824:      	mov	x3, #0x0                // =0
     828:      	mov	x4, #0x0                // =0
     82c:      	bl	0x780 <__libc_start_main@plt>
     830:      	bl	0x7d0 <abort@plt>

0000000000000834 <call_weak_fn>:
     834:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e258>
     838:      	ldr	x0, [x0, #0xfe0]
     83c:      	cbz	x0, 0x844 <call_weak_fn+0x10>
     840:      	b	0x7c0 <__gmon_start__@plt>
     844:      	ret
     848:      	nop
     84c:      	nop

0000000000000850 <deregister_tm_clones>:
     850:      	adrp	x0, 0x20000 <data_start>
     854:      	add	x0, x0, #0x10
     858:      	adrp	x1, 0x20000 <data_start>
     85c:      	add	x1, x1, #0x10
     860:      	cmp	x1, x0
     864:      	b.eq	0x87c <deregister_tm_clones+0x2c>
     868:      	adrp	x1, 0x1f000 <__FRAME_END__+0x1e258>
     86c:      	ldr	x1, [x1, #0xfd0]
     870:      	cbz	x1, 0x87c <deregister_tm_clones+0x2c>
     874:      	mov	x16, x1
     878:      	br	x16
     87c:      	ret

0000000000000880 <register_tm_clones>:
     880:      	adrp	x0, 0x20000 <data_start>
     884:      	add	x0, x0, #0x10
     888:      	adrp	x1, 0x20000 <data_start>
     88c:      	add	x1, x1, #0x10
     890:      	sub	x1, x1, x0
     894:      	lsr	x2, x1, #63
     898:      	add	x1, x2, x1, asr #3
     89c:      	asr	x1, x1, #1
     8a0:      	cbz	x1, 0x8b8 <register_tm_clones+0x38>
     8a4:      	adrp	x2, 0x1f000 <__FRAME_END__+0x1e258>
     8a8:      	ldr	x2, [x2, #0xff8]
     8ac:      	cbz	x2, 0x8b8 <register_tm_clones+0x38>
     8b0:      	mov	x16, x2
     8b4:      	br	x16
     8b8:      	ret
     8bc:      	nop

00000000000008c0 <__do_global_dtors_aux>:
     8c0:      	paciasp
     8c4:      	stp	x29, x30, [sp, #-0x20]!
     8c8:      	mov	x29, sp
     8cc:      	str	x19, [sp, #0x10]
     8d0:      	adrp	x19, 0x20000 <data_start>
     8d4:      	ldrb	w0, [x19, #0x10]
     8d8:      	tbnz	w0, #0x0, 0x900 <__do_global_dtors_aux+0x40>
     8dc:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e258>
     8e0:      	ldr	x0, [x0, #0xfd8]
     8e4:      	cbz	x0, 0x8f4 <__do_global_dtors_aux+0x34>
     8e8:      	adrp	x0, 0x20000 <data_start>
     8ec:      	ldr	x0, [x0, #0x8]
     8f0:      	bl	0x790 <__cxa_finalize@plt>
     8f4:      	bl	0x850 <deregister_tm_clones>
     8f8:      	mov	w0, #0x1                // =1
     8fc:      	strb	w0, [x19, #0x10]
     900:      	ldr	x19, [sp, #0x10]
     904:      	ldp	x29, x30, [sp], #0x20
     908:      	autiasp
     90c:      	ret

0000000000000910 <frame_dummy>:
     910:      	bti	c
     914:      	b	0x880 <register_tm_clones>

0000000000000918 <kernel>:
     918:      	sub	sp, sp, #0x20
     91c:      	str	w0, [sp, #0xc]
     920:      	str	w1, [sp, #0x8]
     924:      	ldr	w0, [sp, #0x8]
     928:      	and	w1, w0, #0xff
     92c:      	ldr	w0, [sp, #0xc]
     930:      	eor	w0, w1, w0
     934:      	mvn	w0, w0
     938:      	str	w0, [sp, #0x14]
     93c:      	str	wzr, [sp, #0x1c]
     940:      	str	wzr, [sp, #0x18]
     944:      	b	0x984 <kernel+0x6c>
     948:      	ldr	w0, [sp, #0x14]
     94c:      	and	w0, w0, #0x1
     950:      	neg	w0, w0
     954:      	str	w0, [sp, #0x1c]
     958:      	ldr	w0, [sp, #0x14]
     95c:      	lsr	w1, w0, #1
     960:      	ldr	w2, [sp, #0x1c]
     964:      	mov	w0, #0x8320             // =33568
     968:      	movk	w0, #0xedb8, lsl #16
     96c:      	and	w0, w2, w0
     970:      	eor	w0, w1, w0
     974:      	str	w0, [sp, #0x14]
     978:      	ldr	w0, [sp, #0x18]
     97c:      	add	w0, w0, #0x1
     980:      	str	w0, [sp, #0x18]
     984:      	ldr	w0, [sp, #0x18]
     988:      	cmp	w0, #0x7
     98c:      	b.ls	0x948 <kernel+0x30>
     990:      	ldr	w0, [sp, #0x14]
     994:      	mvn	w0, w0
     998:      	add	sp, sp, #0x20
     99c:      	ret

00000000000009a0 <csrd_matrix_next_value>:
     9a0:      	sub	sp, sp, #0x10
     9a4:      	str	x0, [sp, #0x8]
     9a8:      	ldr	x0, [sp, #0x8]
     9ac:      	ldr	w1, [x0]
     9b0:      	ldr	x0, [sp, #0x8]
     9b4:      	ldr	w0, [x0]
     9b8:      	lsl	w0, w0, #13
     9bc:      	eor	w1, w1, w0
     9c0:      	ldr	x0, [sp, #0x8]
     9c4:      	str	w1, [x0]
     9c8:      	ldr	x0, [sp, #0x8]
     9cc:      	ldr	w1, [x0]
     9d0:      	ldr	x0, [sp, #0x8]
     9d4:      	ldr	w0, [x0]
     9d8:      	lsr	w0, w0, #17
     9dc:      	eor	w1, w1, w0
     9e0:      	ldr	x0, [sp, #0x8]
     9e4:      	str	w1, [x0]
     9e8:      	ldr	x0, [sp, #0x8]
     9ec:      	ldr	w1, [x0]
     9f0:      	ldr	x0, [sp, #0x8]
     9f4:      	ldr	w0, [x0]
     9f8:      	lsl	w0, w0, #5
     9fc:      	eor	w1, w1, w0
     a00:      	ldr	x0, [sp, #0x8]
     a04:      	str	w1, [x0]
     a08:      	ldr	x0, [sp, #0x8]
     a0c:      	ldr	w0, [x0]
     a10:      	add	sp, sp, #0x10
     a14:      	ret

0000000000000a18 <main>:
     a18:      	sub	sp, sp, #0x80
     a1c:      	stp	x29, x30, [sp, #0x70]
     a20:      	add	x29, sp, #0x70
     a24:      	str	w0, [sp, #0xc]
     a28:      	str	x1, [sp]
     a2c:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e258>
     a30:      	ldr	x0, [x0, #0xfe8]
     a34:      	ldr	x1, [x0]
     a38:      	str	x1, [sp, #0x68]
     a3c:      	mov	x1, #0x0                // =0
     a40:      	ldr	w0, [sp, #0xc]
     a44:      	cmp	w0, #0x1
     a48:      	b.ne	0xa9c <main+0x84>
     a4c:      	b	0xa6c <main+0x54>
     a50:      	ldr	w0, [sp, #0x60]
     a54:      	ldr	w1, [sp, #0x64]
     a58:      	bl	0x918 <kernel>
     a5c:      	mov	w1, w0
     a60:      	adrp	x0, 0x0 <strtoul@GLIBC_2.17>
     a64:      	add	x0, x0, #0xc50
     a68:      	bl	0x7f0 <printf@plt>
     a6c:      	add	x0, sp, #0x60
     a70:      	add	x1, x0, #0x4
     a74:      	add	x0, sp, #0x60
     a78:      	mov	x2, x1
     a7c:      	mov	x1, x0
     a80:      	adrp	x0, 0x0 <strtoul@GLIBC_2.17>
     a84:      	add	x0, x0, #0xc58
     a88:      	bl	0x7e0 <__isoc99_scanf@plt>
     a8c:      	cmp	w0, #0x2
     a90:      	b.eq	0xa50 <main+0x38>
     a94:      	mov	w0, #0x0                // =0
     a98:      	b	0xbfc <main+0x1e4>
     a9c:      	ldr	w0, [sp, #0xc]
     aa0:      	cmp	w0, #0x3
     aa4:      	b.eq	0xab0 <main+0x98>
     aa8:      	mov	w0, #0x3                // =3
     aac:      	b	0xbfc <main+0x1e4>
     ab0:      	ldr	x0, [sp]
     ab4:      	add	x0, x0, #0x8
     ab8:      	ldr	x0, [x0]
     abc:      	mov	w2, #0xa                // =10
     ac0:      	mov	x1, #0x0                // =0
     ac4:      	bl	0x770 <strtoul@plt>
     ac8:      	str	x0, [sp, #0x30]
     acc:      	ldr	x0, [sp]
     ad0:      	add	x0, x0, #0x10
     ad4:      	ldr	x0, [x0]
     ad8:      	mov	w2, #0xa                // =10
     adc:      	mov	x1, #0x0                // =0
     ae0:      	bl	0x770 <strtoul@plt>
     ae4:      	str	w0, [sp, #0x18]
     ae8:      	str	xzr, [sp, #0x20]
     aec:      	add	x0, sp, #0x40
     af0:      	mov	x1, x0
     af4:      	mov	w0, #0x1                // =1
     af8:      	bl	0x7a0 <clock_gettime@plt>
     afc:      	cmp	w0, #0x0
     b00:      	b.eq	0xb0c <main+0xf4>
     b04:      	mov	w0, #0x2                // =2
     b08:      	b	0xbfc <main+0x1e4>
     b0c:      	str	xzr, [sp, #0x28]
     b10:      	b	0xb78 <main+0x160>
     b14:      	str	wzr, [sp, #0x1c]
     b18:      	b	0xb44 <main+0x12c>
     b1c:      	add	x0, sp, #0x18
     b20:      	bl	0x9a0 <csrd_matrix_next_value>
     b24:      	mov	w2, w0
     b28:      	ldr	w0, [sp, #0x1c]
     b2c:      	lsl	x0, x0, #2
     b30:      	add	x1, sp, #0x60
     b34:      	str	w2, [x1, x0]
     b38:      	ldr	w0, [sp, #0x1c]
     b3c:      	add	w0, w0, #0x1
     b40:      	str	w0, [sp, #0x1c]
     b44:      	ldr	w0, [sp, #0x1c]
     b48:      	cmp	w0, #0x1
     b4c:      	b.ls	0xb1c <main+0x104>
     b50:      	ldr	w0, [sp, #0x60]
     b54:      	ldr	w1, [sp, #0x64]
     b58:      	bl	0x918 <kernel>
     b5c:      	mov	w0, w0
     b60:      	ldr	x1, [sp, #0x20]
     b64:      	add	x0, x1, x0
     b68:      	str	x0, [sp, #0x20]
     b6c:      	ldr	x0, [sp, #0x28]
     b70:      	add	x0, x0, #0x1
     b74:      	str	x0, [sp, #0x28]
     b78:      	ldr	x1, [sp, #0x28]
     b7c:      	ldr	x0, [sp, #0x30]
     b80:      	cmp	x1, x0
     b84:      	b.lo	0xb14 <main+0xfc>
     b88:      	add	x0, sp, #0x50
     b8c:      	mov	x1, x0
     b90:      	mov	w0, #0x1                // =1
     b94:      	bl	0x7a0 <clock_gettime@plt>
     b98:      	cmp	w0, #0x0
     b9c:      	b.eq	0xba8 <main+0x190>
     ba0:      	mov	w0, #0x2                // =2
     ba4:      	b	0xbfc <main+0x1e4>
     ba8:      	ldr	x1, [sp, #0x50]
     bac:      	ldr	x0, [sp, #0x40]
     bb0:      	sub	x0, x1, x0
     bb4:      	fmov	d0, x0
     bb8:      	scvtf	d1, d0
     bbc:      	ldr	x1, [sp, #0x58]
     bc0:      	ldr	x0, [sp, #0x48]
     bc4:      	sub	x0, x1, x0
     bc8:      	fmov	d0, x0
     bcc:      	scvtf	d0, d0
     bd0:      	adrp	x0, 0x0 <strtoul@GLIBC_2.17>
     bd4:      	ldr	d2, [x0, #0xc70]
     bd8:      	fmul	d0, d0, d2
     bdc:      	fadd	d0, d1, d0
     be0:      	str	d0, [sp, #0x38]
     be4:      	ldr	x1, [sp, #0x20]
     be8:      	ldr	d0, [sp, #0x38]
     bec:      	adrp	x0, 0x0 <strtoul@GLIBC_2.17>
     bf0:      	add	x0, x0, #0xc60
     bf4:      	bl	0x7f0 <printf@plt>
     bf8:      	mov	w0, #0x0                // =0
     bfc:      	mov	w1, w0
     c00:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e258>
     c04:      	ldr	x0, [x0, #0xfe8]
     c08:      	ldr	x3, [sp, #0x68]
     c0c:      	ldr	x2, [x0]
     c10:      	subs	x3, x3, x2
     c14:      	mov	x2, #0x0                // =0
     c18:      	b.eq	0xc20 <main+0x208>
     c1c:      	bl	0x7b0 <__stack_chk_fail@plt>
     c20:      	mov	w0, w1
     c24:      	ldp	x29, x30, [sp, #0x70]
     c28:      	add	sp, sp, #0x80
     c2c:      	ret

Disassembly of section .fini:

0000000000000c30 <_fini>:
     c30:      	nop
     c34:      	stp	x29, x30, [sp, #-0x10]!
     c38:      	mov	x29, sp
     c3c:      	ldp	x29, x30, [sp], #0x10
     c40:      	ret
