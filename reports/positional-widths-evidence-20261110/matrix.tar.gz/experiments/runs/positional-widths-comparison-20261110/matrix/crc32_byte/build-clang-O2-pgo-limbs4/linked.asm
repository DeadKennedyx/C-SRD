
/work/experiments/runs/positional-widths-comparison-20261110/matrix/crc32_byte/build-clang-O2-pgo-limbs4/program:	file format elf64-littleaarch64

Disassembly of section .init:

0000000000000678 <_init>:
     678:      	nop
     67c:      	stp	x29, x30, [sp, #-0x10]!
     680:      	mov	x29, sp
     684:      	bl	0xbf4 <call_weak_fn>
     688:      	ldp	x29, x30, [sp], #0x10
     68c:      	ret

Disassembly of section .plt:

0000000000000690 <.plt>:
     690:      	stp	x16, x30, [sp, #-0x10]!
     694:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e034>
     698:      	ldr	x17, [x16, #0xff8]
     69c:      	add	x16, x16, #0xff8
     6a0:      	br	x17
     6a4:      	nop
     6a8:      	nop
     6ac:      	nop

00000000000006b0 <strtoul@plt>:
     6b0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6b4:      	ldr	x17, [x16]
     6b8:      	add	x16, x16, #0x0
     6bc:      	br	x17

00000000000006c0 <__libc_start_main@plt>:
     6c0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6c4:      	ldr	x17, [x16, #0x8]
     6c8:      	add	x16, x16, #0x8
     6cc:      	br	x17

00000000000006d0 <__cxa_finalize@plt>:
     6d0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6d4:      	ldr	x17, [x16, #0x10]
     6d8:      	add	x16, x16, #0x10
     6dc:      	br	x17

00000000000006e0 <clock_gettime@plt>:
     6e0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6e4:      	ldr	x17, [x16, #0x18]
     6e8:      	add	x16, x16, #0x18
     6ec:      	br	x17

00000000000006f0 <__gmon_start__@plt>:
     6f0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6f4:      	ldr	x17, [x16, #0x20]
     6f8:      	add	x16, x16, #0x20
     6fc:      	br	x17

0000000000000700 <abort@plt>:
     700:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     704:      	ldr	x17, [x16, #0x28]
     708:      	add	x16, x16, #0x28
     70c:      	br	x17

0000000000000710 <__isoc99_scanf@plt>:
     710:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     714:      	ldr	x17, [x16, #0x30]
     718:      	add	x16, x16, #0x30
     71c:      	br	x17

0000000000000720 <printf@plt>:
     720:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     724:      	ldr	x17, [x16, #0x38]
     728:      	add	x16, x16, #0x38
     72c:      	br	x17

Disassembly of section .text:

0000000000000740 <kernel>:
     740:      	str	x27, [sp, #-0x50]!
     744:      	stp	x26, x25, [sp, #0x10]
     748:      	stp	x24, x23, [sp, #0x20]
     74c:      	stp	x22, x21, [sp, #0x30]
     750:      	stp	x20, x19, [sp, #0x40]
     754:      	mov	w10, #-0x1              // =-1
     758:      	eon	w13, w1, w0
     75c:      	eor	w18, w1, w0
     760:      	eor	w11, w10, w0, lsr #8
     764:      	eor	w14, w10, w0, lsr #12
     768:      	sbfx	w2, w13, #0, #1
     76c:      	eor	w6, w10, w0, lsr #16
     770:      	sbfx	w3, w13, #1, #1
     774:      	mvn	w5, w0
     778:      	ubfx	w16, w11, #1, #3
     77c:      	and	w1, w2, #0x3
     780:      	lsr	w19, w5, #25
     784:      	lsr	w20, w5, #26
     788:      	lsr	w21, w5, #30
     78c:      	and	w22, w2, #0x8
     790:      	bfi	w16, w14, #3, #1
     794:      	and	w5, w3, #0x3
     798:      	eor	w4, w10, w0, lsr #20
     79c:      	eor	w12, w10, w0, lsr #24
     7a0:      	eor	w10, w10, w18, lsr #4
     7a4:      	ubfiz	w11, w11, #3, #1
     7a8:      	eor	w16, w1, w16
     7ac:      	lsr	w1, w14, #1
     7b0:      	ubfx	w14, w14, #1, #3
     7b4:      	lsr	w7, w16, #1
     7b8:      	ubfx	w24, w4, #1, #3
     7bc:      	bfxil	w11, w10, #1, #3
     7c0:      	bfi	w14, w6, #3, #1
     7c4:      	mov	w8, #0xb                // =11
     7c8:      	and	w19, w19, #0x8
     7cc:      	bfi	w7, w1, #3, #1
     7d0:      	lsr	w1, w6, #1
     7d4:      	ubfx	w6, w6, #1, #3
     7d8:      	eor	w14, w22, w14
     7dc:      	bfi	w24, w12, #3, #1
     7e0:      	and	w27, w3, #0x8
     7e4:      	eor	w5, w7, w5
     7e8:      	lsr	w7, w14, #1
     7ec:      	bfi	w6, w4, #3, #1
     7f0:      	lsr	w23, w5, #1
     7f4:      	and	w26, w2, w8
     7f8:      	bfxil	w19, w12, #1, #3
     7fc:      	mov	w9, #0xd                // =13
     800:      	and	w25, w2, #0xe
     804:      	and	w20, w20, #0x8
     808:      	orr	w4, w23, w7, lsl #3
     80c:      	bfi	w7, w1, #3, #1
     810:      	and	w23, w2, #0x2
     814:      	eor	w12, w23, w11
     818:      	eor	w1, w22, w6
     81c:      	eor	w6, w26, w24
     820:      	eor	w11, w7, w27
     824:      	lsr	w7, w1, #1
     828:      	and	w2, w2, w9
     82c:      	lsr	w11, w11, #1
     830:      	lsr	w22, w6, #1
     834:      	eor	w2, w2, w19
     838:      	lsr	w19, w12, #1
     83c:      	and	w23, w3, #0xf
     840:      	sbfx	w13, w13, #2, #1
     844:      	orr	w24, w11, w7, lsl #3
     848:      	bfi	w7, w6, #3, #1
     84c:      	bfi	w22, w2, #3, #1
     850:      	bfi	w19, w16, #3, #1
     854:      	orr	w16, w20, w2, lsr #1
     858:      	and	w6, w3, w8
     85c:      	eor	w7, w7, w27
     860:      	and	w11, w3, #0x2
     864:      	and	w3, w3, w9
     868:      	eor	w6, w22, w6
     86c:      	lsr	w7, w7, #1
     870:      	eor	w16, w16, w3
     874:      	lsr	w20, w6, #1
     878:      	eor	w2, w21, w25, lsr #1
     87c:      	eor	w11, w19, w11
     880:      	lsr	w21, w16, #1
     884:      	orr	w6, w7, w6, lsl #3
     888:      	lsr	w19, w11, #1
     88c:      	orr	w16, w20, w16, lsl #3
     890:      	eor	w3, w2, w23
     894:      	and	w20, w24, #0xf
     898:      	orr	w2, w21, w2, lsl #3
     89c:      	and	w6, w6, #0xe
     8a0:      	and	w24, w13, #0x8
     8a4:      	and	w23, w13, #0xf
     8a8:      	orr	w5, w19, w5, lsl #3
     8ac:      	and	w7, w4, #0xf
     8b0:      	and	w21, w16, #0xf
     8b4:      	and	w16, w13, #0x3
     8b8:      	and	w25, w13, w8
     8bc:      	and	w26, w13, w9
     8c0:      	eor	w4, w19, w13
     8c4:      	eor	w13, w6, w24
     8c8:      	mov	w6, #0x8                // =8
     8cc:      	mov	w15, #0xf               // =15
     8d0:      	and	w2, w2, #0xf
     8d4:      	bics	wzr, w6, w18
     8d8:      	bic	w17, w15, w18, lsr #4
     8dc:      	eor	w7, w7, w16
     8e0:      	eor	w16, w20, w24
     8e4:      	lsr	w5, w5, #1
     8e8:      	eor	w20, w2, w26
     8ec:      	csel	w2, w15, wzr, ne
     8f0:      	bic	w15, w6, w0, lsr #12
     8f4:      	bic	w0, w6, w0, lsr #16
     8f8:      	eor	w19, w21, w25
     8fc:      	and	w18, w5, #0x6
     900:      	lsr	w22, w3, #1
     904:      	orr	w6, w15, w7, lsr #1
     908:      	orr	w15, w0, w16, lsr #1
     90c:      	eor	w3, w23, w3, lsr #1
     910:      	lsr	w21, w13, #1
     914:      	bfi	w18, w7, #3, #1
     918:      	lsr	w23, w19, #1
     91c:      	lsr	w24, w20, #1
     920:      	and	w7, w2, #0x8
     924:      	and	w0, w2, #0x3
     928:      	eor	w15, w15, w7
     92c:      	bfi	w21, w19, #3, #1
     930:      	bfi	w23, w20, #3, #1
     934:      	bfi	w24, w22, #3, #1
     938:      	eor	w22, w6, w0
     93c:      	sbfx	w6, w17, #0, #1
     940:      	lsr	w0, w15, #1
     944:      	and	w19, w2, #0xfffffffb
     948:      	and	w20, w2, #0xfffffffd
     94c:      	and	w1, w1, #0x8
     950:      	eor	w17, w21, w7
     954:      	eor	w7, w23, w19
     958:      	eor	w19, w24, w20
     95c:      	orr	w1, w0, w1
     960:      	and	w20, w6, #0x8
     964:      	lsr	w23, w18, #1
     968:      	eor	w1, w1, w20
     96c:      	and	w18, w4, #0x2
     970:      	lsr	w4, w17, #1
     974:      	lsr	w1, w1, #1
     978:      	and	w14, w14, #0x8
     97c:      	lsl	w24, w3, #2
     980:      	bfi	w23, w22, #3, #1
     984:      	orr	w14, w14, w22, lsr #1
     988:      	ubfiz	w22, w19, #3, #1
     98c:      	eor	w5, w5, w2
     990:      	orr	w1, w1, w4, lsl #3
     994:      	and	w24, w24, #0x8
     998:      	lsr	w3, w3, #2
     99c:      	bfi	w4, w7, #3, #1
     9a0:      	lsr	w5, w5, #1
     9a4:      	orr	w7, w22, w7, lsr #1
     9a8:      	orr	w19, w24, w19, lsr #1
     9ac:      	and	w22, w6, #0x3
     9b0:      	and	w21, w6, #0xf
     9b4:      	eor	w2, w3, w2, lsr #1
     9b8:      	and	w3, w6, #0x2
     9bc:      	and	w24, w6, w8
     9c0:      	and	w6, w6, w9
     9c4:      	eor	w14, w14, w22
     9c8:      	eor	w4, w4, w20
     9cc:      	eor	w7, w7, w24
     9d0:      	eor	w6, w19, w6
     9d4:      	bfi	w18, w5, #2, #1
     9d8:      	lsr	w5, w14, #1
     9dc:      	lsr	w4, w4, #1
     9e0:      	eor	w3, w23, w3
     9e4:      	eor	w20, w2, w21
     9e8:      	lsr	w21, w7, #1
     9ec:      	lsr	w23, w6, #1
     9f0:      	lsr	w3, w3, #1
     9f4:      	sbfx	w22, w10, #1, #1
     9f8:      	orr	w0, w5, w0, lsl #3
     9fc:      	orr	w4, w4, w7, lsl #3
     a00:      	orr	w5, w21, w6, lsl #3
     a04:      	orr	w2, w23, w2, lsl #3
     a08:      	bfi	w18, w3, #3, #1
     a0c:      	eor	w24, w3, w22
     a10:      	bfi	w3, w14, #3, #1
     a14:      	and	w14, w0, #0xf
     a18:      	and	w0, w1, #0xc
     a1c:      	and	w1, w4, #0xc
     a20:      	and	w6, w22, #0x8
     a24:      	and	w4, w5, #0xf
     a28:      	and	w2, w2, #0xf
     a2c:      	and	w5, w22, #0x3
     a30:      	and	w7, w22, w8
     a34:      	and	w21, w22, w9
     a38:      	eor	w1, w1, w6
     a3c:      	and	w19, w22, #0xf
     a40:      	eor	w5, w14, w5
     a44:      	eor	w4, w4, w7
     a48:      	eor	w2, w2, w21
     a4c:      	sbfx	w12, w12, #1, #1
     a50:      	and	w16, w16, #0x8
     a54:      	lsr	w1, w1, #1
     a58:      	lsr	w10, w20, #1
     a5c:      	eor	w0, w0, w6
     a60:      	eor	w14, w19, w20, lsr #1
     a64:      	ubfiz	w19, w5, #3, #1
     a68:      	lsr	w7, w4, #1
     a6c:      	orr	w16, w16, w5, lsr #1
     a70:      	and	w13, w13, #0x8
     a74:      	lsr	w5, w2, #1
     a78:      	orr	w13, w13, w0, lsr #1
     a7c:      	bfi	w1, w4, #3, #1
     a80:      	and	w0, w12, #0x3
     a84:      	orr	w3, w19, w3, lsr #1
     a88:      	bfi	w7, w2, #3, #1
     a8c:      	bfi	w5, w10, #3, #1
     a90:      	and	w2, w12, #0x8
     a94:      	eor	w16, w16, w0
     a98:      	and	w10, w12, #0x2
     a9c:      	and	w19, w12, w9
     aa0:      	eor	w0, w1, w2
     aa4:      	ubfiz	w1, w16, #3, #1
     aa8:      	eor	w10, w3, w10
     aac:      	eor	w3, w5, w19
     ab0:      	lsr	w6, w14, #1
     ab4:      	orr	w10, w1, w10, lsr #1
     ab8:      	lsr	w1, w3, #1
     abc:      	and	w4, w12, w8
     ac0:      	sbfx	w11, w11, #1, #1
     ac4:      	eor	w13, w13, w2
     ac8:      	eor	w2, w7, w4
     acc:      	and	w15, w15, #0x8
     ad0:      	ubfx	w12, w12, #1, #3
     ad4:      	bfi	w1, w6, #3, #1
     ad8:      	orr	w15, w15, w16, lsr #1
     adc:      	lsr	w16, w0, #1
     ae0:      	lsr	w0, w2, #1
     ae4:      	and	w9, w11, w9
     ae8:      	and	w17, w17, #0x8
     aec:      	eor	w12, w12, w14, lsr #2
     af0:      	eor	w9, w1, w9
     af4:      	lsr	w22, w24, #1
     af8:      	lsr	w18, w18, #1
     afc:      	orr	w13, w17, w13, lsr #1
     b00:      	bfi	w16, w2, #3, #1
     b04:      	bfi	w0, w3, #3, #1
     b08:      	and	w14, w11, #0x2
     b0c:      	and	w17, w11, #0x3
     b10:      	and	w2, w11, #0x8
     b14:      	and	w8, w11, w8
     b18:      	and	w11, w11, #0xe
     b1c:      	lsl	w9, w9, #24
     b20:      	eor	w10, w10, w14
     b24:      	eor	w14, w15, w17
     b28:      	eon	w11, w11, w12
     b2c:      	bfi	w18, w22, #3, #1
     b30:      	eor	w13, w13, w2
     b34:      	eor	w8, w0, w8
     b38:      	lsl	w12, w14, #8
     b3c:      	orr	w9, w9, w11, lsl #28
     b40:      	lsl	w13, w13, #12
     b44:      	lsl	w8, w8, #20
     b48:      	eor	w11, w16, w2
     b4c:      	orr	w10, w18, w10, lsl #4
     b50:      	eor	w12, w12, #0xf00
     b54:      	eor	w9, w9, #0xf000000
     b58:      	eor	w13, w13, #0xf000
     b5c:      	lsl	w11, w11, #16
     b60:      	eor	w8, w8, #0xf00000
     b64:      	orr	w9, w9, w12
     b68:      	orr	w8, w9, w8
     b6c:      	orr	w9, w10, w13
     b70:      	eor	w10, w11, #0xf0000
     b74:      	orr	w8, w8, w9
     b78:      	ldp	x20, x19, [sp, #0x40]
     b7c:      	orr	w8, w8, w10
     b80:      	ldp	x22, x21, [sp, #0x30]
     b84:      	eor	w0, w8, #0xff
     b88:      	ldp	x24, x23, [sp, #0x20]
     b8c:      	ldp	x26, x25, [sp, #0x10]
     b90:      	ldr	x27, [sp], #0x50
     b94:      	ret
     b98:      	nop
     b9c:      	nop
     ba0:      	nop
     ba4:      	nop
     ba8:      	nop
     bac:      	nop
     bb0:      	nop
     bb4:      	nop
     bb8:      	nop
     bbc:      	nop

0000000000000bc0 <_start>:
     bc0:      	nop
     bc4:      	mov	x29, #0x0               // =0
     bc8:      	mov	x30, #0x0               // =0
     bcc:      	mov	x5, x0
     bd0:      	ldr	x1, [sp]
     bd4:      	add	x2, sp, #0x8
     bd8:      	mov	x6, sp
     bdc:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e034>
     be0:      	ldr	x0, [x0, #0xfd8]
     be4:      	mov	x3, #0x0                // =0
     be8:      	mov	x4, #0x0                // =0
     bec:      	bl	0x6c0 <__libc_start_main@plt>
     bf0:      	bl	0x700 <abort@plt>

0000000000000bf4 <call_weak_fn>:
     bf4:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e034>
     bf8:      	ldr	x0, [x0, #0xfd0]
     bfc:      	cbz	x0, 0xc04 <call_weak_fn+0x10>
     c00:      	b	0x6f0 <__gmon_start__@plt>
     c04:      	ret
     c08:      	nop
     c0c:      	nop

0000000000000c10 <deregister_tm_clones>:
     c10:      	adrp	x0, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     c14:      	add	x0, x0, #0x50
     c18:      	adrp	x1, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     c1c:      	add	x1, x1, #0x50
     c20:      	cmp	x1, x0
     c24:      	b.eq	0xc3c <deregister_tm_clones+0x2c>
     c28:      	adrp	x1, 0x1f000 <__FRAME_END__+0x1e034>
     c2c:      	ldr	x1, [x1, #0xfc0]
     c30:      	cbz	x1, 0xc3c <deregister_tm_clones+0x2c>
     c34:      	mov	x16, x1
     c38:      	br	x16
     c3c:      	ret

0000000000000c40 <register_tm_clones>:
     c40:      	adrp	x0, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     c44:      	add	x0, x0, #0x50
     c48:      	adrp	x1, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     c4c:      	add	x1, x1, #0x50
     c50:      	sub	x1, x1, x0
     c54:      	lsr	x2, x1, #63
     c58:      	add	x1, x2, x1, asr #3
     c5c:      	asr	x1, x1, #1
     c60:      	cbz	x1, 0xc78 <register_tm_clones+0x38>
     c64:      	adrp	x2, 0x1f000 <__FRAME_END__+0x1e034>
     c68:      	ldr	x2, [x2, #0xfe0]
     c6c:      	cbz	x2, 0xc78 <register_tm_clones+0x38>
     c70:      	mov	x16, x2
     c74:      	br	x16
     c78:      	ret
     c7c:      	nop

0000000000000c80 <__do_global_dtors_aux>:
     c80:      	paciasp
     c84:      	stp	x29, x30, [sp, #-0x20]!
     c88:      	mov	x29, sp
     c8c:      	str	x19, [sp, #0x10]
     c90:      	adrp	x19, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     c94:      	ldrb	w0, [x19, #0x50]
     c98:      	tbnz	w0, #0x0, 0xcc0 <__do_global_dtors_aux+0x40>
     c9c:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e034>
     ca0:      	ldr	x0, [x0, #0xfc8]
     ca4:      	cbz	x0, 0xcb4 <__do_global_dtors_aux+0x34>
     ca8:      	adrp	x0, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     cac:      	ldr	x0, [x0, #0x48]
     cb0:      	bl	0x6d0 <__cxa_finalize@plt>
     cb4:      	bl	0xc10 <deregister_tm_clones>
     cb8:      	mov	w0, #0x1                // =1
     cbc:      	strb	w0, [x19, #0x50]
     cc0:      	ldr	x19, [sp, #0x10]
     cc4:      	ldp	x29, x30, [sp], #0x20
     cc8:      	autiasp
     ccc:      	ret

0000000000000cd0 <frame_dummy>:
     cd0:      	bti	c
     cd4:      	b	0xc40 <register_tm_clones>

0000000000000cd8 <main>:
     cd8:      	sub	sp, sp, #0x50
     cdc:      	stp	x29, x30, [sp, #0x20]
     ce0:      	str	x21, [sp, #0x30]
     ce4:      	stp	x20, x19, [sp, #0x40]
     ce8:      	add	x29, sp, #0x20
     cec:      	cmp	w0, #0x1
     cf0:      	b.ne	0xd68 <main+0x90>
     cf4:      	add	x21, sp, #0x10
     cf8:      	adrp	x0, 0x0 <strtoul@GLIBC_2.17>
     cfc:      	add	x0, x0, #0xe60
     d00:      	add	x1, sp, #0x10
     d04:      	add	x2, x21, #0x4
     d08:      	bl	0x710 <__isoc99_scanf@plt>
     d0c:      	cmp	w0, #0x2
     d10:      	b.ne	0xd50 <main+0x78>
     d14:      	adrp	x19, 0x0 <strtoul@GLIBC_2.17>
     d18:      	add	x19, x19, #0xe65
     d1c:      	adrp	x20, 0x0 <strtoul@GLIBC_2.17>
     d20:      	add	x20, x20, #0xe60
     d24:      	ldp	w0, w1, [sp, #0x10]
     d28:      	bl	0x740 <kernel>
     d2c:      	mov	w1, w0
     d30:      	mov	x0, x19
     d34:      	bl	0x720 <printf@plt>
     d38:      	add	x1, sp, #0x10
     d3c:      	add	x2, x21, #0x4
     d40:      	mov	x0, x20
     d44:      	bl	0x710 <__isoc99_scanf@plt>
     d48:      	cmp	w0, #0x2
     d4c:      	b.eq	0xd24 <main+0x4c>
     d50:      	mov	w0, wzr
     d54:      	ldp	x20, x19, [sp, #0x40]
     d58:      	ldr	x21, [sp, #0x30]
     d5c:      	ldp	x29, x30, [sp, #0x20]
     d60:      	add	sp, sp, #0x50
     d64:      	ret
     d68:      	cmp	w0, #0x3
     d6c:      	b.ne	0xdb8 <main+0xe0>
     d70:      	ldr	x0, [x1, #0x8]
     d74:      	mov	x19, x1
     d78:      	mov	x1, xzr
     d7c:      	mov	w2, #0xa                // =10
     d80:      	bl	0x6b0 <strtoul@plt>
     d84:      	ldr	x8, [x19, #0x10]
     d88:      	mov	x20, x0
     d8c:      	mov	x1, xzr
     d90:      	mov	w2, #0xa                // =10
     d94:      	mov	x0, x8
     d98:      	bl	0x6b0 <strtoul@plt>
     d9c:      	mov	x21, x0
     da0:      	add	x1, sp, #0x10
     da4:      	mov	w0, #0x1                // =1
     da8:      	bl	0x6e0 <clock_gettime@plt>
     dac:      	cbz	w0, 0xdc0 <main+0xe8>
     db0:      	mov	w0, #0x2                // =2
     db4:      	b	0xd54 <main+0x7c>
     db8:      	mov	w0, #0x3                // =3
     dbc:      	b	0xd54 <main+0x7c>
     dc0:      	mov	x19, xzr
     dc4:      	cbz	x20, 0xdf4 <main+0x11c>
     dc8:      	eor	w8, w21, w21, lsl #13
     dcc:      	eor	w8, w8, w8, lsr #17
     dd0:      	eor	w0, w8, w8, lsl #5
     dd4:      	eor	w8, w0, w0, lsl #13
     dd8:      	eor	w8, w8, w8, lsr #17
     ddc:      	eor	w21, w8, w8, lsl #5
     de0:      	mov	w1, w21
     de4:      	bl	0x740 <kernel>
     de8:      	add	x19, x19, w0, uxtw
     dec:      	subs	x20, x20, #0x1
     df0:      	b.ne	0xdc8 <main+0xf0>
     df4:      	mov	x1, sp
     df8:      	mov	w0, #0x1                // =1
     dfc:      	bl	0x6e0 <clock_gettime@plt>
     e00:      	cbnz	w0, 0xdb0 <main+0xd8>
     e04:      	ldp	x8, x9, [sp]
     e08:      	adrp	x0, 0x0 <strtoul@GLIBC_2.17>
     e0c:      	add	x0, x0, #0xe69
     e10:      	ldp	x10, x11, [sp, #0x10]
     e14:      	mov	x1, x19
     e18:      	sub	x8, x8, x10
     e1c:      	sub	x9, x9, x11
     e20:      	scvtf	d0, x8
     e24:      	scvtf	d1, x9
     e28:      	adrp	x8, 0x0 <strtoul@GLIBC_2.17>
     e2c:      	ldr	d2, [x8, #0xe58]
     e30:      	fmadd	d0, d1, d2, d0
     e34:      	bl	0x720 <printf@plt>
     e38:      	b	0xd50 <main+0x78>

Disassembly of section .fini:

0000000000000e3c <_fini>:
     e3c:      	nop
     e40:      	stp	x29, x30, [sp, #-0x10]!
     e44:      	mov	x29, sp
     e48:      	ldp	x29, x30, [sp], #0x10
     e4c:      	ret
