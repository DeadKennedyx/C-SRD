
/work/experiments/runs/positional-widths-comparison-20261110/matrix/crc32_byte/build-gcc-O1-sanitizers-identity/program:	file format elf64-littleaarch64

Disassembly of section .init:

00000000000011c0 <_init>:
    11c0:      	nop
    11c4:      	stp	x29, x30, [sp, #-0x10]!
    11c8:      	mov	x29, sp
    11cc:      	bl	0x13b4 <call_weak_fn>
    11d0:      	ldp	x29, x30, [sp], #0x10
    11d4:      	ret

Disassembly of section .plt:

00000000000011e0 <.plt>:
    11e0:      	stp	x16, x30, [sp, #-0x10]!
    11e4:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1d03c>
    11e8:      	ldr	x17, [x16, #0xf08]
    11ec:      	add	x16, x16, #0xf08
    11f0:      	br	x17
    11f4:      	nop
    11f8:      	nop
    11fc:      	nop

0000000000001200 <__asan_report_store4@plt>:
    1200:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1d03c>
    1204:      	ldr	x17, [x16, #0xf10]
    1208:      	add	x16, x16, #0xf10
    120c:      	br	x17

0000000000001210 <__ubsan_handle_type_mismatch_v1_abort@plt>:
    1210:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1d03c>
    1214:      	ldr	x17, [x16, #0xf18]
    1218:      	add	x16, x16, #0xf18
    121c:      	br	x17

0000000000001220 <__asan_register_globals@plt>:
    1220:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1d03c>
    1224:      	ldr	x17, [x16, #0xf20]
    1228:      	add	x16, x16, #0xf20
    122c:      	br	x17

0000000000001230 <__stack_chk_fail@plt>:
    1230:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1d03c>
    1234:      	ldr	x17, [x16, #0xf28]
    1238:      	add	x16, x16, #0xf28
    123c:      	br	x17

0000000000001240 <__ubsan_handle_nonnull_arg_abort@plt>:
    1240:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1d03c>
    1244:      	ldr	x17, [x16, #0xf30]
    1248:      	add	x16, x16, #0xf30
    124c:      	br	x17

0000000000001250 <__ubsan_handle_sub_overflow_abort@plt>:
    1250:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1d03c>
    1254:      	ldr	x17, [x16, #0xf38]
    1258:      	add	x16, x16, #0xf38
    125c:      	br	x17

0000000000001260 <__asan_report_load4@plt>:
    1260:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1d03c>
    1264:      	ldr	x17, [x16, #0xf40]
    1268:      	add	x16, x16, #0xf40
    126c:      	br	x17

0000000000001270 <__cxa_finalize@plt>:
    1270:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1d03c>
    1274:      	ldr	x17, [x16, #0xf48]
    1278:      	add	x16, x16, #0xf48
    127c:      	br	x17

0000000000001280 <__libc_start_main@plt>:
    1280:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1d03c>
    1284:      	ldr	x17, [x16, #0xf50]
    1288:      	add	x16, x16, #0xf50
    128c:      	br	x17

0000000000001290 <__asan_unregister_globals@plt>:
    1290:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1d03c>
    1294:      	ldr	x17, [x16, #0xf58]
    1298:      	add	x16, x16, #0xf58
    129c:      	br	x17

00000000000012a0 <__asan_handle_no_return@plt>:
    12a0:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1d03c>
    12a4:      	ldr	x17, [x16, #0xf60]
    12a8:      	add	x16, x16, #0xf60
    12ac:      	br	x17

00000000000012b0 <__asan_init@plt>:
    12b0:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1d03c>
    12b4:      	ldr	x17, [x16, #0xf68]
    12b8:      	add	x16, x16, #0xf68
    12bc:      	br	x17

00000000000012c0 <strtoul@plt>:
    12c0:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1d03c>
    12c4:      	ldr	x17, [x16, #0xf70]
    12c8:      	add	x16, x16, #0xf70
    12cc:      	br	x17

00000000000012d0 <clock_gettime@plt>:
    12d0:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1d03c>
    12d4:      	ldr	x17, [x16, #0xf78]
    12d8:      	add	x16, x16, #0xf78
    12dc:      	br	x17

00000000000012e0 <__asan_report_load8@plt>:
    12e0:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1d03c>
    12e4:      	ldr	x17, [x16, #0xf80]
    12e8:      	add	x16, x16, #0xf80
    12ec:      	br	x17

00000000000012f0 <abort@plt>:
    12f0:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1d03c>
    12f4:      	ldr	x17, [x16, #0xf88]
    12f8:      	add	x16, x16, #0xf88
    12fc:      	br	x17

0000000000001300 <__asan_stack_malloc_2@plt>:
    1300:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1d03c>
    1304:      	ldr	x17, [x16, #0xf90]
    1308:      	add	x16, x16, #0xf90
    130c:      	br	x17

0000000000001310 <__asan_version_mismatch_check_v8@plt>:
    1310:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1d03c>
    1314:      	ldr	x17, [x16, #0xf98]
    1318:      	add	x16, x16, #0xf98
    131c:      	br	x17

0000000000001320 <__isoc99_scanf@plt>:
    1320:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1d03c>
    1324:      	ldr	x17, [x16, #0xfa0]
    1328:      	add	x16, x16, #0xfa0
    132c:      	br	x17

0000000000001330 <__printf_chk@plt>:
    1330:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1d03c>
    1334:      	ldr	x17, [x16, #0xfa8]
    1338:      	add	x16, x16, #0xfa8
    133c:      	br	x17

0000000000001340 <__gmon_start__@plt>:
    1340:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1d03c>
    1344:      	ldr	x17, [x16, #0xfb0]
    1348:      	add	x16, x16, #0xfb0
    134c:      	br	x17

0000000000001350 <__ubsan_handle_pointer_overflow_abort@plt>:
    1350:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1d03c>
    1354:      	ldr	x17, [x16, #0xfb8]
    1358:      	add	x16, x16, #0xfb8
    135c:      	br	x17

Disassembly of section .text:

0000000000001380 <_start>:
    1380:      	nop
    1384:      	mov	x29, #0x0               // =0
    1388:      	mov	x30, #0x0               // =0
    138c:      	mov	x5, x0
    1390:      	ldr	x1, [sp]
    1394:      	add	x2, sp, #0x8
    1398:      	mov	x6, sp
    139c:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1d03c>
    13a0:      	ldr	x0, [x0, #0xfd0]
    13a4:      	mov	x3, #0x0                // =0
    13a8:      	mov	x4, #0x0                // =0
    13ac:      	bl	0x1280 <__libc_start_main@plt>
    13b0:      	bl	0x12f0 <abort@plt>

00000000000013b4 <call_weak_fn>:
    13b4:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1d03c>
    13b8:      	ldr	x0, [x0, #0xff0]
    13bc:      	cbz	x0, 0x13c4 <call_weak_fn+0x10>
    13c0:      	b	0x1340 <__gmon_start__@plt>
    13c4:      	ret
    13c8:      	nop
    13cc:      	nop

00000000000013d0 <deregister_tm_clones>:
    13d0:      	adrp	x0, 0x20000 <data_start>
    13d4:      	add	x0, x0, #0x780
    13d8:      	adrp	x1, 0x20000 <data_start>
    13dc:      	add	x1, x1, #0x780
    13e0:      	cmp	x1, x0
    13e4:      	b.eq	0x13fc <deregister_tm_clones+0x2c>
    13e8:      	adrp	x1, 0x1f000 <__FRAME_END__+0x1d03c>
    13ec:      	ldr	x1, [x1, #0xfe8]
    13f0:      	cbz	x1, 0x13fc <deregister_tm_clones+0x2c>
    13f4:      	mov	x16, x1
    13f8:      	br	x16
    13fc:      	ret

0000000000001400 <register_tm_clones>:
    1400:      	adrp	x0, 0x20000 <data_start>
    1404:      	add	x0, x0, #0x780
    1408:      	adrp	x1, 0x20000 <data_start>
    140c:      	add	x1, x1, #0x780
    1410:      	sub	x1, x1, x0
    1414:      	lsr	x2, x1, #63
    1418:      	add	x1, x2, x1, asr #3
    141c:      	asr	x1, x1, #1
    1420:      	cbz	x1, 0x1438 <register_tm_clones+0x38>
    1424:      	adrp	x2, 0x1f000 <__FRAME_END__+0x1d03c>
    1428:      	ldr	x2, [x2, #0xff8]
    142c:      	cbz	x2, 0x1438 <register_tm_clones+0x38>
    1430:      	mov	x16, x2
    1434:      	br	x16
    1438:      	ret
    143c:      	nop

0000000000001440 <__do_global_dtors_aux>:
    1440:      	paciasp
    1444:      	stp	x29, x30, [sp, #-0x20]!
    1448:      	mov	x29, sp
    144c:      	str	x19, [sp, #0x10]
    1450:      	adrp	x19, 0x20000 <data_start>
    1454:      	ldrb	w0, [x19, #0x780]
    1458:      	tbnz	w0, #0x0, 0x1480 <__do_global_dtors_aux+0x40>
    145c:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1d03c>
    1460:      	ldr	x0, [x0, #0xfd8]
    1464:      	cbz	x0, 0x1474 <__do_global_dtors_aux+0x34>
    1468:      	adrp	x0, 0x20000 <data_start>
    146c:      	ldr	x0, [x0, #0x8]
    1470:      	bl	0x1270 <__cxa_finalize@plt>
    1474:      	bl	0x13d0 <deregister_tm_clones>
    1478:      	mov	w0, #0x1                // =1
    147c:      	strb	w0, [x19, #0x780]
    1480:      	ldr	x19, [sp, #0x10]
    1484:      	ldp	x29, x30, [sp], #0x20
    1488:      	autiasp
    148c:      	ret

0000000000001490 <frame_dummy>:
    1490:      	bti	c
    1494:      	b	0x1400 <register_tm_clones>

0000000000001498 <kernel>:
    1498:      	and	w1, w1, #0xff
    149c:      	eon	w0, w1, w0
    14a0:      	sbfx	x2, x0, #0, #1
    14a4:      	mov	w3, #0x8320             // =33568
    14a8:      	movk	w3, #0xedb8, lsl #16
    14ac:      	and	w2, w2, w3
    14b0:      	eor	w2, w2, w0, lsr #1
    14b4:      	sbfx	x1, x0, #1, #1
    14b8:      	and	w1, w1, w3
    14bc:      	eor	w1, w1, w2, lsr #1
    14c0:      	sbfx	x0, x2, #1, #1
    14c4:      	and	w0, w0, w3
    14c8:      	eor	w0, w0, w1, lsr #1
    14cc:      	sbfx	x1, x1, #1, #1
    14d0:      	and	w1, w1, w3
    14d4:      	eor	w1, w1, w0, lsr #1
    14d8:      	sbfx	x0, x0, #1, #1
    14dc:      	and	w0, w0, w3
    14e0:      	eor	w0, w0, w1, lsr #1
    14e4:      	sbfx	x1, x1, #1, #1
    14e8:      	and	w1, w1, w3
    14ec:      	eor	w1, w1, w0, lsr #1
    14f0:      	sbfx	x0, x0, #1, #1
    14f4:      	and	w0, w0, w3
    14f8:      	eor	w0, w0, w1, lsr #1
    14fc:      	sbfx	x1, x1, #1, #1
    1500:      	and	w1, w1, w3
    1504:      	eon	w0, w1, w0, lsr #1
    1508:      	ret

000000000000150c <_sub_I_00099_0>:
    150c:      	stp	x29, x30, [sp, #-0x10]!
    1510:      	mov	x29, sp
    1514:      	bl	0x12b0 <__asan_init@plt>
    1518:      	bl	0x1310 <__asan_version_mismatch_check_v8@plt>
    151c:      	ldp	x29, x30, [sp], #0x10
    1520:      	ret

0000000000001524 <main>:
    1524:      	sub	sp, sp, #0x130
    1528:      	stp	x29, x30, [sp, #0xd0]
    152c:      	add	x29, sp, #0xd0
    1530:      	stp	x19, x20, [sp, #0xe0]
    1534:      	stp	x21, x22, [sp, #0xf0]
    1538:      	stp	x23, x24, [sp, #0x100]
    153c:      	stp	x27, x28, [sp, #0x120]
    1540:      	mov	w21, w0
    1544:      	mov	x20, x1
    1548:      	add	x23, sp, #0x10
    154c:      	mov	x28, x23
    1550:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1d03c>
    1554:      	ldr	x0, [x0, #0xfe0]
    1558:      	ldr	w0, [x0]
    155c:      	cbnz	w0, 0x1868 <main+0x344>
    1560:      	mov	x19, x23
    1564:      	mov	x0, #0x8ab3             // =35507
    1568:      	movk	x0, #0x41b5, lsl #16
    156c:      	str	x0, [x19], #0xc0
    1570:      	adrp	x0, 0x1000 <strtoul@GLIBC_2.17+0x1000>
    1574:      	add	x0, x0, #0xb48
    1578:      	str	x0, [x23, #0x8]
    157c:      	adrp	x0, 0x1000 <strtoul@GLIBC_2.17+0x1000>
    1580:      	add	x0, x0, #0x524
    1584:      	str	x0, [x23, #0x10]
    1588:      	lsr	x24, x23, #3
    158c:      	mov	x0, #0x1000000000       // =68719476736
    1590:      	add	x1, x24, x0
    1594:      	mov	w2, #-0xe0e0e0f         // =-235802127
    1598:      	str	w2, [x24, x0]
    159c:      	add	w2, w2, #0x130, lsl #12 // =0x130000
    15a0:      	str	w2, [x1, #0x4]
    15a4:      	mov	w0, #-0xd0e0000         // =-219021312
    15a8:      	str	w0, [x1, #0x8]
    15ac:      	str	w0, [x1, #0xc]
    15b0:      	mov	w0, #0xf300             // =62208
    15b4:      	movk	w0, #0xf3f3, lsl #16
    15b8:      	str	w0, [x1, #0x10]
    15bc:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1d03c>
    15c0:      	ldr	x0, [x0, #0xfc8]
    15c4:      	ldr	x1, [x0]
    15c8:      	str	x1, [sp, #0xc8]
    15cc:      	mov	x1, #0x0                // =0
    15d0:      	cmp	w21, #0x1
    15d4:      	b.eq	0x187c <main+0x358>
    15d8:      	cmp	w21, #0x3
    15dc:      	b.ne	0x1a24 <main+0x500>
    15e0:      	stp	x25, x26, [sp, #0x110]
    15e4:      	add	x2, x20, #0x8
    15e8:      	cmn	x20, #0x8
    15ec:      	b.hs	0x1920 <main+0x3fc>
    15f0:      	adds	x1, x20, #0x8
    15f4:      	b.eq	0x1930 <main+0x40c>
    15f8:      	tst	x1, #0x7
    15fc:      	b.ne	0x1930 <main+0x40c>
    1600:      	add	x0, x20, #0x8
    1604:      	lsr	x2, x0, #3
    1608:      	mov	x1, #0x1000000000       // =68719476736
    160c:      	ldrsb	w1, [x2, x1]
    1610:      	cbnz	w1, 0x1940 <main+0x41c>
    1614:      	ldr	x0, [x20, #0x8]
    1618:      	cbz	x0, 0x1944 <main+0x420>
    161c:      	mov	w2, #0xa                // =10
    1620:      	mov	x1, #0x0                // =0
    1624:      	bl	0x12c0 <strtoul@plt>
    1628:      	mov	x25, x0
    162c:      	add	x2, x20, #0x10
    1630:      	cmn	x20, #0x10
    1634:      	b.hs	0x1958 <main+0x434>
    1638:      	adds	x1, x20, #0x10
    163c:      	b.eq	0x196c <main+0x448>
    1640:      	tst	x1, #0x7
    1644:      	b.ne	0x196c <main+0x448>
    1648:      	add	x0, x20, #0x10
    164c:      	lsr	x2, x0, #3
    1650:      	mov	x1, #0x1000000000       // =68719476736
    1654:      	ldrsb	w1, [x2, x1]
    1658:      	cbnz	w1, 0x197c <main+0x458>
    165c:      	ldr	x0, [x20, #0x10]
    1660:      	cbz	x0, 0x1980 <main+0x45c>
    1664:      	mov	w2, #0xa                // =10
    1668:      	mov	x1, #0x0                // =0
    166c:      	bl	0x12c0 <strtoul@plt>
    1670:      	sub	x2, x19, #0x90
    1674:      	lsr	x3, x2, #3
    1678:      	mov	x1, #0x1000000000       // =68719476736
    167c:      	ldrsb	w1, [x3, x1]
    1680:      	cmp	w1, #0x0
    1684:      	mov	w3, #0x3                // =3
    1688:      	ccmp	w3, w1, #0x1, ne
    168c:      	b.ge	0x1994 <main+0x470>
    1690:      	stur	w0, [x19, #-0x90]
    1694:      	sub	x1, x19, #0x80
    1698:      	mov	w0, #0x1                // =1
    169c:      	bl	0x12d0 <clock_gettime@plt>
    16a0:      	cbnz	w0, 0x1a7c <main+0x558>
    16a4:      	cbz	x25, 0x19e4 <main+0x4c0>
    16a8:      	mov	x21, #0x0               // =0
    16ac:      	mov	x22, #0x0               // =0
    16b0:      	sub	x0, x19, #0x90
    16b4:      	str	x0, [sp, #0x8]
    16b8:      	lsr	x27, x0, #3
    16bc:      	sub	x20, x19, #0x40
    16c0:      	and	x26, x19, #0x7
    16c4:      	add	w26, w26, #0x3
    16c8:      	mov	x0, #0x1000000000       // =68719476736
    16cc:      	ldrsb	w0, [x27, x0]
    16d0:      	cmp	w0, #0x0
    16d4:      	mov	w1, #0x3                // =3
    16d8:      	ccmp	w1, w0, #0x1, ne
    16dc:      	b.ge	0x199c <main+0x478>
    16e0:      	ldur	w0, [x19, #-0x90]
    16e4:      	eor	w0, w0, w0, lsl #13
    16e8:      	eor	w0, w0, w0, lsr #17
    16ec:      	eor	w0, w0, w0, lsl #5
    16f0:      	stur	w0, [x19, #-0x90]
    16f4:      	lsr	x1, x20, #3
    16f8:      	mov	x2, #0x1000000000       // =68719476736
    16fc:      	ldrsb	w1, [x1, x2]
    1700:      	cmp	w1, #0x0
    1704:      	ccmp	w26, w1, #0x1, ne
    1708:      	b.ge	0x19a4 <main+0x480>
    170c:      	stur	w0, [x19, #-0x40]
    1710:      	eor	w1, w0, w0, lsl #13
    1714:      	eor	w1, w1, w1, lsr #17
    1718:      	eor	w1, w1, w1, lsl #5
    171c:      	stur	w1, [x19, #-0x90]
    1720:      	sub	x2, x19, #0x38
    1724:      	sub	x2, x2, x20
    1728:      	cmp	x2, #0x8
    172c:      	b.hi	0x19ac <main+0x488>
    1730:      	sub	x3, x19, #0x3c
    1734:      	lsr	x4, x3, #3
    1738:      	mov	x2, #0x1000000000       // =68719476736
    173c:      	ldrsb	w4, [x4, x2]
    1740:      	and	x2, x3, #0x7
    1744:      	add	w2, w2, #0x3
    1748:      	cmp	w4, #0x0
    174c:      	ccmp	w2, w4, #0x1, ne
    1750:      	b.ge	0x19cc <main+0x4a8>
    1754:      	stur	w1, [x19, #-0x3c]
    1758:      	lsr	x2, x20, #3
    175c:      	mov	x3, #0x1000000000       // =68719476736
    1760:      	ldrsb	w2, [x2, x3]
    1764:      	cmp	w2, #0x0
    1768:      	mov	w3, #0x3                // =3
    176c:      	ccmp	w3, w2, #0x1, ne
    1770:      	b.ge	0x19d4 <main+0x4b0>
    1774:      	sub	x3, x19, #0x3c
    1778:      	lsr	x4, x3, #3
    177c:      	mov	x2, #0x1000000000       // =68719476736
    1780:      	ldrsb	w4, [x4, x2]
    1784:      	and	x2, x3, #0x7
    1788:      	add	w2, w2, #0x3
    178c:      	cmp	w4, #0x0
    1790:      	ccmp	w2, w4, #0x1, ne
    1794:      	b.ge	0x19dc <main+0x4b8>
    1798:      	bl	0x1498 <kernel>
    179c:      	add	x22, x22, w0, uxtw
    17a0:      	add	x21, x21, #0x1
    17a4:      	cmp	x25, x21
    17a8:      	b.ne	0x16c8 <main+0x1a4>
    17ac:      	sub	x1, x19, #0x60
    17b0:      	mov	w0, #0x1                // =1
    17b4:      	bl	0x12d0 <clock_gettime@plt>
    17b8:      	mov	w20, w0
    17bc:      	cbnz	w0, 0x1a88 <main+0x564>
    17c0:      	sub	x0, x19, #0x60
    17c4:      	lsr	x2, x0, #3
    17c8:      	mov	x1, #0x1000000000       // =68719476736
    17cc:      	ldrsb	w1, [x2, x1]
    17d0:      	cbnz	w1, 0x19ec <main+0x4c8>
    17d4:      	ldur	x1, [x19, #-0x60]
    17d8:      	sub	x0, x19, #0x80
    17dc:      	lsr	x3, x0, #3
    17e0:      	mov	x2, #0x1000000000       // =68719476736
    17e4:      	ldrsb	w2, [x3, x2]
    17e8:      	cbnz	w2, 0x19f0 <main+0x4cc>
    17ec:      	ldur	x0, [x19, #-0x80]
    17f0:      	subs	x0, x1, x0
    17f4:      	b.vs	0x19f4 <main+0x4d0>
    17f8:      	scvtf	d1, x0
    17fc:      	sub	x0, x19, #0x58
    1800:      	lsr	x2, x0, #3
    1804:      	mov	x1, #0x1000000000       // =68719476736
    1808:      	ldrsb	w1, [x2, x1]
    180c:      	cbnz	w1, 0x1a08 <main+0x4e4>
    1810:      	ldur	x1, [x19, #-0x58]
    1814:      	sub	x0, x19, #0x78
    1818:      	lsr	x3, x0, #3
    181c:      	mov	x2, #0x1000000000       // =68719476736
    1820:      	ldrsb	w2, [x3, x2]
    1824:      	cbnz	w2, 0x1a0c <main+0x4e8>
    1828:      	ldur	x0, [x19, #-0x78]
    182c:      	subs	x0, x1, x0
    1830:      	b.vs	0x1a10 <main+0x4ec>
    1834:      	scvtf	d0, x0
    1838:      	adrp	x0, 0x1000 <strtoul@GLIBC_2.17+0x1000>
    183c:      	ldr	d2, [x0, #0xc70]
    1840:      	fmul	d0, d0, d2
    1844:      	mov	x2, x22
    1848:      	fadd	d0, d0, d1
    184c:      	adrp	x1, 0x1000 <strtoul@GLIBC_2.17+0x1000>
    1850:      	add	x1, x1, #0xc80
    1854:      	add	x1, x1, #0x80
    1858:      	mov	w0, #0x2                // =2
    185c:      	bl	0x1330 <__printf_chk@plt>
    1860:      	ldp	x25, x26, [sp, #0x110]
    1864:      	b	0x1a28 <main+0x504>
    1868:      	mov	x0, #0xa0               // =160
    186c:      	bl	0x1300 <__asan_stack_malloc_2@plt>
    1870:      	cmp	x0, #0x0
    1874:      	csel	x23, x23, x0, eq
    1878:      	b	0x1560 <main+0x3c>
    187c:      	stp	x25, x26, [sp, #0x110]
    1880:      	sub	x20, x19, #0x3c
    1884:      	adrp	x21, 0x1000 <strtoul@GLIBC_2.17+0x1000>
    1888:      	add	x21, x21, #0xc80
    188c:      	add	x25, x21, #0x40
    1890:      	and	x22, x20, #0x7
    1894:      	add	w22, w22, #0x3
    1898:      	b	0x18b8 <main+0x394>
    189c:      	bl	0x1260 <__asan_report_load4@plt>
    18a0:      	ldur	w1, [x19, #-0x3c]
    18a4:      	bl	0x1498 <kernel>
    18a8:      	mov	w2, w0
    18ac:      	mov	x1, x21
    18b0:      	mov	w0, #0x2                // =2
    18b4:      	bl	0x1330 <__printf_chk@plt>
    18b8:      	mov	x2, x20
    18bc:      	sub	x1, x19, #0x40
    18c0:      	mov	x0, x25
    18c4:      	bl	0x1320 <__isoc99_scanf@plt>
    18c8:      	cmp	w0, #0x2
    18cc:      	b.ne	0x1914 <main+0x3f0>
    18d0:      	sub	x0, x19, #0x40
    18d4:      	lsr	x2, x0, #3
    18d8:      	mov	x1, #0x1000000000       // =68719476736
    18dc:      	ldrsb	w1, [x2, x1]
    18e0:      	cmp	w1, #0x0
    18e4:      	mov	w2, #0x3                // =3
    18e8:      	ccmp	w2, w1, #0x1, ne
    18ec:      	b.ge	0x189c <main+0x378>
    18f0:      	ldur	w0, [x19, #-0x40]
    18f4:      	lsr	x1, x20, #3
    18f8:      	mov	x2, #0x1000000000       // =68719476736
    18fc:      	ldrsb	w1, [x1, x2]
    1900:      	cmp	w1, #0x0
    1904:      	ccmp	w22, w1, #0x1, ne
    1908:      	b.lt	0x18a0 <main+0x37c>
    190c:      	mov	x0, x20
    1910:      	bl	0x1260 <__asan_report_load4@plt>
    1914:      	mov	w20, #0x0               // =0
    1918:      	ldp	x25, x26, [sp, #0x110]
    191c:      	b	0x1a28 <main+0x504>
    1920:      	mov	x1, x20
    1924:      	adrp	x0, 0x20000 <data_start>
    1928:      	add	x0, x0, #0xe0
    192c:      	bl	0x1350 <__ubsan_handle_pointer_overflow_abort@plt>
    1930:      	adrp	x0, 0x20000 <data_start>
    1934:      	add	x0, x0, #0xe0
    1938:      	add	x0, x0, #0x40
    193c:      	bl	0x1210 <__ubsan_handle_type_mismatch_v1_abort@plt>
    1940:      	bl	0x12e0 <__asan_report_load8@plt>
    1944:      	bl	0x12a0 <__asan_handle_no_return@plt>
    1948:      	adrp	x0, 0x20000 <data_start>
    194c:      	add	x0, x0, #0xe0
    1950:      	add	x0, x0, #0x80
    1954:      	bl	0x1240 <__ubsan_handle_nonnull_arg_abort@plt>
    1958:      	mov	x1, x20
    195c:      	adrp	x0, 0x20000 <data_start>
    1960:      	add	x0, x0, #0xe0
    1964:      	add	x0, x0, #0xe0
    1968:      	bl	0x1350 <__ubsan_handle_pointer_overflow_abort@plt>
    196c:      	adrp	x0, 0x20000 <data_start>
    1970:      	add	x0, x0, #0xe0
    1974:      	add	x0, x0, #0x120
    1978:      	bl	0x1210 <__ubsan_handle_type_mismatch_v1_abort@plt>
    197c:      	bl	0x12e0 <__asan_report_load8@plt>
    1980:      	bl	0x12a0 <__asan_handle_no_return@plt>
    1984:      	adrp	x0, 0x20000 <data_start>
    1988:      	add	x0, x0, #0xe0
    198c:      	add	x0, x0, #0x160
    1990:      	bl	0x1240 <__ubsan_handle_nonnull_arg_abort@plt>
    1994:      	mov	x0, x2
    1998:      	bl	0x1200 <__asan_report_store4@plt>
    199c:      	ldr	x0, [sp, #0x8]
    19a0:      	bl	0x1260 <__asan_report_load4@plt>
    19a4:      	mov	x0, x20
    19a8:      	bl	0x1200 <__asan_report_store4@plt>
    19ac:      	sub	x3, x19, #0x3c
    19b0:      	cmn	x3, x2
    19b4:      	b.hs	0x1730 <main+0x20c>
    19b8:      	mov	x1, x3
    19bc:      	adrp	x0, 0x20000 <data_start>
    19c0:      	add	x0, x0, #0xe0
    19c4:      	add	x0, x0, #0x1c0
    19c8:      	bl	0x1210 <__ubsan_handle_type_mismatch_v1_abort@plt>
    19cc:      	mov	x0, x3
    19d0:      	bl	0x1200 <__asan_report_store4@plt>
    19d4:      	mov	x0, x20
    19d8:      	bl	0x1260 <__asan_report_load4@plt>
    19dc:      	mov	x0, x3
    19e0:      	bl	0x1260 <__asan_report_load4@plt>
    19e4:      	mov	x22, x25
    19e8:      	b	0x17ac <main+0x288>
    19ec:      	bl	0x12e0 <__asan_report_load8@plt>
    19f0:      	bl	0x12e0 <__asan_report_load8@plt>
    19f4:      	ldur	x2, [x19, #-0x80]
    19f8:      	adrp	x0, 0x20000 <data_start>
    19fc:      	add	x0, x0, #0xe0
    1a00:      	add	x0, x0, #0x200
    1a04:      	bl	0x1250 <__ubsan_handle_sub_overflow_abort@plt>
    1a08:      	bl	0x12e0 <__asan_report_load8@plt>
    1a0c:      	bl	0x12e0 <__asan_report_load8@plt>
    1a10:      	ldur	x2, [x19, #-0x78]
    1a14:      	adrp	x0, 0x20000 <data_start>
    1a18:      	add	x0, x0, #0xe0
    1a1c:      	add	x0, x0, #0x240
    1a20:      	bl	0x1250 <__ubsan_handle_sub_overflow_abort@plt>
    1a24:      	mov	w20, #0x3               // =3
    1a28:      	cmp	x28, x23
    1a2c:      	b.ne	0x1a94 <main+0x570>
    1a30:      	mov	x0, #0x1000000000       // =68719476736
    1a34:      	add	x24, x24, x0
    1a38:      	stp	xzr, xzr, [x24]
    1a3c:      	str	wzr, [x24, #0x10]
    1a40:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1d03c>
    1a44:      	ldr	x0, [x0, #0xfc8]
    1a48:      	ldr	x2, [sp, #0xc8]
    1a4c:      	ldr	x1, [x0]
    1a50:      	subs	x2, x2, x1
    1a54:      	mov	x1, #0x0                // =0
    1a58:      	b.ne	0x1ab8 <main+0x594>
    1a5c:      	mov	w0, w20
    1a60:      	ldp	x19, x20, [sp, #0xe0]
    1a64:      	ldp	x21, x22, [sp, #0xf0]
    1a68:      	ldp	x23, x24, [sp, #0x100]
    1a6c:      	ldp	x27, x28, [sp, #0x120]
    1a70:      	ldp	x29, x30, [sp, #0xd0]
    1a74:      	add	sp, sp, #0x130
    1a78:      	ret
    1a7c:      	mov	w20, #0x2               // =2
    1a80:      	ldp	x25, x26, [sp, #0x110]
    1a84:      	b	0x1a28 <main+0x504>
    1a88:      	mov	w20, #0x2               // =2
    1a8c:      	ldp	x25, x26, [sp, #0x110]
    1a90:      	b	0x1a28 <main+0x504>
    1a94:      	mov	x0, #0x360e             // =13838
    1a98:      	movk	x0, #0x45e0, lsl #16
    1a9c:      	str	x0, [x23]
    1aa0:      	mov	x0, #0x1000000000       // =68719476736
    1aa4:      	add	x1, x24, x0
    1aa8:      	movi	v0.16b, #0xf5
    1aac:      	str	q0, [x24, x0]
    1ab0:      	str	s0, [x1, #0x10]
    1ab4:      	b	0x1a40 <main+0x51c>
    1ab8:      	stp	x25, x26, [sp, #0x110]
    1abc:      	bl	0x1230 <__stack_chk_fail@plt>

0000000000001ac0 <_sub_D_00099_0>:
    1ac0:      	stp	x29, x30, [sp, #-0x10]!
    1ac4:      	mov	x29, sp
    1ac8:      	mov	x1, #0x10               // =16
    1acc:      	adrp	x0, 0x20000 <data_start>
    1ad0:      	add	x0, x0, #0xe0
    1ad4:      	add	x0, x0, #0x280
    1ad8:      	bl	0x1290 <__asan_unregister_globals@plt>
    1adc:      	ldp	x29, x30, [sp], #0x10
    1ae0:      	ret

0000000000001ae4 <_sub_I_00099_1>:
    1ae4:      	stp	x29, x30, [sp, #-0x10]!
    1ae8:      	mov	x29, sp
    1aec:      	bl	0x12b0 <__asan_init@plt>
    1af0:      	bl	0x1310 <__asan_version_mismatch_check_v8@plt>
    1af4:      	mov	x1, #0x10               // =16
    1af8:      	adrp	x0, 0x20000 <data_start>
    1afc:      	add	x0, x0, #0xe0
    1b00:      	add	x0, x0, #0x280
    1b04:      	bl	0x1220 <__asan_register_globals@plt>
    1b08:      	ldp	x29, x30, [sp], #0x10
    1b0c:      	ret

Disassembly of section .fini:

0000000000001b10 <_fini>:
    1b10:      	nop
    1b14:      	stp	x29, x30, [sp, #-0x10]!
    1b18:      	mov	x29, sp
    1b1c:      	ldp	x29, x30, [sp], #0x10
    1b20:      	ret
