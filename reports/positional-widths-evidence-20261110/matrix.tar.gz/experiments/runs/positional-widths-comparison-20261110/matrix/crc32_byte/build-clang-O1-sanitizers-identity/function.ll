; ModuleID = '/work/experiments/runs/positional-widths-comparison-20261110/matrix/crc32_byte/build-clang-O1-sanitizers-identity/validation/compiler-0-O1/candidate.i'
source_filename = "/work/experiments/runs/positional-widths-comparison-20261110/matrix/crc32_byte/build-clang-O1-sanitizers-identity/validation/compiler-0-O1/candidate.i"
target datalayout = "e-m:e-i8:8:32-i16:16:32-i64:64-i128:128-n32:64-S128"
target triple = "aarch64-unknown-linux-gnu"

$asan.module_ctor = comdat any

@llvm.used = appending global [1 x ptr] [ptr @asan.module_ctor], section "llvm.metadata"
@___asan_globals_registered = common hidden global i64 0
@__start_asan_globals = extern_weak hidden global i64
@__stop_asan_globals = extern_weak hidden global i64
@llvm.global_ctors = appending global [1 x { i32, ptr, ptr }] [{ i32, ptr, ptr } { i32 1, ptr @asan.module_ctor, ptr @asan.module_ctor }]

; Function Attrs: mustprogress nofree norecurse nosync nounwind sanitize_address willreturn memory(none) uwtable
define dso_local i32 @kernel(i32 noundef %state, i32 noundef %byte) local_unnamed_addr #0 !func_sanitize !6 {
entry:
  %and = and i32 %byte, 255
  %0 = xor i32 %and, %state
  %xor1 = xor i32 %0, -1
  %and2 = and i32 %xor1, 1
  %shr = lshr i32 %xor1, 1
  %1 = icmp eq i32 %and2, 0
  %and3 = select i1 %1, i32 0, i32 -306674912
  %xor4 = xor i32 %and3, %shr
  %shr9 = lshr i32 %xor4, 1
  %2 = and i32 %xor1, 2
  %3 = icmp eq i32 %2, 0
  %and10 = select i1 %3, i32 0, i32 -306674912
  %xor11 = xor i32 %shr9, %and10
  %shr16 = lshr i32 %xor11, 6
  %4 = and i32 %xor1, 4
  %5 = icmp eq i32 %4, 0
  %and17 = select i1 %5, i32 0, i32 124634137
  %6 = and i32 %xor1, 8
  %7 = icmp eq i32 %6, 0
  %and24 = select i1 %7, i32 0, i32 249268274
  %8 = and i32 %xor1, 16
  %9 = icmp eq i32 %8, 0
  %and31 = select i1 %9, i32 0, i32 498536548
  %10 = and i32 %xor1, 32
  %11 = icmp eq i32 %10, 0
  %and38 = select i1 %11, i32 0, i32 997073096
  %12 = and i32 %xor4, 32
  %13 = icmp eq i32 %12, 0
  %and45 = select i1 %13, i32 0, i32 1994146192
  %14 = and i32 %xor11, 32
  %15 = icmp eq i32 %14, 0
  %16 = select i1 %15, i32 -1, i32 306674911
  %xor18 = xor i32 %and24, %and17
  %xor25 = xor i32 %xor18, %and31
  %xor32 = xor i32 %xor25, %and38
  %xor39 = xor i32 %xor32, %shr16
  %xor46 = xor i32 %xor39, %and45
  %xor54 = xor i32 %xor46, %16
  ret i32 %xor54
}

declare void @__asan_register_elf_globals(i64, i64, i64)

declare void @__asan_init()

; Function Attrs: nounwind uwtable
define internal void @asan.module_ctor() #1 comdat {
  call void @__asan_init()
  call void @__asan_version_mismatch_check_v8()
  call void @__asan_register_elf_globals(i64 ptrtoint (ptr @___asan_globals_registered to i64), i64 ptrtoint (ptr @__start_asan_globals to i64), i64 ptrtoint (ptr @__stop_asan_globals to i64))
  ret void
}

declare void @__asan_version_mismatch_check_v8()

attributes #0 = { mustprogress nofree norecurse nosync nounwind sanitize_address willreturn memory(none) uwtable "frame-pointer"="non-leaf" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+fp-armv8,+neon,+outline-atomics,+v8a,-fmv" }
attributes #1 = { nounwind uwtable "frame-pointer"="non-leaf" }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 1, !"wchar_size", i32 4}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 1}
!5 = !{!"Ubuntu clang version 18.1.3 (1ubuntu1)"}
!6 = !{i32 -1056584962, i32 -455559067}
