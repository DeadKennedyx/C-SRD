
/work/experiments/runs/positional-widths-comparison-20261110/matrix/crc32_byte/build-clang-O3-limbs8/program:	file format elf64-littleaarch64

Disassembly of section .init:

0000000000000678 <_init>:
     678:      	nop
     67c:      	stp	x29, x30, [sp, #-0x10]!
     680:      	mov	x29, sp
     684:      	bl	0x774 <call_weak_fn>
     688:      	ldp	x29, x30, [sp], #0x10
     68c:      	ret

Disassembly of section .plt:

0000000000000690 <.plt>:
     690:      	stp	x16, x30, [sp, #-0x10]!
     694:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e218>
     698:      	ldr	x17, [x16, #0xff8]
     69c:      	add	x16, x16, #0xff8
     6a0:      	br	x17
     6a4:      	nop
     6a8:      	nop
     6ac:      	nop

00000000000006b0 <strtoul@plt>:
     6b0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6b4:      	ldr	x17, [x16]
     6b8:      	add	x16, x16, #0x0
     6bc:      	br	x17

00000000000006c0 <__libc_start_main@plt>:
     6c0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6c4:      	ldr	x17, [x16, #0x8]
     6c8:      	add	x16, x16, #0x8
     6cc:      	br	x17

00000000000006d0 <__cxa_finalize@plt>:
     6d0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6d4:      	ldr	x17, [x16, #0x10]
     6d8:      	add	x16, x16, #0x10
     6dc:      	br	x17

00000000000006e0 <clock_gettime@plt>:
     6e0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6e4:      	ldr	x17, [x16, #0x18]
     6e8:      	add	x16, x16, #0x18
     6ec:      	br	x17

00000000000006f0 <__gmon_start__@plt>:
     6f0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6f4:      	ldr	x17, [x16, #0x20]
     6f8:      	add	x16, x16, #0x20
     6fc:      	br	x17

0000000000000700 <abort@plt>:
     700:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     704:      	ldr	x17, [x16, #0x28]
     708:      	add	x16, x16, #0x28
     70c:      	br	x17

0000000000000710 <__isoc99_scanf@plt>:
     710:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     714:      	ldr	x17, [x16, #0x30]
     718:      	add	x16, x16, #0x30
     71c:      	br	x17

0000000000000720 <printf@plt>:
     720:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     724:      	ldr	x17, [x16, #0x38]
     728:      	add	x16, x16, #0x38
     72c:      	br	x17

Disassembly of section .text:

0000000000000740 <_start>:
     740:      	nop
     744:      	mov	x29, #0x0               // =0
     748:      	mov	x30, #0x0               // =0
     74c:      	mov	x5, x0
     750:      	ldr	x1, [sp]
     754:      	add	x2, sp, #0x8
     758:      	mov	x6, sp
     75c:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e218>
     760:      	ldr	x0, [x0, #0xfd8]
     764:      	mov	x3, #0x0                // =0
     768:      	mov	x4, #0x0                // =0
     76c:      	bl	0x6c0 <__libc_start_main@plt>
     770:      	bl	0x700 <abort@plt>

0000000000000774 <call_weak_fn>:
     774:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e218>
     778:      	ldr	x0, [x0, #0xfd0]
     77c:      	cbz	x0, 0x784 <call_weak_fn+0x10>
     780:      	b	0x6f0 <__gmon_start__@plt>
     784:      	ret
     788:      	nop
     78c:      	nop

0000000000000790 <deregister_tm_clones>:
     790:      	adrp	x0, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     794:      	add	x0, x0, #0x50
     798:      	adrp	x1, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     79c:      	add	x1, x1, #0x50
     7a0:      	cmp	x1, x0
     7a4:      	b.eq	0x7bc <deregister_tm_clones+0x2c>
     7a8:      	adrp	x1, 0x1f000 <__FRAME_END__+0x1e218>
     7ac:      	ldr	x1, [x1, #0xfc0]
     7b0:      	cbz	x1, 0x7bc <deregister_tm_clones+0x2c>
     7b4:      	mov	x16, x1
     7b8:      	br	x16
     7bc:      	ret

00000000000007c0 <register_tm_clones>:
     7c0:      	adrp	x0, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     7c4:      	add	x0, x0, #0x50
     7c8:      	adrp	x1, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     7cc:      	add	x1, x1, #0x50
     7d0:      	sub	x1, x1, x0
     7d4:      	lsr	x2, x1, #63
     7d8:      	add	x1, x2, x1, asr #3
     7dc:      	asr	x1, x1, #1
     7e0:      	cbz	x1, 0x7f8 <register_tm_clones+0x38>
     7e4:      	adrp	x2, 0x1f000 <__FRAME_END__+0x1e218>
     7e8:      	ldr	x2, [x2, #0xfe0]
     7ec:      	cbz	x2, 0x7f8 <register_tm_clones+0x38>
     7f0:      	mov	x16, x2
     7f4:      	br	x16
     7f8:      	ret
     7fc:      	nop

0000000000000800 <__do_global_dtors_aux>:
     800:      	paciasp
     804:      	stp	x29, x30, [sp, #-0x20]!
     808:      	mov	x29, sp
     80c:      	str	x19, [sp, #0x10]
     810:      	adrp	x19, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     814:      	ldrb	w0, [x19, #0x50]
     818:      	tbnz	w0, #0x0, 0x840 <__do_global_dtors_aux+0x40>
     81c:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e218>
     820:      	ldr	x0, [x0, #0xfc8]
     824:      	cbz	x0, 0x834 <__do_global_dtors_aux+0x34>
     828:      	adrp	x0, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     82c:      	ldr	x0, [x0, #0x48]
     830:      	bl	0x6d0 <__cxa_finalize@plt>
     834:      	bl	0x790 <deregister_tm_clones>
     838:      	mov	w0, #0x1                // =1
     83c:      	strb	w0, [x19, #0x50]
     840:      	ldr	x19, [sp, #0x10]
     844:      	ldp	x29, x30, [sp], #0x20
     848:      	autiasp
     84c:      	ret

0000000000000850 <frame_dummy>:
     850:      	bti	c
     854:      	b	0x7c0 <register_tm_clones>

0000000000000858 <kernel>:
     858:      	mov	w10, #-0x1              // =-1
     85c:      	eon	w13, w0, w1
     860:      	mvn	w16, w0
     864:      	eor	w12, w10, w0, lsr #8
     868:      	eor	w11, w10, w0, lsr #16
     86c:      	and	w14, w13, #0xff
     870:      	sbfx	w14, w14, #0, #1
     874:      	ubfiz	w17, w13, #5, #1
     878:      	mov	w9, #0x83               // =131
     87c:      	ubfiz	w15, w12, #7, #1
     880:      	ubfx	w12, w12, #1, #7
     884:      	lsr	w18, w16, #17
     888:      	and	w1, w14, w9
     88c:      	lsl	w0, w13, #4
     890:      	lsr	w2, w11, #1
     894:      	bfxil	w15, w13, #1, #7
     898:      	bfi	w12, w11, #7, #1
     89c:      	mov	w8, #0xb8               // =184
     8a0:      	sbfx	w13, w13, #1, #1
     8a4:      	mov	w10, #0xed              // =237
     8a8:      	and	w0, w0, #0x20
     8ac:      	eor	w15, w15, w17
     8b0:      	eor	w12, w1, w12
     8b4:      	and	w17, w18, #0x80
     8b8:      	lsr	w18, w15, #1
     8bc:      	lsr	w1, w12, #1
     8c0:      	bfxil	w17, w11, #1, #7
     8c4:      	and	w3, w14, w8
     8c8:      	and	w14, w14, w10
     8cc:      	lsr	w11, w11, #3
     8d0:      	bfi	w18, w12, #7, #1
     8d4:      	bfi	w1, w2, #7, #1
     8d8:      	and	w2, w13, w9
     8dc:      	eor	w12, w3, w17
     8e0:      	eor	w14, w14, w16, lsr #25
     8e4:      	eor	w18, w18, w0
     8e8:      	lsr	w17, w12, #1
     8ec:      	eor	w0, w1, w2
     8f0:      	lsr	w16, w18, #1
     8f4:      	lsr	w1, w0, #1
     8f8:      	mov	w2, w17
     8fc:      	orr	w16, w16, w0, lsl #7
     900:      	orr	w17, w1, w17, lsl #7
     904:      	bfi	w2, w14, #7, #1
     908:      	ubfx	w1, w15, #1, #1
     90c:      	and	w0, w13, w8
     910:      	and	w13, w13, w10
     914:      	sbfx	w15, w15, #1, #1
     918:      	and	w16, w16, #0xfe
     91c:      	eor	w0, w2, w0
     920:      	eor	w13, w13, w14, lsr #1
     924:      	eor	w14, w16, w1, lsl #5
     928:      	lsr	w16, w0, #1
     92c:      	and	w0, w15, w9
     930:      	and	w17, w17, #0xff
     934:      	ubfx	w2, w18, #1, #1
     938:      	eor	w17, w17, w0
     93c:      	lsr	w0, w14, #1
     940:      	orr	w16, w16, w13, lsl #7
     944:      	lsr	w3, w17, #1
     948:      	and	w1, w15, w8
     94c:      	and	w15, w15, w10
     950:      	bfi	w0, w17, #7, #1
     954:      	and	w16, w16, #0xff
     958:      	sbfx	w18, w18, #1, #1
     95c:      	bfi	w3, w11, #7, #1
     960:      	eor	w11, w16, w1
     964:      	eor	w13, w15, w13, lsr #1
     968:      	eor	w15, w0, w2, lsl #5
     96c:      	lsr	w16, w11, #1
     970:      	and	w17, w18, w9
     974:      	eor	w17, w3, w17
     978:      	lsr	w1, w12, #3
     97c:      	and	w12, w18, w8
     980:      	lsr	w0, w15, #1
     984:      	bfi	w16, w13, #7, #1
     988:      	lsr	w2, w17, #1
     98c:      	sbfx	w3, w14, #1, #1
     990:      	ubfx	w14, w14, #1, #1
     994:      	lsr	w11, w11, #3
     998:      	orr	w17, w0, w17, lsl #7
     99c:      	eor	w12, w16, w12
     9a0:      	and	w16, w18, w10
     9a4:      	lsr	w18, w12, #1
     9a8:      	eor	w13, w16, w13, lsr #1
     9ac:      	bfi	w2, w1, #7, #1
     9b0:      	and	w16, w17, #0xfe
     9b4:      	and	w17, w3, w9
     9b8:      	and	w0, w3, w8
     9bc:      	eor	w14, w16, w14, lsl #5
     9c0:      	mov	w16, w18
     9c4:      	eor	w17, w2, w17
     9c8:      	bfi	w16, w13, #7, #1
     9cc:      	and	w1, w3, w10
     9d0:      	lsr	w3, w17, #1
     9d4:      	lsr	w2, w14, #1
     9d8:      	eor	w13, w1, w13, lsr #1
     9dc:      	lsr	w12, w12, #3
     9e0:      	eor	w16, w16, w0
     9e4:      	ubfx	w0, w15, #1, #1
     9e8:      	sbfx	w15, w15, #1, #1
     9ec:      	bfi	w2, w17, #7, #1
     9f0:      	lsr	w16, w16, #1
     9f4:      	orr	w17, w3, w18, lsl #7
     9f8:      	eor	w18, w2, w0, lsl #5
     9fc:      	orr	w16, w16, w13, lsl #7
     a00:      	and	w0, w15, w9
     a04:      	and	w17, w17, #0xff
     a08:      	and	w2, w15, w8
     a0c:      	and	w15, w15, w10
     a10:      	lsr	w1, w18, #1
     a14:      	eor	w17, w17, w0
     a18:      	and	w16, w16, #0xfc
     a1c:      	eor	w13, w15, w13, lsr #1
     a20:      	eor	w16, w16, w2
     a24:      	ubfx	w0, w14, #1, #1
     a28:      	orr	w15, w1, w17, lsl #7
     a2c:      	lsr	w17, w17, #1
     a30:      	lsr	w16, w16, #1
     a34:      	sbfx	w14, w14, #1, #1
     a38:      	and	w15, w15, #0xfe
     a3c:      	bfi	w17, w11, #7, #1
     a40:      	bfi	w16, w13, #7, #1
     a44:      	eor	w11, w15, w0, lsl #5
     a48:      	and	w15, w14, w9
     a4c:      	and	w0, w14, w8
     a50:      	eor	w15, w17, w15
     a54:      	and	w14, w14, w10
     a58:      	eor	w16, w16, w0
     a5c:      	lsr	w11, w11, #1
     a60:      	lsr	w17, w15, #1
     a64:      	eor	w13, w14, w13, lsr #1
     a68:      	ubfx	w14, w18, #1, #1
     a6c:      	sbfx	w18, w18, #1, #1
     a70:      	bfi	w11, w15, #7, #1
     a74:      	lsr	w15, w16, #1
     a78:      	bfi	w17, w12, #7, #1
     a7c:      	and	w9, w18, w9
     a80:      	and	w8, w18, w8
     a84:      	and	w10, w18, w10
     a88:      	bfi	w15, w13, #7, #1
     a8c:      	eor	w11, w11, w14, lsl #5
     a90:      	eor	w9, w17, w9
     a94:      	eon	w10, w10, w13, lsr #1
     a98:      	eor	w8, w15, w8
     a9c:      	orr	w9, w11, w9, lsl #8
     aa0:      	lsl	w8, w8, #16
     aa4:      	orr	w9, w9, w10, lsl #24
     aa8:      	eor	w8, w8, #0xff0000
     aac:      	orr	w8, w9, w8
     ab0:      	eor	w0, w8, #0xffff
     ab4:      	ret

0000000000000ab8 <main>:
     ab8:      	sub	sp, sp, #0x50
     abc:      	stp	x29, x30, [sp, #0x20]
     ac0:      	str	x21, [sp, #0x30]
     ac4:      	stp	x20, x19, [sp, #0x40]
     ac8:      	add	x29, sp, #0x20
     acc:      	cmp	w0, #0x3
     ad0:      	b.eq	0xb3c <main+0x84>
     ad4:      	cmp	w0, #0x1
     ad8:      	b.ne	0xb94 <main+0xdc>
     adc:      	add	x21, sp, #0x10
     ae0:      	adrp	x0, 0x0 <strtoul@GLIBC_2.17>
     ae4:      	add	x0, x0, #0xc78
     ae8:      	add	x1, sp, #0x10
     aec:      	add	x2, x21, #0x4
     af0:      	bl	0x710 <__isoc99_scanf@plt>
     af4:      	cmp	w0, #0x2
     af8:      	b.ne	0xc3c <main+0x184>
     afc:      	adrp	x19, 0x0 <strtoul@GLIBC_2.17>
     b00:      	add	x19, x19, #0xc7d
     b04:      	adrp	x20, 0x0 <strtoul@GLIBC_2.17>
     b08:      	add	x20, x20, #0xc78
     b0c:      	ldp	w0, w1, [sp, #0x10]
     b10:      	bl	0x858 <kernel>
     b14:      	mov	w1, w0
     b18:      	mov	x0, x19
     b1c:      	bl	0x720 <printf@plt>
     b20:      	add	x1, sp, #0x10
     b24:      	add	x2, x21, #0x4
     b28:      	mov	x0, x20
     b2c:      	bl	0x710 <__isoc99_scanf@plt>
     b30:      	cmp	w0, #0x2
     b34:      	b.eq	0xb0c <main+0x54>
     b38:      	b	0xc3c <main+0x184>
     b3c:      	ldr	x0, [x1, #0x8]
     b40:      	mov	x19, x1
     b44:      	mov	x1, xzr
     b48:      	mov	w2, #0xa                // =10
     b4c:      	bl	0x6b0 <strtoul@plt>
     b50:      	ldr	x8, [x19, #0x10]
     b54:      	mov	x20, x0
     b58:      	mov	x1, xzr
     b5c:      	mov	w2, #0xa                // =10
     b60:      	mov	x0, x8
     b64:      	bl	0x6b0 <strtoul@plt>
     b68:      	mov	x21, x0
     b6c:      	add	x1, sp, #0x10
     b70:      	mov	w0, #0x1                // =1
     b74:      	bl	0x6e0 <clock_gettime@plt>
     b78:      	cbz	w0, 0xbac <main+0xf4>
     b7c:      	mov	w0, #0x2                // =2
     b80:      	ldp	x20, x19, [sp, #0x40]
     b84:      	ldr	x21, [sp, #0x30]
     b88:      	ldp	x29, x30, [sp, #0x20]
     b8c:      	add	sp, sp, #0x50
     b90:      	ret
     b94:      	mov	w0, #0x3                // =3
     b98:      	ldp	x20, x19, [sp, #0x40]
     b9c:      	ldr	x21, [sp, #0x30]
     ba0:      	ldp	x29, x30, [sp, #0x20]
     ba4:      	add	sp, sp, #0x50
     ba8:      	ret
     bac:      	mov	x19, xzr
     bb0:      	cbz	x20, 0xbe0 <main+0x128>
     bb4:      	eor	w8, w21, w21, lsl #13
     bb8:      	eor	w8, w8, w8, lsr #17
     bbc:      	eor	w0, w8, w8, lsl #5
     bc0:      	eor	w8, w0, w0, lsl #13
     bc4:      	eor	w8, w8, w8, lsr #17
     bc8:      	eor	w21, w8, w8, lsl #5
     bcc:      	mov	w1, w21
     bd0:      	bl	0x858 <kernel>
     bd4:      	add	x19, x19, w0, uxtw
     bd8:      	subs	x20, x20, #0x1
     bdc:      	b.ne	0xbb4 <main+0xfc>
     be0:      	mov	x1, sp
     be4:      	mov	w0, #0x1                // =1
     be8:      	bl	0x6e0 <clock_gettime@plt>
     bec:      	cbz	w0, 0xc08 <main+0x150>
     bf0:      	mov	w0, #0x2                // =2
     bf4:      	ldp	x20, x19, [sp, #0x40]
     bf8:      	ldr	x21, [sp, #0x30]
     bfc:      	ldp	x29, x30, [sp, #0x20]
     c00:      	add	sp, sp, #0x50
     c04:      	ret
     c08:      	ldp	x8, x9, [sp]
     c0c:      	adrp	x0, 0x0 <strtoul@GLIBC_2.17>
     c10:      	add	x0, x0, #0xc81
     c14:      	ldp	x10, x11, [sp, #0x10]
     c18:      	mov	x1, x19
     c1c:      	sub	x8, x8, x10
     c20:      	sub	x9, x9, x11
     c24:      	scvtf	d0, x8
     c28:      	scvtf	d1, x9
     c2c:      	adrp	x8, 0x0 <strtoul@GLIBC_2.17>
     c30:      	ldr	d2, [x8, #0xc70]
     c34:      	fmadd	d0, d1, d2, d0
     c38:      	bl	0x720 <printf@plt>
     c3c:      	mov	w0, wzr
     c40:      	ldp	x20, x19, [sp, #0x40]
     c44:      	ldr	x21, [sp, #0x30]
     c48:      	ldp	x29, x30, [sp, #0x20]
     c4c:      	add	sp, sp, #0x50
     c50:      	ret

Disassembly of section .fini:

0000000000000c54 <_fini>:
     c54:      	nop
     c58:      	stp	x29, x30, [sp, #-0x10]!
     c5c:      	mov	x29, sp
     c60:      	ldp	x29, x30, [sp], #0x10
     c64:      	ret
