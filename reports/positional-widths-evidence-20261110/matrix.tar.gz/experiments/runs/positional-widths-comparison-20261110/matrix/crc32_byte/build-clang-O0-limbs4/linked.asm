
/work/experiments/runs/positional-widths-comparison-20261110/matrix/crc32_byte/build-clang-O0-limbs4/program:	file format elf64-littleaarch64

Disassembly of section .init:

0000000000000678 <_init>:
     678:      	nop
     67c:      	stp	x29, x30, [sp, #-0x10]!
     680:      	mov	x29, sp
     684:      	bl	0x774 <call_weak_fn>
     688:      	ldp	x29, x30, [sp], #0x10
     68c:      	ret

Disassembly of section .plt:

0000000000000690 <.plt>:
     690:      	stp	x16, x30, [sp, #-0x10]!
     694:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1c5ec>
     698:      	ldr	x17, [x16, #0xff8]
     69c:      	add	x16, x16, #0xff8
     6a0:      	br	x17
     6a4:      	nop
     6a8:      	nop
     6ac:      	nop

00000000000006b0 <strtoul@plt>:
     6b0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6b4:      	ldr	x17, [x16]
     6b8:      	add	x16, x16, #0x0
     6bc:      	br	x17

00000000000006c0 <__libc_start_main@plt>:
     6c0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6c4:      	ldr	x17, [x16, #0x8]
     6c8:      	add	x16, x16, #0x8
     6cc:      	br	x17

00000000000006d0 <__cxa_finalize@plt>:
     6d0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6d4:      	ldr	x17, [x16, #0x10]
     6d8:      	add	x16, x16, #0x10
     6dc:      	br	x17

00000000000006e0 <clock_gettime@plt>:
     6e0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6e4:      	ldr	x17, [x16, #0x18]
     6e8:      	add	x16, x16, #0x18
     6ec:      	br	x17

00000000000006f0 <__gmon_start__@plt>:
     6f0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6f4:      	ldr	x17, [x16, #0x20]
     6f8:      	add	x16, x16, #0x20
     6fc:      	br	x17

0000000000000700 <abort@plt>:
     700:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     704:      	ldr	x17, [x16, #0x28]
     708:      	add	x16, x16, #0x28
     70c:      	br	x17

0000000000000710 <__isoc99_scanf@plt>:
     710:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     714:      	ldr	x17, [x16, #0x30]
     718:      	add	x16, x16, #0x30
     71c:      	br	x17

0000000000000720 <printf@plt>:
     720:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     724:      	ldr	x17, [x16, #0x38]
     728:      	add	x16, x16, #0x38
     72c:      	br	x17

Disassembly of section .text:

0000000000000740 <_start>:
     740:      	nop
     744:      	mov	x29, #0x0               // =0
     748:      	mov	x30, #0x0               // =0
     74c:      	mov	x5, x0
     750:      	ldr	x1, [sp]
     754:      	add	x2, sp, #0x8
     758:      	mov	x6, sp
     75c:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1c5ec>
     760:      	ldr	x0, [x0, #0xfd8]
     764:      	mov	x3, #0x0                // =0
     768:      	mov	x4, #0x0                // =0
     76c:      	bl	0x6c0 <__libc_start_main@plt>
     770:      	bl	0x700 <abort@plt>

0000000000000774 <call_weak_fn>:
     774:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1c5ec>
     778:      	ldr	x0, [x0, #0xfd0]
     77c:      	cbz	x0, 0x784 <call_weak_fn+0x10>
     780:      	b	0x6f0 <__gmon_start__@plt>
     784:      	ret
     788:      	nop
     78c:      	nop

0000000000000790 <deregister_tm_clones>:
     790:      	adrp	x0, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     794:      	add	x0, x0, #0x50
     798:      	adrp	x1, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     79c:      	add	x1, x1, #0x50
     7a0:      	cmp	x1, x0
     7a4:      	b.eq	0x7bc <deregister_tm_clones+0x2c>
     7a8:      	adrp	x1, 0x1f000 <__FRAME_END__+0x1c5ec>
     7ac:      	ldr	x1, [x1, #0xfc0]
     7b0:      	cbz	x1, 0x7bc <deregister_tm_clones+0x2c>
     7b4:      	mov	x16, x1
     7b8:      	br	x16
     7bc:      	ret

00000000000007c0 <register_tm_clones>:
     7c0:      	adrp	x0, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     7c4:      	add	x0, x0, #0x50
     7c8:      	adrp	x1, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     7cc:      	add	x1, x1, #0x50
     7d0:      	sub	x1, x1, x0
     7d4:      	lsr	x2, x1, #63
     7d8:      	add	x1, x2, x1, asr #3
     7dc:      	asr	x1, x1, #1
     7e0:      	cbz	x1, 0x7f8 <register_tm_clones+0x38>
     7e4:      	adrp	x2, 0x1f000 <__FRAME_END__+0x1c5ec>
     7e8:      	ldr	x2, [x2, #0xfe0]
     7ec:      	cbz	x2, 0x7f8 <register_tm_clones+0x38>
     7f0:      	mov	x16, x2
     7f4:      	br	x16
     7f8:      	ret
     7fc:      	nop

0000000000000800 <__do_global_dtors_aux>:
     800:      	paciasp
     804:      	stp	x29, x30, [sp, #-0x20]!
     808:      	mov	x29, sp
     80c:      	str	x19, [sp, #0x10]
     810:      	adrp	x19, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     814:      	ldrb	w0, [x19, #0x50]
     818:      	tbnz	w0, #0x0, 0x840 <__do_global_dtors_aux+0x40>
     81c:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1c5ec>
     820:      	ldr	x0, [x0, #0xfc8]
     824:      	cbz	x0, 0x834 <__do_global_dtors_aux+0x34>
     828:      	adrp	x0, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     82c:      	ldr	x0, [x0, #0x48]
     830:      	bl	0x6d0 <__cxa_finalize@plt>
     834:      	bl	0x790 <deregister_tm_clones>
     838:      	mov	w0, #0x1                // =1
     83c:      	strb	w0, [x19, #0x50]
     840:      	ldr	x19, [sp, #0x10]
     844:      	ldp	x29, x30, [sp], #0x20
     848:      	autiasp
     84c:      	ret

0000000000000850 <frame_dummy>:
     850:      	bti	c
     854:      	b	0x7c0 <register_tm_clones>

0000000000000858 <kernel>:
     858:      	str	x29, [sp, #-0x10]!
     85c:      	sub	sp, sp, #0x790
     860:      	str	w0, [sp, #0x78c]
     864:      	str	w1, [sp, #0x788]
     868:      	ldr	w8, [sp, #0x78c]
     86c:      	and	w8, w8, #0xf
     870:      	str	w8, [sp, #0x784]
     874:      	ldr	w8, [sp, #0x78c]
     878:      	lsr	w8, w8, #4
     87c:      	and	w8, w8, #0xf
     880:      	str	w8, [sp, #0x780]
     884:      	ldr	w8, [sp, #0x78c]
     888:      	mov	w11, #0x8               // =8
     88c:      	lsr	w8, w8, #8
     890:      	and	w8, w8, #0xf
     894:      	str	w8, [sp, #0x77c]
     898:      	ldr	w8, [sp, #0x78c]
     89c:      	lsr	w8, w8, #12
     8a0:      	and	w8, w8, #0xf
     8a4:      	str	w8, [sp, #0x778]
     8a8:      	ldr	w8, [sp, #0x78c]
     8ac:      	lsr	w8, w8, #16
     8b0:      	and	w8, w8, #0xf
     8b4:      	str	w8, [sp, #0x774]
     8b8:      	ldr	w8, [sp, #0x78c]
     8bc:      	lsr	w8, w8, #20
     8c0:      	and	w8, w8, #0xf
     8c4:      	str	w8, [sp, #0x770]
     8c8:      	ldr	w8, [sp, #0x78c]
     8cc:      	lsr	w8, w8, #24
     8d0:      	and	w8, w8, #0xf
     8d4:      	str	w8, [sp, #0x76c]
     8d8:      	ldr	w8, [sp, #0x78c]
     8dc:      	lsr	w8, w8, #28
     8e0:      	and	w8, w8, #0xf
     8e4:      	str	w8, [sp, #0x768]
     8e8:      	ldr	w8, [sp, #0x788]
     8ec:      	and	w8, w8, #0xf
     8f0:      	str	w8, [sp, #0x764]
     8f4:      	ldr	w8, [sp, #0x788]
     8f8:      	lsr	w8, w8, #4
     8fc:      	and	w8, w8, #0xf
     900:      	str	w8, [sp, #0x760]
     904:      	ldr	w8, [sp, #0x788]
     908:      	lsr	w8, w8, #8
     90c:      	and	w8, w8, #0xf
     910:      	str	w8, [sp, #0x75c]
     914:      	ldr	w8, [sp, #0x788]
     918:      	lsr	w8, w8, #12
     91c:      	and	w8, w8, #0xf
     920:      	str	w8, [sp, #0x758]
     924:      	ldr	w8, [sp, #0x788]
     928:      	lsr	w8, w8, #16
     92c:      	and	w8, w8, #0xf
     930:      	str	w8, [sp, #0x754]
     934:      	ldr	w8, [sp, #0x788]
     938:      	lsr	w8, w8, #20
     93c:      	and	w8, w8, #0xf
     940:      	str	w8, [sp, #0x750]
     944:      	ldr	w8, [sp, #0x788]
     948:      	lsr	w8, w8, #24
     94c:      	and	w8, w8, #0xf
     950:      	str	w8, [sp, #0x74c]
     954:      	ldr	w8, [sp, #0x788]
     958:      	lsr	w8, w8, #28
     95c:      	and	w8, w8, #0xf
     960:      	str	w8, [sp, #0x748]
     964:      	ldr	w8, [sp, #0x784]
     968:      	eor	w8, w8, #0xf
     96c:      	str	w8, [sp, #0x744]
     970:      	ldr	w8, [sp, #0x780]
     974:      	eor	w8, w8, #0xf
     978:      	str	w8, [sp, #0x740]
     97c:      	ldr	w8, [sp, #0x77c]
     980:      	eor	w8, w8, #0xf
     984:      	str	w8, [sp, #0x73c]
     988:      	ldr	w8, [sp, #0x778]
     98c:      	eor	w8, w8, #0xf
     990:      	str	w8, [sp, #0x738]
     994:      	ldr	w8, [sp, #0x774]
     998:      	eor	w8, w8, #0xf
     99c:      	str	w8, [sp, #0x734]
     9a0:      	ldr	w8, [sp, #0x770]
     9a4:      	eor	w8, w8, #0xf
     9a8:      	str	w8, [sp, #0x730]
     9ac:      	ldr	w8, [sp, #0x76c]
     9b0:      	eor	w8, w8, #0xf
     9b4:      	str	w8, [sp, #0x72c]
     9b8:      	ldr	w8, [sp, #0x768]
     9bc:      	eor	w8, w8, #0xf
     9c0:      	str	w8, [sp, #0x728]
     9c4:      	ldr	w8, [sp, #0x764]
     9c8:      	and	w8, w8, #0xf
     9cc:      	str	w8, [sp, #0x724]
     9d0:      	ldr	w8, [sp, #0x760]
     9d4:      	and	w8, w8, #0xf
     9d8:      	str	w8, [sp, #0x720]
     9dc:      	ldr	w8, [sp, #0x75c]
     9e0:      	mov	w14, wzr
     9e4:      	and	w8, w8, w14
     9e8:      	str	w8, [sp, #0x71c]
     9ec:      	ldr	w8, [sp, #0x758]
     9f0:      	and	w8, w8, w14
     9f4:      	str	w8, [sp, #0x718]
     9f8:      	ldr	w8, [sp, #0x754]
     9fc:      	and	w8, w8, w14
     a00:      	str	w8, [sp, #0x714]
     a04:      	ldr	w8, [sp, #0x750]
     a08:      	and	w8, w8, w14
     a0c:      	str	w8, [sp, #0x710]
     a10:      	ldr	w8, [sp, #0x74c]
     a14:      	and	w8, w8, w14
     a18:      	str	w8, [sp, #0x70c]
     a1c:      	ldr	w8, [sp, #0x748]
     a20:      	and	w8, w8, w14
     a24:      	str	w8, [sp, #0x708]
     a28:      	ldr	w8, [sp, #0x744]
     a2c:      	ldr	w9, [sp, #0x724]
     a30:      	eor	w8, w8, w9
     a34:      	str	w8, [sp, #0x704]
     a38:      	ldr	w8, [sp, #0x740]
     a3c:      	ldr	w9, [sp, #0x720]
     a40:      	eor	w8, w8, w9
     a44:      	str	w8, [sp, #0x700]
     a48:      	ldr	w8, [sp, #0x73c]
     a4c:      	ldr	w9, [sp, #0x71c]
     a50:      	eor	w8, w8, w9
     a54:      	str	w8, [sp, #0x6fc]
     a58:      	ldr	w8, [sp, #0x738]
     a5c:      	ldr	w9, [sp, #0x718]
     a60:      	eor	w8, w8, w9
     a64:      	str	w8, [sp, #0x6f8]
     a68:      	ldr	w8, [sp, #0x734]
     a6c:      	ldr	w9, [sp, #0x714]
     a70:      	eor	w8, w8, w9
     a74:      	str	w8, [sp, #0x6f4]
     a78:      	ldr	w8, [sp, #0x730]
     a7c:      	ldr	w9, [sp, #0x710]
     a80:      	eor	w8, w8, w9
     a84:      	str	w8, [sp, #0x6f0]
     a88:      	ldr	w8, [sp, #0x72c]
     a8c:      	ldr	w9, [sp, #0x70c]
     a90:      	eor	w8, w8, w9
     a94:      	str	w8, [sp, #0x6ec]
     a98:      	ldr	w8, [sp, #0x728]
     a9c:      	ldr	w9, [sp, #0x708]
     aa0:      	eor	w8, w8, w9
     aa4:      	str	w8, [sp, #0x6e8]
     aa8:      	ldr	w8, [sp, #0x704]
     aac:      	and	w8, w8, #0x1
     ab0:      	str	w8, [sp, #0x6e4]
     ab4:      	ldr	w8, [sp, #0x700]
     ab8:      	and	w8, w8, w14
     abc:      	str	w8, [sp, #0x6e0]
     ac0:      	ldr	w8, [sp, #0x6fc]
     ac4:      	and	w8, w8, w14
     ac8:      	str	w8, [sp, #0x6dc]
     acc:      	ldr	w8, [sp, #0x6f8]
     ad0:      	and	w8, w8, w14
     ad4:      	str	w8, [sp, #0x6d8]
     ad8:      	ldr	w8, [sp, #0x6f4]
     adc:      	and	w8, w8, w14
     ae0:      	str	w8, [sp, #0x6d4]
     ae4:      	ldr	w8, [sp, #0x6f0]
     ae8:      	and	w8, w8, w14
     aec:      	str	w8, [sp, #0x6d0]
     af0:      	ldr	w8, [sp, #0x6ec]
     af4:      	and	w8, w8, w14
     af8:      	str	w8, [sp, #0x6cc]
     afc:      	ldr	w8, [sp, #0x6e8]
     b00:      	and	w8, w8, w14
     b04:      	str	w8, [sp, #0x6c8]
     b08:      	ldr	w8, [sp, #0x6e4]
     b0c:      	subs	w8, w14, w8
     b10:      	and	w8, w8, #0xf
     b14:      	str	w8, [sp, #0x6c4]
     b18:      	ldr	w8, [sp, #0x6e4]
     b1c:      	subs	w8, w14, w8
     b20:      	cset	w8, lo
     b24:      	str	w8, [sp, #0x6c0]
     b28:      	ldr	w8, [sp, #0x6e0]
     b2c:      	ldr	w9, [sp, #0x6c0]
     b30:      	add	w8, w8, w9
     b34:      	str	w8, [sp, #0x6bc]
     b38:      	ldr	w8, [sp, #0x6bc]
     b3c:      	subs	w8, w14, w8
     b40:      	and	w8, w8, #0xf
     b44:      	str	w8, [sp, #0x6b8]
     b48:      	ldr	w8, [sp, #0x6bc]
     b4c:      	subs	w8, w14, w8
     b50:      	cset	w8, lo
     b54:      	str	w8, [sp, #0x6b4]
     b58:      	ldr	w8, [sp, #0x6dc]
     b5c:      	ldr	w9, [sp, #0x6b4]
     b60:      	add	w8, w8, w9
     b64:      	str	w8, [sp, #0x6b0]
     b68:      	ldr	w8, [sp, #0x6b0]
     b6c:      	subs	w8, w14, w8
     b70:      	and	w8, w8, #0xf
     b74:      	str	w8, [sp, #0x6ac]
     b78:      	ldr	w8, [sp, #0x6b0]
     b7c:      	subs	w8, w14, w8
     b80:      	cset	w8, lo
     b84:      	str	w8, [sp, #0x6a8]
     b88:      	ldr	w8, [sp, #0x6d8]
     b8c:      	ldr	w9, [sp, #0x6a8]
     b90:      	add	w8, w8, w9
     b94:      	str	w8, [sp, #0x6a4]
     b98:      	ldr	w8, [sp, #0x6a4]
     b9c:      	subs	w8, w14, w8
     ba0:      	and	w8, w8, #0xf
     ba4:      	str	w8, [sp, #0x6a0]
     ba8:      	ldr	w8, [sp, #0x6a4]
     bac:      	subs	w8, w14, w8
     bb0:      	cset	w8, lo
     bb4:      	str	w8, [sp, #0x69c]
     bb8:      	ldr	w8, [sp, #0x6d4]
     bbc:      	ldr	w9, [sp, #0x69c]
     bc0:      	add	w8, w8, w9
     bc4:      	str	w8, [sp, #0x698]
     bc8:      	ldr	w8, [sp, #0x698]
     bcc:      	subs	w8, w14, w8
     bd0:      	and	w8, w8, #0xf
     bd4:      	str	w8, [sp, #0x694]
     bd8:      	ldr	w8, [sp, #0x698]
     bdc:      	subs	w8, w14, w8
     be0:      	cset	w8, lo
     be4:      	str	w8, [sp, #0x690]
     be8:      	ldr	w8, [sp, #0x6d0]
     bec:      	ldr	w9, [sp, #0x690]
     bf0:      	add	w8, w8, w9
     bf4:      	str	w8, [sp, #0x68c]
     bf8:      	ldr	w8, [sp, #0x68c]
     bfc:      	subs	w8, w14, w8
     c00:      	and	w8, w8, #0xf
     c04:      	str	w8, [sp, #0x688]
     c08:      	ldr	w8, [sp, #0x68c]
     c0c:      	subs	w8, w14, w8
     c10:      	cset	w8, lo
     c14:      	str	w8, [sp, #0x684]
     c18:      	ldr	w8, [sp, #0x6cc]
     c1c:      	ldr	w9, [sp, #0x684]
     c20:      	add	w8, w8, w9
     c24:      	str	w8, [sp, #0x680]
     c28:      	ldr	w8, [sp, #0x680]
     c2c:      	subs	w8, w14, w8
     c30:      	and	w8, w8, #0xf
     c34:      	str	w8, [sp, #0x67c]
     c38:      	ldr	w8, [sp, #0x680]
     c3c:      	subs	w8, w14, w8
     c40:      	cset	w8, lo
     c44:      	str	w8, [sp, #0x678]
     c48:      	ldr	w8, [sp, #0x6c8]
     c4c:      	ldr	w9, [sp, #0x678]
     c50:      	add	w8, w8, w9
     c54:      	str	w8, [sp, #0x674]
     c58:      	ldr	w8, [sp, #0x674]
     c5c:      	subs	w8, w14, w8
     c60:      	and	w8, w8, #0xf
     c64:      	str	w8, [sp, #0x670]
     c68:      	ldr	w9, [sp, #0x704]
     c6c:      	ldr	w8, [sp, #0x700]
     c70:      	mov	w12, #0x3               // =3
     c74:      	lsl	w8, w8, #3
     c78:      	orr	w8, w8, w9, lsr #1
     c7c:      	and	w8, w8, #0xf
     c80:      	str	w8, [sp, #0x66c]
     c84:      	ldr	w9, [sp, #0x700]
     c88:      	ldr	w8, [sp, #0x6fc]
     c8c:      	lsl	w8, w8, #3
     c90:      	orr	w8, w8, w9, lsr #1
     c94:      	and	w8, w8, #0xf
     c98:      	str	w8, [sp, #0x668]
     c9c:      	ldr	w9, [sp, #0x6fc]
     ca0:      	ldr	w8, [sp, #0x6f8]
     ca4:      	lsl	w8, w8, #3
     ca8:      	orr	w8, w8, w9, lsr #1
     cac:      	and	w8, w8, #0xf
     cb0:      	str	w8, [sp, #0x664]
     cb4:      	ldr	w9, [sp, #0x6f8]
     cb8:      	ldr	w8, [sp, #0x6f4]
     cbc:      	lsl	w8, w8, #3
     cc0:      	orr	w8, w8, w9, lsr #1
     cc4:      	and	w8, w8, #0xf
     cc8:      	str	w8, [sp, #0x660]
     ccc:      	ldr	w9, [sp, #0x6f4]
     cd0:      	ldr	w8, [sp, #0x6f0]
     cd4:      	lsl	w8, w8, #3
     cd8:      	orr	w8, w8, w9, lsr #1
     cdc:      	and	w8, w8, #0xf
     ce0:      	str	w8, [sp, #0x65c]
     ce4:      	ldr	w9, [sp, #0x6f0]
     ce8:      	ldr	w8, [sp, #0x6ec]
     cec:      	lsl	w8, w8, #3
     cf0:      	orr	w8, w8, w9, lsr #1
     cf4:      	and	w8, w8, #0xf
     cf8:      	str	w8, [sp, #0x658]
     cfc:      	ldr	w9, [sp, #0x6ec]
     d00:      	ldr	w8, [sp, #0x6e8]
     d04:      	lsl	w8, w8, #3
     d08:      	orr	w8, w8, w9, lsr #1
     d0c:      	and	w8, w8, #0xf
     d10:      	str	w8, [sp, #0x654]
     d14:      	ldr	w8, [sp, #0x6e8]
     d18:      	lsr	w8, w8, #1
     d1c:      	and	w8, w8, #0xf
     d20:      	str	w8, [sp, #0x650]
     d24:      	ldr	w8, [sp, #0x6c4]
     d28:      	and	w8, w14, w8
     d2c:      	str	w8, [sp, #0x64c]
     d30:      	ldr	w8, [sp, #0x6b8]
     d34:      	mov	w13, #0x2               // =2
     d38:      	and	w8, w13, w8
     d3c:      	str	w8, [sp, #0x648]
     d40:      	ldr	w8, [sp, #0x6ac]
     d44:      	and	w8, w12, w8
     d48:      	str	w8, [sp, #0x644]
     d4c:      	ldr	w8, [sp, #0x6a0]
     d50:      	and	w8, w11, w8
     d54:      	str	w8, [sp, #0x640]
     d58:      	ldr	w8, [sp, #0x694]
     d5c:      	and	w8, w11, w8
     d60:      	str	w8, [sp, #0x63c]
     d64:      	ldr	w8, [sp, #0x688]
     d68:      	mov	w10, #0xb               // =11
     d6c:      	and	w8, w10, w8
     d70:      	str	w8, [sp, #0x638]
     d74:      	ldr	w8, [sp, #0x67c]
     d78:      	mov	w9, #0xd                // =13
     d7c:      	and	w8, w9, w8
     d80:      	str	w8, [sp, #0x634]
     d84:      	ldr	w15, [sp, #0x670]
     d88:      	mov	w8, #0xe                // =14
     d8c:      	and	w15, w8, w15
     d90:      	str	w15, [sp, #0x630]
     d94:      	ldr	w15, [sp, #0x66c]
     d98:      	ldr	w16, [sp, #0x64c]
     d9c:      	eor	w15, w15, w16
     da0:      	str	w15, [sp, #0x62c]
     da4:      	ldr	w15, [sp, #0x668]
     da8:      	ldr	w16, [sp, #0x648]
     dac:      	eor	w15, w15, w16
     db0:      	str	w15, [sp, #0x628]
     db4:      	ldr	w15, [sp, #0x664]
     db8:      	ldr	w16, [sp, #0x644]
     dbc:      	eor	w15, w15, w16
     dc0:      	str	w15, [sp, #0x624]
     dc4:      	ldr	w15, [sp, #0x660]
     dc8:      	ldr	w16, [sp, #0x640]
     dcc:      	eor	w15, w15, w16
     dd0:      	str	w15, [sp, #0x620]
     dd4:      	ldr	w15, [sp, #0x65c]
     dd8:      	ldr	w16, [sp, #0x63c]
     ddc:      	eor	w15, w15, w16
     de0:      	str	w15, [sp, #0x61c]
     de4:      	ldr	w15, [sp, #0x658]
     de8:      	ldr	w16, [sp, #0x638]
     dec:      	eor	w15, w15, w16
     df0:      	str	w15, [sp, #0x618]
     df4:      	ldr	w15, [sp, #0x654]
     df8:      	ldr	w16, [sp, #0x634]
     dfc:      	eor	w15, w15, w16
     e00:      	str	w15, [sp, #0x614]
     e04:      	ldr	w15, [sp, #0x650]
     e08:      	ldr	w16, [sp, #0x630]
     e0c:      	eor	w15, w15, w16
     e10:      	str	w15, [sp, #0x610]
     e14:      	ldr	w15, [sp, #0x62c]
     e18:      	and	w15, w15, #0x1
     e1c:      	str	w15, [sp, #0x60c]
     e20:      	ldr	w15, [sp, #0x628]
     e24:      	and	w15, w15, w14
     e28:      	str	w15, [sp, #0x608]
     e2c:      	ldr	w15, [sp, #0x624]
     e30:      	and	w15, w15, w14
     e34:      	str	w15, [sp, #0x604]
     e38:      	ldr	w15, [sp, #0x620]
     e3c:      	and	w15, w15, w14
     e40:      	str	w15, [sp, #0x600]
     e44:      	ldr	w15, [sp, #0x61c]
     e48:      	and	w15, w15, w14
     e4c:      	str	w15, [sp, #0x5fc]
     e50:      	ldr	w15, [sp, #0x618]
     e54:      	and	w15, w15, w14
     e58:      	str	w15, [sp, #0x5f8]
     e5c:      	ldr	w15, [sp, #0x614]
     e60:      	and	w15, w15, w14
     e64:      	str	w15, [sp, #0x5f4]
     e68:      	ldr	w15, [sp, #0x610]
     e6c:      	and	w15, w15, w14
     e70:      	str	w15, [sp, #0x5f0]
     e74:      	ldr	w15, [sp, #0x60c]
     e78:      	subs	w15, w14, w15
     e7c:      	and	w15, w15, #0xf
     e80:      	str	w15, [sp, #0x5ec]
     e84:      	ldr	w15, [sp, #0x60c]
     e88:      	subs	w15, w14, w15
     e8c:      	cset	w15, lo
     e90:      	str	w15, [sp, #0x5e8]
     e94:      	ldr	w15, [sp, #0x608]
     e98:      	ldr	w16, [sp, #0x5e8]
     e9c:      	add	w15, w15, w16
     ea0:      	str	w15, [sp, #0x5e4]
     ea4:      	ldr	w15, [sp, #0x5e4]
     ea8:      	subs	w15, w14, w15
     eac:      	and	w15, w15, #0xf
     eb0:      	str	w15, [sp, #0x5e0]
     eb4:      	ldr	w15, [sp, #0x5e4]
     eb8:      	subs	w15, w14, w15
     ebc:      	cset	w15, lo
     ec0:      	str	w15, [sp, #0x5dc]
     ec4:      	ldr	w15, [sp, #0x604]
     ec8:      	ldr	w16, [sp, #0x5dc]
     ecc:      	add	w15, w15, w16
     ed0:      	str	w15, [sp, #0x5d8]
     ed4:      	ldr	w15, [sp, #0x5d8]
     ed8:      	subs	w15, w14, w15
     edc:      	and	w15, w15, #0xf
     ee0:      	str	w15, [sp, #0x5d4]
     ee4:      	ldr	w15, [sp, #0x5d8]
     ee8:      	subs	w15, w14, w15
     eec:      	cset	w15, lo
     ef0:      	str	w15, [sp, #0x5d0]
     ef4:      	ldr	w15, [sp, #0x600]
     ef8:      	ldr	w16, [sp, #0x5d0]
     efc:      	add	w15, w15, w16
     f00:      	str	w15, [sp, #0x5cc]
     f04:      	ldr	w15, [sp, #0x5cc]
     f08:      	subs	w15, w14, w15
     f0c:      	and	w15, w15, #0xf
     f10:      	str	w15, [sp, #0x5c8]
     f14:      	ldr	w15, [sp, #0x5cc]
     f18:      	subs	w15, w14, w15
     f1c:      	cset	w15, lo
     f20:      	str	w15, [sp, #0x5c4]
     f24:      	ldr	w15, [sp, #0x5fc]
     f28:      	ldr	w16, [sp, #0x5c4]
     f2c:      	add	w15, w15, w16
     f30:      	str	w15, [sp, #0x5c0]
     f34:      	ldr	w15, [sp, #0x5c0]
     f38:      	subs	w15, w14, w15
     f3c:      	and	w15, w15, #0xf
     f40:      	str	w15, [sp, #0x5bc]
     f44:      	ldr	w15, [sp, #0x5c0]
     f48:      	subs	w15, w14, w15
     f4c:      	cset	w15, lo
     f50:      	str	w15, [sp, #0x5b8]
     f54:      	ldr	w15, [sp, #0x5f8]
     f58:      	ldr	w16, [sp, #0x5b8]
     f5c:      	add	w15, w15, w16
     f60:      	str	w15, [sp, #0x5b4]
     f64:      	ldr	w15, [sp, #0x5b4]
     f68:      	subs	w15, w14, w15
     f6c:      	and	w15, w15, #0xf
     f70:      	str	w15, [sp, #0x5b0]
     f74:      	ldr	w15, [sp, #0x5b4]
     f78:      	subs	w15, w14, w15
     f7c:      	cset	w15, lo
     f80:      	str	w15, [sp, #0x5ac]
     f84:      	ldr	w15, [sp, #0x5f4]
     f88:      	ldr	w16, [sp, #0x5ac]
     f8c:      	add	w15, w15, w16
     f90:      	str	w15, [sp, #0x5a8]
     f94:      	ldr	w15, [sp, #0x5a8]
     f98:      	subs	w15, w14, w15
     f9c:      	and	w15, w15, #0xf
     fa0:      	str	w15, [sp, #0x5a4]
     fa4:      	ldr	w15, [sp, #0x5a8]
     fa8:      	subs	w15, w14, w15
     fac:      	cset	w15, lo
     fb0:      	str	w15, [sp, #0x5a0]
     fb4:      	ldr	w15, [sp, #0x5f0]
     fb8:      	ldr	w16, [sp, #0x5a0]
     fbc:      	add	w15, w15, w16
     fc0:      	str	w15, [sp, #0x59c]
     fc4:      	ldr	w15, [sp, #0x59c]
     fc8:      	subs	w15, w14, w15
     fcc:      	and	w15, w15, #0xf
     fd0:      	str	w15, [sp, #0x598]
     fd4:      	ldr	w16, [sp, #0x62c]
     fd8:      	ldr	w15, [sp, #0x628]
     fdc:      	lsl	w15, w15, #3
     fe0:      	orr	w15, w15, w16, lsr #1
     fe4:      	and	w15, w15, #0xf
     fe8:      	str	w15, [sp, #0x594]
     fec:      	ldr	w16, [sp, #0x628]
     ff0:      	ldr	w15, [sp, #0x624]
     ff4:      	lsl	w15, w15, #3
     ff8:      	orr	w15, w15, w16, lsr #1
     ffc:      	and	w15, w15, #0xf
    1000:      	str	w15, [sp, #0x590]
    1004:      	ldr	w16, [sp, #0x624]
    1008:      	ldr	w15, [sp, #0x620]
    100c:      	lsl	w15, w15, #3
    1010:      	orr	w15, w15, w16, lsr #1
    1014:      	and	w15, w15, #0xf
    1018:      	str	w15, [sp, #0x58c]
    101c:      	ldr	w16, [sp, #0x620]
    1020:      	ldr	w15, [sp, #0x61c]
    1024:      	lsl	w15, w15, #3
    1028:      	orr	w15, w15, w16, lsr #1
    102c:      	and	w15, w15, #0xf
    1030:      	str	w15, [sp, #0x588]
    1034:      	ldr	w16, [sp, #0x61c]
    1038:      	ldr	w15, [sp, #0x618]
    103c:      	lsl	w15, w15, #3
    1040:      	orr	w15, w15, w16, lsr #1
    1044:      	and	w15, w15, #0xf
    1048:      	str	w15, [sp, #0x584]
    104c:      	ldr	w16, [sp, #0x618]
    1050:      	ldr	w15, [sp, #0x614]
    1054:      	lsl	w15, w15, #3
    1058:      	orr	w15, w15, w16, lsr #1
    105c:      	and	w15, w15, #0xf
    1060:      	str	w15, [sp, #0x580]
    1064:      	ldr	w16, [sp, #0x614]
    1068:      	ldr	w15, [sp, #0x610]
    106c:      	lsl	w15, w15, #3
    1070:      	orr	w15, w15, w16, lsr #1
    1074:      	and	w15, w15, #0xf
    1078:      	str	w15, [sp, #0x57c]
    107c:      	ldr	w15, [sp, #0x610]
    1080:      	lsr	w15, w15, #1
    1084:      	and	w15, w15, #0xf
    1088:      	str	w15, [sp, #0x578]
    108c:      	ldr	w15, [sp, #0x5ec]
    1090:      	and	w15, w14, w15
    1094:      	str	w15, [sp, #0x574]
    1098:      	ldr	w15, [sp, #0x5e0]
    109c:      	and	w15, w13, w15
    10a0:      	str	w15, [sp, #0x570]
    10a4:      	ldr	w15, [sp, #0x5d4]
    10a8:      	and	w15, w12, w15
    10ac:      	str	w15, [sp, #0x56c]
    10b0:      	ldr	w15, [sp, #0x5c8]
    10b4:      	and	w15, w11, w15
    10b8:      	str	w15, [sp, #0x568]
    10bc:      	ldr	w15, [sp, #0x5bc]
    10c0:      	and	w15, w11, w15
    10c4:      	str	w15, [sp, #0x564]
    10c8:      	ldr	w15, [sp, #0x5b0]
    10cc:      	and	w15, w10, w15
    10d0:      	str	w15, [sp, #0x560]
    10d4:      	ldr	w15, [sp, #0x5a4]
    10d8:      	and	w15, w9, w15
    10dc:      	str	w15, [sp, #0x55c]
    10e0:      	ldr	w15, [sp, #0x598]
    10e4:      	and	w15, w8, w15
    10e8:      	str	w15, [sp, #0x558]
    10ec:      	ldr	w15, [sp, #0x594]
    10f0:      	ldr	w16, [sp, #0x574]
    10f4:      	eor	w15, w15, w16
    10f8:      	str	w15, [sp, #0x554]
    10fc:      	ldr	w15, [sp, #0x590]
    1100:      	ldr	w16, [sp, #0x570]
    1104:      	eor	w15, w15, w16
    1108:      	str	w15, [sp, #0x550]
    110c:      	ldr	w15, [sp, #0x58c]
    1110:      	ldr	w16, [sp, #0x56c]
    1114:      	eor	w15, w15, w16
    1118:      	str	w15, [sp, #0x54c]
    111c:      	ldr	w15, [sp, #0x588]
    1120:      	ldr	w16, [sp, #0x568]
    1124:      	eor	w15, w15, w16
    1128:      	str	w15, [sp, #0x548]
    112c:      	ldr	w15, [sp, #0x584]
    1130:      	ldr	w16, [sp, #0x564]
    1134:      	eor	w15, w15, w16
    1138:      	str	w15, [sp, #0x544]
    113c:      	ldr	w15, [sp, #0x580]
    1140:      	ldr	w16, [sp, #0x560]
    1144:      	eor	w15, w15, w16
    1148:      	str	w15, [sp, #0x540]
    114c:      	ldr	w15, [sp, #0x57c]
    1150:      	ldr	w16, [sp, #0x55c]
    1154:      	eor	w15, w15, w16
    1158:      	str	w15, [sp, #0x53c]
    115c:      	ldr	w15, [sp, #0x578]
    1160:      	ldr	w16, [sp, #0x558]
    1164:      	eor	w15, w15, w16
    1168:      	str	w15, [sp, #0x538]
    116c:      	ldr	w15, [sp, #0x554]
    1170:      	and	w15, w15, #0x1
    1174:      	str	w15, [sp, #0x534]
    1178:      	ldr	w15, [sp, #0x550]
    117c:      	and	w15, w15, w14
    1180:      	str	w15, [sp, #0x530]
    1184:      	ldr	w15, [sp, #0x54c]
    1188:      	and	w15, w15, w14
    118c:      	str	w15, [sp, #0x52c]
    1190:      	ldr	w15, [sp, #0x548]
    1194:      	and	w15, w15, w14
    1198:      	str	w15, [sp, #0x528]
    119c:      	ldr	w15, [sp, #0x544]
    11a0:      	and	w15, w15, w14
    11a4:      	str	w15, [sp, #0x524]
    11a8:      	ldr	w15, [sp, #0x540]
    11ac:      	and	w15, w15, w14
    11b0:      	str	w15, [sp, #0x520]
    11b4:      	ldr	w15, [sp, #0x53c]
    11b8:      	and	w15, w15, w14
    11bc:      	str	w15, [sp, #0x51c]
    11c0:      	ldr	w15, [sp, #0x538]
    11c4:      	and	w15, w15, w14
    11c8:      	str	w15, [sp, #0x518]
    11cc:      	ldr	w15, [sp, #0x534]
    11d0:      	subs	w15, w14, w15
    11d4:      	and	w15, w15, #0xf
    11d8:      	str	w15, [sp, #0x514]
    11dc:      	ldr	w15, [sp, #0x534]
    11e0:      	subs	w15, w14, w15
    11e4:      	cset	w15, lo
    11e8:      	str	w15, [sp, #0x510]
    11ec:      	ldr	w15, [sp, #0x530]
    11f0:      	ldr	w16, [sp, #0x510]
    11f4:      	add	w15, w15, w16
    11f8:      	str	w15, [sp, #0x50c]
    11fc:      	ldr	w15, [sp, #0x50c]
    1200:      	subs	w15, w14, w15
    1204:      	and	w15, w15, #0xf
    1208:      	str	w15, [sp, #0x508]
    120c:      	ldr	w15, [sp, #0x50c]
    1210:      	subs	w15, w14, w15
    1214:      	cset	w15, lo
    1218:      	str	w15, [sp, #0x504]
    121c:      	ldr	w15, [sp, #0x52c]
    1220:      	ldr	w16, [sp, #0x504]
    1224:      	add	w15, w15, w16
    1228:      	str	w15, [sp, #0x500]
    122c:      	ldr	w15, [sp, #0x500]
    1230:      	subs	w15, w14, w15
    1234:      	and	w15, w15, #0xf
    1238:      	str	w15, [sp, #0x4fc]
    123c:      	ldr	w15, [sp, #0x500]
    1240:      	subs	w15, w14, w15
    1244:      	cset	w15, lo
    1248:      	str	w15, [sp, #0x4f8]
    124c:      	ldr	w15, [sp, #0x528]
    1250:      	ldr	w16, [sp, #0x4f8]
    1254:      	add	w15, w15, w16
    1258:      	str	w15, [sp, #0x4f4]
    125c:      	ldr	w15, [sp, #0x4f4]
    1260:      	subs	w15, w14, w15
    1264:      	and	w15, w15, #0xf
    1268:      	str	w15, [sp, #0x4f0]
    126c:      	ldr	w15, [sp, #0x4f4]
    1270:      	subs	w15, w14, w15
    1274:      	cset	w15, lo
    1278:      	str	w15, [sp, #0x4ec]
    127c:      	ldr	w15, [sp, #0x524]
    1280:      	ldr	w16, [sp, #0x4ec]
    1284:      	add	w15, w15, w16
    1288:      	str	w15, [sp, #0x4e8]
    128c:      	ldr	w15, [sp, #0x4e8]
    1290:      	subs	w15, w14, w15
    1294:      	and	w15, w15, #0xf
    1298:      	str	w15, [sp, #0x4e4]
    129c:      	ldr	w15, [sp, #0x4e8]
    12a0:      	subs	w15, w14, w15
    12a4:      	cset	w15, lo
    12a8:      	str	w15, [sp, #0x4e0]
    12ac:      	ldr	w15, [sp, #0x520]
    12b0:      	ldr	w16, [sp, #0x4e0]
    12b4:      	add	w15, w15, w16
    12b8:      	str	w15, [sp, #0x4dc]
    12bc:      	ldr	w15, [sp, #0x4dc]
    12c0:      	subs	w15, w14, w15
    12c4:      	and	w15, w15, #0xf
    12c8:      	str	w15, [sp, #0x4d8]
    12cc:      	ldr	w15, [sp, #0x4dc]
    12d0:      	subs	w15, w14, w15
    12d4:      	cset	w15, lo
    12d8:      	str	w15, [sp, #0x4d4]
    12dc:      	ldr	w15, [sp, #0x51c]
    12e0:      	ldr	w16, [sp, #0x4d4]
    12e4:      	add	w15, w15, w16
    12e8:      	str	w15, [sp, #0x4d0]
    12ec:      	ldr	w15, [sp, #0x4d0]
    12f0:      	subs	w15, w14, w15
    12f4:      	and	w15, w15, #0xf
    12f8:      	str	w15, [sp, #0x4cc]
    12fc:      	ldr	w15, [sp, #0x4d0]
    1300:      	subs	w15, w14, w15
    1304:      	cset	w15, lo
    1308:      	str	w15, [sp, #0x4c8]
    130c:      	ldr	w15, [sp, #0x518]
    1310:      	ldr	w16, [sp, #0x4c8]
    1314:      	add	w15, w15, w16
    1318:      	str	w15, [sp, #0x4c4]
    131c:      	ldr	w15, [sp, #0x4c4]
    1320:      	subs	w15, w14, w15
    1324:      	and	w15, w15, #0xf
    1328:      	str	w15, [sp, #0x4c0]
    132c:      	ldr	w16, [sp, #0x554]
    1330:      	ldr	w15, [sp, #0x550]
    1334:      	lsl	w15, w15, #3
    1338:      	orr	w15, w15, w16, lsr #1
    133c:      	and	w15, w15, #0xf
    1340:      	str	w15, [sp, #0x4bc]
    1344:      	ldr	w16, [sp, #0x550]
    1348:      	ldr	w15, [sp, #0x54c]
    134c:      	lsl	w15, w15, #3
    1350:      	orr	w15, w15, w16, lsr #1
    1354:      	and	w15, w15, #0xf
    1358:      	str	w15, [sp, #0x4b8]
    135c:      	ldr	w16, [sp, #0x54c]
    1360:      	ldr	w15, [sp, #0x548]
    1364:      	lsl	w15, w15, #3
    1368:      	orr	w15, w15, w16, lsr #1
    136c:      	and	w15, w15, #0xf
    1370:      	str	w15, [sp, #0x4b4]
    1374:      	ldr	w16, [sp, #0x548]
    1378:      	ldr	w15, [sp, #0x544]
    137c:      	lsl	w15, w15, #3
    1380:      	orr	w15, w15, w16, lsr #1
    1384:      	and	w15, w15, #0xf
    1388:      	str	w15, [sp, #0x4b0]
    138c:      	ldr	w16, [sp, #0x544]
    1390:      	ldr	w15, [sp, #0x540]
    1394:      	lsl	w15, w15, #3
    1398:      	orr	w15, w15, w16, lsr #1
    139c:      	and	w15, w15, #0xf
    13a0:      	str	w15, [sp, #0x4ac]
    13a4:      	ldr	w16, [sp, #0x540]
    13a8:      	ldr	w15, [sp, #0x53c]
    13ac:      	lsl	w15, w15, #3
    13b0:      	orr	w15, w15, w16, lsr #1
    13b4:      	and	w15, w15, #0xf
    13b8:      	str	w15, [sp, #0x4a8]
    13bc:      	ldr	w16, [sp, #0x53c]
    13c0:      	ldr	w15, [sp, #0x538]
    13c4:      	lsl	w15, w15, #3
    13c8:      	orr	w15, w15, w16, lsr #1
    13cc:      	and	w15, w15, #0xf
    13d0:      	str	w15, [sp, #0x4a4]
    13d4:      	ldr	w15, [sp, #0x538]
    13d8:      	lsr	w15, w15, #1
    13dc:      	and	w15, w15, #0xf
    13e0:      	str	w15, [sp, #0x4a0]
    13e4:      	ldr	w15, [sp, #0x514]
    13e8:      	and	w15, w14, w15
    13ec:      	str	w15, [sp, #0x49c]
    13f0:      	ldr	w15, [sp, #0x508]
    13f4:      	and	w15, w13, w15
    13f8:      	str	w15, [sp, #0x498]
    13fc:      	ldr	w15, [sp, #0x4fc]
    1400:      	and	w15, w12, w15
    1404:      	str	w15, [sp, #0x494]
    1408:      	ldr	w15, [sp, #0x4f0]
    140c:      	and	w15, w11, w15
    1410:      	str	w15, [sp, #0x490]
    1414:      	ldr	w15, [sp, #0x4e4]
    1418:      	and	w15, w11, w15
    141c:      	str	w15, [sp, #0x48c]
    1420:      	ldr	w15, [sp, #0x4d8]
    1424:      	and	w15, w10, w15
    1428:      	str	w15, [sp, #0x488]
    142c:      	ldr	w15, [sp, #0x4cc]
    1430:      	and	w15, w9, w15
    1434:      	str	w15, [sp, #0x484]
    1438:      	ldr	w15, [sp, #0x4c0]
    143c:      	and	w15, w8, w15
    1440:      	str	w15, [sp, #0x480]
    1444:      	ldr	w15, [sp, #0x4bc]
    1448:      	ldr	w16, [sp, #0x49c]
    144c:      	eor	w15, w15, w16
    1450:      	str	w15, [sp, #0x47c]
    1454:      	ldr	w15, [sp, #0x4b8]
    1458:      	ldr	w16, [sp, #0x498]
    145c:      	eor	w15, w15, w16
    1460:      	str	w15, [sp, #0x478]
    1464:      	ldr	w15, [sp, #0x4b4]
    1468:      	ldr	w16, [sp, #0x494]
    146c:      	eor	w15, w15, w16
    1470:      	str	w15, [sp, #0x474]
    1474:      	ldr	w15, [sp, #0x4b0]
    1478:      	ldr	w16, [sp, #0x490]
    147c:      	eor	w15, w15, w16
    1480:      	str	w15, [sp, #0x470]
    1484:      	ldr	w15, [sp, #0x4ac]
    1488:      	ldr	w16, [sp, #0x48c]
    148c:      	eor	w15, w15, w16
    1490:      	str	w15, [sp, #0x46c]
    1494:      	ldr	w15, [sp, #0x4a8]
    1498:      	ldr	w16, [sp, #0x488]
    149c:      	eor	w15, w15, w16
    14a0:      	str	w15, [sp, #0x468]
    14a4:      	ldr	w15, [sp, #0x4a4]
    14a8:      	ldr	w16, [sp, #0x484]
    14ac:      	eor	w15, w15, w16
    14b0:      	str	w15, [sp, #0x464]
    14b4:      	ldr	w15, [sp, #0x4a0]
    14b8:      	ldr	w16, [sp, #0x480]
    14bc:      	eor	w15, w15, w16
    14c0:      	str	w15, [sp, #0x460]
    14c4:      	ldr	w15, [sp, #0x47c]
    14c8:      	and	w15, w15, #0x1
    14cc:      	str	w15, [sp, #0x45c]
    14d0:      	ldr	w15, [sp, #0x478]
    14d4:      	and	w15, w15, w14
    14d8:      	str	w15, [sp, #0x458]
    14dc:      	ldr	w15, [sp, #0x474]
    14e0:      	and	w15, w15, w14
    14e4:      	str	w15, [sp, #0x454]
    14e8:      	ldr	w15, [sp, #0x470]
    14ec:      	and	w15, w15, w14
    14f0:      	str	w15, [sp, #0x450]
    14f4:      	ldr	w15, [sp, #0x46c]
    14f8:      	and	w15, w15, w14
    14fc:      	str	w15, [sp, #0x44c]
    1500:      	ldr	w15, [sp, #0x468]
    1504:      	and	w15, w15, w14
    1508:      	str	w15, [sp, #0x448]
    150c:      	ldr	w15, [sp, #0x464]
    1510:      	and	w15, w15, w14
    1514:      	str	w15, [sp, #0x444]
    1518:      	ldr	w15, [sp, #0x460]
    151c:      	and	w15, w15, w14
    1520:      	str	w15, [sp, #0x440]
    1524:      	ldr	w15, [sp, #0x45c]
    1528:      	subs	w15, w14, w15
    152c:      	and	w15, w15, #0xf
    1530:      	str	w15, [sp, #0x43c]
    1534:      	ldr	w15, [sp, #0x45c]
    1538:      	subs	w15, w14, w15
    153c:      	cset	w15, lo
    1540:      	str	w15, [sp, #0x438]
    1544:      	ldr	w15, [sp, #0x458]
    1548:      	ldr	w16, [sp, #0x438]
    154c:      	add	w15, w15, w16
    1550:      	str	w15, [sp, #0x434]
    1554:      	ldr	w15, [sp, #0x434]
    1558:      	subs	w15, w14, w15
    155c:      	and	w15, w15, #0xf
    1560:      	str	w15, [sp, #0x430]
    1564:      	ldr	w15, [sp, #0x434]
    1568:      	subs	w15, w14, w15
    156c:      	cset	w15, lo
    1570:      	str	w15, [sp, #0x42c]
    1574:      	ldr	w15, [sp, #0x454]
    1578:      	ldr	w16, [sp, #0x42c]
    157c:      	add	w15, w15, w16
    1580:      	str	w15, [sp, #0x428]
    1584:      	ldr	w15, [sp, #0x428]
    1588:      	subs	w15, w14, w15
    158c:      	and	w15, w15, #0xf
    1590:      	str	w15, [sp, #0x424]
    1594:      	ldr	w15, [sp, #0x428]
    1598:      	subs	w15, w14, w15
    159c:      	cset	w15, lo
    15a0:      	str	w15, [sp, #0x420]
    15a4:      	ldr	w15, [sp, #0x450]
    15a8:      	ldr	w16, [sp, #0x420]
    15ac:      	add	w15, w15, w16
    15b0:      	str	w15, [sp, #0x41c]
    15b4:      	ldr	w15, [sp, #0x41c]
    15b8:      	subs	w15, w14, w15
    15bc:      	and	w15, w15, #0xf
    15c0:      	str	w15, [sp, #0x418]
    15c4:      	ldr	w15, [sp, #0x41c]
    15c8:      	subs	w15, w14, w15
    15cc:      	cset	w15, lo
    15d0:      	str	w15, [sp, #0x414]
    15d4:      	ldr	w15, [sp, #0x44c]
    15d8:      	ldr	w16, [sp, #0x414]
    15dc:      	add	w15, w15, w16
    15e0:      	str	w15, [sp, #0x410]
    15e4:      	ldr	w15, [sp, #0x410]
    15e8:      	subs	w15, w14, w15
    15ec:      	and	w15, w15, #0xf
    15f0:      	str	w15, [sp, #0x40c]
    15f4:      	ldr	w15, [sp, #0x410]
    15f8:      	subs	w15, w14, w15
    15fc:      	cset	w15, lo
    1600:      	str	w15, [sp, #0x408]
    1604:      	ldr	w15, [sp, #0x448]
    1608:      	ldr	w16, [sp, #0x408]
    160c:      	add	w15, w15, w16
    1610:      	str	w15, [sp, #0x404]
    1614:      	ldr	w15, [sp, #0x404]
    1618:      	subs	w15, w14, w15
    161c:      	and	w15, w15, #0xf
    1620:      	str	w15, [sp, #0x400]
    1624:      	ldr	w15, [sp, #0x404]
    1628:      	subs	w15, w14, w15
    162c:      	cset	w15, lo
    1630:      	str	w15, [sp, #0x3fc]
    1634:      	ldr	w15, [sp, #0x444]
    1638:      	ldr	w16, [sp, #0x3fc]
    163c:      	add	w15, w15, w16
    1640:      	str	w15, [sp, #0x3f8]
    1644:      	ldr	w15, [sp, #0x3f8]
    1648:      	subs	w15, w14, w15
    164c:      	and	w15, w15, #0xf
    1650:      	str	w15, [sp, #0x3f4]
    1654:      	ldr	w15, [sp, #0x3f8]
    1658:      	subs	w15, w14, w15
    165c:      	cset	w15, lo
    1660:      	str	w15, [sp, #0x3f0]
    1664:      	ldr	w15, [sp, #0x440]
    1668:      	ldr	w16, [sp, #0x3f0]
    166c:      	add	w15, w15, w16
    1670:      	str	w15, [sp, #0x3ec]
    1674:      	ldr	w15, [sp, #0x3ec]
    1678:      	subs	w15, w14, w15
    167c:      	and	w15, w15, #0xf
    1680:      	str	w15, [sp, #0x3e8]
    1684:      	ldr	w16, [sp, #0x47c]
    1688:      	ldr	w15, [sp, #0x478]
    168c:      	lsl	w15, w15, #3
    1690:      	orr	w15, w15, w16, lsr #1
    1694:      	and	w15, w15, #0xf
    1698:      	str	w15, [sp, #0x3e4]
    169c:      	ldr	w16, [sp, #0x478]
    16a0:      	ldr	w15, [sp, #0x474]
    16a4:      	lsl	w15, w15, #3
    16a8:      	orr	w15, w15, w16, lsr #1
    16ac:      	and	w15, w15, #0xf
    16b0:      	str	w15, [sp, #0x3e0]
    16b4:      	ldr	w16, [sp, #0x474]
    16b8:      	ldr	w15, [sp, #0x470]
    16bc:      	lsl	w15, w15, #3
    16c0:      	orr	w15, w15, w16, lsr #1
    16c4:      	and	w15, w15, #0xf
    16c8:      	str	w15, [sp, #0x3dc]
    16cc:      	ldr	w16, [sp, #0x470]
    16d0:      	ldr	w15, [sp, #0x46c]
    16d4:      	lsl	w15, w15, #3
    16d8:      	orr	w15, w15, w16, lsr #1
    16dc:      	and	w15, w15, #0xf
    16e0:      	str	w15, [sp, #0x3d8]
    16e4:      	ldr	w16, [sp, #0x46c]
    16e8:      	ldr	w15, [sp, #0x468]
    16ec:      	lsl	w15, w15, #3
    16f0:      	orr	w15, w15, w16, lsr #1
    16f4:      	and	w15, w15, #0xf
    16f8:      	str	w15, [sp, #0x3d4]
    16fc:      	ldr	w16, [sp, #0x468]
    1700:      	ldr	w15, [sp, #0x464]
    1704:      	lsl	w15, w15, #3
    1708:      	orr	w15, w15, w16, lsr #1
    170c:      	and	w15, w15, #0xf
    1710:      	str	w15, [sp, #0x3d0]
    1714:      	ldr	w16, [sp, #0x464]
    1718:      	ldr	w15, [sp, #0x460]
    171c:      	lsl	w15, w15, #3
    1720:      	orr	w15, w15, w16, lsr #1
    1724:      	and	w15, w15, #0xf
    1728:      	str	w15, [sp, #0x3cc]
    172c:      	ldr	w15, [sp, #0x460]
    1730:      	lsr	w15, w15, #1
    1734:      	and	w15, w15, #0xf
    1738:      	str	w15, [sp, #0x3c8]
    173c:      	ldr	w15, [sp, #0x43c]
    1740:      	and	w15, w14, w15
    1744:      	str	w15, [sp, #0x3c4]
    1748:      	ldr	w15, [sp, #0x430]
    174c:      	and	w15, w13, w15
    1750:      	str	w15, [sp, #0x3c0]
    1754:      	ldr	w15, [sp, #0x424]
    1758:      	and	w15, w12, w15
    175c:      	str	w15, [sp, #0x3bc]
    1760:      	ldr	w15, [sp, #0x418]
    1764:      	and	w15, w11, w15
    1768:      	str	w15, [sp, #0x3b8]
    176c:      	ldr	w15, [sp, #0x40c]
    1770:      	and	w15, w11, w15
    1774:      	str	w15, [sp, #0x3b4]
    1778:      	ldr	w15, [sp, #0x400]
    177c:      	and	w15, w10, w15
    1780:      	str	w15, [sp, #0x3b0]
    1784:      	ldr	w15, [sp, #0x3f4]
    1788:      	and	w15, w9, w15
    178c:      	str	w15, [sp, #0x3ac]
    1790:      	ldr	w15, [sp, #0x3e8]
    1794:      	and	w15, w8, w15
    1798:      	str	w15, [sp, #0x3a8]
    179c:      	ldr	w15, [sp, #0x3e4]
    17a0:      	ldr	w16, [sp, #0x3c4]
    17a4:      	eor	w15, w15, w16
    17a8:      	str	w15, [sp, #0x3a4]
    17ac:      	ldr	w15, [sp, #0x3e0]
    17b0:      	ldr	w16, [sp, #0x3c0]
    17b4:      	eor	w15, w15, w16
    17b8:      	str	w15, [sp, #0x3a0]
    17bc:      	ldr	w15, [sp, #0x3dc]
    17c0:      	ldr	w16, [sp, #0x3bc]
    17c4:      	eor	w15, w15, w16
    17c8:      	str	w15, [sp, #0x39c]
    17cc:      	ldr	w15, [sp, #0x3d8]
    17d0:      	ldr	w16, [sp, #0x3b8]
    17d4:      	eor	w15, w15, w16
    17d8:      	str	w15, [sp, #0x398]
    17dc:      	ldr	w15, [sp, #0x3d4]
    17e0:      	ldr	w16, [sp, #0x3b4]
    17e4:      	eor	w15, w15, w16
    17e8:      	str	w15, [sp, #0x394]
    17ec:      	ldr	w15, [sp, #0x3d0]
    17f0:      	ldr	w16, [sp, #0x3b0]
    17f4:      	eor	w15, w15, w16
    17f8:      	str	w15, [sp, #0x390]
    17fc:      	ldr	w15, [sp, #0x3cc]
    1800:      	ldr	w16, [sp, #0x3ac]
    1804:      	eor	w15, w15, w16
    1808:      	str	w15, [sp, #0x38c]
    180c:      	ldr	w15, [sp, #0x3c8]
    1810:      	ldr	w16, [sp, #0x3a8]
    1814:      	eor	w15, w15, w16
    1818:      	str	w15, [sp, #0x388]
    181c:      	ldr	w15, [sp, #0x3a4]
    1820:      	and	w15, w15, #0x1
    1824:      	str	w15, [sp, #0x384]
    1828:      	ldr	w15, [sp, #0x3a0]
    182c:      	and	w15, w15, w14
    1830:      	str	w15, [sp, #0x380]
    1834:      	ldr	w15, [sp, #0x39c]
    1838:      	and	w15, w15, w14
    183c:      	str	w15, [sp, #0x37c]
    1840:      	ldr	w15, [sp, #0x398]
    1844:      	and	w15, w15, w14
    1848:      	str	w15, [sp, #0x378]
    184c:      	ldr	w15, [sp, #0x394]
    1850:      	and	w15, w15, w14
    1854:      	str	w15, [sp, #0x374]
    1858:      	ldr	w15, [sp, #0x390]
    185c:      	and	w15, w15, w14
    1860:      	str	w15, [sp, #0x370]
    1864:      	ldr	w15, [sp, #0x38c]
    1868:      	and	w15, w15, w14
    186c:      	str	w15, [sp, #0x36c]
    1870:      	ldr	w15, [sp, #0x388]
    1874:      	and	w15, w15, w14
    1878:      	str	w15, [sp, #0x368]
    187c:      	ldr	w15, [sp, #0x384]
    1880:      	subs	w15, w14, w15
    1884:      	and	w15, w15, #0xf
    1888:      	str	w15, [sp, #0x364]
    188c:      	ldr	w15, [sp, #0x384]
    1890:      	subs	w15, w14, w15
    1894:      	cset	w15, lo
    1898:      	str	w15, [sp, #0x360]
    189c:      	ldr	w15, [sp, #0x380]
    18a0:      	ldr	w16, [sp, #0x360]
    18a4:      	add	w15, w15, w16
    18a8:      	str	w15, [sp, #0x35c]
    18ac:      	ldr	w15, [sp, #0x35c]
    18b0:      	subs	w15, w14, w15
    18b4:      	and	w15, w15, #0xf
    18b8:      	str	w15, [sp, #0x358]
    18bc:      	ldr	w15, [sp, #0x35c]
    18c0:      	subs	w15, w14, w15
    18c4:      	cset	w15, lo
    18c8:      	str	w15, [sp, #0x354]
    18cc:      	ldr	w15, [sp, #0x37c]
    18d0:      	ldr	w16, [sp, #0x354]
    18d4:      	add	w15, w15, w16
    18d8:      	str	w15, [sp, #0x350]
    18dc:      	ldr	w15, [sp, #0x350]
    18e0:      	subs	w15, w14, w15
    18e4:      	and	w15, w15, #0xf
    18e8:      	str	w15, [sp, #0x34c]
    18ec:      	ldr	w15, [sp, #0x350]
    18f0:      	subs	w15, w14, w15
    18f4:      	cset	w15, lo
    18f8:      	str	w15, [sp, #0x348]
    18fc:      	ldr	w15, [sp, #0x378]
    1900:      	ldr	w16, [sp, #0x348]
    1904:      	add	w15, w15, w16
    1908:      	str	w15, [sp, #0x344]
    190c:      	ldr	w15, [sp, #0x344]
    1910:      	subs	w15, w14, w15
    1914:      	and	w15, w15, #0xf
    1918:      	str	w15, [sp, #0x340]
    191c:      	ldr	w15, [sp, #0x344]
    1920:      	subs	w15, w14, w15
    1924:      	cset	w15, lo
    1928:      	str	w15, [sp, #0x33c]
    192c:      	ldr	w15, [sp, #0x374]
    1930:      	ldr	w16, [sp, #0x33c]
    1934:      	add	w15, w15, w16
    1938:      	str	w15, [sp, #0x338]
    193c:      	ldr	w15, [sp, #0x338]
    1940:      	subs	w15, w14, w15
    1944:      	and	w15, w15, #0xf
    1948:      	str	w15, [sp, #0x334]
    194c:      	ldr	w15, [sp, #0x338]
    1950:      	subs	w15, w14, w15
    1954:      	cset	w15, lo
    1958:      	str	w15, [sp, #0x330]
    195c:      	ldr	w15, [sp, #0x370]
    1960:      	ldr	w16, [sp, #0x330]
    1964:      	add	w15, w15, w16
    1968:      	str	w15, [sp, #0x32c]
    196c:      	ldr	w15, [sp, #0x32c]
    1970:      	subs	w15, w14, w15
    1974:      	and	w15, w15, #0xf
    1978:      	str	w15, [sp, #0x328]
    197c:      	ldr	w15, [sp, #0x32c]
    1980:      	subs	w15, w14, w15
    1984:      	cset	w15, lo
    1988:      	str	w15, [sp, #0x324]
    198c:      	ldr	w15, [sp, #0x36c]
    1990:      	ldr	w16, [sp, #0x324]
    1994:      	add	w15, w15, w16
    1998:      	str	w15, [sp, #0x320]
    199c:      	ldr	w15, [sp, #0x320]
    19a0:      	subs	w15, w14, w15
    19a4:      	and	w15, w15, #0xf
    19a8:      	str	w15, [sp, #0x31c]
    19ac:      	ldr	w15, [sp, #0x320]
    19b0:      	subs	w15, w14, w15
    19b4:      	cset	w15, lo
    19b8:      	str	w15, [sp, #0x318]
    19bc:      	ldr	w15, [sp, #0x368]
    19c0:      	ldr	w16, [sp, #0x318]
    19c4:      	add	w15, w15, w16
    19c8:      	str	w15, [sp, #0x314]
    19cc:      	ldr	w15, [sp, #0x314]
    19d0:      	subs	w15, w14, w15
    19d4:      	and	w15, w15, #0xf
    19d8:      	str	w15, [sp, #0x310]
    19dc:      	ldr	w16, [sp, #0x3a4]
    19e0:      	ldr	w15, [sp, #0x3a0]
    19e4:      	lsl	w15, w15, #3
    19e8:      	orr	w15, w15, w16, lsr #1
    19ec:      	and	w15, w15, #0xf
    19f0:      	str	w15, [sp, #0x30c]
    19f4:      	ldr	w16, [sp, #0x3a0]
    19f8:      	ldr	w15, [sp, #0x39c]
    19fc:      	lsl	w15, w15, #3
    1a00:      	orr	w15, w15, w16, lsr #1
    1a04:      	and	w15, w15, #0xf
    1a08:      	str	w15, [sp, #0x308]
    1a0c:      	ldr	w16, [sp, #0x39c]
    1a10:      	ldr	w15, [sp, #0x398]
    1a14:      	lsl	w15, w15, #3
    1a18:      	orr	w15, w15, w16, lsr #1
    1a1c:      	and	w15, w15, #0xf
    1a20:      	str	w15, [sp, #0x304]
    1a24:      	ldr	w16, [sp, #0x398]
    1a28:      	ldr	w15, [sp, #0x394]
    1a2c:      	lsl	w15, w15, #3
    1a30:      	orr	w15, w15, w16, lsr #1
    1a34:      	and	w15, w15, #0xf
    1a38:      	str	w15, [sp, #0x300]
    1a3c:      	ldr	w16, [sp, #0x394]
    1a40:      	ldr	w15, [sp, #0x390]
    1a44:      	lsl	w15, w15, #3
    1a48:      	orr	w15, w15, w16, lsr #1
    1a4c:      	and	w15, w15, #0xf
    1a50:      	str	w15, [sp, #0x2fc]
    1a54:      	ldr	w16, [sp, #0x390]
    1a58:      	ldr	w15, [sp, #0x38c]
    1a5c:      	lsl	w15, w15, #3
    1a60:      	orr	w15, w15, w16, lsr #1
    1a64:      	and	w15, w15, #0xf
    1a68:      	str	w15, [sp, #0x2f8]
    1a6c:      	ldr	w16, [sp, #0x38c]
    1a70:      	ldr	w15, [sp, #0x388]
    1a74:      	lsl	w15, w15, #3
    1a78:      	orr	w15, w15, w16, lsr #1
    1a7c:      	and	w15, w15, #0xf
    1a80:      	str	w15, [sp, #0x2f4]
    1a84:      	ldr	w15, [sp, #0x388]
    1a88:      	lsr	w15, w15, #1
    1a8c:      	and	w15, w15, #0xf
    1a90:      	str	w15, [sp, #0x2f0]
    1a94:      	ldr	w15, [sp, #0x364]
    1a98:      	and	w15, w14, w15
    1a9c:      	str	w15, [sp, #0x2ec]
    1aa0:      	ldr	w15, [sp, #0x358]
    1aa4:      	and	w15, w13, w15
    1aa8:      	str	w15, [sp, #0x2e8]
    1aac:      	ldr	w15, [sp, #0x34c]
    1ab0:      	and	w15, w12, w15
    1ab4:      	str	w15, [sp, #0x2e4]
    1ab8:      	ldr	w15, [sp, #0x340]
    1abc:      	and	w15, w11, w15
    1ac0:      	str	w15, [sp, #0x2e0]
    1ac4:      	ldr	w15, [sp, #0x334]
    1ac8:      	and	w15, w11, w15
    1acc:      	str	w15, [sp, #0x2dc]
    1ad0:      	ldr	w15, [sp, #0x328]
    1ad4:      	and	w15, w10, w15
    1ad8:      	str	w15, [sp, #0x2d8]
    1adc:      	ldr	w15, [sp, #0x31c]
    1ae0:      	and	w15, w9, w15
    1ae4:      	str	w15, [sp, #0x2d4]
    1ae8:      	ldr	w15, [sp, #0x310]
    1aec:      	and	w15, w8, w15
    1af0:      	str	w15, [sp, #0x2d0]
    1af4:      	ldr	w15, [sp, #0x30c]
    1af8:      	ldr	w16, [sp, #0x2ec]
    1afc:      	eor	w15, w15, w16
    1b00:      	str	w15, [sp, #0x2cc]
    1b04:      	ldr	w15, [sp, #0x308]
    1b08:      	ldr	w16, [sp, #0x2e8]
    1b0c:      	eor	w15, w15, w16
    1b10:      	str	w15, [sp, #0x2c8]
    1b14:      	ldr	w15, [sp, #0x304]
    1b18:      	ldr	w16, [sp, #0x2e4]
    1b1c:      	eor	w15, w15, w16
    1b20:      	str	w15, [sp, #0x2c4]
    1b24:      	ldr	w15, [sp, #0x300]
    1b28:      	ldr	w16, [sp, #0x2e0]
    1b2c:      	eor	w15, w15, w16
    1b30:      	str	w15, [sp, #0x2c0]
    1b34:      	ldr	w15, [sp, #0x2fc]
    1b38:      	ldr	w16, [sp, #0x2dc]
    1b3c:      	eor	w15, w15, w16
    1b40:      	str	w15, [sp, #0x2bc]
    1b44:      	ldr	w15, [sp, #0x2f8]
    1b48:      	ldr	w16, [sp, #0x2d8]
    1b4c:      	eor	w15, w15, w16
    1b50:      	str	w15, [sp, #0x2b8]
    1b54:      	ldr	w15, [sp, #0x2f4]
    1b58:      	ldr	w16, [sp, #0x2d4]
    1b5c:      	eor	w15, w15, w16
    1b60:      	str	w15, [sp, #0x2b4]
    1b64:      	ldr	w15, [sp, #0x2f0]
    1b68:      	ldr	w16, [sp, #0x2d0]
    1b6c:      	eor	w15, w15, w16
    1b70:      	str	w15, [sp, #0x2b0]
    1b74:      	ldr	w15, [sp, #0x2cc]
    1b78:      	and	w15, w15, #0x1
    1b7c:      	str	w15, [sp, #0x2ac]
    1b80:      	ldr	w15, [sp, #0x2c8]
    1b84:      	and	w15, w15, w14
    1b88:      	str	w15, [sp, #0x2a8]
    1b8c:      	ldr	w15, [sp, #0x2c4]
    1b90:      	and	w15, w15, w14
    1b94:      	str	w15, [sp, #0x2a4]
    1b98:      	ldr	w15, [sp, #0x2c0]
    1b9c:      	and	w15, w15, w14
    1ba0:      	str	w15, [sp, #0x2a0]
    1ba4:      	ldr	w15, [sp, #0x2bc]
    1ba8:      	and	w15, w15, w14
    1bac:      	str	w15, [sp, #0x29c]
    1bb0:      	ldr	w15, [sp, #0x2b8]
    1bb4:      	and	w15, w15, w14
    1bb8:      	str	w15, [sp, #0x298]
    1bbc:      	ldr	w15, [sp, #0x2b4]
    1bc0:      	and	w15, w15, w14
    1bc4:      	str	w15, [sp, #0x294]
    1bc8:      	ldr	w15, [sp, #0x2b0]
    1bcc:      	and	w15, w15, w14
    1bd0:      	str	w15, [sp, #0x290]
    1bd4:      	ldr	w15, [sp, #0x2ac]
    1bd8:      	subs	w15, w14, w15
    1bdc:      	and	w15, w15, #0xf
    1be0:      	str	w15, [sp, #0x28c]
    1be4:      	ldr	w15, [sp, #0x2ac]
    1be8:      	subs	w15, w14, w15
    1bec:      	cset	w15, lo
    1bf0:      	str	w15, [sp, #0x288]
    1bf4:      	ldr	w15, [sp, #0x2a8]
    1bf8:      	ldr	w16, [sp, #0x288]
    1bfc:      	add	w15, w15, w16
    1c00:      	str	w15, [sp, #0x284]
    1c04:      	ldr	w15, [sp, #0x284]
    1c08:      	subs	w15, w14, w15
    1c0c:      	and	w15, w15, #0xf
    1c10:      	str	w15, [sp, #0x280]
    1c14:      	ldr	w15, [sp, #0x284]
    1c18:      	subs	w15, w14, w15
    1c1c:      	cset	w15, lo
    1c20:      	str	w15, [sp, #0x27c]
    1c24:      	ldr	w15, [sp, #0x2a4]
    1c28:      	ldr	w16, [sp, #0x27c]
    1c2c:      	add	w15, w15, w16
    1c30:      	str	w15, [sp, #0x278]
    1c34:      	ldr	w15, [sp, #0x278]
    1c38:      	subs	w15, w14, w15
    1c3c:      	and	w15, w15, #0xf
    1c40:      	str	w15, [sp, #0x274]
    1c44:      	ldr	w15, [sp, #0x278]
    1c48:      	subs	w15, w14, w15
    1c4c:      	cset	w15, lo
    1c50:      	str	w15, [sp, #0x270]
    1c54:      	ldr	w15, [sp, #0x2a0]
    1c58:      	ldr	w16, [sp, #0x270]
    1c5c:      	add	w15, w15, w16
    1c60:      	str	w15, [sp, #0x26c]
    1c64:      	ldr	w15, [sp, #0x26c]
    1c68:      	subs	w15, w14, w15
    1c6c:      	and	w15, w15, #0xf
    1c70:      	str	w15, [sp, #0x268]
    1c74:      	ldr	w15, [sp, #0x26c]
    1c78:      	subs	w15, w14, w15
    1c7c:      	cset	w15, lo
    1c80:      	str	w15, [sp, #0x264]
    1c84:      	ldr	w15, [sp, #0x29c]
    1c88:      	ldr	w16, [sp, #0x264]
    1c8c:      	add	w15, w15, w16
    1c90:      	str	w15, [sp, #0x260]
    1c94:      	ldr	w15, [sp, #0x260]
    1c98:      	subs	w15, w14, w15
    1c9c:      	and	w15, w15, #0xf
    1ca0:      	str	w15, [sp, #0x25c]
    1ca4:      	ldr	w15, [sp, #0x260]
    1ca8:      	subs	w15, w14, w15
    1cac:      	cset	w15, lo
    1cb0:      	str	w15, [sp, #0x258]
    1cb4:      	ldr	w15, [sp, #0x298]
    1cb8:      	ldr	w16, [sp, #0x258]
    1cbc:      	add	w15, w15, w16
    1cc0:      	str	w15, [sp, #0x254]
    1cc4:      	ldr	w15, [sp, #0x254]
    1cc8:      	subs	w15, w14, w15
    1ccc:      	and	w15, w15, #0xf
    1cd0:      	str	w15, [sp, #0x250]
    1cd4:      	ldr	w15, [sp, #0x254]
    1cd8:      	subs	w15, w14, w15
    1cdc:      	cset	w15, lo
    1ce0:      	str	w15, [sp, #0x24c]
    1ce4:      	ldr	w15, [sp, #0x294]
    1ce8:      	ldr	w16, [sp, #0x24c]
    1cec:      	add	w15, w15, w16
    1cf0:      	str	w15, [sp, #0x248]
    1cf4:      	ldr	w15, [sp, #0x248]
    1cf8:      	subs	w15, w14, w15
    1cfc:      	and	w15, w15, #0xf
    1d00:      	str	w15, [sp, #0x244]
    1d04:      	ldr	w15, [sp, #0x248]
    1d08:      	subs	w15, w14, w15
    1d0c:      	cset	w15, lo
    1d10:      	str	w15, [sp, #0x240]
    1d14:      	ldr	w15, [sp, #0x290]
    1d18:      	ldr	w16, [sp, #0x240]
    1d1c:      	add	w15, w15, w16
    1d20:      	str	w15, [sp, #0x23c]
    1d24:      	ldr	w15, [sp, #0x23c]
    1d28:      	subs	w15, w14, w15
    1d2c:      	and	w15, w15, #0xf
    1d30:      	str	w15, [sp, #0x238]
    1d34:      	ldr	w16, [sp, #0x2cc]
    1d38:      	ldr	w15, [sp, #0x2c8]
    1d3c:      	lsl	w15, w15, #3
    1d40:      	orr	w15, w15, w16, lsr #1
    1d44:      	and	w15, w15, #0xf
    1d48:      	str	w15, [sp, #0x234]
    1d4c:      	ldr	w16, [sp, #0x2c8]
    1d50:      	ldr	w15, [sp, #0x2c4]
    1d54:      	lsl	w15, w15, #3
    1d58:      	orr	w15, w15, w16, lsr #1
    1d5c:      	and	w15, w15, #0xf
    1d60:      	str	w15, [sp, #0x230]
    1d64:      	ldr	w16, [sp, #0x2c4]
    1d68:      	ldr	w15, [sp, #0x2c0]
    1d6c:      	lsl	w15, w15, #3
    1d70:      	orr	w15, w15, w16, lsr #1
    1d74:      	and	w15, w15, #0xf
    1d78:      	str	w15, [sp, #0x22c]
    1d7c:      	ldr	w16, [sp, #0x2c0]
    1d80:      	ldr	w15, [sp, #0x2bc]
    1d84:      	lsl	w15, w15, #3
    1d88:      	orr	w15, w15, w16, lsr #1
    1d8c:      	and	w15, w15, #0xf
    1d90:      	str	w15, [sp, #0x228]
    1d94:      	ldr	w16, [sp, #0x2bc]
    1d98:      	ldr	w15, [sp, #0x2b8]
    1d9c:      	lsl	w15, w15, #3
    1da0:      	orr	w15, w15, w16, lsr #1
    1da4:      	and	w15, w15, #0xf
    1da8:      	str	w15, [sp, #0x224]
    1dac:      	ldr	w16, [sp, #0x2b8]
    1db0:      	ldr	w15, [sp, #0x2b4]
    1db4:      	lsl	w15, w15, #3
    1db8:      	orr	w15, w15, w16, lsr #1
    1dbc:      	and	w15, w15, #0xf
    1dc0:      	str	w15, [sp, #0x220]
    1dc4:      	ldr	w16, [sp, #0x2b4]
    1dc8:      	ldr	w15, [sp, #0x2b0]
    1dcc:      	lsl	w15, w15, #3
    1dd0:      	orr	w15, w15, w16, lsr #1
    1dd4:      	and	w15, w15, #0xf
    1dd8:      	str	w15, [sp, #0x21c]
    1ddc:      	ldr	w15, [sp, #0x2b0]
    1de0:      	lsr	w15, w15, #1
    1de4:      	and	w15, w15, #0xf
    1de8:      	str	w15, [sp, #0x218]
    1dec:      	ldr	w15, [sp, #0x28c]
    1df0:      	and	w15, w14, w15
    1df4:      	str	w15, [sp, #0x214]
    1df8:      	ldr	w15, [sp, #0x280]
    1dfc:      	and	w15, w13, w15
    1e00:      	str	w15, [sp, #0x210]
    1e04:      	ldr	w15, [sp, #0x274]
    1e08:      	and	w15, w12, w15
    1e0c:      	str	w15, [sp, #0x20c]
    1e10:      	ldr	w15, [sp, #0x268]
    1e14:      	and	w15, w11, w15
    1e18:      	str	w15, [sp, #0x208]
    1e1c:      	ldr	w15, [sp, #0x25c]
    1e20:      	and	w15, w11, w15
    1e24:      	str	w15, [sp, #0x204]
    1e28:      	ldr	w15, [sp, #0x250]
    1e2c:      	and	w15, w10, w15
    1e30:      	str	w15, [sp, #0x200]
    1e34:      	ldr	w15, [sp, #0x244]
    1e38:      	and	w15, w9, w15
    1e3c:      	str	w15, [sp, #0x1fc]
    1e40:      	ldr	w15, [sp, #0x238]
    1e44:      	and	w15, w8, w15
    1e48:      	str	w15, [sp, #0x1f8]
    1e4c:      	ldr	w15, [sp, #0x234]
    1e50:      	ldr	w16, [sp, #0x214]
    1e54:      	eor	w15, w15, w16
    1e58:      	str	w15, [sp, #0x1f4]
    1e5c:      	ldr	w15, [sp, #0x230]
    1e60:      	ldr	w16, [sp, #0x210]
    1e64:      	eor	w15, w15, w16
    1e68:      	str	w15, [sp, #0x1f0]
    1e6c:      	ldr	w15, [sp, #0x22c]
    1e70:      	ldr	w16, [sp, #0x20c]
    1e74:      	eor	w15, w15, w16
    1e78:      	str	w15, [sp, #0x1ec]
    1e7c:      	ldr	w15, [sp, #0x228]
    1e80:      	ldr	w16, [sp, #0x208]
    1e84:      	eor	w15, w15, w16
    1e88:      	str	w15, [sp, #0x1e8]
    1e8c:      	ldr	w15, [sp, #0x224]
    1e90:      	ldr	w16, [sp, #0x204]
    1e94:      	eor	w15, w15, w16
    1e98:      	str	w15, [sp, #0x1e4]
    1e9c:      	ldr	w15, [sp, #0x220]
    1ea0:      	ldr	w16, [sp, #0x200]
    1ea4:      	eor	w15, w15, w16
    1ea8:      	str	w15, [sp, #0x1e0]
    1eac:      	ldr	w15, [sp, #0x21c]
    1eb0:      	ldr	w16, [sp, #0x1fc]
    1eb4:      	eor	w15, w15, w16
    1eb8:      	str	w15, [sp, #0x1dc]
    1ebc:      	ldr	w15, [sp, #0x218]
    1ec0:      	ldr	w16, [sp, #0x1f8]
    1ec4:      	eor	w15, w15, w16
    1ec8:      	str	w15, [sp, #0x1d8]
    1ecc:      	ldr	w15, [sp, #0x1f4]
    1ed0:      	and	w15, w15, #0x1
    1ed4:      	str	w15, [sp, #0x1d4]
    1ed8:      	ldr	w15, [sp, #0x1f0]
    1edc:      	and	w15, w15, w14
    1ee0:      	str	w15, [sp, #0x1d0]
    1ee4:      	ldr	w15, [sp, #0x1ec]
    1ee8:      	and	w15, w15, w14
    1eec:      	str	w15, [sp, #0x1cc]
    1ef0:      	ldr	w15, [sp, #0x1e8]
    1ef4:      	and	w15, w15, w14
    1ef8:      	str	w15, [sp, #0x1c8]
    1efc:      	ldr	w15, [sp, #0x1e4]
    1f00:      	and	w15, w15, w14
    1f04:      	str	w15, [sp, #0x1c4]
    1f08:      	ldr	w15, [sp, #0x1e0]
    1f0c:      	and	w15, w15, w14
    1f10:      	str	w15, [sp, #0x1c0]
    1f14:      	ldr	w15, [sp, #0x1dc]
    1f18:      	and	w15, w15, w14
    1f1c:      	str	w15, [sp, #0x1bc]
    1f20:      	ldr	w15, [sp, #0x1d8]
    1f24:      	and	w15, w15, w14
    1f28:      	str	w15, [sp, #0x1b8]
    1f2c:      	ldr	w15, [sp, #0x1d4]
    1f30:      	subs	w15, w14, w15
    1f34:      	and	w15, w15, #0xf
    1f38:      	str	w15, [sp, #0x1b4]
    1f3c:      	ldr	w15, [sp, #0x1d4]
    1f40:      	subs	w15, w14, w15
    1f44:      	cset	w15, lo
    1f48:      	str	w15, [sp, #0x1b0]
    1f4c:      	ldr	w15, [sp, #0x1d0]
    1f50:      	ldr	w16, [sp, #0x1b0]
    1f54:      	add	w15, w15, w16
    1f58:      	str	w15, [sp, #0x1ac]
    1f5c:      	ldr	w15, [sp, #0x1ac]
    1f60:      	subs	w15, w14, w15
    1f64:      	and	w15, w15, #0xf
    1f68:      	str	w15, [sp, #0x1a8]
    1f6c:      	ldr	w15, [sp, #0x1ac]
    1f70:      	subs	w15, w14, w15
    1f74:      	cset	w15, lo
    1f78:      	str	w15, [sp, #0x1a4]
    1f7c:      	ldr	w15, [sp, #0x1cc]
    1f80:      	ldr	w16, [sp, #0x1a4]
    1f84:      	add	w15, w15, w16
    1f88:      	str	w15, [sp, #0x1a0]
    1f8c:      	ldr	w15, [sp, #0x1a0]
    1f90:      	subs	w15, w14, w15
    1f94:      	and	w15, w15, #0xf
    1f98:      	str	w15, [sp, #0x19c]
    1f9c:      	ldr	w15, [sp, #0x1a0]
    1fa0:      	subs	w15, w14, w15
    1fa4:      	cset	w15, lo
    1fa8:      	str	w15, [sp, #0x198]
    1fac:      	ldr	w15, [sp, #0x1c8]
    1fb0:      	ldr	w16, [sp, #0x198]
    1fb4:      	add	w15, w15, w16
    1fb8:      	str	w15, [sp, #0x194]
    1fbc:      	ldr	w15, [sp, #0x194]
    1fc0:      	subs	w15, w14, w15
    1fc4:      	and	w15, w15, #0xf
    1fc8:      	str	w15, [sp, #0x190]
    1fcc:      	ldr	w15, [sp, #0x194]
    1fd0:      	subs	w15, w14, w15
    1fd4:      	cset	w15, lo
    1fd8:      	str	w15, [sp, #0x18c]
    1fdc:      	ldr	w15, [sp, #0x1c4]
    1fe0:      	ldr	w16, [sp, #0x18c]
    1fe4:      	add	w15, w15, w16
    1fe8:      	str	w15, [sp, #0x188]
    1fec:      	ldr	w15, [sp, #0x188]
    1ff0:      	subs	w15, w14, w15
    1ff4:      	and	w15, w15, #0xf
    1ff8:      	str	w15, [sp, #0x184]
    1ffc:      	ldr	w15, [sp, #0x188]
    2000:      	subs	w15, w14, w15
    2004:      	cset	w15, lo
    2008:      	str	w15, [sp, #0x180]
    200c:      	ldr	w15, [sp, #0x1c0]
    2010:      	ldr	w16, [sp, #0x180]
    2014:      	add	w15, w15, w16
    2018:      	str	w15, [sp, #0x17c]
    201c:      	ldr	w15, [sp, #0x17c]
    2020:      	subs	w15, w14, w15
    2024:      	and	w15, w15, #0xf
    2028:      	str	w15, [sp, #0x178]
    202c:      	ldr	w15, [sp, #0x17c]
    2030:      	subs	w15, w14, w15
    2034:      	cset	w15, lo
    2038:      	str	w15, [sp, #0x174]
    203c:      	ldr	w15, [sp, #0x1bc]
    2040:      	ldr	w16, [sp, #0x174]
    2044:      	add	w15, w15, w16
    2048:      	str	w15, [sp, #0x170]
    204c:      	ldr	w15, [sp, #0x170]
    2050:      	subs	w15, w14, w15
    2054:      	and	w15, w15, #0xf
    2058:      	str	w15, [sp, #0x16c]
    205c:      	ldr	w15, [sp, #0x170]
    2060:      	subs	w15, w14, w15
    2064:      	cset	w15, lo
    2068:      	str	w15, [sp, #0x168]
    206c:      	ldr	w15, [sp, #0x1b8]
    2070:      	ldr	w16, [sp, #0x168]
    2074:      	add	w15, w15, w16
    2078:      	str	w15, [sp, #0x164]
    207c:      	ldr	w15, [sp, #0x164]
    2080:      	subs	w15, w14, w15
    2084:      	and	w15, w15, #0xf
    2088:      	str	w15, [sp, #0x160]
    208c:      	ldr	w16, [sp, #0x1f4]
    2090:      	ldr	w15, [sp, #0x1f0]
    2094:      	lsl	w15, w15, #3
    2098:      	orr	w15, w15, w16, lsr #1
    209c:      	and	w15, w15, #0xf
    20a0:      	str	w15, [sp, #0x15c]
    20a4:      	ldr	w16, [sp, #0x1f0]
    20a8:      	ldr	w15, [sp, #0x1ec]
    20ac:      	lsl	w15, w15, #3
    20b0:      	orr	w15, w15, w16, lsr #1
    20b4:      	and	w15, w15, #0xf
    20b8:      	str	w15, [sp, #0x158]
    20bc:      	ldr	w16, [sp, #0x1ec]
    20c0:      	ldr	w15, [sp, #0x1e8]
    20c4:      	lsl	w15, w15, #3
    20c8:      	orr	w15, w15, w16, lsr #1
    20cc:      	and	w15, w15, #0xf
    20d0:      	str	w15, [sp, #0x154]
    20d4:      	ldr	w16, [sp, #0x1e8]
    20d8:      	ldr	w15, [sp, #0x1e4]
    20dc:      	lsl	w15, w15, #3
    20e0:      	orr	w15, w15, w16, lsr #1
    20e4:      	and	w15, w15, #0xf
    20e8:      	str	w15, [sp, #0x150]
    20ec:      	ldr	w16, [sp, #0x1e4]
    20f0:      	ldr	w15, [sp, #0x1e0]
    20f4:      	lsl	w15, w15, #3
    20f8:      	orr	w15, w15, w16, lsr #1
    20fc:      	and	w15, w15, #0xf
    2100:      	str	w15, [sp, #0x14c]
    2104:      	ldr	w16, [sp, #0x1e0]
    2108:      	ldr	w15, [sp, #0x1dc]
    210c:      	lsl	w15, w15, #3
    2110:      	orr	w15, w15, w16, lsr #1
    2114:      	and	w15, w15, #0xf
    2118:      	str	w15, [sp, #0x148]
    211c:      	ldr	w16, [sp, #0x1dc]
    2120:      	ldr	w15, [sp, #0x1d8]
    2124:      	lsl	w15, w15, #3
    2128:      	orr	w15, w15, w16, lsr #1
    212c:      	and	w15, w15, #0xf
    2130:      	str	w15, [sp, #0x144]
    2134:      	ldr	w15, [sp, #0x1d8]
    2138:      	lsr	w15, w15, #1
    213c:      	and	w15, w15, #0xf
    2140:      	str	w15, [sp, #0x140]
    2144:      	ldr	w15, [sp, #0x1b4]
    2148:      	and	w15, w14, w15
    214c:      	str	w15, [sp, #0x13c]
    2150:      	ldr	w15, [sp, #0x1a8]
    2154:      	and	w15, w13, w15
    2158:      	str	w15, [sp, #0x138]
    215c:      	ldr	w15, [sp, #0x19c]
    2160:      	and	w15, w12, w15
    2164:      	str	w15, [sp, #0x134]
    2168:      	ldr	w15, [sp, #0x190]
    216c:      	and	w15, w11, w15
    2170:      	str	w15, [sp, #0x130]
    2174:      	ldr	w15, [sp, #0x184]
    2178:      	and	w15, w11, w15
    217c:      	str	w15, [sp, #0x12c]
    2180:      	ldr	w15, [sp, #0x178]
    2184:      	and	w15, w10, w15
    2188:      	str	w15, [sp, #0x128]
    218c:      	ldr	w15, [sp, #0x16c]
    2190:      	and	w15, w9, w15
    2194:      	str	w15, [sp, #0x124]
    2198:      	ldr	w15, [sp, #0x160]
    219c:      	and	w15, w8, w15
    21a0:      	str	w15, [sp, #0x120]
    21a4:      	ldr	w15, [sp, #0x15c]
    21a8:      	ldr	w16, [sp, #0x13c]
    21ac:      	eor	w15, w15, w16
    21b0:      	str	w15, [sp, #0x11c]
    21b4:      	ldr	w15, [sp, #0x158]
    21b8:      	ldr	w16, [sp, #0x138]
    21bc:      	eor	w15, w15, w16
    21c0:      	str	w15, [sp, #0x118]
    21c4:      	ldr	w15, [sp, #0x154]
    21c8:      	ldr	w16, [sp, #0x134]
    21cc:      	eor	w15, w15, w16
    21d0:      	str	w15, [sp, #0x114]
    21d4:      	ldr	w15, [sp, #0x150]
    21d8:      	ldr	w16, [sp, #0x130]
    21dc:      	eor	w15, w15, w16
    21e0:      	str	w15, [sp, #0x110]
    21e4:      	ldr	w15, [sp, #0x14c]
    21e8:      	ldr	w16, [sp, #0x12c]
    21ec:      	eor	w15, w15, w16
    21f0:      	str	w15, [sp, #0x10c]
    21f4:      	ldr	w15, [sp, #0x148]
    21f8:      	ldr	w16, [sp, #0x128]
    21fc:      	eor	w15, w15, w16
    2200:      	str	w15, [sp, #0x108]
    2204:      	ldr	w15, [sp, #0x144]
    2208:      	ldr	w16, [sp, #0x124]
    220c:      	eor	w15, w15, w16
    2210:      	str	w15, [sp, #0x104]
    2214:      	ldr	w15, [sp, #0x140]
    2218:      	ldr	w16, [sp, #0x120]
    221c:      	eor	w15, w15, w16
    2220:      	str	w15, [sp, #0x100]
    2224:      	ldr	w15, [sp, #0x11c]
    2228:      	and	w15, w15, #0x1
    222c:      	str	w15, [sp, #0xfc]
    2230:      	ldr	w15, [sp, #0x118]
    2234:      	and	w15, w15, w14
    2238:      	str	w15, [sp, #0xf8]
    223c:      	ldr	w15, [sp, #0x114]
    2240:      	and	w15, w15, w14
    2244:      	str	w15, [sp, #0xf4]
    2248:      	ldr	w15, [sp, #0x110]
    224c:      	and	w15, w15, w14
    2250:      	str	w15, [sp, #0xf0]
    2254:      	ldr	w15, [sp, #0x10c]
    2258:      	and	w15, w15, w14
    225c:      	str	w15, [sp, #0xec]
    2260:      	ldr	w15, [sp, #0x108]
    2264:      	and	w15, w15, w14
    2268:      	str	w15, [sp, #0xe8]
    226c:      	ldr	w15, [sp, #0x104]
    2270:      	and	w15, w15, w14
    2274:      	str	w15, [sp, #0xe4]
    2278:      	ldr	w15, [sp, #0x100]
    227c:      	and	w15, w15, w14
    2280:      	str	w15, [sp, #0xe0]
    2284:      	ldr	w15, [sp, #0xfc]
    2288:      	subs	w15, w14, w15
    228c:      	and	w15, w15, #0xf
    2290:      	str	w15, [sp, #0xdc]
    2294:      	ldr	w15, [sp, #0xfc]
    2298:      	subs	w15, w14, w15
    229c:      	cset	w15, lo
    22a0:      	str	w15, [sp, #0xd8]
    22a4:      	ldr	w15, [sp, #0xf8]
    22a8:      	ldr	w16, [sp, #0xd8]
    22ac:      	add	w15, w15, w16
    22b0:      	str	w15, [sp, #0xd4]
    22b4:      	ldr	w15, [sp, #0xd4]
    22b8:      	subs	w15, w14, w15
    22bc:      	and	w15, w15, #0xf
    22c0:      	str	w15, [sp, #0xd0]
    22c4:      	ldr	w15, [sp, #0xd4]
    22c8:      	subs	w15, w14, w15
    22cc:      	cset	w15, lo
    22d0:      	str	w15, [sp, #0xcc]
    22d4:      	ldr	w15, [sp, #0xf4]
    22d8:      	ldr	w16, [sp, #0xcc]
    22dc:      	add	w15, w15, w16
    22e0:      	str	w15, [sp, #0xc8]
    22e4:      	ldr	w15, [sp, #0xc8]
    22e8:      	subs	w15, w14, w15
    22ec:      	and	w15, w15, #0xf
    22f0:      	str	w15, [sp, #0xc4]
    22f4:      	ldr	w15, [sp, #0xc8]
    22f8:      	subs	w15, w14, w15
    22fc:      	cset	w15, lo
    2300:      	str	w15, [sp, #0xc0]
    2304:      	ldr	w15, [sp, #0xf0]
    2308:      	ldr	w16, [sp, #0xc0]
    230c:      	add	w15, w15, w16
    2310:      	str	w15, [sp, #0xbc]
    2314:      	ldr	w15, [sp, #0xbc]
    2318:      	subs	w15, w14, w15
    231c:      	and	w15, w15, #0xf
    2320:      	str	w15, [sp, #0xb8]
    2324:      	ldr	w15, [sp, #0xbc]
    2328:      	subs	w15, w14, w15
    232c:      	cset	w15, lo
    2330:      	str	w15, [sp, #0xb4]
    2334:      	ldr	w15, [sp, #0xec]
    2338:      	ldr	w16, [sp, #0xb4]
    233c:      	add	w15, w15, w16
    2340:      	str	w15, [sp, #0xb0]
    2344:      	ldr	w15, [sp, #0xb0]
    2348:      	subs	w15, w14, w15
    234c:      	and	w15, w15, #0xf
    2350:      	str	w15, [sp, #0xac]
    2354:      	ldr	w15, [sp, #0xb0]
    2358:      	subs	w15, w14, w15
    235c:      	cset	w15, lo
    2360:      	str	w15, [sp, #0xa8]
    2364:      	ldr	w15, [sp, #0xe8]
    2368:      	ldr	w16, [sp, #0xa8]
    236c:      	add	w15, w15, w16
    2370:      	str	w15, [sp, #0xa4]
    2374:      	ldr	w15, [sp, #0xa4]
    2378:      	subs	w15, w14, w15
    237c:      	and	w15, w15, #0xf
    2380:      	str	w15, [sp, #0xa0]
    2384:      	ldr	w15, [sp, #0xa4]
    2388:      	subs	w15, w14, w15
    238c:      	cset	w15, lo
    2390:      	str	w15, [sp, #0x9c]
    2394:      	ldr	w15, [sp, #0xe4]
    2398:      	ldr	w16, [sp, #0x9c]
    239c:      	add	w15, w15, w16
    23a0:      	str	w15, [sp, #0x98]
    23a4:      	ldr	w15, [sp, #0x98]
    23a8:      	subs	w15, w14, w15
    23ac:      	and	w15, w15, #0xf
    23b0:      	str	w15, [sp, #0x94]
    23b4:      	ldr	w15, [sp, #0x98]
    23b8:      	subs	w15, w14, w15
    23bc:      	cset	w15, lo
    23c0:      	str	w15, [sp, #0x90]
    23c4:      	ldr	w15, [sp, #0xe0]
    23c8:      	ldr	w16, [sp, #0x90]
    23cc:      	add	w15, w15, w16
    23d0:      	str	w15, [sp, #0x8c]
    23d4:      	ldr	w15, [sp, #0x8c]
    23d8:      	subs	w15, w14, w15
    23dc:      	and	w15, w15, #0xf
    23e0:      	str	w15, [sp, #0x88]
    23e4:      	ldr	w16, [sp, #0x11c]
    23e8:      	ldr	w15, [sp, #0x118]
    23ec:      	lsl	w15, w15, #3
    23f0:      	orr	w15, w15, w16, lsr #1
    23f4:      	and	w15, w15, #0xf
    23f8:      	str	w15, [sp, #0x84]
    23fc:      	ldr	w16, [sp, #0x118]
    2400:      	ldr	w15, [sp, #0x114]
    2404:      	lsl	w15, w15, #3
    2408:      	orr	w15, w15, w16, lsr #1
    240c:      	and	w15, w15, #0xf
    2410:      	str	w15, [sp, #0x80]
    2414:      	ldr	w16, [sp, #0x114]
    2418:      	ldr	w15, [sp, #0x110]
    241c:      	lsl	w15, w15, #3
    2420:      	orr	w15, w15, w16, lsr #1
    2424:      	and	w15, w15, #0xf
    2428:      	str	w15, [sp, #0x7c]
    242c:      	ldr	w16, [sp, #0x110]
    2430:      	ldr	w15, [sp, #0x10c]
    2434:      	lsl	w15, w15, #3
    2438:      	orr	w15, w15, w16, lsr #1
    243c:      	and	w15, w15, #0xf
    2440:      	str	w15, [sp, #0x78]
    2444:      	ldr	w16, [sp, #0x10c]
    2448:      	ldr	w15, [sp, #0x108]
    244c:      	lsl	w15, w15, #3
    2450:      	orr	w15, w15, w16, lsr #1
    2454:      	and	w15, w15, #0xf
    2458:      	str	w15, [sp, #0x74]
    245c:      	ldr	w16, [sp, #0x108]
    2460:      	ldr	w15, [sp, #0x104]
    2464:      	lsl	w15, w15, #3
    2468:      	orr	w15, w15, w16, lsr #1
    246c:      	and	w15, w15, #0xf
    2470:      	str	w15, [sp, #0x70]
    2474:      	ldr	w16, [sp, #0x104]
    2478:      	ldr	w15, [sp, #0x100]
    247c:      	lsl	w15, w15, #3
    2480:      	orr	w15, w15, w16, lsr #1
    2484:      	and	w15, w15, #0xf
    2488:      	str	w15, [sp, #0x6c]
    248c:      	ldr	w15, [sp, #0x100]
    2490:      	lsr	w15, w15, #1
    2494:      	and	w15, w15, #0xf
    2498:      	str	w15, [sp, #0x68]
    249c:      	ldr	w15, [sp, #0xdc]
    24a0:      	and	w14, w14, w15
    24a4:      	str	w14, [sp, #0x64]
    24a8:      	ldr	w14, [sp, #0xd0]
    24ac:      	and	w13, w13, w14
    24b0:      	str	w13, [sp, #0x60]
    24b4:      	ldr	w13, [sp, #0xc4]
    24b8:      	and	w12, w12, w13
    24bc:      	str	w12, [sp, #0x5c]
    24c0:      	ldr	w12, [sp, #0xb8]
    24c4:      	and	w12, w11, w12
    24c8:      	str	w12, [sp, #0x58]
    24cc:      	ldr	w12, [sp, #0xac]
    24d0:      	and	w11, w11, w12
    24d4:      	str	w11, [sp, #0x54]
    24d8:      	ldr	w11, [sp, #0xa0]
    24dc:      	and	w10, w10, w11
    24e0:      	str	w10, [sp, #0x50]
    24e4:      	ldr	w10, [sp, #0x94]
    24e8:      	and	w9, w9, w10
    24ec:      	str	w9, [sp, #0x4c]
    24f0:      	ldr	w9, [sp, #0x88]
    24f4:      	and	w8, w8, w9
    24f8:      	str	w8, [sp, #0x48]
    24fc:      	ldr	w8, [sp, #0x84]
    2500:      	ldr	w9, [sp, #0x64]
    2504:      	eor	w8, w8, w9
    2508:      	str	w8, [sp, #0x44]
    250c:      	ldr	w8, [sp, #0x80]
    2510:      	ldr	w9, [sp, #0x60]
    2514:      	eor	w8, w8, w9
    2518:      	str	w8, [sp, #0x40]
    251c:      	ldr	w8, [sp, #0x7c]
    2520:      	ldr	w9, [sp, #0x5c]
    2524:      	eor	w8, w8, w9
    2528:      	str	w8, [sp, #0x3c]
    252c:      	ldr	w8, [sp, #0x78]
    2530:      	ldr	w9, [sp, #0x58]
    2534:      	eor	w8, w8, w9
    2538:      	str	w8, [sp, #0x38]
    253c:      	ldr	w8, [sp, #0x74]
    2540:      	ldr	w9, [sp, #0x54]
    2544:      	eor	w8, w8, w9
    2548:      	str	w8, [sp, #0x34]
    254c:      	ldr	w8, [sp, #0x70]
    2550:      	ldr	w9, [sp, #0x50]
    2554:      	eor	w8, w8, w9
    2558:      	str	w8, [sp, #0x30]
    255c:      	ldr	w8, [sp, #0x6c]
    2560:      	ldr	w9, [sp, #0x4c]
    2564:      	eor	w8, w8, w9
    2568:      	str	w8, [sp, #0x2c]
    256c:      	ldr	w8, [sp, #0x68]
    2570:      	ldr	w9, [sp, #0x48]
    2574:      	eor	w8, w8, w9
    2578:      	str	w8, [sp, #0x28]
    257c:      	ldr	w8, [sp, #0x44]
    2580:      	eor	w8, w8, #0xf
    2584:      	str	w8, [sp, #0x24]
    2588:      	ldr	w8, [sp, #0x40]
    258c:      	eor	w8, w8, #0xf
    2590:      	str	w8, [sp, #0x20]
    2594:      	ldr	w8, [sp, #0x3c]
    2598:      	eor	w8, w8, #0xf
    259c:      	str	w8, [sp, #0x1c]
    25a0:      	ldr	w8, [sp, #0x38]
    25a4:      	eor	w8, w8, #0xf
    25a8:      	str	w8, [sp, #0x18]
    25ac:      	ldr	w8, [sp, #0x34]
    25b0:      	eor	w8, w8, #0xf
    25b4:      	str	w8, [sp, #0x14]
    25b8:      	ldr	w8, [sp, #0x30]
    25bc:      	eor	w8, w8, #0xf
    25c0:      	str	w8, [sp, #0x10]
    25c4:      	ldr	w8, [sp, #0x2c]
    25c8:      	eor	w8, w8, #0xf
    25cc:      	str	w8, [sp, #0xc]
    25d0:      	ldr	w8, [sp, #0x28]
    25d4:      	eor	w8, w8, #0xf
    25d8:      	str	w8, [sp, #0x8]
    25dc:      	ldr	w8, [sp, #0x24]
    25e0:      	ldr	w9, [sp, #0x20]
    25e4:      	orr	w8, w8, w9, lsl #4
    25e8:      	ldr	w9, [sp, #0x1c]
    25ec:      	orr	w8, w8, w9, lsl #8
    25f0:      	ldr	w9, [sp, #0x18]
    25f4:      	orr	w8, w8, w9, lsl #12
    25f8:      	ldr	w9, [sp, #0x14]
    25fc:      	orr	w8, w8, w9, lsl #16
    2600:      	ldr	w9, [sp, #0x10]
    2604:      	orr	w8, w8, w9, lsl #20
    2608:      	ldr	w9, [sp, #0xc]
    260c:      	orr	w8, w8, w9, lsl #24
    2610:      	ldr	w9, [sp, #0x8]
    2614:      	orr	w8, w8, w9, lsl #28
    2618:      	str	w8, [sp, #0x4]
    261c:      	ldr	w0, [sp, #0x4]
    2620:      	add	sp, sp, #0x790
    2624:      	ldr	x29, [sp], #0x10
    2628:      	ret

000000000000262c <main>:
    262c:      	sub	sp, sp, #0x90
    2630:      	stp	x29, x30, [sp, #0x80]
    2634:      	add	x29, sp, #0x80
    2638:      	stur	wzr, [x29, #-0x4]
    263c:      	stur	w0, [x29, #-0x8]
    2640:      	stur	x1, [x29, #-0x10]
    2644:      	ldur	w8, [x29, #-0x8]
    2648:      	subs	w8, w8, #0x1
    264c:      	b.ne	0x26a0 <main+0x74>
    2650:      	b	0x2654 <main+0x28>
    2654:      	b	0x2658 <main+0x2c>
    2658:      	sub	x1, x29, #0x18
    265c:      	add	x2, x1, #0x4
    2660:      	adrp	x0, 0x2000 <kernel+0x17a8>
    2664:      	add	x0, x0, #0x8a8
    2668:      	bl	0x710 <__isoc99_scanf@plt>
    266c:      	subs	w8, w0, #0x2
    2670:      	b.ne	0x2698 <main+0x6c>
    2674:      	b	0x2678 <main+0x4c>
    2678:      	ldur	w0, [x29, #-0x18]
    267c:      	ldur	w1, [x29, #-0x14]
    2680:      	bl	0x858 <kernel>
    2684:      	mov	w1, w0
    2688:      	adrp	x0, 0x2000 <kernel+0x17a8>
    268c:      	add	x0, x0, #0x8ad
    2690:      	bl	0x720 <printf@plt>
    2694:      	b	0x2658 <main+0x2c>
    2698:      	stur	wzr, [x29, #-0x4]
    269c:      	b	0x2814 <main+0x1e8>
    26a0:      	ldur	w8, [x29, #-0x8]
    26a4:      	subs	w8, w8, #0x3
    26a8:      	b.eq	0x26bc <main+0x90>
    26ac:      	b	0x26b0 <main+0x84>
    26b0:      	mov	w8, #0x3                // =3
    26b4:      	stur	w8, [x29, #-0x4]
    26b8:      	b	0x2814 <main+0x1e8>
    26bc:      	ldur	x8, [x29, #-0x10]
    26c0:      	ldr	x0, [x8, #0x8]
    26c4:      	mov	x1, xzr
    26c8:      	str	x1, [sp, #0x8]
    26cc:      	mov	w2, #0xa                // =10
    26d0:      	str	w2, [sp, #0x14]
    26d4:      	bl	0x6b0 <strtoul@plt>
    26d8:      	ldr	x1, [sp, #0x8]
    26dc:      	ldr	w2, [sp, #0x14]
    26e0:      	stur	x0, [x29, #-0x20]
    26e4:      	ldur	x8, [x29, #-0x10]
    26e8:      	ldr	x0, [x8, #0x10]
    26ec:      	bl	0x6b0 <strtoul@plt>
    26f0:      	mov	w8, w0
    26f4:      	stur	w8, [x29, #-0x24]
    26f8:      	stur	xzr, [x29, #-0x30]
    26fc:      	mov	w0, #0x1                // =1
    2700:      	add	x1, sp, #0x40
    2704:      	bl	0x6e0 <clock_gettime@plt>
    2708:      	cbz	w0, 0x271c <main+0xf0>
    270c:      	b	0x2710 <main+0xe4>
    2710:      	mov	w8, #0x2                // =2
    2714:      	stur	w8, [x29, #-0x4]
    2718:      	b	0x2814 <main+0x1e8>
    271c:      	str	xzr, [sp, #0x28]
    2720:      	b	0x2724 <main+0xf8>
    2724:      	ldr	x8, [sp, #0x28]
    2728:      	ldur	x9, [x29, #-0x20]
    272c:      	subs	x8, x8, x9
    2730:      	b.hs	0x27a8 <main+0x17c>
    2734:      	b	0x2738 <main+0x10c>
    2738:      	str	wzr, [sp, #0x24]
    273c:      	b	0x2740 <main+0x114>
    2740:      	ldr	w8, [sp, #0x24]
    2744:      	subs	w8, w8, #0x2
    2748:      	b.hs	0x277c <main+0x150>
    274c:      	b	0x2750 <main+0x124>
    2750:      	sub	x0, x29, #0x24
    2754:      	bl	0x2824 <csrd_matrix_next_value>
    2758:      	ldr	w8, [sp, #0x24]
    275c:      	mov	w9, w8
    2760:      	sub	x8, x29, #0x18
    2764:      	str	w0, [x8, x9, lsl #2]
    2768:      	b	0x276c <main+0x140>
    276c:      	ldr	w8, [sp, #0x24]
    2770:      	add	w8, w8, #0x1
    2774:      	str	w8, [sp, #0x24]
    2778:      	b	0x2740 <main+0x114>
    277c:      	ldur	w0, [x29, #-0x18]
    2780:      	ldur	w1, [x29, #-0x14]
    2784:      	bl	0x858 <kernel>
    2788:      	ldur	x8, [x29, #-0x30]
    278c:      	add	x8, x8, w0, uxtw
    2790:      	stur	x8, [x29, #-0x30]
    2794:      	b	0x2798 <main+0x16c>
    2798:      	ldr	x8, [sp, #0x28]
    279c:      	add	x8, x8, #0x1
    27a0:      	str	x8, [sp, #0x28]
    27a4:      	b	0x2724 <main+0xf8>
    27a8:      	mov	w0, #0x1                // =1
    27ac:      	add	x1, sp, #0x30
    27b0:      	bl	0x6e0 <clock_gettime@plt>
    27b4:      	cbz	w0, 0x27c8 <main+0x19c>
    27b8:      	b	0x27bc <main+0x190>
    27bc:      	mov	w8, #0x2                // =2
    27c0:      	stur	w8, [x29, #-0x4]
    27c4:      	b	0x2814 <main+0x1e8>
    27c8:      	ldr	x8, [sp, #0x30]
    27cc:      	ldr	x9, [sp, #0x40]
    27d0:      	subs	x8, x8, x9
    27d4:      	scvtf	d2, x8
    27d8:      	ldr	x8, [sp, #0x38]
    27dc:      	ldr	x9, [sp, #0x48]
    27e0:      	subs	x8, x8, x9
    27e4:      	scvtf	d0, x8
    27e8:      	adrp	x8, 0x2000 <kernel+0x17a8>
    27ec:      	ldr	d1, [x8, #0x8a0]
    27f0:      	fmadd	d0, d0, d1, d2
    27f4:      	str	d0, [sp, #0x18]
    27f8:      	ldr	d0, [sp, #0x18]
    27fc:      	ldur	x1, [x29, #-0x30]
    2800:      	adrp	x0, 0x2000 <kernel+0x17a8>
    2804:      	add	x0, x0, #0x8b1
    2808:      	bl	0x720 <printf@plt>
    280c:      	stur	wzr, [x29, #-0x4]
    2810:      	b	0x2814 <main+0x1e8>
    2814:      	ldur	w0, [x29, #-0x4]
    2818:      	ldp	x29, x30, [sp, #0x80]
    281c:      	add	sp, sp, #0x90
    2820:      	ret

0000000000002824 <csrd_matrix_next_value>:
    2824:      	sub	sp, sp, #0x10
    2828:      	str	x0, [sp, #0x8]
    282c:      	ldr	x8, [sp, #0x8]
    2830:      	ldr	w10, [x8]
    2834:      	ldr	x9, [sp, #0x8]
    2838:      	ldr	w8, [x9]
    283c:      	eor	w8, w8, w10, lsl #13
    2840:      	str	w8, [x9]
    2844:      	ldr	x8, [sp, #0x8]
    2848:      	ldr	w10, [x8]
    284c:      	ldr	x9, [sp, #0x8]
    2850:      	ldr	w8, [x9]
    2854:      	eor	w8, w8, w10, lsr #17
    2858:      	str	w8, [x9]
    285c:      	ldr	x8, [sp, #0x8]
    2860:      	ldr	w10, [x8]
    2864:      	ldr	x9, [sp, #0x8]
    2868:      	ldr	w8, [x9]
    286c:      	eor	w8, w8, w10, lsl #5
    2870:      	str	w8, [x9]
    2874:      	ldr	x8, [sp, #0x8]
    2878:      	ldr	w0, [x8]
    287c:      	add	sp, sp, #0x10
    2880:      	ret

Disassembly of section .fini:

0000000000002884 <_fini>:
    2884:      	nop
    2888:      	stp	x29, x30, [sp, #-0x10]!
    288c:      	mov	x29, sp
    2890:      	ldp	x29, x30, [sp], #0x10
    2894:      	ret
