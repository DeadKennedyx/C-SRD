
/work/experiments/runs/positional-widths-comparison-20261110/matrix/crc32_byte/build-clang-O2-pgo-limbs16/program:	file format elf64-littleaarch64

Disassembly of section .init:

0000000000000678 <_init>:
     678:      	nop
     67c:      	stp	x29, x30, [sp, #-0x10]!
     680:      	mov	x29, sp
     684:      	bl	0x8f4 <call_weak_fn>
     688:      	ldp	x29, x30, [sp], #0x10
     68c:      	ret

Disassembly of section .plt:

0000000000000690 <.plt>:
     690:      	stp	x16, x30, [sp, #-0x10]!
     694:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e35c>
     698:      	ldr	x17, [x16, #0xff8]
     69c:      	add	x16, x16, #0xff8
     6a0:      	br	x17
     6a4:      	nop
     6a8:      	nop
     6ac:      	nop

00000000000006b0 <strtoul@plt>:
     6b0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6b4:      	ldr	x17, [x16]
     6b8:      	add	x16, x16, #0x0
     6bc:      	br	x17

00000000000006c0 <__libc_start_main@plt>:
     6c0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6c4:      	ldr	x17, [x16, #0x8]
     6c8:      	add	x16, x16, #0x8
     6cc:      	br	x17

00000000000006d0 <__cxa_finalize@plt>:
     6d0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6d4:      	ldr	x17, [x16, #0x10]
     6d8:      	add	x16, x16, #0x10
     6dc:      	br	x17

00000000000006e0 <clock_gettime@plt>:
     6e0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6e4:      	ldr	x17, [x16, #0x18]
     6e8:      	add	x16, x16, #0x18
     6ec:      	br	x17

00000000000006f0 <__gmon_start__@plt>:
     6f0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6f4:      	ldr	x17, [x16, #0x20]
     6f8:      	add	x16, x16, #0x20
     6fc:      	br	x17

0000000000000700 <abort@plt>:
     700:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     704:      	ldr	x17, [x16, #0x28]
     708:      	add	x16, x16, #0x28
     70c:      	br	x17

0000000000000710 <__isoc99_scanf@plt>:
     710:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     714:      	ldr	x17, [x16, #0x30]
     718:      	add	x16, x16, #0x30
     71c:      	br	x17

0000000000000720 <printf@plt>:
     720:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     724:      	ldr	x17, [x16, #0x38]
     728:      	add	x16, x16, #0x38
     72c:      	br	x17

Disassembly of section .text:

0000000000000740 <kernel>:
     740:      	and	w8, w0, #0xffff
     744:      	and	w9, w1, #0xff
     748:      	mov	w12, #0x10000           // =65536
     74c:      	eor	w9, w8, w9
     750:      	mov	w8, #0x76dc             // =30428
     754:      	mov	w11, #0x832             // =2098
     758:      	eor	w10, w9, #0xffff
     75c:      	mvn	w16, w0
     760:      	bic	w12, w12, w0
     764:      	sbfx	w14, w10, #0, #1
     768:      	lsr	w17, w16, #5
     76c:      	orr	w12, w10, w12
     770:      	sbfx	w0, w10, #1, #1
     774:      	mov	w13, #0x1064            // =4196
     778:      	mov	w9, #0xedb8             // =60856
     77c:      	and	w18, w14, w8
     780:      	and	w11, w14, w11
     784:      	mov	w15, #0x20c8            // =8392
     788:      	eor	w14, w18, w16, lsr #18
     78c:      	eor	w12, w11, w12, lsr #5
     790:      	and	w16, w17, #0x1000
     794:      	sbfx	w17, w10, #2, #1
     798:      	and	w11, w0, w13
     79c:      	and	w0, w0, w9
     7a0:      	lsl	w13, w14, #13
     7a4:      	orr	w16, w12, w16
     7a8:      	eor	w14, w14, w0
     7ac:      	and	w1, w17, w9
     7b0:      	eor	w11, w16, w11
     7b4:      	sbfx	w18, w10, #3, #1
     7b8:      	and	w16, w13, #0x2000
     7bc:      	and	w15, w17, w15
     7c0:      	eor	w17, w1, w14, lsr #1
     7c4:      	orr	w16, w16, w11
     7c8:      	mov	w0, #0x4190             // =16784
     7cc:      	and	w13, w13, #0x4000
     7d0:      	eor	w15, w16, w15
     7d4:      	and	w16, w18, w0
     7d8:      	lsr	w0, w17, #1
     7dc:      	orr	w13, w15, w13
     7e0:      	sbfx	w15, w10, #4, #1
     7e4:      	lsr	w14, w14, #3
     7e8:      	eor	w13, w13, w16
     7ec:      	mov	w16, #0x8320            // =33568
     7f0:      	sbfx	w10, w10, #5, #1
     7f4:      	orr	w13, w13, w0, lsl #15
     7f8:      	and	w1, w15, w16
     7fc:      	sbfx	w12, w12, #1, #1
     800:      	and	w8, w10, w8
     804:      	tst	w11, #0x4
     808:      	and	w13, w13, #0xfffc
     80c:      	eor	w13, w13, w1
     810:      	lsr	w13, w13, #1
     814:      	bfi	w13, w14, #15, #1
     818:      	and	w14, w10, w16
     81c:      	lsl	w10, w11, #29
     820:      	mov	w11, #0x1247            // =4679
     824:      	eor	w13, w13, w14
     828:      	lsr	w14, w17, #3
     82c:      	mov	w17, #0x3b6e            // =15214
     830:      	lsr	w13, w13, #1
     834:      	and	w15, w17, w15, lsr #2
     838:      	and	w17, w12, w16
     83c:      	and	w10, w16, w10, asr #31
     840:      	bfi	w13, w14, #15, #1
     844:      	and	w14, w18, w9
     848:      	and	w9, w12, w9
     84c:      	eor	w14, w0, w14
     850:      	eor	w8, w8, w9
     854:      	mov	w12, #0xffff            // =65535
     858:      	eor	w13, w13, w17
     85c:      	eor	w14, w15, w14, lsr #3
     860:      	csel	w11, w12, w11, eq
     864:      	lsr	w13, w13, #1
     868:      	eor	w8, w14, w8
     86c:      	orr	w9, w13, w14, lsl #15
     870:      	eor	w8, w11, w8, lsr #1
     874:      	and	w9, w9, #0xffff
     878:      	eor	w9, w9, w10
     87c:      	orr	w8, w9, w8, lsl #16
     880:      	eor	w0, w8, #0xffff
     884:      	ret
     888:      	nop
     88c:      	nop
     890:      	nop
     894:      	nop
     898:      	nop
     89c:      	nop
     8a0:      	nop
     8a4:      	nop
     8a8:      	nop
     8ac:      	nop
     8b0:      	nop
     8b4:      	nop
     8b8:      	nop
     8bc:      	nop

00000000000008c0 <_start>:
     8c0:      	nop
     8c4:      	mov	x29, #0x0               // =0
     8c8:      	mov	x30, #0x0               // =0
     8cc:      	mov	x5, x0
     8d0:      	ldr	x1, [sp]
     8d4:      	add	x2, sp, #0x8
     8d8:      	mov	x6, sp
     8dc:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e35c>
     8e0:      	ldr	x0, [x0, #0xfd8]
     8e4:      	mov	x3, #0x0                // =0
     8e8:      	mov	x4, #0x0                // =0
     8ec:      	bl	0x6c0 <__libc_start_main@plt>
     8f0:      	bl	0x700 <abort@plt>

00000000000008f4 <call_weak_fn>:
     8f4:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e35c>
     8f8:      	ldr	x0, [x0, #0xfd0]
     8fc:      	cbz	x0, 0x904 <call_weak_fn+0x10>
     900:      	b	0x6f0 <__gmon_start__@plt>
     904:      	ret
     908:      	nop
     90c:      	nop

0000000000000910 <deregister_tm_clones>:
     910:      	adrp	x0, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     914:      	add	x0, x0, #0x50
     918:      	adrp	x1, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     91c:      	add	x1, x1, #0x50
     920:      	cmp	x1, x0
     924:      	b.eq	0x93c <deregister_tm_clones+0x2c>
     928:      	adrp	x1, 0x1f000 <__FRAME_END__+0x1e35c>
     92c:      	ldr	x1, [x1, #0xfc0]
     930:      	cbz	x1, 0x93c <deregister_tm_clones+0x2c>
     934:      	mov	x16, x1
     938:      	br	x16
     93c:      	ret

0000000000000940 <register_tm_clones>:
     940:      	adrp	x0, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     944:      	add	x0, x0, #0x50
     948:      	adrp	x1, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     94c:      	add	x1, x1, #0x50
     950:      	sub	x1, x1, x0
     954:      	lsr	x2, x1, #63
     958:      	add	x1, x2, x1, asr #3
     95c:      	asr	x1, x1, #1
     960:      	cbz	x1, 0x978 <register_tm_clones+0x38>
     964:      	adrp	x2, 0x1f000 <__FRAME_END__+0x1e35c>
     968:      	ldr	x2, [x2, #0xfe0]
     96c:      	cbz	x2, 0x978 <register_tm_clones+0x38>
     970:      	mov	x16, x2
     974:      	br	x16
     978:      	ret
     97c:      	nop

0000000000000980 <__do_global_dtors_aux>:
     980:      	paciasp
     984:      	stp	x29, x30, [sp, #-0x20]!
     988:      	mov	x29, sp
     98c:      	str	x19, [sp, #0x10]
     990:      	adrp	x19, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     994:      	ldrb	w0, [x19, #0x50]
     998:      	tbnz	w0, #0x0, 0x9c0 <__do_global_dtors_aux+0x40>
     99c:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e35c>
     9a0:      	ldr	x0, [x0, #0xfc8]
     9a4:      	cbz	x0, 0x9b4 <__do_global_dtors_aux+0x34>
     9a8:      	adrp	x0, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     9ac:      	ldr	x0, [x0, #0x48]
     9b0:      	bl	0x6d0 <__cxa_finalize@plt>
     9b4:      	bl	0x910 <deregister_tm_clones>
     9b8:      	mov	w0, #0x1                // =1
     9bc:      	strb	w0, [x19, #0x50]
     9c0:      	ldr	x19, [sp, #0x10]
     9c4:      	ldp	x29, x30, [sp], #0x20
     9c8:      	autiasp
     9cc:      	ret

00000000000009d0 <frame_dummy>:
     9d0:      	bti	c
     9d4:      	b	0x940 <register_tm_clones>

00000000000009d8 <main>:
     9d8:      	sub	sp, sp, #0x50
     9dc:      	stp	x29, x30, [sp, #0x20]
     9e0:      	str	x21, [sp, #0x30]
     9e4:      	stp	x20, x19, [sp, #0x40]
     9e8:      	add	x29, sp, #0x20
     9ec:      	cmp	w0, #0x1
     9f0:      	b.ne	0xa68 <main+0x90>
     9f4:      	add	x21, sp, #0x10
     9f8:      	adrp	x0, 0x0 <strtoul@GLIBC_2.17>
     9fc:      	add	x0, x0, #0xb60
     a00:      	add	x1, sp, #0x10
     a04:      	add	x2, x21, #0x4
     a08:      	bl	0x710 <__isoc99_scanf@plt>
     a0c:      	cmp	w0, #0x2
     a10:      	b.ne	0xa50 <main+0x78>
     a14:      	adrp	x19, 0x0 <strtoul@GLIBC_2.17>
     a18:      	add	x19, x19, #0xb65
     a1c:      	adrp	x20, 0x0 <strtoul@GLIBC_2.17>
     a20:      	add	x20, x20, #0xb60
     a24:      	ldp	w0, w1, [sp, #0x10]
     a28:      	bl	0x740 <kernel>
     a2c:      	mov	w1, w0
     a30:      	mov	x0, x19
     a34:      	bl	0x720 <printf@plt>
     a38:      	add	x1, sp, #0x10
     a3c:      	add	x2, x21, #0x4
     a40:      	mov	x0, x20
     a44:      	bl	0x710 <__isoc99_scanf@plt>
     a48:      	cmp	w0, #0x2
     a4c:      	b.eq	0xa24 <main+0x4c>
     a50:      	mov	w0, wzr
     a54:      	ldp	x20, x19, [sp, #0x40]
     a58:      	ldr	x21, [sp, #0x30]
     a5c:      	ldp	x29, x30, [sp, #0x20]
     a60:      	add	sp, sp, #0x50
     a64:      	ret
     a68:      	cmp	w0, #0x3
     a6c:      	b.ne	0xab8 <main+0xe0>
     a70:      	ldr	x0, [x1, #0x8]
     a74:      	mov	x19, x1
     a78:      	mov	x1, xzr
     a7c:      	mov	w2, #0xa                // =10
     a80:      	bl	0x6b0 <strtoul@plt>
     a84:      	ldr	x8, [x19, #0x10]
     a88:      	mov	x20, x0
     a8c:      	mov	x1, xzr
     a90:      	mov	w2, #0xa                // =10
     a94:      	mov	x0, x8
     a98:      	bl	0x6b0 <strtoul@plt>
     a9c:      	mov	x21, x0
     aa0:      	add	x1, sp, #0x10
     aa4:      	mov	w0, #0x1                // =1
     aa8:      	bl	0x6e0 <clock_gettime@plt>
     aac:      	cbz	w0, 0xac0 <main+0xe8>
     ab0:      	mov	w0, #0x2                // =2
     ab4:      	b	0xa54 <main+0x7c>
     ab8:      	mov	w0, #0x3                // =3
     abc:      	b	0xa54 <main+0x7c>
     ac0:      	mov	x19, xzr
     ac4:      	cbz	x20, 0xaf4 <main+0x11c>
     ac8:      	eor	w8, w21, w21, lsl #13
     acc:      	eor	w8, w8, w8, lsr #17
     ad0:      	eor	w0, w8, w8, lsl #5
     ad4:      	eor	w8, w0, w0, lsl #13
     ad8:      	eor	w8, w8, w8, lsr #17
     adc:      	eor	w21, w8, w8, lsl #5
     ae0:      	mov	w1, w21
     ae4:      	bl	0x740 <kernel>
     ae8:      	add	x19, x19, w0, uxtw
     aec:      	subs	x20, x20, #0x1
     af0:      	b.ne	0xac8 <main+0xf0>
     af4:      	mov	x1, sp
     af8:      	mov	w0, #0x1                // =1
     afc:      	bl	0x6e0 <clock_gettime@plt>
     b00:      	cbnz	w0, 0xab0 <main+0xd8>
     b04:      	ldp	x8, x9, [sp]
     b08:      	adrp	x0, 0x0 <strtoul@GLIBC_2.17>
     b0c:      	add	x0, x0, #0xb69
     b10:      	ldp	x10, x11, [sp, #0x10]
     b14:      	mov	x1, x19
     b18:      	sub	x8, x8, x10
     b1c:      	sub	x9, x9, x11
     b20:      	scvtf	d0, x8
     b24:      	scvtf	d1, x9
     b28:      	adrp	x8, 0x0 <strtoul@GLIBC_2.17>
     b2c:      	ldr	d2, [x8, #0xb58]
     b30:      	fmadd	d0, d1, d2, d0
     b34:      	bl	0x720 <printf@plt>
     b38:      	b	0xa50 <main+0x78>

Disassembly of section .fini:

0000000000000b3c <_fini>:
     b3c:      	nop
     b40:      	stp	x29, x30, [sp, #-0x10]!
     b44:      	mov	x29, sp
     b48:      	ldp	x29, x30, [sp], #0x10
     b4c:      	ret
