
/work/experiments/runs/positional-widths-comparison-20261110/matrix/crc32_byte/build-gcc-O1-limbs16/program:	file format elf64-littleaarch64

Disassembly of section .init:

0000000000000738 <_init>:
     738:      	nop
     73c:      	stp	x29, x30, [sp, #-0x10]!
     740:      	mov	x29, sp
     744:      	bl	0x834 <call_weak_fn>
     748:      	ldp	x29, x30, [sp], #0x10
     74c:      	ret

Disassembly of section .plt:

0000000000000750 <.plt>:
     750:      	stp	x16, x30, [sp, #-0x10]!
     754:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e234>
     758:      	ldr	x17, [x16, #0xf78]
     75c:      	add	x16, x16, #0xf78
     760:      	br	x17
     764:      	nop
     768:      	nop
     76c:      	nop

0000000000000770 <strtoul@plt>:
     770:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e234>
     774:      	ldr	x17, [x16, #0xf80]
     778:      	add	x16, x16, #0xf80
     77c:      	br	x17

0000000000000780 <__libc_start_main@plt>:
     780:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e234>
     784:      	ldr	x17, [x16, #0xf88]
     788:      	add	x16, x16, #0xf88
     78c:      	br	x17

0000000000000790 <__cxa_finalize@plt>:
     790:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e234>
     794:      	ldr	x17, [x16, #0xf90]
     798:      	add	x16, x16, #0xf90
     79c:      	br	x17

00000000000007a0 <clock_gettime@plt>:
     7a0:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e234>
     7a4:      	ldr	x17, [x16, #0xf98]
     7a8:      	add	x16, x16, #0xf98
     7ac:      	br	x17

00000000000007b0 <__printf_chk@plt>:
     7b0:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e234>
     7b4:      	ldr	x17, [x16, #0xfa0]
     7b8:      	add	x16, x16, #0xfa0
     7bc:      	br	x17

00000000000007c0 <__stack_chk_fail@plt>:
     7c0:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e234>
     7c4:      	ldr	x17, [x16, #0xfa8]
     7c8:      	add	x16, x16, #0xfa8
     7cc:      	br	x17

00000000000007d0 <__gmon_start__@plt>:
     7d0:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e234>
     7d4:      	ldr	x17, [x16, #0xfb0]
     7d8:      	add	x16, x16, #0xfb0
     7dc:      	br	x17

00000000000007e0 <abort@plt>:
     7e0:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e234>
     7e4:      	ldr	x17, [x16, #0xfb8]
     7e8:      	add	x16, x16, #0xfb8
     7ec:      	br	x17

00000000000007f0 <__isoc99_scanf@plt>:
     7f0:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e234>
     7f4:      	ldr	x17, [x16, #0xfc0]
     7f8:      	add	x16, x16, #0xfc0
     7fc:      	br	x17

Disassembly of section .text:

0000000000000800 <_start>:
     800:      	nop
     804:      	mov	x29, #0x0               // =0
     808:      	mov	x30, #0x0               // =0
     80c:      	mov	x5, x0
     810:      	ldr	x1, [sp]
     814:      	add	x2, sp, #0x8
     818:      	mov	x6, sp
     81c:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e234>
     820:      	ldr	x0, [x0, #0xff0]
     824:      	mov	x3, #0x0                // =0
     828:      	mov	x4, #0x0                // =0
     82c:      	bl	0x780 <__libc_start_main@plt>
     830:      	bl	0x7e0 <abort@plt>

0000000000000834 <call_weak_fn>:
     834:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e234>
     838:      	ldr	x0, [x0, #0xfe0]
     83c:      	cbz	x0, 0x844 <call_weak_fn+0x10>
     840:      	b	0x7d0 <__gmon_start__@plt>
     844:      	ret
     848:      	nop
     84c:      	nop

0000000000000850 <deregister_tm_clones>:
     850:      	adrp	x0, 0x20000 <data_start>
     854:      	add	x0, x0, #0x10
     858:      	adrp	x1, 0x20000 <data_start>
     85c:      	add	x1, x1, #0x10
     860:      	cmp	x1, x0
     864:      	b.eq	0x87c <deregister_tm_clones+0x2c>
     868:      	adrp	x1, 0x1f000 <__FRAME_END__+0x1e234>
     86c:      	ldr	x1, [x1, #0xfd0]
     870:      	cbz	x1, 0x87c <deregister_tm_clones+0x2c>
     874:      	mov	x16, x1
     878:      	br	x16
     87c:      	ret

0000000000000880 <register_tm_clones>:
     880:      	adrp	x0, 0x20000 <data_start>
     884:      	add	x0, x0, #0x10
     888:      	adrp	x1, 0x20000 <data_start>
     88c:      	add	x1, x1, #0x10
     890:      	sub	x1, x1, x0
     894:      	lsr	x2, x1, #63
     898:      	add	x1, x2, x1, asr #3
     89c:      	asr	x1, x1, #1
     8a0:      	cbz	x1, 0x8b8 <register_tm_clones+0x38>
     8a4:      	adrp	x2, 0x1f000 <__FRAME_END__+0x1e234>
     8a8:      	ldr	x2, [x2, #0xff8]
     8ac:      	cbz	x2, 0x8b8 <register_tm_clones+0x38>
     8b0:      	mov	x16, x2
     8b4:      	br	x16
     8b8:      	ret
     8bc:      	nop

00000000000008c0 <__do_global_dtors_aux>:
     8c0:      	paciasp
     8c4:      	stp	x29, x30, [sp, #-0x20]!
     8c8:      	mov	x29, sp
     8cc:      	str	x19, [sp, #0x10]
     8d0:      	adrp	x19, 0x20000 <data_start>
     8d4:      	ldrb	w0, [x19, #0x10]
     8d8:      	tbnz	w0, #0x0, 0x900 <__do_global_dtors_aux+0x40>
     8dc:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e234>
     8e0:      	ldr	x0, [x0, #0xfd8]
     8e4:      	cbz	x0, 0x8f4 <__do_global_dtors_aux+0x34>
     8e8:      	adrp	x0, 0x20000 <data_start>
     8ec:      	ldr	x0, [x0, #0x8]
     8f0:      	bl	0x790 <__cxa_finalize@plt>
     8f4:      	bl	0x850 <deregister_tm_clones>
     8f8:      	mov	w0, #0x1                // =1
     8fc:      	strb	w0, [x19, #0x10]
     900:      	ldr	x19, [sp, #0x10]
     904:      	ldp	x29, x30, [sp], #0x20
     908:      	autiasp
     90c:      	ret

0000000000000910 <frame_dummy>:
     910:      	bti	c
     914:      	b	0x880 <register_tm_clones>

0000000000000918 <kernel>:
     918:      	lsr	w2, w0, #16
     91c:      	eor	w2, w2, #0xffff
     920:      	mvn	w0, w0
     924:      	and	w0, w0, #0xffff
     928:      	and	w1, w1, #0xff
     92c:      	eor	w0, w0, w1
     930:      	lsl	w5, w2, #15
     934:      	orr	w5, w5, w0, lsr #1
     938:      	and	w5, w5, #0xffff
     93c:      	sbfx	x1, x0, #0, #1
     940:      	mov	w4, #0x8320             // =33568
     944:      	and	w1, w1, w4
     948:      	eor	w5, w5, w1
     94c:      	mov	w3, #0xedb8             // =60856
     950:      	tst	x0, #0x1
     954:      	csel	w0, w3, wzr, ne
     958:      	eor	w1, w0, w2, lsr #1
     95c:      	lsl	w0, w1, #15
     960:      	orr	w0, w0, w5, lsr #1
     964:      	and	w0, w0, #0xffff
     968:      	sbfx	x2, x5, #0, #1
     96c:      	and	w2, w2, w4
     970:      	eor	w0, w0, w2
     974:      	tst	x5, #0x1
     978:      	csel	w2, w3, wzr, ne
     97c:      	eor	w1, w2, w1, lsr #1
     980:      	lsl	w2, w1, #15
     984:      	orr	w2, w2, w0, lsr #1
     988:      	and	w2, w2, #0xffff
     98c:      	sbfx	x5, x0, #0, #1
     990:      	and	w5, w5, w4
     994:      	eor	w2, w2, w5
     998:      	tst	x0, #0x1
     99c:      	csel	w0, w3, wzr, ne
     9a0:      	eor	w1, w0, w1, lsr #1
     9a4:      	lsl	w0, w1, #15
     9a8:      	orr	w0, w0, w2, lsr #1
     9ac:      	and	w0, w0, #0xffff
     9b0:      	sbfx	x5, x2, #0, #1
     9b4:      	and	w5, w5, w4
     9b8:      	eor	w0, w0, w5
     9bc:      	tst	x2, #0x1
     9c0:      	csel	w2, w3, wzr, ne
     9c4:      	eor	w1, w2, w1, lsr #1
     9c8:      	lsl	w2, w1, #15
     9cc:      	orr	w2, w2, w0, lsr #1
     9d0:      	and	w2, w2, #0xffff
     9d4:      	sbfx	x5, x0, #0, #1
     9d8:      	and	w5, w5, w4
     9dc:      	eor	w2, w2, w5
     9e0:      	tst	x0, #0x1
     9e4:      	csel	w0, w3, wzr, ne
     9e8:      	eor	w1, w0, w1, lsr #1
     9ec:      	lsl	w0, w1, #15
     9f0:      	orr	w0, w0, w2, lsr #1
     9f4:      	and	w0, w0, #0xffff
     9f8:      	sbfx	x5, x2, #0, #1
     9fc:      	and	w5, w5, w4
     a00:      	eor	w0, w0, w5
     a04:      	tst	x2, #0x1
     a08:      	csel	w2, w3, wzr, ne
     a0c:      	eor	w1, w2, w1, lsr #1
     a10:      	lsl	w2, w1, #15
     a14:      	orr	w2, w2, w0, lsr #1
     a18:      	and	w2, w2, #0xffff
     a1c:      	sbfx	x5, x0, #0, #1
     a20:      	and	w5, w5, w4
     a24:      	eor	w2, w2, w5
     a28:      	tst	x0, #0x1
     a2c:      	csel	w0, w3, wzr, ne
     a30:      	eor	w1, w0, w1, lsr #1
     a34:      	lsl	w0, w1, #15
     a38:      	orr	w0, w0, w2, lsr #1
     a3c:      	and	w0, w0, #0xffff
     a40:      	sbfx	x5, x2, #0, #1
     a44:      	and	w4, w5, w4
     a48:      	eor	w0, w0, w4
     a4c:      	eor	w0, w0, #0xffff
     a50:      	tst	x2, #0x1
     a54:      	csel	w3, w3, wzr, ne
     a58:      	eor	w1, w3, w1, lsr #1
     a5c:      	lsl	w1, w1, #16
     a60:      	eor	w1, w1, #0xffff0000
     a64:      	orr	w0, w0, w1
     a68:      	ret

0000000000000a6c <main>:
     a6c:      	sub	sp, sp, #0x60
     a70:      	stp	x29, x30, [sp, #0x30]
     a74:      	add	x29, sp, #0x30
     a78:      	stp	x19, x20, [sp, #0x40]
     a7c:      	mov	x19, x1
     a80:      	adrp	x1, 0x1f000 <__FRAME_END__+0x1e234>
     a84:      	ldr	x1, [x1, #0xfe8]
     a88:      	ldr	x2, [x1]
     a8c:      	str	x2, [sp, #0x28]
     a90:      	mov	x2, #0x0                // =0
     a94:      	cmp	w0, #0x1
     a98:      	b.eq	0xad8 <main+0x6c>
     a9c:      	mov	w20, #0x3               // =3
     aa0:      	cmp	w0, w20
     aa4:      	b.eq	0xb38 <main+0xcc>
     aa8:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e234>
     aac:      	ldr	x0, [x0, #0xfe8]
     ab0:      	ldr	x2, [sp, #0x28]
     ab4:      	ldr	x1, [x0]
     ab8:      	subs	x2, x2, x1
     abc:      	mov	x1, #0x0                // =0
     ac0:      	b.ne	0xc40 <main+0x1d4>
     ac4:      	mov	w0, w20
     ac8:      	ldp	x19, x20, [sp, #0x40]
     acc:      	ldp	x29, x30, [sp, #0x30]
     ad0:      	add	sp, sp, #0x60
     ad4:      	ret
     ad8:      	stp	x21, x22, [sp, #0x50]
     adc:      	add	x22, sp, #0x20
     ae0:      	add	x21, sp, #0x24
     ae4:      	adrp	x19, 0x0 <strtoul@GLIBC_2.17>
     ae8:      	add	x19, x19, #0xc70
     aec:      	adrp	x20, 0x0 <strtoul@GLIBC_2.17>
     af0:      	add	x20, x20, #0xc68
     af4:      	b	0xb14 <main+0xa8>
     af8:      	ldr	w1, [sp, #0x24]
     afc:      	ldr	w0, [sp, #0x20]
     b00:      	bl	0x918 <kernel>
     b04:      	mov	w2, w0
     b08:      	mov	x1, x20
     b0c:      	mov	w0, #0x2                // =2
     b10:      	bl	0x7b0 <__printf_chk@plt>
     b14:      	mov	x2, x21
     b18:      	mov	x1, x22
     b1c:      	mov	x0, x19
     b20:      	bl	0x7f0 <__isoc99_scanf@plt>
     b24:      	cmp	w0, #0x2
     b28:      	b.eq	0xaf8 <main+0x8c>
     b2c:      	mov	w20, #0x0               // =0
     b30:      	ldp	x21, x22, [sp, #0x50]
     b34:      	b	0xaa8 <main+0x3c>
     b38:      	stp	x21, x22, [sp, #0x50]
     b3c:      	mov	w2, #0xa                // =10
     b40:      	mov	x1, #0x0                // =0
     b44:      	ldr	x0, [x19, #0x8]
     b48:      	bl	0x770 <strtoul@plt>
     b4c:      	mov	x21, x0
     b50:      	mov	w2, #0xa                // =10
     b54:      	mov	x1, #0x0                // =0
     b58:      	ldr	x0, [x19, #0x10]
     b5c:      	bl	0x770 <strtoul@plt>
     b60:      	mov	x19, x0
     b64:      	mov	x1, sp
     b68:      	mov	w0, #0x1                // =1
     b6c:      	bl	0x7a0 <clock_gettime@plt>
     b70:      	cbnz	w0, 0xc28 <main+0x1bc>
     b74:      	cbz	x21, 0xc20 <main+0x1b4>
     b78:      	mov	x20, #0x0               // =0
     b7c:      	mov	x22, #0x0               // =0
     b80:      	eor	w19, w19, w19, lsl #13
     b84:      	eor	w19, w19, w19, lsr #17
     b88:      	eor	w0, w19, w19, lsl #5
     b8c:      	str	w0, [sp, #0x20]
     b90:      	eor	w19, w0, w0, lsl #13
     b94:      	eor	w19, w19, w19, lsr #17
     b98:      	eor	w19, w19, w19, lsl #5
     b9c:      	str	w19, [sp, #0x24]
     ba0:      	mov	w1, w19
     ba4:      	bl	0x918 <kernel>
     ba8:      	add	x22, x22, w0, uxtw
     bac:      	add	x20, x20, #0x1
     bb0:      	cmp	x21, x20
     bb4:      	b.ne	0xb80 <main+0x114>
     bb8:      	add	x1, sp, #0x10
     bbc:      	mov	w0, #0x1                // =1
     bc0:      	bl	0x7a0 <clock_gettime@plt>
     bc4:      	mov	w20, w0
     bc8:      	cbnz	w0, 0xc34 <main+0x1c8>
     bcc:      	ldr	x0, [sp, #0x18]
     bd0:      	ldr	x1, [sp, #0x8]
     bd4:      	sub	x0, x0, x1
     bd8:      	fmov	d1, x0
     bdc:      	scvtf	d1, d1
     be0:      	adrp	x0, 0x0 <strtoul@GLIBC_2.17>
     be4:      	ldr	d0, [x0, #0xc88]
     be8:      	fmul	d1, d1, d0
     bec:      	ldr	x0, [sp, #0x10]
     bf0:      	ldr	x1, [sp]
     bf4:      	sub	x0, x0, x1
     bf8:      	fmov	d0, x0
     bfc:      	scvtf	d0, d0
     c00:      	mov	x2, x22
     c04:      	fadd	d0, d1, d0
     c08:      	adrp	x1, 0x0 <strtoul@GLIBC_2.17>
     c0c:      	add	x1, x1, #0xc78
     c10:      	mov	w0, #0x2                // =2
     c14:      	bl	0x7b0 <__printf_chk@plt>
     c18:      	ldp	x21, x22, [sp, #0x50]
     c1c:      	b	0xaa8 <main+0x3c>
     c20:      	mov	x22, x21
     c24:      	b	0xbb8 <main+0x14c>
     c28:      	mov	w20, #0x2               // =2
     c2c:      	ldp	x21, x22, [sp, #0x50]
     c30:      	b	0xaa8 <main+0x3c>
     c34:      	mov	w20, #0x2               // =2
     c38:      	ldp	x21, x22, [sp, #0x50]
     c3c:      	b	0xaa8 <main+0x3c>
     c40:      	stp	x21, x22, [sp, #0x50]
     c44:      	bl	0x7c0 <__stack_chk_fail@plt>

Disassembly of section .fini:

0000000000000c48 <_fini>:
     c48:      	nop
     c4c:      	stp	x29, x30, [sp, #-0x10]!
     c50:      	mov	x29, sp
     c54:      	ldp	x29, x30, [sp], #0x10
     c58:      	ret
