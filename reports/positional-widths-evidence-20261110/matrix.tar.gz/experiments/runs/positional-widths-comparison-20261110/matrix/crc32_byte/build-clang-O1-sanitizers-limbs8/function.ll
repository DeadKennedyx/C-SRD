; ModuleID = '/work/experiments/runs/positional-widths-comparison-20261110/matrix/crc32_byte/build-clang-O1-sanitizers-limbs8/validation/compiler-0-O1/candidate.i'
source_filename = "/work/experiments/runs/positional-widths-comparison-20261110/matrix/crc32_byte/build-clang-O1-sanitizers-limbs8/validation/compiler-0-O1/candidate.i"
target datalayout = "e-m:e-i8:8:32-i16:16:32-i64:64-i128:128-n32:64-S128"
target triple = "aarch64-unknown-linux-gnu"

$asan.module_ctor = comdat any

@llvm.used = appending global [1 x ptr] [ptr @asan.module_ctor], section "llvm.metadata"
@___asan_globals_registered = common hidden global i64 0
@__start_asan_globals = extern_weak hidden global i64
@__stop_asan_globals = extern_weak hidden global i64
@llvm.global_ctors = appending global [1 x { i32, ptr, ptr }] [{ i32, ptr, ptr } { i32 1, ptr @asan.module_ctor, ptr @asan.module_ctor }]

; Function Attrs: mustprogress nofree norecurse nosync nounwind sanitize_address willreturn memory(none) uwtable
define dso_local i32 @kernel(i32 noundef %state, i32 noundef %byte) local_unnamed_addr #0 !func_sanitize !6 {
entry:
  %shr = lshr i32 %state, 8
  %and1 = and i32 %shr, 255
  %shr4 = lshr i32 %state, 16
  %and5 = and i32 %shr4, 255
  %xor23 = xor i32 %and1, 255
  %xor24 = xor i32 %and5, 255
  %0 = xor i32 %state, -1
  %and819 = xor i32 %byte, %state
  %1 = and i32 %and819, 255
  %xor30 = xor i32 %1, 255
  %and34 = and i32 %xor30, 1
  %and38 = shl nuw nsw i32 %xor30, 5
  %2 = icmp eq i32 %and34, 0
  %and40 = select i1 %2, i32 0, i32 255
  %shr53 = lshr i32 %xor30, 1
  %shl = shl nuw nsw i32 %xor23, 7
  %shl.masked = and i32 %shl, 128
  %and56 = or disjoint i32 %shr53, %shl.masked
  %shr59 = lshr i32 %xor23, 1
  %shl62 = shl nuw nsw i32 %xor24, 7
  %shl62.masked = and i32 %shl62, 128
  %and64 = or disjoint i32 %shl62.masked, %shr59
  %shr67 = lshr i32 %xor24, 1
  %3 = lshr i32 %0, 17
  %shl70.masked = and i32 %3, 128
  %and72 = or disjoint i32 %shr67, %shl70.masked
  %shr75 = lshr i32 %0, 25
  %and77 = and i32 %and38, 32
  %and78 = and i32 %and40, 131
  %and79 = and i32 %and40, 184
  %and80 = and i32 %and40, 237
  %xor81 = xor i32 %and56, %and77
  %xor82 = xor i32 %and78, %and64
  %xor83 = xor i32 %and79, %and72
  %xor84 = xor i32 %and80, %shr75
  %and90 = shl nuw nsw i32 %shr53, 5
  %4 = and i32 %xor30, 2
  %5 = icmp eq i32 %4, 0
  %and95 = select i1 %5, i32 0, i32 255
  %shr108 = lshr i32 %xor81, 1
  %shl111 = shl nuw nsw i32 %xor82, 7
  %shl111.masked = and i32 %shl111, 128
  %and113 = or i32 %shl111.masked, %shr108
  %shr116 = lshr i32 %xor82, 1
  %shl119 = shl nuw nsw i32 %shr67, 7
  %shl119.masked = and i32 %shl119, 128
  %and121 = or i32 %shr116, %shl119.masked
  %shr124 = lshr i32 %xor83, 1
  %shl127 = shl nuw nsw i32 %xor84, 7
  %shl127.masked = and i32 %shl127, 128
  %and129 = or i32 %shl127.masked, %shr124
  %shr132 = lshr i32 %xor84, 1
  %and134 = and i32 %and90, 32
  %and135 = and i32 %and95, 131
  %and136 = and i32 %and95, 184
  %and137 = and i32 %and95, 237
  %xor138 = xor i32 %and113, %and134
  %xor139 = xor i32 %and121, %and135
  %xor140 = xor i32 %and129, %and136
  %xor141 = xor i32 %shr132, %and137
  %and142 = and i32 %shr108, 1
  %and147 = shl nuw nsw i32 %and142, 5
  %6 = icmp eq i32 %and142, 0
  %and152 = select i1 %6, i32 0, i32 255
  %shr165 = lshr i32 %xor138, 1
  %shl168 = shl nuw nsw i32 %xor139, 7
  %or169 = or i32 %shr165, %shl168
  %and170 = and i32 %or169, 254
  %shr173 = lshr i32 %xor139, 1
  %shl176 = shl nuw nsw i32 %shr124, 7
  %or177 = or i32 %shr173, %shl176
  %and178 = and i32 %or177, 255
  %shr181 = lshr i32 %xor140, 1
  %shl184 = shl nuw nsw i32 %xor141, 7
  %or185 = or i32 %shr181, %shl184
  %and186 = and i32 %or185, 255
  %shr189 = lshr i32 %xor141, 1
  %and192 = and i32 %and152, 131
  %and193 = and i32 %and152, 184
  %and194 = and i32 %and152, 237
  %xor195 = xor i32 %and170, %and147
  %xor196 = xor i32 %and178, %and192
  %xor197 = xor i32 %and186, %and193
  %xor198 = xor i32 %shr189, %and194
  %and199 = and i32 %shr165, 1
  %and204 = shl nuw nsw i32 %and199, 5
  %7 = icmp eq i32 %and199, 0
  %and209 = select i1 %7, i32 0, i32 255
  %shr222 = lshr exact i32 %xor195, 1
  %shl225 = shl nuw nsw i32 %xor196, 7
  %shl225.masked = and i32 %shl225, 128
  %and227 = or disjoint i32 %shr222, %shl225.masked
  %shr230 = lshr i32 %xor196, 1
  %shl233 = shl nuw nsw i32 %and186, 7
  %shl233.masked = and i32 %shl233, 128
  %and235 = or disjoint i32 %shl233.masked, %shr230
  %shr238 = lshr i32 %xor197, 1
  %shl241 = shl nuw nsw i32 %xor198, 7
  %shl241.masked = and i32 %shl241, 128
  %and243 = or disjoint i32 %shr238, %shl241.masked
  %shr246 = lshr i32 %xor198, 1
  %and247 = and i32 %shr246, 255
  %and249 = and i32 %and209, 131
  %and250 = and i32 %and209, 184
  %and251 = and i32 %and209, 237
  %xor252 = xor i32 %and227, %and204
  %xor253 = xor i32 %and235, %and249
  %xor254 = xor i32 %and243, %and250
  %xor255 = xor i32 %and251, %and247
  %and256 = and i32 %shr222, 1
  %and261 = shl nuw nsw i32 %and256, 5
  %8 = icmp eq i32 %and256, 0
  %and266 = select i1 %8, i32 0, i32 255
  %shr279 = lshr i32 %xor252, 1
  %shl282 = shl nuw nsw i32 %xor253, 7
  %or283 = or i32 %shr279, %shl282
  %and284 = and i32 %or283, 254
  %shr287 = lshr i32 %xor253, 1
  %shl290 = shl nuw nsw i32 %shr238, 7
  %shl290.masked = and i32 %shl290, 128
  %and292 = or i32 %shr287, %shl290.masked
  %shr295 = lshr i32 %xor254, 1
  %shl298 = shl nuw nsw i32 %xor255, 7
  %shl298.masked = and i32 %shl298, 128
  %and300 = or i32 %shr295, %shl298.masked
  %shr303 = lshr i32 %xor255, 1
  %and306 = and i32 %and266, 131
  %and307 = and i32 %and266, 184
  %and308 = and i32 %and266, 237
  %xor309 = xor i32 %and284, %and261
  %xor310 = xor i32 %and292, %and306
  %xor311 = xor i32 %and300, %and307
  %xor312 = xor i32 %and308, %shr303
  %and313 = and i32 %shr279, 1
  %and318 = shl nuw nsw i32 %and313, 5
  %9 = icmp eq i32 %and313, 0
  %and323 = select i1 %9, i32 0, i32 255
  %shr336 = lshr exact i32 %xor309, 1
  %shl339 = shl nuw nsw i32 %xor310, 7
  %shl339.masked = and i32 %shl339, 128
  %and341 = or disjoint i32 %shr336, %shl339.masked
  %shr344 = lshr i32 %xor310, 1
  %shl347 = shl nuw nsw i32 %shr295, 7
  %or348 = or i32 %shr344, %shl347
  %and349 = and i32 %or348, 255
  %shr352 = lshr i32 %xor311, 1
  %shl355 = shl nuw nsw i32 %xor312, 7
  %or356 = or i32 %shr352, %shl355
  %and357 = and i32 %or356, 255
  %shr360 = lshr i32 %xor312, 1
  %and363 = and i32 %and323, 131
  %and364 = and i32 %and323, 184
  %and365 = and i32 %and323, 237
  %xor366 = xor i32 %and341, %and318
  %xor367 = xor i32 %and349, %and363
  %xor368 = xor i32 %and357, %and364
  %xor369 = xor i32 %and365, %shr360
  %and370 = and i32 %shr336, 1
  %and375 = shl nuw nsw i32 %and370, 5
  %10 = icmp eq i32 %and370, 0
  %and380 = select i1 %10, i32 0, i32 255
  %shr393 = lshr i32 %xor366, 1
  %shl396 = shl nuw nsw i32 %xor367, 7
  %or397 = or i32 %shr393, %shl396
  %and398 = and i32 %or397, 254
  %shr401 = lshr i32 %xor367, 1
  %shl404 = shl nuw nsw i32 %and357, 7
  %shl404.masked = and i32 %shl404, 128
  %and406 = or disjoint i32 %shr401, %shl404.masked
  %shr409 = lshr i32 %xor368, 1
  %shl412 = shl nuw nsw i32 %xor369, 7
  %shl412.masked = and i32 %shl412, 128
  %and414 = or disjoint i32 %shr409, %shl412.masked
  %shr417 = lshr i32 %xor369, 1
  %and418 = and i32 %shr417, 255
  %and420 = and i32 %and380, 131
  %and421 = and i32 %and380, 184
  %and422 = and i32 %and380, 237
  %xor423 = xor i32 %and398, %and375
  %xor424 = xor i32 %and406, %and420
  %xor425 = xor i32 %and414, %and421
  %xor426 = xor i32 %and422, %and418
  %and427 = and i32 %shr393, 1
  %and432 = shl nuw nsw i32 %and427, 5
  %11 = icmp eq i32 %and427, 0
  %and437 = select i1 %11, i32 0, i32 255
  %shr450 = lshr exact i32 %xor423, 1
  %shl453 = shl nuw nsw i32 %xor424, 7
  %shl453.masked = and i32 %shl453, 128
  %and455 = or disjoint i32 %shr450, %shl453.masked
  %shr458 = lshr i32 %xor424, 1
  %shl461 = shl nuw nsw i32 %shr409, 7
  %shl461.masked = and i32 %shl461, 128
  %and463 = or i32 %shr458, %shl461.masked
  %shr466 = lshr i32 %xor425, 1
  %shl469 = shl nuw nsw i32 %xor426, 7
  %shl469.masked = and i32 %shl469, 128
  %and471 = or i32 %shl469.masked, %shr466
  %shr474 = lshr i32 %xor426, 1
  %and477 = and i32 %and437, 131
  %and478 = and i32 %and437, 184
  %and479 = and i32 %and437, 237
  %xor480 = xor i32 %and455, %and432
  %xor481 = xor i32 %and463, %and477
  %xor482 = xor i32 %and471, %and478
  %xor485 = shl nuw nsw i32 %xor481, 8
  %12 = or disjoint i32 %xor485, %xor480
  %xor486 = shl nuw nsw i32 %xor482, 16
  %shl494 = xor i32 %xor486, 16711680
  %13 = xor i32 %shr474, %and479
  %14 = xor i32 %13, -1
  %shl498 = shl i32 %14, 24
  %15 = or i32 %12, %shl498
  %16 = or i32 %15, %shl494
  %or499 = xor i32 %16, 65535
  ret i32 %or499
}

declare void @__asan_register_elf_globals(i64, i64, i64)

declare void @__asan_init()

; Function Attrs: nounwind uwtable
define internal void @asan.module_ctor() #1 comdat {
  call void @__asan_init()
  call void @__asan_version_mismatch_check_v8()
  call void @__asan_register_elf_globals(i64 ptrtoint (ptr @___asan_globals_registered to i64), i64 ptrtoint (ptr @__start_asan_globals to i64), i64 ptrtoint (ptr @__stop_asan_globals to i64))
  ret void
}

declare void @__asan_version_mismatch_check_v8()

attributes #0 = { mustprogress nofree norecurse nosync nounwind sanitize_address willreturn memory(none) uwtable "frame-pointer"="non-leaf" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+fp-armv8,+neon,+outline-atomics,+v8a,-fmv" }
attributes #1 = { nounwind uwtable "frame-pointer"="non-leaf" }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 1, !"wchar_size", i32 4}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 1}
!5 = !{!"Ubuntu clang version 18.1.3 (1ubuntu1)"}
!6 = !{i32 -1056584962, i32 -455559067}
