
/work/experiments/runs/positional-widths-comparison-20261110/matrix/crc32_byte/build-gcc-O1-sanitizers-limbs16/program:	file format elf64-littleaarch64

Disassembly of section .init:

00000000000011c0 <_init>:
    11c0:      	nop
    11c4:      	stp	x29, x30, [sp, #-0x10]!
    11c8:      	mov	x29, sp
    11cc:      	bl	0x13b4 <call_weak_fn>
    11d0:      	ldp	x29, x30, [sp], #0x10
    11d4:      	ret

Disassembly of section .plt:

00000000000011e0 <.plt>:
    11e0:      	stp	x16, x30, [sp, #-0x10]!
    11e4:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1cf5c>
    11e8:      	ldr	x17, [x16, #0xf08]
    11ec:      	add	x16, x16, #0xf08
    11f0:      	br	x17
    11f4:      	nop
    11f8:      	nop
    11fc:      	nop

0000000000001200 <__asan_report_store4@plt>:
    1200:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1cf5c>
    1204:      	ldr	x17, [x16, #0xf10]
    1208:      	add	x16, x16, #0xf10
    120c:      	br	x17

0000000000001210 <__ubsan_handle_type_mismatch_v1_abort@plt>:
    1210:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1cf5c>
    1214:      	ldr	x17, [x16, #0xf18]
    1218:      	add	x16, x16, #0xf18
    121c:      	br	x17

0000000000001220 <__asan_register_globals@plt>:
    1220:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1cf5c>
    1224:      	ldr	x17, [x16, #0xf20]
    1228:      	add	x16, x16, #0xf20
    122c:      	br	x17

0000000000001230 <__stack_chk_fail@plt>:
    1230:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1cf5c>
    1234:      	ldr	x17, [x16, #0xf28]
    1238:      	add	x16, x16, #0xf28
    123c:      	br	x17

0000000000001240 <__ubsan_handle_nonnull_arg_abort@plt>:
    1240:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1cf5c>
    1244:      	ldr	x17, [x16, #0xf30]
    1248:      	add	x16, x16, #0xf30
    124c:      	br	x17

0000000000001250 <__ubsan_handle_sub_overflow_abort@plt>:
    1250:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1cf5c>
    1254:      	ldr	x17, [x16, #0xf38]
    1258:      	add	x16, x16, #0xf38
    125c:      	br	x17

0000000000001260 <__asan_report_load4@plt>:
    1260:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1cf5c>
    1264:      	ldr	x17, [x16, #0xf40]
    1268:      	add	x16, x16, #0xf40
    126c:      	br	x17

0000000000001270 <__cxa_finalize@plt>:
    1270:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1cf5c>
    1274:      	ldr	x17, [x16, #0xf48]
    1278:      	add	x16, x16, #0xf48
    127c:      	br	x17

0000000000001280 <__libc_start_main@plt>:
    1280:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1cf5c>
    1284:      	ldr	x17, [x16, #0xf50]
    1288:      	add	x16, x16, #0xf50
    128c:      	br	x17

0000000000001290 <__asan_unregister_globals@plt>:
    1290:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1cf5c>
    1294:      	ldr	x17, [x16, #0xf58]
    1298:      	add	x16, x16, #0xf58
    129c:      	br	x17

00000000000012a0 <__asan_handle_no_return@plt>:
    12a0:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1cf5c>
    12a4:      	ldr	x17, [x16, #0xf60]
    12a8:      	add	x16, x16, #0xf60
    12ac:      	br	x17

00000000000012b0 <__asan_init@plt>:
    12b0:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1cf5c>
    12b4:      	ldr	x17, [x16, #0xf68]
    12b8:      	add	x16, x16, #0xf68
    12bc:      	br	x17

00000000000012c0 <strtoul@plt>:
    12c0:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1cf5c>
    12c4:      	ldr	x17, [x16, #0xf70]
    12c8:      	add	x16, x16, #0xf70
    12cc:      	br	x17

00000000000012d0 <clock_gettime@plt>:
    12d0:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1cf5c>
    12d4:      	ldr	x17, [x16, #0xf78]
    12d8:      	add	x16, x16, #0xf78
    12dc:      	br	x17

00000000000012e0 <__asan_report_load8@plt>:
    12e0:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1cf5c>
    12e4:      	ldr	x17, [x16, #0xf80]
    12e8:      	add	x16, x16, #0xf80
    12ec:      	br	x17

00000000000012f0 <abort@plt>:
    12f0:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1cf5c>
    12f4:      	ldr	x17, [x16, #0xf88]
    12f8:      	add	x16, x16, #0xf88
    12fc:      	br	x17

0000000000001300 <__asan_stack_malloc_2@plt>:
    1300:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1cf5c>
    1304:      	ldr	x17, [x16, #0xf90]
    1308:      	add	x16, x16, #0xf90
    130c:      	br	x17

0000000000001310 <__asan_version_mismatch_check_v8@plt>:
    1310:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1cf5c>
    1314:      	ldr	x17, [x16, #0xf98]
    1318:      	add	x16, x16, #0xf98
    131c:      	br	x17

0000000000001320 <__isoc99_scanf@plt>:
    1320:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1cf5c>
    1324:      	ldr	x17, [x16, #0xfa0]
    1328:      	add	x16, x16, #0xfa0
    132c:      	br	x17

0000000000001330 <__printf_chk@plt>:
    1330:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1cf5c>
    1334:      	ldr	x17, [x16, #0xfa8]
    1338:      	add	x16, x16, #0xfa8
    133c:      	br	x17

0000000000001340 <__gmon_start__@plt>:
    1340:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1cf5c>
    1344:      	ldr	x17, [x16, #0xfb0]
    1348:      	add	x16, x16, #0xfb0
    134c:      	br	x17

0000000000001350 <__ubsan_handle_pointer_overflow_abort@plt>:
    1350:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1cf5c>
    1354:      	ldr	x17, [x16, #0xfb8]
    1358:      	add	x16, x16, #0xfb8
    135c:      	br	x17

Disassembly of section .text:

0000000000001380 <_start>:
    1380:      	nop
    1384:      	mov	x29, #0x0               // =0
    1388:      	mov	x30, #0x0               // =0
    138c:      	mov	x5, x0
    1390:      	ldr	x1, [sp]
    1394:      	add	x2, sp, #0x8
    1398:      	mov	x6, sp
    139c:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1cf5c>
    13a0:      	ldr	x0, [x0, #0xfd0]
    13a4:      	mov	x3, #0x0                // =0
    13a8:      	mov	x4, #0x0                // =0
    13ac:      	bl	0x1280 <__libc_start_main@plt>
    13b0:      	bl	0x12f0 <abort@plt>

00000000000013b4 <call_weak_fn>:
    13b4:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1cf5c>
    13b8:      	ldr	x0, [x0, #0xff0]
    13bc:      	cbz	x0, 0x13c4 <call_weak_fn+0x10>
    13c0:      	b	0x1340 <__gmon_start__@plt>
    13c4:      	ret
    13c8:      	nop
    13cc:      	nop

00000000000013d0 <deregister_tm_clones>:
    13d0:      	adrp	x0, 0x20000 <data_start>
    13d4:      	add	x0, x0, #0x780
    13d8:      	adrp	x1, 0x20000 <data_start>
    13dc:      	add	x1, x1, #0x780
    13e0:      	cmp	x1, x0
    13e4:      	b.eq	0x13fc <deregister_tm_clones+0x2c>
    13e8:      	adrp	x1, 0x1f000 <__FRAME_END__+0x1cf5c>
    13ec:      	ldr	x1, [x1, #0xfe8]
    13f0:      	cbz	x1, 0x13fc <deregister_tm_clones+0x2c>
    13f4:      	mov	x16, x1
    13f8:      	br	x16
    13fc:      	ret

0000000000001400 <register_tm_clones>:
    1400:      	adrp	x0, 0x20000 <data_start>
    1404:      	add	x0, x0, #0x780
    1408:      	adrp	x1, 0x20000 <data_start>
    140c:      	add	x1, x1, #0x780
    1410:      	sub	x1, x1, x0
    1414:      	lsr	x2, x1, #63
    1418:      	add	x1, x2, x1, asr #3
    141c:      	asr	x1, x1, #1
    1420:      	cbz	x1, 0x1438 <register_tm_clones+0x38>
    1424:      	adrp	x2, 0x1f000 <__FRAME_END__+0x1cf5c>
    1428:      	ldr	x2, [x2, #0xff8]
    142c:      	cbz	x2, 0x1438 <register_tm_clones+0x38>
    1430:      	mov	x16, x2
    1434:      	br	x16
    1438:      	ret
    143c:      	nop

0000000000001440 <__do_global_dtors_aux>:
    1440:      	paciasp
    1444:      	stp	x29, x30, [sp, #-0x20]!
    1448:      	mov	x29, sp
    144c:      	str	x19, [sp, #0x10]
    1450:      	adrp	x19, 0x20000 <data_start>
    1454:      	ldrb	w0, [x19, #0x780]
    1458:      	tbnz	w0, #0x0, 0x1480 <__do_global_dtors_aux+0x40>
    145c:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1cf5c>
    1460:      	ldr	x0, [x0, #0xfd8]
    1464:      	cbz	x0, 0x1474 <__do_global_dtors_aux+0x34>
    1468:      	adrp	x0, 0x20000 <data_start>
    146c:      	ldr	x0, [x0, #0x8]
    1470:      	bl	0x1270 <__cxa_finalize@plt>
    1474:      	bl	0x13d0 <deregister_tm_clones>
    1478:      	mov	w0, #0x1                // =1
    147c:      	strb	w0, [x19, #0x780]
    1480:      	ldr	x19, [sp, #0x10]
    1484:      	ldp	x29, x30, [sp], #0x20
    1488:      	autiasp
    148c:      	ret

0000000000001490 <frame_dummy>:
    1490:      	bti	c
    1494:      	b	0x1400 <register_tm_clones>

0000000000001498 <kernel>:
    1498:      	lsr	w2, w0, #16
    149c:      	eor	w2, w2, #0xffff
    14a0:      	mvn	w0, w0
    14a4:      	and	w0, w0, #0xffff
    14a8:      	and	w1, w1, #0xff
    14ac:      	eor	w0, w0, w1
    14b0:      	lsl	w5, w2, #15
    14b4:      	orr	w5, w5, w0, lsr #1
    14b8:      	and	w5, w5, #0xffff
    14bc:      	sbfx	x1, x0, #0, #1
    14c0:      	mov	w4, #0x8320             // =33568
    14c4:      	and	w1, w1, w4
    14c8:      	eor	w5, w5, w1
    14cc:      	mov	w3, #0xedb8             // =60856
    14d0:      	tst	x0, #0x1
    14d4:      	csel	w0, w3, wzr, ne
    14d8:      	eor	w1, w0, w2, lsr #1
    14dc:      	lsl	w0, w1, #15
    14e0:      	orr	w0, w0, w5, lsr #1
    14e4:      	and	w0, w0, #0xffff
    14e8:      	sbfx	x2, x5, #0, #1
    14ec:      	and	w2, w2, w4
    14f0:      	eor	w0, w0, w2
    14f4:      	tst	x5, #0x1
    14f8:      	csel	w2, w3, wzr, ne
    14fc:      	eor	w1, w2, w1, lsr #1
    1500:      	lsl	w2, w1, #15
    1504:      	orr	w2, w2, w0, lsr #1
    1508:      	and	w2, w2, #0xffff
    150c:      	sbfx	x5, x0, #0, #1
    1510:      	and	w5, w5, w4
    1514:      	eor	w2, w2, w5
    1518:      	tst	x0, #0x1
    151c:      	csel	w0, w3, wzr, ne
    1520:      	eor	w1, w0, w1, lsr #1
    1524:      	lsl	w0, w1, #15
    1528:      	orr	w0, w0, w2, lsr #1
    152c:      	and	w0, w0, #0xffff
    1530:      	sbfx	x5, x2, #0, #1
    1534:      	and	w5, w5, w4
    1538:      	eor	w0, w0, w5
    153c:      	tst	x2, #0x1
    1540:      	csel	w2, w3, wzr, ne
    1544:      	eor	w1, w2, w1, lsr #1
    1548:      	lsl	w2, w1, #15
    154c:      	orr	w2, w2, w0, lsr #1
    1550:      	and	w2, w2, #0xffff
    1554:      	sbfx	x5, x0, #0, #1
    1558:      	and	w5, w5, w4
    155c:      	eor	w2, w2, w5
    1560:      	tst	x0, #0x1
    1564:      	csel	w0, w3, wzr, ne
    1568:      	eor	w1, w0, w1, lsr #1
    156c:      	lsl	w0, w1, #15
    1570:      	orr	w0, w0, w2, lsr #1
    1574:      	and	w0, w0, #0xffff
    1578:      	sbfx	x5, x2, #0, #1
    157c:      	and	w5, w5, w4
    1580:      	eor	w0, w0, w5
    1584:      	tst	x2, #0x1
    1588:      	csel	w2, w3, wzr, ne
    158c:      	eor	w1, w2, w1, lsr #1
    1590:      	lsl	w2, w1, #15
    1594:      	orr	w2, w2, w0, lsr #1
    1598:      	and	w2, w2, #0xffff
    159c:      	sbfx	x5, x0, #0, #1
    15a0:      	and	w5, w5, w4
    15a4:      	eor	w2, w2, w5
    15a8:      	tst	x0, #0x1
    15ac:      	csel	w0, w3, wzr, ne
    15b0:      	eor	w1, w0, w1, lsr #1
    15b4:      	lsl	w0, w1, #15
    15b8:      	orr	w0, w0, w2, lsr #1
    15bc:      	and	w0, w0, #0xffff
    15c0:      	sbfx	x5, x2, #0, #1
    15c4:      	and	w4, w5, w4
    15c8:      	eor	w0, w0, w4
    15cc:      	eor	w0, w0, #0xffff
    15d0:      	tst	x2, #0x1
    15d4:      	csel	w3, w3, wzr, ne
    15d8:      	eor	w1, w3, w1, lsr #1
    15dc:      	lsl	w1, w1, #16
    15e0:      	eor	w1, w1, #0xffff0000
    15e4:      	orr	w0, w0, w1
    15e8:      	ret

00000000000015ec <_sub_I_00099_0>:
    15ec:      	stp	x29, x30, [sp, #-0x10]!
    15f0:      	mov	x29, sp
    15f4:      	bl	0x12b0 <__asan_init@plt>
    15f8:      	bl	0x1310 <__asan_version_mismatch_check_v8@plt>
    15fc:      	ldp	x29, x30, [sp], #0x10
    1600:      	ret

0000000000001604 <main>:
    1604:      	sub	sp, sp, #0x130
    1608:      	stp	x29, x30, [sp, #0xd0]
    160c:      	add	x29, sp, #0xd0
    1610:      	stp	x19, x20, [sp, #0xe0]
    1614:      	stp	x21, x22, [sp, #0xf0]
    1618:      	stp	x23, x24, [sp, #0x100]
    161c:      	stp	x27, x28, [sp, #0x120]
    1620:      	mov	w21, w0
    1624:      	mov	x20, x1
    1628:      	add	x23, sp, #0x10
    162c:      	mov	x28, x23
    1630:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1cf5c>
    1634:      	ldr	x0, [x0, #0xfe0]
    1638:      	ldr	w0, [x0]
    163c:      	cbnz	w0, 0x1948 <main+0x344>
    1640:      	mov	x19, x23
    1644:      	mov	x0, #0x8ab3             // =35507
    1648:      	movk	x0, #0x41b5, lsl #16
    164c:      	str	x0, [x19], #0xc0
    1650:      	adrp	x0, 0x1000 <strtoul@GLIBC_2.17+0x1000>
    1654:      	add	x0, x0, #0xc28
    1658:      	str	x0, [x23, #0x8]
    165c:      	adrp	x0, 0x1000 <strtoul@GLIBC_2.17+0x1000>
    1660:      	add	x0, x0, #0x604
    1664:      	str	x0, [x23, #0x10]
    1668:      	lsr	x24, x23, #3
    166c:      	mov	x0, #0x1000000000       // =68719476736
    1670:      	add	x1, x24, x0
    1674:      	mov	w2, #-0xe0e0e0f         // =-235802127
    1678:      	str	w2, [x24, x0]
    167c:      	add	w2, w2, #0x130, lsl #12 // =0x130000
    1680:      	str	w2, [x1, #0x4]
    1684:      	mov	w0, #-0xd0e0000         // =-219021312
    1688:      	str	w0, [x1, #0x8]
    168c:      	str	w0, [x1, #0xc]
    1690:      	mov	w0, #0xf300             // =62208
    1694:      	movk	w0, #0xf3f3, lsl #16
    1698:      	str	w0, [x1, #0x10]
    169c:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1cf5c>
    16a0:      	ldr	x0, [x0, #0xfc8]
    16a4:      	ldr	x1, [x0]
    16a8:      	str	x1, [sp, #0xc8]
    16ac:      	mov	x1, #0x0                // =0
    16b0:      	cmp	w21, #0x1
    16b4:      	b.eq	0x195c <main+0x358>
    16b8:      	cmp	w21, #0x3
    16bc:      	b.ne	0x1b04 <main+0x500>
    16c0:      	stp	x25, x26, [sp, #0x110]
    16c4:      	add	x2, x20, #0x8
    16c8:      	cmn	x20, #0x8
    16cc:      	b.hs	0x1a00 <main+0x3fc>
    16d0:      	adds	x1, x20, #0x8
    16d4:      	b.eq	0x1a10 <main+0x40c>
    16d8:      	tst	x1, #0x7
    16dc:      	b.ne	0x1a10 <main+0x40c>
    16e0:      	add	x0, x20, #0x8
    16e4:      	lsr	x2, x0, #3
    16e8:      	mov	x1, #0x1000000000       // =68719476736
    16ec:      	ldrsb	w1, [x2, x1]
    16f0:      	cbnz	w1, 0x1a20 <main+0x41c>
    16f4:      	ldr	x0, [x20, #0x8]
    16f8:      	cbz	x0, 0x1a24 <main+0x420>
    16fc:      	mov	w2, #0xa                // =10
    1700:      	mov	x1, #0x0                // =0
    1704:      	bl	0x12c0 <strtoul@plt>
    1708:      	mov	x25, x0
    170c:      	add	x2, x20, #0x10
    1710:      	cmn	x20, #0x10
    1714:      	b.hs	0x1a38 <main+0x434>
    1718:      	adds	x1, x20, #0x10
    171c:      	b.eq	0x1a4c <main+0x448>
    1720:      	tst	x1, #0x7
    1724:      	b.ne	0x1a4c <main+0x448>
    1728:      	add	x0, x20, #0x10
    172c:      	lsr	x2, x0, #3
    1730:      	mov	x1, #0x1000000000       // =68719476736
    1734:      	ldrsb	w1, [x2, x1]
    1738:      	cbnz	w1, 0x1a5c <main+0x458>
    173c:      	ldr	x0, [x20, #0x10]
    1740:      	cbz	x0, 0x1a60 <main+0x45c>
    1744:      	mov	w2, #0xa                // =10
    1748:      	mov	x1, #0x0                // =0
    174c:      	bl	0x12c0 <strtoul@plt>
    1750:      	sub	x2, x19, #0x90
    1754:      	lsr	x3, x2, #3
    1758:      	mov	x1, #0x1000000000       // =68719476736
    175c:      	ldrsb	w1, [x3, x1]
    1760:      	cmp	w1, #0x0
    1764:      	mov	w3, #0x3                // =3
    1768:      	ccmp	w3, w1, #0x1, ne
    176c:      	b.ge	0x1a74 <main+0x470>
    1770:      	stur	w0, [x19, #-0x90]
    1774:      	sub	x1, x19, #0x80
    1778:      	mov	w0, #0x1                // =1
    177c:      	bl	0x12d0 <clock_gettime@plt>
    1780:      	cbnz	w0, 0x1b5c <main+0x558>
    1784:      	cbz	x25, 0x1ac4 <main+0x4c0>
    1788:      	mov	x21, #0x0               // =0
    178c:      	mov	x22, #0x0               // =0
    1790:      	sub	x0, x19, #0x90
    1794:      	str	x0, [sp, #0x8]
    1798:      	lsr	x27, x0, #3
    179c:      	sub	x20, x19, #0x40
    17a0:      	and	x26, x19, #0x7
    17a4:      	add	w26, w26, #0x3
    17a8:      	mov	x0, #0x1000000000       // =68719476736
    17ac:      	ldrsb	w0, [x27, x0]
    17b0:      	cmp	w0, #0x0
    17b4:      	mov	w1, #0x3                // =3
    17b8:      	ccmp	w1, w0, #0x1, ne
    17bc:      	b.ge	0x1a7c <main+0x478>
    17c0:      	ldur	w0, [x19, #-0x90]
    17c4:      	eor	w0, w0, w0, lsl #13
    17c8:      	eor	w0, w0, w0, lsr #17
    17cc:      	eor	w0, w0, w0, lsl #5
    17d0:      	stur	w0, [x19, #-0x90]
    17d4:      	lsr	x1, x20, #3
    17d8:      	mov	x2, #0x1000000000       // =68719476736
    17dc:      	ldrsb	w1, [x1, x2]
    17e0:      	cmp	w1, #0x0
    17e4:      	ccmp	w26, w1, #0x1, ne
    17e8:      	b.ge	0x1a84 <main+0x480>
    17ec:      	stur	w0, [x19, #-0x40]
    17f0:      	eor	w1, w0, w0, lsl #13
    17f4:      	eor	w1, w1, w1, lsr #17
    17f8:      	eor	w1, w1, w1, lsl #5
    17fc:      	stur	w1, [x19, #-0x90]
    1800:      	sub	x2, x19, #0x38
    1804:      	sub	x2, x2, x20
    1808:      	cmp	x2, #0x8
    180c:      	b.hi	0x1a8c <main+0x488>
    1810:      	sub	x3, x19, #0x3c
    1814:      	lsr	x4, x3, #3
    1818:      	mov	x2, #0x1000000000       // =68719476736
    181c:      	ldrsb	w4, [x4, x2]
    1820:      	and	x2, x3, #0x7
    1824:      	add	w2, w2, #0x3
    1828:      	cmp	w4, #0x0
    182c:      	ccmp	w2, w4, #0x1, ne
    1830:      	b.ge	0x1aac <main+0x4a8>
    1834:      	stur	w1, [x19, #-0x3c]
    1838:      	lsr	x2, x20, #3
    183c:      	mov	x3, #0x1000000000       // =68719476736
    1840:      	ldrsb	w2, [x2, x3]
    1844:      	cmp	w2, #0x0
    1848:      	mov	w3, #0x3                // =3
    184c:      	ccmp	w3, w2, #0x1, ne
    1850:      	b.ge	0x1ab4 <main+0x4b0>
    1854:      	sub	x3, x19, #0x3c
    1858:      	lsr	x4, x3, #3
    185c:      	mov	x2, #0x1000000000       // =68719476736
    1860:      	ldrsb	w4, [x4, x2]
    1864:      	and	x2, x3, #0x7
    1868:      	add	w2, w2, #0x3
    186c:      	cmp	w4, #0x0
    1870:      	ccmp	w2, w4, #0x1, ne
    1874:      	b.ge	0x1abc <main+0x4b8>
    1878:      	bl	0x1498 <kernel>
    187c:      	add	x22, x22, w0, uxtw
    1880:      	add	x21, x21, #0x1
    1884:      	cmp	x25, x21
    1888:      	b.ne	0x17a8 <main+0x1a4>
    188c:      	sub	x1, x19, #0x60
    1890:      	mov	w0, #0x1                // =1
    1894:      	bl	0x12d0 <clock_gettime@plt>
    1898:      	mov	w20, w0
    189c:      	cbnz	w0, 0x1b68 <main+0x564>
    18a0:      	sub	x0, x19, #0x60
    18a4:      	lsr	x2, x0, #3
    18a8:      	mov	x1, #0x1000000000       // =68719476736
    18ac:      	ldrsb	w1, [x2, x1]
    18b0:      	cbnz	w1, 0x1acc <main+0x4c8>
    18b4:      	ldur	x1, [x19, #-0x60]
    18b8:      	sub	x0, x19, #0x80
    18bc:      	lsr	x3, x0, #3
    18c0:      	mov	x2, #0x1000000000       // =68719476736
    18c4:      	ldrsb	w2, [x3, x2]
    18c8:      	cbnz	w2, 0x1ad0 <main+0x4cc>
    18cc:      	ldur	x0, [x19, #-0x80]
    18d0:      	subs	x0, x1, x0
    18d4:      	b.vs	0x1ad4 <main+0x4d0>
    18d8:      	scvtf	d1, x0
    18dc:      	sub	x0, x19, #0x58
    18e0:      	lsr	x2, x0, #3
    18e4:      	mov	x1, #0x1000000000       // =68719476736
    18e8:      	ldrsb	w1, [x2, x1]
    18ec:      	cbnz	w1, 0x1ae8 <main+0x4e4>
    18f0:      	ldur	x1, [x19, #-0x58]
    18f4:      	sub	x0, x19, #0x78
    18f8:      	lsr	x3, x0, #3
    18fc:      	mov	x2, #0x1000000000       // =68719476736
    1900:      	ldrsb	w2, [x3, x2]
    1904:      	cbnz	w2, 0x1aec <main+0x4e8>
    1908:      	ldur	x0, [x19, #-0x78]
    190c:      	subs	x0, x1, x0
    1910:      	b.vs	0x1af0 <main+0x4ec>
    1914:      	scvtf	d0, x0
    1918:      	adrp	x0, 0x1000 <strtoul@GLIBC_2.17+0x1000>
    191c:      	ldr	d2, [x0, #0xd50]
    1920:      	fmul	d0, d0, d2
    1924:      	mov	x2, x22
    1928:      	fadd	d0, d0, d1
    192c:      	adrp	x1, 0x1000 <strtoul@GLIBC_2.17+0x1000>
    1930:      	add	x1, x1, #0xd60
    1934:      	add	x1, x1, #0x80
    1938:      	mov	w0, #0x2                // =2
    193c:      	bl	0x1330 <__printf_chk@plt>
    1940:      	ldp	x25, x26, [sp, #0x110]
    1944:      	b	0x1b08 <main+0x504>
    1948:      	mov	x0, #0xa0               // =160
    194c:      	bl	0x1300 <__asan_stack_malloc_2@plt>
    1950:      	cmp	x0, #0x0
    1954:      	csel	x23, x23, x0, eq
    1958:      	b	0x1640 <main+0x3c>
    195c:      	stp	x25, x26, [sp, #0x110]
    1960:      	sub	x20, x19, #0x3c
    1964:      	adrp	x21, 0x1000 <strtoul@GLIBC_2.17+0x1000>
    1968:      	add	x21, x21, #0xd60
    196c:      	add	x25, x21, #0x40
    1970:      	and	x22, x20, #0x7
    1974:      	add	w22, w22, #0x3
    1978:      	b	0x1998 <main+0x394>
    197c:      	bl	0x1260 <__asan_report_load4@plt>
    1980:      	ldur	w1, [x19, #-0x3c]
    1984:      	bl	0x1498 <kernel>
    1988:      	mov	w2, w0
    198c:      	mov	x1, x21
    1990:      	mov	w0, #0x2                // =2
    1994:      	bl	0x1330 <__printf_chk@plt>
    1998:      	mov	x2, x20
    199c:      	sub	x1, x19, #0x40
    19a0:      	mov	x0, x25
    19a4:      	bl	0x1320 <__isoc99_scanf@plt>
    19a8:      	cmp	w0, #0x2
    19ac:      	b.ne	0x19f4 <main+0x3f0>
    19b0:      	sub	x0, x19, #0x40
    19b4:      	lsr	x2, x0, #3
    19b8:      	mov	x1, #0x1000000000       // =68719476736
    19bc:      	ldrsb	w1, [x2, x1]
    19c0:      	cmp	w1, #0x0
    19c4:      	mov	w2, #0x3                // =3
    19c8:      	ccmp	w2, w1, #0x1, ne
    19cc:      	b.ge	0x197c <main+0x378>
    19d0:      	ldur	w0, [x19, #-0x40]
    19d4:      	lsr	x1, x20, #3
    19d8:      	mov	x2, #0x1000000000       // =68719476736
    19dc:      	ldrsb	w1, [x1, x2]
    19e0:      	cmp	w1, #0x0
    19e4:      	ccmp	w22, w1, #0x1, ne
    19e8:      	b.lt	0x1980 <main+0x37c>
    19ec:      	mov	x0, x20
    19f0:      	bl	0x1260 <__asan_report_load4@plt>
    19f4:      	mov	w20, #0x0               // =0
    19f8:      	ldp	x25, x26, [sp, #0x110]
    19fc:      	b	0x1b08 <main+0x504>
    1a00:      	mov	x1, x20
    1a04:      	adrp	x0, 0x20000 <data_start>
    1a08:      	add	x0, x0, #0xe0
    1a0c:      	bl	0x1350 <__ubsan_handle_pointer_overflow_abort@plt>
    1a10:      	adrp	x0, 0x20000 <data_start>
    1a14:      	add	x0, x0, #0xe0
    1a18:      	add	x0, x0, #0x40
    1a1c:      	bl	0x1210 <__ubsan_handle_type_mismatch_v1_abort@plt>
    1a20:      	bl	0x12e0 <__asan_report_load8@plt>
    1a24:      	bl	0x12a0 <__asan_handle_no_return@plt>
    1a28:      	adrp	x0, 0x20000 <data_start>
    1a2c:      	add	x0, x0, #0xe0
    1a30:      	add	x0, x0, #0x80
    1a34:      	bl	0x1240 <__ubsan_handle_nonnull_arg_abort@plt>
    1a38:      	mov	x1, x20
    1a3c:      	adrp	x0, 0x20000 <data_start>
    1a40:      	add	x0, x0, #0xe0
    1a44:      	add	x0, x0, #0xe0
    1a48:      	bl	0x1350 <__ubsan_handle_pointer_overflow_abort@plt>
    1a4c:      	adrp	x0, 0x20000 <data_start>
    1a50:      	add	x0, x0, #0xe0
    1a54:      	add	x0, x0, #0x120
    1a58:      	bl	0x1210 <__ubsan_handle_type_mismatch_v1_abort@plt>
    1a5c:      	bl	0x12e0 <__asan_report_load8@plt>
    1a60:      	bl	0x12a0 <__asan_handle_no_return@plt>
    1a64:      	adrp	x0, 0x20000 <data_start>
    1a68:      	add	x0, x0, #0xe0
    1a6c:      	add	x0, x0, #0x160
    1a70:      	bl	0x1240 <__ubsan_handle_nonnull_arg_abort@plt>
    1a74:      	mov	x0, x2
    1a78:      	bl	0x1200 <__asan_report_store4@plt>
    1a7c:      	ldr	x0, [sp, #0x8]
    1a80:      	bl	0x1260 <__asan_report_load4@plt>
    1a84:      	mov	x0, x20
    1a88:      	bl	0x1200 <__asan_report_store4@plt>
    1a8c:      	sub	x3, x19, #0x3c
    1a90:      	cmn	x3, x2
    1a94:      	b.hs	0x1810 <main+0x20c>
    1a98:      	mov	x1, x3
    1a9c:      	adrp	x0, 0x20000 <data_start>
    1aa0:      	add	x0, x0, #0xe0
    1aa4:      	add	x0, x0, #0x1c0
    1aa8:      	bl	0x1210 <__ubsan_handle_type_mismatch_v1_abort@plt>
    1aac:      	mov	x0, x3
    1ab0:      	bl	0x1200 <__asan_report_store4@plt>
    1ab4:      	mov	x0, x20
    1ab8:      	bl	0x1260 <__asan_report_load4@plt>
    1abc:      	mov	x0, x3
    1ac0:      	bl	0x1260 <__asan_report_load4@plt>
    1ac4:      	mov	x22, x25
    1ac8:      	b	0x188c <main+0x288>
    1acc:      	bl	0x12e0 <__asan_report_load8@plt>
    1ad0:      	bl	0x12e0 <__asan_report_load8@plt>
    1ad4:      	ldur	x2, [x19, #-0x80]
    1ad8:      	adrp	x0, 0x20000 <data_start>
    1adc:      	add	x0, x0, #0xe0
    1ae0:      	add	x0, x0, #0x200
    1ae4:      	bl	0x1250 <__ubsan_handle_sub_overflow_abort@plt>
    1ae8:      	bl	0x12e0 <__asan_report_load8@plt>
    1aec:      	bl	0x12e0 <__asan_report_load8@plt>
    1af0:      	ldur	x2, [x19, #-0x78]
    1af4:      	adrp	x0, 0x20000 <data_start>
    1af8:      	add	x0, x0, #0xe0
    1afc:      	add	x0, x0, #0x240
    1b00:      	bl	0x1250 <__ubsan_handle_sub_overflow_abort@plt>
    1b04:      	mov	w20, #0x3               // =3
    1b08:      	cmp	x28, x23
    1b0c:      	b.ne	0x1b74 <main+0x570>
    1b10:      	mov	x0, #0x1000000000       // =68719476736
    1b14:      	add	x24, x24, x0
    1b18:      	stp	xzr, xzr, [x24]
    1b1c:      	str	wzr, [x24, #0x10]
    1b20:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1cf5c>
    1b24:      	ldr	x0, [x0, #0xfc8]
    1b28:      	ldr	x2, [sp, #0xc8]
    1b2c:      	ldr	x1, [x0]
    1b30:      	subs	x2, x2, x1
    1b34:      	mov	x1, #0x0                // =0
    1b38:      	b.ne	0x1b98 <main+0x594>
    1b3c:      	mov	w0, w20
    1b40:      	ldp	x19, x20, [sp, #0xe0]
    1b44:      	ldp	x21, x22, [sp, #0xf0]
    1b48:      	ldp	x23, x24, [sp, #0x100]
    1b4c:      	ldp	x27, x28, [sp, #0x120]
    1b50:      	ldp	x29, x30, [sp, #0xd0]
    1b54:      	add	sp, sp, #0x130
    1b58:      	ret
    1b5c:      	mov	w20, #0x2               // =2
    1b60:      	ldp	x25, x26, [sp, #0x110]
    1b64:      	b	0x1b08 <main+0x504>
    1b68:      	mov	w20, #0x2               // =2
    1b6c:      	ldp	x25, x26, [sp, #0x110]
    1b70:      	b	0x1b08 <main+0x504>
    1b74:      	mov	x0, #0x360e             // =13838
    1b78:      	movk	x0, #0x45e0, lsl #16
    1b7c:      	str	x0, [x23]
    1b80:      	mov	x0, #0x1000000000       // =68719476736
    1b84:      	add	x1, x24, x0
    1b88:      	movi	v0.16b, #0xf5
    1b8c:      	str	q0, [x24, x0]
    1b90:      	str	s0, [x1, #0x10]
    1b94:      	b	0x1b20 <main+0x51c>
    1b98:      	stp	x25, x26, [sp, #0x110]
    1b9c:      	bl	0x1230 <__stack_chk_fail@plt>

0000000000001ba0 <_sub_D_00099_0>:
    1ba0:      	stp	x29, x30, [sp, #-0x10]!
    1ba4:      	mov	x29, sp
    1ba8:      	mov	x1, #0x10               // =16
    1bac:      	adrp	x0, 0x20000 <data_start>
    1bb0:      	add	x0, x0, #0xe0
    1bb4:      	add	x0, x0, #0x280
    1bb8:      	bl	0x1290 <__asan_unregister_globals@plt>
    1bbc:      	ldp	x29, x30, [sp], #0x10
    1bc0:      	ret

0000000000001bc4 <_sub_I_00099_1>:
    1bc4:      	stp	x29, x30, [sp, #-0x10]!
    1bc8:      	mov	x29, sp
    1bcc:      	bl	0x12b0 <__asan_init@plt>
    1bd0:      	bl	0x1310 <__asan_version_mismatch_check_v8@plt>
    1bd4:      	mov	x1, #0x10               // =16
    1bd8:      	adrp	x0, 0x20000 <data_start>
    1bdc:      	add	x0, x0, #0xe0
    1be0:      	add	x0, x0, #0x280
    1be4:      	bl	0x1220 <__asan_register_globals@plt>
    1be8:      	ldp	x29, x30, [sp], #0x10
    1bec:      	ret

Disassembly of section .fini:

0000000000001bf0 <_fini>:
    1bf0:      	nop
    1bf4:      	stp	x29, x30, [sp, #-0x10]!
    1bf8:      	mov	x29, sp
    1bfc:      	ldp	x29, x30, [sp], #0x10
    1c00:      	ret
