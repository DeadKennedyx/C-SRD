; ModuleID = '/work/experiments/runs/positional-widths-comparison-20261110/matrix/crc32_byte/build-clang-O2-identity/validation/compiler-0-O2/candidate.i'
source_filename = "/work/experiments/runs/positional-widths-comparison-20261110/matrix/crc32_byte/build-clang-O2-identity/validation/compiler-0-O2/candidate.i"
target datalayout = "e-m:e-i8:8:32-i16:16:32-i64:64-i128:128-n32:64-S128"
target triple = "aarch64-unknown-linux-gnu"

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local i32 @kernel(i32 noundef %0, i32 noundef %1) local_unnamed_addr #0 {
  %3 = and i32 %1, 255
  %4 = xor i32 %3, %0
  %5 = xor i32 %4, -1
  %6 = and i32 %5, 1
  %7 = lshr i32 %5, 1
  %8 = icmp eq i32 %6, 0
  %9 = select i1 %8, i32 0, i32 -306674912
  %10 = xor i32 %9, %7
  %11 = lshr i32 %10, 1
  %12 = and i32 %5, 2
  %13 = icmp eq i32 %12, 0
  %14 = select i1 %13, i32 0, i32 -306674912
  %15 = xor i32 %11, %14
  %16 = lshr i32 %15, 6
  %17 = insertelement <4 x i32> poison, i32 %5, i64 0
  %18 = shufflevector <4 x i32> %17, <4 x i32> poison, <4 x i32> zeroinitializer
  %19 = and <4 x i32> %18, <i32 4, i32 8, i32 16, i32 32>
  %20 = icmp eq <4 x i32> %19, zeroinitializer
  %21 = select <4 x i1> %20, <4 x i32> zeroinitializer, <4 x i32> <i32 124634137, i32 249268274, i32 498536548, i32 997073096>
  %22 = and i32 %10, 32
  %23 = icmp eq i32 %22, 0
  %24 = select i1 %23, i32 0, i32 1994146192
  %25 = and i32 %15, 32
  %26 = icmp eq i32 %25, 0
  %27 = select i1 %26, i32 -1, i32 306674911
  %28 = tail call i32 @llvm.vector.reduce.xor.v4i32(<4 x i32> %21)
  %29 = xor i32 %28, %24
  %30 = xor i32 %27, %16
  %31 = xor i32 %29, %30
  ret i32 %31
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.vector.reduce.xor.v4i32(<4 x i32>) #1

attributes #0 = { mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable "frame-pointer"="non-leaf" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+fp-armv8,+neon,+outline-atomics,+v8a,-fmv" }
attributes #1 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 1, !"wchar_size", i32 4}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 1}
!5 = !{!"Ubuntu clang version 18.1.3 (1ubuntu1)"}
