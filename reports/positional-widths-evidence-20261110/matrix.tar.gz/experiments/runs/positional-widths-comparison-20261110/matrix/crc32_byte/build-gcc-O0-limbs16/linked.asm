
/work/experiments/runs/positional-widths-comparison-20261110/matrix/crc32_byte/build-gcc-O0-limbs16/program:	file format elf64-littleaarch64

Disassembly of section .init:

0000000000000730 <_init>:
     730:      	nop
     734:      	stp	x29, x30, [sp, #-0x10]!
     738:      	mov	x29, sp
     73c:      	bl	0x834 <call_weak_fn>
     740:      	ldp	x29, x30, [sp], #0x10
     744:      	ret

Disassembly of section .plt:

0000000000000750 <.plt>:
     750:      	stp	x16, x30, [sp, #-0x10]!
     754:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1dc80>
     758:      	ldr	x17, [x16, #0xf78]
     75c:      	add	x16, x16, #0xf78
     760:      	br	x17
     764:      	nop
     768:      	nop
     76c:      	nop

0000000000000770 <strtoul@plt>:
     770:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1dc80>
     774:      	ldr	x17, [x16, #0xf80]
     778:      	add	x16, x16, #0xf80
     77c:      	br	x17

0000000000000780 <__libc_start_main@plt>:
     780:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1dc80>
     784:      	ldr	x17, [x16, #0xf88]
     788:      	add	x16, x16, #0xf88
     78c:      	br	x17

0000000000000790 <__cxa_finalize@plt>:
     790:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1dc80>
     794:      	ldr	x17, [x16, #0xf90]
     798:      	add	x16, x16, #0xf90
     79c:      	br	x17

00000000000007a0 <clock_gettime@plt>:
     7a0:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1dc80>
     7a4:      	ldr	x17, [x16, #0xf98]
     7a8:      	add	x16, x16, #0xf98
     7ac:      	br	x17

00000000000007b0 <__stack_chk_fail@plt>:
     7b0:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1dc80>
     7b4:      	ldr	x17, [x16, #0xfa0]
     7b8:      	add	x16, x16, #0xfa0
     7bc:      	br	x17

00000000000007c0 <__gmon_start__@plt>:
     7c0:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1dc80>
     7c4:      	ldr	x17, [x16, #0xfa8]
     7c8:      	add	x16, x16, #0xfa8
     7cc:      	br	x17

00000000000007d0 <abort@plt>:
     7d0:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1dc80>
     7d4:      	ldr	x17, [x16, #0xfb0]
     7d8:      	add	x16, x16, #0xfb0
     7dc:      	br	x17

00000000000007e0 <__isoc99_scanf@plt>:
     7e0:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1dc80>
     7e4:      	ldr	x17, [x16, #0xfb8]
     7e8:      	add	x16, x16, #0xfb8
     7ec:      	br	x17

00000000000007f0 <printf@plt>:
     7f0:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1dc80>
     7f4:      	ldr	x17, [x16, #0xfc0]
     7f8:      	add	x16, x16, #0xfc0
     7fc:      	br	x17

Disassembly of section .text:

0000000000000800 <_start>:
     800:      	nop
     804:      	mov	x29, #0x0               // =0
     808:      	mov	x30, #0x0               // =0
     80c:      	mov	x5, x0
     810:      	ldr	x1, [sp]
     814:      	add	x2, sp, #0x8
     818:      	mov	x6, sp
     81c:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1dc80>
     820:      	ldr	x0, [x0, #0xff0]
     824:      	mov	x3, #0x0                // =0
     828:      	mov	x4, #0x0                // =0
     82c:      	bl	0x780 <__libc_start_main@plt>
     830:      	bl	0x7d0 <abort@plt>

0000000000000834 <call_weak_fn>:
     834:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1dc80>
     838:      	ldr	x0, [x0, #0xfe0]
     83c:      	cbz	x0, 0x844 <call_weak_fn+0x10>
     840:      	b	0x7c0 <__gmon_start__@plt>
     844:      	ret
     848:      	nop
     84c:      	nop

0000000000000850 <deregister_tm_clones>:
     850:      	adrp	x0, 0x20000 <data_start>
     854:      	add	x0, x0, #0x10
     858:      	adrp	x1, 0x20000 <data_start>
     85c:      	add	x1, x1, #0x10
     860:      	cmp	x1, x0
     864:      	b.eq	0x87c <deregister_tm_clones+0x2c>
     868:      	adrp	x1, 0x1f000 <__FRAME_END__+0x1dc80>
     86c:      	ldr	x1, [x1, #0xfd0]
     870:      	cbz	x1, 0x87c <deregister_tm_clones+0x2c>
     874:      	mov	x16, x1
     878:      	br	x16
     87c:      	ret

0000000000000880 <register_tm_clones>:
     880:      	adrp	x0, 0x20000 <data_start>
     884:      	add	x0, x0, #0x10
     888:      	adrp	x1, 0x20000 <data_start>
     88c:      	add	x1, x1, #0x10
     890:      	sub	x1, x1, x0
     894:      	lsr	x2, x1, #63
     898:      	add	x1, x2, x1, asr #3
     89c:      	asr	x1, x1, #1
     8a0:      	cbz	x1, 0x8b8 <register_tm_clones+0x38>
     8a4:      	adrp	x2, 0x1f000 <__FRAME_END__+0x1dc80>
     8a8:      	ldr	x2, [x2, #0xff8]
     8ac:      	cbz	x2, 0x8b8 <register_tm_clones+0x38>
     8b0:      	mov	x16, x2
     8b4:      	br	x16
     8b8:      	ret
     8bc:      	nop

00000000000008c0 <__do_global_dtors_aux>:
     8c0:      	paciasp
     8c4:      	stp	x29, x30, [sp, #-0x20]!
     8c8:      	mov	x29, sp
     8cc:      	str	x19, [sp, #0x10]
     8d0:      	adrp	x19, 0x20000 <data_start>
     8d4:      	ldrb	w0, [x19, #0x10]
     8d8:      	tbnz	w0, #0x0, 0x900 <__do_global_dtors_aux+0x40>
     8dc:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1dc80>
     8e0:      	ldr	x0, [x0, #0xfd8]
     8e4:      	cbz	x0, 0x8f4 <__do_global_dtors_aux+0x34>
     8e8:      	adrp	x0, 0x20000 <data_start>
     8ec:      	ldr	x0, [x0, #0x8]
     8f0:      	bl	0x790 <__cxa_finalize@plt>
     8f4:      	bl	0x850 <deregister_tm_clones>
     8f8:      	mov	w0, #0x1                // =1
     8fc:      	strb	w0, [x19, #0x10]
     900:      	ldr	x19, [sp, #0x10]
     904:      	ldp	x29, x30, [sp], #0x20
     908:      	autiasp
     90c:      	ret

0000000000000910 <frame_dummy>:
     910:      	bti	c
     914:      	b	0x880 <register_tm_clones>

0000000000000918 <kernel>:
     918:      	sub	sp, sp, #0x1b0
     91c:      	str	w0, [sp, #0xc]
     920:      	str	w1, [sp, #0x8]
     924:      	ldr	w0, [sp, #0xc]
     928:      	and	w0, w0, #0xffff
     92c:      	str	w0, [sp, #0x1c]
     930:      	ldr	w0, [sp, #0xc]
     934:      	lsr	w0, w0, #16
     938:      	str	w0, [sp, #0x20]
     93c:      	ldr	w0, [sp, #0x8]
     940:      	and	w0, w0, #0xffff
     944:      	str	w0, [sp, #0x24]
     948:      	ldr	w0, [sp, #0x8]
     94c:      	lsr	w0, w0, #16
     950:      	str	w0, [sp, #0x28]
     954:      	ldr	w0, [sp, #0x1c]
     958:      	eor	w0, w0, #0xffff
     95c:      	str	w0, [sp, #0x2c]
     960:      	ldr	w0, [sp, #0x20]
     964:      	eor	w0, w0, #0xffff
     968:      	str	w0, [sp, #0x30]
     96c:      	ldr	w0, [sp, #0x24]
     970:      	and	w0, w0, #0xff
     974:      	str	w0, [sp, #0x34]
     978:      	str	wzr, [sp, #0x38]
     97c:      	ldr	w1, [sp, #0x2c]
     980:      	ldr	w0, [sp, #0x34]
     984:      	eor	w0, w1, w0
     988:      	str	w0, [sp, #0x3c]
     98c:      	ldr	w1, [sp, #0x30]
     990:      	ldr	w0, [sp, #0x38]
     994:      	eor	w0, w1, w0
     998:      	str	w0, [sp, #0x40]
     99c:      	ldr	w0, [sp, #0x3c]
     9a0:      	and	w0, w0, #0x1
     9a4:      	str	w0, [sp, #0x44]
     9a8:      	str	wzr, [sp, #0x48]
     9ac:      	ldr	w0, [sp, #0x44]
     9b0:      	cmp	w0, #0x0
     9b4:      	cset	w0, ne
     9b8:      	and	w0, w0, #0xff
     9bc:      	str	w0, [sp, #0x4c]
     9c0:      	ldr	w0, [sp, #0x44]
     9c4:      	neg	w0, w0
     9c8:      	and	w0, w0, #0xffff
     9cc:      	str	w0, [sp, #0x50]
     9d0:      	ldr	w0, [sp, #0x48]
     9d4:      	neg	w1, w0
     9d8:      	ldr	w0, [sp, #0x4c]
     9dc:      	sub	w0, w1, w0
     9e0:      	and	w0, w0, #0xffff
     9e4:      	str	w0, [sp, #0x54]
     9e8:      	ldr	w0, [sp, #0x3c]
     9ec:      	lsr	w1, w0, #1
     9f0:      	ldr	w0, [sp, #0x40]
     9f4:      	lsl	w0, w0, #15
     9f8:      	orr	w0, w1, w0
     9fc:      	and	w0, w0, #0xffff
     a00:      	str	w0, [sp, #0x58]
     a04:      	ldr	w0, [sp, #0x40]
     a08:      	lsr	w0, w0, #1
     a0c:      	str	w0, [sp, #0x5c]
     a10:      	ldr	w1, [sp, #0x50]
     a14:      	mov	w0, #0x8320             // =33568
     a18:      	and	w0, w1, w0
     a1c:      	str	w0, [sp, #0x60]
     a20:      	ldr	w1, [sp, #0x54]
     a24:      	mov	w0, #0xedb8             // =60856
     a28:      	and	w0, w1, w0
     a2c:      	str	w0, [sp, #0x64]
     a30:      	ldr	w1, [sp, #0x58]
     a34:      	ldr	w0, [sp, #0x60]
     a38:      	eor	w0, w1, w0
     a3c:      	str	w0, [sp, #0x68]
     a40:      	ldr	w1, [sp, #0x5c]
     a44:      	ldr	w0, [sp, #0x64]
     a48:      	eor	w0, w1, w0
     a4c:      	str	w0, [sp, #0x6c]
     a50:      	ldr	w0, [sp, #0x68]
     a54:      	and	w0, w0, #0x1
     a58:      	str	w0, [sp, #0x70]
     a5c:      	str	wzr, [sp, #0x74]
     a60:      	ldr	w0, [sp, #0x70]
     a64:      	cmp	w0, #0x0
     a68:      	cset	w0, ne
     a6c:      	and	w0, w0, #0xff
     a70:      	str	w0, [sp, #0x78]
     a74:      	ldr	w0, [sp, #0x70]
     a78:      	neg	w0, w0
     a7c:      	and	w0, w0, #0xffff
     a80:      	str	w0, [sp, #0x7c]
     a84:      	ldr	w0, [sp, #0x74]
     a88:      	neg	w1, w0
     a8c:      	ldr	w0, [sp, #0x78]
     a90:      	sub	w0, w1, w0
     a94:      	and	w0, w0, #0xffff
     a98:      	str	w0, [sp, #0x80]
     a9c:      	ldr	w0, [sp, #0x68]
     aa0:      	lsr	w1, w0, #1
     aa4:      	ldr	w0, [sp, #0x6c]
     aa8:      	lsl	w0, w0, #15
     aac:      	orr	w0, w1, w0
     ab0:      	and	w0, w0, #0xffff
     ab4:      	str	w0, [sp, #0x84]
     ab8:      	ldr	w0, [sp, #0x6c]
     abc:      	lsr	w0, w0, #1
     ac0:      	str	w0, [sp, #0x88]
     ac4:      	ldr	w1, [sp, #0x7c]
     ac8:      	mov	w0, #0x8320             // =33568
     acc:      	and	w0, w1, w0
     ad0:      	str	w0, [sp, #0x8c]
     ad4:      	ldr	w1, [sp, #0x80]
     ad8:      	mov	w0, #0xedb8             // =60856
     adc:      	and	w0, w1, w0
     ae0:      	str	w0, [sp, #0x90]
     ae4:      	ldr	w1, [sp, #0x84]
     ae8:      	ldr	w0, [sp, #0x8c]
     aec:      	eor	w0, w1, w0
     af0:      	str	w0, [sp, #0x94]
     af4:      	ldr	w1, [sp, #0x88]
     af8:      	ldr	w0, [sp, #0x90]
     afc:      	eor	w0, w1, w0
     b00:      	str	w0, [sp, #0x98]
     b04:      	ldr	w0, [sp, #0x94]
     b08:      	and	w0, w0, #0x1
     b0c:      	str	w0, [sp, #0x9c]
     b10:      	str	wzr, [sp, #0xa0]
     b14:      	ldr	w0, [sp, #0x9c]
     b18:      	cmp	w0, #0x0
     b1c:      	cset	w0, ne
     b20:      	and	w0, w0, #0xff
     b24:      	str	w0, [sp, #0xa4]
     b28:      	ldr	w0, [sp, #0x9c]
     b2c:      	neg	w0, w0
     b30:      	and	w0, w0, #0xffff
     b34:      	str	w0, [sp, #0xa8]
     b38:      	ldr	w0, [sp, #0xa0]
     b3c:      	neg	w1, w0
     b40:      	ldr	w0, [sp, #0xa4]
     b44:      	sub	w0, w1, w0
     b48:      	and	w0, w0, #0xffff
     b4c:      	str	w0, [sp, #0xac]
     b50:      	ldr	w0, [sp, #0x94]
     b54:      	lsr	w1, w0, #1
     b58:      	ldr	w0, [sp, #0x98]
     b5c:      	lsl	w0, w0, #15
     b60:      	orr	w0, w1, w0
     b64:      	and	w0, w0, #0xffff
     b68:      	str	w0, [sp, #0xb0]
     b6c:      	ldr	w0, [sp, #0x98]
     b70:      	lsr	w0, w0, #1
     b74:      	str	w0, [sp, #0xb4]
     b78:      	ldr	w1, [sp, #0xa8]
     b7c:      	mov	w0, #0x8320             // =33568
     b80:      	and	w0, w1, w0
     b84:      	str	w0, [sp, #0xb8]
     b88:      	ldr	w1, [sp, #0xac]
     b8c:      	mov	w0, #0xedb8             // =60856
     b90:      	and	w0, w1, w0
     b94:      	str	w0, [sp, #0xbc]
     b98:      	ldr	w1, [sp, #0xb0]
     b9c:      	ldr	w0, [sp, #0xb8]
     ba0:      	eor	w0, w1, w0
     ba4:      	str	w0, [sp, #0xc0]
     ba8:      	ldr	w1, [sp, #0xb4]
     bac:      	ldr	w0, [sp, #0xbc]
     bb0:      	eor	w0, w1, w0
     bb4:      	str	w0, [sp, #0xc4]
     bb8:      	ldr	w0, [sp, #0xc0]
     bbc:      	and	w0, w0, #0x1
     bc0:      	str	w0, [sp, #0xc8]
     bc4:      	str	wzr, [sp, #0xcc]
     bc8:      	ldr	w0, [sp, #0xc8]
     bcc:      	cmp	w0, #0x0
     bd0:      	cset	w0, ne
     bd4:      	and	w0, w0, #0xff
     bd8:      	str	w0, [sp, #0xd0]
     bdc:      	ldr	w0, [sp, #0xc8]
     be0:      	neg	w0, w0
     be4:      	and	w0, w0, #0xffff
     be8:      	str	w0, [sp, #0xd4]
     bec:      	ldr	w0, [sp, #0xcc]
     bf0:      	neg	w1, w0
     bf4:      	ldr	w0, [sp, #0xd0]
     bf8:      	sub	w0, w1, w0
     bfc:      	and	w0, w0, #0xffff
     c00:      	str	w0, [sp, #0xd8]
     c04:      	ldr	w0, [sp, #0xc0]
     c08:      	lsr	w1, w0, #1
     c0c:      	ldr	w0, [sp, #0xc4]
     c10:      	lsl	w0, w0, #15
     c14:      	orr	w0, w1, w0
     c18:      	and	w0, w0, #0xffff
     c1c:      	str	w0, [sp, #0xdc]
     c20:      	ldr	w0, [sp, #0xc4]
     c24:      	lsr	w0, w0, #1
     c28:      	str	w0, [sp, #0xe0]
     c2c:      	ldr	w1, [sp, #0xd4]
     c30:      	mov	w0, #0x8320             // =33568
     c34:      	and	w0, w1, w0
     c38:      	str	w0, [sp, #0xe4]
     c3c:      	ldr	w1, [sp, #0xd8]
     c40:      	mov	w0, #0xedb8             // =60856
     c44:      	and	w0, w1, w0
     c48:      	str	w0, [sp, #0xe8]
     c4c:      	ldr	w1, [sp, #0xdc]
     c50:      	ldr	w0, [sp, #0xe4]
     c54:      	eor	w0, w1, w0
     c58:      	str	w0, [sp, #0xec]
     c5c:      	ldr	w1, [sp, #0xe0]
     c60:      	ldr	w0, [sp, #0xe8]
     c64:      	eor	w0, w1, w0
     c68:      	str	w0, [sp, #0xf0]
     c6c:      	ldr	w0, [sp, #0xec]
     c70:      	and	w0, w0, #0x1
     c74:      	str	w0, [sp, #0xf4]
     c78:      	str	wzr, [sp, #0xf8]
     c7c:      	ldr	w0, [sp, #0xf4]
     c80:      	cmp	w0, #0x0
     c84:      	cset	w0, ne
     c88:      	and	w0, w0, #0xff
     c8c:      	str	w0, [sp, #0xfc]
     c90:      	ldr	w0, [sp, #0xf4]
     c94:      	neg	w0, w0
     c98:      	and	w0, w0, #0xffff
     c9c:      	str	w0, [sp, #0x100]
     ca0:      	ldr	w0, [sp, #0xf8]
     ca4:      	neg	w1, w0
     ca8:      	ldr	w0, [sp, #0xfc]
     cac:      	sub	w0, w1, w0
     cb0:      	and	w0, w0, #0xffff
     cb4:      	str	w0, [sp, #0x104]
     cb8:      	ldr	w0, [sp, #0xec]
     cbc:      	lsr	w1, w0, #1
     cc0:      	ldr	w0, [sp, #0xf0]
     cc4:      	lsl	w0, w0, #15
     cc8:      	orr	w0, w1, w0
     ccc:      	and	w0, w0, #0xffff
     cd0:      	str	w0, [sp, #0x108]
     cd4:      	ldr	w0, [sp, #0xf0]
     cd8:      	lsr	w0, w0, #1
     cdc:      	str	w0, [sp, #0x10c]
     ce0:      	ldr	w1, [sp, #0x100]
     ce4:      	mov	w0, #0x8320             // =33568
     ce8:      	and	w0, w1, w0
     cec:      	str	w0, [sp, #0x110]
     cf0:      	ldr	w1, [sp, #0x104]
     cf4:      	mov	w0, #0xedb8             // =60856
     cf8:      	and	w0, w1, w0
     cfc:      	str	w0, [sp, #0x114]
     d00:      	ldr	w1, [sp, #0x108]
     d04:      	ldr	w0, [sp, #0x110]
     d08:      	eor	w0, w1, w0
     d0c:      	str	w0, [sp, #0x118]
     d10:      	ldr	w1, [sp, #0x10c]
     d14:      	ldr	w0, [sp, #0x114]
     d18:      	eor	w0, w1, w0
     d1c:      	str	w0, [sp, #0x11c]
     d20:      	ldr	w0, [sp, #0x118]
     d24:      	and	w0, w0, #0x1
     d28:      	str	w0, [sp, #0x120]
     d2c:      	str	wzr, [sp, #0x124]
     d30:      	ldr	w0, [sp, #0x120]
     d34:      	cmp	w0, #0x0
     d38:      	cset	w0, ne
     d3c:      	and	w0, w0, #0xff
     d40:      	str	w0, [sp, #0x128]
     d44:      	ldr	w0, [sp, #0x120]
     d48:      	neg	w0, w0
     d4c:      	and	w0, w0, #0xffff
     d50:      	str	w0, [sp, #0x12c]
     d54:      	ldr	w0, [sp, #0x124]
     d58:      	neg	w1, w0
     d5c:      	ldr	w0, [sp, #0x128]
     d60:      	sub	w0, w1, w0
     d64:      	and	w0, w0, #0xffff
     d68:      	str	w0, [sp, #0x130]
     d6c:      	ldr	w0, [sp, #0x118]
     d70:      	lsr	w1, w0, #1
     d74:      	ldr	w0, [sp, #0x11c]
     d78:      	lsl	w0, w0, #15
     d7c:      	orr	w0, w1, w0
     d80:      	and	w0, w0, #0xffff
     d84:      	str	w0, [sp, #0x134]
     d88:      	ldr	w0, [sp, #0x11c]
     d8c:      	lsr	w0, w0, #1
     d90:      	str	w0, [sp, #0x138]
     d94:      	ldr	w1, [sp, #0x12c]
     d98:      	mov	w0, #0x8320             // =33568
     d9c:      	and	w0, w1, w0
     da0:      	str	w0, [sp, #0x13c]
     da4:      	ldr	w1, [sp, #0x130]
     da8:      	mov	w0, #0xedb8             // =60856
     dac:      	and	w0, w1, w0
     db0:      	str	w0, [sp, #0x140]
     db4:      	ldr	w1, [sp, #0x134]
     db8:      	ldr	w0, [sp, #0x13c]
     dbc:      	eor	w0, w1, w0
     dc0:      	str	w0, [sp, #0x144]
     dc4:      	ldr	w1, [sp, #0x138]
     dc8:      	ldr	w0, [sp, #0x140]
     dcc:      	eor	w0, w1, w0
     dd0:      	str	w0, [sp, #0x148]
     dd4:      	ldr	w0, [sp, #0x144]
     dd8:      	and	w0, w0, #0x1
     ddc:      	str	w0, [sp, #0x14c]
     de0:      	str	wzr, [sp, #0x150]
     de4:      	ldr	w0, [sp, #0x14c]
     de8:      	cmp	w0, #0x0
     dec:      	cset	w0, ne
     df0:      	and	w0, w0, #0xff
     df4:      	str	w0, [sp, #0x154]
     df8:      	ldr	w0, [sp, #0x14c]
     dfc:      	neg	w0, w0
     e00:      	and	w0, w0, #0xffff
     e04:      	str	w0, [sp, #0x158]
     e08:      	ldr	w0, [sp, #0x150]
     e0c:      	neg	w1, w0
     e10:      	ldr	w0, [sp, #0x154]
     e14:      	sub	w0, w1, w0
     e18:      	and	w0, w0, #0xffff
     e1c:      	str	w0, [sp, #0x15c]
     e20:      	ldr	w0, [sp, #0x144]
     e24:      	lsr	w1, w0, #1
     e28:      	ldr	w0, [sp, #0x148]
     e2c:      	lsl	w0, w0, #15
     e30:      	orr	w0, w1, w0
     e34:      	and	w0, w0, #0xffff
     e38:      	str	w0, [sp, #0x160]
     e3c:      	ldr	w0, [sp, #0x148]
     e40:      	lsr	w0, w0, #1
     e44:      	str	w0, [sp, #0x164]
     e48:      	ldr	w1, [sp, #0x158]
     e4c:      	mov	w0, #0x8320             // =33568
     e50:      	and	w0, w1, w0
     e54:      	str	w0, [sp, #0x168]
     e58:      	ldr	w1, [sp, #0x15c]
     e5c:      	mov	w0, #0xedb8             // =60856
     e60:      	and	w0, w1, w0
     e64:      	str	w0, [sp, #0x16c]
     e68:      	ldr	w1, [sp, #0x160]
     e6c:      	ldr	w0, [sp, #0x168]
     e70:      	eor	w0, w1, w0
     e74:      	str	w0, [sp, #0x170]
     e78:      	ldr	w1, [sp, #0x164]
     e7c:      	ldr	w0, [sp, #0x16c]
     e80:      	eor	w0, w1, w0
     e84:      	str	w0, [sp, #0x174]
     e88:      	ldr	w0, [sp, #0x170]
     e8c:      	and	w0, w0, #0x1
     e90:      	str	w0, [sp, #0x178]
     e94:      	str	wzr, [sp, #0x17c]
     e98:      	ldr	w0, [sp, #0x178]
     e9c:      	cmp	w0, #0x0
     ea0:      	cset	w0, ne
     ea4:      	and	w0, w0, #0xff
     ea8:      	str	w0, [sp, #0x180]
     eac:      	ldr	w0, [sp, #0x178]
     eb0:      	neg	w0, w0
     eb4:      	and	w0, w0, #0xffff
     eb8:      	str	w0, [sp, #0x184]
     ebc:      	ldr	w0, [sp, #0x17c]
     ec0:      	neg	w1, w0
     ec4:      	ldr	w0, [sp, #0x180]
     ec8:      	sub	w0, w1, w0
     ecc:      	and	w0, w0, #0xffff
     ed0:      	str	w0, [sp, #0x188]
     ed4:      	ldr	w0, [sp, #0x170]
     ed8:      	lsr	w1, w0, #1
     edc:      	ldr	w0, [sp, #0x174]
     ee0:      	lsl	w0, w0, #15
     ee4:      	orr	w0, w1, w0
     ee8:      	and	w0, w0, #0xffff
     eec:      	str	w0, [sp, #0x18c]
     ef0:      	ldr	w0, [sp, #0x174]
     ef4:      	lsr	w0, w0, #1
     ef8:      	str	w0, [sp, #0x190]
     efc:      	ldr	w1, [sp, #0x184]
     f00:      	mov	w0, #0x8320             // =33568
     f04:      	and	w0, w1, w0
     f08:      	str	w0, [sp, #0x194]
     f0c:      	ldr	w1, [sp, #0x188]
     f10:      	mov	w0, #0xedb8             // =60856
     f14:      	and	w0, w1, w0
     f18:      	str	w0, [sp, #0x198]
     f1c:      	ldr	w1, [sp, #0x18c]
     f20:      	ldr	w0, [sp, #0x194]
     f24:      	eor	w0, w1, w0
     f28:      	str	w0, [sp, #0x19c]
     f2c:      	ldr	w1, [sp, #0x190]
     f30:      	ldr	w0, [sp, #0x198]
     f34:      	eor	w0, w1, w0
     f38:      	str	w0, [sp, #0x1a0]
     f3c:      	ldr	w0, [sp, #0x19c]
     f40:      	eor	w0, w0, #0xffff
     f44:      	str	w0, [sp, #0x1a4]
     f48:      	ldr	w0, [sp, #0x1a0]
     f4c:      	eor	w0, w0, #0xffff
     f50:      	str	w0, [sp, #0x1a8]
     f54:      	ldr	w0, [sp, #0x1a8]
     f58:      	lsl	w0, w0, #16
     f5c:      	ldr	w1, [sp, #0x1a4]
     f60:      	orr	w0, w1, w0
     f64:      	str	w0, [sp, #0x1ac]
     f68:      	ldr	w0, [sp, #0x1ac]
     f6c:      	add	sp, sp, #0x1b0
     f70:      	ret

0000000000000f74 <csrd_matrix_next_value>:
     f74:      	sub	sp, sp, #0x10
     f78:      	str	x0, [sp, #0x8]
     f7c:      	ldr	x0, [sp, #0x8]
     f80:      	ldr	w1, [x0]
     f84:      	ldr	x0, [sp, #0x8]
     f88:      	ldr	w0, [x0]
     f8c:      	lsl	w0, w0, #13
     f90:      	eor	w1, w1, w0
     f94:      	ldr	x0, [sp, #0x8]
     f98:      	str	w1, [x0]
     f9c:      	ldr	x0, [sp, #0x8]
     fa0:      	ldr	w1, [x0]
     fa4:      	ldr	x0, [sp, #0x8]
     fa8:      	ldr	w0, [x0]
     fac:      	lsr	w0, w0, #17
     fb0:      	eor	w1, w1, w0
     fb4:      	ldr	x0, [sp, #0x8]
     fb8:      	str	w1, [x0]
     fbc:      	ldr	x0, [sp, #0x8]
     fc0:      	ldr	w1, [x0]
     fc4:      	ldr	x0, [sp, #0x8]
     fc8:      	ldr	w0, [x0]
     fcc:      	lsl	w0, w0, #5
     fd0:      	eor	w1, w1, w0
     fd4:      	ldr	x0, [sp, #0x8]
     fd8:      	str	w1, [x0]
     fdc:      	ldr	x0, [sp, #0x8]
     fe0:      	ldr	w0, [x0]
     fe4:      	add	sp, sp, #0x10
     fe8:      	ret

0000000000000fec <main>:
     fec:      	sub	sp, sp, #0x80
     ff0:      	stp	x29, x30, [sp, #0x70]
     ff4:      	add	x29, sp, #0x70
     ff8:      	str	w0, [sp, #0xc]
     ffc:      	str	x1, [sp]
    1000:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1dc80>
    1004:      	ldr	x0, [x0, #0xfe8]
    1008:      	ldr	x1, [x0]
    100c:      	str	x1, [sp, #0x68]
    1010:      	mov	x1, #0x0                // =0
    1014:      	ldr	w0, [sp, #0xc]
    1018:      	cmp	w0, #0x1
    101c:      	b.ne	0x1070 <main+0x84>
    1020:      	b	0x1040 <main+0x54>
    1024:      	ldr	w0, [sp, #0x60]
    1028:      	ldr	w1, [sp, #0x64]
    102c:      	bl	0x918 <kernel>
    1030:      	mov	w1, w0
    1034:      	adrp	x0, 0x1000 <main+0x14>
    1038:      	add	x0, x0, #0x220
    103c:      	bl	0x7f0 <printf@plt>
    1040:      	add	x0, sp, #0x60
    1044:      	add	x1, x0, #0x4
    1048:      	add	x0, sp, #0x60
    104c:      	mov	x2, x1
    1050:      	mov	x1, x0
    1054:      	adrp	x0, 0x1000 <main+0x14>
    1058:      	add	x0, x0, #0x228
    105c:      	bl	0x7e0 <__isoc99_scanf@plt>
    1060:      	cmp	w0, #0x2
    1064:      	b.eq	0x1024 <main+0x38>
    1068:      	mov	w0, #0x0                // =0
    106c:      	b	0x11d0 <main+0x1e4>
    1070:      	ldr	w0, [sp, #0xc]
    1074:      	cmp	w0, #0x3
    1078:      	b.eq	0x1084 <main+0x98>
    107c:      	mov	w0, #0x3                // =3
    1080:      	b	0x11d0 <main+0x1e4>
    1084:      	ldr	x0, [sp]
    1088:      	add	x0, x0, #0x8
    108c:      	ldr	x0, [x0]
    1090:      	mov	w2, #0xa                // =10
    1094:      	mov	x1, #0x0                // =0
    1098:      	bl	0x770 <strtoul@plt>
    109c:      	str	x0, [sp, #0x30]
    10a0:      	ldr	x0, [sp]
    10a4:      	add	x0, x0, #0x10
    10a8:      	ldr	x0, [x0]
    10ac:      	mov	w2, #0xa                // =10
    10b0:      	mov	x1, #0x0                // =0
    10b4:      	bl	0x770 <strtoul@plt>
    10b8:      	str	w0, [sp, #0x18]
    10bc:      	str	xzr, [sp, #0x20]
    10c0:      	add	x0, sp, #0x40
    10c4:      	mov	x1, x0
    10c8:      	mov	w0, #0x1                // =1
    10cc:      	bl	0x7a0 <clock_gettime@plt>
    10d0:      	cmp	w0, #0x0
    10d4:      	b.eq	0x10e0 <main+0xf4>
    10d8:      	mov	w0, #0x2                // =2
    10dc:      	b	0x11d0 <main+0x1e4>
    10e0:      	str	xzr, [sp, #0x28]
    10e4:      	b	0x114c <main+0x160>
    10e8:      	str	wzr, [sp, #0x1c]
    10ec:      	b	0x1118 <main+0x12c>
    10f0:      	add	x0, sp, #0x18
    10f4:      	bl	0xf74 <csrd_matrix_next_value>
    10f8:      	mov	w2, w0
    10fc:      	ldr	w0, [sp, #0x1c]
    1100:      	lsl	x0, x0, #2
    1104:      	add	x1, sp, #0x60
    1108:      	str	w2, [x1, x0]
    110c:      	ldr	w0, [sp, #0x1c]
    1110:      	add	w0, w0, #0x1
    1114:      	str	w0, [sp, #0x1c]
    1118:      	ldr	w0, [sp, #0x1c]
    111c:      	cmp	w0, #0x1
    1120:      	b.ls	0x10f0 <main+0x104>
    1124:      	ldr	w0, [sp, #0x60]
    1128:      	ldr	w1, [sp, #0x64]
    112c:      	bl	0x918 <kernel>
    1130:      	mov	w0, w0
    1134:      	ldr	x1, [sp, #0x20]
    1138:      	add	x0, x1, x0
    113c:      	str	x0, [sp, #0x20]
    1140:      	ldr	x0, [sp, #0x28]
    1144:      	add	x0, x0, #0x1
    1148:      	str	x0, [sp, #0x28]
    114c:      	ldr	x1, [sp, #0x28]
    1150:      	ldr	x0, [sp, #0x30]
    1154:      	cmp	x1, x0
    1158:      	b.lo	0x10e8 <main+0xfc>
    115c:      	add	x0, sp, #0x50
    1160:      	mov	x1, x0
    1164:      	mov	w0, #0x1                // =1
    1168:      	bl	0x7a0 <clock_gettime@plt>
    116c:      	cmp	w0, #0x0
    1170:      	b.eq	0x117c <main+0x190>
    1174:      	mov	w0, #0x2                // =2
    1178:      	b	0x11d0 <main+0x1e4>
    117c:      	ldr	x1, [sp, #0x50]
    1180:      	ldr	x0, [sp, #0x40]
    1184:      	sub	x0, x1, x0
    1188:      	fmov	d0, x0
    118c:      	scvtf	d1, d0
    1190:      	ldr	x1, [sp, #0x58]
    1194:      	ldr	x0, [sp, #0x48]
    1198:      	sub	x0, x1, x0
    119c:      	fmov	d0, x0
    11a0:      	scvtf	d0, d0
    11a4:      	adrp	x0, 0x1000 <main+0x14>
    11a8:      	ldr	d2, [x0, #0x240]
    11ac:      	fmul	d0, d0, d2
    11b0:      	fadd	d0, d1, d0
    11b4:      	str	d0, [sp, #0x38]
    11b8:      	ldr	x1, [sp, #0x20]
    11bc:      	ldr	d0, [sp, #0x38]
    11c0:      	adrp	x0, 0x1000 <main+0x14>
    11c4:      	add	x0, x0, #0x230
    11c8:      	bl	0x7f0 <printf@plt>
    11cc:      	mov	w0, #0x0                // =0
    11d0:      	mov	w1, w0
    11d4:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1dc80>
    11d8:      	ldr	x0, [x0, #0xfe8]
    11dc:      	ldr	x3, [sp, #0x68]
    11e0:      	ldr	x2, [x0]
    11e4:      	subs	x3, x3, x2
    11e8:      	mov	x2, #0x0                // =0
    11ec:      	b.eq	0x11f4 <main+0x208>
    11f0:      	bl	0x7b0 <__stack_chk_fail@plt>
    11f4:      	mov	w0, w1
    11f8:      	ldp	x29, x30, [sp, #0x70]
    11fc:      	add	sp, sp, #0x80
    1200:      	ret

Disassembly of section .fini:

0000000000001204 <_fini>:
    1204:      	nop
    1208:      	stp	x29, x30, [sp, #-0x10]!
    120c:      	mov	x29, sp
    1210:      	ldp	x29, x30, [sp], #0x10
    1214:      	ret
