
/work/experiments/runs/positional-widths-comparison-20261110/matrix/crc32_byte/build-gcc-O1-limbs8/program:	file format elf64-littleaarch64

Disassembly of section .init:

0000000000000738 <_init>:
     738:      	nop
     73c:      	stp	x29, x30, [sp, #-0x10]!
     740:      	mov	x29, sp
     744:      	bl	0x834 <call_weak_fn>
     748:      	ldp	x29, x30, [sp], #0x10
     74c:      	ret

Disassembly of section .plt:

0000000000000750 <.plt>:
     750:      	stp	x16, x30, [sp, #-0x10]!
     754:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e0fc>
     758:      	ldr	x17, [x16, #0xf78]
     75c:      	add	x16, x16, #0xf78
     760:      	br	x17
     764:      	nop
     768:      	nop
     76c:      	nop

0000000000000770 <strtoul@plt>:
     770:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e0fc>
     774:      	ldr	x17, [x16, #0xf80]
     778:      	add	x16, x16, #0xf80
     77c:      	br	x17

0000000000000780 <__libc_start_main@plt>:
     780:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e0fc>
     784:      	ldr	x17, [x16, #0xf88]
     788:      	add	x16, x16, #0xf88
     78c:      	br	x17

0000000000000790 <__cxa_finalize@plt>:
     790:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e0fc>
     794:      	ldr	x17, [x16, #0xf90]
     798:      	add	x16, x16, #0xf90
     79c:      	br	x17

00000000000007a0 <clock_gettime@plt>:
     7a0:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e0fc>
     7a4:      	ldr	x17, [x16, #0xf98]
     7a8:      	add	x16, x16, #0xf98
     7ac:      	br	x17

00000000000007b0 <__printf_chk@plt>:
     7b0:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e0fc>
     7b4:      	ldr	x17, [x16, #0xfa0]
     7b8:      	add	x16, x16, #0xfa0
     7bc:      	br	x17

00000000000007c0 <__stack_chk_fail@plt>:
     7c0:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e0fc>
     7c4:      	ldr	x17, [x16, #0xfa8]
     7c8:      	add	x16, x16, #0xfa8
     7cc:      	br	x17

00000000000007d0 <__gmon_start__@plt>:
     7d0:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e0fc>
     7d4:      	ldr	x17, [x16, #0xfb0]
     7d8:      	add	x16, x16, #0xfb0
     7dc:      	br	x17

00000000000007e0 <abort@plt>:
     7e0:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e0fc>
     7e4:      	ldr	x17, [x16, #0xfb8]
     7e8:      	add	x16, x16, #0xfb8
     7ec:      	br	x17

00000000000007f0 <__isoc99_scanf@plt>:
     7f0:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e0fc>
     7f4:      	ldr	x17, [x16, #0xfc0]
     7f8:      	add	x16, x16, #0xfc0
     7fc:      	br	x17

Disassembly of section .text:

0000000000000800 <_start>:
     800:      	nop
     804:      	mov	x29, #0x0               // =0
     808:      	mov	x30, #0x0               // =0
     80c:      	mov	x5, x0
     810:      	ldr	x1, [sp]
     814:      	add	x2, sp, #0x8
     818:      	mov	x6, sp
     81c:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e0fc>
     820:      	ldr	x0, [x0, #0xff0]
     824:      	mov	x3, #0x0                // =0
     828:      	mov	x4, #0x0                // =0
     82c:      	bl	0x780 <__libc_start_main@plt>
     830:      	bl	0x7e0 <abort@plt>

0000000000000834 <call_weak_fn>:
     834:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e0fc>
     838:      	ldr	x0, [x0, #0xfe0]
     83c:      	cbz	x0, 0x844 <call_weak_fn+0x10>
     840:      	b	0x7d0 <__gmon_start__@plt>
     844:      	ret
     848:      	nop
     84c:      	nop

0000000000000850 <deregister_tm_clones>:
     850:      	adrp	x0, 0x20000 <data_start>
     854:      	add	x0, x0, #0x10
     858:      	adrp	x1, 0x20000 <data_start>
     85c:      	add	x1, x1, #0x10
     860:      	cmp	x1, x0
     864:      	b.eq	0x87c <deregister_tm_clones+0x2c>
     868:      	adrp	x1, 0x1f000 <__FRAME_END__+0x1e0fc>
     86c:      	ldr	x1, [x1, #0xfd0]
     870:      	cbz	x1, 0x87c <deregister_tm_clones+0x2c>
     874:      	mov	x16, x1
     878:      	br	x16
     87c:      	ret

0000000000000880 <register_tm_clones>:
     880:      	adrp	x0, 0x20000 <data_start>
     884:      	add	x0, x0, #0x10
     888:      	adrp	x1, 0x20000 <data_start>
     88c:      	add	x1, x1, #0x10
     890:      	sub	x1, x1, x0
     894:      	lsr	x2, x1, #63
     898:      	add	x1, x2, x1, asr #3
     89c:      	asr	x1, x1, #1
     8a0:      	cbz	x1, 0x8b8 <register_tm_clones+0x38>
     8a4:      	adrp	x2, 0x1f000 <__FRAME_END__+0x1e0fc>
     8a8:      	ldr	x2, [x2, #0xff8]
     8ac:      	cbz	x2, 0x8b8 <register_tm_clones+0x38>
     8b0:      	mov	x16, x2
     8b4:      	br	x16
     8b8:      	ret
     8bc:      	nop

00000000000008c0 <__do_global_dtors_aux>:
     8c0:      	paciasp
     8c4:      	stp	x29, x30, [sp, #-0x20]!
     8c8:      	mov	x29, sp
     8cc:      	str	x19, [sp, #0x10]
     8d0:      	adrp	x19, 0x20000 <data_start>
     8d4:      	ldrb	w0, [x19, #0x10]
     8d8:      	tbnz	w0, #0x0, 0x900 <__do_global_dtors_aux+0x40>
     8dc:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e0fc>
     8e0:      	ldr	x0, [x0, #0xfd8]
     8e4:      	cbz	x0, 0x8f4 <__do_global_dtors_aux+0x34>
     8e8:      	adrp	x0, 0x20000 <data_start>
     8ec:      	ldr	x0, [x0, #0x8]
     8f0:      	bl	0x790 <__cxa_finalize@plt>
     8f4:      	bl	0x850 <deregister_tm_clones>
     8f8:      	mov	w0, #0x1                // =1
     8fc:      	strb	w0, [x19, #0x10]
     900:      	ldr	x19, [sp, #0x10]
     904:      	ldp	x29, x30, [sp], #0x20
     908:      	autiasp
     90c:      	ret

0000000000000910 <frame_dummy>:
     910:      	bti	c
     914:      	b	0x880 <register_tm_clones>

0000000000000918 <kernel>:
     918:      	mvn	w3, w0, lsr #8
     91c:      	mvn	w2, w0, lsr #16
     920:      	lsr	w8, w0, #24
     924:      	eor	w8, w8, #0xff
     928:      	eon	w0, w0, w1
     92c:      	ands	w1, w0, #0x1
     930:      	ubfx	x4, x0, #1, #7
     934:      	ubfiz	w7, w3, #7, #1
     938:      	orr	w7, w7, w4
     93c:      	ubfiz	w0, w0, #5, #1
     940:      	eor	w6, w7, w0
     944:      	ubfx	x3, x3, #1, #7
     948:      	ubfiz	w5, w2, #7, #1
     94c:      	orr	w5, w5, w3
     950:      	mov	w0, #0x83               // =131
     954:      	csel	w1, w0, wzr, ne
     958:      	eor	w5, w5, w1
     95c:      	ubfx	x1, x2, #1, #7
     960:      	orr	w1, w1, w8, lsl #7
     964:      	and	w1, w1, #0xff
     968:      	mov	w4, #0xb8               // =184
     96c:      	csel	w2, w4, wzr, ne
     970:      	eor	w1, w1, w2
     974:      	mov	w3, #0xed               // =237
     978:      	csel	w2, w3, wzr, ne
     97c:      	eor	w8, w2, w8, lsr #1
     980:      	ands	w9, w7, #0x1
     984:      	lsl	w2, w5, #7
     988:      	orr	w6, w2, w6, lsr #1
     98c:      	and	w6, w6, #0xff
     990:      	ubfiz	w7, w7, #5, #1
     994:      	eor	w7, w6, w7
     998:      	lsl	w2, w1, #7
     99c:      	orr	w2, w2, w5, lsr #1
     9a0:      	and	w2, w2, #0xff
     9a4:      	csel	w5, w0, wzr, ne
     9a8:      	eor	w2, w2, w5
     9ac:      	lsl	w5, w8, #7
     9b0:      	orr	w1, w5, w1, lsr #1
     9b4:      	and	w1, w1, #0xff
     9b8:      	csel	w5, w4, wzr, ne
     9bc:      	eor	w1, w1, w5
     9c0:      	csel	w5, w3, wzr, ne
     9c4:      	eor	w8, w5, w8, lsr #1
     9c8:      	ands	w9, w6, #0x1
     9cc:      	lsl	w5, w2, #7
     9d0:      	orr	w7, w5, w7, lsr #1
     9d4:      	and	w7, w7, #0xff
     9d8:      	ubfiz	w5, w6, #5, #1
     9dc:      	eor	w5, w7, w5
     9e0:      	lsl	w6, w1, #7
     9e4:      	orr	w2, w6, w2, lsr #1
     9e8:      	and	w2, w2, #0xff
     9ec:      	csel	w6, w0, wzr, ne
     9f0:      	eor	w2, w2, w6
     9f4:      	lsl	w6, w8, #7
     9f8:      	orr	w1, w6, w1, lsr #1
     9fc:      	and	w1, w1, #0xff
     a00:      	csel	w6, w4, wzr, ne
     a04:      	eor	w1, w1, w6
     a08:      	csel	w6, w3, wzr, ne
     a0c:      	eor	w8, w6, w8, lsr #1
     a10:      	ands	w9, w7, #0x1
     a14:      	lsl	w6, w2, #7
     a18:      	orr	w5, w6, w5, lsr #1
     a1c:      	and	w5, w5, #0xff
     a20:      	ubfiz	w6, w7, #5, #1
     a24:      	eor	w6, w5, w6
     a28:      	lsl	w7, w1, #7
     a2c:      	orr	w2, w7, w2, lsr #1
     a30:      	and	w2, w2, #0xff
     a34:      	csel	w7, w0, wzr, ne
     a38:      	eor	w2, w2, w7
     a3c:      	lsl	w7, w8, #7
     a40:      	orr	w1, w7, w1, lsr #1
     a44:      	and	w1, w1, #0xff
     a48:      	csel	w7, w4, wzr, ne
     a4c:      	eor	w1, w1, w7
     a50:      	csel	w7, w3, wzr, ne
     a54:      	eor	w7, w7, w8, lsr #1
     a58:      	ands	w8, w5, #0x1
     a5c:      	lsl	w9, w2, #7
     a60:      	orr	w6, w9, w6, lsr #1
     a64:      	and	w6, w6, #0xff
     a68:      	ubfiz	w5, w5, #5, #1
     a6c:      	eor	w5, w6, w5
     a70:      	lsl	w9, w1, #7
     a74:      	orr	w2, w9, w2, lsr #1
     a78:      	and	w2, w2, #0xff
     a7c:      	csel	w8, w0, wzr, ne
     a80:      	eor	w2, w2, w8
     a84:      	lsl	w8, w7, #7
     a88:      	orr	w1, w8, w1, lsr #1
     a8c:      	and	w1, w1, #0xff
     a90:      	csel	w8, w4, wzr, ne
     a94:      	eor	w1, w1, w8
     a98:      	csel	w8, w3, wzr, ne
     a9c:      	eor	w7, w8, w7, lsr #1
     aa0:      	ands	w8, w6, #0x1
     aa4:      	lsl	w9, w2, #7
     aa8:      	orr	w5, w9, w5, lsr #1
     aac:      	and	w5, w5, #0xff
     ab0:      	ubfiz	w6, w6, #5, #1
     ab4:      	eor	w6, w5, w6
     ab8:      	lsl	w9, w1, #7
     abc:      	orr	w2, w9, w2, lsr #1
     ac0:      	and	w2, w2, #0xff
     ac4:      	csel	w8, w0, wzr, ne
     ac8:      	eor	w2, w2, w8
     acc:      	lsl	w8, w7, #7
     ad0:      	orr	w1, w8, w1, lsr #1
     ad4:      	and	w1, w1, #0xff
     ad8:      	csel	w8, w4, wzr, ne
     adc:      	eor	w1, w1, w8
     ae0:      	csel	w8, w3, wzr, ne
     ae4:      	eor	w7, w8, w7, lsr #1
     ae8:      	ands	w8, w5, #0x1
     aec:      	lsl	w9, w2, #7
     af0:      	orr	w6, w9, w6, lsr #1
     af4:      	and	w6, w6, #0xff
     af8:      	ubfiz	w5, w5, #5, #1
     afc:      	eor	w5, w6, w5
     b00:      	lsl	w9, w1, #7
     b04:      	orr	w2, w9, w2, lsr #1
     b08:      	and	w2, w2, #0xff
     b0c:      	csel	w8, w0, wzr, ne
     b10:      	eor	w2, w2, w8
     b14:      	lsl	w8, w7, #7
     b18:      	orr	w1, w8, w1, lsr #1
     b1c:      	and	w1, w1, #0xff
     b20:      	csel	w8, w4, wzr, ne
     b24:      	eor	w1, w1, w8
     b28:      	csel	w8, w3, wzr, ne
     b2c:      	eor	w7, w8, w7, lsr #1
     b30:      	ands	w9, w6, #0x1
     b34:      	lsl	w8, w1, #7
     b38:      	orr	w8, w8, w2, lsr #1
     b3c:      	and	w8, w8, #0xff
     b40:      	csel	w0, w0, wzr, ne
     b44:      	eor	w0, w8, w0
     b48:      	lsl	w0, w0, #8
     b4c:      	eor	w0, w0, #0xff00
     b50:      	lsl	w8, w7, #7
     b54:      	orr	w1, w8, w1, lsr #1
     b58:      	and	w1, w1, #0xff
     b5c:      	csel	w4, w4, wzr, ne
     b60:      	eor	w1, w1, w4
     b64:      	lsl	w1, w1, #16
     b68:      	eor	w1, w1, #0xff0000
     b6c:      	orr	w1, w0, w1
     b70:      	lsl	w2, w2, #7
     b74:      	orr	w0, w2, w5, lsr #1
     b78:      	and	w0, w0, #0xff
     b7c:      	ubfiz	w6, w6, #5, #1
     b80:      	eor	w0, w0, w6
     b84:      	eor	w0, w0, #0xff
     b88:      	csel	w3, w3, wzr, ne
     b8c:      	eor	w7, w3, w7, lsr #1
     b90:      	lsl	w7, w7, #24
     b94:      	eor	w7, w7, #0xff000000
     b98:      	orr	w0, w0, w7
     b9c:      	orr	w0, w1, w0
     ba0:      	ret

0000000000000ba4 <main>:
     ba4:      	sub	sp, sp, #0x60
     ba8:      	stp	x29, x30, [sp, #0x30]
     bac:      	add	x29, sp, #0x30
     bb0:      	stp	x19, x20, [sp, #0x40]
     bb4:      	mov	x19, x1
     bb8:      	adrp	x1, 0x1f000 <__FRAME_END__+0x1e0fc>
     bbc:      	ldr	x1, [x1, #0xfe8]
     bc0:      	ldr	x2, [x1]
     bc4:      	str	x2, [sp, #0x28]
     bc8:      	mov	x2, #0x0                // =0
     bcc:      	cmp	w0, #0x1
     bd0:      	b.eq	0xc10 <main+0x6c>
     bd4:      	mov	w20, #0x3               // =3
     bd8:      	cmp	w0, w20
     bdc:      	b.eq	0xc70 <main+0xcc>
     be0:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e0fc>
     be4:      	ldr	x0, [x0, #0xfe8]
     be8:      	ldr	x2, [sp, #0x28]
     bec:      	ldr	x1, [x0]
     bf0:      	subs	x2, x2, x1
     bf4:      	mov	x1, #0x0                // =0
     bf8:      	b.ne	0xd78 <main+0x1d4>
     bfc:      	mov	w0, w20
     c00:      	ldp	x19, x20, [sp, #0x40]
     c04:      	ldp	x29, x30, [sp, #0x30]
     c08:      	add	sp, sp, #0x60
     c0c:      	ret
     c10:      	stp	x21, x22, [sp, #0x50]
     c14:      	add	x22, sp, #0x20
     c18:      	add	x21, sp, #0x24
     c1c:      	adrp	x19, 0x0 <strtoul@GLIBC_2.17>
     c20:      	add	x19, x19, #0xda8
     c24:      	adrp	x20, 0x0 <strtoul@GLIBC_2.17>
     c28:      	add	x20, x20, #0xda0
     c2c:      	b	0xc4c <main+0xa8>
     c30:      	ldr	w1, [sp, #0x24]
     c34:      	ldr	w0, [sp, #0x20]
     c38:      	bl	0x918 <kernel>
     c3c:      	mov	w2, w0
     c40:      	mov	x1, x20
     c44:      	mov	w0, #0x2                // =2
     c48:      	bl	0x7b0 <__printf_chk@plt>
     c4c:      	mov	x2, x21
     c50:      	mov	x1, x22
     c54:      	mov	x0, x19
     c58:      	bl	0x7f0 <__isoc99_scanf@plt>
     c5c:      	cmp	w0, #0x2
     c60:      	b.eq	0xc30 <main+0x8c>
     c64:      	mov	w20, #0x0               // =0
     c68:      	ldp	x21, x22, [sp, #0x50]
     c6c:      	b	0xbe0 <main+0x3c>
     c70:      	stp	x21, x22, [sp, #0x50]
     c74:      	mov	w2, #0xa                // =10
     c78:      	mov	x1, #0x0                // =0
     c7c:      	ldr	x0, [x19, #0x8]
     c80:      	bl	0x770 <strtoul@plt>
     c84:      	mov	x21, x0
     c88:      	mov	w2, #0xa                // =10
     c8c:      	mov	x1, #0x0                // =0
     c90:      	ldr	x0, [x19, #0x10]
     c94:      	bl	0x770 <strtoul@plt>
     c98:      	mov	x19, x0
     c9c:      	mov	x1, sp
     ca0:      	mov	w0, #0x1                // =1
     ca4:      	bl	0x7a0 <clock_gettime@plt>
     ca8:      	cbnz	w0, 0xd60 <main+0x1bc>
     cac:      	cbz	x21, 0xd58 <main+0x1b4>
     cb0:      	mov	x20, #0x0               // =0
     cb4:      	mov	x22, #0x0               // =0
     cb8:      	eor	w19, w19, w19, lsl #13
     cbc:      	eor	w19, w19, w19, lsr #17
     cc0:      	eor	w0, w19, w19, lsl #5
     cc4:      	str	w0, [sp, #0x20]
     cc8:      	eor	w19, w0, w0, lsl #13
     ccc:      	eor	w19, w19, w19, lsr #17
     cd0:      	eor	w19, w19, w19, lsl #5
     cd4:      	str	w19, [sp, #0x24]
     cd8:      	mov	w1, w19
     cdc:      	bl	0x918 <kernel>
     ce0:      	add	x22, x22, w0, uxtw
     ce4:      	add	x20, x20, #0x1
     ce8:      	cmp	x21, x20
     cec:      	b.ne	0xcb8 <main+0x114>
     cf0:      	add	x1, sp, #0x10
     cf4:      	mov	w0, #0x1                // =1
     cf8:      	bl	0x7a0 <clock_gettime@plt>
     cfc:      	mov	w20, w0
     d00:      	cbnz	w0, 0xd6c <main+0x1c8>
     d04:      	ldr	x0, [sp, #0x18]
     d08:      	ldr	x1, [sp, #0x8]
     d0c:      	sub	x0, x0, x1
     d10:      	fmov	d1, x0
     d14:      	scvtf	d1, d1
     d18:      	adrp	x0, 0x0 <strtoul@GLIBC_2.17>
     d1c:      	ldr	d0, [x0, #0xdc0]
     d20:      	fmul	d1, d1, d0
     d24:      	ldr	x0, [sp, #0x10]
     d28:      	ldr	x1, [sp]
     d2c:      	sub	x0, x0, x1
     d30:      	fmov	d0, x0
     d34:      	scvtf	d0, d0
     d38:      	mov	x2, x22
     d3c:      	fadd	d0, d1, d0
     d40:      	adrp	x1, 0x0 <strtoul@GLIBC_2.17>
     d44:      	add	x1, x1, #0xdb0
     d48:      	mov	w0, #0x2                // =2
     d4c:      	bl	0x7b0 <__printf_chk@plt>
     d50:      	ldp	x21, x22, [sp, #0x50]
     d54:      	b	0xbe0 <main+0x3c>
     d58:      	mov	x22, x21
     d5c:      	b	0xcf0 <main+0x14c>
     d60:      	mov	w20, #0x2               // =2
     d64:      	ldp	x21, x22, [sp, #0x50]
     d68:      	b	0xbe0 <main+0x3c>
     d6c:      	mov	w20, #0x2               // =2
     d70:      	ldp	x21, x22, [sp, #0x50]
     d74:      	b	0xbe0 <main+0x3c>
     d78:      	stp	x21, x22, [sp, #0x50]
     d7c:      	bl	0x7c0 <__stack_chk_fail@plt>

Disassembly of section .fini:

0000000000000d80 <_fini>:
     d80:      	nop
     d84:      	stp	x29, x30, [sp, #-0x10]!
     d88:      	mov	x29, sp
     d8c:      	ldp	x29, x30, [sp], #0x10
     d90:      	ret
