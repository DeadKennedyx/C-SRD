
/work/experiments/runs/positional-widths-comparison-20261110/matrix/crc32_byte/build-clang-O0-identity/program:	file format elf64-littleaarch64

Disassembly of section .init:

0000000000000678 <_init>:
     678:      	nop
     67c:      	stp	x29, x30, [sp, #-0x10]!
     680:      	mov	x29, sp
     684:      	bl	0x774 <call_weak_fn>
     688:      	ldp	x29, x30, [sp], #0x10
     68c:      	ret

Disassembly of section .plt:

0000000000000690 <.plt>:
     690:      	stp	x16, x30, [sp, #-0x10]!
     694:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e174>
     698:      	ldr	x17, [x16, #0xff8]
     69c:      	add	x16, x16, #0xff8
     6a0:      	br	x17
     6a4:      	nop
     6a8:      	nop
     6ac:      	nop

00000000000006b0 <strtoul@plt>:
     6b0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6b4:      	ldr	x17, [x16]
     6b8:      	add	x16, x16, #0x0
     6bc:      	br	x17

00000000000006c0 <__libc_start_main@plt>:
     6c0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6c4:      	ldr	x17, [x16, #0x8]
     6c8:      	add	x16, x16, #0x8
     6cc:      	br	x17

00000000000006d0 <__cxa_finalize@plt>:
     6d0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6d4:      	ldr	x17, [x16, #0x10]
     6d8:      	add	x16, x16, #0x10
     6dc:      	br	x17

00000000000006e0 <clock_gettime@plt>:
     6e0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6e4:      	ldr	x17, [x16, #0x18]
     6e8:      	add	x16, x16, #0x18
     6ec:      	br	x17

00000000000006f0 <__gmon_start__@plt>:
     6f0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6f4:      	ldr	x17, [x16, #0x20]
     6f8:      	add	x16, x16, #0x20
     6fc:      	br	x17

0000000000000700 <abort@plt>:
     700:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     704:      	ldr	x17, [x16, #0x28]
     708:      	add	x16, x16, #0x28
     70c:      	br	x17

0000000000000710 <__isoc99_scanf@plt>:
     710:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     714:      	ldr	x17, [x16, #0x30]
     718:      	add	x16, x16, #0x30
     71c:      	br	x17

0000000000000720 <printf@plt>:
     720:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     724:      	ldr	x17, [x16, #0x38]
     728:      	add	x16, x16, #0x38
     72c:      	br	x17

Disassembly of section .text:

0000000000000740 <_start>:
     740:      	nop
     744:      	mov	x29, #0x0               // =0
     748:      	mov	x30, #0x0               // =0
     74c:      	mov	x5, x0
     750:      	ldr	x1, [sp]
     754:      	add	x2, sp, #0x8
     758:      	mov	x6, sp
     75c:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e174>
     760:      	ldr	x0, [x0, #0xfd8]
     764:      	mov	x3, #0x0                // =0
     768:      	mov	x4, #0x0                // =0
     76c:      	bl	0x6c0 <__libc_start_main@plt>
     770:      	bl	0x700 <abort@plt>

0000000000000774 <call_weak_fn>:
     774:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e174>
     778:      	ldr	x0, [x0, #0xfd0]
     77c:      	cbz	x0, 0x784 <call_weak_fn+0x10>
     780:      	b	0x6f0 <__gmon_start__@plt>
     784:      	ret
     788:      	nop
     78c:      	nop

0000000000000790 <deregister_tm_clones>:
     790:      	adrp	x0, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     794:      	add	x0, x0, #0x50
     798:      	adrp	x1, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     79c:      	add	x1, x1, #0x50
     7a0:      	cmp	x1, x0
     7a4:      	b.eq	0x7bc <deregister_tm_clones+0x2c>
     7a8:      	adrp	x1, 0x1f000 <__FRAME_END__+0x1e174>
     7ac:      	ldr	x1, [x1, #0xfc0]
     7b0:      	cbz	x1, 0x7bc <deregister_tm_clones+0x2c>
     7b4:      	mov	x16, x1
     7b8:      	br	x16
     7bc:      	ret

00000000000007c0 <register_tm_clones>:
     7c0:      	adrp	x0, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     7c4:      	add	x0, x0, #0x50
     7c8:      	adrp	x1, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     7cc:      	add	x1, x1, #0x50
     7d0:      	sub	x1, x1, x0
     7d4:      	lsr	x2, x1, #63
     7d8:      	add	x1, x2, x1, asr #3
     7dc:      	asr	x1, x1, #1
     7e0:      	cbz	x1, 0x7f8 <register_tm_clones+0x38>
     7e4:      	adrp	x2, 0x1f000 <__FRAME_END__+0x1e174>
     7e8:      	ldr	x2, [x2, #0xfe0]
     7ec:      	cbz	x2, 0x7f8 <register_tm_clones+0x38>
     7f0:      	mov	x16, x2
     7f4:      	br	x16
     7f8:      	ret
     7fc:      	nop

0000000000000800 <__do_global_dtors_aux>:
     800:      	paciasp
     804:      	stp	x29, x30, [sp, #-0x20]!
     808:      	mov	x29, sp
     80c:      	str	x19, [sp, #0x10]
     810:      	adrp	x19, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     814:      	ldrb	w0, [x19, #0x50]
     818:      	tbnz	w0, #0x0, 0x840 <__do_global_dtors_aux+0x40>
     81c:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e174>
     820:      	ldr	x0, [x0, #0xfc8]
     824:      	cbz	x0, 0x834 <__do_global_dtors_aux+0x34>
     828:      	adrp	x0, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     82c:      	ldr	x0, [x0, #0x48]
     830:      	bl	0x6d0 <__cxa_finalize@plt>
     834:      	bl	0x790 <deregister_tm_clones>
     838:      	mov	w0, #0x1                // =1
     83c:      	strb	w0, [x19, #0x50]
     840:      	ldr	x19, [sp, #0x10]
     844:      	ldp	x29, x30, [sp], #0x20
     848:      	autiasp
     84c:      	ret

0000000000000850 <frame_dummy>:
     850:      	bti	c
     854:      	b	0x7c0 <register_tm_clones>

0000000000000858 <kernel>:
     858:      	sub	sp, sp, #0xc0
     85c:      	mov	w8, #0x8320             // =33568
     860:      	movk	w8, #0xedb8, lsl #16
     864:      	str	w0, [sp, #0xbc]
     868:      	str	w1, [sp, #0xb8]
     86c:      	ldr	w9, [sp, #0xbc]
     870:      	mvn	w9, w9
     874:      	str	w9, [sp, #0xb4]
     878:      	ldrb	w9, [sp, #0xb8]
     87c:      	str	w9, [sp, #0xb0]
     880:      	ldr	w9, [sp, #0xb4]
     884:      	ldr	w10, [sp, #0xb0]
     888:      	eor	w9, w9, w10
     88c:      	str	w9, [sp, #0xac]
     890:      	ldr	w9, [sp, #0xac]
     894:      	and	w9, w9, #0x1
     898:      	str	w9, [sp, #0xa8]
     89c:      	ldr	w10, [sp, #0xa8]
     8a0:      	mov	w9, wzr
     8a4:      	subs	w10, w9, w10
     8a8:      	str	w10, [sp, #0xa4]
     8ac:      	ldr	w10, [sp, #0xac]
     8b0:      	lsr	w10, w10, #1
     8b4:      	str	w10, [sp, #0xa0]
     8b8:      	ldr	w10, [sp, #0xa4]
     8bc:      	and	w10, w8, w10
     8c0:      	str	w10, [sp, #0x9c]
     8c4:      	ldr	w10, [sp, #0xa0]
     8c8:      	ldr	w11, [sp, #0x9c]
     8cc:      	eor	w10, w10, w11
     8d0:      	str	w10, [sp, #0x98]
     8d4:      	ldr	w10, [sp, #0x98]
     8d8:      	and	w10, w10, #0x1
     8dc:      	str	w10, [sp, #0x94]
     8e0:      	ldr	w10, [sp, #0x94]
     8e4:      	subs	w10, w9, w10
     8e8:      	str	w10, [sp, #0x90]
     8ec:      	ldr	w10, [sp, #0x98]
     8f0:      	lsr	w10, w10, #1
     8f4:      	str	w10, [sp, #0x8c]
     8f8:      	ldr	w10, [sp, #0x90]
     8fc:      	and	w10, w8, w10
     900:      	str	w10, [sp, #0x88]
     904:      	ldr	w10, [sp, #0x8c]
     908:      	ldr	w11, [sp, #0x88]
     90c:      	eor	w10, w10, w11
     910:      	str	w10, [sp, #0x84]
     914:      	ldr	w10, [sp, #0x84]
     918:      	and	w10, w10, #0x1
     91c:      	str	w10, [sp, #0x80]
     920:      	ldr	w10, [sp, #0x80]
     924:      	subs	w10, w9, w10
     928:      	str	w10, [sp, #0x7c]
     92c:      	ldr	w10, [sp, #0x84]
     930:      	lsr	w10, w10, #1
     934:      	str	w10, [sp, #0x78]
     938:      	ldr	w10, [sp, #0x7c]
     93c:      	and	w10, w8, w10
     940:      	str	w10, [sp, #0x74]
     944:      	ldr	w10, [sp, #0x78]
     948:      	ldr	w11, [sp, #0x74]
     94c:      	eor	w10, w10, w11
     950:      	str	w10, [sp, #0x70]
     954:      	ldr	w10, [sp, #0x70]
     958:      	and	w10, w10, #0x1
     95c:      	str	w10, [sp, #0x6c]
     960:      	ldr	w10, [sp, #0x6c]
     964:      	subs	w10, w9, w10
     968:      	str	w10, [sp, #0x68]
     96c:      	ldr	w10, [sp, #0x70]
     970:      	lsr	w10, w10, #1
     974:      	str	w10, [sp, #0x64]
     978:      	ldr	w10, [sp, #0x68]
     97c:      	and	w10, w8, w10
     980:      	str	w10, [sp, #0x60]
     984:      	ldr	w10, [sp, #0x64]
     988:      	ldr	w11, [sp, #0x60]
     98c:      	eor	w10, w10, w11
     990:      	str	w10, [sp, #0x5c]
     994:      	ldr	w10, [sp, #0x5c]
     998:      	and	w10, w10, #0x1
     99c:      	str	w10, [sp, #0x58]
     9a0:      	ldr	w10, [sp, #0x58]
     9a4:      	subs	w10, w9, w10
     9a8:      	str	w10, [sp, #0x54]
     9ac:      	ldr	w10, [sp, #0x5c]
     9b0:      	lsr	w10, w10, #1
     9b4:      	str	w10, [sp, #0x50]
     9b8:      	ldr	w10, [sp, #0x54]
     9bc:      	and	w10, w8, w10
     9c0:      	str	w10, [sp, #0x4c]
     9c4:      	ldr	w10, [sp, #0x50]
     9c8:      	ldr	w11, [sp, #0x4c]
     9cc:      	eor	w10, w10, w11
     9d0:      	str	w10, [sp, #0x48]
     9d4:      	ldr	w10, [sp, #0x48]
     9d8:      	and	w10, w10, #0x1
     9dc:      	str	w10, [sp, #0x44]
     9e0:      	ldr	w10, [sp, #0x44]
     9e4:      	subs	w10, w9, w10
     9e8:      	str	w10, [sp, #0x40]
     9ec:      	ldr	w10, [sp, #0x48]
     9f0:      	lsr	w10, w10, #1
     9f4:      	str	w10, [sp, #0x3c]
     9f8:      	ldr	w10, [sp, #0x40]
     9fc:      	and	w10, w8, w10
     a00:      	str	w10, [sp, #0x38]
     a04:      	ldr	w10, [sp, #0x3c]
     a08:      	ldr	w11, [sp, #0x38]
     a0c:      	eor	w10, w10, w11
     a10:      	str	w10, [sp, #0x34]
     a14:      	ldr	w10, [sp, #0x34]
     a18:      	and	w10, w10, #0x1
     a1c:      	str	w10, [sp, #0x30]
     a20:      	ldr	w10, [sp, #0x30]
     a24:      	subs	w10, w9, w10
     a28:      	str	w10, [sp, #0x2c]
     a2c:      	ldr	w10, [sp, #0x34]
     a30:      	lsr	w10, w10, #1
     a34:      	str	w10, [sp, #0x28]
     a38:      	ldr	w10, [sp, #0x2c]
     a3c:      	and	w10, w8, w10
     a40:      	str	w10, [sp, #0x24]
     a44:      	ldr	w10, [sp, #0x28]
     a48:      	ldr	w11, [sp, #0x24]
     a4c:      	eor	w10, w10, w11
     a50:      	str	w10, [sp, #0x20]
     a54:      	ldr	w10, [sp, #0x20]
     a58:      	and	w10, w10, #0x1
     a5c:      	str	w10, [sp, #0x1c]
     a60:      	ldr	w10, [sp, #0x1c]
     a64:      	subs	w9, w9, w10
     a68:      	str	w9, [sp, #0x18]
     a6c:      	ldr	w9, [sp, #0x20]
     a70:      	lsr	w9, w9, #1
     a74:      	str	w9, [sp, #0x14]
     a78:      	ldr	w9, [sp, #0x18]
     a7c:      	and	w8, w8, w9
     a80:      	str	w8, [sp, #0x10]
     a84:      	ldr	w8, [sp, #0x14]
     a88:      	ldr	w9, [sp, #0x10]
     a8c:      	eor	w8, w8, w9
     a90:      	str	w8, [sp, #0xc]
     a94:      	ldr	w8, [sp, #0xc]
     a98:      	mvn	w8, w8
     a9c:      	str	w8, [sp, #0x8]
     aa0:      	ldr	w0, [sp, #0x8]
     aa4:      	add	sp, sp, #0xc0
     aa8:      	ret

0000000000000aac <main>:
     aac:      	sub	sp, sp, #0x90
     ab0:      	stp	x29, x30, [sp, #0x80]
     ab4:      	add	x29, sp, #0x80
     ab8:      	stur	wzr, [x29, #-0x4]
     abc:      	stur	w0, [x29, #-0x8]
     ac0:      	stur	x1, [x29, #-0x10]
     ac4:      	ldur	w8, [x29, #-0x8]
     ac8:      	subs	w8, w8, #0x1
     acc:      	b.ne	0xb20 <main+0x74>
     ad0:      	b	0xad4 <main+0x28>
     ad4:      	b	0xad8 <main+0x2c>
     ad8:      	sub	x1, x29, #0x18
     adc:      	add	x2, x1, #0x4
     ae0:      	adrp	x0, 0x0 <strtoul@GLIBC_2.17>
     ae4:      	add	x0, x0, #0xd28
     ae8:      	bl	0x710 <__isoc99_scanf@plt>
     aec:      	subs	w8, w0, #0x2
     af0:      	b.ne	0xb18 <main+0x6c>
     af4:      	b	0xaf8 <main+0x4c>
     af8:      	ldur	w0, [x29, #-0x18]
     afc:      	ldur	w1, [x29, #-0x14]
     b00:      	bl	0x858 <kernel>
     b04:      	mov	w1, w0
     b08:      	adrp	x0, 0x0 <strtoul@GLIBC_2.17>
     b0c:      	add	x0, x0, #0xd2d
     b10:      	bl	0x720 <printf@plt>
     b14:      	b	0xad8 <main+0x2c>
     b18:      	stur	wzr, [x29, #-0x4]
     b1c:      	b	0xc94 <main+0x1e8>
     b20:      	ldur	w8, [x29, #-0x8]
     b24:      	subs	w8, w8, #0x3
     b28:      	b.eq	0xb3c <main+0x90>
     b2c:      	b	0xb30 <main+0x84>
     b30:      	mov	w8, #0x3                // =3
     b34:      	stur	w8, [x29, #-0x4]
     b38:      	b	0xc94 <main+0x1e8>
     b3c:      	ldur	x8, [x29, #-0x10]
     b40:      	ldr	x0, [x8, #0x8]
     b44:      	mov	x1, xzr
     b48:      	str	x1, [sp, #0x8]
     b4c:      	mov	w2, #0xa                // =10
     b50:      	str	w2, [sp, #0x14]
     b54:      	bl	0x6b0 <strtoul@plt>
     b58:      	ldr	x1, [sp, #0x8]
     b5c:      	ldr	w2, [sp, #0x14]
     b60:      	stur	x0, [x29, #-0x20]
     b64:      	ldur	x8, [x29, #-0x10]
     b68:      	ldr	x0, [x8, #0x10]
     b6c:      	bl	0x6b0 <strtoul@plt>
     b70:      	mov	w8, w0
     b74:      	stur	w8, [x29, #-0x24]
     b78:      	stur	xzr, [x29, #-0x30]
     b7c:      	mov	w0, #0x1                // =1
     b80:      	add	x1, sp, #0x40
     b84:      	bl	0x6e0 <clock_gettime@plt>
     b88:      	cbz	w0, 0xb9c <main+0xf0>
     b8c:      	b	0xb90 <main+0xe4>
     b90:      	mov	w8, #0x2                // =2
     b94:      	stur	w8, [x29, #-0x4]
     b98:      	b	0xc94 <main+0x1e8>
     b9c:      	str	xzr, [sp, #0x28]
     ba0:      	b	0xba4 <main+0xf8>
     ba4:      	ldr	x8, [sp, #0x28]
     ba8:      	ldur	x9, [x29, #-0x20]
     bac:      	subs	x8, x8, x9
     bb0:      	b.hs	0xc28 <main+0x17c>
     bb4:      	b	0xbb8 <main+0x10c>
     bb8:      	str	wzr, [sp, #0x24]
     bbc:      	b	0xbc0 <main+0x114>
     bc0:      	ldr	w8, [sp, #0x24]
     bc4:      	subs	w8, w8, #0x2
     bc8:      	b.hs	0xbfc <main+0x150>
     bcc:      	b	0xbd0 <main+0x124>
     bd0:      	sub	x0, x29, #0x24
     bd4:      	bl	0xca4 <csrd_matrix_next_value>
     bd8:      	ldr	w8, [sp, #0x24]
     bdc:      	mov	w9, w8
     be0:      	sub	x8, x29, #0x18
     be4:      	str	w0, [x8, x9, lsl #2]
     be8:      	b	0xbec <main+0x140>
     bec:      	ldr	w8, [sp, #0x24]
     bf0:      	add	w8, w8, #0x1
     bf4:      	str	w8, [sp, #0x24]
     bf8:      	b	0xbc0 <main+0x114>
     bfc:      	ldur	w0, [x29, #-0x18]
     c00:      	ldur	w1, [x29, #-0x14]
     c04:      	bl	0x858 <kernel>
     c08:      	ldur	x8, [x29, #-0x30]
     c0c:      	add	x8, x8, w0, uxtw
     c10:      	stur	x8, [x29, #-0x30]
     c14:      	b	0xc18 <main+0x16c>
     c18:      	ldr	x8, [sp, #0x28]
     c1c:      	add	x8, x8, #0x1
     c20:      	str	x8, [sp, #0x28]
     c24:      	b	0xba4 <main+0xf8>
     c28:      	mov	w0, #0x1                // =1
     c2c:      	add	x1, sp, #0x30
     c30:      	bl	0x6e0 <clock_gettime@plt>
     c34:      	cbz	w0, 0xc48 <main+0x19c>
     c38:      	b	0xc3c <main+0x190>
     c3c:      	mov	w8, #0x2                // =2
     c40:      	stur	w8, [x29, #-0x4]
     c44:      	b	0xc94 <main+0x1e8>
     c48:      	ldr	x8, [sp, #0x30]
     c4c:      	ldr	x9, [sp, #0x40]
     c50:      	subs	x8, x8, x9
     c54:      	scvtf	d2, x8
     c58:      	ldr	x8, [sp, #0x38]
     c5c:      	ldr	x9, [sp, #0x48]
     c60:      	subs	x8, x8, x9
     c64:      	scvtf	d0, x8
     c68:      	adrp	x8, 0x0 <strtoul@GLIBC_2.17>
     c6c:      	ldr	d1, [x8, #0xd20]
     c70:      	fmadd	d0, d0, d1, d2
     c74:      	str	d0, [sp, #0x18]
     c78:      	ldr	d0, [sp, #0x18]
     c7c:      	ldur	x1, [x29, #-0x30]
     c80:      	adrp	x0, 0x0 <strtoul@GLIBC_2.17>
     c84:      	add	x0, x0, #0xd31
     c88:      	bl	0x720 <printf@plt>
     c8c:      	stur	wzr, [x29, #-0x4]
     c90:      	b	0xc94 <main+0x1e8>
     c94:      	ldur	w0, [x29, #-0x4]
     c98:      	ldp	x29, x30, [sp, #0x80]
     c9c:      	add	sp, sp, #0x90
     ca0:      	ret

0000000000000ca4 <csrd_matrix_next_value>:
     ca4:      	sub	sp, sp, #0x10
     ca8:      	str	x0, [sp, #0x8]
     cac:      	ldr	x8, [sp, #0x8]
     cb0:      	ldr	w10, [x8]
     cb4:      	ldr	x9, [sp, #0x8]
     cb8:      	ldr	w8, [x9]
     cbc:      	eor	w8, w8, w10, lsl #13
     cc0:      	str	w8, [x9]
     cc4:      	ldr	x8, [sp, #0x8]
     cc8:      	ldr	w10, [x8]
     ccc:      	ldr	x9, [sp, #0x8]
     cd0:      	ldr	w8, [x9]
     cd4:      	eor	w8, w8, w10, lsr #17
     cd8:      	str	w8, [x9]
     cdc:      	ldr	x8, [sp, #0x8]
     ce0:      	ldr	w10, [x8]
     ce4:      	ldr	x9, [sp, #0x8]
     ce8:      	ldr	w8, [x9]
     cec:      	eor	w8, w8, w10, lsl #5
     cf0:      	str	w8, [x9]
     cf4:      	ldr	x8, [sp, #0x8]
     cf8:      	ldr	w0, [x8]
     cfc:      	add	sp, sp, #0x10
     d00:      	ret

Disassembly of section .fini:

0000000000000d04 <_fini>:
     d04:      	nop
     d08:      	stp	x29, x30, [sp, #-0x10]!
     d0c:      	mov	x29, sp
     d10:      	ldp	x29, x30, [sp], #0x10
     d14:      	ret
