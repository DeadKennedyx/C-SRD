typedef signed char int8_t;
typedef short int16_t;
typedef int int32_t;
typedef long long int64_t;

typedef unsigned char uint8_t;
typedef unsigned short uint16_t;
typedef unsigned int uint32_t;
typedef unsigned long long uint64_t;
typedef int8_t int_least8_t;
typedef int16_t int_least16_t;
typedef int32_t int_least32_t;
typedef int64_t int_least64_t;
typedef uint8_t uint_least8_t;
typedef uint16_t uint_least16_t;
typedef uint32_t uint_least32_t;
typedef uint64_t uint_least64_t;
typedef int8_t int_fast8_t;
typedef int16_t int_fast16_t;
typedef int32_t int_fast32_t;
typedef int64_t int_fast64_t;
typedef uint8_t uint_fast8_t;
typedef uint16_t uint_fast16_t;
typedef uint32_t uint_fast32_t;
typedef uint64_t uint_fast64_t;
typedef signed char __int8_t;
typedef unsigned char __uint8_t;
typedef short __int16_t;
typedef unsigned short __uint16_t;
typedef int __int32_t;
typedef unsigned int __uint32_t;
typedef long long __int64_t;
typedef unsigned long long __uint64_t;
typedef long __darwin_intptr_t;
typedef unsigned int __darwin_natural_t;
typedef int __darwin_ct_rune_t;
typedef union {
 char __mbstate8[128];
 long long _mbstateL;
} __mbstate_t;
typedef __mbstate_t __darwin_mbstate_t;
typedef long int __darwin_ptrdiff_t;
typedef long unsigned int __darwin_size_t;
typedef __builtin_va_list __darwin_va_list;
typedef int __darwin_wchar_t;
typedef __darwin_wchar_t __darwin_rune_t;
typedef int __darwin_wint_t;
typedef unsigned long __darwin_clock_t;
typedef __uint32_t __darwin_socklen_t;
typedef long __darwin_ssize_t;
typedef long __darwin_time_t;
typedef __int64_t __darwin_blkcnt_t;
typedef __int32_t __darwin_blksize_t;
typedef __int32_t __darwin_dev_t;
typedef unsigned int __darwin_fsblkcnt_t;
typedef unsigned int __darwin_fsfilcnt_t;
typedef __uint32_t __darwin_gid_t;
typedef __uint32_t __darwin_id_t;
typedef __uint64_t __darwin_ino64_t;
typedef __darwin_ino64_t __darwin_ino_t;
typedef __darwin_natural_t __darwin_mach_port_name_t;
typedef __darwin_mach_port_name_t __darwin_mach_port_t;
typedef __uint16_t __darwin_mode_t;
typedef __int64_t __darwin_off_t;
typedef __int32_t __darwin_pid_t;
typedef __uint32_t __darwin_sigset_t;
typedef __int32_t __darwin_suseconds_t;
typedef __uint32_t __darwin_uid_t;
typedef __uint32_t __darwin_useconds_t;
typedef unsigned char __darwin_uuid_t[16];
typedef char __darwin_uuid_string_t[37];
struct __darwin_pthread_handler_rec {
 void (*__routine)(void *);
 void *__arg;
 struct __darwin_pthread_handler_rec *__next;
};
struct _opaque_pthread_attr_t {
 long __sig;
 char __opaque[56];
};
struct _opaque_pthread_cond_t {
 long __sig;
 char __opaque[40];
};
struct _opaque_pthread_condattr_t {
 long __sig;
 char __opaque[8];
};
struct _opaque_pthread_mutex_t {
 long __sig;
 char __opaque[56];
};
struct _opaque_pthread_mutexattr_t {
 long __sig;
 char __opaque[8];
};
struct _opaque_pthread_once_t {
 long __sig;
 char __opaque[8];
};
struct _opaque_pthread_rwlock_t {
 long __sig;
 char __opaque[192];
};
struct _opaque_pthread_rwlockattr_t {
 long __sig;
 char __opaque[16];
};
struct _opaque_pthread_t {
 long __sig;
 struct __darwin_pthread_handler_rec *__cleanup_stack;
 char __opaque[8176];
};
typedef struct _opaque_pthread_attr_t __darwin_pthread_attr_t;
typedef struct _opaque_pthread_cond_t __darwin_pthread_cond_t;
typedef struct _opaque_pthread_condattr_t __darwin_pthread_condattr_t;
typedef unsigned long __darwin_pthread_key_t;
typedef struct _opaque_pthread_mutex_t __darwin_pthread_mutex_t;
typedef struct _opaque_pthread_mutexattr_t __darwin_pthread_mutexattr_t;
typedef struct _opaque_pthread_once_t __darwin_pthread_once_t;
typedef struct _opaque_pthread_rwlock_t __darwin_pthread_rwlock_t;
typedef struct _opaque_pthread_rwlockattr_t __darwin_pthread_rwlockattr_t;
typedef struct _opaque_pthread_t *__darwin_pthread_t;
typedef __darwin_intptr_t intptr_t;
typedef unsigned long uintptr_t;
typedef long int intmax_t;
typedef long unsigned int uintmax_t;

extern uint32_t next_value(uint32_t value);
extern void record_event(uint32_t value);
uint32_t region_pipeline(uint32_t *buffer, uint32_t x, int limit)
{
    uint32_t y = buffer[0];
    unsigned int csrd_frame_4121_0 = ((3754150975u * (x)) + 2232441807u); unsigned int csrd_frame_4121_1 = ((3754150975u * (y)) + 2232441807u); unsigned int csrd_frame_4121_2 = (((csrd_frame_4121_0) + (csrd_frame_4121_1)) - 2232441807u); unsigned int csrd_frame_4121_3 = (((((3u * (csrd_frame_4121_2)) + 4125050978u)) + (578429572u)) - 2232441807u); csrd_frame_4121_0 = (((csrd_frame_4121_3) - (csrd_frame_4121_1)) + 2232441807u); x = (1887577023u * ((csrd_frame_4121_0) - 2232441807u)); register unsigned int sum = (1887577023u * ((csrd_frame_4121_2) - 2232441807u)); (void)sum; unsigned int bias = (1887577023u * ((csrd_frame_4121_3) - 2232441807u)); (void)bias

;
    record_event(sum);
    if (limit < 0) return x;
    while (limit-- > 0) {
        y = next_value(x);
        {
            unsigned int csrd_frame_4333_0 = ((1743748849u * (x)) + 2246991772u); unsigned int csrd_frame_4333_1 = ((1743748849u * (y)) + 2246991772u); unsigned int csrd_frame_4333_2 = ((1743748849u * (bias)) + 2246991772u); unsigned int csrd_frame_4333_3 = ((1743748849u * (sum)) + 2246991772u); csrd_frame_4333_0 = (((csrd_frame_4333_0) + (csrd_frame_4333_1)) - 2246991772u); unsigned int csrd_frame_4333_4 = (((csrd_frame_4333_2) + (((5u * (csrd_frame_4333_1)) + 3896934800u))) - 2246991772u); unsigned int csrd_frame_4333_5 = (((csrd_frame_4333_4) - (csrd_frame_4333_1)) + 2246991772u); csrd_frame_4333_2 = (((csrd_frame_4333_5) + (csrd_frame_4333_3)) - 2246991772u); x = (3659903505u * ((csrd_frame_4333_0) - 2246991772u)); bias = (3659903505u * ((csrd_frame_4333_2) - 2246991772u)); unsigned int x = (3659903505u * ((csrd_frame_4333_4) - 2246991772u)); (void)x; unsigned int local = (3659903505u * ((csrd_frame_4333_5) - 2246991772u)); (void)local


;
            record_event(x);
            { unsigned int csrd_frame_4493_0 = ((1802629301u * (x)) + 4025129675u); csrd_frame_4493_0 = (((csrd_frame_4493_0) + (3758632894u)) - 4025129675u); x = (2946203037u * ((csrd_frame_4493_0) - 4025129675u));}
            buffer[0] = x;
        }
        { unsigned int csrd_frame_4550_0 = ((2941103111u * (x)) + 25316313u); unsigned int csrd_frame_4550_1 = ((2941103111u * (bias)) + 25316313u); csrd_frame_4550_0 = (((csrd_frame_4550_0) + (csrd_frame_4550_1)) - 25316313u); x = (3091333559u * ((csrd_frame_4550_0) - 25316313u));}
        record_event(y);
    }
    return x;
}
int region_outputs(uint32_t *buffer, uint32_t x, uint32_t y)
{
    unsigned int csrd_frame_4678_0 = ((668389211u * (x)) + 844385197u); unsigned int csrd_frame_4678_1 = ((668389211u * (y)) + 844385197u); unsigned int csrd_frame_4678_2 = 3617067192u; unsigned int csrd_frame_4678_3 = (((csrd_frame_4678_2) + (csrd_frame_4678_0)) - 844385197u); csrd_frame_4678_0 = (((((3u * (csrd_frame_4678_3)) + 2606196902u)) + (csrd_frame_4678_1)) - 844385197u); csrd_frame_4678_1 = (((csrd_frame_4678_0) - (csrd_frame_4678_2)) + 844385197u); x = (505202899u * ((csrd_frame_4678_0) - 844385197u)); y = (505202899u * ((csrd_frame_4678_1) - 844385197u)); register unsigned int pending = (505202899u * ((csrd_frame_4678_2) - 844385197u)); (void)pending; unsigned int mix = (505202899u * ((csrd_frame_4678_3) - 844385197u)); (void)mix


;
    record_event(x);
    {
        unsigned int csrd_frame_4821_0 = ((2761185909u * (x)) + 3646113089u); unsigned int csrd_frame_4821_1 = (((csrd_frame_4821_0) + (1499577972u)) - 3646113089u); unsigned int y = (3054446045u * ((csrd_frame_4821_1) - 3646113089u)); (void)y;
        buffer[2] = y;
    }
    buffer[0] = y;
    buffer[1] = pending;
    return x == y;
}
