
/Users/admin/C-SRD/experiments/runs/private-declarations-cost-native-20261110/clang-O0/affine:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001000004f8 <_region_pipeline>:
1000004f8:     	sub	sp, sp, #0x80
1000004fc:     	stp	x29, x30, [sp, #0x70]
100000500:     	add	x29, sp, #0x70
100000504:     	mov	w10, #0x5bcf            ; =23503
100000508:     	movk	w10, #0x8510, lsl #16
10000050c:     	mov	w8, #0x23bf             ; =9151
100000510:     	movk	w8, #0x7082, lsl #16
100000514:     	mov	w9, #0x7ef1             ; =32497
100000518:     	movk	w9, #0x67ef, lsl #16
10000051c:     	str	w9, [sp, #0x4]
100000520:     	mov	w9, #0x5f9c             ; =24476
100000524:     	movk	w9, #0x85ee, lsl #16
100000528:     	str	w9, [sp, #0x8]
10000052c:     	mov	w9, #0xb211             ; =45585
100000530:     	movk	w9, #0xda25, lsl #16
100000534:     	str	w9, [sp, #0xc]
100000538:     	stur	x0, [x29, #-0x10]
10000053c:     	stur	w1, [x29, #-0x14]
100000540:     	stur	w2, [x29, #-0x18]
100000544:     	ldur	x9, [x29, #-0x10]
100000548:     	ldr	w9, [x9]
10000054c:     	stur	w9, [x29, #-0x1c]
100000550:     	ldur	w11, [x29, #-0x14]
100000554:     	mov	w9, #0xcc3f             ; =52287
100000558:     	movk	w9, #0xdfc3, lsl #16
10000055c:     	mul	w11, w9, w11
100000560:     	add	w11, w11, w10
100000564:     	stur	w11, [x29, #-0x20]
100000568:     	ldur	w11, [x29, #-0x1c]
10000056c:     	mul	w9, w9, w11
100000570:     	add	w9, w9, w10
100000574:     	stur	w9, [x29, #-0x24]
100000578:     	ldur	w9, [x29, #-0x20]
10000057c:     	ldur	w11, [x29, #-0x24]
100000580:     	add	w9, w9, w11
100000584:     	mov	w11, #0xa431            ; =42033
100000588:     	movk	w11, #0x7aef, lsl #16
10000058c:     	add	w9, w9, w11
100000590:     	stur	w9, [x29, #-0x28]
100000594:     	ldur	w11, [x29, #-0x28]
100000598:     	mov	w9, #0x3                ; =3
10000059c:     	mul	w9, w9, w11
1000005a0:     	mov	w11, #0x4862            ; =18530
1000005a4:     	movk	w11, #0xf5df, lsl #16
1000005a8:     	add	w9, w9, w11
1000005ac:     	mov	w11, #0x2284            ; =8836
1000005b0:     	movk	w11, #0x227a, lsl #16
1000005b4:     	add	w9, w9, w11
1000005b8:     	mov	w11, #0xa431            ; =42033
1000005bc:     	movk	w11, #0x7aef, lsl #16
1000005c0:     	add	w9, w9, w11
1000005c4:     	stur	w9, [x29, #-0x2c]
1000005c8:     	ldur	w9, [x29, #-0x2c]
1000005cc:     	ldur	w11, [x29, #-0x24]
1000005d0:     	subs	w9, w9, w11
1000005d4:     	add	w9, w9, w10
1000005d8:     	stur	w9, [x29, #-0x20]
1000005dc:     	ldur	w9, [x29, #-0x20]
1000005e0:     	mov	w10, #0xa431            ; =42033
1000005e4:     	movk	w10, #0x7aef, lsl #16
1000005e8:     	add	w9, w9, w10
1000005ec:     	mul	w9, w8, w9
1000005f0:     	stur	w9, [x29, #-0x14]
1000005f4:     	ldur	w9, [x29, #-0x28]
1000005f8:     	mov	w10, #0xa431            ; =42033
1000005fc:     	movk	w10, #0x7aef, lsl #16
100000600:     	add	w9, w9, w10
100000604:     	mul	w9, w8, w9
100000608:     	stur	w9, [x29, #-0x30]
10000060c:     	ldur	w9, [x29, #-0x2c]
100000610:     	mov	w10, #0xa431            ; =42033
100000614:     	movk	w10, #0x7aef, lsl #16
100000618:     	add	w9, w9, w10
10000061c:     	mul	w8, w8, w9
100000620:     	stur	w8, [x29, #-0x34]
100000624:     	ldur	w0, [x29, #-0x30]
100000628:     	bl	0x100000a60 <_record_event>
10000062c:     	ldur	w8, [x29, #-0x18]
100000630:     	tbnz	w8, #0x1f, 0x100000638 <_region_pipeline+0x140>
100000634:     	b	0x100000644 <_region_pipeline+0x14c>
100000638:     	ldur	w8, [x29, #-0x14]
10000063c:     	stur	w8, [x29, #-0x4]
100000640:     	b	0x10000088c <_region_pipeline+0x394>
100000644:     	b	0x100000648 <_region_pipeline+0x150>
100000648:     	ldur	w8, [x29, #-0x18]
10000064c:     	subs	w9, w8, #0x1
100000650:     	stur	w9, [x29, #-0x18]
100000654:     	subs	w8, w8, #0x0
100000658:     	b.gt	0x100000660 <_region_pipeline+0x168>
10000065c:     	b	0x100000880 <_region_pipeline+0x388>
100000660:     	ldur	w0, [x29, #-0x14]
100000664:     	bl	0x100000a8c <_next_value>
100000668:     	ldr	w9, [sp, #0x4]
10000066c:     	ldr	w10, [sp, #0x8]
100000670:     	ldr	w8, [sp, #0xc]
100000674:     	stur	w0, [x29, #-0x1c]
100000678:     	ldur	w11, [x29, #-0x14]
10000067c:     	mul	w11, w9, w11
100000680:     	add	w11, w11, w10
100000684:     	str	w11, [sp, #0x38]
100000688:     	ldur	w11, [x29, #-0x1c]
10000068c:     	mul	w11, w9, w11
100000690:     	add	w11, w11, w10
100000694:     	str	w11, [sp, #0x34]
100000698:     	ldur	w11, [x29, #-0x34]
10000069c:     	mul	w11, w9, w11
1000006a0:     	add	w11, w11, w10
1000006a4:     	str	w11, [sp, #0x30]
1000006a8:     	ldur	w11, [x29, #-0x30]
1000006ac:     	mul	w9, w9, w11
1000006b0:     	add	w9, w9, w10
1000006b4:     	str	w9, [sp, #0x2c]
1000006b8:     	ldr	w9, [sp, #0x38]
1000006bc:     	ldr	w11, [sp, #0x34]
1000006c0:     	add	w9, w9, w11
1000006c4:     	mov	w11, #0xa064            ; =41060
1000006c8:     	movk	w11, #0x7a11, lsl #16
1000006cc:     	add	w9, w9, w11
1000006d0:     	str	w9, [sp, #0x38]
1000006d4:     	ldr	w9, [sp, #0x30]
1000006d8:     	ldr	w12, [sp, #0x34]
1000006dc:     	mov	w11, #0x5               ; =5
1000006e0:     	mul	w11, w11, w12
1000006e4:     	mov	w12, #0x8190            ; =33168
1000006e8:     	movk	w12, #0xe846, lsl #16
1000006ec:     	add	w11, w11, w12
1000006f0:     	add	w9, w9, w11
1000006f4:     	mov	w11, #0xa064            ; =41060
1000006f8:     	movk	w11, #0x7a11, lsl #16
1000006fc:     	add	w9, w9, w11
100000700:     	str	w9, [sp, #0x28]
100000704:     	ldr	w9, [sp, #0x28]
100000708:     	ldr	w11, [sp, #0x34]
10000070c:     	subs	w9, w9, w11
100000710:     	add	w9, w9, w10
100000714:     	str	w9, [sp, #0x24]
100000718:     	ldr	w9, [sp, #0x24]
10000071c:     	ldr	w10, [sp, #0x2c]
100000720:     	add	w9, w9, w10
100000724:     	mov	w10, #0xa064            ; =41060
100000728:     	movk	w10, #0x7a11, lsl #16
10000072c:     	add	w9, w9, w10
100000730:     	str	w9, [sp, #0x30]
100000734:     	ldr	w9, [sp, #0x38]
100000738:     	mov	w10, #0xa064            ; =41060
10000073c:     	movk	w10, #0x7a11, lsl #16
100000740:     	add	w9, w9, w10
100000744:     	mul	w9, w8, w9
100000748:     	stur	w9, [x29, #-0x14]
10000074c:     	ldr	w9, [sp, #0x30]
100000750:     	mov	w10, #0xa064            ; =41060
100000754:     	movk	w10, #0x7a11, lsl #16
100000758:     	add	w9, w9, w10
10000075c:     	mul	w9, w8, w9
100000760:     	stur	w9, [x29, #-0x34]
100000764:     	ldr	w9, [sp, #0x28]
100000768:     	mov	w10, #0xa064            ; =41060
10000076c:     	movk	w10, #0x7a11, lsl #16
100000770:     	add	w9, w9, w10
100000774:     	mul	w9, w8, w9
100000778:     	str	w9, [sp, #0x20]
10000077c:     	ldr	w9, [sp, #0x24]
100000780:     	mov	w10, #0xa064            ; =41060
100000784:     	movk	w10, #0x7a11, lsl #16
100000788:     	add	w9, w9, w10
10000078c:     	mul	w8, w8, w9
100000790:     	str	w8, [sp, #0x1c]
100000794:     	ldr	w0, [sp, #0x20]
100000798:     	bl	0x100000a60 <_record_event>
10000079c:     	ldr	w9, [sp, #0x20]
1000007a0:     	mov	w8, #0xf0b5             ; =61621
1000007a4:     	movk	w8, #0x6b71, lsl #16
1000007a8:     	mul	w8, w8, w9
1000007ac:     	mov	w9, #0x9acb             ; =39627
1000007b0:     	movk	w9, #0xefea, lsl #16
1000007b4:     	add	w8, w8, w9
1000007b8:     	str	w8, [sp, #0x18]
1000007bc:     	ldr	w8, [sp, #0x18]
1000007c0:     	mov	w9, #0x2fbe             ; =12222
1000007c4:     	movk	w9, #0xe008, lsl #16
1000007c8:     	add	w8, w8, w9
1000007cc:     	mov	w9, #0x6535             ; =25909
1000007d0:     	movk	w9, #0x1015, lsl #16
1000007d4:     	add	w8, w8, w9
1000007d8:     	str	w8, [sp, #0x18]
1000007dc:     	ldr	w8, [sp, #0x18]
1000007e0:     	mov	w9, #0x6535             ; =25909
1000007e4:     	movk	w9, #0x1015, lsl #16
1000007e8:     	add	w9, w8, w9
1000007ec:     	mov	w8, #0x7d9d             ; =32157
1000007f0:     	movk	w8, #0xaf9b, lsl #16
1000007f4:     	mul	w8, w8, w9
1000007f8:     	str	w8, [sp, #0x20]
1000007fc:     	ldr	w8, [sp, #0x20]
100000800:     	ldur	x9, [x29, #-0x10]
100000804:     	str	w8, [x9]
100000808:     	ldur	w9, [x29, #-0x14]
10000080c:     	mov	w8, #0xac07             ; =44039
100000810:     	movk	w8, #0xaf4d, lsl #16
100000814:     	mul	w10, w8, w9
100000818:     	mov	w9, #0x4bd9             ; =19417
10000081c:     	movk	w9, #0x182, lsl #16
100000820:     	add	w10, w10, w9
100000824:     	str	w10, [sp, #0x14]
100000828:     	ldur	w10, [x29, #-0x34]
10000082c:     	mul	w8, w8, w10
100000830:     	add	w8, w8, w9
100000834:     	str	w8, [sp, #0x10]
100000838:     	ldr	w8, [sp, #0x14]
10000083c:     	ldr	w9, [sp, #0x10]
100000840:     	add	w8, w8, w9
100000844:     	mov	w9, #0xb427             ; =46119
100000848:     	movk	w9, #0xfe7d, lsl #16
10000084c:     	add	w8, w8, w9
100000850:     	str	w8, [sp, #0x14]
100000854:     	ldr	w8, [sp, #0x14]
100000858:     	mov	w9, #0xb427             ; =46119
10000085c:     	movk	w9, #0xfe7d, lsl #16
100000860:     	add	w9, w8, w9
100000864:     	mov	w8, #0x1b7              ; =439
100000868:     	movk	w8, #0xb842, lsl #16
10000086c:     	mul	w8, w8, w9
100000870:     	stur	w8, [x29, #-0x14]
100000874:     	ldur	w0, [x29, #-0x1c]
100000878:     	bl	0x100000a60 <_record_event>
10000087c:     	b	0x100000648 <_region_pipeline+0x150>
100000880:     	ldur	w8, [x29, #-0x14]
100000884:     	stur	w8, [x29, #-0x4]
100000888:     	b	0x10000088c <_region_pipeline+0x394>
10000088c:     	ldur	w0, [x29, #-0x4]
100000890:     	ldp	x29, x30, [sp, #0x70]
100000894:     	add	sp, sp, #0x80
100000898:     	ret

000000010000089c <_region_outputs>:
10000089c:     	sub	sp, sp, #0x50
1000008a0:     	stp	x29, x30, [sp, #0x40]
1000008a4:     	add	x29, sp, #0x40
1000008a8:     	mov	w10, #0x4bad            ; =19373
1000008ac:     	movk	w10, #0x3254, lsl #16
1000008b0:     	mov	w8, #0xc8d3             ; =51411
1000008b4:     	movk	w8, #0x1e1c, lsl #16
1000008b8:     	stur	x0, [x29, #-0x8]
1000008bc:     	stur	w1, [x29, #-0xc]
1000008c0:     	stur	w2, [x29, #-0x10]
1000008c4:     	ldur	w11, [x29, #-0xc]
1000008c8:     	mov	w9, #0xcf5b             ; =53083
1000008cc:     	movk	w9, #0x27d6, lsl #16
1000008d0:     	mul	w11, w9, w11
1000008d4:     	add	w11, w11, w10
1000008d8:     	stur	w11, [x29, #-0x14]
1000008dc:     	ldur	w11, [x29, #-0x10]
1000008e0:     	mul	w9, w9, w11
1000008e4:     	add	w9, w9, w10
1000008e8:     	stur	w9, [x29, #-0x18]
1000008ec:     	mov	w9, #0x10b8             ; =4280
1000008f0:     	movk	w9, #0xd798, lsl #16
1000008f4:     	stur	w9, [x29, #-0x1c]
1000008f8:     	ldur	w9, [x29, #-0x1c]
1000008fc:     	ldur	w11, [x29, #-0x14]
100000900:     	add	w9, w9, w11
100000904:     	mov	w11, #0xb453            ; =46163
100000908:     	movk	w11, #0xcdab, lsl #16
10000090c:     	add	w9, w9, w11
100000910:     	str	w9, [sp, #0x20]
100000914:     	ldr	w11, [sp, #0x20]
100000918:     	mov	w9, #0x3                ; =3
10000091c:     	mul	w9, w9, w11
100000920:     	mov	w11, #0x68a6            ; =26790
100000924:     	movk	w11, #0x9b57, lsl #16
100000928:     	add	w9, w9, w11
10000092c:     	ldur	w11, [x29, #-0x18]
100000930:     	add	w9, w9, w11
100000934:     	mov	w11, #0xb453            ; =46163
100000938:     	movk	w11, #0xcdab, lsl #16
10000093c:     	add	w9, w9, w11
100000940:     	stur	w9, [x29, #-0x14]
100000944:     	ldur	w9, [x29, #-0x14]
100000948:     	ldur	w11, [x29, #-0x1c]
10000094c:     	subs	w9, w9, w11
100000950:     	add	w9, w9, w10
100000954:     	stur	w9, [x29, #-0x18]
100000958:     	ldur	w9, [x29, #-0x14]
10000095c:     	mov	w10, #0xb453            ; =46163
100000960:     	movk	w10, #0xcdab, lsl #16
100000964:     	add	w9, w9, w10
100000968:     	mul	w9, w8, w9
10000096c:     	stur	w9, [x29, #-0xc]
100000970:     	ldur	w9, [x29, #-0x18]
100000974:     	mov	w10, #0xb453            ; =46163
100000978:     	movk	w10, #0xcdab, lsl #16
10000097c:     	add	w9, w9, w10
100000980:     	mul	w9, w8, w9
100000984:     	stur	w9, [x29, #-0x10]
100000988:     	ldur	w9, [x29, #-0x1c]
10000098c:     	mov	w10, #0xb453            ; =46163
100000990:     	movk	w10, #0xcdab, lsl #16
100000994:     	add	w9, w9, w10
100000998:     	mul	w9, w8, w9
10000099c:     	str	w9, [sp, #0x1c]
1000009a0:     	ldr	w9, [sp, #0x20]
1000009a4:     	mov	w10, #0xb453            ; =46163
1000009a8:     	movk	w10, #0xcdab, lsl #16
1000009ac:     	add	w9, w9, w10
1000009b0:     	mul	w8, w8, w9
1000009b4:     	str	w8, [sp, #0x18]
1000009b8:     	ldur	w0, [x29, #-0xc]
1000009bc:     	bl	0x100000a60 <_record_event>
1000009c0:     	ldur	w9, [x29, #-0xc]
1000009c4:     	mov	w8, #0x5a75             ; =23157
1000009c8:     	movk	w8, #0xa494, lsl #16
1000009cc:     	mul	w8, w8, w9
1000009d0:     	mov	w9, #0x4541             ; =17729
1000009d4:     	movk	w9, #0xd953, lsl #16
1000009d8:     	add	w8, w8, w9
1000009dc:     	str	w8, [sp, #0x14]
1000009e0:     	ldr	w8, [sp, #0x14]
1000009e4:     	mov	w9, #0xbe74             ; =48756
1000009e8:     	movk	w9, #0x5961, lsl #16
1000009ec:     	add	w8, w8, w9
1000009f0:     	mov	w9, #0xbabf             ; =47807
1000009f4:     	movk	w9, #0x26ac, lsl #16
1000009f8:     	add	w8, w8, w9
1000009fc:     	str	w8, [sp, #0x10]
100000a00:     	ldr	w8, [sp, #0x10]
100000a04:     	mov	w9, #0xbabf             ; =47807
100000a08:     	movk	w9, #0x26ac, lsl #16
100000a0c:     	add	w9, w8, w9
100000a10:     	mov	w8, #0x25dd             ; =9693
100000a14:     	movk	w8, #0xb60f, lsl #16
100000a18:     	mul	w8, w8, w9
100000a1c:     	str	w8, [sp, #0xc]
100000a20:     	ldr	w8, [sp, #0xc]
100000a24:     	ldur	x9, [x29, #-0x8]
100000a28:     	str	w8, [x9, #0x8]
100000a2c:     	ldur	w8, [x29, #-0x10]
100000a30:     	ldur	x9, [x29, #-0x8]
100000a34:     	str	w8, [x9]
100000a38:     	ldr	w8, [sp, #0x1c]
100000a3c:     	ldur	x9, [x29, #-0x8]
100000a40:     	str	w8, [x9, #0x4]
100000a44:     	ldur	w8, [x29, #-0xc]
100000a48:     	ldur	w9, [x29, #-0x10]
100000a4c:     	subs	w8, w8, w9
100000a50:     	cset	w0, eq
100000a54:     	ldp	x29, x30, [sp, #0x40]
100000a58:     	add	sp, sp, #0x50
100000a5c:     	ret

0000000100000a60 <_record_event>:
100000a60:     	sub	sp, sp, #0x10
100000a64:     	str	w0, [sp, #0xc]
100000a68:     	adrp	x9, 0x100008000 <_event_hash>
100000a6c:     	ldr	w8, [x9]
100000a70:     	mov	w10, #0x21              ; =33
100000a74:     	mul	w8, w8, w10
100000a78:     	ldr	w10, [sp, #0xc]
100000a7c:     	eor	w8, w8, w10
100000a80:     	str	w8, [x9]
100000a84:     	add	sp, sp, #0x10
100000a88:     	ret

0000000100000a8c <_next_value>:
100000a8c:     	sub	sp, sp, #0x20
100000a90:     	stp	x29, x30, [sp, #0x10]
100000a94:     	add	x29, sp, #0x10
100000a98:     	stur	w0, [x29, #-0x4]
100000a9c:     	ldur	w0, [x29, #-0x4]
100000aa0:     	bl	0x100000a60 <_record_event>
100000aa4:     	ldur	w10, [x29, #-0x4]
100000aa8:     	adrp	x9, 0x100008000 <_event_hash>
100000aac:     	add	x9, x9, #0x4
100000ab0:     	ldr	w8, [x9, #0x4]
100000ab4:     	add	w8, w8, w10
100000ab8:     	str	w8, [x9, #0x4]
100000abc:     	ldur	w8, [x29, #-0x4]
100000ac0:     	ldr	w9, [x9, #0x4]
100000ac4:     	add	w0, w8, w9
100000ac8:     	ldp	x29, x30, [sp, #0x10]
100000acc:     	add	sp, sp, #0x20
100000ad0:     	ret

0000000100000ad4 <_main>:
100000ad4:     	sub	sp, sp, #0xb0
100000ad8:     	stp	x29, x30, [sp, #0xa0]
100000adc:     	add	x29, sp, #0xa0
100000ae0:     	stur	wzr, [x29, #-0x4]
100000ae4:     	stur	w0, [x29, #-0x8]
100000ae8:     	stur	x1, [x29, #-0x10]
100000aec:     	ldur	w8, [x29, #-0x8]
100000af0:     	subs	w8, w8, #0x3
100000af4:     	b.ne	0x100000afc <_main+0x28>
100000af8:     	b	0x100000b08 <_main+0x34>
100000afc:     	mov	w8, #0x2                ; =2
100000b00:     	stur	w8, [x29, #-0x4]
100000b04:     	b	0x100000ce4 <_main+0x210>
100000b08:     	ldur	x8, [x29, #-0x10]
100000b0c:     	ldr	x0, [x8, #0x8]
100000b10:     	mov	x1, #0x0                ; =0
100000b14:     	str	x1, [sp, #0x40]
100000b18:     	mov	w2, #0xa                ; =10
100000b1c:     	str	w2, [sp, #0x4c]
100000b20:     	bl	0x100000d0c <_strtoul+0x100000d0c>
100000b24:     	ldr	x1, [sp, #0x40]
100000b28:     	ldr	w2, [sp, #0x4c]
100000b2c:     	stur	x0, [x29, #-0x18]
100000b30:     	ldur	x8, [x29, #-0x10]
100000b34:     	ldr	x0, [x8, #0x10]
100000b38:     	bl	0x100000d0c <_strtoul+0x100000d0c>
100000b3c:     	mov	x8, x0
100000b40:     	stur	w8, [x29, #-0x1c]
100000b44:     	stur	wzr, [x29, #-0x20]
100000b48:     	mov	w0, #0x6                ; =6
100000b4c:     	sub	x1, x29, #0x30
100000b50:     	bl	0x100000cf4 <_strtoul+0x100000cf4>
100000b54:     	cbnz	w0, 0x100000b5c <_main+0x88>
100000b58:     	b	0x100000b68 <_main+0x94>
100000b5c:     	mov	w8, #0x2                ; =2
100000b60:     	stur	w8, [x29, #-0x4]
100000b64:     	b	0x100000ce4 <_main+0x210>
100000b68:     	stur	xzr, [x29, #-0x48]
100000b6c:     	b	0x100000b70 <_main+0x9c>
100000b70:     	ldur	x8, [x29, #-0x48]
100000b74:     	ldur	x9, [x29, #-0x18]
100000b78:     	subs	x8, x8, x9
100000b7c:     	b.lo	0x100000b84 <_main+0xb0>
100000b80:     	b	0x100000c20 <_main+0x14c>
100000b84:     	ldur	w9, [x29, #-0x1c]
100000b88:     	ldur	w8, [x29, #-0x1c]
100000b8c:     	eor	w8, w8, w9, lsl #13
100000b90:     	stur	w8, [x29, #-0x1c]
100000b94:     	ldur	w9, [x29, #-0x1c]
100000b98:     	ldur	w8, [x29, #-0x1c]
100000b9c:     	eor	w8, w8, w9, lsr #17
100000ba0:     	stur	w8, [x29, #-0x1c]
100000ba4:     	ldur	w9, [x29, #-0x1c]
100000ba8:     	ldur	w8, [x29, #-0x1c]
100000bac:     	eor	w8, w8, w9, lsl #5
100000bb0:     	stur	w8, [x29, #-0x1c]
100000bb4:     	ldur	w1, [x29, #-0x1c]
100000bb8:     	ldur	x8, [x29, #-0x48]
100000bbc:     	mov	x10, #0xa               ; =10
100000bc0:     	udiv	x9, x8, x10
100000bc4:     	mul	x9, x9, x10
100000bc8:     	subs	x8, x8, x9
100000bcc:     	subs	w2, w8, #0x1
100000bd0:     	adrp	x0, 0x100008000 <_event_hash>
100000bd4:     	add	x0, x0, #0x4
100000bd8:     	str	x0, [sp, #0x38]
100000bdc:     	bl	0x1000004f8 <_region_pipeline>
100000be0:     	mov	x9, x0
100000be4:     	ldr	x0, [sp, #0x38]
100000be8:     	ldur	w8, [x29, #-0x20]
100000bec:     	add	w8, w8, w9
100000bf0:     	stur	w8, [x29, #-0x20]
100000bf4:     	ldur	w1, [x29, #-0x1c]
100000bf8:     	ldur	w2, [x29, #-0x20]
100000bfc:     	bl	0x10000089c <_region_outputs>
100000c00:     	ldur	w8, [x29, #-0x20]
100000c04:     	add	w8, w8, w0
100000c08:     	stur	w8, [x29, #-0x20]
100000c0c:     	b	0x100000c10 <_main+0x13c>
100000c10:     	ldur	x8, [x29, #-0x48]
100000c14:     	add	x8, x8, #0x1
100000c18:     	stur	x8, [x29, #-0x48]
100000c1c:     	b	0x100000b70 <_main+0x9c>
100000c20:     	mov	w0, #0x6                ; =6
100000c24:     	sub	x1, x29, #0x40
100000c28:     	bl	0x100000cf4 <_strtoul+0x100000cf4>
100000c2c:     	cbnz	w0, 0x100000c34 <_main+0x160>
100000c30:     	b	0x100000c40 <_main+0x16c>
100000c34:     	mov	w8, #0x2                ; =2
100000c38:     	stur	w8, [x29, #-0x4]
100000c3c:     	b	0x100000ce4 <_main+0x210>
100000c40:     	ldur	x8, [x29, #-0x40]
100000c44:     	ldur	x9, [x29, #-0x30]
100000c48:     	subs	x8, x8, x9
100000c4c:     	scvtf	d2, x8
100000c50:     	ldur	x8, [x29, #-0x38]
100000c54:     	ldur	x9, [x29, #-0x28]
100000c58:     	subs	x8, x8, x9
100000c5c:     	scvtf	d0, x8
100000c60:     	mov	x8, #0xd695             ; =54933
100000c64:     	movk	x8, #0xe826, lsl #16
100000c68:     	movk	x8, #0x2e0b, lsl #32
100000c6c:     	movk	x8, #0x3e11, lsl #48
100000c70:     	fmov	d1, x8
100000c74:     	fmadd	d0, d0, d1, d2
100000c78:     	str	d0, [sp, #0x50]
100000c7c:     	ldr	d0, [sp, #0x50]
100000c80:     	ldur	w8, [x29, #-0x20]
100000c84:     	mov	x13, x8
100000c88:     	adrp	x9, 0x100008000 <_event_hash>
100000c8c:     	adrp	x8, 0x100008000 <_event_hash>
100000c90:     	add	x8, x8, #0x4
100000c94:     	ldr	w9, [x9, #0x4]
100000c98:     	mov	x12, x9
100000c9c:     	ldr	w9, [x8, #0x4]
100000ca0:     	mov	x11, x9
100000ca4:     	ldr	w8, [x8, #0x8]
100000ca8:     	mov	x10, x8
100000cac:     	adrp	x8, 0x100008000 <_event_hash>
100000cb0:     	ldr	w8, [x8]
100000cb4:     	mov	x9, sp
100000cb8:     	str	d0, [x9]
100000cbc:     	str	x13, [x9, #0x8]
100000cc0:     	str	x12, [x9, #0x10]
100000cc4:     	str	x11, [x9, #0x18]
100000cc8:     	str	x10, [x9, #0x20]
100000ccc:     	str	x8, [x9, #0x28]
100000cd0:     	adrp	x0, 0x100000000 <_strtoul+0x100000000>
100000cd4:     	add	x0, x0, #0xd18
100000cd8:     	bl	0x100000d00 <_strtoul+0x100000d00>
100000cdc:     	stur	wzr, [x29, #-0x4]
100000ce0:     	b	0x100000ce4 <_main+0x210>
100000ce4:     	ldur	w0, [x29, #-0x4]
100000ce8:     	ldp	x29, x30, [sp, #0xa0]
100000cec:     	add	sp, sp, #0xb0
100000cf0:     	ret

Disassembly of section __TEXT,__stubs:

0000000100000cf4 <__stubs>:
100000cf4:     	adrp	x16, 0x100004000 <_strtoul+0x100004000>
100000cf8:     	ldr	x16, [x16]
100000cfc:     	br	x16
100000d00:     	adrp	x16, 0x100004000 <_strtoul+0x100004000>
100000d04:     	ldr	x16, [x16, #0x8]
100000d08:     	br	x16
100000d0c:     	adrp	x16, 0x100004000 <_strtoul+0x100004000>
100000d10:     	ldr	x16, [x16, #0x10]
100000d14:     	br	x16
