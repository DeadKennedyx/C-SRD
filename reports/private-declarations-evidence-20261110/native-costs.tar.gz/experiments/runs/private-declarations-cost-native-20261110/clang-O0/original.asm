
/Users/admin/C-SRD/experiments/runs/private-declarations-cost-native-20261110/clang-O0/original:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001000004f8 <_region_pipeline>:
1000004f8:     	sub	sp, sp, #0x40
1000004fc:     	stp	x29, x30, [sp, #0x30]
100000500:     	add	x29, sp, #0x30
100000504:     	stur	x0, [x29, #-0x10]
100000508:     	stur	w1, [x29, #-0x14]
10000050c:     	str	w2, [sp, #0x18]
100000510:     	ldur	x8, [x29, #-0x10]
100000514:     	ldr	w8, [x8]
100000518:     	str	w8, [sp, #0x14]
10000051c:     	ldur	w8, [x29, #-0x14]
100000520:     	ldr	w9, [sp, #0x14]
100000524:     	add	w8, w8, w9
100000528:     	str	w8, [sp, #0x10]
10000052c:     	ldr	w9, [sp, #0x10]
100000530:     	mov	w8, #0x3                ; =3
100000534:     	mul	w8, w8, w9
100000538:     	add	w8, w8, #0xb
10000053c:     	str	w8, [sp, #0xc]
100000540:     	ldr	w8, [sp, #0xc]
100000544:     	ldr	w9, [sp, #0x14]
100000548:     	subs	w8, w8, w9
10000054c:     	stur	w8, [x29, #-0x14]
100000550:     	ldr	w0, [sp, #0x10]
100000554:     	bl	0x1000006e4 <_record_event>
100000558:     	ldr	w8, [sp, #0x18]
10000055c:     	tbnz	w8, #0x1f, 0x100000564 <_region_pipeline+0x6c>
100000560:     	b	0x100000570 <_region_pipeline+0x78>
100000564:     	ldur	w8, [x29, #-0x14]
100000568:     	stur	w8, [x29, #-0x4]
10000056c:     	b	0x100000628 <_region_pipeline+0x130>
100000570:     	b	0x100000574 <_region_pipeline+0x7c>
100000574:     	ldr	w8, [sp, #0x18]
100000578:     	subs	w9, w8, #0x1
10000057c:     	str	w9, [sp, #0x18]
100000580:     	subs	w8, w8, #0x0
100000584:     	b.gt	0x10000058c <_region_pipeline+0x94>
100000588:     	b	0x10000061c <_region_pipeline+0x124>
10000058c:     	ldur	w0, [x29, #-0x14]
100000590:     	bl	0x100000710 <_next_value>
100000594:     	str	w0, [sp, #0x14]
100000598:     	ldur	w8, [x29, #-0x14]
10000059c:     	ldr	w9, [sp, #0x14]
1000005a0:     	add	w8, w8, w9
1000005a4:     	stur	w8, [x29, #-0x14]
1000005a8:     	ldr	w8, [sp, #0xc]
1000005ac:     	ldr	w10, [sp, #0x14]
1000005b0:     	mov	w9, #0x5                ; =5
1000005b4:     	mul	w9, w9, w10
1000005b8:     	add	w8, w8, w9
1000005bc:     	str	w8, [sp, #0x8]
1000005c0:     	ldr	w8, [sp, #0x8]
1000005c4:     	ldr	w9, [sp, #0x14]
1000005c8:     	subs	w8, w8, w9
1000005cc:     	str	w8, [sp, #0x4]
1000005d0:     	ldr	w8, [sp, #0x4]
1000005d4:     	ldr	w9, [sp, #0x10]
1000005d8:     	add	w8, w8, w9
1000005dc:     	str	w8, [sp, #0xc]
1000005e0:     	ldr	w0, [sp, #0x8]
1000005e4:     	bl	0x1000006e4 <_record_event>
1000005e8:     	ldr	w8, [sp, #0x8]
1000005ec:     	add	w8, w8, #0x7
1000005f0:     	str	w8, [sp, #0x8]
1000005f4:     	ldr	w8, [sp, #0x8]
1000005f8:     	ldur	x9, [x29, #-0x10]
1000005fc:     	str	w8, [x9]
100000600:     	ldur	w8, [x29, #-0x14]
100000604:     	ldr	w9, [sp, #0xc]
100000608:     	add	w8, w8, w9
10000060c:     	stur	w8, [x29, #-0x14]
100000610:     	ldr	w0, [sp, #0x14]
100000614:     	bl	0x1000006e4 <_record_event>
100000618:     	b	0x100000574 <_region_pipeline+0x7c>
10000061c:     	ldur	w8, [x29, #-0x14]
100000620:     	stur	w8, [x29, #-0x4]
100000624:     	b	0x100000628 <_region_pipeline+0x130>
100000628:     	ldur	w0, [x29, #-0x4]
10000062c:     	ldp	x29, x30, [sp, #0x30]
100000630:     	add	sp, sp, #0x40
100000634:     	ret

0000000100000638 <_region_outputs>:
100000638:     	sub	sp, sp, #0x30
10000063c:     	stp	x29, x30, [sp, #0x20]
100000640:     	add	x29, sp, #0x20
100000644:     	stur	x0, [x29, #-0x8]
100000648:     	stur	w1, [x29, #-0xc]
10000064c:     	str	w2, [sp, #0x10]
100000650:     	mov	w8, #0x11               ; =17
100000654:     	str	w8, [sp, #0xc]
100000658:     	ldr	w8, [sp, #0xc]
10000065c:     	ldur	w9, [x29, #-0xc]
100000660:     	add	w8, w8, w9
100000664:     	str	w8, [sp, #0x8]
100000668:     	ldr	w9, [sp, #0x8]
10000066c:     	mov	w8, #0x3                ; =3
100000670:     	mul	w8, w8, w9
100000674:     	ldr	w9, [sp, #0x10]
100000678:     	add	w8, w8, w9
10000067c:     	stur	w8, [x29, #-0xc]
100000680:     	ldur	w8, [x29, #-0xc]
100000684:     	ldr	w9, [sp, #0xc]
100000688:     	subs	w8, w8, w9
10000068c:     	str	w8, [sp, #0x10]
100000690:     	ldur	w0, [x29, #-0xc]
100000694:     	bl	0x1000006e4 <_record_event>
100000698:     	ldur	w8, [x29, #-0xc]
10000069c:     	add	w8, w8, #0x7
1000006a0:     	str	w8, [sp, #0x4]
1000006a4:     	ldr	w8, [sp, #0x4]
1000006a8:     	ldur	x9, [x29, #-0x8]
1000006ac:     	str	w8, [x9, #0x8]
1000006b0:     	ldr	w8, [sp, #0x10]
1000006b4:     	ldur	x9, [x29, #-0x8]
1000006b8:     	str	w8, [x9]
1000006bc:     	ldr	w8, [sp, #0xc]
1000006c0:     	ldur	x9, [x29, #-0x8]
1000006c4:     	str	w8, [x9, #0x4]
1000006c8:     	ldur	w8, [x29, #-0xc]
1000006cc:     	ldr	w9, [sp, #0x10]
1000006d0:     	subs	w8, w8, w9
1000006d4:     	cset	w0, eq
1000006d8:     	ldp	x29, x30, [sp, #0x20]
1000006dc:     	add	sp, sp, #0x30
1000006e0:     	ret

00000001000006e4 <_record_event>:
1000006e4:     	sub	sp, sp, #0x10
1000006e8:     	str	w0, [sp, #0xc]
1000006ec:     	adrp	x9, 0x100008000 <_event_hash>
1000006f0:     	ldr	w8, [x9]
1000006f4:     	mov	w10, #0x21              ; =33
1000006f8:     	mul	w8, w8, w10
1000006fc:     	ldr	w10, [sp, #0xc]
100000700:     	eor	w8, w8, w10
100000704:     	str	w8, [x9]
100000708:     	add	sp, sp, #0x10
10000070c:     	ret

0000000100000710 <_next_value>:
100000710:     	sub	sp, sp, #0x20
100000714:     	stp	x29, x30, [sp, #0x10]
100000718:     	add	x29, sp, #0x10
10000071c:     	stur	w0, [x29, #-0x4]
100000720:     	ldur	w0, [x29, #-0x4]
100000724:     	bl	0x1000006e4 <_record_event>
100000728:     	ldur	w10, [x29, #-0x4]
10000072c:     	adrp	x9, 0x100008000 <_event_hash>
100000730:     	add	x9, x9, #0x4
100000734:     	ldr	w8, [x9, #0x4]
100000738:     	add	w8, w8, w10
10000073c:     	str	w8, [x9, #0x4]
100000740:     	ldur	w8, [x29, #-0x4]
100000744:     	ldr	w9, [x9, #0x4]
100000748:     	add	w0, w8, w9
10000074c:     	ldp	x29, x30, [sp, #0x10]
100000750:     	add	sp, sp, #0x20
100000754:     	ret

0000000100000758 <_main>:
100000758:     	sub	sp, sp, #0xb0
10000075c:     	stp	x29, x30, [sp, #0xa0]
100000760:     	add	x29, sp, #0xa0
100000764:     	stur	wzr, [x29, #-0x4]
100000768:     	stur	w0, [x29, #-0x8]
10000076c:     	stur	x1, [x29, #-0x10]
100000770:     	ldur	w8, [x29, #-0x8]
100000774:     	subs	w8, w8, #0x3
100000778:     	b.ne	0x100000780 <_main+0x28>
10000077c:     	b	0x10000078c <_main+0x34>
100000780:     	mov	w8, #0x2                ; =2
100000784:     	stur	w8, [x29, #-0x4]
100000788:     	b	0x100000968 <_main+0x210>
10000078c:     	ldur	x8, [x29, #-0x10]
100000790:     	ldr	x0, [x8, #0x8]
100000794:     	mov	x1, #0x0                ; =0
100000798:     	str	x1, [sp, #0x40]
10000079c:     	mov	w2, #0xa                ; =10
1000007a0:     	str	w2, [sp, #0x4c]
1000007a4:     	bl	0x100000990 <_strtoul+0x100000990>
1000007a8:     	ldr	x1, [sp, #0x40]
1000007ac:     	ldr	w2, [sp, #0x4c]
1000007b0:     	stur	x0, [x29, #-0x18]
1000007b4:     	ldur	x8, [x29, #-0x10]
1000007b8:     	ldr	x0, [x8, #0x10]
1000007bc:     	bl	0x100000990 <_strtoul+0x100000990>
1000007c0:     	mov	x8, x0
1000007c4:     	stur	w8, [x29, #-0x1c]
1000007c8:     	stur	wzr, [x29, #-0x20]
1000007cc:     	mov	w0, #0x6                ; =6
1000007d0:     	sub	x1, x29, #0x30
1000007d4:     	bl	0x100000978 <_strtoul+0x100000978>
1000007d8:     	cbnz	w0, 0x1000007e0 <_main+0x88>
1000007dc:     	b	0x1000007ec <_main+0x94>
1000007e0:     	mov	w8, #0x2                ; =2
1000007e4:     	stur	w8, [x29, #-0x4]
1000007e8:     	b	0x100000968 <_main+0x210>
1000007ec:     	stur	xzr, [x29, #-0x48]
1000007f0:     	b	0x1000007f4 <_main+0x9c>
1000007f4:     	ldur	x8, [x29, #-0x48]
1000007f8:     	ldur	x9, [x29, #-0x18]
1000007fc:     	subs	x8, x8, x9
100000800:     	b.lo	0x100000808 <_main+0xb0>
100000804:     	b	0x1000008a4 <_main+0x14c>
100000808:     	ldur	w9, [x29, #-0x1c]
10000080c:     	ldur	w8, [x29, #-0x1c]
100000810:     	eor	w8, w8, w9, lsl #13
100000814:     	stur	w8, [x29, #-0x1c]
100000818:     	ldur	w9, [x29, #-0x1c]
10000081c:     	ldur	w8, [x29, #-0x1c]
100000820:     	eor	w8, w8, w9, lsr #17
100000824:     	stur	w8, [x29, #-0x1c]
100000828:     	ldur	w9, [x29, #-0x1c]
10000082c:     	ldur	w8, [x29, #-0x1c]
100000830:     	eor	w8, w8, w9, lsl #5
100000834:     	stur	w8, [x29, #-0x1c]
100000838:     	ldur	w1, [x29, #-0x1c]
10000083c:     	ldur	x8, [x29, #-0x48]
100000840:     	mov	x10, #0xa               ; =10
100000844:     	udiv	x9, x8, x10
100000848:     	mul	x9, x9, x10
10000084c:     	subs	x8, x8, x9
100000850:     	subs	w2, w8, #0x1
100000854:     	adrp	x0, 0x100008000 <_event_hash>
100000858:     	add	x0, x0, #0x4
10000085c:     	str	x0, [sp, #0x38]
100000860:     	bl	0x1000004f8 <_region_pipeline>
100000864:     	mov	x9, x0
100000868:     	ldr	x0, [sp, #0x38]
10000086c:     	ldur	w8, [x29, #-0x20]
100000870:     	add	w8, w8, w9
100000874:     	stur	w8, [x29, #-0x20]
100000878:     	ldur	w1, [x29, #-0x1c]
10000087c:     	ldur	w2, [x29, #-0x20]
100000880:     	bl	0x100000638 <_region_outputs>
100000884:     	ldur	w8, [x29, #-0x20]
100000888:     	add	w8, w8, w0
10000088c:     	stur	w8, [x29, #-0x20]
100000890:     	b	0x100000894 <_main+0x13c>
100000894:     	ldur	x8, [x29, #-0x48]
100000898:     	add	x8, x8, #0x1
10000089c:     	stur	x8, [x29, #-0x48]
1000008a0:     	b	0x1000007f4 <_main+0x9c>
1000008a4:     	mov	w0, #0x6                ; =6
1000008a8:     	sub	x1, x29, #0x40
1000008ac:     	bl	0x100000978 <_strtoul+0x100000978>
1000008b0:     	cbnz	w0, 0x1000008b8 <_main+0x160>
1000008b4:     	b	0x1000008c4 <_main+0x16c>
1000008b8:     	mov	w8, #0x2                ; =2
1000008bc:     	stur	w8, [x29, #-0x4]
1000008c0:     	b	0x100000968 <_main+0x210>
1000008c4:     	ldur	x8, [x29, #-0x40]
1000008c8:     	ldur	x9, [x29, #-0x30]
1000008cc:     	subs	x8, x8, x9
1000008d0:     	scvtf	d2, x8
1000008d4:     	ldur	x8, [x29, #-0x38]
1000008d8:     	ldur	x9, [x29, #-0x28]
1000008dc:     	subs	x8, x8, x9
1000008e0:     	scvtf	d0, x8
1000008e4:     	mov	x8, #0xd695             ; =54933
1000008e8:     	movk	x8, #0xe826, lsl #16
1000008ec:     	movk	x8, #0x2e0b, lsl #32
1000008f0:     	movk	x8, #0x3e11, lsl #48
1000008f4:     	fmov	d1, x8
1000008f8:     	fmadd	d0, d0, d1, d2
1000008fc:     	str	d0, [sp, #0x50]
100000900:     	ldr	d0, [sp, #0x50]
100000904:     	ldur	w8, [x29, #-0x20]
100000908:     	mov	x13, x8
10000090c:     	adrp	x9, 0x100008000 <_event_hash>
100000910:     	adrp	x8, 0x100008000 <_event_hash>
100000914:     	add	x8, x8, #0x4
100000918:     	ldr	w9, [x9, #0x4]
10000091c:     	mov	x12, x9
100000920:     	ldr	w9, [x8, #0x4]
100000924:     	mov	x11, x9
100000928:     	ldr	w8, [x8, #0x8]
10000092c:     	mov	x10, x8
100000930:     	adrp	x8, 0x100008000 <_event_hash>
100000934:     	ldr	w8, [x8]
100000938:     	mov	x9, sp
10000093c:     	str	d0, [x9]
100000940:     	str	x13, [x9, #0x8]
100000944:     	str	x12, [x9, #0x10]
100000948:     	str	x11, [x9, #0x18]
10000094c:     	str	x10, [x9, #0x20]
100000950:     	str	x8, [x9, #0x28]
100000954:     	adrp	x0, 0x100000000 <_strtoul+0x100000000>
100000958:     	add	x0, x0, #0x99c
10000095c:     	bl	0x100000984 <_strtoul+0x100000984>
100000960:     	stur	wzr, [x29, #-0x4]
100000964:     	b	0x100000968 <_main+0x210>
100000968:     	ldur	w0, [x29, #-0x4]
10000096c:     	ldp	x29, x30, [sp, #0xa0]
100000970:     	add	sp, sp, #0xb0
100000974:     	ret

Disassembly of section __TEXT,__stubs:

0000000100000978 <__stubs>:
100000978:     	adrp	x16, 0x100004000 <_strtoul+0x100004000>
10000097c:     	ldr	x16, [x16]
100000980:     	br	x16
100000984:     	adrp	x16, 0x100004000 <_strtoul+0x100004000>
100000988:     	ldr	x16, [x16, #0x8]
10000098c:     	br	x16
100000990:     	adrp	x16, 0x100004000 <_strtoul+0x100004000>
100000994:     	ldr	x16, [x16, #0x10]
100000998:     	br	x16
