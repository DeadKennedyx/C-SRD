
/Users/admin/C-SRD/experiments/runs/private-declarations-cost-native-20261110/clang-O0/identity:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001000004f8 <_region_pipeline>:
1000004f8:     	sub	sp, sp, #0x70
1000004fc:     	stp	x29, x30, [sp, #0x60]
100000500:     	add	x29, sp, #0x60
100000504:     	stur	x0, [x29, #-0x10]
100000508:     	stur	w1, [x29, #-0x14]
10000050c:     	stur	w2, [x29, #-0x18]
100000510:     	ldur	x8, [x29, #-0x10]
100000514:     	ldr	w8, [x8]
100000518:     	stur	w8, [x29, #-0x1c]
10000051c:     	ldur	w8, [x29, #-0x14]
100000520:     	stur	w8, [x29, #-0x20]
100000524:     	ldur	w8, [x29, #-0x1c]
100000528:     	stur	w8, [x29, #-0x24]
10000052c:     	ldur	w8, [x29, #-0x20]
100000530:     	ldur	w9, [x29, #-0x24]
100000534:     	add	w8, w8, w9
100000538:     	stur	w8, [x29, #-0x28]
10000053c:     	ldur	w9, [x29, #-0x28]
100000540:     	mov	w8, #0x3                ; =3
100000544:     	mul	w8, w8, w9
100000548:     	add	w8, w8, #0xb
10000054c:     	stur	w8, [x29, #-0x2c]
100000550:     	ldur	w8, [x29, #-0x2c]
100000554:     	ldur	w9, [x29, #-0x24]
100000558:     	subs	w8, w8, w9
10000055c:     	stur	w8, [x29, #-0x20]
100000560:     	ldur	w8, [x29, #-0x20]
100000564:     	stur	w8, [x29, #-0x14]
100000568:     	ldur	w8, [x29, #-0x28]
10000056c:     	str	w8, [sp, #0x30]
100000570:     	ldur	w8, [x29, #-0x2c]
100000574:     	str	w8, [sp, #0x2c]
100000578:     	ldr	w0, [sp, #0x30]
10000057c:     	bl	0x1000007b4 <_record_event>
100000580:     	ldur	w8, [x29, #-0x18]
100000584:     	tbnz	w8, #0x1f, 0x10000058c <_region_pipeline+0x94>
100000588:     	b	0x100000598 <_region_pipeline+0xa0>
10000058c:     	ldur	w8, [x29, #-0x14]
100000590:     	stur	w8, [x29, #-0x4]
100000594:     	b	0x1000006b8 <_region_pipeline+0x1c0>
100000598:     	b	0x10000059c <_region_pipeline+0xa4>
10000059c:     	ldur	w8, [x29, #-0x18]
1000005a0:     	subs	w9, w8, #0x1
1000005a4:     	stur	w9, [x29, #-0x18]
1000005a8:     	subs	w8, w8, #0x0
1000005ac:     	b.gt	0x1000005b4 <_region_pipeline+0xbc>
1000005b0:     	b	0x1000006ac <_region_pipeline+0x1b4>
1000005b4:     	ldur	w0, [x29, #-0x14]
1000005b8:     	bl	0x1000007e0 <_next_value>
1000005bc:     	stur	w0, [x29, #-0x1c]
1000005c0:     	ldur	w8, [x29, #-0x14]
1000005c4:     	str	w8, [sp, #0x28]
1000005c8:     	ldur	w8, [x29, #-0x1c]
1000005cc:     	str	w8, [sp, #0x24]
1000005d0:     	ldr	w8, [sp, #0x2c]
1000005d4:     	str	w8, [sp, #0x20]
1000005d8:     	ldr	w8, [sp, #0x30]
1000005dc:     	str	w8, [sp, #0x1c]
1000005e0:     	ldr	w8, [sp, #0x28]
1000005e4:     	ldr	w9, [sp, #0x24]
1000005e8:     	add	w8, w8, w9
1000005ec:     	str	w8, [sp, #0x28]
1000005f0:     	ldr	w8, [sp, #0x20]
1000005f4:     	ldr	w10, [sp, #0x24]
1000005f8:     	mov	w9, #0x5                ; =5
1000005fc:     	mul	w9, w9, w10
100000600:     	add	w8, w8, w9
100000604:     	str	w8, [sp, #0x18]
100000608:     	ldr	w8, [sp, #0x18]
10000060c:     	ldr	w9, [sp, #0x24]
100000610:     	subs	w8, w8, w9
100000614:     	str	w8, [sp, #0x14]
100000618:     	ldr	w8, [sp, #0x14]
10000061c:     	ldr	w9, [sp, #0x1c]
100000620:     	add	w8, w8, w9
100000624:     	str	w8, [sp, #0x20]
100000628:     	ldr	w8, [sp, #0x28]
10000062c:     	stur	w8, [x29, #-0x14]
100000630:     	ldr	w8, [sp, #0x20]
100000634:     	str	w8, [sp, #0x2c]
100000638:     	ldr	w8, [sp, #0x18]
10000063c:     	str	w8, [sp, #0x10]
100000640:     	ldr	w8, [sp, #0x14]
100000644:     	str	w8, [sp, #0xc]
100000648:     	ldr	w0, [sp, #0x10]
10000064c:     	bl	0x1000007b4 <_record_event>
100000650:     	ldr	w8, [sp, #0x10]
100000654:     	str	w8, [sp, #0x8]
100000658:     	ldr	w8, [sp, #0x8]
10000065c:     	add	w8, w8, #0x7
100000660:     	str	w8, [sp, #0x8]
100000664:     	ldr	w8, [sp, #0x8]
100000668:     	str	w8, [sp, #0x10]
10000066c:     	ldr	w8, [sp, #0x10]
100000670:     	ldur	x9, [x29, #-0x10]
100000674:     	str	w8, [x9]
100000678:     	ldur	w8, [x29, #-0x14]
10000067c:     	str	w8, [sp, #0x4]
100000680:     	ldr	w8, [sp, #0x2c]
100000684:     	str	w8, [sp]
100000688:     	ldr	w8, [sp, #0x4]
10000068c:     	ldr	w9, [sp]
100000690:     	add	w8, w8, w9
100000694:     	str	w8, [sp, #0x4]
100000698:     	ldr	w8, [sp, #0x4]
10000069c:     	stur	w8, [x29, #-0x14]
1000006a0:     	ldur	w0, [x29, #-0x1c]
1000006a4:     	bl	0x1000007b4 <_record_event>
1000006a8:     	b	0x10000059c <_region_pipeline+0xa4>
1000006ac:     	ldur	w8, [x29, #-0x14]
1000006b0:     	stur	w8, [x29, #-0x4]
1000006b4:     	b	0x1000006b8 <_region_pipeline+0x1c0>
1000006b8:     	ldur	w0, [x29, #-0x4]
1000006bc:     	ldp	x29, x30, [sp, #0x60]
1000006c0:     	add	sp, sp, #0x70
1000006c4:     	ret

00000001000006c8 <_region_outputs>:
1000006c8:     	sub	sp, sp, #0x50
1000006cc:     	stp	x29, x30, [sp, #0x40]
1000006d0:     	add	x29, sp, #0x40
1000006d4:     	stur	x0, [x29, #-0x8]
1000006d8:     	stur	w1, [x29, #-0xc]
1000006dc:     	stur	w2, [x29, #-0x10]
1000006e0:     	ldur	w8, [x29, #-0xc]
1000006e4:     	stur	w8, [x29, #-0x14]
1000006e8:     	ldur	w8, [x29, #-0x10]
1000006ec:     	stur	w8, [x29, #-0x18]
1000006f0:     	mov	w8, #0x11               ; =17
1000006f4:     	stur	w8, [x29, #-0x1c]
1000006f8:     	ldur	w8, [x29, #-0x1c]
1000006fc:     	ldur	w9, [x29, #-0x14]
100000700:     	add	w8, w8, w9
100000704:     	str	w8, [sp, #0x20]
100000708:     	ldr	w9, [sp, #0x20]
10000070c:     	mov	w8, #0x3                ; =3
100000710:     	mul	w8, w8, w9
100000714:     	ldur	w9, [x29, #-0x18]
100000718:     	add	w8, w8, w9
10000071c:     	stur	w8, [x29, #-0x14]
100000720:     	ldur	w8, [x29, #-0x14]
100000724:     	ldur	w9, [x29, #-0x1c]
100000728:     	subs	w8, w8, w9
10000072c:     	stur	w8, [x29, #-0x18]
100000730:     	ldur	w8, [x29, #-0x14]
100000734:     	stur	w8, [x29, #-0xc]
100000738:     	ldur	w8, [x29, #-0x18]
10000073c:     	stur	w8, [x29, #-0x10]
100000740:     	ldur	w8, [x29, #-0x1c]
100000744:     	str	w8, [sp, #0x1c]
100000748:     	ldr	w8, [sp, #0x20]
10000074c:     	str	w8, [sp, #0x18]
100000750:     	ldur	w0, [x29, #-0xc]
100000754:     	bl	0x1000007b4 <_record_event>
100000758:     	ldur	w8, [x29, #-0xc]
10000075c:     	str	w8, [sp, #0x14]
100000760:     	ldr	w8, [sp, #0x14]
100000764:     	add	w8, w8, #0x7
100000768:     	str	w8, [sp, #0x10]
10000076c:     	ldr	w8, [sp, #0x10]
100000770:     	str	w8, [sp, #0xc]
100000774:     	ldr	w8, [sp, #0xc]
100000778:     	ldur	x9, [x29, #-0x8]
10000077c:     	str	w8, [x9, #0x8]
100000780:     	ldur	w8, [x29, #-0x10]
100000784:     	ldur	x9, [x29, #-0x8]
100000788:     	str	w8, [x9]
10000078c:     	ldr	w8, [sp, #0x1c]
100000790:     	ldur	x9, [x29, #-0x8]
100000794:     	str	w8, [x9, #0x4]
100000798:     	ldur	w8, [x29, #-0xc]
10000079c:     	ldur	w9, [x29, #-0x10]
1000007a0:     	subs	w8, w8, w9
1000007a4:     	cset	w0, eq
1000007a8:     	ldp	x29, x30, [sp, #0x40]
1000007ac:     	add	sp, sp, #0x50
1000007b0:     	ret

00000001000007b4 <_record_event>:
1000007b4:     	sub	sp, sp, #0x10
1000007b8:     	str	w0, [sp, #0xc]
1000007bc:     	adrp	x9, 0x100008000 <_event_hash>
1000007c0:     	ldr	w8, [x9]
1000007c4:     	mov	w10, #0x21              ; =33
1000007c8:     	mul	w8, w8, w10
1000007cc:     	ldr	w10, [sp, #0xc]
1000007d0:     	eor	w8, w8, w10
1000007d4:     	str	w8, [x9]
1000007d8:     	add	sp, sp, #0x10
1000007dc:     	ret

00000001000007e0 <_next_value>:
1000007e0:     	sub	sp, sp, #0x20
1000007e4:     	stp	x29, x30, [sp, #0x10]
1000007e8:     	add	x29, sp, #0x10
1000007ec:     	stur	w0, [x29, #-0x4]
1000007f0:     	ldur	w0, [x29, #-0x4]
1000007f4:     	bl	0x1000007b4 <_record_event>
1000007f8:     	ldur	w10, [x29, #-0x4]
1000007fc:     	adrp	x9, 0x100008000 <_event_hash>
100000800:     	add	x9, x9, #0x4
100000804:     	ldr	w8, [x9, #0x4]
100000808:     	add	w8, w8, w10
10000080c:     	str	w8, [x9, #0x4]
100000810:     	ldur	w8, [x29, #-0x4]
100000814:     	ldr	w9, [x9, #0x4]
100000818:     	add	w0, w8, w9
10000081c:     	ldp	x29, x30, [sp, #0x10]
100000820:     	add	sp, sp, #0x20
100000824:     	ret

0000000100000828 <_main>:
100000828:     	sub	sp, sp, #0xb0
10000082c:     	stp	x29, x30, [sp, #0xa0]
100000830:     	add	x29, sp, #0xa0
100000834:     	stur	wzr, [x29, #-0x4]
100000838:     	stur	w0, [x29, #-0x8]
10000083c:     	stur	x1, [x29, #-0x10]
100000840:     	ldur	w8, [x29, #-0x8]
100000844:     	subs	w8, w8, #0x3
100000848:     	b.ne	0x100000850 <_main+0x28>
10000084c:     	b	0x10000085c <_main+0x34>
100000850:     	mov	w8, #0x2                ; =2
100000854:     	stur	w8, [x29, #-0x4]
100000858:     	b	0x100000a38 <_main+0x210>
10000085c:     	ldur	x8, [x29, #-0x10]
100000860:     	ldr	x0, [x8, #0x8]
100000864:     	mov	x1, #0x0                ; =0
100000868:     	str	x1, [sp, #0x40]
10000086c:     	mov	w2, #0xa                ; =10
100000870:     	str	w2, [sp, #0x4c]
100000874:     	bl	0x100000a60 <_strtoul+0x100000a60>
100000878:     	ldr	x1, [sp, #0x40]
10000087c:     	ldr	w2, [sp, #0x4c]
100000880:     	stur	x0, [x29, #-0x18]
100000884:     	ldur	x8, [x29, #-0x10]
100000888:     	ldr	x0, [x8, #0x10]
10000088c:     	bl	0x100000a60 <_strtoul+0x100000a60>
100000890:     	mov	x8, x0
100000894:     	stur	w8, [x29, #-0x1c]
100000898:     	stur	wzr, [x29, #-0x20]
10000089c:     	mov	w0, #0x6                ; =6
1000008a0:     	sub	x1, x29, #0x30
1000008a4:     	bl	0x100000a48 <_strtoul+0x100000a48>
1000008a8:     	cbnz	w0, 0x1000008b0 <_main+0x88>
1000008ac:     	b	0x1000008bc <_main+0x94>
1000008b0:     	mov	w8, #0x2                ; =2
1000008b4:     	stur	w8, [x29, #-0x4]
1000008b8:     	b	0x100000a38 <_main+0x210>
1000008bc:     	stur	xzr, [x29, #-0x48]
1000008c0:     	b	0x1000008c4 <_main+0x9c>
1000008c4:     	ldur	x8, [x29, #-0x48]
1000008c8:     	ldur	x9, [x29, #-0x18]
1000008cc:     	subs	x8, x8, x9
1000008d0:     	b.lo	0x1000008d8 <_main+0xb0>
1000008d4:     	b	0x100000974 <_main+0x14c>
1000008d8:     	ldur	w9, [x29, #-0x1c]
1000008dc:     	ldur	w8, [x29, #-0x1c]
1000008e0:     	eor	w8, w8, w9, lsl #13
1000008e4:     	stur	w8, [x29, #-0x1c]
1000008e8:     	ldur	w9, [x29, #-0x1c]
1000008ec:     	ldur	w8, [x29, #-0x1c]
1000008f0:     	eor	w8, w8, w9, lsr #17
1000008f4:     	stur	w8, [x29, #-0x1c]
1000008f8:     	ldur	w9, [x29, #-0x1c]
1000008fc:     	ldur	w8, [x29, #-0x1c]
100000900:     	eor	w8, w8, w9, lsl #5
100000904:     	stur	w8, [x29, #-0x1c]
100000908:     	ldur	w1, [x29, #-0x1c]
10000090c:     	ldur	x8, [x29, #-0x48]
100000910:     	mov	x10, #0xa               ; =10
100000914:     	udiv	x9, x8, x10
100000918:     	mul	x9, x9, x10
10000091c:     	subs	x8, x8, x9
100000920:     	subs	w2, w8, #0x1
100000924:     	adrp	x0, 0x100008000 <_event_hash>
100000928:     	add	x0, x0, #0x4
10000092c:     	str	x0, [sp, #0x38]
100000930:     	bl	0x1000004f8 <_region_pipeline>
100000934:     	mov	x9, x0
100000938:     	ldr	x0, [sp, #0x38]
10000093c:     	ldur	w8, [x29, #-0x20]
100000940:     	add	w8, w8, w9
100000944:     	stur	w8, [x29, #-0x20]
100000948:     	ldur	w1, [x29, #-0x1c]
10000094c:     	ldur	w2, [x29, #-0x20]
100000950:     	bl	0x1000006c8 <_region_outputs>
100000954:     	ldur	w8, [x29, #-0x20]
100000958:     	add	w8, w8, w0
10000095c:     	stur	w8, [x29, #-0x20]
100000960:     	b	0x100000964 <_main+0x13c>
100000964:     	ldur	x8, [x29, #-0x48]
100000968:     	add	x8, x8, #0x1
10000096c:     	stur	x8, [x29, #-0x48]
100000970:     	b	0x1000008c4 <_main+0x9c>
100000974:     	mov	w0, #0x6                ; =6
100000978:     	sub	x1, x29, #0x40
10000097c:     	bl	0x100000a48 <_strtoul+0x100000a48>
100000980:     	cbnz	w0, 0x100000988 <_main+0x160>
100000984:     	b	0x100000994 <_main+0x16c>
100000988:     	mov	w8, #0x2                ; =2
10000098c:     	stur	w8, [x29, #-0x4]
100000990:     	b	0x100000a38 <_main+0x210>
100000994:     	ldur	x8, [x29, #-0x40]
100000998:     	ldur	x9, [x29, #-0x30]
10000099c:     	subs	x8, x8, x9
1000009a0:     	scvtf	d2, x8
1000009a4:     	ldur	x8, [x29, #-0x38]
1000009a8:     	ldur	x9, [x29, #-0x28]
1000009ac:     	subs	x8, x8, x9
1000009b0:     	scvtf	d0, x8
1000009b4:     	mov	x8, #0xd695             ; =54933
1000009b8:     	movk	x8, #0xe826, lsl #16
1000009bc:     	movk	x8, #0x2e0b, lsl #32
1000009c0:     	movk	x8, #0x3e11, lsl #48
1000009c4:     	fmov	d1, x8
1000009c8:     	fmadd	d0, d0, d1, d2
1000009cc:     	str	d0, [sp, #0x50]
1000009d0:     	ldr	d0, [sp, #0x50]
1000009d4:     	ldur	w8, [x29, #-0x20]
1000009d8:     	mov	x13, x8
1000009dc:     	adrp	x9, 0x100008000 <_event_hash>
1000009e0:     	adrp	x8, 0x100008000 <_event_hash>
1000009e4:     	add	x8, x8, #0x4
1000009e8:     	ldr	w9, [x9, #0x4]
1000009ec:     	mov	x12, x9
1000009f0:     	ldr	w9, [x8, #0x4]
1000009f4:     	mov	x11, x9
1000009f8:     	ldr	w8, [x8, #0x8]
1000009fc:     	mov	x10, x8
100000a00:     	adrp	x8, 0x100008000 <_event_hash>
100000a04:     	ldr	w8, [x8]
100000a08:     	mov	x9, sp
100000a0c:     	str	d0, [x9]
100000a10:     	str	x13, [x9, #0x8]
100000a14:     	str	x12, [x9, #0x10]
100000a18:     	str	x11, [x9, #0x18]
100000a1c:     	str	x10, [x9, #0x20]
100000a20:     	str	x8, [x9, #0x28]
100000a24:     	adrp	x0, 0x100000000 <_strtoul+0x100000000>
100000a28:     	add	x0, x0, #0xa6c
100000a2c:     	bl	0x100000a54 <_strtoul+0x100000a54>
100000a30:     	stur	wzr, [x29, #-0x4]
100000a34:     	b	0x100000a38 <_main+0x210>
100000a38:     	ldur	w0, [x29, #-0x4]
100000a3c:     	ldp	x29, x30, [sp, #0xa0]
100000a40:     	add	sp, sp, #0xb0
100000a44:     	ret

Disassembly of section __TEXT,__stubs:

0000000100000a48 <__stubs>:
100000a48:     	adrp	x16, 0x100004000 <_strtoul+0x100004000>
100000a4c:     	ldr	x16, [x16]
100000a50:     	br	x16
100000a54:     	adrp	x16, 0x100004000 <_strtoul+0x100004000>
100000a58:     	ldr	x16, [x16, #0x8]
100000a5c:     	br	x16
100000a60:     	adrp	x16, 0x100004000 <_strtoul+0x100004000>
100000a64:     	ldr	x16, [x16, #0x10]
100000a68:     	br	x16
