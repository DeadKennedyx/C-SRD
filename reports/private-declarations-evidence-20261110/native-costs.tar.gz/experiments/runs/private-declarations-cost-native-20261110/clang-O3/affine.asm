
/Users/admin/C-SRD/experiments/runs/private-declarations-cost-native-20261110/clang-O3/affine:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001000004f8 <_region_pipeline>:
1000004f8:     	stp	x28, x27, [sp, #-0x60]!
1000004fc:     	stp	x26, x25, [sp, #0x10]
100000500:     	stp	x24, x23, [sp, #0x20]
100000504:     	stp	x22, x21, [sp, #0x30]
100000508:     	stp	x20, x19, [sp, #0x40]
10000050c:     	stp	x29, x30, [sp, #0x50]
100000510:     	add	x29, sp, #0x50
100000514:     	mov	x21, x2
100000518:     	mov	x19, x0
10000051c:     	ldr	w8, [x0]
100000520:     	mov	w9, #0xcc3f             ; =52287
100000524:     	movk	w9, #0xdfc3, lsl #16
100000528:     	mul	w10, w8, w9
10000052c:     	madd	w9, w1, w9, w10
100000530:     	mov	w11, #0x5bcf            ; =23503
100000534:     	movk	w11, #0x8510, lsl #16
100000538:     	add	w24, w9, w11
10000053c:     	add	w9, w24, w24, lsl #1
100000540:     	sub	w9, w9, w10
100000544:     	mov	w10, #0x23bf            ; =9151
100000548:     	movk	w10, #0x7082, lsl #16
10000054c:     	mov	w11, #0x9ab8            ; =39608
100000550:     	movk	w11, #0xe760, lsl #16
100000554:     	madd	w20, w9, w10, w11
100000558:     	add	w22, w8, w1
10000055c:     	mov	x0, x22
100000560:     	bl	0x100000694 <_record_event>
100000564:     	cmp	w21, #0x1
100000568:     	b.lt	0x10000060c <_region_pipeline+0x114>
10000056c:     	mov	w23, #0xb211            ; =45585
100000570:     	movk	w23, #0xda25, lsl #16
100000574:     	mov	w8, #0x7ef1             ; =32497
100000578:     	movk	w8, #0x67ef, lsl #16
10000057c:     	mov	w9, #0xfa6d             ; =64109
100000580:     	movk	w9, #0x9145, lsl #16
100000584:     	mov	w10, #0x3738            ; =14136
100000588:     	movk	w10, #0xd7e0, lsl #16
10000058c:     	madd	w26, w24, w9, w10
100000590:     	mov	w9, #0x21f4             ; =8692
100000594:     	movk	w9, #0x6258, lsl #16
100000598:     	madd	w22, w22, w8, w9
10000059c:     	add	w25, w21, #0x1
1000005a0:     	mov	w28, #0x7ab5            ; =31413
1000005a4:     	movk	w28, #0x7ad, lsl #16
1000005a8:     	mov	w24, #0xde0c            ; =56844
1000005ac:     	movk	w24, #0x9da7, lsl #16
1000005b0:     	mov	x0, x20
1000005b4:     	bl	0x1000006ac <_next_value>
1000005b8:     	mov	x21, x0
1000005bc:     	madd	w8, w0, w28, w26
1000005c0:     	mov	w9, #0x810f             ; =33039
1000005c4:     	movk	w9, #0x9810, lsl #16
1000005c8:     	madd	w9, w0, w9, w22
1000005cc:     	add	w8, w8, w24
1000005d0:     	add	w26, w9, w8
1000005d4:     	add	w27, w0, w20
1000005d8:     	mov	w9, #0xe934             ; =59700
1000005dc:     	movk	w9, #0x7fb9, lsl #16
1000005e0:     	madd	w20, w8, w23, w9
1000005e4:     	mov	x0, x20
1000005e8:     	bl	0x100000694 <_record_event>
1000005ec:     	add	w8, w20, #0x7
1000005f0:     	str	w8, [x19]
1000005f4:     	madd	w20, w26, w23, w27
1000005f8:     	mov	x0, x21
1000005fc:     	bl	0x100000694 <_record_event>
100000600:     	sub	w25, w25, #0x1
100000604:     	cmp	w25, #0x1
100000608:     	b.hi	0x1000005b0 <_region_pipeline+0xb8>
10000060c:     	mov	x0, x20
100000610:     	ldp	x29, x30, [sp, #0x50]
100000614:     	ldp	x20, x19, [sp, #0x40]
100000618:     	ldp	x22, x21, [sp, #0x30]
10000061c:     	ldp	x24, x23, [sp, #0x20]
100000620:     	ldp	x26, x25, [sp, #0x10]
100000624:     	ldp	x28, x27, [sp], #0x60
100000628:     	ret

000000010000062c <_region_outputs>:
10000062c:     	stp	x22, x21, [sp, #-0x30]!
100000630:     	stp	x20, x19, [sp, #0x10]
100000634:     	stp	x29, x30, [sp, #0x20]
100000638:     	add	x29, sp, #0x20
10000063c:     	mov	x19, x0
100000640:     	mov	w8, #0xcf5b             ; =53083
100000644:     	movk	w8, #0x27d6, lsl #16
100000648:     	mov	w9, #0x6e11             ; =28177
10000064c:     	movk	w9, #0x7784, lsl #16
100000650:     	mul	w9, w1, w9
100000654:     	madd	w8, w2, w8, w9
100000658:     	mov	w9, #0xc8d3             ; =51411
10000065c:     	movk	w9, #0x1e1c, lsl #16
100000660:     	mul	w20, w8, w9
100000664:     	add	w21, w20, #0x22
100000668:     	add	w0, w20, #0x33
10000066c:     	bl	0x100000694 <_record_event>
100000670:     	add	w9, w20, #0x3a
100000674:     	mov	w8, #0x11               ; =17
100000678:     	str	w21, [x19]
10000067c:     	stp	w8, w9, [x19, #0x4]
100000680:     	mov	w0, #0x0                ; =0
100000684:     	ldp	x29, x30, [sp, #0x20]
100000688:     	ldp	x20, x19, [sp, #0x10]
10000068c:     	ldp	x22, x21, [sp], #0x30
100000690:     	ret

0000000100000694 <_record_event>:
100000694:     	adrp	x8, 0x100008000 <__MergedGlobals>
100000698:     	ldr	w9, [x8]
10000069c:     	add	w9, w9, w9, lsl #5
1000006a0:     	eor	w9, w9, w0
1000006a4:     	str	w9, [x8]
1000006a8:     	ret

00000001000006ac <_next_value>:
1000006ac:     	adrp	x8, 0x100008000 <__MergedGlobals>
1000006b0:     	add	x8, x8, #0x0
1000006b4:     	ldr	w9, [x8]
1000006b8:     	add	w9, w9, w9, lsl #5
1000006bc:     	eor	w9, w9, w0
1000006c0:     	str	w9, [x8]
1000006c4:     	ldr	w9, [x8, #0x8]
1000006c8:     	add	w9, w9, w0
1000006cc:     	add	w0, w9, w0
1000006d0:     	str	w9, [x8, #0x8]
1000006d4:     	ret

00000001000006d8 <_main>:
1000006d8:     	cmp	w0, #0x3
1000006dc:     	b.ne	0x1000007d8 <_main+0x100>
1000006e0:     	sub	sp, sp, #0xa0
1000006e4:     	stp	x26, x25, [sp, #0x50]
1000006e8:     	stp	x24, x23, [sp, #0x60]
1000006ec:     	stp	x22, x21, [sp, #0x70]
1000006f0:     	stp	x20, x19, [sp, #0x80]
1000006f4:     	stp	x29, x30, [sp, #0x90]
1000006f8:     	add	x29, sp, #0x90
1000006fc:     	ldr	x0, [x1, #0x8]
100000700:     	mov	x20, x1
100000704:     	mov	x1, #0x0                ; =0
100000708:     	mov	w2, #0xa                ; =10
10000070c:     	bl	0x100000870 <_strtoul+0x100000870>
100000710:     	mov	x19, x0
100000714:     	ldr	x0, [x20, #0x10]
100000718:     	mov	x1, #0x0                ; =0
10000071c:     	mov	w2, #0xa                ; =10
100000720:     	bl	0x100000870 <_strtoul+0x100000870>
100000724:     	mov	x20, x0
100000728:     	add	x1, sp, #0x40
10000072c:     	mov	w0, #0x6                ; =6
100000730:     	bl	0x100000858 <_strtoul+0x100000858>
100000734:     	cbnz	w0, 0x1000007b8 <_main+0xe0>
100000738:     	cbz	x19, 0x1000007e0 <_main+0x108>
10000073c:     	mov	x23, #0x0               ; =0
100000740:     	mov	w22, #0x0               ; =0
100000744:     	mov	w24, #-0x1              ; =-1
100000748:     	mov	x25, #-0x3333333333333334 ; =-3689348814741910324
10000074c:     	movk	x25, #0xcccd
100000750:     	mov	w26, #0xa               ; =10
100000754:     	adrp	x21, 0x100008000 <__MergedGlobals>
100000758:     	add	x21, x21, #0x4
10000075c:     	umulh	x8, x23, x25
100000760:     	lsr	x8, x8, #3
100000764:     	msub	w2, w8, w26, w24
100000768:     	eor	w8, w20, w20, lsl #13
10000076c:     	eor	w8, w8, w8, lsr #17
100000770:     	eor	w20, w8, w8, lsl #5
100000774:     	mov	x0, x21
100000778:     	mov	x1, x20
10000077c:     	bl	0x1000004f8 <_region_pipeline>
100000780:     	add	w22, w0, w22
100000784:     	mov	x0, x21
100000788:     	mov	x1, x20
10000078c:     	mov	x2, x22
100000790:     	bl	0x10000062c <_region_outputs>
100000794:     	add	w22, w22, w0
100000798:     	add	x23, x23, #0x1
10000079c:     	add	w24, w24, #0x1
1000007a0:     	subs	x19, x19, #0x1
1000007a4:     	b.ne	0x10000075c <_main+0x84>
1000007a8:     	add	x1, sp, #0x30
1000007ac:     	mov	w0, #0x6                ; =6
1000007b0:     	bl	0x100000858 <_strtoul+0x100000858>
1000007b4:     	cbz	w0, 0x1000007f4 <_main+0x11c>
1000007b8:     	mov	w0, #0x2                ; =2
1000007bc:     	ldp	x29, x30, [sp, #0x90]
1000007c0:     	ldp	x20, x19, [sp, #0x80]
1000007c4:     	ldp	x22, x21, [sp, #0x70]
1000007c8:     	ldp	x24, x23, [sp, #0x60]
1000007cc:     	ldp	x26, x25, [sp, #0x50]
1000007d0:     	add	sp, sp, #0xa0
1000007d4:     	ret
1000007d8:     	mov	w0, #0x2                ; =2
1000007dc:     	ret
1000007e0:     	mov	w22, #0x0               ; =0
1000007e4:     	add	x1, sp, #0x30
1000007e8:     	mov	w0, #0x6                ; =6
1000007ec:     	bl	0x100000858 <_strtoul+0x100000858>
1000007f0:     	cbnz	w0, 0x1000007b8 <_main+0xe0>
1000007f4:     	ldp	x8, x9, [sp, #0x30]
1000007f8:     	ldp	x10, x11, [sp, #0x40]
1000007fc:     	sub	x8, x8, x10
100000800:     	scvtf	d0, x8
100000804:     	sub	x8, x9, x11
100000808:     	scvtf	d1, x8
10000080c:     	mov	x8, #0xd695             ; =54933
100000810:     	movk	x8, #0xe826, lsl #16
100000814:     	movk	x8, #0x2e0b, lsl #32
100000818:     	movk	x8, #0x3e11, lsl #48
10000081c:     	fmov	d2, x8
100000820:     	fmadd	d0, d1, d2, d0
100000824:     	adrp	x8, 0x100008000 <__MergedGlobals>
100000828:     	add	x8, x8, #0x0
10000082c:     	ldp	w9, w10, [x8, #0x8]
100000830:     	ldp	w8, w11, [x8]
100000834:     	stp	x10, x8, [sp, #0x20]
100000838:     	stp	x11, x9, [sp, #0x10]
10000083c:     	str	x22, [sp, #0x8]
100000840:     	str	d0, [sp]
100000844:     	adrp	x0, 0x100000000 <_strtoul+0x100000000>
100000848:     	add	x0, x0, #0x87c
10000084c:     	bl	0x100000864 <_strtoul+0x100000864>
100000850:     	mov	w0, #0x0                ; =0
100000854:     	b	0x1000007bc <_main+0xe4>

Disassembly of section __TEXT,__stubs:

0000000100000858 <__stubs>:
100000858:     	adrp	x16, 0x100004000 <_strtoul+0x100004000>
10000085c:     	ldr	x16, [x16]
100000860:     	br	x16
100000864:     	adrp	x16, 0x100004000 <_strtoul+0x100004000>
100000868:     	ldr	x16, [x16, #0x8]
10000086c:     	br	x16
100000870:     	adrp	x16, 0x100004000 <_strtoul+0x100004000>
100000874:     	ldr	x16, [x16, #0x10]
100000878:     	br	x16
