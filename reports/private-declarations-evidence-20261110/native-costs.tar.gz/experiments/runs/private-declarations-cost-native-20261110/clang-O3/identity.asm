
/Users/admin/C-SRD/experiments/runs/private-declarations-cost-native-20261110/clang-O3/identity:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001000004f8 <_region_pipeline>:
1000004f8:     	stp	x26, x25, [sp, #-0x50]!
1000004fc:     	stp	x24, x23, [sp, #0x10]
100000500:     	stp	x22, x21, [sp, #0x20]
100000504:     	stp	x20, x19, [sp, #0x30]
100000508:     	stp	x29, x30, [sp, #0x40]
10000050c:     	add	x29, sp, #0x40
100000510:     	mov	x22, x2
100000514:     	mov	x19, x0
100000518:     	ldr	w8, [x0]
10000051c:     	add	w20, w8, w1
100000520:     	add	w9, w20, w20, lsl #1
100000524:     	add	w23, w9, #0xb
100000528:     	sub	w21, w23, w8
10000052c:     	mov	x0, x20
100000530:     	bl	0x1000005f0 <_record_event>
100000534:     	cmp	w22, #0x1
100000538:     	b.lt	0x100000588 <_region_pipeline+0x90>
10000053c:     	add	w24, w22, #0x1
100000540:     	mov	x0, x21
100000544:     	bl	0x100000608 <_next_value>
100000548:     	mov	x22, x0
10000054c:     	add	w25, w0, w21
100000550:     	add	w8, w0, w0, lsl #2
100000554:     	add	w21, w8, w23
100000558:     	sub	w8, w21, w0
10000055c:     	add	w23, w8, w20
100000560:     	mov	x0, x21
100000564:     	bl	0x1000005f0 <_record_event>
100000568:     	add	w8, w21, #0x7
10000056c:     	str	w8, [x19]
100000570:     	add	w21, w25, w23
100000574:     	mov	x0, x22
100000578:     	bl	0x1000005f0 <_record_event>
10000057c:     	sub	w24, w24, #0x1
100000580:     	cmp	w24, #0x1
100000584:     	b.hi	0x100000540 <_region_pipeline+0x48>
100000588:     	mov	x0, x21
10000058c:     	ldp	x29, x30, [sp, #0x40]
100000590:     	ldp	x20, x19, [sp, #0x30]
100000594:     	ldp	x22, x21, [sp, #0x20]
100000598:     	ldp	x24, x23, [sp, #0x10]
10000059c:     	ldp	x26, x25, [sp], #0x50
1000005a0:     	ret

00000001000005a4 <_region_outputs>:
1000005a4:     	stp	x22, x21, [sp, #-0x30]!
1000005a8:     	stp	x20, x19, [sp, #0x10]
1000005ac:     	stp	x29, x30, [sp, #0x20]
1000005b0:     	add	x29, sp, #0x20
1000005b4:     	mov	x19, x0
1000005b8:     	add	w8, w1, w1, lsl #1
1000005bc:     	add	w20, w8, w2
1000005c0:     	add	w21, w20, #0x22
1000005c4:     	add	w0, w20, #0x33
1000005c8:     	bl	0x1000005f0 <_record_event>
1000005cc:     	add	w9, w20, #0x3a
1000005d0:     	mov	w8, #0x11               ; =17
1000005d4:     	str	w21, [x19]
1000005d8:     	stp	w8, w9, [x19, #0x4]
1000005dc:     	mov	w0, #0x0                ; =0
1000005e0:     	ldp	x29, x30, [sp, #0x20]
1000005e4:     	ldp	x20, x19, [sp, #0x10]
1000005e8:     	ldp	x22, x21, [sp], #0x30
1000005ec:     	ret

00000001000005f0 <_record_event>:
1000005f0:     	adrp	x8, 0x100008000 <__MergedGlobals>
1000005f4:     	ldr	w9, [x8]
1000005f8:     	add	w9, w9, w9, lsl #5
1000005fc:     	eor	w9, w9, w0
100000600:     	str	w9, [x8]
100000604:     	ret

0000000100000608 <_next_value>:
100000608:     	adrp	x8, 0x100008000 <__MergedGlobals>
10000060c:     	add	x8, x8, #0x0
100000610:     	ldr	w9, [x8]
100000614:     	add	w9, w9, w9, lsl #5
100000618:     	eor	w9, w9, w0
10000061c:     	str	w9, [x8]
100000620:     	ldr	w9, [x8, #0x8]
100000624:     	add	w9, w9, w0
100000628:     	add	w0, w9, w0
10000062c:     	str	w9, [x8, #0x8]
100000630:     	ret

0000000100000634 <_main>:
100000634:     	cmp	w0, #0x3
100000638:     	b.ne	0x100000734 <_main+0x100>
10000063c:     	sub	sp, sp, #0xa0
100000640:     	stp	x26, x25, [sp, #0x50]
100000644:     	stp	x24, x23, [sp, #0x60]
100000648:     	stp	x22, x21, [sp, #0x70]
10000064c:     	stp	x20, x19, [sp, #0x80]
100000650:     	stp	x29, x30, [sp, #0x90]
100000654:     	add	x29, sp, #0x90
100000658:     	ldr	x0, [x1, #0x8]
10000065c:     	mov	x20, x1
100000660:     	mov	x1, #0x0                ; =0
100000664:     	mov	w2, #0xa                ; =10
100000668:     	bl	0x1000007cc <_strtoul+0x1000007cc>
10000066c:     	mov	x19, x0
100000670:     	ldr	x0, [x20, #0x10]
100000674:     	mov	x1, #0x0                ; =0
100000678:     	mov	w2, #0xa                ; =10
10000067c:     	bl	0x1000007cc <_strtoul+0x1000007cc>
100000680:     	mov	x20, x0
100000684:     	add	x1, sp, #0x40
100000688:     	mov	w0, #0x6                ; =6
10000068c:     	bl	0x1000007b4 <_strtoul+0x1000007b4>
100000690:     	cbnz	w0, 0x100000714 <_main+0xe0>
100000694:     	cbz	x19, 0x10000073c <_main+0x108>
100000698:     	mov	x23, #0x0               ; =0
10000069c:     	mov	w22, #0x0               ; =0
1000006a0:     	mov	w24, #-0x1              ; =-1
1000006a4:     	mov	x25, #-0x3333333333333334 ; =-3689348814741910324
1000006a8:     	movk	x25, #0xcccd
1000006ac:     	mov	w26, #0xa               ; =10
1000006b0:     	adrp	x21, 0x100008000 <__MergedGlobals>
1000006b4:     	add	x21, x21, #0x4
1000006b8:     	umulh	x8, x23, x25
1000006bc:     	lsr	x8, x8, #3
1000006c0:     	msub	w2, w8, w26, w24
1000006c4:     	eor	w8, w20, w20, lsl #13
1000006c8:     	eor	w8, w8, w8, lsr #17
1000006cc:     	eor	w20, w8, w8, lsl #5
1000006d0:     	mov	x0, x21
1000006d4:     	mov	x1, x20
1000006d8:     	bl	0x1000004f8 <_region_pipeline>
1000006dc:     	add	w22, w0, w22
1000006e0:     	mov	x0, x21
1000006e4:     	mov	x1, x20
1000006e8:     	mov	x2, x22
1000006ec:     	bl	0x1000005a4 <_region_outputs>
1000006f0:     	add	w22, w22, w0
1000006f4:     	add	x23, x23, #0x1
1000006f8:     	add	w24, w24, #0x1
1000006fc:     	subs	x19, x19, #0x1
100000700:     	b.ne	0x1000006b8 <_main+0x84>
100000704:     	add	x1, sp, #0x30
100000708:     	mov	w0, #0x6                ; =6
10000070c:     	bl	0x1000007b4 <_strtoul+0x1000007b4>
100000710:     	cbz	w0, 0x100000750 <_main+0x11c>
100000714:     	mov	w0, #0x2                ; =2
100000718:     	ldp	x29, x30, [sp, #0x90]
10000071c:     	ldp	x20, x19, [sp, #0x80]
100000720:     	ldp	x22, x21, [sp, #0x70]
100000724:     	ldp	x24, x23, [sp, #0x60]
100000728:     	ldp	x26, x25, [sp, #0x50]
10000072c:     	add	sp, sp, #0xa0
100000730:     	ret
100000734:     	mov	w0, #0x2                ; =2
100000738:     	ret
10000073c:     	mov	w22, #0x0               ; =0
100000740:     	add	x1, sp, #0x30
100000744:     	mov	w0, #0x6                ; =6
100000748:     	bl	0x1000007b4 <_strtoul+0x1000007b4>
10000074c:     	cbnz	w0, 0x100000714 <_main+0xe0>
100000750:     	ldp	x8, x9, [sp, #0x30]
100000754:     	ldp	x10, x11, [sp, #0x40]
100000758:     	sub	x8, x8, x10
10000075c:     	scvtf	d0, x8
100000760:     	sub	x8, x9, x11
100000764:     	scvtf	d1, x8
100000768:     	mov	x8, #0xd695             ; =54933
10000076c:     	movk	x8, #0xe826, lsl #16
100000770:     	movk	x8, #0x2e0b, lsl #32
100000774:     	movk	x8, #0x3e11, lsl #48
100000778:     	fmov	d2, x8
10000077c:     	fmadd	d0, d1, d2, d0
100000780:     	adrp	x8, 0x100008000 <__MergedGlobals>
100000784:     	add	x8, x8, #0x0
100000788:     	ldp	w9, w10, [x8, #0x8]
10000078c:     	ldp	w8, w11, [x8]
100000790:     	stp	x10, x8, [sp, #0x20]
100000794:     	stp	x11, x9, [sp, #0x10]
100000798:     	str	x22, [sp, #0x8]
10000079c:     	str	d0, [sp]
1000007a0:     	adrp	x0, 0x100000000 <_strtoul+0x100000000>
1000007a4:     	add	x0, x0, #0x7d8
1000007a8:     	bl	0x1000007c0 <_strtoul+0x1000007c0>
1000007ac:     	mov	w0, #0x0                ; =0
1000007b0:     	b	0x100000718 <_main+0xe4>

Disassembly of section __TEXT,__stubs:

00000001000007b4 <__stubs>:
1000007b4:     	adrp	x16, 0x100004000 <_strtoul+0x100004000>
1000007b8:     	ldr	x16, [x16]
1000007bc:     	br	x16
1000007c0:     	adrp	x16, 0x100004000 <_strtoul+0x100004000>
1000007c4:     	ldr	x16, [x16, #0x8]
1000007c8:     	br	x16
1000007cc:     	adrp	x16, 0x100004000 <_strtoul+0x100004000>
1000007d0:     	ldr	x16, [x16, #0x10]
1000007d4:     	br	x16
