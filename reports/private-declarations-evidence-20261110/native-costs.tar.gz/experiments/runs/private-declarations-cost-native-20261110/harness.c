#define _POSIX_C_SOURCE 200809L
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
uint32_t region_pipeline(uint32_t*,uint32_t,int);
int region_outputs(uint32_t*,uint32_t,uint32_t);
static uint32_t memory[3], event_hash;
void record_event(uint32_t v){event_hash=(event_hash*33u)^v;}
uint32_t next_value(uint32_t v){record_event(v);memory[1]+=v;return v+memory[1];}
int main(int argc,char**argv){
 if(argc!=3)return 2;
 unsigned long n=strtoul(argv[1],0,10);uint32_t x=(uint32_t)strtoul(argv[2],0,10),sum=0;
 struct timespec start,end;if(clock_gettime(CLOCK_MONOTONIC,&start))return 2;
 for(unsigned long i=0;i<n;i++){
  x^=x<<13;x^=x>>17;x^=x<<5;
  sum+=region_pipeline(memory,x,(int)(i%10)-1);
  sum+=(uint32_t)region_outputs(memory,x,sum);
 }
 if(clock_gettime(CLOCK_MONOTONIC,&end))return 2;
 double elapsed=(double)(end.tv_sec-start.tv_sec)+(double)(end.tv_nsec-start.tv_nsec)*1e-9;
 printf("%.9f %u %u %u %u %u\n",elapsed,sum,memory[0],memory[1],memory[2],event_hash);return 0;
}
