
/Users/admin/C-SRD/experiments/runs/private-declarations-cost-native-20261110/gcc-O0/original:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000100000648 <_region_pipeline>:
100000648:     	stp	x29, x30, [sp, #-0x40]!
10000064c:     	mov	x29, sp
100000650:     	str	x19, [sp, #0x10]
100000654:     	str	x0, [x29, #0x28]
100000658:     	str	w1, [x29, #0x24]
10000065c:     	str	w2, [x29, #0x20]
100000660:     	ldr	x0, [x29, #0x28]
100000664:     	ldr	w0, [x0]
100000668:     	str	w0, [x29, #0x38]
10000066c:     	ldr	w1, [x29, #0x24]
100000670:     	ldr	w0, [x29, #0x38]
100000674:     	add	w19, w1, w0
100000678:     	mov	w0, w19
10000067c:     	lsl	w0, w0, #1
100000680:     	add	w0, w0, w19
100000684:     	add	w0, w0, #0xb
100000688:     	str	w0, [x29, #0x3c]
10000068c:     	ldr	w1, [x29, #0x3c]
100000690:     	ldr	w0, [x29, #0x38]
100000694:     	sub	w0, w1, w0
100000698:     	str	w0, [x29, #0x24]
10000069c:     	mov	w0, w19
1000006a0:     	bl	0x100000814 <_record_event>
1000006a4:     	ldr	w0, [x29, #0x20]
1000006a8:     	cmp	w0, #0x0
1000006ac:     	b.ge	0x100000744 <_region_pipeline+0xfc>
1000006b0:     	ldr	w0, [x29, #0x24]
1000006b4:     	b	0x10000075c <_region_pipeline+0x114>
1000006b8:     	ldr	w0, [x29, #0x24]
1000006bc:     	bl	0x100000854 <_next_value>
1000006c0:     	str	w0, [x29, #0x38]
1000006c4:     	ldr	w1, [x29, #0x24]
1000006c8:     	ldr	w0, [x29, #0x38]
1000006cc:     	add	w0, w1, w0
1000006d0:     	str	w0, [x29, #0x24]
1000006d4:     	ldr	w1, [x29, #0x38]
1000006d8:     	mov	w0, w1
1000006dc:     	lsl	w0, w0, #2
1000006e0:     	add	w0, w0, w1
1000006e4:     	ldr	w1, [x29, #0x3c]
1000006e8:     	add	w0, w1, w0
1000006ec:     	str	w0, [x29, #0x34]
1000006f0:     	ldr	w1, [x29, #0x34]
1000006f4:     	ldr	w0, [x29, #0x38]
1000006f8:     	sub	w0, w1, w0
1000006fc:     	str	w0, [x29, #0x30]
100000700:     	ldr	w0, [x29, #0x30]
100000704:     	add	w0, w0, w19
100000708:     	str	w0, [x29, #0x3c]
10000070c:     	ldr	w0, [x29, #0x34]
100000710:     	bl	0x100000814 <_record_event>
100000714:     	ldr	w0, [x29, #0x34]
100000718:     	add	w0, w0, #0x7
10000071c:     	str	w0, [x29, #0x34]
100000720:     	ldr	x0, [x29, #0x28]
100000724:     	ldr	w1, [x29, #0x34]
100000728:     	str	w1, [x0]
10000072c:     	ldr	w1, [x29, #0x24]
100000730:     	ldr	w0, [x29, #0x3c]
100000734:     	add	w0, w1, w0
100000738:     	str	w0, [x29, #0x24]
10000073c:     	ldr	w0, [x29, #0x38]
100000740:     	bl	0x100000814 <_record_event>
100000744:     	ldr	w0, [x29, #0x20]
100000748:     	sub	w1, w0, #0x1
10000074c:     	str	w1, [x29, #0x20]
100000750:     	cmp	w0, #0x0
100000754:     	b.gt	0x1000006b8 <_region_pipeline+0x70>
100000758:     	ldr	w0, [x29, #0x24]
10000075c:     	ldr	x19, [sp, #0x10]
100000760:     	ldp	x29, x30, [sp], #0x40
100000764:     	ret

0000000100000768 <_region_outputs>:
100000768:     	stp	x29, x30, [sp, #-0x40]!
10000076c:     	mov	x29, sp
100000770:     	str	x19, [sp, #0x10]
100000774:     	str	x0, [x29, #0x28]
100000778:     	str	w1, [x29, #0x24]
10000077c:     	str	w2, [x29, #0x20]
100000780:     	mov	w19, #0x11              ; =17
100000784:     	ldr	w0, [x29, #0x24]
100000788:     	add	w0, w19, w0
10000078c:     	str	w0, [x29, #0x3c]
100000790:     	ldr	w1, [x29, #0x3c]
100000794:     	mov	w0, w1
100000798:     	lsl	w0, w0, #1
10000079c:     	add	w0, w0, w1
1000007a0:     	ldr	w1, [x29, #0x20]
1000007a4:     	add	w0, w1, w0
1000007a8:     	str	w0, [x29, #0x24]
1000007ac:     	ldr	w0, [x29, #0x24]
1000007b0:     	sub	w0, w0, w19
1000007b4:     	str	w0, [x29, #0x20]
1000007b8:     	ldr	w0, [x29, #0x24]
1000007bc:     	bl	0x100000814 <_record_event>
1000007c0:     	ldr	w0, [x29, #0x24]
1000007c4:     	add	w0, w0, #0x7
1000007c8:     	str	w0, [x29, #0x38]
1000007cc:     	ldr	x0, [x29, #0x28]
1000007d0:     	add	x0, x0, #0x8
1000007d4:     	ldr	w1, [x29, #0x38]
1000007d8:     	str	w1, [x0]
1000007dc:     	ldr	x0, [x29, #0x28]
1000007e0:     	ldr	w1, [x29, #0x20]
1000007e4:     	str	w1, [x0]
1000007e8:     	ldr	x0, [x29, #0x28]
1000007ec:     	add	x0, x0, #0x4
1000007f0:     	str	w19, [x0]
1000007f4:     	ldr	w1, [x29, #0x24]
1000007f8:     	ldr	w0, [x29, #0x20]
1000007fc:     	cmp	w1, w0
100000800:     	cset	w0, eq
100000804:     	and	w0, w0, #0xff
100000808:     	ldr	x19, [sp, #0x10]
10000080c:     	ldp	x29, x30, [sp], #0x40
100000810:     	ret

0000000100000814 <_record_event>:
100000814:     	sub	sp, sp, #0x10
100000818:     	str	w0, [sp, #0xc]
10000081c:     	adrp	x0, 0x100008000 <_memory>
100000820:     	add	x0, x0, #0xc
100000824:     	ldr	w1, [x0]
100000828:     	mov	w0, w1
10000082c:     	lsl	w0, w0, #5
100000830:     	add	w1, w0, w1
100000834:     	ldr	w0, [sp, #0xc]
100000838:     	eor	w1, w1, w0
10000083c:     	adrp	x0, 0x100008000 <_memory>
100000840:     	add	x0, x0, #0xc
100000844:     	str	w1, [x0]
100000848:     	nop
10000084c:     	add	sp, sp, #0x10
100000850:     	ret

0000000100000854 <_next_value>:
100000854:     	stp	x29, x30, [sp, #-0x20]!
100000858:     	mov	x29, sp
10000085c:     	str	w0, [x29, #0x1c]
100000860:     	ldr	w0, [x29, #0x1c]
100000864:     	bl	0x100000814 <_record_event>
100000868:     	adrp	x0, 0x100008000 <_memory>
10000086c:     	add	x0, x0, #0x0
100000870:     	ldr	w1, [x0, #0x4]
100000874:     	ldr	w0, [x29, #0x1c]
100000878:     	add	w1, w1, w0
10000087c:     	adrp	x0, 0x100008000 <_memory>
100000880:     	add	x0, x0, #0x0
100000884:     	str	w1, [x0, #0x4]
100000888:     	adrp	x0, 0x100008000 <_memory>
10000088c:     	add	x0, x0, #0x0
100000890:     	ldr	w1, [x0, #0x4]
100000894:     	ldr	w0, [x29, #0x1c]
100000898:     	add	w0, w1, w0
10000089c:     	ldp	x29, x30, [sp], #0x20
1000008a0:     	ret

00000001000008a4 <_main>:
1000008a4:     	sub	sp, sp, #0x90
1000008a8:     	stp	x29, x30, [sp, #0x30]
1000008ac:     	add	x29, sp, #0x30
1000008b0:     	str	w0, [x29, #0x1c]
1000008b4:     	str	x1, [x29, #0x10]
1000008b8:     	ldr	w0, [x29, #0x1c]
1000008bc:     	cmp	w0, #0x3
1000008c0:     	b.eq	0x1000008cc <_main+0x28>
1000008c4:     	mov	w0, #0x2                ; =2
1000008c8:     	b	0x100000ac0 <_main+0x21c>
1000008cc:     	ldr	x0, [x29, #0x10]
1000008d0:     	add	x0, x0, #0x8
1000008d4:     	ldr	x0, [x0]
1000008d8:     	mov	w2, #0xa                ; =10
1000008dc:     	mov	x1, #0x0                ; =0
1000008e0:     	bl	0x100000ae4 <_strtoul+0x100000ae4>
1000008e4:     	str	x0, [x29, #0x48]
1000008e8:     	ldr	x0, [x29, #0x10]
1000008ec:     	add	x0, x0, #0x10
1000008f0:     	ldr	x0, [x0]
1000008f4:     	mov	w2, #0xa                ; =10
1000008f8:     	mov	x1, #0x0                ; =0
1000008fc:     	bl	0x100000ae4 <_strtoul+0x100000ae4>
100000900:     	str	w0, [x29, #0x5c]
100000904:     	str	wzr, [x29, #0x58]
100000908:     	add	x0, x29, #0x30
10000090c:     	mov	x1, x0
100000910:     	mov	w0, #0x6                ; =6
100000914:     	bl	0x100000acc <_strtoul+0x100000acc>
100000918:     	cmp	w0, #0x0
10000091c:     	b.eq	0x100000928 <_main+0x84>
100000920:     	mov	w0, #0x2                ; =2
100000924:     	b	0x100000ac0 <_main+0x21c>
100000928:     	str	xzr, [x29, #0x50]
10000092c:     	b	0x1000009f0 <_main+0x14c>
100000930:     	ldr	w0, [x29, #0x5c]
100000934:     	lsl	w0, w0, #13
100000938:     	ldr	w1, [x29, #0x5c]
10000093c:     	eor	w0, w1, w0
100000940:     	str	w0, [x29, #0x5c]
100000944:     	ldr	w0, [x29, #0x5c]
100000948:     	lsr	w0, w0, #17
10000094c:     	ldr	w1, [x29, #0x5c]
100000950:     	eor	w0, w1, w0
100000954:     	str	w0, [x29, #0x5c]
100000958:     	ldr	w0, [x29, #0x5c]
10000095c:     	lsl	w0, w0, #5
100000960:     	ldr	w1, [x29, #0x5c]
100000964:     	eor	w0, w1, w0
100000968:     	str	w0, [x29, #0x5c]
10000096c:     	ldr	x2, [x29, #0x50]
100000970:     	mov	x0, #-0x3333333333333334 ; =-3689348814741910324
100000974:     	movk	x0, #0xcccd
100000978:     	umulh	x0, x2, x0
10000097c:     	lsr	x1, x0, #3
100000980:     	mov	x0, x1
100000984:     	lsl	x0, x0, #2
100000988:     	add	x0, x0, x1
10000098c:     	lsl	x0, x0, #1
100000990:     	sub	x1, x2, x0
100000994:     	mov	w0, w1
100000998:     	sub	w0, w0, #0x1
10000099c:     	mov	w2, w0
1000009a0:     	ldr	w1, [x29, #0x5c]
1000009a4:     	adrp	x0, 0x100008000 <_memory>
1000009a8:     	add	x0, x0, #0x0
1000009ac:     	bl	0x100000648 <_region_pipeline>
1000009b0:     	mov	w1, w0
1000009b4:     	ldr	w0, [x29, #0x58]
1000009b8:     	add	w0, w0, w1
1000009bc:     	str	w0, [x29, #0x58]
1000009c0:     	ldr	w2, [x29, #0x58]
1000009c4:     	ldr	w1, [x29, #0x5c]
1000009c8:     	adrp	x0, 0x100008000 <_memory>
1000009cc:     	add	x0, x0, #0x0
1000009d0:     	bl	0x100000768 <_region_outputs>
1000009d4:     	mov	w1, w0
1000009d8:     	ldr	w0, [x29, #0x58]
1000009dc:     	add	w0, w0, w1
1000009e0:     	str	w0, [x29, #0x58]
1000009e4:     	ldr	x0, [x29, #0x50]
1000009e8:     	add	x0, x0, #0x1
1000009ec:     	str	x0, [x29, #0x50]
1000009f0:     	ldr	x1, [x29, #0x50]
1000009f4:     	ldr	x0, [x29, #0x48]
1000009f8:     	cmp	x1, x0
1000009fc:     	b.lo	0x100000930 <_main+0x8c>
100000a00:     	add	x0, x29, #0x20
100000a04:     	mov	x1, x0
100000a08:     	mov	w0, #0x6                ; =6
100000a0c:     	bl	0x100000acc <_strtoul+0x100000acc>
100000a10:     	cmp	w0, #0x0
100000a14:     	b.eq	0x100000a20 <_main+0x17c>
100000a18:     	mov	w0, #0x2                ; =2
100000a1c:     	b	0x100000ac0 <_main+0x21c>
100000a20:     	ldr	x1, [x29, #0x20]
100000a24:     	ldr	x0, [x29, #0x30]
100000a28:     	sub	x0, x1, x0
100000a2c:     	fmov	d31, x0
100000a30:     	scvtf	d30, d31
100000a34:     	ldr	x1, [x29, #0x28]
100000a38:     	ldr	x0, [x29, #0x38]
100000a3c:     	sub	x0, x1, x0
100000a40:     	fmov	d31, x0
100000a44:     	scvtf	d29, d31
100000a48:     	adrp	x0, 0x100000000 <_strtoul+0x100000000>
100000a4c:     	add	x0, x0, #0xb08
100000a50:     	ldr	d31, [x0]
100000a54:     	fmul	d31, d29, d31
100000a58:     	fadd	d31, d30, d31
100000a5c:     	str	d31, [x29, #0x40]
100000a60:     	adrp	x0, 0x100008000 <_memory>
100000a64:     	add	x0, x0, #0x0
100000a68:     	ldr	w1, [x0]
100000a6c:     	adrp	x0, 0x100008000 <_memory>
100000a70:     	add	x0, x0, #0x0
100000a74:     	ldr	w2, [x0, #0x4]
100000a78:     	adrp	x0, 0x100008000 <_memory>
100000a7c:     	add	x0, x0, #0x0
100000a80:     	ldr	w3, [x0, #0x8]
100000a84:     	adrp	x0, 0x100008000 <_memory>
100000a88:     	add	x0, x0, #0xc
100000a8c:     	ldr	w0, [x0]
100000a90:     	str	w0, [sp, #0x28]
100000a94:     	str	w3, [sp, #0x20]
100000a98:     	str	w2, [sp, #0x18]
100000a9c:     	str	w1, [sp, #0x10]
100000aa0:     	ldr	w0, [x29, #0x58]
100000aa4:     	str	w0, [sp, #0x8]
100000aa8:     	ldr	d31, [x29, #0x40]
100000aac:     	str	d31, [sp]
100000ab0:     	adrp	x0, 0x100000000 <_strtoul+0x100000000>
100000ab4:     	add	x0, x0, #0xaf0
100000ab8:     	bl	0x100000ad8 <_strtoul+0x100000ad8>
100000abc:     	mov	w0, #0x0                ; =0
100000ac0:     	ldp	x29, x30, [sp, #0x30]
100000ac4:     	add	sp, sp, #0x90
100000ac8:     	ret

Disassembly of section __TEXT,__stubs:

0000000100000acc <__stubs>:
100000acc:     	adrp	x16, 0x100004000 <_strtoul+0x100004000>
100000ad0:     	ldr	x16, [x16]
100000ad4:     	br	x16
100000ad8:     	adrp	x16, 0x100004000 <_strtoul+0x100004000>
100000adc:     	ldr	x16, [x16, #0x8]
100000ae0:     	br	x16
100000ae4:     	adrp	x16, 0x100004000 <_strtoul+0x100004000>
100000ae8:     	ldr	x16, [x16, #0x10]
100000aec:     	br	x16
