
/Users/admin/C-SRD/experiments/runs/private-declarations-cost-native-20261110/gcc-O0/identity:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000100000648 <_region_pipeline>:
100000648:     	stp	x29, x30, [sp, #-0x80]!
10000064c:     	mov	x29, sp
100000650:     	str	x19, [sp, #0x10]
100000654:     	str	x0, [x29, #0x28]
100000658:     	str	w1, [x29, #0x24]
10000065c:     	str	w2, [x29, #0x20]
100000660:     	ldr	x0, [x29, #0x28]
100000664:     	ldr	w0, [x0]
100000668:     	str	w0, [x29, #0x78]
10000066c:     	ldr	w0, [x29, #0x24]
100000670:     	str	w0, [x29, #0x74]
100000674:     	ldr	w0, [x29, #0x78]
100000678:     	str	w0, [x29, #0x70]
10000067c:     	ldr	w1, [x29, #0x74]
100000680:     	ldr	w0, [x29, #0x70]
100000684:     	add	w0, w1, w0
100000688:     	str	w0, [x29, #0x6c]
10000068c:     	ldr	w1, [x29, #0x6c]
100000690:     	mov	w0, w1
100000694:     	lsl	w0, w0, #1
100000698:     	add	w0, w0, w1
10000069c:     	add	w0, w0, #0xb
1000006a0:     	str	w0, [x29, #0x68]
1000006a4:     	ldr	w1, [x29, #0x68]
1000006a8:     	ldr	w0, [x29, #0x70]
1000006ac:     	sub	w0, w1, w0
1000006b0:     	str	w0, [x29, #0x74]
1000006b4:     	ldr	w0, [x29, #0x74]
1000006b8:     	str	w0, [x29, #0x24]
1000006bc:     	ldr	w19, [x29, #0x6c]
1000006c0:     	ldr	w0, [x29, #0x68]
1000006c4:     	str	w0, [x29, #0x7c]
1000006c8:     	mov	w0, w19
1000006cc:     	bl	0x1000008f0 <_record_event>
1000006d0:     	ldr	w0, [x29, #0x20]
1000006d4:     	cmp	w0, #0x0
1000006d8:     	b.ge	0x1000007d8 <_region_pipeline+0x190>
1000006dc:     	ldr	w0, [x29, #0x24]
1000006e0:     	b	0x1000007f0 <_region_pipeline+0x1a8>
1000006e4:     	ldr	w0, [x29, #0x24]
1000006e8:     	bl	0x100000930 <_next_value>
1000006ec:     	str	w0, [x29, #0x78]
1000006f0:     	ldr	w0, [x29, #0x24]
1000006f4:     	str	w0, [x29, #0x64]
1000006f8:     	ldr	w0, [x29, #0x78]
1000006fc:     	str	w0, [x29, #0x60]
100000700:     	ldr	w0, [x29, #0x7c]
100000704:     	str	w0, [x29, #0x5c]
100000708:     	str	w19, [x29, #0x58]
10000070c:     	ldr	w1, [x29, #0x64]
100000710:     	ldr	w0, [x29, #0x60]
100000714:     	add	w0, w1, w0
100000718:     	str	w0, [x29, #0x64]
10000071c:     	ldr	w1, [x29, #0x60]
100000720:     	mov	w0, w1
100000724:     	lsl	w0, w0, #2
100000728:     	add	w0, w0, w1
10000072c:     	ldr	w1, [x29, #0x5c]
100000730:     	add	w0, w1, w0
100000734:     	str	w0, [x29, #0x54]
100000738:     	ldr	w1, [x29, #0x54]
10000073c:     	ldr	w0, [x29, #0x60]
100000740:     	sub	w0, w1, w0
100000744:     	str	w0, [x29, #0x50]
100000748:     	ldr	w1, [x29, #0x50]
10000074c:     	ldr	w0, [x29, #0x58]
100000750:     	add	w0, w1, w0
100000754:     	str	w0, [x29, #0x5c]
100000758:     	ldr	w0, [x29, #0x64]
10000075c:     	str	w0, [x29, #0x24]
100000760:     	ldr	w0, [x29, #0x5c]
100000764:     	str	w0, [x29, #0x7c]
100000768:     	ldr	w0, [x29, #0x54]
10000076c:     	str	w0, [x29, #0x4c]
100000770:     	ldr	w0, [x29, #0x50]
100000774:     	str	w0, [x29, #0x48]
100000778:     	ldr	w0, [x29, #0x4c]
10000077c:     	bl	0x1000008f0 <_record_event>
100000780:     	ldr	w0, [x29, #0x4c]
100000784:     	str	w0, [x29, #0x44]
100000788:     	ldr	w0, [x29, #0x44]
10000078c:     	add	w0, w0, #0x7
100000790:     	str	w0, [x29, #0x44]
100000794:     	ldr	w0, [x29, #0x44]
100000798:     	str	w0, [x29, #0x4c]
10000079c:     	ldr	x0, [x29, #0x28]
1000007a0:     	ldr	w1, [x29, #0x4c]
1000007a4:     	str	w1, [x0]
1000007a8:     	ldr	w0, [x29, #0x24]
1000007ac:     	str	w0, [x29, #0x40]
1000007b0:     	ldr	w0, [x29, #0x7c]
1000007b4:     	str	w0, [x29, #0x3c]
1000007b8:     	ldr	w1, [x29, #0x40]
1000007bc:     	ldr	w0, [x29, #0x3c]
1000007c0:     	add	w0, w1, w0
1000007c4:     	str	w0, [x29, #0x40]
1000007c8:     	ldr	w0, [x29, #0x40]
1000007cc:     	str	w0, [x29, #0x24]
1000007d0:     	ldr	w0, [x29, #0x78]
1000007d4:     	bl	0x1000008f0 <_record_event>
1000007d8:     	ldr	w0, [x29, #0x20]
1000007dc:     	sub	w1, w0, #0x1
1000007e0:     	str	w1, [x29, #0x20]
1000007e4:     	cmp	w0, #0x0
1000007e8:     	b.gt	0x1000006e4 <_region_pipeline+0x9c>
1000007ec:     	ldr	w0, [x29, #0x24]
1000007f0:     	ldr	x19, [sp, #0x10]
1000007f4:     	ldp	x29, x30, [sp], #0x80
1000007f8:     	ret

00000001000007fc <_region_outputs>:
1000007fc:     	stp	x29, x30, [sp, #-0x50]!
100000800:     	mov	x29, sp
100000804:     	str	x19, [sp, #0x10]
100000808:     	str	x0, [x29, #0x28]
10000080c:     	str	w1, [x29, #0x24]
100000810:     	str	w2, [x29, #0x20]
100000814:     	ldr	w0, [x29, #0x24]
100000818:     	str	w0, [x29, #0x4c]
10000081c:     	ldr	w0, [x29, #0x20]
100000820:     	str	w0, [x29, #0x48]
100000824:     	mov	w0, #0x11               ; =17
100000828:     	str	w0, [x29, #0x44]
10000082c:     	ldr	w1, [x29, #0x44]
100000830:     	ldr	w0, [x29, #0x4c]
100000834:     	add	w0, w1, w0
100000838:     	str	w0, [x29, #0x40]
10000083c:     	ldr	w1, [x29, #0x40]
100000840:     	mov	w0, w1
100000844:     	lsl	w0, w0, #1
100000848:     	add	w0, w0, w1
10000084c:     	ldr	w1, [x29, #0x48]
100000850:     	add	w0, w1, w0
100000854:     	str	w0, [x29, #0x4c]
100000858:     	ldr	w1, [x29, #0x4c]
10000085c:     	ldr	w0, [x29, #0x44]
100000860:     	sub	w0, w1, w0
100000864:     	str	w0, [x29, #0x48]
100000868:     	ldr	w0, [x29, #0x4c]
10000086c:     	str	w0, [x29, #0x24]
100000870:     	ldr	w0, [x29, #0x48]
100000874:     	str	w0, [x29, #0x20]
100000878:     	ldr	w19, [x29, #0x44]
10000087c:     	ldr	w0, [x29, #0x40]
100000880:     	str	w0, [x29, #0x3c]
100000884:     	ldr	w0, [x29, #0x24]
100000888:     	bl	0x1000008f0 <_record_event>
10000088c:     	ldr	w0, [x29, #0x24]
100000890:     	str	w0, [x29, #0x38]
100000894:     	ldr	w0, [x29, #0x38]
100000898:     	add	w0, w0, #0x7
10000089c:     	str	w0, [x29, #0x34]
1000008a0:     	ldr	w0, [x29, #0x34]
1000008a4:     	str	w0, [x29, #0x30]
1000008a8:     	ldr	x0, [x29, #0x28]
1000008ac:     	add	x0, x0, #0x8
1000008b0:     	ldr	w1, [x29, #0x30]
1000008b4:     	str	w1, [x0]
1000008b8:     	ldr	x0, [x29, #0x28]
1000008bc:     	ldr	w1, [x29, #0x20]
1000008c0:     	str	w1, [x0]
1000008c4:     	ldr	x0, [x29, #0x28]
1000008c8:     	add	x0, x0, #0x4
1000008cc:     	str	w19, [x0]
1000008d0:     	ldr	w1, [x29, #0x24]
1000008d4:     	ldr	w0, [x29, #0x20]
1000008d8:     	cmp	w1, w0
1000008dc:     	cset	w0, eq
1000008e0:     	and	w0, w0, #0xff
1000008e4:     	ldr	x19, [sp, #0x10]
1000008e8:     	ldp	x29, x30, [sp], #0x50
1000008ec:     	ret

00000001000008f0 <_record_event>:
1000008f0:     	sub	sp, sp, #0x10
1000008f4:     	str	w0, [sp, #0xc]
1000008f8:     	adrp	x0, 0x100008000 <_memory>
1000008fc:     	add	x0, x0, #0xc
100000900:     	ldr	w1, [x0]
100000904:     	mov	w0, w1
100000908:     	lsl	w0, w0, #5
10000090c:     	add	w1, w0, w1
100000910:     	ldr	w0, [sp, #0xc]
100000914:     	eor	w1, w1, w0
100000918:     	adrp	x0, 0x100008000 <_memory>
10000091c:     	add	x0, x0, #0xc
100000920:     	str	w1, [x0]
100000924:     	nop
100000928:     	add	sp, sp, #0x10
10000092c:     	ret

0000000100000930 <_next_value>:
100000930:     	stp	x29, x30, [sp, #-0x20]!
100000934:     	mov	x29, sp
100000938:     	str	w0, [x29, #0x1c]
10000093c:     	ldr	w0, [x29, #0x1c]
100000940:     	bl	0x1000008f0 <_record_event>
100000944:     	adrp	x0, 0x100008000 <_memory>
100000948:     	add	x0, x0, #0x0
10000094c:     	ldr	w1, [x0, #0x4]
100000950:     	ldr	w0, [x29, #0x1c]
100000954:     	add	w1, w1, w0
100000958:     	adrp	x0, 0x100008000 <_memory>
10000095c:     	add	x0, x0, #0x0
100000960:     	str	w1, [x0, #0x4]
100000964:     	adrp	x0, 0x100008000 <_memory>
100000968:     	add	x0, x0, #0x0
10000096c:     	ldr	w1, [x0, #0x4]
100000970:     	ldr	w0, [x29, #0x1c]
100000974:     	add	w0, w1, w0
100000978:     	ldp	x29, x30, [sp], #0x20
10000097c:     	ret

0000000100000980 <_main>:
100000980:     	sub	sp, sp, #0x90
100000984:     	stp	x29, x30, [sp, #0x30]
100000988:     	add	x29, sp, #0x30
10000098c:     	str	w0, [x29, #0x1c]
100000990:     	str	x1, [x29, #0x10]
100000994:     	ldr	w0, [x29, #0x1c]
100000998:     	cmp	w0, #0x3
10000099c:     	b.eq	0x1000009a8 <_main+0x28>
1000009a0:     	mov	w0, #0x2                ; =2
1000009a4:     	b	0x100000b9c <_main+0x21c>
1000009a8:     	ldr	x0, [x29, #0x10]
1000009ac:     	add	x0, x0, #0x8
1000009b0:     	ldr	x0, [x0]
1000009b4:     	mov	w2, #0xa                ; =10
1000009b8:     	mov	x1, #0x0                ; =0
1000009bc:     	bl	0x100000bc0 <_strtoul+0x100000bc0>
1000009c0:     	str	x0, [x29, #0x48]
1000009c4:     	ldr	x0, [x29, #0x10]
1000009c8:     	add	x0, x0, #0x10
1000009cc:     	ldr	x0, [x0]
1000009d0:     	mov	w2, #0xa                ; =10
1000009d4:     	mov	x1, #0x0                ; =0
1000009d8:     	bl	0x100000bc0 <_strtoul+0x100000bc0>
1000009dc:     	str	w0, [x29, #0x5c]
1000009e0:     	str	wzr, [x29, #0x58]
1000009e4:     	add	x0, x29, #0x30
1000009e8:     	mov	x1, x0
1000009ec:     	mov	w0, #0x6                ; =6
1000009f0:     	bl	0x100000ba8 <_strtoul+0x100000ba8>
1000009f4:     	cmp	w0, #0x0
1000009f8:     	b.eq	0x100000a04 <_main+0x84>
1000009fc:     	mov	w0, #0x2                ; =2
100000a00:     	b	0x100000b9c <_main+0x21c>
100000a04:     	str	xzr, [x29, #0x50]
100000a08:     	b	0x100000acc <_main+0x14c>
100000a0c:     	ldr	w0, [x29, #0x5c]
100000a10:     	lsl	w0, w0, #13
100000a14:     	ldr	w1, [x29, #0x5c]
100000a18:     	eor	w0, w1, w0
100000a1c:     	str	w0, [x29, #0x5c]
100000a20:     	ldr	w0, [x29, #0x5c]
100000a24:     	lsr	w0, w0, #17
100000a28:     	ldr	w1, [x29, #0x5c]
100000a2c:     	eor	w0, w1, w0
100000a30:     	str	w0, [x29, #0x5c]
100000a34:     	ldr	w0, [x29, #0x5c]
100000a38:     	lsl	w0, w0, #5
100000a3c:     	ldr	w1, [x29, #0x5c]
100000a40:     	eor	w0, w1, w0
100000a44:     	str	w0, [x29, #0x5c]
100000a48:     	ldr	x2, [x29, #0x50]
100000a4c:     	mov	x0, #-0x3333333333333334 ; =-3689348814741910324
100000a50:     	movk	x0, #0xcccd
100000a54:     	umulh	x0, x2, x0
100000a58:     	lsr	x1, x0, #3
100000a5c:     	mov	x0, x1
100000a60:     	lsl	x0, x0, #2
100000a64:     	add	x0, x0, x1
100000a68:     	lsl	x0, x0, #1
100000a6c:     	sub	x1, x2, x0
100000a70:     	mov	w0, w1
100000a74:     	sub	w0, w0, #0x1
100000a78:     	mov	w2, w0
100000a7c:     	ldr	w1, [x29, #0x5c]
100000a80:     	adrp	x0, 0x100008000 <_memory>
100000a84:     	add	x0, x0, #0x0
100000a88:     	bl	0x100000648 <_region_pipeline>
100000a8c:     	mov	w1, w0
100000a90:     	ldr	w0, [x29, #0x58]
100000a94:     	add	w0, w0, w1
100000a98:     	str	w0, [x29, #0x58]
100000a9c:     	ldr	w2, [x29, #0x58]
100000aa0:     	ldr	w1, [x29, #0x5c]
100000aa4:     	adrp	x0, 0x100008000 <_memory>
100000aa8:     	add	x0, x0, #0x0
100000aac:     	bl	0x1000007fc <_region_outputs>
100000ab0:     	mov	w1, w0
100000ab4:     	ldr	w0, [x29, #0x58]
100000ab8:     	add	w0, w0, w1
100000abc:     	str	w0, [x29, #0x58]
100000ac0:     	ldr	x0, [x29, #0x50]
100000ac4:     	add	x0, x0, #0x1
100000ac8:     	str	x0, [x29, #0x50]
100000acc:     	ldr	x1, [x29, #0x50]
100000ad0:     	ldr	x0, [x29, #0x48]
100000ad4:     	cmp	x1, x0
100000ad8:     	b.lo	0x100000a0c <_main+0x8c>
100000adc:     	add	x0, x29, #0x20
100000ae0:     	mov	x1, x0
100000ae4:     	mov	w0, #0x6                ; =6
100000ae8:     	bl	0x100000ba8 <_strtoul+0x100000ba8>
100000aec:     	cmp	w0, #0x0
100000af0:     	b.eq	0x100000afc <_main+0x17c>
100000af4:     	mov	w0, #0x2                ; =2
100000af8:     	b	0x100000b9c <_main+0x21c>
100000afc:     	ldr	x1, [x29, #0x20]
100000b00:     	ldr	x0, [x29, #0x30]
100000b04:     	sub	x0, x1, x0
100000b08:     	fmov	d31, x0
100000b0c:     	scvtf	d30, d31
100000b10:     	ldr	x1, [x29, #0x28]
100000b14:     	ldr	x0, [x29, #0x38]
100000b18:     	sub	x0, x1, x0
100000b1c:     	fmov	d31, x0
100000b20:     	scvtf	d29, d31
100000b24:     	adrp	x0, 0x100000000 <_strtoul+0x100000000>
100000b28:     	add	x0, x0, #0xbe8
100000b2c:     	ldr	d31, [x0]
100000b30:     	fmul	d31, d29, d31
100000b34:     	fadd	d31, d30, d31
100000b38:     	str	d31, [x29, #0x40]
100000b3c:     	adrp	x0, 0x100008000 <_memory>
100000b40:     	add	x0, x0, #0x0
100000b44:     	ldr	w1, [x0]
100000b48:     	adrp	x0, 0x100008000 <_memory>
100000b4c:     	add	x0, x0, #0x0
100000b50:     	ldr	w2, [x0, #0x4]
100000b54:     	adrp	x0, 0x100008000 <_memory>
100000b58:     	add	x0, x0, #0x0
100000b5c:     	ldr	w3, [x0, #0x8]
100000b60:     	adrp	x0, 0x100008000 <_memory>
100000b64:     	add	x0, x0, #0xc
100000b68:     	ldr	w0, [x0]
100000b6c:     	str	w0, [sp, #0x28]
100000b70:     	str	w3, [sp, #0x20]
100000b74:     	str	w2, [sp, #0x18]
100000b78:     	str	w1, [sp, #0x10]
100000b7c:     	ldr	w0, [x29, #0x58]
100000b80:     	str	w0, [sp, #0x8]
100000b84:     	ldr	d31, [x29, #0x40]
100000b88:     	str	d31, [sp]
100000b8c:     	adrp	x0, 0x100000000 <_strtoul+0x100000000>
100000b90:     	add	x0, x0, #0xbd0
100000b94:     	bl	0x100000bb4 <_strtoul+0x100000bb4>
100000b98:     	mov	w0, #0x0                ; =0
100000b9c:     	ldp	x29, x30, [sp, #0x30]
100000ba0:     	add	sp, sp, #0x90
100000ba4:     	ret

Disassembly of section __TEXT,__stubs:

0000000100000ba8 <__stubs>:
100000ba8:     	adrp	x16, 0x100004000 <_strtoul+0x100004000>
100000bac:     	ldr	x16, [x16]
100000bb0:     	br	x16
100000bb4:     	adrp	x16, 0x100004000 <_strtoul+0x100004000>
100000bb8:     	ldr	x16, [x16, #0x8]
100000bbc:     	br	x16
100000bc0:     	adrp	x16, 0x100004000 <_strtoul+0x100004000>
100000bc4:     	ldr	x16, [x16, #0x10]
100000bc8:     	br	x16
