
/Users/admin/C-SRD/experiments/runs/private-declarations-cost-native-20261110/gcc-O0/affine:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000100000648 <_region_pipeline>:
100000648:     	stp	x29, x30, [sp, #-0x80]!
10000064c:     	mov	x29, sp
100000650:     	str	x19, [sp, #0x10]
100000654:     	str	x0, [x29, #0x28]
100000658:     	str	w1, [x29, #0x24]
10000065c:     	str	w2, [x29, #0x20]
100000660:     	ldr	x0, [x29, #0x28]
100000664:     	ldr	w0, [x0]
100000668:     	str	w0, [x29, #0x78]
10000066c:     	ldr	w1, [x29, #0x24]
100000670:     	mov	w0, #0xc255             ; =49749
100000674:     	movk	w0, #0xf13, lsl #16
100000678:     	mul	w1, w1, w0
10000067c:     	mov	w0, #0x8950             ; =35152
100000680:     	movk	w0, #0xf66f, lsl #16
100000684:     	add	w0, w1, w0
100000688:     	str	w0, [x29, #0x74]
10000068c:     	ldr	w1, [x29, #0x78]
100000690:     	mov	w0, #0xc255             ; =49749
100000694:     	movk	w0, #0xf13, lsl #16
100000698:     	mul	w1, w1, w0
10000069c:     	mov	w0, #0x8950             ; =35152
1000006a0:     	movk	w0, #0xf66f, lsl #16
1000006a4:     	add	w0, w1, w0
1000006a8:     	str	w0, [x29, #0x70]
1000006ac:     	ldr	w1, [x29, #0x74]
1000006b0:     	ldr	w0, [x29, #0x70]
1000006b4:     	add	w1, w1, w0
1000006b8:     	mov	w0, #0x76b0             ; =30384
1000006bc:     	movk	w0, #0x990, lsl #16
1000006c0:     	add	w0, w1, w0
1000006c4:     	str	w0, [x29, #0x6c]
1000006c8:     	ldr	w1, [x29, #0x6c]
1000006cc:     	mov	w0, w1
1000006d0:     	lsl	w0, w0, #1
1000006d4:     	add	w1, w0, w1
1000006d8:     	mov	w0, #0x4707             ; =18183
1000006dc:     	movk	w0, #0xb8fa, lsl #16
1000006e0:     	add	w0, w1, w0
1000006e4:     	str	w0, [x29, #0x68]
1000006e8:     	ldr	w1, [x29, #0x68]
1000006ec:     	ldr	w0, [x29, #0x70]
1000006f0:     	sub	w1, w1, w0
1000006f4:     	mov	w0, #0x8950             ; =35152
1000006f8:     	movk	w0, #0xf66f, lsl #16
1000006fc:     	add	w0, w1, w0
100000700:     	str	w0, [x29, #0x74]
100000704:     	ldr	w1, [x29, #0x74]
100000708:     	mov	w0, #0x2afd             ; =11005
10000070c:     	movk	w0, #0xca3b, lsl #16
100000710:     	mul	w1, w1, w0
100000714:     	mov	w0, #0x2bf0             ; =11248
100000718:     	movk	w0, #0x61ce, lsl #16
10000071c:     	add	w0, w1, w0
100000720:     	str	w0, [x29, #0x24]
100000724:     	ldr	w1, [x29, #0x6c]
100000728:     	mov	w0, #0x2afd             ; =11005
10000072c:     	movk	w0, #0xca3b, lsl #16
100000730:     	mul	w1, w1, w0
100000734:     	mov	w0, #0x2bf0             ; =11248
100000738:     	movk	w0, #0x61ce, lsl #16
10000073c:     	add	w19, w1, w0
100000740:     	ldr	w1, [x29, #0x68]
100000744:     	mov	w0, #0x2afd             ; =11005
100000748:     	movk	w0, #0xca3b, lsl #16
10000074c:     	mul	w1, w1, w0
100000750:     	mov	w0, #0x2bf0             ; =11248
100000754:     	movk	w0, #0x61ce, lsl #16
100000758:     	add	w0, w1, w0
10000075c:     	str	w0, [x29, #0x7c]
100000760:     	mov	w0, w19
100000764:     	bl	0x100000bf4 <_record_event>
100000768:     	ldr	w0, [x29, #0x20]
10000076c:     	cmp	w0, #0x0
100000770:     	b.ge	0x1000009ec <_region_pipeline+0x3a4>
100000774:     	ldr	w0, [x29, #0x24]
100000778:     	b	0x100000a04 <_region_pipeline+0x3bc>
10000077c:     	ldr	w0, [x29, #0x24]
100000780:     	bl	0x100000c34 <_next_value>
100000784:     	str	w0, [x29, #0x78]
100000788:     	ldr	w1, [x29, #0x24]
10000078c:     	mov	w0, #0xb955             ; =47445
100000790:     	movk	w0, #0xcb3a, lsl #16
100000794:     	mul	w1, w1, w0
100000798:     	mov	w0, #0xeff3             ; =61427
10000079c:     	movk	w0, #0x8064, lsl #16
1000007a0:     	add	w0, w1, w0
1000007a4:     	str	w0, [x29, #0x64]
1000007a8:     	ldr	w1, [x29, #0x78]
1000007ac:     	mov	w0, #0xb955             ; =47445
1000007b0:     	movk	w0, #0xcb3a, lsl #16
1000007b4:     	mul	w1, w1, w0
1000007b8:     	mov	w0, #0xeff3             ; =61427
1000007bc:     	movk	w0, #0x8064, lsl #16
1000007c0:     	add	w0, w1, w0
1000007c4:     	str	w0, [x29, #0x60]
1000007c8:     	ldr	w1, [x29, #0x7c]
1000007cc:     	mov	w0, #0xb955             ; =47445
1000007d0:     	movk	w0, #0xcb3a, lsl #16
1000007d4:     	mul	w1, w1, w0
1000007d8:     	mov	w0, #0xeff3             ; =61427
1000007dc:     	movk	w0, #0x8064, lsl #16
1000007e0:     	add	w0, w1, w0
1000007e4:     	str	w0, [x29, #0x5c]
1000007e8:     	mov	w0, #0xb955             ; =47445
1000007ec:     	movk	w0, #0xcb3a, lsl #16
1000007f0:     	mul	w1, w19, w0
1000007f4:     	mov	w0, #0xeff3             ; =61427
1000007f8:     	movk	w0, #0x8064, lsl #16
1000007fc:     	add	w0, w1, w0
100000800:     	str	w0, [x29, #0x58]
100000804:     	ldr	w1, [x29, #0x64]
100000808:     	ldr	w0, [x29, #0x60]
10000080c:     	add	w1, w1, w0
100000810:     	mov	w0, #0x100d             ; =4109
100000814:     	movk	w0, #0x7f9b, lsl #16
100000818:     	add	w0, w1, w0
10000081c:     	str	w0, [x29, #0x64]
100000820:     	ldr	w1, [x29, #0x60]
100000824:     	mov	w0, w1
100000828:     	lsl	w0, w0, #2
10000082c:     	add	w1, w0, w1
100000830:     	ldr	w0, [x29, #0x5c]
100000834:     	add	w1, w1, w0
100000838:     	mov	w0, #0x5041             ; =20545
10000083c:     	movk	w0, #0x7e07, lsl #16
100000840:     	add	w0, w1, w0
100000844:     	str	w0, [x29, #0x54]
100000848:     	ldr	w1, [x29, #0x54]
10000084c:     	ldr	w0, [x29, #0x60]
100000850:     	sub	w1, w1, w0
100000854:     	mov	w0, #0xeff3             ; =61427
100000858:     	movk	w0, #0x8064, lsl #16
10000085c:     	add	w0, w1, w0
100000860:     	str	w0, [x29, #0x50]
100000864:     	ldr	w1, [x29, #0x50]
100000868:     	ldr	w0, [x29, #0x58]
10000086c:     	add	w1, w1, w0
100000870:     	mov	w0, #0x100d             ; =4109
100000874:     	movk	w0, #0x7f9b, lsl #16
100000878:     	add	w0, w1, w0
10000087c:     	str	w0, [x29, #0x5c]
100000880:     	ldr	w1, [x29, #0x64]
100000884:     	mov	w0, #0x7bfd             ; =31741
100000888:     	movk	w0, #0x43f, lsl #16
10000088c:     	mul	w1, w1, w0
100000890:     	mov	w0, #0x1bd9             ; =7129
100000894:     	movk	w0, #0xc428, lsl #16
100000898:     	add	w0, w1, w0
10000089c:     	str	w0, [x29, #0x24]
1000008a0:     	ldr	w1, [x29, #0x5c]
1000008a4:     	mov	w0, #0x7bfd             ; =31741
1000008a8:     	movk	w0, #0x43f, lsl #16
1000008ac:     	mul	w1, w1, w0
1000008b0:     	mov	w0, #0x1bd9             ; =7129
1000008b4:     	movk	w0, #0xc428, lsl #16
1000008b8:     	add	w0, w1, w0
1000008bc:     	str	w0, [x29, #0x7c]
1000008c0:     	ldr	w1, [x29, #0x54]
1000008c4:     	mov	w0, #0x7bfd             ; =31741
1000008c8:     	movk	w0, #0x43f, lsl #16
1000008cc:     	mul	w1, w1, w0
1000008d0:     	mov	w0, #0x1bd9             ; =7129
1000008d4:     	movk	w0, #0xc428, lsl #16
1000008d8:     	add	w0, w1, w0
1000008dc:     	str	w0, [x29, #0x4c]
1000008e0:     	ldr	w1, [x29, #0x50]
1000008e4:     	mov	w0, #0x7bfd             ; =31741
1000008e8:     	movk	w0, #0x43f, lsl #16
1000008ec:     	mul	w1, w1, w0
1000008f0:     	mov	w0, #0x1bd9             ; =7129
1000008f4:     	movk	w0, #0xc428, lsl #16
1000008f8:     	add	w0, w1, w0
1000008fc:     	str	w0, [x29, #0x48]
100000900:     	ldr	w0, [x29, #0x4c]
100000904:     	bl	0x100000bf4 <_record_event>
100000908:     	ldr	w1, [x29, #0x4c]
10000090c:     	mov	w0, #0x27a7             ; =10151
100000910:     	movk	w0, #0xa483, lsl #16
100000914:     	mul	w1, w1, w0
100000918:     	mov	w0, #0x210f             ; =8463
10000091c:     	movk	w0, #0x3e85, lsl #16
100000920:     	add	w0, w1, w0
100000924:     	str	w0, [x29, #0x44]
100000928:     	ldr	w1, [x29, #0x44]
10000092c:     	mov	w0, #0x1591             ; =5521
100000930:     	movk	w0, #0x7f96, lsl #16
100000934:     	add	w0, w1, w0
100000938:     	str	w0, [x29, #0x44]
10000093c:     	ldr	w1, [x29, #0x44]
100000940:     	mov	w0, #0x1017             ; =4119
100000944:     	movk	w0, #0x53fb, lsl #16
100000948:     	mul	w1, w1, w0
10000094c:     	mov	w0, #0x17a7             ; =6055
100000950:     	movk	w0, #0xc944, lsl #16
100000954:     	add	w0, w1, w0
100000958:     	str	w0, [x29, #0x4c]
10000095c:     	ldr	x0, [x29, #0x28]
100000960:     	ldr	w1, [x29, #0x4c]
100000964:     	str	w1, [x0]
100000968:     	ldr	w1, [x29, #0x24]
10000096c:     	mov	w0, #0xf8e9             ; =63721
100000970:     	movk	w0, #0x6e34, lsl #16
100000974:     	mul	w1, w1, w0
100000978:     	mov	w0, #0x3d0d             ; =15629
10000097c:     	movk	w0, #0xab22, lsl #16
100000980:     	add	w0, w1, w0
100000984:     	str	w0, [x29, #0x40]
100000988:     	ldr	w1, [x29, #0x7c]
10000098c:     	mov	w0, #0xf8e9             ; =63721
100000990:     	movk	w0, #0x6e34, lsl #16
100000994:     	mul	w1, w1, w0
100000998:     	mov	w0, #0x3d0d             ; =15629
10000099c:     	movk	w0, #0xab22, lsl #16
1000009a0:     	add	w0, w1, w0
1000009a4:     	str	w0, [x29, #0x3c]
1000009a8:     	ldr	w1, [x29, #0x40]
1000009ac:     	ldr	w0, [x29, #0x3c]
1000009b0:     	add	w1, w1, w0
1000009b4:     	mov	w0, #0xc2f3             ; =49907
1000009b8:     	movk	w0, #0x54dd, lsl #16
1000009bc:     	add	w0, w1, w0
1000009c0:     	str	w0, [x29, #0x40]
1000009c4:     	ldr	w1, [x29, #0x40]
1000009c8:     	mov	w0, #0x5f59             ; =24409
1000009cc:     	movk	w0, #0xeb1f, lsl #16
1000009d0:     	mul	w1, w1, w0
1000009d4:     	mov	w0, #0xf37b             ; =62331
1000009d8:     	movk	w0, #0x78dd, lsl #16
1000009dc:     	add	w0, w1, w0
1000009e0:     	str	w0, [x29, #0x24]
1000009e4:     	ldr	w0, [x29, #0x78]
1000009e8:     	bl	0x100000bf4 <_record_event>
1000009ec:     	ldr	w0, [x29, #0x20]
1000009f0:     	sub	w1, w0, #0x1
1000009f4:     	str	w1, [x29, #0x20]
1000009f8:     	cmp	w0, #0x0
1000009fc:     	b.gt	0x10000077c <_region_pipeline+0x134>
100000a00:     	ldr	w0, [x29, #0x24]
100000a04:     	ldr	x19, [sp, #0x10]
100000a08:     	ldp	x29, x30, [sp], #0x80
100000a0c:     	ret

0000000100000a10 <_region_outputs>:
100000a10:     	stp	x29, x30, [sp, #-0x50]!
100000a14:     	mov	x29, sp
100000a18:     	str	x19, [sp, #0x10]
100000a1c:     	str	x0, [x29, #0x28]
100000a20:     	str	w1, [x29, #0x24]
100000a24:     	str	w2, [x29, #0x20]
100000a28:     	ldr	w1, [x29, #0x24]
100000a2c:     	mov	w0, #0x41b5             ; =16821
100000a30:     	movk	w0, #0x9ed1, lsl #16
100000a34:     	mul	w1, w1, w0
100000a38:     	mov	w0, #0x9263             ; =37475
100000a3c:     	movk	w0, #0x6a1c, lsl #16
100000a40:     	add	w0, w1, w0
100000a44:     	str	w0, [x29, #0x4c]
100000a48:     	ldr	w1, [x29, #0x20]
100000a4c:     	mov	w0, #0x41b5             ; =16821
100000a50:     	movk	w0, #0x9ed1, lsl #16
100000a54:     	mul	w1, w1, w0
100000a58:     	mov	w0, #0x9263             ; =37475
100000a5c:     	movk	w0, #0x6a1c, lsl #16
100000a60:     	add	w0, w1, w0
100000a64:     	str	w0, [x29, #0x48]
100000a68:     	mov	w0, #0xef68             ; =61288
100000a6c:     	movk	w0, #0xf601, lsl #16
100000a70:     	str	w0, [x29, #0x44]
100000a74:     	ldr	w1, [x29, #0x44]
100000a78:     	ldr	w0, [x29, #0x4c]
100000a7c:     	add	w1, w1, w0
100000a80:     	mov	w0, #0x6d9d             ; =28061
100000a84:     	movk	w0, #0x95e3, lsl #16
100000a88:     	add	w0, w1, w0
100000a8c:     	str	w0, [x29, #0x40]
100000a90:     	ldr	w1, [x29, #0x40]
100000a94:     	mov	w0, w1
100000a98:     	lsl	w0, w0, #1
100000a9c:     	add	w1, w0, w1
100000aa0:     	ldr	w0, [x29, #0x48]
100000aa4:     	add	w1, w1, w0
100000aa8:     	mov	w0, #0x48d7             ; =18647
100000aac:     	movk	w0, #0xc1aa, lsl #16
100000ab0:     	add	w0, w1, w0
100000ab4:     	str	w0, [x29, #0x4c]
100000ab8:     	ldr	w1, [x29, #0x4c]
100000abc:     	ldr	w0, [x29, #0x44]
100000ac0:     	sub	w1, w1, w0
100000ac4:     	mov	w0, #0x9263             ; =37475
100000ac8:     	movk	w0, #0x6a1c, lsl #16
100000acc:     	add	w0, w1, w0
100000ad0:     	str	w0, [x29, #0x48]
100000ad4:     	ldr	w1, [x29, #0x4c]
100000ad8:     	mov	w0, #0x649d             ; =25757
100000adc:     	movk	w0, #0xec00, lsl #16
100000ae0:     	mul	w1, w1, w0
100000ae4:     	mov	w0, #0x8d49             ; =36169
100000ae8:     	movk	w0, #0x7f4b, lsl #16
100000aec:     	add	w0, w1, w0
100000af0:     	str	w0, [x29, #0x24]
100000af4:     	ldr	w1, [x29, #0x48]
100000af8:     	mov	w0, #0x649d             ; =25757
100000afc:     	movk	w0, #0xec00, lsl #16
100000b00:     	mul	w1, w1, w0
100000b04:     	mov	w0, #0x8d49             ; =36169
100000b08:     	movk	w0, #0x7f4b, lsl #16
100000b0c:     	add	w0, w1, w0
100000b10:     	str	w0, [x29, #0x20]
100000b14:     	ldr	w1, [x29, #0x44]
100000b18:     	mov	w0, #0x649d             ; =25757
100000b1c:     	movk	w0, #0xec00, lsl #16
100000b20:     	mul	w1, w1, w0
100000b24:     	mov	w0, #0x8d49             ; =36169
100000b28:     	movk	w0, #0x7f4b, lsl #16
100000b2c:     	add	w19, w1, w0
100000b30:     	ldr	w1, [x29, #0x40]
100000b34:     	mov	w0, #0x649d             ; =25757
100000b38:     	movk	w0, #0xec00, lsl #16
100000b3c:     	mul	w1, w1, w0
100000b40:     	mov	w0, #0x8d49             ; =36169
100000b44:     	movk	w0, #0x7f4b, lsl #16
100000b48:     	add	w0, w1, w0
100000b4c:     	str	w0, [x29, #0x3c]
100000b50:     	ldr	w0, [x29, #0x24]
100000b54:     	bl	0x100000bf4 <_record_event>
100000b58:     	ldr	w1, [x29, #0x24]
100000b5c:     	mov	w0, #0x4935             ; =18741
100000b60:     	movk	w0, #0x20cf, lsl #16
100000b64:     	mul	w1, w1, w0
100000b68:     	mov	w0, #0x3202             ; =12802
100000b6c:     	movk	w0, #0x8a11, lsl #16
100000b70:     	add	w0, w1, w0
100000b74:     	str	w0, [x29, #0x38]
100000b78:     	ldr	w1, [x29, #0x38]
100000b7c:     	mov	w0, #0x73               ; =115
100000b80:     	movk	w0, #0xe5ab, lsl #16
100000b84:     	add	w0, w1, w0
100000b88:     	str	w0, [x29, #0x34]
100000b8c:     	ldr	w1, [x29, #0x34]
100000b90:     	mov	w0, #0x811d             ; =33053
100000b94:     	movk	w0, #0x373d, lsl #16
100000b98:     	mul	w1, w1, w0
100000b9c:     	mov	w0, #0x53c6             ; =21446
100000ba0:     	movk	w0, #0x5960, lsl #16
100000ba4:     	add	w0, w1, w0
100000ba8:     	str	w0, [x29, #0x30]
100000bac:     	ldr	x0, [x29, #0x28]
100000bb0:     	add	x0, x0, #0x8
100000bb4:     	ldr	w1, [x29, #0x30]
100000bb8:     	str	w1, [x0]
100000bbc:     	ldr	x0, [x29, #0x28]
100000bc0:     	ldr	w1, [x29, #0x20]
100000bc4:     	str	w1, [x0]
100000bc8:     	ldr	x0, [x29, #0x28]
100000bcc:     	add	x0, x0, #0x4
100000bd0:     	str	w19, [x0]
100000bd4:     	ldr	w1, [x29, #0x24]
100000bd8:     	ldr	w0, [x29, #0x20]
100000bdc:     	cmp	w1, w0
100000be0:     	cset	w0, eq
100000be4:     	and	w0, w0, #0xff
100000be8:     	ldr	x19, [sp, #0x10]
100000bec:     	ldp	x29, x30, [sp], #0x50
100000bf0:     	ret

0000000100000bf4 <_record_event>:
100000bf4:     	sub	sp, sp, #0x10
100000bf8:     	str	w0, [sp, #0xc]
100000bfc:     	adrp	x0, 0x100008000 <_memory>
100000c00:     	add	x0, x0, #0xc
100000c04:     	ldr	w1, [x0]
100000c08:     	mov	w0, w1
100000c0c:     	lsl	w0, w0, #5
100000c10:     	add	w1, w0, w1
100000c14:     	ldr	w0, [sp, #0xc]
100000c18:     	eor	w1, w1, w0
100000c1c:     	adrp	x0, 0x100008000 <_memory>
100000c20:     	add	x0, x0, #0xc
100000c24:     	str	w1, [x0]
100000c28:     	nop
100000c2c:     	add	sp, sp, #0x10
100000c30:     	ret

0000000100000c34 <_next_value>:
100000c34:     	stp	x29, x30, [sp, #-0x20]!
100000c38:     	mov	x29, sp
100000c3c:     	str	w0, [x29, #0x1c]
100000c40:     	ldr	w0, [x29, #0x1c]
100000c44:     	bl	0x100000bf4 <_record_event>
100000c48:     	adrp	x0, 0x100008000 <_memory>
100000c4c:     	add	x0, x0, #0x0
100000c50:     	ldr	w1, [x0, #0x4]
100000c54:     	ldr	w0, [x29, #0x1c]
100000c58:     	add	w1, w1, w0
100000c5c:     	adrp	x0, 0x100008000 <_memory>
100000c60:     	add	x0, x0, #0x0
100000c64:     	str	w1, [x0, #0x4]
100000c68:     	adrp	x0, 0x100008000 <_memory>
100000c6c:     	add	x0, x0, #0x0
100000c70:     	ldr	w1, [x0, #0x4]
100000c74:     	ldr	w0, [x29, #0x1c]
100000c78:     	add	w0, w1, w0
100000c7c:     	ldp	x29, x30, [sp], #0x20
100000c80:     	ret

0000000100000c84 <_main>:
100000c84:     	sub	sp, sp, #0x90
100000c88:     	stp	x29, x30, [sp, #0x30]
100000c8c:     	add	x29, sp, #0x30
100000c90:     	str	w0, [x29, #0x1c]
100000c94:     	str	x1, [x29, #0x10]
100000c98:     	ldr	w0, [x29, #0x1c]
100000c9c:     	cmp	w0, #0x3
100000ca0:     	b.eq	0x100000cac <_main+0x28>
100000ca4:     	mov	w0, #0x2                ; =2
100000ca8:     	b	0x100000ea0 <_main+0x21c>
100000cac:     	ldr	x0, [x29, #0x10]
100000cb0:     	add	x0, x0, #0x8
100000cb4:     	ldr	x0, [x0]
100000cb8:     	mov	w2, #0xa                ; =10
100000cbc:     	mov	x1, #0x0                ; =0
100000cc0:     	bl	0x100000ec4 <_strtoul+0x100000ec4>
100000cc4:     	str	x0, [x29, #0x48]
100000cc8:     	ldr	x0, [x29, #0x10]
100000ccc:     	add	x0, x0, #0x10
100000cd0:     	ldr	x0, [x0]
100000cd4:     	mov	w2, #0xa                ; =10
100000cd8:     	mov	x1, #0x0                ; =0
100000cdc:     	bl	0x100000ec4 <_strtoul+0x100000ec4>
100000ce0:     	str	w0, [x29, #0x5c]
100000ce4:     	str	wzr, [x29, #0x58]
100000ce8:     	add	x0, x29, #0x30
100000cec:     	mov	x1, x0
100000cf0:     	mov	w0, #0x6                ; =6
100000cf4:     	bl	0x100000eac <_strtoul+0x100000eac>
100000cf8:     	cmp	w0, #0x0
100000cfc:     	b.eq	0x100000d08 <_main+0x84>
100000d00:     	mov	w0, #0x2                ; =2
100000d04:     	b	0x100000ea0 <_main+0x21c>
100000d08:     	str	xzr, [x29, #0x50]
100000d0c:     	b	0x100000dd0 <_main+0x14c>
100000d10:     	ldr	w0, [x29, #0x5c]
100000d14:     	lsl	w0, w0, #13
100000d18:     	ldr	w1, [x29, #0x5c]
100000d1c:     	eor	w0, w1, w0
100000d20:     	str	w0, [x29, #0x5c]
100000d24:     	ldr	w0, [x29, #0x5c]
100000d28:     	lsr	w0, w0, #17
100000d2c:     	ldr	w1, [x29, #0x5c]
100000d30:     	eor	w0, w1, w0
100000d34:     	str	w0, [x29, #0x5c]
100000d38:     	ldr	w0, [x29, #0x5c]
100000d3c:     	lsl	w0, w0, #5
100000d40:     	ldr	w1, [x29, #0x5c]
100000d44:     	eor	w0, w1, w0
100000d48:     	str	w0, [x29, #0x5c]
100000d4c:     	ldr	x2, [x29, #0x50]
100000d50:     	mov	x0, #-0x3333333333333334 ; =-3689348814741910324
100000d54:     	movk	x0, #0xcccd
100000d58:     	umulh	x0, x2, x0
100000d5c:     	lsr	x1, x0, #3
100000d60:     	mov	x0, x1
100000d64:     	lsl	x0, x0, #2
100000d68:     	add	x0, x0, x1
100000d6c:     	lsl	x0, x0, #1
100000d70:     	sub	x1, x2, x0
100000d74:     	mov	w0, w1
100000d78:     	sub	w0, w0, #0x1
100000d7c:     	mov	w2, w0
100000d80:     	ldr	w1, [x29, #0x5c]
100000d84:     	adrp	x0, 0x100008000 <_memory>
100000d88:     	add	x0, x0, #0x0
100000d8c:     	bl	0x100000648 <_region_pipeline>
100000d90:     	mov	w1, w0
100000d94:     	ldr	w0, [x29, #0x58]
100000d98:     	add	w0, w0, w1
100000d9c:     	str	w0, [x29, #0x58]
100000da0:     	ldr	w2, [x29, #0x58]
100000da4:     	ldr	w1, [x29, #0x5c]
100000da8:     	adrp	x0, 0x100008000 <_memory>
100000dac:     	add	x0, x0, #0x0
100000db0:     	bl	0x100000a10 <_region_outputs>
100000db4:     	mov	w1, w0
100000db8:     	ldr	w0, [x29, #0x58]
100000dbc:     	add	w0, w0, w1
100000dc0:     	str	w0, [x29, #0x58]
100000dc4:     	ldr	x0, [x29, #0x50]
100000dc8:     	add	x0, x0, #0x1
100000dcc:     	str	x0, [x29, #0x50]
100000dd0:     	ldr	x1, [x29, #0x50]
100000dd4:     	ldr	x0, [x29, #0x48]
100000dd8:     	cmp	x1, x0
100000ddc:     	b.lo	0x100000d10 <_main+0x8c>
100000de0:     	add	x0, x29, #0x20
100000de4:     	mov	x1, x0
100000de8:     	mov	w0, #0x6                ; =6
100000dec:     	bl	0x100000eac <_strtoul+0x100000eac>
100000df0:     	cmp	w0, #0x0
100000df4:     	b.eq	0x100000e00 <_main+0x17c>
100000df8:     	mov	w0, #0x2                ; =2
100000dfc:     	b	0x100000ea0 <_main+0x21c>
100000e00:     	ldr	x1, [x29, #0x20]
100000e04:     	ldr	x0, [x29, #0x30]
100000e08:     	sub	x0, x1, x0
100000e0c:     	fmov	d31, x0
100000e10:     	scvtf	d30, d31
100000e14:     	ldr	x1, [x29, #0x28]
100000e18:     	ldr	x0, [x29, #0x38]
100000e1c:     	sub	x0, x1, x0
100000e20:     	fmov	d31, x0
100000e24:     	scvtf	d29, d31
100000e28:     	adrp	x0, 0x100000000 <_strtoul+0x100000000>
100000e2c:     	add	x0, x0, #0xee8
100000e30:     	ldr	d31, [x0]
100000e34:     	fmul	d31, d29, d31
100000e38:     	fadd	d31, d30, d31
100000e3c:     	str	d31, [x29, #0x40]
100000e40:     	adrp	x0, 0x100008000 <_memory>
100000e44:     	add	x0, x0, #0x0
100000e48:     	ldr	w1, [x0]
100000e4c:     	adrp	x0, 0x100008000 <_memory>
100000e50:     	add	x0, x0, #0x0
100000e54:     	ldr	w2, [x0, #0x4]
100000e58:     	adrp	x0, 0x100008000 <_memory>
100000e5c:     	add	x0, x0, #0x0
100000e60:     	ldr	w3, [x0, #0x8]
100000e64:     	adrp	x0, 0x100008000 <_memory>
100000e68:     	add	x0, x0, #0xc
100000e6c:     	ldr	w0, [x0]
100000e70:     	str	w0, [sp, #0x28]
100000e74:     	str	w3, [sp, #0x20]
100000e78:     	str	w2, [sp, #0x18]
100000e7c:     	str	w1, [sp, #0x10]
100000e80:     	ldr	w0, [x29, #0x58]
100000e84:     	str	w0, [sp, #0x8]
100000e88:     	ldr	d31, [x29, #0x40]
100000e8c:     	str	d31, [sp]
100000e90:     	adrp	x0, 0x100000000 <_strtoul+0x100000000>
100000e94:     	add	x0, x0, #0xed0
100000e98:     	bl	0x100000eb8 <_strtoul+0x100000eb8>
100000e9c:     	mov	w0, #0x0                ; =0
100000ea0:     	ldp	x29, x30, [sp, #0x30]
100000ea4:     	add	sp, sp, #0x90
100000ea8:     	ret

Disassembly of section __TEXT,__stubs:

0000000100000eac <__stubs>:
100000eac:     	adrp	x16, 0x100004000 <_strtoul+0x100004000>
100000eb0:     	ldr	x16, [x16]
100000eb4:     	br	x16
100000eb8:     	adrp	x16, 0x100004000 <_strtoul+0x100004000>
100000ebc:     	ldr	x16, [x16, #0x8]
100000ec0:     	br	x16
100000ec4:     	adrp	x16, 0x100004000 <_strtoul+0x100004000>
100000ec8:     	ldr	x16, [x16, #0x10]
100000ecc:     	br	x16
