#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wpedantic"
typedef signed char int8_t;
typedef short int16_t;
typedef int int32_t;
typedef long long int64_t;
typedef unsigned char uint8_t;
typedef unsigned short uint16_t;
typedef unsigned int uint32_t;
typedef unsigned long long uint64_t;
typedef int8_t int_least8_t;
typedef int16_t int_least16_t;
typedef int32_t int_least32_t;
typedef int64_t int_least64_t;
typedef uint8_t uint_least8_t;
typedef uint16_t uint_least16_t;
typedef uint32_t uint_least32_t;
typedef uint64_t uint_least64_t;
typedef int8_t int_fast8_t;
typedef int16_t int_fast16_t;
typedef int32_t int_fast32_t;
typedef int64_t int_fast64_t;
typedef uint8_t uint_fast8_t;
typedef uint16_t uint_fast16_t;
typedef uint32_t uint_fast32_t;
typedef uint64_t uint_fast64_t;
typedef signed char __int8_t;
typedef unsigned char __uint8_t;
typedef short __int16_t;
typedef unsigned short __uint16_t;
typedef int __int32_t;
typedef unsigned int __uint32_t;
typedef long long __int64_t;
typedef unsigned long long __uint64_t;
typedef long __darwin_intptr_t;
typedef unsigned int __darwin_natural_t;
typedef int __darwin_ct_rune_t;
typedef union {
 char __mbstate8[128];
 long long _mbstateL;
} __mbstate_t;
typedef __mbstate_t __darwin_mbstate_t;
typedef long int __darwin_ptrdiff_t;
typedef long unsigned int __darwin_size_t;
typedef __builtin_va_list __darwin_va_list;
typedef int __darwin_wchar_t;
typedef __darwin_wchar_t __darwin_rune_t;
typedef int __darwin_wint_t;
typedef unsigned long __darwin_clock_t;
typedef __uint32_t __darwin_socklen_t;
typedef long __darwin_ssize_t;
typedef long __darwin_time_t;
typedef __int64_t __darwin_blkcnt_t;
typedef __int32_t __darwin_blksize_t;
typedef __int32_t __darwin_dev_t;
typedef unsigned int __darwin_fsblkcnt_t;
typedef unsigned int __darwin_fsfilcnt_t;
typedef __uint32_t __darwin_gid_t;
typedef __uint32_t __darwin_id_t;
typedef __uint64_t __darwin_ino64_t;
typedef __darwin_ino64_t __darwin_ino_t;
typedef __darwin_natural_t __darwin_mach_port_name_t;
typedef __darwin_mach_port_name_t __darwin_mach_port_t;
typedef __uint16_t __darwin_mode_t;
typedef __int64_t __darwin_off_t;
typedef __int32_t __darwin_pid_t;
typedef __uint32_t __darwin_sigset_t;
typedef __int32_t __darwin_suseconds_t;
typedef __uint32_t __darwin_uid_t;
typedef __uint32_t __darwin_useconds_t;
typedef unsigned char __darwin_uuid_t[16];
typedef char __darwin_uuid_string_t[37];
struct __darwin_pthread_handler_rec {
 void (*__routine)(void *);
 void *__arg;
 struct __darwin_pthread_handler_rec *__next;
};
struct _opaque_pthread_attr_t {
 long __sig;
 char __opaque[56];
};
struct _opaque_pthread_cond_t {
 long __sig;
 char __opaque[40];
};
struct _opaque_pthread_condattr_t {
 long __sig;
 char __opaque[8];
};
struct _opaque_pthread_mutex_t {
 long __sig;
 char __opaque[56];
};
struct _opaque_pthread_mutexattr_t {
 long __sig;
 char __opaque[8];
};
struct _opaque_pthread_once_t {
 long __sig;
 char __opaque[8];
};
struct _opaque_pthread_rwlock_t {
 long __sig;
 char __opaque[192];
};
struct _opaque_pthread_rwlockattr_t {
 long __sig;
 char __opaque[16];
};
struct _opaque_pthread_t {
 long __sig;
 struct __darwin_pthread_handler_rec *__cleanup_stack;
 char __opaque[8176];
};
typedef struct _opaque_pthread_attr_t __darwin_pthread_attr_t;
typedef struct _opaque_pthread_cond_t __darwin_pthread_cond_t;
typedef struct _opaque_pthread_condattr_t __darwin_pthread_condattr_t;
typedef unsigned long __darwin_pthread_key_t;
typedef struct _opaque_pthread_mutex_t __darwin_pthread_mutex_t;
typedef struct _opaque_pthread_mutexattr_t __darwin_pthread_mutexattr_t;
typedef struct _opaque_pthread_once_t __darwin_pthread_once_t;
typedef struct _opaque_pthread_rwlock_t __darwin_pthread_rwlock_t;
typedef struct _opaque_pthread_rwlockattr_t __darwin_pthread_rwlockattr_t;
typedef struct _opaque_pthread_t *__darwin_pthread_t;
typedef __darwin_intptr_t intptr_t;
typedef unsigned long uintptr_t;
typedef long int intmax_t;
typedef long unsigned int uintmax_t;
#pragma GCC diagnostic pop
extern uint32_t next_value(uint32_t value);
extern void record_event(uint32_t value);
uint32_t region_pipeline(uint32_t *buffer, uint32_t x, int limit)
{
    uint32_t y = buffer[0];
    unsigned int csrd_frame_4218_0 = ((252953173u * (x)) + 4134504784u); unsigned int csrd_frame_4218_1 = ((252953173u * (y)) + 4134504784u); unsigned int csrd_frame_4218_2 = (((csrd_frame_4218_0) + (csrd_frame_4218_1)) - 4134504784u); unsigned int csrd_frame_4218_3 = (((((3u * (csrd_frame_4218_2)) + 320925024u)) + (2622022391u)) - 4134504784u); csrd_frame_4218_0 = (((csrd_frame_4218_3) - (csrd_frame_4218_1)) + 4134504784u); x = (3392875261u * ((csrd_frame_4218_0) - 4134504784u)); register unsigned int sum = (3392875261u * ((csrd_frame_4218_2) - 4134504784u)); (void)sum; unsigned int bias = (3392875261u * ((csrd_frame_4218_3) - 4134504784u)); (void)bias

;
    record_event(sum);
    if (limit < 0) return x;
    while (limit-- > 0) {
        y = next_value(x);
        {
            unsigned int csrd_frame_4430_0 = ((3409623381u * (x)) + 2154098675u); unsigned int csrd_frame_4430_1 = ((3409623381u * (y)) + 2154098675u); unsigned int csrd_frame_4430_2 = ((3409623381u * (bias)) + 2154098675u); unsigned int csrd_frame_4430_3 = ((3409623381u * (sum)) + 2154098675u); csrd_frame_4430_0 = (((csrd_frame_4430_0) + (csrd_frame_4430_1)) - 2154098675u); unsigned int csrd_frame_4430_4 = (((csrd_frame_4430_2) + (((5u * (csrd_frame_4430_1)) + 4268507188u))) - 2154098675u); unsigned int csrd_frame_4430_5 = (((csrd_frame_4430_4) - (csrd_frame_4430_1)) + 2154098675u); csrd_frame_4430_2 = (((csrd_frame_4430_5) + (csrd_frame_4430_3)) - 2154098675u); x = (71269373u * ((csrd_frame_4430_0) - 2154098675u)); bias = (71269373u * ((csrd_frame_4430_2) - 2154098675u)); unsigned int x = (71269373u * ((csrd_frame_4430_4) - 2154098675u)); (void)x; unsigned int local = (71269373u * ((csrd_frame_4430_5) - 2154098675u)); (void)local


;
            record_event(x);
            { unsigned int csrd_frame_4590_0 = ((2760058791u * (x)) + 1048912143u); csrd_frame_4590_0 = (((csrd_frame_4590_0) + (3189454496u)) - 1048912143u); x = (1408962583u * ((csrd_frame_4590_0) - 1048912143u));}
            buffer[0] = x;
        }
        { unsigned int csrd_frame_4647_0 = ((1848965353u * (x)) + 2871147789u); unsigned int csrd_frame_4647_1 = ((1848965353u * (bias)) + 2871147789u); csrd_frame_4647_0 = (((csrd_frame_4647_0) + (csrd_frame_4647_1)) - 2871147789u); x = (3944701785u * ((csrd_frame_4647_0) - 2871147789u));}
        record_event(y);
    }
    return x;
}
int region_outputs(uint32_t *buffer, uint32_t x, uint32_t y)
{
    unsigned int csrd_frame_4775_0 = ((2664513973u * (x)) + 1780257379u); unsigned int csrd_frame_4775_1 = ((2664513973u * (y)) + 1780257379u); unsigned int csrd_frame_4775_2 = 4127321960u; unsigned int csrd_frame_4775_3 = (((csrd_frame_4775_2) + (csrd_frame_4775_0)) - 1780257379u); csrd_frame_4775_0 = (((((3u * (csrd_frame_4775_3)) + 734452538u)) + (csrd_frame_4775_1)) - 1780257379u); csrd_frame_4775_1 = (((csrd_frame_4775_0) - (csrd_frame_4775_2)) + 1780257379u); x = (3959448733u * ((csrd_frame_4775_0) - 1780257379u)); y = (3959448733u * ((csrd_frame_4775_1) - 1780257379u)); register unsigned int pending = (3959448733u * ((csrd_frame_4775_2) - 1780257379u)); (void)pending; unsigned int mix = (3959448733u * ((csrd_frame_4775_3) - 1780257379u)); (void)mix


;
    record_event(x);
    {
        unsigned int csrd_frame_4918_0 = ((550455605u * (x)) + 2316382722u); unsigned int csrd_frame_4918_1 = (((csrd_frame_4918_0) + (1874604661u)) - 2316382722u); unsigned int y = (926777629u * ((csrd_frame_4918_1) - 2316382722u)); (void)y;
        buffer[2] = y;
    }
    buffer[0] = y;
    buffer[1] = pending;
    return x == y;
}
