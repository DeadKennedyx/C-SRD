
/Users/admin/C-SRD/experiments/runs/private-declarations-cost-native-20261110/clang-Os/identity:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000100000548 <_region_pipeline>:
100000548:     	stp	x26, x25, [sp, #-0x50]!
10000054c:     	stp	x24, x23, [sp, #0x10]
100000550:     	stp	x22, x21, [sp, #0x20]
100000554:     	stp	x20, x19, [sp, #0x30]
100000558:     	stp	x29, x30, [sp, #0x40]
10000055c:     	add	x29, sp, #0x40
100000560:     	mov	x22, x2
100000564:     	mov	x19, x0
100000568:     	ldr	w8, [x0]
10000056c:     	add	w20, w8, w1
100000570:     	add	w9, w20, w20, lsl #1
100000574:     	add	w23, w9, #0xb
100000578:     	sub	w21, w23, w8
10000057c:     	mov	x0, x20
100000580:     	bl	0x100000640 <_record_event>
100000584:     	cmp	w22, #0x1
100000588:     	b.lt	0x1000005d8 <_region_pipeline+0x90>
10000058c:     	add	w24, w22, #0x1
100000590:     	mov	x0, x21
100000594:     	bl	0x100000658 <_next_value>
100000598:     	mov	x22, x0
10000059c:     	add	w25, w0, w21
1000005a0:     	add	w8, w0, w0, lsl #2
1000005a4:     	add	w21, w8, w23
1000005a8:     	sub	w8, w21, w0
1000005ac:     	add	w23, w8, w20
1000005b0:     	mov	x0, x21
1000005b4:     	bl	0x100000640 <_record_event>
1000005b8:     	add	w8, w21, #0x7
1000005bc:     	str	w8, [x19]
1000005c0:     	add	w21, w25, w23
1000005c4:     	mov	x0, x22
1000005c8:     	bl	0x100000640 <_record_event>
1000005cc:     	sub	w24, w24, #0x1
1000005d0:     	cmp	w24, #0x1
1000005d4:     	b.hi	0x100000590 <_region_pipeline+0x48>
1000005d8:     	mov	x0, x21
1000005dc:     	ldp	x29, x30, [sp, #0x40]
1000005e0:     	ldp	x20, x19, [sp, #0x30]
1000005e4:     	ldp	x22, x21, [sp, #0x20]
1000005e8:     	ldp	x24, x23, [sp, #0x10]
1000005ec:     	ldp	x26, x25, [sp], #0x50
1000005f0:     	ret

00000001000005f4 <_region_outputs>:
1000005f4:     	stp	x22, x21, [sp, #-0x30]!
1000005f8:     	stp	x20, x19, [sp, #0x10]
1000005fc:     	stp	x29, x30, [sp, #0x20]
100000600:     	add	x29, sp, #0x20
100000604:     	mov	x19, x0
100000608:     	add	w8, w1, w1, lsl #1
10000060c:     	add	w20, w8, w2
100000610:     	add	w21, w20, #0x22
100000614:     	add	w0, w20, #0x33
100000618:     	bl	0x100000640 <_record_event>
10000061c:     	add	w9, w20, #0x3a
100000620:     	mov	w8, #0x11               ; =17
100000624:     	str	w21, [x19]
100000628:     	stp	w8, w9, [x19, #0x4]
10000062c:     	mov	w0, #0x0                ; =0
100000630:     	ldp	x29, x30, [sp, #0x20]
100000634:     	ldp	x20, x19, [sp, #0x10]
100000638:     	ldp	x22, x21, [sp], #0x30
10000063c:     	ret

0000000100000640 <_record_event>:
100000640:     	adrp	x8, 0x100008000 <_event_hash>
100000644:     	ldr	w9, [x8]
100000648:     	add	w9, w9, w9, lsl #5
10000064c:     	eor	w9, w9, w0
100000650:     	str	w9, [x8]
100000654:     	ret

0000000100000658 <_next_value>:
100000658:     	adrp	x8, 0x100008000 <_event_hash>
10000065c:     	ldr	w9, [x8]
100000660:     	add	w9, w9, w9, lsl #5
100000664:     	eor	w9, w9, w0
100000668:     	str	w9, [x8]
10000066c:     	adrp	x8, 0x100008000 <_event_hash>
100000670:     	ldr	w9, [x8, #0x8]
100000674:     	add	w9, w9, w0
100000678:     	add	w0, w9, w0
10000067c:     	str	w9, [x8, #0x8]
100000680:     	ret

0000000100000684 <_main>:
100000684:     	cmp	w0, #0x3
100000688:     	b.ne	0x100000758 <_main+0xd4>
10000068c:     	sub	sp, sp, #0xa0
100000690:     	stp	x26, x25, [sp, #0x50]
100000694:     	stp	x24, x23, [sp, #0x60]
100000698:     	stp	x22, x21, [sp, #0x70]
10000069c:     	stp	x20, x19, [sp, #0x80]
1000006a0:     	stp	x29, x30, [sp, #0x90]
1000006a4:     	add	x29, sp, #0x90
1000006a8:     	mov	x20, x1
1000006ac:     	ldr	x0, [x1, #0x8]
1000006b0:     	mov	x1, #0x0                ; =0
1000006b4:     	mov	w2, #0xa                ; =10
1000006b8:     	bl	0x10000080c <_strtoul+0x10000080c>
1000006bc:     	mov	x19, x0
1000006c0:     	ldr	x0, [x20, #0x10]
1000006c4:     	mov	x1, #0x0                ; =0
1000006c8:     	mov	w2, #0xa                ; =10
1000006cc:     	bl	0x10000080c <_strtoul+0x10000080c>
1000006d0:     	mov	x20, x0
1000006d4:     	add	x1, sp, #0x40
1000006d8:     	mov	w0, #0x6                ; =6
1000006dc:     	bl	0x1000007f4 <_strtoul+0x1000007f4>
1000006e0:     	cbnz	w0, 0x100000774 <_main+0xf0>
1000006e4:     	cbz	x19, 0x100000760 <_main+0xdc>
1000006e8:     	mov	x23, #0x0               ; =0
1000006ec:     	mov	w22, #0x0               ; =0
1000006f0:     	mov	w24, #-0x1              ; =-1
1000006f4:     	mov	x25, #-0x3333333333333334 ; =-3689348814741910324
1000006f8:     	movk	x25, #0xcccd
1000006fc:     	mov	w26, #0xa               ; =10
100000700:     	adrp	x21, 0x100008000 <_event_hash>
100000704:     	add	x21, x21, #0x4
100000708:     	umulh	x8, x23, x25
10000070c:     	lsr	x8, x8, #3
100000710:     	msub	w2, w8, w26, w24
100000714:     	eor	w8, w20, w20, lsl #13
100000718:     	eor	w8, w8, w8, lsr #17
10000071c:     	eor	w20, w8, w8, lsl #5
100000720:     	mov	x0, x21
100000724:     	mov	x1, x20
100000728:     	bl	0x100000548 <_region_pipeline>
10000072c:     	add	w22, w0, w22
100000730:     	mov	x0, x21
100000734:     	mov	x1, x20
100000738:     	mov	x2, x22
10000073c:     	bl	0x1000005f4 <_region_outputs>
100000740:     	add	w22, w22, w0
100000744:     	add	x23, x23, #0x1
100000748:     	add	w24, w24, #0x1
10000074c:     	subs	x19, x19, #0x1
100000750:     	b.ne	0x100000708 <_main+0x84>
100000754:     	b	0x100000764 <_main+0xe0>
100000758:     	mov	w0, #0x2                ; =2
10000075c:     	ret
100000760:     	mov	w22, #0x0               ; =0
100000764:     	add	x1, sp, #0x30
100000768:     	mov	w0, #0x6                ; =6
10000076c:     	bl	0x1000007f4 <_strtoul+0x1000007f4>
100000770:     	cbz	w0, 0x100000794 <_main+0x110>
100000774:     	mov	w0, #0x2                ; =2
100000778:     	ldp	x29, x30, [sp, #0x90]
10000077c:     	ldp	x20, x19, [sp, #0x80]
100000780:     	ldp	x22, x21, [sp, #0x70]
100000784:     	ldp	x24, x23, [sp, #0x60]
100000788:     	ldp	x26, x25, [sp, #0x50]
10000078c:     	add	sp, sp, #0xa0
100000790:     	ret
100000794:     	ldp	x8, x9, [sp, #0x30]
100000798:     	ldp	x10, x11, [sp, #0x40]
10000079c:     	sub	x8, x8, x10
1000007a0:     	adrp	x10, 0x100008000 <_event_hash>
1000007a4:     	add	x10, x10, #0x4
1000007a8:     	scvtf	d0, x8
1000007ac:     	sub	x8, x9, x11
1000007b0:     	scvtf	d1, x8
1000007b4:     	adrp	x8, 0x100000000 <_strtoul+0x100000000>
1000007b8:     	ldr	d2, [x8, #0x818]
1000007bc:     	fmadd	d0, d1, d2, d0
1000007c0:     	ldp	w8, w9, [x10]
1000007c4:     	ldr	w10, [x10, #0x8]
1000007c8:     	adrp	x11, 0x100008000 <_event_hash>
1000007cc:     	ldr	w11, [x11]
1000007d0:     	stp	x10, x11, [sp, #0x20]
1000007d4:     	stp	x8, x9, [sp, #0x10]
1000007d8:     	str	x22, [sp, #0x8]
1000007dc:     	str	d0, [sp]
1000007e0:     	adrp	x0, 0x100000000 <_strtoul+0x100000000>
1000007e4:     	add	x0, x0, #0x820
1000007e8:     	bl	0x100000800 <_strtoul+0x100000800>
1000007ec:     	mov	w0, #0x0                ; =0
1000007f0:     	b	0x100000778 <_main+0xf4>

Disassembly of section __TEXT,__stubs:

00000001000007f4 <__stubs>:
1000007f4:     	adrp	x16, 0x100004000 <_strtoul+0x100004000>
1000007f8:     	ldr	x16, [x16]
1000007fc:     	br	x16
100000800:     	adrp	x16, 0x100004000 <_strtoul+0x100004000>
100000804:     	ldr	x16, [x16, #0x8]
100000808:     	br	x16
10000080c:     	adrp	x16, 0x100004000 <_strtoul+0x100004000>
100000810:     	ldr	x16, [x16, #0x10]
100000814:     	br	x16
