
/Users/admin/C-SRD/experiments/runs/private-declarations-cost-native-20261110/clang-Os/affine:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000100000548 <_region_pipeline>:
100000548:     	stp	x28, x27, [sp, #-0x60]!
10000054c:     	stp	x26, x25, [sp, #0x10]
100000550:     	stp	x24, x23, [sp, #0x20]
100000554:     	stp	x22, x21, [sp, #0x30]
100000558:     	stp	x20, x19, [sp, #0x40]
10000055c:     	stp	x29, x30, [sp, #0x50]
100000560:     	add	x29, sp, #0x50
100000564:     	mov	x21, x2
100000568:     	mov	x19, x0
10000056c:     	ldr	w8, [x0]
100000570:     	mov	w9, #0xcc3f             ; =52287
100000574:     	movk	w9, #0xdfc3, lsl #16
100000578:     	mul	w10, w8, w9
10000057c:     	madd	w9, w1, w9, w10
100000580:     	mov	w11, #0x5bcf            ; =23503
100000584:     	movk	w11, #0x8510, lsl #16
100000588:     	add	w24, w9, w11
10000058c:     	add	w9, w24, w24, lsl #1
100000590:     	sub	w9, w9, w10
100000594:     	mov	w10, #0x23bf            ; =9151
100000598:     	movk	w10, #0x7082, lsl #16
10000059c:     	mov	w11, #0x9ab8            ; =39608
1000005a0:     	movk	w11, #0xe760, lsl #16
1000005a4:     	madd	w20, w9, w10, w11
1000005a8:     	add	w22, w8, w1
1000005ac:     	mov	x0, x22
1000005b0:     	bl	0x1000006e4 <_record_event>
1000005b4:     	cmp	w21, #0x1
1000005b8:     	b.lt	0x10000065c <_region_pipeline+0x114>
1000005bc:     	mov	w23, #0xb211            ; =45585
1000005c0:     	movk	w23, #0xda25, lsl #16
1000005c4:     	mov	w8, #0x7ef1             ; =32497
1000005c8:     	movk	w8, #0x67ef, lsl #16
1000005cc:     	mov	w9, #0xfa6d             ; =64109
1000005d0:     	movk	w9, #0x9145, lsl #16
1000005d4:     	mov	w10, #0x3738            ; =14136
1000005d8:     	movk	w10, #0xd7e0, lsl #16
1000005dc:     	madd	w26, w24, w9, w10
1000005e0:     	mov	w9, #0x21f4             ; =8692
1000005e4:     	movk	w9, #0x6258, lsl #16
1000005e8:     	madd	w22, w22, w8, w9
1000005ec:     	add	w25, w21, #0x1
1000005f0:     	mov	w28, #0x7ab5            ; =31413
1000005f4:     	movk	w28, #0x7ad, lsl #16
1000005f8:     	mov	w24, #0xde0c            ; =56844
1000005fc:     	movk	w24, #0x9da7, lsl #16
100000600:     	mov	x0, x20
100000604:     	bl	0x1000006fc <_next_value>
100000608:     	mov	x21, x0
10000060c:     	madd	w8, w0, w28, w26
100000610:     	mov	w9, #0x810f             ; =33039
100000614:     	movk	w9, #0x9810, lsl #16
100000618:     	madd	w9, w0, w9, w22
10000061c:     	add	w8, w8, w24
100000620:     	add	w26, w9, w8
100000624:     	add	w27, w0, w20
100000628:     	mov	w9, #0xe934             ; =59700
10000062c:     	movk	w9, #0x7fb9, lsl #16
100000630:     	madd	w20, w8, w23, w9
100000634:     	mov	x0, x20
100000638:     	bl	0x1000006e4 <_record_event>
10000063c:     	add	w8, w20, #0x7
100000640:     	str	w8, [x19]
100000644:     	madd	w20, w26, w23, w27
100000648:     	mov	x0, x21
10000064c:     	bl	0x1000006e4 <_record_event>
100000650:     	sub	w25, w25, #0x1
100000654:     	cmp	w25, #0x1
100000658:     	b.hi	0x100000600 <_region_pipeline+0xb8>
10000065c:     	mov	x0, x20
100000660:     	ldp	x29, x30, [sp, #0x50]
100000664:     	ldp	x20, x19, [sp, #0x40]
100000668:     	ldp	x22, x21, [sp, #0x30]
10000066c:     	ldp	x24, x23, [sp, #0x20]
100000670:     	ldp	x26, x25, [sp, #0x10]
100000674:     	ldp	x28, x27, [sp], #0x60
100000678:     	ret

000000010000067c <_region_outputs>:
10000067c:     	stp	x22, x21, [sp, #-0x30]!
100000680:     	stp	x20, x19, [sp, #0x10]
100000684:     	stp	x29, x30, [sp, #0x20]
100000688:     	add	x29, sp, #0x20
10000068c:     	mov	x19, x0
100000690:     	mov	w8, #0xcf5b             ; =53083
100000694:     	movk	w8, #0x27d6, lsl #16
100000698:     	mov	w9, #0x6e11             ; =28177
10000069c:     	movk	w9, #0x7784, lsl #16
1000006a0:     	mul	w9, w1, w9
1000006a4:     	madd	w8, w2, w8, w9
1000006a8:     	mov	w9, #0xc8d3             ; =51411
1000006ac:     	movk	w9, #0x1e1c, lsl #16
1000006b0:     	mul	w20, w8, w9
1000006b4:     	add	w21, w20, #0x22
1000006b8:     	add	w0, w20, #0x33
1000006bc:     	bl	0x1000006e4 <_record_event>
1000006c0:     	add	w9, w20, #0x3a
1000006c4:     	mov	w8, #0x11               ; =17
1000006c8:     	str	w21, [x19]
1000006cc:     	stp	w8, w9, [x19, #0x4]
1000006d0:     	mov	w0, #0x0                ; =0
1000006d4:     	ldp	x29, x30, [sp, #0x20]
1000006d8:     	ldp	x20, x19, [sp, #0x10]
1000006dc:     	ldp	x22, x21, [sp], #0x30
1000006e0:     	ret

00000001000006e4 <_record_event>:
1000006e4:     	adrp	x8, 0x100008000 <_event_hash>
1000006e8:     	ldr	w9, [x8]
1000006ec:     	add	w9, w9, w9, lsl #5
1000006f0:     	eor	w9, w9, w0
1000006f4:     	str	w9, [x8]
1000006f8:     	ret

00000001000006fc <_next_value>:
1000006fc:     	adrp	x8, 0x100008000 <_event_hash>
100000700:     	ldr	w9, [x8]
100000704:     	add	w9, w9, w9, lsl #5
100000708:     	eor	w9, w9, w0
10000070c:     	str	w9, [x8]
100000710:     	adrp	x8, 0x100008000 <_event_hash>
100000714:     	ldr	w9, [x8, #0x8]
100000718:     	add	w9, w9, w0
10000071c:     	add	w0, w9, w0
100000720:     	str	w9, [x8, #0x8]
100000724:     	ret

0000000100000728 <_main>:
100000728:     	cmp	w0, #0x3
10000072c:     	b.ne	0x1000007fc <_main+0xd4>
100000730:     	sub	sp, sp, #0xa0
100000734:     	stp	x26, x25, [sp, #0x50]
100000738:     	stp	x24, x23, [sp, #0x60]
10000073c:     	stp	x22, x21, [sp, #0x70]
100000740:     	stp	x20, x19, [sp, #0x80]
100000744:     	stp	x29, x30, [sp, #0x90]
100000748:     	add	x29, sp, #0x90
10000074c:     	mov	x20, x1
100000750:     	ldr	x0, [x1, #0x8]
100000754:     	mov	x1, #0x0                ; =0
100000758:     	mov	w2, #0xa                ; =10
10000075c:     	bl	0x1000008b0 <_strtoul+0x1000008b0>
100000760:     	mov	x19, x0
100000764:     	ldr	x0, [x20, #0x10]
100000768:     	mov	x1, #0x0                ; =0
10000076c:     	mov	w2, #0xa                ; =10
100000770:     	bl	0x1000008b0 <_strtoul+0x1000008b0>
100000774:     	mov	x20, x0
100000778:     	add	x1, sp, #0x40
10000077c:     	mov	w0, #0x6                ; =6
100000780:     	bl	0x100000898 <_strtoul+0x100000898>
100000784:     	cbnz	w0, 0x100000818 <_main+0xf0>
100000788:     	cbz	x19, 0x100000804 <_main+0xdc>
10000078c:     	mov	x23, #0x0               ; =0
100000790:     	mov	w22, #0x0               ; =0
100000794:     	mov	w24, #-0x1              ; =-1
100000798:     	mov	x25, #-0x3333333333333334 ; =-3689348814741910324
10000079c:     	movk	x25, #0xcccd
1000007a0:     	mov	w26, #0xa               ; =10
1000007a4:     	adrp	x21, 0x100008000 <_event_hash>
1000007a8:     	add	x21, x21, #0x4
1000007ac:     	umulh	x8, x23, x25
1000007b0:     	lsr	x8, x8, #3
1000007b4:     	msub	w2, w8, w26, w24
1000007b8:     	eor	w8, w20, w20, lsl #13
1000007bc:     	eor	w8, w8, w8, lsr #17
1000007c0:     	eor	w20, w8, w8, lsl #5
1000007c4:     	mov	x0, x21
1000007c8:     	mov	x1, x20
1000007cc:     	bl	0x100000548 <_region_pipeline>
1000007d0:     	add	w22, w0, w22
1000007d4:     	mov	x0, x21
1000007d8:     	mov	x1, x20
1000007dc:     	mov	x2, x22
1000007e0:     	bl	0x10000067c <_region_outputs>
1000007e4:     	add	w22, w22, w0
1000007e8:     	add	x23, x23, #0x1
1000007ec:     	add	w24, w24, #0x1
1000007f0:     	subs	x19, x19, #0x1
1000007f4:     	b.ne	0x1000007ac <_main+0x84>
1000007f8:     	b	0x100000808 <_main+0xe0>
1000007fc:     	mov	w0, #0x2                ; =2
100000800:     	ret
100000804:     	mov	w22, #0x0               ; =0
100000808:     	add	x1, sp, #0x30
10000080c:     	mov	w0, #0x6                ; =6
100000810:     	bl	0x100000898 <_strtoul+0x100000898>
100000814:     	cbz	w0, 0x100000838 <_main+0x110>
100000818:     	mov	w0, #0x2                ; =2
10000081c:     	ldp	x29, x30, [sp, #0x90]
100000820:     	ldp	x20, x19, [sp, #0x80]
100000824:     	ldp	x22, x21, [sp, #0x70]
100000828:     	ldp	x24, x23, [sp, #0x60]
10000082c:     	ldp	x26, x25, [sp, #0x50]
100000830:     	add	sp, sp, #0xa0
100000834:     	ret
100000838:     	ldp	x8, x9, [sp, #0x30]
10000083c:     	ldp	x10, x11, [sp, #0x40]
100000840:     	sub	x8, x8, x10
100000844:     	adrp	x10, 0x100008000 <_event_hash>
100000848:     	add	x10, x10, #0x4
10000084c:     	scvtf	d0, x8
100000850:     	sub	x8, x9, x11
100000854:     	scvtf	d1, x8
100000858:     	adrp	x8, 0x100000000 <_strtoul+0x100000000>
10000085c:     	ldr	d2, [x8, #0x8c0]
100000860:     	fmadd	d0, d1, d2, d0
100000864:     	ldp	w8, w9, [x10]
100000868:     	ldr	w10, [x10, #0x8]
10000086c:     	adrp	x11, 0x100008000 <_event_hash>
100000870:     	ldr	w11, [x11]
100000874:     	stp	x10, x11, [sp, #0x20]
100000878:     	stp	x8, x9, [sp, #0x10]
10000087c:     	str	x22, [sp, #0x8]
100000880:     	str	d0, [sp]
100000884:     	adrp	x0, 0x100000000 <_strtoul+0x100000000>
100000888:     	add	x0, x0, #0x8c8
10000088c:     	bl	0x1000008a4 <_strtoul+0x1000008a4>
100000890:     	mov	w0, #0x0                ; =0
100000894:     	b	0x10000081c <_main+0xf4>

Disassembly of section __TEXT,__stubs:

0000000100000898 <__stubs>:
100000898:     	adrp	x16, 0x100004000 <_strtoul+0x100004000>
10000089c:     	ldr	x16, [x16]
1000008a0:     	br	x16
1000008a4:     	adrp	x16, 0x100004000 <_strtoul+0x100004000>
1000008a8:     	ldr	x16, [x16, #0x8]
1000008ac:     	br	x16
1000008b0:     	adrp	x16, 0x100004000 <_strtoul+0x100004000>
1000008b4:     	ldr	x16, [x16, #0x10]
1000008b8:     	br	x16
