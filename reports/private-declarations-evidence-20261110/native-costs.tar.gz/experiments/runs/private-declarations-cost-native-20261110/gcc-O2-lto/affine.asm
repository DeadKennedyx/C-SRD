
/Users/admin/C-SRD/experiments/runs/private-declarations-cost-native-20261110/gcc-O2-lto/affine:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001000006a0 <_region_pipeline>:
1000006a0:     	stp	x29, x30, [sp, #-0x40]!
1000006a4:     	mov	x29, sp
1000006a8:     	mov	x11, x0
1000006ac:     	mov	w3, #0xc255             ; =49749
1000006b0:     	mov	w4, #0x8950             ; =35152
1000006b4:     	movk	w3, #0xf13, lsl #16
1000006b8:     	stp	x21, x22, [sp, #0x20]
1000006bc:     	movk	w4, #0xf66f, lsl #16
1000006c0:     	adrp	x21, 0x100008000 <_memory>
1000006c4:     	mov	w6, #0x2bf0             ; =11248
1000006c8:     	movk	w6, #0x61ce, lsl #16
1000006cc:     	ldr	w0, [x0]
1000006d0:     	madd	w0, w0, w3, w4
1000006d4:     	mov	w4, #0x2afd             ; =11005
1000006d8:     	movk	w4, #0xca3b, lsl #16
1000006dc:     	madd	w1, w1, w3, w0
1000006e0:     	mov	w3, #0x4707             ; =18183
1000006e4:     	movk	w3, #0xb8fa, lsl #16
1000006e8:     	add	w5, w1, w1, lsl #1
1000006ec:     	madd	w1, w1, w4, w6
1000006f0:     	add	w5, w5, w3
1000006f4:     	ldr	w3, [x21, #0xc]
1000006f8:     	sub	w0, w5, w0
1000006fc:     	mul	w0, w0, w4
100000700:     	add	w3, w3, w3, lsl #5
100000704:     	eor	w3, w3, w1
100000708:     	str	w3, [x21, #0xc]
10000070c:     	cmp	w2, #0x0
100000710:     	b.le	0x10000081c <_region_pipeline+0x17c>
100000714:     	madd	w5, w5, w4, w6
100000718:     	mov	w6, #0xb955             ; =47445
10000071c:     	mov	w4, #0xdfe6             ; =57318
100000720:     	movk	w6, #0xcb3a, lsl #16
100000724:     	movk	w4, #0xc9, lsl #16
100000728:     	stp	x19, x20, [sp, #0x10]
10000072c:     	mov	w12, #0x1bd9            ; =7129
100000730:     	adrp	x8, 0x100008000 <_memory>
100000734:     	mov	w10, #0xeff3            ; =61427
100000738:     	mov	w20, #0x4034            ; =16436
10000073c:     	madd	w7, w1, w6, w4
100000740:     	mov	w9, #0x7bfd             ; =31741
100000744:     	mov	w19, #0x37b2            ; =14258
100000748:     	str	x23, [sp, #0x30]
10000074c:     	movk	w12, #0xc428, lsl #16
100000750:     	mov	w17, #0xf145            ; =61765
100000754:     	mov	w16, #0x9b1c            ; =39708
100000758:     	mov	w15, #0xf8e9            ; =63721
10000075c:     	mov	w14, #0x5f59            ; =24409
100000760:     	mov	w13, #0xe6f6            ; =59126
100000764:     	sub	w2, w2, #0x1
100000768:     	add	x8, x8, #0x0
10000076c:     	movk	w10, #0x8064, lsl #16
100000770:     	movk	w20, #0xfe6c, lsl #16
100000774:     	movk	w9, #0x43f, lsl #16
100000778:     	movk	w19, #0x8850, lsl #16
10000077c:     	add	w30, w12, #0x7
100000780:     	movk	w17, #0x4348, lsl #16
100000784:     	movk	w16, #0xe963, lsl #16
100000788:     	movk	w15, #0x6e34, lsl #16
10000078c:     	movk	w14, #0xeb1f, lsl #16
100000790:     	movk	w13, #0xf1bb, lsl #16
100000794:     	nop
100000798:     	nop
10000079c:     	nop
1000007a0:     	ldr	w4, [x8, #0x4]
1000007a4:     	add	w3, w3, w3, lsl #5
1000007a8:     	sub	w2, w2, #0x1
1000007ac:     	eor	w3, w3, w0
1000007b0:     	add	w3, w3, w3, lsl #5
1000007b4:     	add	w4, w0, w4
1000007b8:     	str	w4, [x8, #0x4]
1000007bc:     	add	w4, w0, w4
1000007c0:     	madd	w0, w0, w6, w10
1000007c4:     	madd	w22, w4, w6, w10
1000007c8:     	add	w1, w22, w22, lsl #2
1000007cc:     	add	w0, w0, w22
1000007d0:     	add	w1, w1, w20
1000007d4:     	madd	w0, w0, w17, w16
1000007d8:     	madd	w1, w5, w6, w1
1000007dc:     	sub	w5, w7, w22
1000007e0:     	add	w5, w5, w1
1000007e4:     	madd	w23, w1, w9, w12
1000007e8:     	madd	w1, w1, w9, w30
1000007ec:     	madd	w5, w5, w9, w19
1000007f0:     	eor	w3, w3, w23
1000007f4:     	add	w3, w3, w3, lsl #5
1000007f8:     	str	w1, [x11]
1000007fc:     	madd	w0, w5, w15, w0
100000800:     	eor	w3, w3, w4
100000804:     	madd	w0, w0, w14, w13
100000808:     	cmn	w2, #0x1
10000080c:     	b.ne	0x1000007a0 <_region_pipeline+0x100>
100000810:     	ldr	x23, [sp, #0x30]
100000814:     	ldp	x19, x20, [sp, #0x10]
100000818:     	str	w3, [x21, #0xc]
10000081c:     	ldp	x21, x22, [sp, #0x20]
100000820:     	ldp	x29, x30, [sp], #0x40
100000824:     	ret

0000000100000828 <_record_event>:
100000828:     	adrp	x2, 0x100008000 <_memory>
10000082c:     	ldr	w1, [x2, #0xc]
100000830:     	add	w1, w1, w1, lsl #5
100000834:     	eor	w1, w1, w0
100000838:     	str	w1, [x2, #0xc]
10000083c:     	ret

0000000100000840 <_next_value>:
100000840:     	adrp	x2, 0x100008000 <_memory>
100000844:     	ldr	w1, [x2, #0xc]
100000848:     	add	w1, w1, w1, lsl #5
10000084c:     	eor	w1, w1, w0
100000850:     	str	w1, [x2, #0xc]
100000854:     	adrp	x2, 0x100008000 <_memory>
100000858:     	add	x2, x2, #0x0
10000085c:     	ldr	w1, [x2, #0x4]
100000860:     	add	w1, w0, w1
100000864:     	add	w0, w1, w0
100000868:     	str	w1, [x2, #0x4]
10000086c:     	ret

0000000100000870 <_region_outputs>:
100000870:     	mov	w4, #0x41b5             ; =16821
100000874:     	mov	w3, #0x609b             ; =24731
100000878:     	movk	w4, #0x9ed1, lsl #16
10000087c:     	movk	w3, #0x4c22, lsl #16
100000880:     	madd	w2, w2, w4, w3
100000884:     	mov	w3, #0xc51f             ; =50463
100000888:     	adrp	x4, 0x100008000 <_memory>
10000088c:     	movk	w3, #0xdc73, lsl #16
100000890:     	madd	w1, w1, w3, w2
100000894:     	mov	w2, #0x649d             ; =25757
100000898:     	movk	w2, #0xec00, lsl #16
10000089c:     	mul	w1, w1, w2
1000008a0:     	ldr	w2, [x4, #0xc]
1000008a4:     	add	w3, w2, w2, lsl #5
1000008a8:     	mov	w2, #0x3524             ; =13604
1000008ac:     	movk	w2, #0xfd2e, lsl #16
1000008b0:     	add	w5, w1, w2
1000008b4:     	add	w2, w2, #0x7
1000008b8:     	eor	w3, w3, w5
1000008bc:     	str	w3, [x4, #0xc]
1000008c0:     	add	w3, w1, w2
1000008c4:     	sub	w2, w2, #0x18
1000008c8:     	add	w1, w1, w2
1000008cc:     	mov	w2, #0x11               ; =17
1000008d0:     	str	w3, [x0, #0x8]
1000008d4:     	stp	w1, w2, [x0]
1000008d8:     	mov	w0, #0x0                ; =0
1000008dc:     	ret

Disassembly of section __TEXT,__text_startup:

00000001000008e0 <_main>:
1000008e0:     	sub	sp, sp, #0xc0
1000008e4:     	stp	x29, x30, [sp, #0x30]
1000008e8:     	add	x29, sp, #0x30
1000008ec:     	stp	x19, x20, [sp, #0x40]
1000008f0:     	cmp	w0, #0x3
1000008f4:     	b.eq	0x100000910 <_main+0x30>
1000008f8:     	mov	w19, #0x2               ; =2
1000008fc:     	ldp	x29, x30, [sp, #0x30]
100000900:     	mov	w0, w19
100000904:     	ldp	x19, x20, [sp, #0x40]
100000908:     	add	sp, sp, #0xc0
10000090c:     	ret
100000910:     	mov	x19, x1
100000914:     	mov	w2, #0xa                ; =10
100000918:     	stp	x21, x22, [x29, #0x20]
10000091c:     	mov	x1, #0x0                ; =0
100000920:     	ldr	x0, [x19, #0x8]
100000924:     	bl	0x100000af0 <_strtoul+0x100000af0>
100000928:     	mov	x1, #0x0                ; =0
10000092c:     	mov	x21, x0
100000930:     	ldr	x0, [x19, #0x10]
100000934:     	mov	w2, #0xa                ; =10
100000938:     	bl	0x100000af0 <_strtoul+0x100000af0>
10000093c:     	mov	x19, x0
100000940:     	add	x1, x29, #0x80
100000944:     	mov	w0, #0x6                ; =6
100000948:     	bl	0x100000ad8 <_strtoul+0x100000ad8>
10000094c:     	cbnz	w0, 0x100000ac8 <_main+0x1e8>
100000950:     	stp	x27, x28, [x29, #0x50]
100000954:     	cbz	x21, 0x100000ad0 <_main+0x1f0>
100000958:     	mov	w20, #0x3524            ; =13604
10000095c:     	mov	x27, #0x0               ; =0
100000960:     	movk	w20, #0xfd2e, lsl #16
100000964:     	stp	x23, x24, [x29, #0x30]
100000968:     	mov	w24, #0xc51f            ; =50463
10000096c:     	add	w0, w20, #0x7
100000970:     	mov	w28, #0x0               ; =0
100000974:     	adrp	x22, 0x100008000 <_memory>
100000978:     	movk	w24, #0xdc73, lsl #16
10000097c:     	stp	x25, x26, [x29, #0x40]
100000980:     	mov	x25, #-0x3333333333333334 ; =-3689348814741910324
100000984:     	adrp	x26, 0x100008000 <_memory>
100000988:     	movk	x25, #0xcccd
10000098c:     	str	w0, [x29, #0x6c]
100000990:     	umulh	x2, x27, x25
100000994:     	add	x23, x26, #0x0
100000998:     	eor	w19, w19, w19, lsl #13
10000099c:     	mov	x0, x23
1000009a0:     	lsr	x2, x2, #3
1000009a4:     	eor	w19, w19, w19, lsr #17
1000009a8:     	add	x2, x2, x2, lsl #2
1000009ac:     	eor	w19, w19, w19, lsl #5
1000009b0:     	sub	x2, x27, x2, lsl #1
1000009b4:     	add	x27, x27, #0x1
1000009b8:     	mov	w1, w19
1000009bc:     	sub	w2, w2, #0x1
1000009c0:     	bl	0x1000006a0 <_region_pipeline>
1000009c4:     	mov	w1, #0x609b             ; =24731
1000009c8:     	add	w28, w28, w0
1000009cc:     	movk	w1, #0x4c22, lsl #16
1000009d0:     	mov	w0, #0x41b5             ; =16821
1000009d4:     	movk	w0, #0x9ed1, lsl #16
1000009d8:     	madd	w1, w19, w24, w1
1000009dc:     	madd	w0, w28, w0, w1
1000009e0:     	mov	w1, #0x649d             ; =25757
1000009e4:     	movk	w1, #0xec00, lsl #16
1000009e8:     	mul	w0, w0, w1
1000009ec:     	ldr	w1, [x22, #0xc]
1000009f0:     	add	w2, w0, w20
1000009f4:     	add	w1, w1, w1, lsl #5
1000009f8:     	eor	w1, w1, w2
1000009fc:     	str	w1, [x22, #0xc]
100000a00:     	ldr	w1, [x29, #0x6c]
100000a04:     	add	w1, w0, w1
100000a08:     	str	w1, [x23, #0x8]
100000a0c:     	mov	w1, #0x3513             ; =13587
100000a10:     	movk	w1, #0xfd2e, lsl #16
100000a14:     	add	w0, w0, w1
100000a18:     	mov	w1, #0x11               ; =17
100000a1c:     	stp	w0, w1, [x23]
100000a20:     	cmp	x21, x27
100000a24:     	b.ne	0x100000990 <_main+0xb0>
100000a28:     	ldp	x23, x24, [x29, #0x30]
100000a2c:     	ldp	x25, x26, [x29, #0x40]
100000a30:     	add	x1, x29, #0x70
100000a34:     	mov	w0, #0x6                ; =6
100000a38:     	bl	0x100000ad8 <_strtoul+0x100000ad8>
100000a3c:     	mov	w19, w0
100000a40:     	cbnz	w0, 0x100000abc <_main+0x1dc>
100000a44:     	adrp	x0, 0x100008000 <_memory>
100000a48:     	ldr	w0, [x0, #0xc]
100000a4c:     	str	w0, [sp, #0x28]
100000a50:     	adrp	x0, 0x100008000 <_memory>
100000a54:     	add	x0, x0, #0x0
100000a58:     	ldr	w1, [x0, #0x8]
100000a5c:     	str	w1, [sp, #0x20]
100000a60:     	ldp	w0, w1, [x0]
100000a64:     	str	w28, [sp, #0x8]
100000a68:     	str	w0, [sp, #0x10]
100000a6c:     	ldr	x0, [x29, #0x78]
100000a70:     	str	w1, [sp, #0x18]
100000a74:     	ldr	x1, [x29, #0x88]
100000a78:     	sub	x0, x0, x1
100000a7c:     	ldr	x1, [x29, #0x80]
100000a80:     	scvtf	d0, x0
100000a84:     	adrp	x0, 0x100000000 <_strtoul+0x100000000>
100000a88:     	ldr	d30, [x0, #0xb18]
100000a8c:     	ldr	x0, [x29, #0x70]
100000a90:     	fmul	d30, d0, d30
100000a94:     	sub	x0, x0, x1
100000a98:     	scvtf	d31, x0
100000a9c:     	adrp	x0, 0x100000000 <_strtoul+0x100000000>
100000aa0:     	add	x0, x0, #0xb00
100000aa4:     	fadd	d31, d30, d31
100000aa8:     	str	d31, [sp]
100000aac:     	bl	0x100000ae4 <_strtoul+0x100000ae4>
100000ab0:     	ldp	x21, x22, [x29, #0x20]
100000ab4:     	ldp	x27, x28, [x29, #0x50]
100000ab8:     	b	0x1000008fc <_main+0x1c>
100000abc:     	ldp	x21, x22, [x29, #0x20]
100000ac0:     	ldp	x27, x28, [x29, #0x50]
100000ac4:     	b	0x1000008f8 <_main+0x18>
100000ac8:     	ldp	x21, x22, [x29, #0x20]
100000acc:     	b	0x1000008f8 <_main+0x18>
100000ad0:     	mov	w28, #0x0               ; =0
100000ad4:     	b	0x100000a30 <_main+0x150>

Disassembly of section __TEXT,__stubs:

0000000100000ad8 <__stubs>:
100000ad8:     	adrp	x16, 0x100004000 <_strtoul+0x100004000>
100000adc:     	ldr	x16, [x16]
100000ae0:     	br	x16
100000ae4:     	adrp	x16, 0x100004000 <_strtoul+0x100004000>
100000ae8:     	ldr	x16, [x16, #0x8]
100000aec:     	br	x16
100000af0:     	adrp	x16, 0x100004000 <_strtoul+0x100004000>
100000af4:     	ldr	x16, [x16, #0x10]
100000af8:     	br	x16
