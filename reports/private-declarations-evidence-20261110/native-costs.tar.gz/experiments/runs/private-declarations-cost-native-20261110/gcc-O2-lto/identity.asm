
/Users/admin/C-SRD/experiments/runs/private-declarations-cost-native-20261110/gcc-O2-lto/identity:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001000006a0 <_region_pipeline>:
1000006a0:     	ldr	w3, [x0]
1000006a4:     	adrp	x9, 0x100008000 <_memory>
1000006a8:     	mov	x8, x0
1000006ac:     	add	w1, w3, w1
1000006b0:     	add	w6, w1, w1, lsl #1
1000006b4:     	add	w6, w6, #0xb
1000006b8:     	sub	w0, w6, w3
1000006bc:     	ldr	w3, [x9, #0xc]
1000006c0:     	add	w3, w3, w3, lsl #5
1000006c4:     	eor	w3, w3, w1
1000006c8:     	str	w3, [x9, #0xc]
1000006cc:     	cmp	w2, #0x0
1000006d0:     	b.le	0x100000738 <_region_pipeline+0x98>
1000006d4:     	adrp	x7, 0x100008000 <_memory>
1000006d8:     	sub	w2, w2, #0x1
1000006dc:     	add	x7, x7, #0x0
1000006e0:     	ldr	w4, [x7, #0x4]
1000006e4:     	add	w3, w3, w3, lsl #5
1000006e8:     	sub	w2, w2, #0x1
1000006ec:     	eor	w3, w3, w0
1000006f0:     	add	w3, w3, w3, lsl #5
1000006f4:     	add	w4, w0, w4
1000006f8:     	str	w4, [x7, #0x4]
1000006fc:     	add	w4, w0, w4
100000700:     	add	w5, w4, w4, lsl #2
100000704:     	add	w0, w0, w4
100000708:     	add	w5, w5, w6
10000070c:     	sub	w6, w1, w4
100000710:     	add	w6, w6, w5
100000714:     	eor	w3, w3, w5
100000718:     	add	w5, w5, #0x7
10000071c:     	add	w3, w3, w3, lsl #5
100000720:     	add	w0, w0, w6
100000724:     	str	w5, [x8]
100000728:     	eor	w3, w3, w4
10000072c:     	cmn	w2, #0x1
100000730:     	b.ne	0x1000006e0 <_region_pipeline+0x40>
100000734:     	str	w3, [x9, #0xc]
100000738:     	ret
10000073c:     	nop

0000000100000740 <_record_event>:
100000740:     	adrp	x2, 0x100008000 <_memory>
100000744:     	ldr	w1, [x2, #0xc]
100000748:     	add	w1, w1, w1, lsl #5
10000074c:     	eor	w1, w1, w0
100000750:     	str	w1, [x2, #0xc]
100000754:     	ret
100000758:     	nop
10000075c:     	nop

0000000100000760 <_next_value>:
100000760:     	adrp	x2, 0x100008000 <_memory>
100000764:     	ldr	w1, [x2, #0xc]
100000768:     	add	w1, w1, w1, lsl #5
10000076c:     	eor	w1, w1, w0
100000770:     	str	w1, [x2, #0xc]
100000774:     	adrp	x2, 0x100008000 <_memory>
100000778:     	add	x2, x2, #0x0
10000077c:     	ldr	w1, [x2, #0x4]
100000780:     	add	w1, w0, w1
100000784:     	add	w0, w1, w0
100000788:     	str	w1, [x2, #0x4]
10000078c:     	ret

0000000100000790 <_region_outputs>:
100000790:     	add	w1, w1, #0x11
100000794:     	adrp	x3, 0x100008000 <_memory>
100000798:     	add	w1, w1, w1, lsl #1
10000079c:     	add	w2, w1, w2
1000007a0:     	ldr	w1, [x3, #0xc]
1000007a4:     	add	w1, w1, w1, lsl #5
1000007a8:     	eor	w1, w1, w2
1000007ac:     	str	w1, [x3, #0xc]
1000007b0:     	add	w1, w2, #0x7
1000007b4:     	sub	w2, w2, #0x11
1000007b8:     	str	w1, [x0, #0x8]
1000007bc:     	mov	w1, #0x11               ; =17
1000007c0:     	stp	w2, w1, [x0]
1000007c4:     	mov	w0, #0x0                ; =0
1000007c8:     	ret

Disassembly of section __TEXT,__text_startup:

00000001000007e0 <_main>:
1000007e0:     	sub	sp, sp, #0x70
1000007e4:     	stp	x29, x30, [sp, #0x30]
1000007e8:     	add	x29, sp, #0x30
1000007ec:     	stp	x19, x20, [sp, #0x40]
1000007f0:     	cmp	w0, #0x3
1000007f4:     	b.eq	0x100000810 <_main+0x30>
1000007f8:     	mov	w19, #0x2               ; =2
1000007fc:     	ldp	x29, x30, [sp, #0x30]
100000800:     	mov	w0, w19
100000804:     	ldp	x19, x20, [sp, #0x40]
100000808:     	add	sp, sp, #0x70
10000080c:     	ret
100000810:     	mov	x20, x1
100000814:     	mov	w2, #0xa                ; =10
100000818:     	ldr	x0, [x20, #0x8]
10000081c:     	mov	x1, #0x0                ; =0
100000820:     	bl	0x10000098c <_strtoul+0x10000098c>
100000824:     	mov	x1, #0x0                ; =0
100000828:     	mov	x19, x0
10000082c:     	ldr	x0, [x20, #0x10]
100000830:     	mov	w2, #0xa                ; =10
100000834:     	bl	0x10000098c <_strtoul+0x10000098c>
100000838:     	mov	x20, x0
10000083c:     	add	x1, x29, #0x30
100000840:     	mov	w0, #0x6                ; =6
100000844:     	bl	0x100000974 <_strtoul+0x100000974>
100000848:     	cbnz	w0, 0x1000007f8 <_main+0x18>
10000084c:     	cbz	x19, 0x10000096c <_main+0x18c>
100000850:     	mov	x12, #-0x3333333333333334 ; =-3689348814741910324
100000854:     	adrp	x14, 0x100008000 <_memory>
100000858:     	adrp	x15, 0x100008000 <_memory>
10000085c:     	mov	w10, w20
100000860:     	mov	x13, #0x0               ; =0
100000864:     	mov	w20, #0x0               ; =0
100000868:     	movk	x12, #0xcccd
10000086c:     	add	x14, x14, #0x0
100000870:     	add	x15, x15, #0xc
100000874:     	mov	w11, #0x11              ; =17
100000878:     	nop
10000087c:     	nop
100000880:     	umulh	x2, x13, x12
100000884:     	mov	x0, x14
100000888:     	eor	w10, w10, w10, lsl #13
10000088c:     	lsr	x2, x2, #3
100000890:     	eor	w10, w10, w10, lsr #17
100000894:     	add	x2, x2, x2, lsl #2
100000898:     	eor	w10, w10, w10, lsl #5
10000089c:     	sub	x2, x13, x2, lsl #1
1000008a0:     	add	x13, x13, #0x1
1000008a4:     	mov	w1, w10
1000008a8:     	sub	w2, w2, #0x1
1000008ac:     	bl	0x1000006a0 <_region_pipeline>
1000008b0:     	ldr	w1, [x15]
1000008b4:     	add	w20, w20, w0
1000008b8:     	add	w0, w10, #0x11
1000008bc:     	add	w0, w0, w0, lsl #1
1000008c0:     	add	w0, w0, w20
1000008c4:     	add	w1, w1, w1, lsl #5
1000008c8:     	eor	w1, w1, w0
1000008cc:     	str	w1, [x15]
1000008d0:     	add	w1, w0, #0x7
1000008d4:     	sub	w0, w0, #0x11
1000008d8:     	stp	w0, w11, [x14]
1000008dc:     	str	w1, [x14, #0x8]
1000008e0:     	cmp	x19, x13
1000008e4:     	b.ne	0x100000880 <_main+0xa0>
1000008e8:     	add	x1, x29, #0x20
1000008ec:     	mov	w0, #0x6                ; =6
1000008f0:     	bl	0x100000974 <_strtoul+0x100000974>
1000008f4:     	mov	w19, w0
1000008f8:     	cbnz	w0, 0x1000007f8 <_main+0x18>
1000008fc:     	adrp	x0, 0x100008000 <_memory>
100000900:     	ldr	w0, [x0, #0xc]
100000904:     	str	w0, [sp, #0x28]
100000908:     	adrp	x0, 0x100008000 <_memory>
10000090c:     	add	x0, x0, #0x0
100000910:     	ldr	w1, [x0, #0x8]
100000914:     	str	w1, [sp, #0x20]
100000918:     	ldp	w0, w1, [x0]
10000091c:     	str	w20, [sp, #0x8]
100000920:     	str	w0, [sp, #0x10]
100000924:     	ldr	x0, [x29, #0x28]
100000928:     	str	w1, [sp, #0x18]
10000092c:     	ldr	x1, [x29, #0x38]
100000930:     	sub	x0, x0, x1
100000934:     	ldr	x1, [x29, #0x30]
100000938:     	scvtf	d0, x0
10000093c:     	adrp	x0, 0x100000000 <_strtoul+0x100000000>
100000940:     	ldr	d30, [x0, #0x9b0]
100000944:     	ldr	x0, [x29, #0x20]
100000948:     	fmul	d30, d0, d30
10000094c:     	sub	x0, x0, x1
100000950:     	scvtf	d31, x0
100000954:     	adrp	x0, 0x100000000 <_strtoul+0x100000000>
100000958:     	add	x0, x0, #0x998
10000095c:     	fadd	d31, d30, d31
100000960:     	str	d31, [sp]
100000964:     	bl	0x100000980 <_strtoul+0x100000980>
100000968:     	b	0x1000007fc <_main+0x1c>
10000096c:     	mov	w20, #0x0               ; =0
100000970:     	b	0x1000008e8 <_main+0x108>

Disassembly of section __TEXT,__stubs:

0000000100000974 <__stubs>:
100000974:     	adrp	x16, 0x100004000 <_strtoul+0x100004000>
100000978:     	ldr	x16, [x16]
10000097c:     	br	x16
100000980:     	adrp	x16, 0x100004000 <_strtoul+0x100004000>
100000984:     	ldr	x16, [x16, #0x8]
100000988:     	br	x16
10000098c:     	adrp	x16, 0x100004000 <_strtoul+0x100004000>
100000990:     	ldr	x16, [x16, #0x10]
100000994:     	br	x16
