
/Users/admin/C-SRD/experiments/runs/private-declarations-cost-native-20261110/clang-O2-lto/original:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001000004f8 <_main>:
1000004f8:     	cmp	w0, #0x3
1000004fc:     	b.ne	0x100000648 <_main+0x150>
100000500:     	sub	sp, sp, #0xa0
100000504:     	stp	x26, x25, [sp, #0x50]
100000508:     	stp	x24, x23, [sp, #0x60]
10000050c:     	stp	x22, x21, [sp, #0x70]
100000510:     	stp	x20, x19, [sp, #0x80]
100000514:     	stp	x29, x30, [sp, #0x90]
100000518:     	add	x29, sp, #0x90
10000051c:     	ldr	x0, [x1, #0x8]
100000520:     	mov	x20, x1
100000524:     	mov	x1, #0x0                ; =0
100000528:     	mov	w2, #0xa                ; =10
10000052c:     	bl	0x100000718 <_strtoul+0x100000718>
100000530:     	mov	x19, x0
100000534:     	ldr	x0, [x20, #0x10]
100000538:     	mov	x1, #0x0                ; =0
10000053c:     	mov	w2, #0xa                ; =10
100000540:     	bl	0x100000718 <_strtoul+0x100000718>
100000544:     	mov	x20, x0
100000548:     	add	x1, sp, #0x40
10000054c:     	mov	w0, #0x6                ; =6
100000550:     	bl	0x100000700 <_strtoul+0x100000700>
100000554:     	cbnz	w0, 0x10000067c <_main+0x184>
100000558:     	adrp	x25, 0x100008000 <_event_hash>
10000055c:     	adrp	x24, 0x100008000 <_event_hash>
100000560:     	adrp	x23, 0x100008000 <_event_hash>
100000564:     	adrp	x22, 0x100008000 <_event_hash>
100000568:     	cbz	x19, 0x100000668 <_main+0x170>
10000056c:     	mov	x8, #0x0                ; =0
100000570:     	mov	w21, #0x0               ; =0
100000574:     	ldr	w13, [x25, #0x4]
100000578:     	ldr	w14, [x22]
10000057c:     	mov	w9, #0x1                ; =1
100000580:     	mov	x10, #-0x3333333333333334 ; =-3689348814741910324
100000584:     	movk	x10, #0xcccd
100000588:     	mov	w11, #0xa               ; =10
10000058c:     	ldr	w12, [x24, #0x8]
100000590:     	b	0x1000005c4 <_main+0xcc>
100000594:     	add	w12, w20, w20, lsl #1
100000598:     	add	w21, w13, w21
10000059c:     	add	w12, w12, w21
1000005a0:     	add	w16, w12, #0x33
1000005a4:     	add	w13, w12, #0x22
1000005a8:     	add	w12, w15, w15, lsl #5
1000005ac:     	eor	w14, w12, w16
1000005b0:     	add	x8, x8, #0x1
1000005b4:     	add	w9, w9, #0x1
1000005b8:     	mov	w12, #0x11              ; =17
1000005bc:     	cmp	x8, x19
1000005c0:     	b.eq	0x100000650 <_main+0x158>
1000005c4:     	umulh	x15, x8, x10
1000005c8:     	lsr	x17, x15, #3
1000005cc:     	eor	w15, w20, w20, lsl #13
1000005d0:     	eor	w15, w15, w15, lsr #17
1000005d4:     	eor	w20, w15, w15, lsl #5
1000005d8:     	msub	x0, x17, x11, x8
1000005dc:     	add	w15, w14, w14, lsl #5
1000005e0:     	add	w14, w13, w20
1000005e4:     	eor	w15, w15, w14
1000005e8:     	add	w16, w14, w14, lsl #1
1000005ec:     	add	w16, w16, #0xb
1000005f0:     	sub	w13, w16, w13
1000005f4:     	cmp	x0, #0x2
1000005f8:     	b.lo	0x100000594 <_main+0x9c>
1000005fc:     	msub	w17, w17, w11, w9
100000600:     	add	w15, w15, w15, lsl #5
100000604:     	eor	w15, w15, w13
100000608:     	add	w12, w12, w13
10000060c:     	add	w0, w12, w13
100000610:     	add	w13, w0, w13
100000614:     	add	w1, w0, w0, lsl #2
100000618:     	add	w16, w1, w16
10000061c:     	sub	w1, w16, w0
100000620:     	add	w15, w15, w15, lsl #5
100000624:     	eor	w15, w15, w16
100000628:     	add	w16, w1, w14
10000062c:     	add	w13, w13, w16
100000630:     	add	w15, w15, w15, lsl #5
100000634:     	eor	w15, w15, w0
100000638:     	sub	w17, w17, #0x1
10000063c:     	cmp	w17, #0x2
100000640:     	b.gt	0x100000600 <_main+0x108>
100000644:     	b	0x100000594 <_main+0x9c>
100000648:     	mov	w0, #0x2                ; =2
10000064c:     	ret
100000650:     	add	w8, w16, #0x7
100000654:     	str	w13, [x25, #0x4]
100000658:     	str	w14, [x22]
10000065c:     	str	w8, [x23, #0xc]
100000660:     	str	w12, [x24, #0x8]
100000664:     	b	0x10000066c <_main+0x174>
100000668:     	mov	w21, #0x0               ; =0
10000066c:     	add	x1, sp, #0x30
100000670:     	mov	w0, #0x6                ; =6
100000674:     	bl	0x100000700 <_strtoul+0x100000700>
100000678:     	cbz	w0, 0x10000069c <_main+0x1a4>
10000067c:     	mov	w0, #0x2                ; =2
100000680:     	ldp	x29, x30, [sp, #0x90]
100000684:     	ldp	x20, x19, [sp, #0x80]
100000688:     	ldp	x22, x21, [sp, #0x70]
10000068c:     	ldp	x24, x23, [sp, #0x60]
100000690:     	ldp	x26, x25, [sp, #0x50]
100000694:     	add	sp, sp, #0xa0
100000698:     	ret
10000069c:     	ldp	x8, x9, [sp, #0x30]
1000006a0:     	ldp	x10, x11, [sp, #0x40]
1000006a4:     	sub	x8, x8, x10
1000006a8:     	scvtf	d0, x8
1000006ac:     	sub	x8, x9, x11
1000006b0:     	scvtf	d1, x8
1000006b4:     	mov	x8, #0xd695             ; =54933
1000006b8:     	movk	x8, #0xe826, lsl #16
1000006bc:     	movk	x8, #0x2e0b, lsl #32
1000006c0:     	movk	x8, #0x3e11, lsl #48
1000006c4:     	fmov	d2, x8
1000006c8:     	fmadd	d0, d1, d2, d0
1000006cc:     	ldr	w8, [x25, #0x4]
1000006d0:     	ldr	w9, [x24, #0x8]
1000006d4:     	ldr	w10, [x23, #0xc]
1000006d8:     	ldr	w11, [x22]
1000006dc:     	stp	x10, x11, [sp, #0x20]
1000006e0:     	stp	x8, x9, [sp, #0x10]
1000006e4:     	str	x21, [sp, #0x8]
1000006e8:     	str	d0, [sp]
1000006ec:     	adrp	x0, 0x100000000 <_strtoul+0x100000000>
1000006f0:     	add	x0, x0, #0x724
1000006f4:     	bl	0x10000070c <_strtoul+0x10000070c>
1000006f8:     	mov	w0, #0x0                ; =0
1000006fc:     	b	0x100000680 <_main+0x188>

Disassembly of section __TEXT,__stubs:

0000000100000700 <__stubs>:
100000700:     	adrp	x16, 0x100004000 <_strtoul+0x100004000>
100000704:     	ldr	x16, [x16]
100000708:     	br	x16
10000070c:     	adrp	x16, 0x100004000 <_strtoul+0x100004000>
100000710:     	ldr	x16, [x16, #0x8]
100000714:     	br	x16
100000718:     	adrp	x16, 0x100004000 <_strtoul+0x100004000>
10000071c:     	ldr	x16, [x16, #0x10]
100000720:     	br	x16
