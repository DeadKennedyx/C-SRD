
/Users/admin/C-SRD/experiments/runs/private-declarations-cost-native-20261110/clang-O2-lto/affine:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001000004f8 <_main>:
1000004f8:     	cmp	w0, #0x3
1000004fc:     	b.ne	0x1000006cc <_main+0x1d4>
100000500:     	sub	sp, sp, #0xb0
100000504:     	stp	x28, x27, [sp, #0x50]
100000508:     	stp	x26, x25, [sp, #0x60]
10000050c:     	stp	x24, x23, [sp, #0x70]
100000510:     	stp	x22, x21, [sp, #0x80]
100000514:     	stp	x20, x19, [sp, #0x90]
100000518:     	stp	x29, x30, [sp, #0xa0]
10000051c:     	add	x29, sp, #0xa0
100000520:     	ldr	x0, [x1, #0x8]
100000524:     	mov	x20, x1
100000528:     	mov	x1, #0x0                ; =0
10000052c:     	mov	w2, #0xa                ; =10
100000530:     	bl	0x1000007b0 <_strtoul+0x1000007b0>
100000534:     	mov	x19, x0
100000538:     	ldr	x0, [x20, #0x10]
10000053c:     	mov	x1, #0x0                ; =0
100000540:     	mov	w2, #0xa                ; =10
100000544:     	bl	0x1000007b0 <_strtoul+0x1000007b0>
100000548:     	mov	x20, x0
10000054c:     	add	x1, sp, #0x40
100000550:     	mov	w0, #0x6                ; =6
100000554:     	bl	0x100000798 <_strtoul+0x100000798>
100000558:     	cbnz	w0, 0x100000710 <_main+0x218>
10000055c:     	adrp	x25, 0x100008000 <_event_hash>
100000560:     	adrp	x24, 0x100008000 <_event_hash>
100000564:     	adrp	x23, 0x100008000 <_event_hash>
100000568:     	adrp	x22, 0x100008000 <_event_hash>
10000056c:     	cbz	x19, 0x1000006fc <_main+0x204>
100000570:     	mov	x8, #0x0                ; =0
100000574:     	mov	w21, #0x0               ; =0
100000578:     	mov	w9, #0xcc3f             ; =52287
10000057c:     	movk	w9, #0xdfc3, lsl #16
100000580:     	mov	w10, #0xb211            ; =45585
100000584:     	movk	w10, #0xda25, lsl #16
100000588:     	ldr	w26, [x25, #0x4]
10000058c:     	ldr	w27, [x22]
100000590:     	mov	w11, #0x1               ; =1
100000594:     	mov	x12, #-0x3333333333333334 ; =-3689348814741910324
100000598:     	movk	x12, #0xcccd
10000059c:     	ldr	w7, [x24, #0x8]
1000005a0:     	mov	w13, #0xa               ; =10
1000005a4:     	mov	w14, #0x5bcf            ; =23503
1000005a8:     	movk	w14, #0x8510, lsl #16
1000005ac:     	mov	w15, #0x23bf            ; =9151
1000005b0:     	movk	w15, #0x7082, lsl #16
1000005b4:     	mov	w16, #0x9ab8            ; =39608
1000005b8:     	movk	w16, #0xe760, lsl #16
1000005bc:     	mov	w17, #0x7ef1            ; =32497
1000005c0:     	movk	w17, #0x67ef, lsl #16
1000005c4:     	mov	w0, #0xfa6d             ; =64109
1000005c8:     	movk	w0, #0x9145, lsl #16
1000005cc:     	mov	w1, #0x3738             ; =14136
1000005d0:     	movk	w1, #0xd7e0, lsl #16
1000005d4:     	mov	w2, #0x21f4             ; =8692
1000005d8:     	movk	w2, #0x6258, lsl #16
1000005dc:     	mov	w3, #0x810f             ; =33039
1000005e0:     	movk	w3, #0x9810, lsl #16
1000005e4:     	mov	w4, #0x7ab5             ; =31413
1000005e8:     	movk	w4, #0x7ad, lsl #16
1000005ec:     	mov	w5, #0xde0c             ; =56844
1000005f0:     	movk	w5, #0x9da7, lsl #16
1000005f4:     	mov	w6, #0xe934             ; =59700
1000005f8:     	movk	w6, #0x7fb9, lsl #16
1000005fc:     	b	0x100000630 <_main+0x138>
100000600:     	add	w7, w20, w20, lsl #1
100000604:     	add	w21, w28, w21
100000608:     	add	w23, w21, w7
10000060c:     	add	w7, w23, #0x33
100000610:     	add	w26, w23, #0x22
100000614:     	add	w22, w27, w27, lsl #5
100000618:     	eor	w27, w22, w7
10000061c:     	add	x8, x8, #0x1
100000620:     	add	w11, w11, #0x1
100000624:     	mov	w7, #0x11               ; =17
100000628:     	cmp	x8, x19
10000062c:     	b.eq	0x1000006d4 <_main+0x1dc>
100000630:     	umulh	x22, x8, x12
100000634:     	lsr	x23, x22, #3
100000638:     	eor	w20, w20, w20, lsl #13
10000063c:     	eor	w20, w20, w20, lsr #17
100000640:     	eor	w20, w20, w20, lsl #5
100000644:     	msub	x24, x23, x13, x8
100000648:     	mul	w22, w26, w9
10000064c:     	madd	w28, w20, w9, w22
100000650:     	add	w30, w28, w14
100000654:     	add	w28, w30, w30, lsl #1
100000658:     	sub	w22, w28, w22
10000065c:     	madd	w28, w22, w15, w16
100000660:     	add	w27, w27, w27, lsl #5
100000664:     	add	w22, w26, w20
100000668:     	eor	w27, w27, w22
10000066c:     	cmp	x24, #0x2
100000670:     	b.lo	0x100000600 <_main+0x108>
100000674:     	msub	w26, w23, w13, w11
100000678:     	madd	w23, w30, w0, w1
10000067c:     	madd	w30, w22, w17, w2
100000680:     	add	w22, w27, w27, lsl #5
100000684:     	eor	w22, w22, w28
100000688:     	add	w7, w7, w28
10000068c:     	add	w24, w7, w28
100000690:     	madd	w23, w24, w4, w23
100000694:     	madd	w27, w24, w3, w30
100000698:     	add	w25, w23, w5
10000069c:     	add	w23, w27, w25
1000006a0:     	add	w27, w24, w28
1000006a4:     	madd	w25, w25, w10, w6
1000006a8:     	add	w22, w22, w22, lsl #5
1000006ac:     	eor	w22, w22, w25
1000006b0:     	madd	w28, w23, w10, w27
1000006b4:     	add	w22, w22, w22, lsl #5
1000006b8:     	eor	w27, w22, w24
1000006bc:     	sub	w26, w26, #0x1
1000006c0:     	cmp	w26, #0x2
1000006c4:     	b.gt	0x100000680 <_main+0x188>
1000006c8:     	b	0x100000600 <_main+0x108>
1000006cc:     	mov	w0, #0x2                ; =2
1000006d0:     	ret
1000006d4:     	add	w8, w23, #0x3a
1000006d8:     	adrp	x25, 0x100008000 <_event_hash>
1000006dc:     	str	w26, [x25, #0x4]
1000006e0:     	adrp	x22, 0x100008000 <_event_hash>
1000006e4:     	str	w27, [x22]
1000006e8:     	adrp	x24, 0x100008000 <_event_hash>
1000006ec:     	str	w7, [x24, #0x8]
1000006f0:     	adrp	x23, 0x100008000 <_event_hash>
1000006f4:     	str	w8, [x23, #0xc]
1000006f8:     	b	0x100000700 <_main+0x208>
1000006fc:     	mov	w21, #0x0               ; =0
100000700:     	add	x1, sp, #0x30
100000704:     	mov	w0, #0x6                ; =6
100000708:     	bl	0x100000798 <_strtoul+0x100000798>
10000070c:     	cbz	w0, 0x100000734 <_main+0x23c>
100000710:     	mov	w0, #0x2                ; =2
100000714:     	ldp	x29, x30, [sp, #0xa0]
100000718:     	ldp	x20, x19, [sp, #0x90]
10000071c:     	ldp	x22, x21, [sp, #0x80]
100000720:     	ldp	x24, x23, [sp, #0x70]
100000724:     	ldp	x26, x25, [sp, #0x60]
100000728:     	ldp	x28, x27, [sp, #0x50]
10000072c:     	add	sp, sp, #0xb0
100000730:     	ret
100000734:     	ldp	x8, x9, [sp, #0x30]
100000738:     	ldp	x10, x11, [sp, #0x40]
10000073c:     	sub	x8, x8, x10
100000740:     	scvtf	d0, x8
100000744:     	sub	x8, x9, x11
100000748:     	scvtf	d1, x8
10000074c:     	mov	x8, #0xd695             ; =54933
100000750:     	movk	x8, #0xe826, lsl #16
100000754:     	movk	x8, #0x2e0b, lsl #32
100000758:     	movk	x8, #0x3e11, lsl #48
10000075c:     	fmov	d2, x8
100000760:     	fmadd	d0, d1, d2, d0
100000764:     	ldr	w8, [x25, #0x4]
100000768:     	ldr	w9, [x24, #0x8]
10000076c:     	ldr	w10, [x23, #0xc]
100000770:     	ldr	w11, [x22]
100000774:     	stp	x10, x11, [sp, #0x20]
100000778:     	stp	x8, x9, [sp, #0x10]
10000077c:     	str	x21, [sp, #0x8]
100000780:     	str	d0, [sp]
100000784:     	adrp	x0, 0x100000000 <_strtoul+0x100000000>
100000788:     	add	x0, x0, #0x7bc
10000078c:     	bl	0x1000007a4 <_strtoul+0x1000007a4>
100000790:     	mov	w0, #0x0                ; =0
100000794:     	b	0x100000714 <_main+0x21c>

Disassembly of section __TEXT,__stubs:

0000000100000798 <__stubs>:
100000798:     	adrp	x16, 0x100004000 <_strtoul+0x100004000>
10000079c:     	ldr	x16, [x16]
1000007a0:     	br	x16
1000007a4:     	adrp	x16, 0x100004000 <_strtoul+0x100004000>
1000007a8:     	ldr	x16, [x16, #0x8]
1000007ac:     	br	x16
1000007b0:     	adrp	x16, 0x100004000 <_strtoul+0x100004000>
1000007b4:     	ldr	x16, [x16, #0x10]
1000007b8:     	br	x16
