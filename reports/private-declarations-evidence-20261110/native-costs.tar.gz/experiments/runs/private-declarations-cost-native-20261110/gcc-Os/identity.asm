
/Users/admin/C-SRD/experiments/runs/private-declarations-cost-native-20261110/gcc-Os/identity:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000100000698 <_region_pipeline>:
100000698:     	stp	x29, x30, [sp, #-0x50]!
10000069c:     	mov	x29, sp
1000006a0:     	stp	x19, x20, [sp, #0x10]
1000006a4:     	stp	x21, x22, [sp, #0x20]
1000006a8:     	mov	w22, w2
1000006ac:     	stp	x23, x24, [sp, #0x30]
1000006b0:     	mov	x23, x0
1000006b4:     	ldr	w19, [x0]
1000006b8:     	str	x25, [sp, #0x40]
1000006bc:     	add	w24, w19, w1
1000006c0:     	add	w20, w24, w24, lsl #1
1000006c4:     	mov	w0, w24
1000006c8:     	add	w20, w20, #0xb
1000006cc:     	sub	w19, w20, w19
1000006d0:     	bl	0x100000784 <_record_event>
1000006d4:     	tbz	w22, #0x1f, 0x100000734 <_region_pipeline+0x9c>
1000006d8:     	ldr	x25, [sp, #0x40]
1000006dc:     	mov	w0, w19
1000006e0:     	ldp	x19, x20, [sp, #0x10]
1000006e4:     	ldp	x21, x22, [sp, #0x20]
1000006e8:     	ldp	x23, x24, [sp, #0x30]
1000006ec:     	ldp	x29, x30, [sp], #0x50
1000006f0:     	ret
1000006f4:     	mov	w0, w19
1000006f8:     	sub	w22, w22, #0x1
1000006fc:     	bl	0x10000079c <_next_value>
100000700:     	add	w21, w0, w0, lsl #2
100000704:     	mov	w25, w0
100000708:     	add	w19, w19, w0
10000070c:     	add	w21, w21, w20
100000710:     	sub	w20, w24, w0
100000714:     	add	w20, w20, w21
100000718:     	mov	w0, w21
10000071c:     	add	w21, w21, #0x7
100000720:     	add	w19, w19, w20
100000724:     	bl	0x100000784 <_record_event>
100000728:     	mov	w0, w25
10000072c:     	str	w21, [x23]
100000730:     	bl	0x100000784 <_record_event>
100000734:     	cbnz	w22, 0x1000006f4 <_region_pipeline+0x5c>
100000738:     	b	0x1000006d8 <_region_pipeline+0x40>

000000010000073c <_region_outputs>:
10000073c:     	stp	x29, x30, [sp, #-0x20]!
100000740:     	mov	x29, sp
100000744:     	stp	x19, x20, [sp, #0x10]
100000748:     	add	w19, w1, #0x11
10000074c:     	mov	x20, x0
100000750:     	add	w19, w19, w19, lsl #1
100000754:     	add	w19, w19, w2
100000758:     	mov	w0, w19
10000075c:     	bl	0x100000784 <_record_event>
100000760:     	add	w0, w19, #0x7
100000764:     	sub	w19, w19, #0x11
100000768:     	str	w0, [x20, #0x8]
10000076c:     	mov	w0, #0x11               ; =17
100000770:     	stp	w19, w0, [x20]
100000774:     	mov	w0, #0x0                ; =0
100000778:     	ldp	x19, x20, [sp, #0x10]
10000077c:     	ldp	x29, x30, [sp], #0x20
100000780:     	ret

0000000100000784 <_record_event>:
100000784:     	adrp	x2, 0x100008000 <_event_hash>
100000788:     	ldr	w1, [x2]
10000078c:     	add	w1, w1, w1, lsl #5
100000790:     	eor	w1, w1, w0
100000794:     	str	w1, [x2]
100000798:     	ret

000000010000079c <_next_value>:
10000079c:     	stp	x29, x30, [sp, #-0x10]!
1000007a0:     	mov	x29, sp
1000007a4:     	bl	0x100000784 <_record_event>
1000007a8:     	adrp	x2, 0x100008000 <_event_hash>
1000007ac:     	ldp	x29, x30, [sp], #0x10
1000007b0:     	add	x2, x2, #0x4
1000007b4:     	ldr	w1, [x2, #0x4]
1000007b8:     	add	w1, w0, w1
1000007bc:     	add	w0, w1, w0
1000007c0:     	str	w1, [x2, #0x4]
1000007c4:     	ret

Disassembly of section __TEXT,__text_startup:

00000001000007c8 <_main>:
1000007c8:     	sub	sp, sp, #0x90
1000007cc:     	stp	x29, x30, [sp, #0x30]
1000007d0:     	add	x29, sp, #0x30
1000007d4:     	stp	x19, x20, [sp, #0x40]
1000007d8:     	stp	x21, x22, [sp, #0x50]
1000007dc:     	stp	x23, x24, [sp, #0x60]
1000007e0:     	cmp	w0, #0x3
1000007e4:     	b.eq	0x100000808 <_main+0x40>
1000007e8:     	mov	w19, #0x2               ; =2
1000007ec:     	ldp	x29, x30, [sp, #0x30]
1000007f0:     	mov	w0, w19
1000007f4:     	ldp	x19, x20, [sp, #0x40]
1000007f8:     	ldp	x21, x22, [sp, #0x50]
1000007fc:     	ldp	x23, x24, [sp, #0x60]
100000800:     	add	sp, sp, #0x90
100000804:     	ret
100000808:     	mov	x19, x1
10000080c:     	mov	w2, #0xa                ; =10
100000810:     	ldr	x0, [x19, #0x8]
100000814:     	mov	x1, #0x0                ; =0
100000818:     	bl	0x100000940 <_strtoul+0x100000940>
10000081c:     	mov	x1, #0x0                ; =0
100000820:     	mov	x23, x0
100000824:     	ldr	x0, [x19, #0x10]
100000828:     	mov	w2, #0xa                ; =10
10000082c:     	bl	0x100000940 <_strtoul+0x100000940>
100000830:     	mov	x19, x0
100000834:     	add	x1, x29, #0x40
100000838:     	mov	w0, #0x6                ; =6
10000083c:     	bl	0x100000928 <_strtoul+0x100000928>
100000840:     	cbnz	w0, 0x1000007e8 <_main+0x20>
100000844:     	adrp	x22, 0x100008000 <_event_hash>
100000848:     	mov	x21, #0x0               ; =0
10000084c:     	mov	w20, #0x0               ; =0
100000850:     	mov	x24, #0xa               ; =10
100000854:     	add	x22, x22, #0x4
100000858:     	cmp	x21, x23
10000085c:     	b.ne	0x1000008e4 <_main+0x11c>
100000860:     	add	x1, x29, #0x50
100000864:     	mov	w0, #0x6                ; =6
100000868:     	bl	0x100000928 <_strtoul+0x100000928>
10000086c:     	mov	w19, w0
100000870:     	cbnz	w0, 0x1000007e8 <_main+0x20>
100000874:     	adrp	x0, 0x100008000 <_event_hash>
100000878:     	ldr	w0, [x0]
10000087c:     	str	w0, [sp, #0x28]
100000880:     	adrp	x0, 0x100008000 <_event_hash>
100000884:     	add	x0, x0, #0x4
100000888:     	ldr	w1, [x0, #0x8]
10000088c:     	str	w1, [sp, #0x20]
100000890:     	ldp	w0, w1, [x0]
100000894:     	str	w20, [sp, #0x8]
100000898:     	str	w0, [sp, #0x10]
10000089c:     	ldr	x0, [x29, #0x58]
1000008a0:     	str	w1, [sp, #0x18]
1000008a4:     	ldr	x1, [x29, #0x48]
1000008a8:     	sub	x0, x0, x1
1000008ac:     	ldr	x1, [x29, #0x40]
1000008b0:     	scvtf	d0, x0
1000008b4:     	adrp	x0, 0x100000000 <_strtoul+0x100000000>
1000008b8:     	ldr	d30, [x0, #0x968]
1000008bc:     	ldr	x0, [x29, #0x50]
1000008c0:     	fmul	d30, d0, d30
1000008c4:     	sub	x0, x0, x1
1000008c8:     	scvtf	d31, x0
1000008cc:     	adrp	x0, 0x100000000 <_strtoul+0x100000000>
1000008d0:     	add	x0, x0, #0x94c
1000008d4:     	fadd	d31, d30, d31
1000008d8:     	str	d31, [sp]
1000008dc:     	bl	0x100000934 <_strtoul+0x100000934>
1000008e0:     	b	0x1000007ec <_main+0x24>
1000008e4:     	udiv	x2, x21, x24
1000008e8:     	mov	x0, x22
1000008ec:     	eor	w19, w19, w19, lsl #13
1000008f0:     	eor	w19, w19, w19, lsr #17
1000008f4:     	eor	w19, w19, w19, lsl #5
1000008f8:     	msub	x2, x2, x24, x21
1000008fc:     	mov	w1, w19
100000900:     	add	x21, x21, #0x1
100000904:     	sub	w2, w2, #0x1
100000908:     	bl	0x100000698 <_region_pipeline>
10000090c:     	add	w20, w20, w0
100000910:     	mov	w1, w19
100000914:     	mov	w2, w20
100000918:     	mov	x0, x22
10000091c:     	bl	0x10000073c <_region_outputs>
100000920:     	add	w20, w0, w20
100000924:     	b	0x100000858 <_main+0x90>

Disassembly of section __TEXT,__stubs:

0000000100000928 <__stubs>:
100000928:     	adrp	x16, 0x100004000 <_strtoul+0x100004000>
10000092c:     	ldr	x16, [x16]
100000930:     	br	x16
100000934:     	adrp	x16, 0x100004000 <_strtoul+0x100004000>
100000938:     	ldr	x16, [x16, #0x8]
10000093c:     	br	x16
100000940:     	adrp	x16, 0x100004000 <_strtoul+0x100004000>
100000944:     	ldr	x16, [x16, #0x10]
100000948:     	br	x16
