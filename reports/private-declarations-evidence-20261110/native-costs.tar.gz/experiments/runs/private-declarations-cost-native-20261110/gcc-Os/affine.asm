
/Users/admin/C-SRD/experiments/runs/private-declarations-cost-native-20261110/gcc-Os/affine:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000100000698 <_region_pipeline>:
100000698:     	stp	x29, x30, [sp, #-0x70]!
10000069c:     	mov	x29, sp
1000006a0:     	stp	x19, x20, [sp, #0x10]
1000006a4:     	stp	x21, x22, [sp, #0x20]
1000006a8:     	mov	x22, x0
1000006ac:     	stp	x23, x24, [sp, #0x30]
1000006b0:     	mov	w23, #0x2afd            ; =11005
1000006b4:     	mov	w24, #0x2bf0            ; =11248
1000006b8:     	movk	w23, #0xca3b, lsl #16
1000006bc:     	movk	w24, #0x61ce, lsl #16
1000006c0:     	stp	x25, x26, [sp, #0x40]
1000006c4:     	stp	x27, x28, [sp, #0x50]
1000006c8:     	mov	w27, w2
1000006cc:     	mov	w2, #0x8950             ; =35152
1000006d0:     	movk	w2, #0xf66f, lsl #16
1000006d4:     	ldr	w19, [x0]
1000006d8:     	mov	w0, #0xc255             ; =49749
1000006dc:     	movk	w0, #0xf13, lsl #16
1000006e0:     	madd	w19, w19, w0, w2
1000006e4:     	madd	w1, w1, w0, w19
1000006e8:     	mov	w0, #0x4707             ; =18183
1000006ec:     	movk	w0, #0xb8fa, lsl #16
1000006f0:     	add	w20, w1, w1, lsl #1
1000006f4:     	madd	w21, w1, w23, w24
1000006f8:     	add	w20, w20, w0
1000006fc:     	sub	w19, w20, w19
100000700:     	mov	w0, w21
100000704:     	mul	w19, w19, w23
100000708:     	bl	0x100000884 <_record_event>
10000070c:     	tbnz	w27, #0x1f, 0x100000740 <_region_pipeline+0xa8>
100000710:     	mov	w25, #0xb955            ; =47445
100000714:     	mov	w0, #0xdfe6             ; =57318
100000718:     	madd	w20, w20, w23, w24
10000071c:     	movk	w25, #0xcb3a, lsl #16
100000720:     	movk	w0, #0xc9, lsl #16
100000724:     	mov	w24, #0x1bd9            ; =7129
100000728:     	mov	w23, #0xeff3            ; =61427
10000072c:     	movk	w24, #0xc428, lsl #16
100000730:     	madd	w21, w21, w25, w0
100000734:     	movk	w23, #0x8064, lsl #16
100000738:     	add	w26, w24, #0x7
10000073c:     	cbnz	w27, 0x100000760 <_region_pipeline+0xc8>
100000740:     	ldp	x21, x22, [sp, #0x20]
100000744:     	mov	w0, w19
100000748:     	ldp	x19, x20, [sp, #0x10]
10000074c:     	ldp	x23, x24, [sp, #0x30]
100000750:     	ldp	x25, x26, [sp, #0x40]
100000754:     	ldp	x27, x28, [sp, #0x50]
100000758:     	ldp	x29, x30, [sp], #0x70
10000075c:     	ret
100000760:     	mov	w0, w19
100000764:     	madd	w19, w19, w25, w23
100000768:     	sub	w27, w27, #0x1
10000076c:     	bl	0x10000089c <_next_value>
100000770:     	mov	w2, w0
100000774:     	madd	w0, w0, w25, w23
100000778:     	mov	w1, #0x4034             ; =16436
10000077c:     	movk	w1, #0xfe6c, lsl #16
100000780:     	mov	w3, #0x7bfd             ; =31741
100000784:     	movk	w3, #0x43f, lsl #16
100000788:     	str	w2, [x29, #0x6c]
10000078c:     	add	w28, w19, w0
100000790:     	add	w19, w0, w0, lsl #2
100000794:     	sub	w0, w21, w0
100000798:     	add	w19, w19, w1
10000079c:     	madd	w19, w20, w25, w19
1000007a0:     	mov	w20, #0x37b2            ; =14258
1000007a4:     	movk	w20, #0x8850, lsl #16
1000007a8:     	add	w0, w0, w19
1000007ac:     	mul	w19, w19, w3
1000007b0:     	madd	w20, w0, w3, w20
1000007b4:     	add	w0, w19, w24
1000007b8:     	add	w19, w19, w26
1000007bc:     	bl	0x100000884 <_record_event>
1000007c0:     	mov	w3, #0xf145             ; =61765
1000007c4:     	mov	w0, #0x9b1c             ; =39708
1000007c8:     	str	w19, [x22]
1000007cc:     	movk	w3, #0x4348, lsl #16
1000007d0:     	movk	w0, #0xe963, lsl #16
1000007d4:     	mov	w19, #0x5f59            ; =24409
1000007d8:     	madd	w28, w28, w3, w0
1000007dc:     	mov	w0, #0xf8e9             ; =63721
1000007e0:     	mov	w3, #0xe6f6             ; =59126
1000007e4:     	movk	w0, #0x6e34, lsl #16
1000007e8:     	movk	w3, #0xf1bb, lsl #16
1000007ec:     	movk	w19, #0xeb1f, lsl #16
1000007f0:     	madd	w0, w20, w0, w28
1000007f4:     	madd	w19, w0, w19, w3
1000007f8:     	ldr	w0, [x29, #0x6c]
1000007fc:     	bl	0x100000884 <_record_event>
100000800:     	b	0x10000073c <_region_pipeline+0xa4>

0000000100000804 <_region_outputs>:
100000804:     	stp	x29, x30, [sp, #-0x30]!
100000808:     	mov	x29, sp
10000080c:     	mov	w3, #0x41b5             ; =16821
100000810:     	movk	w3, #0x9ed1, lsl #16
100000814:     	str	x21, [sp, #0x20]
100000818:     	mov	x21, x0
10000081c:     	mov	w0, #0x609b             ; =24731
100000820:     	movk	w0, #0x4c22, lsl #16
100000824:     	stp	x19, x20, [sp, #0x10]
100000828:     	mov	w20, #0x3524            ; =13604
10000082c:     	movk	w20, #0xfd2e, lsl #16
100000830:     	madd	w2, w2, w3, w0
100000834:     	mov	w0, #0xc51f             ; =50463
100000838:     	movk	w0, #0xdc73, lsl #16
10000083c:     	madd	w1, w1, w0, w2
100000840:     	mov	w0, #0x649d             ; =25757
100000844:     	movk	w0, #0xec00, lsl #16
100000848:     	mul	w19, w1, w0
10000084c:     	add	w0, w19, w20
100000850:     	add	w20, w20, #0x7
100000854:     	bl	0x100000884 <_record_event>
100000858:     	add	w0, w19, w20
10000085c:     	sub	w20, w20, #0x18
100000860:     	add	w19, w19, w20
100000864:     	str	w0, [x21, #0x8]
100000868:     	mov	w0, #0x11               ; =17
10000086c:     	stp	w19, w0, [x21]
100000870:     	mov	w0, #0x0                ; =0
100000874:     	ldr	x21, [sp, #0x20]
100000878:     	ldp	x19, x20, [sp, #0x10]
10000087c:     	ldp	x29, x30, [sp], #0x30
100000880:     	ret

0000000100000884 <_record_event>:
100000884:     	adrp	x2, 0x100008000 <_event_hash>
100000888:     	ldr	w1, [x2]
10000088c:     	add	w1, w1, w1, lsl #5
100000890:     	eor	w1, w1, w0
100000894:     	str	w1, [x2]
100000898:     	ret

000000010000089c <_next_value>:
10000089c:     	stp	x29, x30, [sp, #-0x10]!
1000008a0:     	mov	x29, sp
1000008a4:     	bl	0x100000884 <_record_event>
1000008a8:     	adrp	x2, 0x100008000 <_event_hash>
1000008ac:     	ldp	x29, x30, [sp], #0x10
1000008b0:     	add	x2, x2, #0x4
1000008b4:     	ldr	w1, [x2, #0x4]
1000008b8:     	add	w1, w0, w1
1000008bc:     	add	w0, w1, w0
1000008c0:     	str	w1, [x2, #0x4]
1000008c4:     	ret

Disassembly of section __TEXT,__text_startup:

00000001000008c8 <_main>:
1000008c8:     	sub	sp, sp, #0x90
1000008cc:     	stp	x29, x30, [sp, #0x30]
1000008d0:     	add	x29, sp, #0x30
1000008d4:     	stp	x19, x20, [sp, #0x40]
1000008d8:     	stp	x21, x22, [sp, #0x50]
1000008dc:     	stp	x23, x24, [sp, #0x60]
1000008e0:     	cmp	w0, #0x3
1000008e4:     	b.eq	0x100000908 <_main+0x40>
1000008e8:     	mov	w19, #0x2               ; =2
1000008ec:     	ldp	x29, x30, [sp, #0x30]
1000008f0:     	mov	w0, w19
1000008f4:     	ldp	x19, x20, [sp, #0x40]
1000008f8:     	ldp	x21, x22, [sp, #0x50]
1000008fc:     	ldp	x23, x24, [sp, #0x60]
100000900:     	add	sp, sp, #0x90
100000904:     	ret
100000908:     	mov	x19, x1
10000090c:     	mov	w2, #0xa                ; =10
100000910:     	ldr	x0, [x19, #0x8]
100000914:     	mov	x1, #0x0                ; =0
100000918:     	bl	0x100000a40 <_strtoul+0x100000a40>
10000091c:     	mov	x1, #0x0                ; =0
100000920:     	mov	x23, x0
100000924:     	ldr	x0, [x19, #0x10]
100000928:     	mov	w2, #0xa                ; =10
10000092c:     	bl	0x100000a40 <_strtoul+0x100000a40>
100000930:     	mov	x19, x0
100000934:     	add	x1, x29, #0x40
100000938:     	mov	w0, #0x6                ; =6
10000093c:     	bl	0x100000a28 <_strtoul+0x100000a28>
100000940:     	cbnz	w0, 0x1000008e8 <_main+0x20>
100000944:     	adrp	x22, 0x100008000 <_event_hash>
100000948:     	mov	x21, #0x0               ; =0
10000094c:     	mov	w20, #0x0               ; =0
100000950:     	mov	x24, #0xa               ; =10
100000954:     	add	x22, x22, #0x4
100000958:     	cmp	x21, x23
10000095c:     	b.ne	0x1000009e4 <_main+0x11c>
100000960:     	add	x1, x29, #0x50
100000964:     	mov	w0, #0x6                ; =6
100000968:     	bl	0x100000a28 <_strtoul+0x100000a28>
10000096c:     	mov	w19, w0
100000970:     	cbnz	w0, 0x1000008e8 <_main+0x20>
100000974:     	adrp	x0, 0x100008000 <_event_hash>
100000978:     	ldr	w0, [x0]
10000097c:     	str	w0, [sp, #0x28]
100000980:     	adrp	x0, 0x100008000 <_event_hash>
100000984:     	add	x0, x0, #0x4
100000988:     	ldr	w1, [x0, #0x8]
10000098c:     	str	w1, [sp, #0x20]
100000990:     	ldp	w0, w1, [x0]
100000994:     	str	w20, [sp, #0x8]
100000998:     	str	w0, [sp, #0x10]
10000099c:     	ldr	x0, [x29, #0x58]
1000009a0:     	str	w1, [sp, #0x18]
1000009a4:     	ldr	x1, [x29, #0x48]
1000009a8:     	sub	x0, x0, x1
1000009ac:     	ldr	x1, [x29, #0x40]
1000009b0:     	scvtf	d0, x0
1000009b4:     	adrp	x0, 0x100000000 <_strtoul+0x100000000>
1000009b8:     	ldr	d30, [x0, #0xa68]
1000009bc:     	ldr	x0, [x29, #0x50]
1000009c0:     	fmul	d30, d0, d30
1000009c4:     	sub	x0, x0, x1
1000009c8:     	scvtf	d31, x0
1000009cc:     	adrp	x0, 0x100000000 <_strtoul+0x100000000>
1000009d0:     	add	x0, x0, #0xa4c
1000009d4:     	fadd	d31, d30, d31
1000009d8:     	str	d31, [sp]
1000009dc:     	bl	0x100000a34 <_strtoul+0x100000a34>
1000009e0:     	b	0x1000008ec <_main+0x24>
1000009e4:     	udiv	x2, x21, x24
1000009e8:     	mov	x0, x22
1000009ec:     	eor	w19, w19, w19, lsl #13
1000009f0:     	eor	w19, w19, w19, lsr #17
1000009f4:     	eor	w19, w19, w19, lsl #5
1000009f8:     	msub	x2, x2, x24, x21
1000009fc:     	mov	w1, w19
100000a00:     	add	x21, x21, #0x1
100000a04:     	sub	w2, w2, #0x1
100000a08:     	bl	0x100000698 <_region_pipeline>
100000a0c:     	add	w20, w20, w0
100000a10:     	mov	w1, w19
100000a14:     	mov	w2, w20
100000a18:     	mov	x0, x22
100000a1c:     	bl	0x100000804 <_region_outputs>
100000a20:     	add	w20, w0, w20
100000a24:     	b	0x100000958 <_main+0x90>

Disassembly of section __TEXT,__stubs:

0000000100000a28 <__stubs>:
100000a28:     	adrp	x16, 0x100004000 <_strtoul+0x100004000>
100000a2c:     	ldr	x16, [x16]
100000a30:     	br	x16
100000a34:     	adrp	x16, 0x100004000 <_strtoul+0x100004000>
100000a38:     	ldr	x16, [x16, #0x8]
100000a3c:     	br	x16
100000a40:     	adrp	x16, 0x100004000 <_strtoul+0x100004000>
100000a44:     	ldr	x16, [x16, #0x10]
100000a48:     	br	x16
