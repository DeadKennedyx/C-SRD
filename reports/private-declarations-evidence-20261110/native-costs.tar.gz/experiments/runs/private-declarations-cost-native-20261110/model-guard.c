#include <limits.h>
#include <stdint.h>
_Static_assert(sizeof(int) * CHAR_BIT == 32, "C-SRD requires 32-bit int");
_Static_assert(sizeof(unsigned int) * CHAR_BIT == 32, "C-SRD requires 32-bit unsigned int");
_Static_assert(_Generic((uint32_t)0, unsigned int: 1, default: 0),
               "C-SRD requires uint32_t to be unsigned int");
