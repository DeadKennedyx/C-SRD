
/Users/admin/C-SRD/experiments/runs/private-declarations-cost-native-20261110/gcc-O2/original:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001000006a0 <_region_pipeline>:
1000006a0:     	stp	x29, x30, [sp, #-0x50]!
1000006a4:     	mov	x29, sp
1000006a8:     	stp	x19, x20, [sp, #0x10]
1000006ac:     	stp	x21, x22, [sp, #0x20]
1000006b0:     	stp	x23, x24, [sp, #0x30]
1000006b4:     	mov	x24, x0
1000006b8:     	ldr	w19, [x0]
1000006bc:     	str	x25, [sp, #0x40]
1000006c0:     	mov	w25, w2
1000006c4:     	add	w23, w19, w1
1000006c8:     	add	w22, w23, w23, lsl #1
1000006cc:     	mov	w0, w23
1000006d0:     	add	w22, w22, #0xb
1000006d4:     	sub	w21, w22, w19
1000006d8:     	bl	0x1000007a0 <_record_event>
1000006dc:     	cmp	w25, #0x0
1000006e0:     	b.le	0x100000728 <_region_pipeline+0x88>
1000006e4:     	mov	w0, w21
1000006e8:     	bl	0x1000007c0 <_next_value>
1000006ec:     	add	w19, w0, w0, lsl #2
1000006f0:     	mov	w20, w0
1000006f4:     	add	w21, w0, w21
1000006f8:     	add	w19, w19, w22
1000006fc:     	sub	w22, w23, w0
100000700:     	add	w22, w22, w19
100000704:     	mov	w0, w19
100000708:     	add	w19, w19, #0x7
10000070c:     	add	w21, w21, w22
100000710:     	bl	0x1000007a0 <_record_event>
100000714:     	mov	w0, w20
100000718:     	str	w19, [x24]
10000071c:     	bl	0x1000007a0 <_record_event>
100000720:     	subs	w25, w25, #0x1
100000724:     	b.ne	0x1000006e4 <_region_pipeline+0x44>
100000728:     	ldr	x25, [sp, #0x40]
10000072c:     	mov	w0, w21
100000730:     	ldp	x19, x20, [sp, #0x10]
100000734:     	ldp	x21, x22, [sp, #0x20]
100000738:     	ldp	x23, x24, [sp, #0x30]
10000073c:     	ldp	x29, x30, [sp], #0x50
100000740:     	ret

0000000100000744 <_region_outputs>:
100000744:     	stp	x29, x30, [sp, #-0x20]!
100000748:     	mov	x29, sp
10000074c:     	stp	x19, x20, [sp, #0x10]
100000750:     	add	w19, w1, #0x11
100000754:     	mov	x20, x0
100000758:     	add	w19, w19, w19, lsl #1
10000075c:     	add	w19, w19, w2
100000760:     	mov	w0, w19
100000764:     	bl	0x1000007a0 <_record_event>
100000768:     	add	w0, w19, #0x7
10000076c:     	sub	w19, w19, #0x11
100000770:     	str	w0, [x20, #0x8]
100000774:     	mov	w0, #0x11               ; =17
100000778:     	stp	w19, w0, [x20]
10000077c:     	mov	w0, #0x0                ; =0
100000780:     	ldp	x19, x20, [sp, #0x10]
100000784:     	ldp	x29, x30, [sp], #0x20
100000788:     	ret
		...

00000001000007a0 <_record_event>:
1000007a0:     	adrp	x2, 0x100008000 <_event_hash>
1000007a4:     	ldr	w1, [x2]
1000007a8:     	add	w1, w1, w1, lsl #5
1000007ac:     	eor	w1, w1, w0
1000007b0:     	str	w1, [x2]
1000007b4:     	ret
1000007b8:     	nop
1000007bc:     	nop

00000001000007c0 <_next_value>:
1000007c0:     	adrp	x2, 0x100008000 <_event_hash>
1000007c4:     	ldr	w1, [x2]
1000007c8:     	add	w1, w1, w1, lsl #5
1000007cc:     	eor	w1, w1, w0
1000007d0:     	str	w1, [x2]
1000007d4:     	adrp	x2, 0x100008000 <_event_hash>
1000007d8:     	add	x2, x2, #0x4
1000007dc:     	ldr	w1, [x2, #0x4]
1000007e0:     	add	w1, w0, w1
1000007e4:     	add	w0, w1, w0
1000007e8:     	str	w1, [x2, #0x4]
1000007ec:     	ret

Disassembly of section __TEXT,__text_startup:

0000000100000800 <_main>:
100000800:     	sub	sp, sp, #0x90
100000804:     	stp	x29, x30, [sp, #0x30]
100000808:     	add	x29, sp, #0x30
10000080c:     	stp	x19, x20, [sp, #0x40]
100000810:     	cmp	w0, #0x3
100000814:     	b.eq	0x100000830 <_main+0x30>
100000818:     	mov	w19, #0x2               ; =2
10000081c:     	ldp	x29, x30, [sp, #0x30]
100000820:     	mov	w0, w19
100000824:     	ldp	x19, x20, [sp, #0x40]
100000828:     	add	sp, sp, #0x90
10000082c:     	ret
100000830:     	mov	x19, x1
100000834:     	mov	w2, #0xa                ; =10
100000838:     	stp	x21, x22, [x29, #0x20]
10000083c:     	mov	x1, #0x0                ; =0
100000840:     	ldr	x0, [x19, #0x8]
100000844:     	bl	0x100000994 <_strtoul+0x100000994>
100000848:     	mov	x1, #0x0                ; =0
10000084c:     	mov	x21, x0
100000850:     	ldr	x0, [x19, #0x10]
100000854:     	mov	w2, #0xa                ; =10
100000858:     	bl	0x100000994 <_strtoul+0x100000994>
10000085c:     	mov	x19, x0
100000860:     	add	x1, x29, #0x40
100000864:     	mov	w0, #0x6                ; =6
100000868:     	bl	0x10000097c <_strtoul+0x10000097c>
10000086c:     	cbnz	w0, 0x10000096c <_main+0x16c>
100000870:     	cbz	x21, 0x100000974 <_main+0x174>
100000874:     	adrp	x22, 0x100008000 <_event_hash>
100000878:     	stp	x23, x24, [x29, #0x30]
10000087c:     	mov	x23, #-0x3333333333333334 ; =-3689348814741910324
100000880:     	mov	x24, #0x0               ; =0
100000884:     	mov	w20, #0x0               ; =0
100000888:     	movk	x23, #0xcccd
10000088c:     	add	x22, x22, #0x4
100000890:     	umulh	x1, x24, x23
100000894:     	mov	x0, x22
100000898:     	eor	w19, w19, w19, lsl #13
10000089c:     	lsr	x1, x1, #3
1000008a0:     	eor	w19, w19, w19, lsr #17
1000008a4:     	add	x1, x1, x1, lsl #2
1000008a8:     	eor	w19, w19, w19, lsl #5
1000008ac:     	sub	x2, x24, x1, lsl #1
1000008b0:     	add	x24, x24, #0x1
1000008b4:     	mov	w1, w19
1000008b8:     	sub	w2, w2, #0x1
1000008bc:     	bl	0x1000006a0 <_region_pipeline>
1000008c0:     	add	w20, w0, w20
1000008c4:     	mov	w1, w19
1000008c8:     	mov	w2, w20
1000008cc:     	mov	x0, x22
1000008d0:     	bl	0x100000744 <_region_outputs>
1000008d4:     	add	w20, w0, w20
1000008d8:     	cmp	x21, x24
1000008dc:     	b.ne	0x100000890 <_main+0x90>
1000008e0:     	ldp	x23, x24, [x29, #0x30]
1000008e4:     	add	x1, x29, #0x50
1000008e8:     	mov	w0, #0x6                ; =6
1000008ec:     	bl	0x10000097c <_strtoul+0x10000097c>
1000008f0:     	mov	w19, w0
1000008f4:     	cbnz	w0, 0x10000096c <_main+0x16c>
1000008f8:     	adrp	x0, 0x100008000 <_event_hash>
1000008fc:     	ldr	w0, [x0]
100000900:     	str	w0, [sp, #0x28]
100000904:     	adrp	x0, 0x100008000 <_event_hash>
100000908:     	add	x0, x0, #0x4
10000090c:     	ldr	w1, [x0, #0x8]
100000910:     	str	w1, [sp, #0x20]
100000914:     	ldp	w0, w1, [x0]
100000918:     	str	w20, [sp, #0x8]
10000091c:     	str	w0, [sp, #0x10]
100000920:     	ldr	x0, [x29, #0x58]
100000924:     	str	w1, [sp, #0x18]
100000928:     	ldr	x1, [x29, #0x48]
10000092c:     	sub	x0, x0, x1
100000930:     	ldr	x1, [x29, #0x40]
100000934:     	scvtf	d0, x0
100000938:     	adrp	x0, 0x100000000 <_strtoul+0x100000000>
10000093c:     	ldr	d30, [x0, #0x9b8]
100000940:     	ldr	x0, [x29, #0x50]
100000944:     	fmul	d30, d0, d30
100000948:     	sub	x0, x0, x1
10000094c:     	scvtf	d31, x0
100000950:     	adrp	x0, 0x100000000 <_strtoul+0x100000000>
100000954:     	add	x0, x0, #0x9a0
100000958:     	fadd	d31, d30, d31
10000095c:     	str	d31, [sp]
100000960:     	bl	0x100000988 <_strtoul+0x100000988>
100000964:     	ldp	x21, x22, [x29, #0x20]
100000968:     	b	0x10000081c <_main+0x1c>
10000096c:     	ldp	x21, x22, [x29, #0x20]
100000970:     	b	0x100000818 <_main+0x18>
100000974:     	mov	w20, #0x0               ; =0
100000978:     	b	0x1000008e4 <_main+0xe4>

Disassembly of section __TEXT,__stubs:

000000010000097c <__stubs>:
10000097c:     	adrp	x16, 0x100004000 <_strtoul+0x100004000>
100000980:     	ldr	x16, [x16]
100000984:     	br	x16
100000988:     	adrp	x16, 0x100004000 <_strtoul+0x100004000>
10000098c:     	ldr	x16, [x16, #0x8]
100000990:     	br	x16
100000994:     	adrp	x16, 0x100004000 <_strtoul+0x100004000>
100000998:     	ldr	x16, [x16, #0x10]
10000099c:     	br	x16
