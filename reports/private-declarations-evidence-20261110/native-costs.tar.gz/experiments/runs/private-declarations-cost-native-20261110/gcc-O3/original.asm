
/Users/admin/C-SRD/experiments/runs/private-declarations-cost-native-20261110/gcc-O3/original:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001000006a0 <_region_pipeline>:
1000006a0:     	stp	x29, x30, [sp, #-0x50]!
1000006a4:     	mov	x29, sp
1000006a8:     	stp	x21, x22, [sp, #0x20]
1000006ac:     	stp	x23, x24, [sp, #0x30]
1000006b0:     	mov	x24, x0
1000006b4:     	ldr	w21, [x0]
1000006b8:     	str	x25, [sp, #0x40]
1000006bc:     	mov	w25, w2
1000006c0:     	add	w23, w21, w1
1000006c4:     	add	w22, w23, w23, lsl #1
1000006c8:     	mov	w0, w23
1000006cc:     	add	w22, w22, #0xb
1000006d0:     	sub	w21, w22, w21
1000006d4:     	bl	0x1000007a0 <_record_event>
1000006d8:     	cmp	w25, #0x0
1000006dc:     	b.le	0x10000072c <_region_pipeline+0x8c>
1000006e0:     	stp	x19, x20, [x29, #0x10]
1000006e4:     	mov	w0, w21
1000006e8:     	bl	0x1000007c0 <_next_value>
1000006ec:     	add	w19, w0, w0, lsl #2
1000006f0:     	sub	w1, w23, w0
1000006f4:     	mov	w20, w0
1000006f8:     	add	w21, w0, w21
1000006fc:     	add	w19, w19, w22
100000700:     	add	w22, w1, w19
100000704:     	mov	w0, w19
100000708:     	add	w19, w19, #0x7
10000070c:     	add	w21, w21, w22
100000710:     	bl	0x1000007a0 <_record_event>
100000714:     	mov	w0, w20
100000718:     	str	w19, [x24]
10000071c:     	bl	0x1000007a0 <_record_event>
100000720:     	subs	w25, w25, #0x1
100000724:     	b.ne	0x1000006e4 <_region_pipeline+0x44>
100000728:     	ldp	x19, x20, [x29, #0x10]
10000072c:     	mov	w0, w21
100000730:     	ldp	x21, x22, [sp, #0x20]
100000734:     	ldp	x23, x24, [sp, #0x30]
100000738:     	ldr	x25, [sp, #0x40]
10000073c:     	ldp	x29, x30, [sp], #0x50
100000740:     	ret

0000000100000744 <_region_outputs>:
100000744:     	stp	x29, x30, [sp, #-0x20]!
100000748:     	mov	x29, sp
10000074c:     	stp	x19, x20, [sp, #0x10]
100000750:     	add	w19, w1, #0x11
100000754:     	mov	x20, x0
100000758:     	add	w19, w19, w19, lsl #1
10000075c:     	add	w19, w19, w2
100000760:     	mov	w0, w19
100000764:     	bl	0x1000007a0 <_record_event>
100000768:     	add	w1, w19, #0x7
10000076c:     	mov	w2, #0x11               ; =17
100000770:     	sub	w19, w19, #0x11
100000774:     	mov	w0, #0x0                ; =0
100000778:     	str	w1, [x20, #0x8]
10000077c:     	stp	w19, w2, [x20]
100000780:     	ldp	x19, x20, [sp, #0x10]
100000784:     	ldp	x29, x30, [sp], #0x20
100000788:     	ret
		...

00000001000007a0 <_record_event>:
1000007a0:     	adrp	x2, 0x100008000 <_event_hash>
1000007a4:     	ldr	w1, [x2]
1000007a8:     	add	w1, w1, w1, lsl #5
1000007ac:     	eor	w1, w1, w0
1000007b0:     	str	w1, [x2]
1000007b4:     	ret
1000007b8:     	nop
1000007bc:     	nop

00000001000007c0 <_next_value>:
1000007c0:     	adrp	x4, 0x100008000 <_event_hash>
1000007c4:     	adrp	x2, 0x100008000 <_event_hash>
1000007c8:     	ldr	w1, [x4]
1000007cc:     	add	x2, x2, #0x4
1000007d0:     	ldr	w3, [x2, #0x4]
1000007d4:     	add	w1, w1, w1, lsl #5
1000007d8:     	add	w3, w0, w3
1000007dc:     	eor	w1, w1, w0
1000007e0:     	add	w0, w3, w0
1000007e4:     	str	w1, [x4]
1000007e8:     	str	w3, [x2, #0x4]
1000007ec:     	ret

Disassembly of section __TEXT,__text_startup:

0000000100000800 <_main>:
100000800:     	sub	sp, sp, #0x90
100000804:     	stp	x29, x30, [sp, #0x30]
100000808:     	add	x29, sp, #0x30
10000080c:     	stp	x19, x20, [sp, #0x40]
100000810:     	cmp	w0, #0x3
100000814:     	b.eq	0x100000830 <_main+0x30>
100000818:     	mov	w19, #0x2               ; =2
10000081c:     	ldp	x29, x30, [sp, #0x30]
100000820:     	mov	w0, w19
100000824:     	ldp	x19, x20, [sp, #0x40]
100000828:     	add	sp, sp, #0x90
10000082c:     	ret
100000830:     	mov	x19, x1
100000834:     	mov	w2, #0xa                ; =10
100000838:     	stp	x21, x22, [x29, #0x20]
10000083c:     	mov	x1, #0x0                ; =0
100000840:     	ldr	x0, [x19, #0x8]
100000844:     	bl	0x10000098c <_strtoul+0x10000098c>
100000848:     	mov	x1, #0x0                ; =0
10000084c:     	mov	x21, x0
100000850:     	ldr	x0, [x19, #0x10]
100000854:     	mov	w2, #0xa                ; =10
100000858:     	bl	0x10000098c <_strtoul+0x10000098c>
10000085c:     	mov	x19, x0
100000860:     	add	x1, x29, #0x40
100000864:     	mov	w0, #0x6                ; =6
100000868:     	bl	0x100000974 <_strtoul+0x100000974>
10000086c:     	cbnz	w0, 0x100000964 <_main+0x164>
100000870:     	cbz	x21, 0x10000096c <_main+0x16c>
100000874:     	adrp	x22, 0x100008000 <_event_hash>
100000878:     	stp	x23, x24, [x29, #0x30]
10000087c:     	mov	x23, #-0x3333333333333334 ; =-3689348814741910324
100000880:     	mov	x24, #0x0               ; =0
100000884:     	mov	w20, #0x0               ; =0
100000888:     	add	x22, x22, #0x4
10000088c:     	movk	x23, #0xcccd
100000890:     	umulh	x1, x24, x23
100000894:     	mov	x0, x22
100000898:     	eor	w19, w19, w19, lsl #13
10000089c:     	lsr	x1, x1, #3
1000008a0:     	eor	w19, w19, w19, lsr #17
1000008a4:     	add	x1, x1, x1, lsl #2
1000008a8:     	eor	w19, w19, w19, lsl #5
1000008ac:     	sub	x2, x24, x1, lsl #1
1000008b0:     	add	x24, x24, #0x1
1000008b4:     	mov	w1, w19
1000008b8:     	sub	w2, w2, #0x1
1000008bc:     	bl	0x1000006a0 <_region_pipeline>
1000008c0:     	add	w20, w0, w20
1000008c4:     	mov	w1, w19
1000008c8:     	mov	w2, w20
1000008cc:     	mov	x0, x22
1000008d0:     	bl	0x100000744 <_region_outputs>
1000008d4:     	add	w20, w0, w20
1000008d8:     	cmp	x21, x24
1000008dc:     	b.ne	0x100000890 <_main+0x90>
1000008e0:     	ldp	x23, x24, [x29, #0x30]
1000008e4:     	add	x1, x29, #0x50
1000008e8:     	mov	w0, #0x6                ; =6
1000008ec:     	bl	0x100000974 <_strtoul+0x100000974>
1000008f0:     	mov	w19, w0
1000008f4:     	cbnz	w0, 0x100000964 <_main+0x164>
1000008f8:     	ldp	x6, x4, [x29, #0x40]
1000008fc:     	adrp	x0, 0x100000000 <_strtoul+0x100000000>
100000900:     	adrp	x1, 0x100008000 <_event_hash>
100000904:     	add	x1, x1, #0x4
100000908:     	adrp	x5, 0x100008000 <_event_hash>
10000090c:     	ldp	x2, x3, [x29, #0x50]
100000910:     	str	w20, [sp, #0x8]
100000914:     	ldr	d30, [x0, #0x9b0]
100000918:     	adrp	x0, 0x100000000 <_strtoul+0x100000000>
10000091c:     	sub	x3, x3, x4
100000920:     	sub	x2, x2, x6
100000924:     	ldr	w4, [x1, #0x8]
100000928:     	add	x0, x0, #0x998
10000092c:     	scvtf	d0, x3
100000930:     	scvtf	d31, x2
100000934:     	ldp	w3, w1, [x1]
100000938:     	str	w4, [sp, #0x20]
10000093c:     	fmul	d30, d0, d30
100000940:     	str	w1, [sp, #0x18]
100000944:     	ldr	w1, [x5]
100000948:     	str	w3, [sp, #0x10]
10000094c:     	fadd	d31, d30, d31
100000950:     	str	w1, [sp, #0x28]
100000954:     	str	d31, [sp]
100000958:     	bl	0x100000980 <_strtoul+0x100000980>
10000095c:     	ldp	x21, x22, [x29, #0x20]
100000960:     	b	0x10000081c <_main+0x1c>
100000964:     	ldp	x21, x22, [x29, #0x20]
100000968:     	b	0x100000818 <_main+0x18>
10000096c:     	mov	w20, #0x0               ; =0
100000970:     	b	0x1000008e4 <_main+0xe4>

Disassembly of section __TEXT,__stubs:

0000000100000974 <__stubs>:
100000974:     	adrp	x16, 0x100004000 <_strtoul+0x100004000>
100000978:     	ldr	x16, [x16]
10000097c:     	br	x16
100000980:     	adrp	x16, 0x100004000 <_strtoul+0x100004000>
100000984:     	ldr	x16, [x16, #0x8]
100000988:     	br	x16
10000098c:     	adrp	x16, 0x100004000 <_strtoul+0x100004000>
100000990:     	ldr	x16, [x16, #0x10]
100000994:     	br	x16
