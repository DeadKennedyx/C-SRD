
/Users/admin/C-SRD/experiments/runs/private-declarations-cost-native-20261110/gcc-O3/affine:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001000006a0 <_region_pipeline>:
1000006a0:     	stp	x29, x30, [sp, #-0x60]!
1000006a4:     	mov	x29, sp
1000006a8:     	mov	w3, #0xc255             ; =49749
1000006ac:     	mov	w4, #0x8950             ; =35152
1000006b0:     	movk	w3, #0xf13, lsl #16
1000006b4:     	movk	w4, #0xf66f, lsl #16
1000006b8:     	stp	x19, x20, [sp, #0x10]
1000006bc:     	stp	x21, x22, [sp, #0x20]
1000006c0:     	mov	w21, #0x2afd            ; =11005
1000006c4:     	mov	x22, x0
1000006c8:     	movk	w21, #0xca3b, lsl #16
1000006cc:     	stp	x23, x24, [sp, #0x30]
1000006d0:     	mov	w23, #0x2bf0            ; =11248
1000006d4:     	movk	w23, #0x61ce, lsl #16
1000006d8:     	stp	x25, x26, [sp, #0x40]
1000006dc:     	stp	x27, x28, [sp, #0x50]
1000006e0:     	mov	w28, w2
1000006e4:     	ldr	w19, [x0]
1000006e8:     	mov	w0, #0x4707             ; =18183
1000006ec:     	movk	w0, #0xb8fa, lsl #16
1000006f0:     	madd	w19, w19, w3, w4
1000006f4:     	madd	w1, w1, w3, w19
1000006f8:     	add	w26, w1, w1, lsl #1
1000006fc:     	madd	w20, w1, w21, w23
100000700:     	add	w26, w26, w0
100000704:     	sub	w19, w26, w19
100000708:     	mov	w0, w20
10000070c:     	mul	w19, w19, w21
100000710:     	bl	0x1000008a0 <_record_event>
100000714:     	cmp	w28, #0x0
100000718:     	b.le	0x1000007ec <_region_pipeline+0x14c>
10000071c:     	mov	w24, #0xb955            ; =47445
100000720:     	mov	w0, #0xdfe6             ; =57318
100000724:     	madd	w26, w26, w21, w23
100000728:     	movk	w24, #0xcb3a, lsl #16
10000072c:     	movk	w0, #0xc9, lsl #16
100000730:     	mov	w23, #0x1bd9            ; =7129
100000734:     	mov	w21, #0xeff3            ; =61427
100000738:     	madd	w20, w20, w24, w0
10000073c:     	movk	w23, #0xc428, lsl #16
100000740:     	movk	w21, #0x8064, lsl #16
100000744:     	mov	w0, w19
100000748:     	madd	w19, w19, w24, w21
10000074c:     	bl	0x1000008c0 <_next_value>
100000750:     	mov	w25, w0
100000754:     	madd	w0, w0, w24, w21
100000758:     	mov	w5, #0x7bfd             ; =31741
10000075c:     	movk	w5, #0x43f, lsl #16
100000760:     	mov	w6, #0x37b2             ; =14258
100000764:     	movk	w6, #0x8850, lsl #16
100000768:     	sub	w3, w20, w0
10000076c:     	add	w1, w0, w0, lsl #2
100000770:     	add	w19, w19, w0
100000774:     	mov	w0, #0x4034             ; =16436
100000778:     	movk	w0, #0xfe6c, lsl #16
10000077c:     	add	w1, w1, w0
100000780:     	madd	w1, w26, w24, w1
100000784:     	mul	w27, w1, w5
100000788:     	add	w0, w3, w1
10000078c:     	madd	w26, w0, w5, w6
100000790:     	add	w0, w27, w23
100000794:     	bl	0x1000008a0 <_record_event>
100000798:     	mov	w3, #0xf145             ; =61765
10000079c:     	mov	w0, #0x9b1c             ; =39708
1000007a0:     	movk	w3, #0x4348, lsl #16
1000007a4:     	movk	w0, #0xe963, lsl #16
1000007a8:     	mov	w1, #0xf8e9             ; =63721
1000007ac:     	mov	w2, #0x1be0             ; =7136
1000007b0:     	madd	w19, w19, w3, w0
1000007b4:     	movk	w1, #0x6e34, lsl #16
1000007b8:     	movk	w2, #0xc428, lsl #16
1000007bc:     	add	w27, w27, w2
1000007c0:     	mov	w5, #0x5f59             ; =24409
1000007c4:     	mov	w3, #0xe6f6             ; =59126
1000007c8:     	movk	w5, #0xeb1f, lsl #16
1000007cc:     	madd	w1, w26, w1, w19
1000007d0:     	movk	w3, #0xf1bb, lsl #16
1000007d4:     	mov	w0, w25
1000007d8:     	str	w27, [x22]
1000007dc:     	madd	w19, w1, w5, w3
1000007e0:     	bl	0x1000008a0 <_record_event>
1000007e4:     	subs	w28, w28, #0x1
1000007e8:     	b.ne	0x100000744 <_region_pipeline+0xa4>
1000007ec:     	mov	w0, w19
1000007f0:     	ldp	x21, x22, [sp, #0x20]
1000007f4:     	ldp	x19, x20, [sp, #0x10]
1000007f8:     	ldp	x23, x24, [sp, #0x30]
1000007fc:     	ldp	x25, x26, [sp, #0x40]
100000800:     	ldp	x27, x28, [sp, #0x50]
100000804:     	ldp	x29, x30, [sp], #0x60
100000808:     	ret

000000010000080c <_region_outputs>:
10000080c:     	mov	w6, #0x41b5             ; =16821
100000810:     	mov	w5, #0x609b             ; =24731
100000814:     	stp	x29, x30, [sp, #-0x30]!
100000818:     	movk	w6, #0x9ed1, lsl #16
10000081c:     	movk	w5, #0x4c22, lsl #16
100000820:     	mov	w4, #0xc51f             ; =50463
100000824:     	mov	w3, #0x649d             ; =25757
100000828:     	madd	w2, w2, w6, w5
10000082c:     	movk	w4, #0xdc73, lsl #16
100000830:     	movk	w3, #0xec00, lsl #16
100000834:     	mov	x29, sp
100000838:     	stp	x19, x20, [sp, #0x10]
10000083c:     	mov	w20, #0x3524            ; =13604
100000840:     	madd	w1, w1, w4, w2
100000844:     	movk	w20, #0xfd2e, lsl #16
100000848:     	str	x21, [sp, #0x20]
10000084c:     	mov	x21, x0
100000850:     	mul	w19, w1, w3
100000854:     	add	w0, w19, w20
100000858:     	add	w20, w20, #0x7
10000085c:     	bl	0x1000008a0 <_record_event>
100000860:     	sub	w0, w20, #0x18
100000864:     	mov	w1, #0x11               ; =17
100000868:     	add	w20, w19, w20
10000086c:     	add	w19, w19, w0
100000870:     	mov	w0, #0x0                ; =0
100000874:     	stp	w19, w1, [x21]
100000878:     	str	w20, [x21, #0x8]
10000087c:     	ldr	x21, [sp, #0x20]
100000880:     	ldp	x19, x20, [sp, #0x10]
100000884:     	ldp	x29, x30, [sp], #0x30
100000888:     	ret
		...

00000001000008a0 <_record_event>:
1000008a0:     	adrp	x2, 0x100008000 <_event_hash>
1000008a4:     	ldr	w1, [x2]
1000008a8:     	add	w1, w1, w1, lsl #5
1000008ac:     	eor	w1, w1, w0
1000008b0:     	str	w1, [x2]
1000008b4:     	ret
1000008b8:     	nop
1000008bc:     	nop

00000001000008c0 <_next_value>:
1000008c0:     	adrp	x4, 0x100008000 <_event_hash>
1000008c4:     	adrp	x2, 0x100008000 <_event_hash>
1000008c8:     	ldr	w1, [x4]
1000008cc:     	add	x2, x2, #0x4
1000008d0:     	ldr	w3, [x2, #0x4]
1000008d4:     	add	w1, w1, w1, lsl #5
1000008d8:     	add	w3, w0, w3
1000008dc:     	eor	w1, w1, w0
1000008e0:     	add	w0, w3, w0
1000008e4:     	str	w1, [x4]
1000008e8:     	str	w3, [x2, #0x4]
1000008ec:     	ret

Disassembly of section __TEXT,__text_startup:

0000000100000900 <_main>:
100000900:     	sub	sp, sp, #0x90
100000904:     	stp	x29, x30, [sp, #0x30]
100000908:     	add	x29, sp, #0x30
10000090c:     	stp	x19, x20, [sp, #0x40]
100000910:     	cmp	w0, #0x3
100000914:     	b.eq	0x100000930 <_main+0x30>
100000918:     	mov	w19, #0x2               ; =2
10000091c:     	ldp	x29, x30, [sp, #0x30]
100000920:     	mov	w0, w19
100000924:     	ldp	x19, x20, [sp, #0x40]
100000928:     	add	sp, sp, #0x90
10000092c:     	ret
100000930:     	mov	x19, x1
100000934:     	mov	w2, #0xa                ; =10
100000938:     	stp	x21, x22, [x29, #0x20]
10000093c:     	mov	x1, #0x0                ; =0
100000940:     	ldr	x0, [x19, #0x8]
100000944:     	bl	0x100000a8c <_strtoul+0x100000a8c>
100000948:     	mov	x1, #0x0                ; =0
10000094c:     	mov	x21, x0
100000950:     	ldr	x0, [x19, #0x10]
100000954:     	mov	w2, #0xa                ; =10
100000958:     	bl	0x100000a8c <_strtoul+0x100000a8c>
10000095c:     	mov	x19, x0
100000960:     	add	x1, x29, #0x40
100000964:     	mov	w0, #0x6                ; =6
100000968:     	bl	0x100000a74 <_strtoul+0x100000a74>
10000096c:     	cbnz	w0, 0x100000a64 <_main+0x164>
100000970:     	cbz	x21, 0x100000a6c <_main+0x16c>
100000974:     	adrp	x22, 0x100008000 <_event_hash>
100000978:     	stp	x23, x24, [x29, #0x30]
10000097c:     	mov	x23, #-0x3333333333333334 ; =-3689348814741910324
100000980:     	mov	x24, #0x0               ; =0
100000984:     	mov	w20, #0x0               ; =0
100000988:     	add	x22, x22, #0x4
10000098c:     	movk	x23, #0xcccd
100000990:     	umulh	x1, x24, x23
100000994:     	mov	x0, x22
100000998:     	eor	w19, w19, w19, lsl #13
10000099c:     	lsr	x1, x1, #3
1000009a0:     	eor	w19, w19, w19, lsr #17
1000009a4:     	add	x1, x1, x1, lsl #2
1000009a8:     	eor	w19, w19, w19, lsl #5
1000009ac:     	sub	x2, x24, x1, lsl #1
1000009b0:     	add	x24, x24, #0x1
1000009b4:     	mov	w1, w19
1000009b8:     	sub	w2, w2, #0x1
1000009bc:     	bl	0x1000006a0 <_region_pipeline>
1000009c0:     	add	w20, w0, w20
1000009c4:     	mov	w1, w19
1000009c8:     	mov	w2, w20
1000009cc:     	mov	x0, x22
1000009d0:     	bl	0x10000080c <_region_outputs>
1000009d4:     	add	w20, w0, w20
1000009d8:     	cmp	x21, x24
1000009dc:     	b.ne	0x100000990 <_main+0x90>
1000009e0:     	ldp	x23, x24, [x29, #0x30]
1000009e4:     	add	x1, x29, #0x50
1000009e8:     	mov	w0, #0x6                ; =6
1000009ec:     	bl	0x100000a74 <_strtoul+0x100000a74>
1000009f0:     	mov	w19, w0
1000009f4:     	cbnz	w0, 0x100000a64 <_main+0x164>
1000009f8:     	ldp	x6, x4, [x29, #0x40]
1000009fc:     	adrp	x0, 0x100000000 <_strtoul+0x100000000>
100000a00:     	adrp	x1, 0x100008000 <_event_hash>
100000a04:     	add	x1, x1, #0x4
100000a08:     	adrp	x5, 0x100008000 <_event_hash>
100000a0c:     	ldp	x2, x3, [x29, #0x50]
100000a10:     	str	w20, [sp, #0x8]
100000a14:     	ldr	d30, [x0, #0xab0]
100000a18:     	adrp	x0, 0x100000000 <_strtoul+0x100000000>
100000a1c:     	sub	x3, x3, x4
100000a20:     	sub	x2, x2, x6
100000a24:     	ldr	w4, [x1, #0x8]
100000a28:     	add	x0, x0, #0xa98
100000a2c:     	scvtf	d0, x3
100000a30:     	scvtf	d31, x2
100000a34:     	ldp	w3, w1, [x1]
100000a38:     	str	w4, [sp, #0x20]
100000a3c:     	fmul	d30, d0, d30
100000a40:     	str	w1, [sp, #0x18]
100000a44:     	ldr	w1, [x5]
100000a48:     	str	w3, [sp, #0x10]
100000a4c:     	fadd	d31, d30, d31
100000a50:     	str	w1, [sp, #0x28]
100000a54:     	str	d31, [sp]
100000a58:     	bl	0x100000a80 <_strtoul+0x100000a80>
100000a5c:     	ldp	x21, x22, [x29, #0x20]
100000a60:     	b	0x10000091c <_main+0x1c>
100000a64:     	ldp	x21, x22, [x29, #0x20]
100000a68:     	b	0x100000918 <_main+0x18>
100000a6c:     	mov	w20, #0x0               ; =0
100000a70:     	b	0x1000009e4 <_main+0xe4>

Disassembly of section __TEXT,__stubs:

0000000100000a74 <__stubs>:
100000a74:     	adrp	x16, 0x100004000 <_strtoul+0x100004000>
100000a78:     	ldr	x16, [x16]
100000a7c:     	br	x16
100000a80:     	adrp	x16, 0x100004000 <_strtoul+0x100004000>
100000a84:     	ldr	x16, [x16, #0x8]
100000a88:     	br	x16
100000a8c:     	adrp	x16, 0x100004000 <_strtoul+0x100004000>
100000a90:     	ldr	x16, [x16, #0x10]
100000a94:     	br	x16
