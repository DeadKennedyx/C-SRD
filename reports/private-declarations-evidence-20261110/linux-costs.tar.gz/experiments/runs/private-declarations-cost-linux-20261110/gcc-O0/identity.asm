
/work/experiments/runs/private-declarations-cost-linux-20261110/gcc-O0/identity:	file format elf64-littleaarch64

Disassembly of section .init:

00000000000006f0 <_init>:
     6f0:      	nop
     6f4:      	stp	x29, x30, [sp, #-0x10]!
     6f8:      	mov	x29, sp
     6fc:      	bl	0x7f4 <call_weak_fn>
     700:      	ldp	x29, x30, [sp], #0x10
     704:      	ret

Disassembly of section .plt:

0000000000000710 <.plt>:
     710:      	stp	x16, x30, [sp, #-0x10]!
     714:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1dfc8>
     718:      	ldr	x17, [x16, #0xf80]
     71c:      	add	x16, x16, #0xf80
     720:      	br	x17
     724:      	nop
     728:      	nop
     72c:      	nop

0000000000000730 <strtoul@plt>:
     730:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1dfc8>
     734:      	ldr	x17, [x16, #0xf88]
     738:      	add	x16, x16, #0xf88
     73c:      	br	x17

0000000000000740 <__libc_start_main@plt>:
     740:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1dfc8>
     744:      	ldr	x17, [x16, #0xf90]
     748:      	add	x16, x16, #0xf90
     74c:      	br	x17

0000000000000750 <__cxa_finalize@plt>:
     750:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1dfc8>
     754:      	ldr	x17, [x16, #0xf98]
     758:      	add	x16, x16, #0xf98
     75c:      	br	x17

0000000000000760 <clock_gettime@plt>:
     760:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1dfc8>
     764:      	ldr	x17, [x16, #0xfa0]
     768:      	add	x16, x16, #0xfa0
     76c:      	br	x17

0000000000000770 <__stack_chk_fail@plt>:
     770:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1dfc8>
     774:      	ldr	x17, [x16, #0xfa8]
     778:      	add	x16, x16, #0xfa8
     77c:      	br	x17

0000000000000780 <__gmon_start__@plt>:
     780:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1dfc8>
     784:      	ldr	x17, [x16, #0xfb0]
     788:      	add	x16, x16, #0xfb0
     78c:      	br	x17

0000000000000790 <abort@plt>:
     790:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1dfc8>
     794:      	ldr	x17, [x16, #0xfb8]
     798:      	add	x16, x16, #0xfb8
     79c:      	br	x17

00000000000007a0 <printf@plt>:
     7a0:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1dfc8>
     7a4:      	ldr	x17, [x16, #0xfc0]
     7a8:      	add	x16, x16, #0xfc0
     7ac:      	br	x17

Disassembly of section .text:

00000000000007c0 <_start>:
     7c0:      	nop
     7c4:      	mov	x29, #0x0               // =0
     7c8:      	mov	x30, #0x0               // =0
     7cc:      	mov	x5, x0
     7d0:      	ldr	x1, [sp]
     7d4:      	add	x2, sp, #0x8
     7d8:      	mov	x6, sp
     7dc:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1dfc8>
     7e0:      	ldr	x0, [x0, #0xff0]
     7e4:      	mov	x3, #0x0                // =0
     7e8:      	mov	x4, #0x0                // =0
     7ec:      	bl	0x740 <__libc_start_main@plt>
     7f0:      	bl	0x790 <abort@plt>

00000000000007f4 <call_weak_fn>:
     7f4:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1dfc8>
     7f8:      	ldr	x0, [x0, #0xfe0]
     7fc:      	cbz	x0, 0x804 <call_weak_fn+0x10>
     800:      	b	0x780 <__gmon_start__@plt>
     804:      	ret
     808:      	nop
     80c:      	nop

0000000000000810 <deregister_tm_clones>:
     810:      	adrp	x0, 0x20000 <data_start>
     814:      	add	x0, x0, #0x10
     818:      	adrp	x1, 0x20000 <data_start>
     81c:      	add	x1, x1, #0x10
     820:      	cmp	x1, x0
     824:      	b.eq	0x83c <deregister_tm_clones+0x2c>
     828:      	adrp	x1, 0x1f000 <__FRAME_END__+0x1dfc8>
     82c:      	ldr	x1, [x1, #0xfd0]
     830:      	cbz	x1, 0x83c <deregister_tm_clones+0x2c>
     834:      	mov	x16, x1
     838:      	br	x16
     83c:      	ret

0000000000000840 <register_tm_clones>:
     840:      	adrp	x0, 0x20000 <data_start>
     844:      	add	x0, x0, #0x10
     848:      	adrp	x1, 0x20000 <data_start>
     84c:      	add	x1, x1, #0x10
     850:      	sub	x1, x1, x0
     854:      	lsr	x2, x1, #63
     858:      	add	x1, x2, x1, asr #3
     85c:      	asr	x1, x1, #1
     860:      	cbz	x1, 0x878 <register_tm_clones+0x38>
     864:      	adrp	x2, 0x1f000 <__FRAME_END__+0x1dfc8>
     868:      	ldr	x2, [x2, #0xff8]
     86c:      	cbz	x2, 0x878 <register_tm_clones+0x38>
     870:      	mov	x16, x2
     874:      	br	x16
     878:      	ret
     87c:      	nop

0000000000000880 <__do_global_dtors_aux>:
     880:      	paciasp
     884:      	stp	x29, x30, [sp, #-0x20]!
     888:      	mov	x29, sp
     88c:      	str	x19, [sp, #0x10]
     890:      	adrp	x19, 0x20000 <data_start>
     894:      	ldrb	w0, [x19, #0x10]
     898:      	tbnz	w0, #0x0, 0x8c0 <__do_global_dtors_aux+0x40>
     89c:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1dfc8>
     8a0:      	ldr	x0, [x0, #0xfd8]
     8a4:      	cbz	x0, 0x8b4 <__do_global_dtors_aux+0x34>
     8a8:      	adrp	x0, 0x20000 <data_start>
     8ac:      	ldr	x0, [x0, #0x8]
     8b0:      	bl	0x750 <__cxa_finalize@plt>
     8b4:      	bl	0x810 <deregister_tm_clones>
     8b8:      	mov	w0, #0x1                // =1
     8bc:      	strb	w0, [x19, #0x10]
     8c0:      	ldr	x19, [sp, #0x10]
     8c4:      	ldp	x29, x30, [sp], #0x20
     8c8:      	autiasp
     8cc:      	ret

00000000000008d0 <frame_dummy>:
     8d0:      	bti	c
     8d4:      	b	0x840 <register_tm_clones>

00000000000008d8 <region_pipeline>:
     8d8:      	stp	x29, x30, [sp, #-0x80]!
     8dc:      	mov	x29, sp
     8e0:      	str	x19, [sp, #0x10]
     8e4:      	str	x0, [sp, #0x28]
     8e8:      	str	w1, [sp, #0x24]
     8ec:      	str	w2, [sp, #0x20]
     8f0:      	ldr	x0, [sp, #0x28]
     8f4:      	ldr	w0, [x0]
     8f8:      	str	w0, [sp, #0x40]
     8fc:      	ldr	w0, [sp, #0x24]
     900:      	str	w0, [sp, #0x44]
     904:      	ldr	w0, [sp, #0x40]
     908:      	str	w0, [sp, #0x48]
     90c:      	ldr	w1, [sp, #0x44]
     910:      	ldr	w0, [sp, #0x48]
     914:      	add	w0, w1, w0
     918:      	str	w0, [sp, #0x4c]
     91c:      	ldr	w1, [sp, #0x4c]
     920:      	mov	w0, w1
     924:      	lsl	w0, w0, #1
     928:      	add	w0, w0, w1
     92c:      	add	w0, w0, #0xb
     930:      	str	w0, [sp, #0x50]
     934:      	ldr	w1, [sp, #0x50]
     938:      	ldr	w0, [sp, #0x48]
     93c:      	sub	w0, w1, w0
     940:      	str	w0, [sp, #0x44]
     944:      	ldr	w0, [sp, #0x44]
     948:      	str	w0, [sp, #0x24]
     94c:      	ldr	w19, [sp, #0x4c]
     950:      	ldr	w0, [sp, #0x50]
     954:      	str	w0, [sp, #0x3c]
     958:      	mov	w0, w19
     95c:      	bl	0xb80 <record_event>
     960:      	ldr	w0, [sp, #0x20]
     964:      	cmp	w0, #0x0
     968:      	b.ge	0xa68 <region_pipeline+0x190>
     96c:      	ldr	w0, [sp, #0x24]
     970:      	b	0xa80 <region_pipeline+0x1a8>
     974:      	ldr	w0, [sp, #0x24]
     978:      	bl	0xbc0 <next_value>
     97c:      	str	w0, [sp, #0x40]
     980:      	ldr	w0, [sp, #0x24]
     984:      	str	w0, [sp, #0x54]
     988:      	ldr	w0, [sp, #0x40]
     98c:      	str	w0, [sp, #0x58]
     990:      	ldr	w0, [sp, #0x3c]
     994:      	str	w0, [sp, #0x5c]
     998:      	str	w19, [sp, #0x60]
     99c:      	ldr	w1, [sp, #0x54]
     9a0:      	ldr	w0, [sp, #0x58]
     9a4:      	add	w0, w1, w0
     9a8:      	str	w0, [sp, #0x54]
     9ac:      	ldr	w1, [sp, #0x58]
     9b0:      	mov	w0, w1
     9b4:      	lsl	w0, w0, #2
     9b8:      	add	w0, w0, w1
     9bc:      	ldr	w1, [sp, #0x5c]
     9c0:      	add	w0, w1, w0
     9c4:      	str	w0, [sp, #0x64]
     9c8:      	ldr	w1, [sp, #0x64]
     9cc:      	ldr	w0, [sp, #0x58]
     9d0:      	sub	w0, w1, w0
     9d4:      	str	w0, [sp, #0x68]
     9d8:      	ldr	w1, [sp, #0x68]
     9dc:      	ldr	w0, [sp, #0x60]
     9e0:      	add	w0, w1, w0
     9e4:      	str	w0, [sp, #0x5c]
     9e8:      	ldr	w0, [sp, #0x54]
     9ec:      	str	w0, [sp, #0x24]
     9f0:      	ldr	w0, [sp, #0x5c]
     9f4:      	str	w0, [sp, #0x3c]
     9f8:      	ldr	w0, [sp, #0x64]
     9fc:      	str	w0, [sp, #0x6c]
     a00:      	ldr	w0, [sp, #0x68]
     a04:      	str	w0, [sp, #0x70]
     a08:      	ldr	w0, [sp, #0x6c]
     a0c:      	bl	0xb80 <record_event>
     a10:      	ldr	w0, [sp, #0x6c]
     a14:      	str	w0, [sp, #0x74]
     a18:      	ldr	w0, [sp, #0x74]
     a1c:      	add	w0, w0, #0x7
     a20:      	str	w0, [sp, #0x74]
     a24:      	ldr	w0, [sp, #0x74]
     a28:      	str	w0, [sp, #0x6c]
     a2c:      	ldr	x0, [sp, #0x28]
     a30:      	ldr	w1, [sp, #0x6c]
     a34:      	str	w1, [x0]
     a38:      	ldr	w0, [sp, #0x24]
     a3c:      	str	w0, [sp, #0x78]
     a40:      	ldr	w0, [sp, #0x3c]
     a44:      	str	w0, [sp, #0x7c]
     a48:      	ldr	w1, [sp, #0x78]
     a4c:      	ldr	w0, [sp, #0x7c]
     a50:      	add	w0, w1, w0
     a54:      	str	w0, [sp, #0x78]
     a58:      	ldr	w0, [sp, #0x78]
     a5c:      	str	w0, [sp, #0x24]
     a60:      	ldr	w0, [sp, #0x40]
     a64:      	bl	0xb80 <record_event>
     a68:      	ldr	w0, [sp, #0x20]
     a6c:      	sub	w1, w0, #0x1
     a70:      	str	w1, [sp, #0x20]
     a74:      	cmp	w0, #0x0
     a78:      	b.gt	0x974 <region_pipeline+0x9c>
     a7c:      	ldr	w0, [sp, #0x24]
     a80:      	ldr	x19, [sp, #0x10]
     a84:      	ldp	x29, x30, [sp], #0x80
     a88:      	ret

0000000000000a8c <region_outputs>:
     a8c:      	stp	x29, x30, [sp, #-0x50]!
     a90:      	mov	x29, sp
     a94:      	str	x19, [sp, #0x10]
     a98:      	str	x0, [sp, #0x28]
     a9c:      	str	w1, [sp, #0x24]
     aa0:      	str	w2, [sp, #0x20]
     aa4:      	ldr	w0, [sp, #0x24]
     aa8:      	str	w0, [sp, #0x30]
     aac:      	ldr	w0, [sp, #0x20]
     ab0:      	str	w0, [sp, #0x34]
     ab4:      	mov	w0, #0x11               // =17
     ab8:      	str	w0, [sp, #0x38]
     abc:      	ldr	w1, [sp, #0x38]
     ac0:      	ldr	w0, [sp, #0x30]
     ac4:      	add	w0, w1, w0
     ac8:      	str	w0, [sp, #0x3c]
     acc:      	ldr	w1, [sp, #0x3c]
     ad0:      	mov	w0, w1
     ad4:      	lsl	w0, w0, #1
     ad8:      	add	w0, w0, w1
     adc:      	ldr	w1, [sp, #0x34]
     ae0:      	add	w0, w1, w0
     ae4:      	str	w0, [sp, #0x30]
     ae8:      	ldr	w1, [sp, #0x30]
     aec:      	ldr	w0, [sp, #0x38]
     af0:      	sub	w0, w1, w0
     af4:      	str	w0, [sp, #0x34]
     af8:      	ldr	w0, [sp, #0x30]
     afc:      	str	w0, [sp, #0x24]
     b00:      	ldr	w0, [sp, #0x34]
     b04:      	str	w0, [sp, #0x20]
     b08:      	ldr	w19, [sp, #0x38]
     b0c:      	ldr	w0, [sp, #0x3c]
     b10:      	str	w0, [sp, #0x40]
     b14:      	ldr	w0, [sp, #0x24]
     b18:      	bl	0xb80 <record_event>
     b1c:      	ldr	w0, [sp, #0x24]
     b20:      	str	w0, [sp, #0x44]
     b24:      	ldr	w0, [sp, #0x44]
     b28:      	add	w0, w0, #0x7
     b2c:      	str	w0, [sp, #0x48]
     b30:      	ldr	w0, [sp, #0x48]
     b34:      	str	w0, [sp, #0x4c]
     b38:      	ldr	x0, [sp, #0x28]
     b3c:      	add	x0, x0, #0x8
     b40:      	ldr	w1, [sp, #0x4c]
     b44:      	str	w1, [x0]
     b48:      	ldr	x0, [sp, #0x28]
     b4c:      	ldr	w1, [sp, #0x20]
     b50:      	str	w1, [x0]
     b54:      	ldr	x0, [sp, #0x28]
     b58:      	add	x0, x0, #0x4
     b5c:      	str	w19, [x0]
     b60:      	ldr	w1, [sp, #0x24]
     b64:      	ldr	w0, [sp, #0x20]
     b68:      	cmp	w1, w0
     b6c:      	cset	w0, eq
     b70:      	and	w0, w0, #0xff
     b74:      	ldr	x19, [sp, #0x10]
     b78:      	ldp	x29, x30, [sp], #0x50
     b7c:      	ret

0000000000000b80 <record_event>:
     b80:      	sub	sp, sp, #0x10
     b84:      	str	w0, [sp, #0xc]
     b88:      	adrp	x0, 0x20000 <data_start>
     b8c:      	add	x0, x0, #0x24
     b90:      	ldr	w1, [x0]
     b94:      	mov	w0, w1
     b98:      	lsl	w0, w0, #5
     b9c:      	add	w1, w0, w1
     ba0:      	ldr	w0, [sp, #0xc]
     ba4:      	eor	w1, w1, w0
     ba8:      	adrp	x0, 0x20000 <data_start>
     bac:      	add	x0, x0, #0x24
     bb0:      	str	w1, [x0]
     bb4:      	nop
     bb8:      	add	sp, sp, #0x10
     bbc:      	ret

0000000000000bc0 <next_value>:
     bc0:      	stp	x29, x30, [sp, #-0x20]!
     bc4:      	mov	x29, sp
     bc8:      	str	w0, [sp, #0x1c]
     bcc:      	ldr	w0, [sp, #0x1c]
     bd0:      	bl	0xb80 <record_event>
     bd4:      	adrp	x0, 0x20000 <data_start>
     bd8:      	add	x0, x0, #0x18
     bdc:      	ldr	w1, [x0, #0x4]
     be0:      	ldr	w0, [sp, #0x1c]
     be4:      	add	w1, w1, w0
     be8:      	adrp	x0, 0x20000 <data_start>
     bec:      	add	x0, x0, #0x18
     bf0:      	str	w1, [x0, #0x4]
     bf4:      	adrp	x0, 0x20000 <data_start>
     bf8:      	add	x0, x0, #0x18
     bfc:      	ldr	w1, [x0, #0x4]
     c00:      	ldr	w0, [sp, #0x1c]
     c04:      	add	w0, w1, w0
     c08:      	ldp	x29, x30, [sp], #0x20
     c0c:      	ret

0000000000000c10 <main>:
     c10:      	sub	sp, sp, #0x70
     c14:      	stp	x29, x30, [sp, #0x60]
     c18:      	add	x29, sp, #0x60
     c1c:      	str	w0, [sp, #0xc]
     c20:      	str	x1, [sp]
     c24:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1dfc8>
     c28:      	ldr	x0, [x0, #0xfe8]
     c2c:      	ldr	x1, [x0]
     c30:      	str	x1, [sp, #0x58]
     c34:      	mov	x1, #0x0                // =0
     c38:      	ldr	w0, [sp, #0xc]
     c3c:      	cmp	w0, #0x3
     c40:      	b.eq	0xc4c <main+0x3c>
     c44:      	mov	w0, #0x2                // =2
     c48:      	b	0xe34 <main+0x224>
     c4c:      	ldr	x0, [sp]
     c50:      	add	x0, x0, #0x8
     c54:      	ldr	x0, [x0]
     c58:      	mov	w2, #0xa                // =10
     c5c:      	mov	x1, #0x0                // =0
     c60:      	bl	0x730 <strtoul@plt>
     c64:      	str	x0, [sp, #0x28]
     c68:      	ldr	x0, [sp]
     c6c:      	add	x0, x0, #0x10
     c70:      	ldr	x0, [x0]
     c74:      	mov	w2, #0xa                // =10
     c78:      	mov	x1, #0x0                // =0
     c7c:      	bl	0x730 <strtoul@plt>
     c80:      	str	w0, [sp, #0x18]
     c84:      	str	wzr, [sp, #0x1c]
     c88:      	add	x0, sp, #0x38
     c8c:      	mov	x1, x0
     c90:      	mov	w0, #0x1                // =1
     c94:      	bl	0x760 <clock_gettime@plt>
     c98:      	cmp	w0, #0x0
     c9c:      	b.eq	0xca8 <main+0x98>
     ca0:      	mov	w0, #0x2                // =2
     ca4:      	b	0xe34 <main+0x224>
     ca8:      	str	xzr, [sp, #0x20]
     cac:      	b	0xd70 <main+0x160>
     cb0:      	ldr	w0, [sp, #0x18]
     cb4:      	lsl	w0, w0, #13
     cb8:      	ldr	w1, [sp, #0x18]
     cbc:      	eor	w0, w1, w0
     cc0:      	str	w0, [sp, #0x18]
     cc4:      	ldr	w0, [sp, #0x18]
     cc8:      	lsr	w0, w0, #17
     ccc:      	ldr	w1, [sp, #0x18]
     cd0:      	eor	w0, w1, w0
     cd4:      	str	w0, [sp, #0x18]
     cd8:      	ldr	w0, [sp, #0x18]
     cdc:      	lsl	w0, w0, #5
     ce0:      	ldr	w1, [sp, #0x18]
     ce4:      	eor	w0, w1, w0
     ce8:      	str	w0, [sp, #0x18]
     cec:      	ldr	x2, [sp, #0x20]
     cf0:      	mov	x0, #-0x3333333333333334 // =-3689348814741910324
     cf4:      	movk	x0, #0xcccd
     cf8:      	umulh	x0, x2, x0
     cfc:      	lsr	x1, x0, #3
     d00:      	mov	x0, x1
     d04:      	lsl	x0, x0, #2
     d08:      	add	x0, x0, x1
     d0c:      	lsl	x0, x0, #1
     d10:      	sub	x1, x2, x0
     d14:      	mov	w0, w1
     d18:      	sub	w0, w0, #0x1
     d1c:      	mov	w2, w0
     d20:      	ldr	w1, [sp, #0x18]
     d24:      	adrp	x0, 0x20000 <data_start>
     d28:      	add	x0, x0, #0x18
     d2c:      	bl	0x8d8 <region_pipeline>
     d30:      	mov	w1, w0
     d34:      	ldr	w0, [sp, #0x1c]
     d38:      	add	w0, w0, w1
     d3c:      	str	w0, [sp, #0x1c]
     d40:      	ldr	w2, [sp, #0x1c]
     d44:      	ldr	w1, [sp, #0x18]
     d48:      	adrp	x0, 0x20000 <data_start>
     d4c:      	add	x0, x0, #0x18
     d50:      	bl	0xa8c <region_outputs>
     d54:      	mov	w1, w0
     d58:      	ldr	w0, [sp, #0x1c]
     d5c:      	add	w0, w0, w1
     d60:      	str	w0, [sp, #0x1c]
     d64:      	ldr	x0, [sp, #0x20]
     d68:      	add	x0, x0, #0x1
     d6c:      	str	x0, [sp, #0x20]
     d70:      	ldr	x1, [sp, #0x20]
     d74:      	ldr	x0, [sp, #0x28]
     d78:      	cmp	x1, x0
     d7c:      	b.lo	0xcb0 <main+0xa0>
     d80:      	add	x0, sp, #0x48
     d84:      	mov	x1, x0
     d88:      	mov	w0, #0x1                // =1
     d8c:      	bl	0x760 <clock_gettime@plt>
     d90:      	cmp	w0, #0x0
     d94:      	b.eq	0xda0 <main+0x190>
     d98:      	mov	w0, #0x2                // =2
     d9c:      	b	0xe34 <main+0x224>
     da0:      	ldr	x1, [sp, #0x48]
     da4:      	ldr	x0, [sp, #0x38]
     da8:      	sub	x0, x1, x0
     dac:      	fmov	d0, x0
     db0:      	scvtf	d1, d0
     db4:      	ldr	x1, [sp, #0x50]
     db8:      	ldr	x0, [sp, #0x40]
     dbc:      	sub	x0, x1, x0
     dc0:      	fmov	d0, x0
     dc4:      	scvtf	d0, d0
     dc8:      	adrp	x0, 0x0 <strtoul@GLIBC_2.17>
     dcc:      	ldr	d2, [x0, #0xea0]
     dd0:      	fmul	d0, d0, d2
     dd4:      	fadd	d0, d1, d0
     dd8:      	str	d0, [sp, #0x30]
     ddc:      	adrp	x0, 0x20000 <data_start>
     de0:      	add	x0, x0, #0x18
     de4:      	ldr	w1, [x0]
     de8:      	adrp	x0, 0x20000 <data_start>
     dec:      	add	x0, x0, #0x18
     df0:      	ldr	w2, [x0, #0x4]
     df4:      	adrp	x0, 0x20000 <data_start>
     df8:      	add	x0, x0, #0x18
     dfc:      	ldr	w3, [x0, #0x8]
     e00:      	adrp	x0, 0x20000 <data_start>
     e04:      	add	x0, x0, #0x24
     e08:      	ldr	w0, [x0]
     e0c:      	mov	w5, w0
     e10:      	mov	w4, w3
     e14:      	mov	w3, w2
     e18:      	mov	w2, w1
     e1c:      	ldr	w1, [sp, #0x1c]
     e20:      	ldr	d0, [sp, #0x30]
     e24:      	adrp	x0, 0x0 <strtoul@GLIBC_2.17>
     e28:      	add	x0, x0, #0xe88
     e2c:      	bl	0x7a0 <printf@plt>
     e30:      	mov	w0, #0x0                // =0
     e34:      	mov	w1, w0
     e38:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1dfc8>
     e3c:      	ldr	x0, [x0, #0xfe8]
     e40:      	ldr	x3, [sp, #0x58]
     e44:      	ldr	x2, [x0]
     e48:      	subs	x3, x3, x2
     e4c:      	mov	x2, #0x0                // =0
     e50:      	b.eq	0xe58 <main+0x248>
     e54:      	bl	0x770 <__stack_chk_fail@plt>
     e58:      	mov	w0, w1
     e5c:      	ldp	x29, x30, [sp, #0x60]
     e60:      	add	sp, sp, #0x70
     e64:      	ret

Disassembly of section .fini:

0000000000000e68 <_fini>:
     e68:      	nop
     e6c:      	stp	x29, x30, [sp, #-0x10]!
     e70:      	mov	x29, sp
     e74:      	ldp	x29, x30, [sp], #0x10
     e78:      	ret
