
/work/experiments/runs/private-declarations-cost-linux-20261110/gcc-O0/affine:	file format elf64-littleaarch64

Disassembly of section .init:

00000000000006f0 <_init>:
     6f0:      	nop
     6f4:      	stp	x29, x30, [sp, #-0x10]!
     6f8:      	mov	x29, sp
     6fc:      	bl	0x7f4 <call_weak_fn>
     700:      	ldp	x29, x30, [sp], #0x10
     704:      	ret

Disassembly of section .plt:

0000000000000710 <.plt>:
     710:      	stp	x16, x30, [sp, #-0x10]!
     714:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1dcc8>
     718:      	ldr	x17, [x16, #0xf80]
     71c:      	add	x16, x16, #0xf80
     720:      	br	x17
     724:      	nop
     728:      	nop
     72c:      	nop

0000000000000730 <strtoul@plt>:
     730:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1dcc8>
     734:      	ldr	x17, [x16, #0xf88]
     738:      	add	x16, x16, #0xf88
     73c:      	br	x17

0000000000000740 <__libc_start_main@plt>:
     740:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1dcc8>
     744:      	ldr	x17, [x16, #0xf90]
     748:      	add	x16, x16, #0xf90
     74c:      	br	x17

0000000000000750 <__cxa_finalize@plt>:
     750:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1dcc8>
     754:      	ldr	x17, [x16, #0xf98]
     758:      	add	x16, x16, #0xf98
     75c:      	br	x17

0000000000000760 <clock_gettime@plt>:
     760:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1dcc8>
     764:      	ldr	x17, [x16, #0xfa0]
     768:      	add	x16, x16, #0xfa0
     76c:      	br	x17

0000000000000770 <__stack_chk_fail@plt>:
     770:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1dcc8>
     774:      	ldr	x17, [x16, #0xfa8]
     778:      	add	x16, x16, #0xfa8
     77c:      	br	x17

0000000000000780 <__gmon_start__@plt>:
     780:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1dcc8>
     784:      	ldr	x17, [x16, #0xfb0]
     788:      	add	x16, x16, #0xfb0
     78c:      	br	x17

0000000000000790 <abort@plt>:
     790:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1dcc8>
     794:      	ldr	x17, [x16, #0xfb8]
     798:      	add	x16, x16, #0xfb8
     79c:      	br	x17

00000000000007a0 <printf@plt>:
     7a0:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1dcc8>
     7a4:      	ldr	x17, [x16, #0xfc0]
     7a8:      	add	x16, x16, #0xfc0
     7ac:      	br	x17

Disassembly of section .text:

00000000000007c0 <_start>:
     7c0:      	nop
     7c4:      	mov	x29, #0x0               // =0
     7c8:      	mov	x30, #0x0               // =0
     7cc:      	mov	x5, x0
     7d0:      	ldr	x1, [sp]
     7d4:      	add	x2, sp, #0x8
     7d8:      	mov	x6, sp
     7dc:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1dcc8>
     7e0:      	ldr	x0, [x0, #0xff0]
     7e4:      	mov	x3, #0x0                // =0
     7e8:      	mov	x4, #0x0                // =0
     7ec:      	bl	0x740 <__libc_start_main@plt>
     7f0:      	bl	0x790 <abort@plt>

00000000000007f4 <call_weak_fn>:
     7f4:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1dcc8>
     7f8:      	ldr	x0, [x0, #0xfe0]
     7fc:      	cbz	x0, 0x804 <call_weak_fn+0x10>
     800:      	b	0x780 <__gmon_start__@plt>
     804:      	ret
     808:      	nop
     80c:      	nop

0000000000000810 <deregister_tm_clones>:
     810:      	adrp	x0, 0x20000 <data_start>
     814:      	add	x0, x0, #0x10
     818:      	adrp	x1, 0x20000 <data_start>
     81c:      	add	x1, x1, #0x10
     820:      	cmp	x1, x0
     824:      	b.eq	0x83c <deregister_tm_clones+0x2c>
     828:      	adrp	x1, 0x1f000 <__FRAME_END__+0x1dcc8>
     82c:      	ldr	x1, [x1, #0xfd0]
     830:      	cbz	x1, 0x83c <deregister_tm_clones+0x2c>
     834:      	mov	x16, x1
     838:      	br	x16
     83c:      	ret

0000000000000840 <register_tm_clones>:
     840:      	adrp	x0, 0x20000 <data_start>
     844:      	add	x0, x0, #0x10
     848:      	adrp	x1, 0x20000 <data_start>
     84c:      	add	x1, x1, #0x10
     850:      	sub	x1, x1, x0
     854:      	lsr	x2, x1, #63
     858:      	add	x1, x2, x1, asr #3
     85c:      	asr	x1, x1, #1
     860:      	cbz	x1, 0x878 <register_tm_clones+0x38>
     864:      	adrp	x2, 0x1f000 <__FRAME_END__+0x1dcc8>
     868:      	ldr	x2, [x2, #0xff8]
     86c:      	cbz	x2, 0x878 <register_tm_clones+0x38>
     870:      	mov	x16, x2
     874:      	br	x16
     878:      	ret
     87c:      	nop

0000000000000880 <__do_global_dtors_aux>:
     880:      	paciasp
     884:      	stp	x29, x30, [sp, #-0x20]!
     888:      	mov	x29, sp
     88c:      	str	x19, [sp, #0x10]
     890:      	adrp	x19, 0x20000 <data_start>
     894:      	ldrb	w0, [x19, #0x10]
     898:      	tbnz	w0, #0x0, 0x8c0 <__do_global_dtors_aux+0x40>
     89c:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1dcc8>
     8a0:      	ldr	x0, [x0, #0xfd8]
     8a4:      	cbz	x0, 0x8b4 <__do_global_dtors_aux+0x34>
     8a8:      	adrp	x0, 0x20000 <data_start>
     8ac:      	ldr	x0, [x0, #0x8]
     8b0:      	bl	0x750 <__cxa_finalize@plt>
     8b4:      	bl	0x810 <deregister_tm_clones>
     8b8:      	mov	w0, #0x1                // =1
     8bc:      	strb	w0, [x19, #0x10]
     8c0:      	ldr	x19, [sp, #0x10]
     8c4:      	ldp	x29, x30, [sp], #0x20
     8c8:      	autiasp
     8cc:      	ret

00000000000008d0 <frame_dummy>:
     8d0:      	bti	c
     8d4:      	b	0x840 <register_tm_clones>

00000000000008d8 <region_pipeline>:
     8d8:      	stp	x29, x30, [sp, #-0x80]!
     8dc:      	mov	x29, sp
     8e0:      	str	x19, [sp, #0x10]
     8e4:      	str	x0, [sp, #0x28]
     8e8:      	str	w1, [sp, #0x24]
     8ec:      	str	w2, [sp, #0x20]
     8f0:      	ldr	x0, [sp, #0x28]
     8f4:      	ldr	w0, [x0]
     8f8:      	str	w0, [sp, #0x40]
     8fc:      	ldr	w1, [sp, #0x24]
     900:      	mov	w0, #0x86a1             // =34465
     904:      	movk	w0, #0x487e, lsl #16
     908:      	mul	w1, w1, w0
     90c:      	mov	w0, #0x6ab4             // =27316
     910:      	movk	w0, #0x72f8, lsl #16
     914:      	add	w0, w1, w0
     918:      	str	w0, [sp, #0x44]
     91c:      	ldr	w1, [sp, #0x40]
     920:      	mov	w0, #0x86a1             // =34465
     924:      	movk	w0, #0x487e, lsl #16
     928:      	mul	w1, w1, w0
     92c:      	mov	w0, #0x6ab4             // =27316
     930:      	movk	w0, #0x72f8, lsl #16
     934:      	add	w0, w1, w0
     938:      	str	w0, [sp, #0x48]
     93c:      	ldr	w1, [sp, #0x44]
     940:      	ldr	w0, [sp, #0x48]
     944:      	add	w1, w1, w0
     948:      	mov	w0, #0x954c             // =38220
     94c:      	movk	w0, #0x8d07, lsl #16
     950:      	add	w0, w1, w0
     954:      	str	w0, [sp, #0x4c]
     958:      	ldr	w1, [sp, #0x4c]
     95c:      	mov	w0, w1
     960:      	lsl	w0, w0, #1
     964:      	add	w1, w0, w1
     968:      	mov	w0, #0xf383             // =62339
     96c:      	movk	w0, #0x377e, lsl #16
     970:      	add	w0, w1, w0
     974:      	str	w0, [sp, #0x50]
     978:      	ldr	w1, [sp, #0x50]
     97c:      	ldr	w0, [sp, #0x48]
     980:      	sub	w1, w1, w0
     984:      	mov	w0, #0x6ab4             // =27316
     988:      	movk	w0, #0x72f8, lsl #16
     98c:      	add	w0, w1, w0
     990:      	str	w0, [sp, #0x44]
     994:      	ldr	w1, [sp, #0x44]
     998:      	mov	w0, #0xdd61             // =56673
     99c:      	movk	w0, #0x3c16, lsl #16
     9a0:      	mul	w1, w1, w0
     9a4:      	mov	w0, #0x2dcc             // =11724
     9a8:      	movk	w0, #0xa04a, lsl #16
     9ac:      	add	w0, w1, w0
     9b0:      	str	w0, [sp, #0x24]
     9b4:      	ldr	w1, [sp, #0x4c]
     9b8:      	mov	w0, #0xdd61             // =56673
     9bc:      	movk	w0, #0x3c16, lsl #16
     9c0:      	mul	w1, w1, w0
     9c4:      	mov	w0, #0x2dcc             // =11724
     9c8:      	movk	w0, #0xa04a, lsl #16
     9cc:      	add	w19, w1, w0
     9d0:      	ldr	w1, [sp, #0x50]
     9d4:      	mov	w0, #0xdd61             // =56673
     9d8:      	movk	w0, #0x3c16, lsl #16
     9dc:      	mul	w1, w1, w0
     9e0:      	mov	w0, #0x2dcc             // =11724
     9e4:      	movk	w0, #0xa04a, lsl #16
     9e8:      	add	w0, w1, w0
     9ec:      	str	w0, [sp, #0x3c]
     9f0:      	mov	w0, w19
     9f4:      	bl	0xe84 <record_event>
     9f8:      	ldr	w0, [sp, #0x20]
     9fc:      	cmp	w0, #0x0
     a00:      	b.ge	0xc7c <region_pipeline+0x3a4>
     a04:      	ldr	w0, [sp, #0x24]
     a08:      	b	0xc94 <region_pipeline+0x3bc>
     a0c:      	ldr	w0, [sp, #0x24]
     a10:      	bl	0xec4 <next_value>
     a14:      	str	w0, [sp, #0x40]
     a18:      	ldr	w1, [sp, #0x24]
     a1c:      	mov	w0, #0xe9ef             // =59887
     a20:      	movk	w0, #0xf824, lsl #16
     a24:      	mul	w1, w1, w0
     a28:      	mov	w0, #0x9979             // =39289
     a2c:      	movk	w0, #0xc389, lsl #16
     a30:      	add	w0, w1, w0
     a34:      	str	w0, [sp, #0x54]
     a38:      	ldr	w1, [sp, #0x40]
     a3c:      	mov	w0, #0xe9ef             // =59887
     a40:      	movk	w0, #0xf824, lsl #16
     a44:      	mul	w1, w1, w0
     a48:      	mov	w0, #0x9979             // =39289
     a4c:      	movk	w0, #0xc389, lsl #16
     a50:      	add	w0, w1, w0
     a54:      	str	w0, [sp, #0x58]
     a58:      	ldr	w1, [sp, #0x3c]
     a5c:      	mov	w0, #0xe9ef             // =59887
     a60:      	movk	w0, #0xf824, lsl #16
     a64:      	mul	w1, w1, w0
     a68:      	mov	w0, #0x9979             // =39289
     a6c:      	movk	w0, #0xc389, lsl #16
     a70:      	add	w0, w1, w0
     a74:      	str	w0, [sp, #0x5c]
     a78:      	mov	w0, #0xe9ef             // =59887
     a7c:      	movk	w0, #0xf824, lsl #16
     a80:      	mul	w1, w19, w0
     a84:      	mov	w0, #0x9979             // =39289
     a88:      	movk	w0, #0xc389, lsl #16
     a8c:      	add	w0, w1, w0
     a90:      	str	w0, [sp, #0x60]
     a94:      	ldr	w1, [sp, #0x54]
     a98:      	ldr	w0, [sp, #0x58]
     a9c:      	add	w1, w1, w0
     aa0:      	mov	w0, #0x6687             // =26247
     aa4:      	movk	w0, #0x3c76, lsl #16
     aa8:      	add	w0, w1, w0
     aac:      	str	w0, [sp, #0x54]
     ab0:      	ldr	w1, [sp, #0x58]
     ab4:      	mov	w0, w1
     ab8:      	lsl	w0, w0, #2
     abc:      	add	w1, w0, w1
     ac0:      	ldr	w0, [sp, #0x5c]
     ac4:      	add	w1, w1, w0
     ac8:      	mov	w0, #0xa3               // =163
     acc:      	movk	w0, #0x2e50, lsl #16
     ad0:      	add	w0, w1, w0
     ad4:      	str	w0, [sp, #0x64]
     ad8:      	ldr	w1, [sp, #0x64]
     adc:      	ldr	w0, [sp, #0x58]
     ae0:      	sub	w1, w1, w0
     ae4:      	mov	w0, #0x9979             // =39289
     ae8:      	movk	w0, #0xc389, lsl #16
     aec:      	add	w0, w1, w0
     af0:      	str	w0, [sp, #0x68]
     af4:      	ldr	w1, [sp, #0x68]
     af8:      	ldr	w0, [sp, #0x60]
     afc:      	add	w1, w1, w0
     b00:      	mov	w0, #0x6687             // =26247
     b04:      	movk	w0, #0x3c76, lsl #16
     b08:      	add	w0, w1, w0
     b0c:      	str	w0, [sp, #0x5c]
     b10:      	ldr	w1, [sp, #0x54]
     b14:      	mov	w0, #0x650f             // =25871
     b18:      	movk	w0, #0x4a25, lsl #16
     b1c:      	mul	w1, w1, w0
     b20:      	mov	w0, #0x44e9             // =17641
     b24:      	movk	w0, #0x18e6, lsl #16
     b28:      	add	w0, w1, w0
     b2c:      	str	w0, [sp, #0x24]
     b30:      	ldr	w1, [sp, #0x5c]
     b34:      	mov	w0, #0x650f             // =25871
     b38:      	movk	w0, #0x4a25, lsl #16
     b3c:      	mul	w1, w1, w0
     b40:      	mov	w0, #0x44e9             // =17641
     b44:      	movk	w0, #0x18e6, lsl #16
     b48:      	add	w0, w1, w0
     b4c:      	str	w0, [sp, #0x3c]
     b50:      	ldr	w1, [sp, #0x64]
     b54:      	mov	w0, #0x650f             // =25871
     b58:      	movk	w0, #0x4a25, lsl #16
     b5c:      	mul	w1, w1, w0
     b60:      	mov	w0, #0x44e9             // =17641
     b64:      	movk	w0, #0x18e6, lsl #16
     b68:      	add	w0, w1, w0
     b6c:      	str	w0, [sp, #0x6c]
     b70:      	ldr	w1, [sp, #0x68]
     b74:      	mov	w0, #0x650f             // =25871
     b78:      	movk	w0, #0x4a25, lsl #16
     b7c:      	mul	w1, w1, w0
     b80:      	mov	w0, #0x44e9             // =17641
     b84:      	movk	w0, #0x18e6, lsl #16
     b88:      	add	w0, w1, w0
     b8c:      	str	w0, [sp, #0x70]
     b90:      	ldr	w0, [sp, #0x6c]
     b94:      	bl	0xe84 <record_event>
     b98:      	ldr	w1, [sp, #0x6c]
     b9c:      	mov	w0, #0x58c1             // =22721
     ba0:      	movk	w0, #0x5c56, lsl #16
     ba4:      	mul	w1, w1, w0
     ba8:      	mov	w0, #0x595a             // =22874
     bac:      	movk	w0, #0x2e9, lsl #16
     bb0:      	add	w0, w1, w0
     bb4:      	str	w0, [sp, #0x74]
     bb8:      	ldr	w1, [sp, #0x74]
     bbc:      	mov	w0, #0x6d47             // =27975
     bc0:      	movk	w0, #0x865c, lsl #16
     bc4:      	add	w0, w1, w0
     bc8:      	str	w0, [sp, #0x74]
     bcc:      	ldr	w1, [sp, #0x74]
     bd0:      	mov	w0, #0x3741             // =14145
     bd4:      	movk	w0, #0xaf82, lsl #16
     bd8:      	mul	w1, w1, w0
     bdc:      	mov	w0, #0xfa26             // =64038
     be0:      	movk	w0, #0x3ad9, lsl #16
     be4:      	add	w0, w1, w0
     be8:      	str	w0, [sp, #0x6c]
     bec:      	ldr	x0, [sp, #0x28]
     bf0:      	ldr	w1, [sp, #0x6c]
     bf4:      	str	w1, [x0]
     bf8:      	ldr	w1, [sp, #0x24]
     bfc:      	mov	w0, #0x802b             // =32811
     c00:      	movk	w0, #0x95b, lsl #16
     c04:      	mul	w1, w1, w0
     c08:      	mov	w0, #0xc7b7             // =51127
     c0c:      	movk	w0, #0x38dc, lsl #16
     c10:      	add	w0, w1, w0
     c14:      	str	w0, [sp, #0x78]
     c18:      	ldr	w1, [sp, #0x3c]
     c1c:      	mov	w0, #0x802b             // =32811
     c20:      	movk	w0, #0x95b, lsl #16
     c24:      	mul	w1, w1, w0
     c28:      	mov	w0, #0xc7b7             // =51127
     c2c:      	movk	w0, #0x38dc, lsl #16
     c30:      	add	w0, w1, w0
     c34:      	str	w0, [sp, #0x7c]
     c38:      	ldr	w1, [sp, #0x78]
     c3c:      	ldr	w0, [sp, #0x7c]
     c40:      	add	w1, w1, w0
     c44:      	mov	w0, #0x3849             // =14409
     c48:      	movk	w0, #0xc723, lsl #16
     c4c:      	add	w0, w1, w0
     c50:      	str	w0, [sp, #0x78]
     c54:      	ldr	w1, [sp, #0x78]
     c58:      	mov	w0, #0x3e83             // =16003
     c5c:      	movk	w0, #0x32e9, lsl #16
     c60:      	mul	w1, w1, w0
     c64:      	mov	w0, #0x7b5b             // =31579
     c68:      	movk	w0, #0xeb18, lsl #16
     c6c:      	add	w0, w1, w0
     c70:      	str	w0, [sp, #0x24]
     c74:      	ldr	w0, [sp, #0x40]
     c78:      	bl	0xe84 <record_event>
     c7c:      	ldr	w0, [sp, #0x20]
     c80:      	sub	w1, w0, #0x1
     c84:      	str	w1, [sp, #0x20]
     c88:      	cmp	w0, #0x0
     c8c:      	b.gt	0xa0c <region_pipeline+0x134>
     c90:      	ldr	w0, [sp, #0x24]
     c94:      	ldr	x19, [sp, #0x10]
     c98:      	ldp	x29, x30, [sp], #0x80
     c9c:      	ret

0000000000000ca0 <region_outputs>:
     ca0:      	stp	x29, x30, [sp, #-0x50]!
     ca4:      	mov	x29, sp
     ca8:      	str	x19, [sp, #0x10]
     cac:      	str	x0, [sp, #0x28]
     cb0:      	str	w1, [sp, #0x24]
     cb4:      	str	w2, [sp, #0x20]
     cb8:      	ldr	w1, [sp, #0x24]
     cbc:      	mov	w0, #0x2ef1             // =12017
     cc0:      	movk	w0, #0x9c54, lsl #16
     cc4:      	mul	w1, w1, w0
     cc8:      	mov	w0, #0x4890             // =18576
     ccc:      	movk	w0, #0xcf94, lsl #16
     cd0:      	add	w0, w1, w0
     cd4:      	str	w0, [sp, #0x30]
     cd8:      	ldr	w1, [sp, #0x20]
     cdc:      	mov	w0, #0x2ef1             // =12017
     ce0:      	movk	w0, #0x9c54, lsl #16
     ce4:      	mul	w1, w1, w0
     ce8:      	mov	w0, #0x4890             // =18576
     cec:      	movk	w0, #0xcf94, lsl #16
     cf0:      	add	w0, w1, w0
     cf4:      	str	w0, [sp, #0x34]
     cf8:      	mov	w0, #0x6691             // =26257
     cfc:      	movk	w0, #0x312b, lsl #16
     d00:      	str	w0, [sp, #0x38]
     d04:      	ldr	w1, [sp, #0x38]
     d08:      	ldr	w0, [sp, #0x30]
     d0c:      	add	w1, w1, w0
     d10:      	mov	w0, #0xb770             // =46960
     d14:      	movk	w0, #0x306b, lsl #16
     d18:      	add	w0, w1, w0
     d1c:      	str	w0, [sp, #0x3c]
     d20:      	ldr	w1, [sp, #0x3c]
     d24:      	mov	w0, w1
     d28:      	lsl	w0, w0, #1
     d2c:      	add	w1, w0, w1
     d30:      	ldr	w0, [sp, #0x34]
     d34:      	add	w1, w1, w0
     d38:      	mov	w0, #0x2650             // =9808
     d3c:      	movk	w0, #0x9143, lsl #16
     d40:      	add	w0, w1, w0
     d44:      	str	w0, [sp, #0x30]
     d48:      	ldr	w1, [sp, #0x30]
     d4c:      	ldr	w0, [sp, #0x38]
     d50:      	sub	w1, w1, w0
     d54:      	mov	w0, #0x4890             // =18576
     d58:      	movk	w0, #0xcf94, lsl #16
     d5c:      	add	w0, w1, w0
     d60:      	str	w0, [sp, #0x34]
     d64:      	ldr	w1, [sp, #0x30]
     d68:      	mov	w0, #0x211              // =529
     d6c:      	movk	w0, #0x6cbb, lsl #16
     d70:      	mul	w1, w1, w0
     d74:      	mov	w0, #0xe70              // =3696
     d78:      	movk	w0, #0x4d66, lsl #16
     d7c:      	add	w0, w1, w0
     d80:      	str	w0, [sp, #0x24]
     d84:      	ldr	w1, [sp, #0x34]
     d88:      	mov	w0, #0x211              // =529
     d8c:      	movk	w0, #0x6cbb, lsl #16
     d90:      	mul	w1, w1, w0
     d94:      	mov	w0, #0xe70              // =3696
     d98:      	movk	w0, #0x4d66, lsl #16
     d9c:      	add	w0, w1, w0
     da0:      	str	w0, [sp, #0x20]
     da4:      	ldr	w1, [sp, #0x38]
     da8:      	mov	w0, #0x211              // =529
     dac:      	movk	w0, #0x6cbb, lsl #16
     db0:      	mul	w1, w1, w0
     db4:      	mov	w0, #0xe70              // =3696
     db8:      	movk	w0, #0x4d66, lsl #16
     dbc:      	add	w19, w1, w0
     dc0:      	ldr	w1, [sp, #0x3c]
     dc4:      	mov	w0, #0x211              // =529
     dc8:      	movk	w0, #0x6cbb, lsl #16
     dcc:      	mul	w1, w1, w0
     dd0:      	mov	w0, #0xe70              // =3696
     dd4:      	movk	w0, #0x4d66, lsl #16
     dd8:      	add	w0, w1, w0
     ddc:      	str	w0, [sp, #0x40]
     de0:      	ldr	w0, [sp, #0x24]
     de4:      	bl	0xe84 <record_event>
     de8:      	ldr	w1, [sp, #0x24]
     dec:      	mov	w0, #0xe557             // =58711
     df0:      	movk	w0, #0x785, lsl #16
     df4:      	mul	w1, w1, w0
     df8:      	mov	w0, #0xc148             // =49480
     dfc:      	movk	w0, #0x559e, lsl #16
     e00:      	add	w0, w1, w0
     e04:      	str	w0, [sp, #0x44]
     e08:      	ldr	w1, [sp, #0x44]
     e0c:      	mov	w0, #0x4561             // =17761
     e10:      	movk	w0, #0x34a9, lsl #16
     e14:      	add	w0, w1, w0
     e18:      	str	w0, [sp, #0x48]
     e1c:      	ldr	w1, [sp, #0x48]
     e20:      	mov	w0, #0xd667             // =54887
     e24:      	movk	w0, #0x33a6, lsl #16
     e28:      	mul	w1, w1, w0
     e2c:      	mov	w0, #0xc08              // =3080
     e30:      	movk	w0, #0x2ade, lsl #16
     e34:      	add	w0, w1, w0
     e38:      	str	w0, [sp, #0x4c]
     e3c:      	ldr	x0, [sp, #0x28]
     e40:      	add	x0, x0, #0x8
     e44:      	ldr	w1, [sp, #0x4c]
     e48:      	str	w1, [x0]
     e4c:      	ldr	x0, [sp, #0x28]
     e50:      	ldr	w1, [sp, #0x20]
     e54:      	str	w1, [x0]
     e58:      	ldr	x0, [sp, #0x28]
     e5c:      	add	x0, x0, #0x4
     e60:      	str	w19, [x0]
     e64:      	ldr	w1, [sp, #0x24]
     e68:      	ldr	w0, [sp, #0x20]
     e6c:      	cmp	w1, w0
     e70:      	cset	w0, eq
     e74:      	and	w0, w0, #0xff
     e78:      	ldr	x19, [sp, #0x10]
     e7c:      	ldp	x29, x30, [sp], #0x50
     e80:      	ret

0000000000000e84 <record_event>:
     e84:      	sub	sp, sp, #0x10
     e88:      	str	w0, [sp, #0xc]
     e8c:      	adrp	x0, 0x20000 <data_start>
     e90:      	add	x0, x0, #0x24
     e94:      	ldr	w1, [x0]
     e98:      	mov	w0, w1
     e9c:      	lsl	w0, w0, #5
     ea0:      	add	w1, w0, w1
     ea4:      	ldr	w0, [sp, #0xc]
     ea8:      	eor	w1, w1, w0
     eac:      	adrp	x0, 0x20000 <data_start>
     eb0:      	add	x0, x0, #0x24
     eb4:      	str	w1, [x0]
     eb8:      	nop
     ebc:      	add	sp, sp, #0x10
     ec0:      	ret

0000000000000ec4 <next_value>:
     ec4:      	stp	x29, x30, [sp, #-0x20]!
     ec8:      	mov	x29, sp
     ecc:      	str	w0, [sp, #0x1c]
     ed0:      	ldr	w0, [sp, #0x1c]
     ed4:      	bl	0xe84 <record_event>
     ed8:      	adrp	x0, 0x20000 <data_start>
     edc:      	add	x0, x0, #0x18
     ee0:      	ldr	w1, [x0, #0x4]
     ee4:      	ldr	w0, [sp, #0x1c]
     ee8:      	add	w1, w1, w0
     eec:      	adrp	x0, 0x20000 <data_start>
     ef0:      	add	x0, x0, #0x18
     ef4:      	str	w1, [x0, #0x4]
     ef8:      	adrp	x0, 0x20000 <data_start>
     efc:      	add	x0, x0, #0x18
     f00:      	ldr	w1, [x0, #0x4]
     f04:      	ldr	w0, [sp, #0x1c]
     f08:      	add	w0, w1, w0
     f0c:      	ldp	x29, x30, [sp], #0x20
     f10:      	ret

0000000000000f14 <main>:
     f14:      	sub	sp, sp, #0x70
     f18:      	stp	x29, x30, [sp, #0x60]
     f1c:      	add	x29, sp, #0x60
     f20:      	str	w0, [sp, #0xc]
     f24:      	str	x1, [sp]
     f28:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1dcc8>
     f2c:      	ldr	x0, [x0, #0xfe8]
     f30:      	ldr	x1, [x0]
     f34:      	str	x1, [sp, #0x58]
     f38:      	mov	x1, #0x0                // =0
     f3c:      	ldr	w0, [sp, #0xc]
     f40:      	cmp	w0, #0x3
     f44:      	b.eq	0xf50 <main+0x3c>
     f48:      	mov	w0, #0x2                // =2
     f4c:      	b	0x1138 <main+0x224>
     f50:      	ldr	x0, [sp]
     f54:      	add	x0, x0, #0x8
     f58:      	ldr	x0, [x0]
     f5c:      	mov	w2, #0xa                // =10
     f60:      	mov	x1, #0x0                // =0
     f64:      	bl	0x730 <strtoul@plt>
     f68:      	str	x0, [sp, #0x28]
     f6c:      	ldr	x0, [sp]
     f70:      	add	x0, x0, #0x10
     f74:      	ldr	x0, [x0]
     f78:      	mov	w2, #0xa                // =10
     f7c:      	mov	x1, #0x0                // =0
     f80:      	bl	0x730 <strtoul@plt>
     f84:      	str	w0, [sp, #0x18]
     f88:      	str	wzr, [sp, #0x1c]
     f8c:      	add	x0, sp, #0x38
     f90:      	mov	x1, x0
     f94:      	mov	w0, #0x1                // =1
     f98:      	bl	0x760 <clock_gettime@plt>
     f9c:      	cmp	w0, #0x0
     fa0:      	b.eq	0xfac <main+0x98>
     fa4:      	mov	w0, #0x2                // =2
     fa8:      	b	0x1138 <main+0x224>
     fac:      	str	xzr, [sp, #0x20]
     fb0:      	b	0x1074 <main+0x160>
     fb4:      	ldr	w0, [sp, #0x18]
     fb8:      	lsl	w0, w0, #13
     fbc:      	ldr	w1, [sp, #0x18]
     fc0:      	eor	w0, w1, w0
     fc4:      	str	w0, [sp, #0x18]
     fc8:      	ldr	w0, [sp, #0x18]
     fcc:      	lsr	w0, w0, #17
     fd0:      	ldr	w1, [sp, #0x18]
     fd4:      	eor	w0, w1, w0
     fd8:      	str	w0, [sp, #0x18]
     fdc:      	ldr	w0, [sp, #0x18]
     fe0:      	lsl	w0, w0, #5
     fe4:      	ldr	w1, [sp, #0x18]
     fe8:      	eor	w0, w1, w0
     fec:      	str	w0, [sp, #0x18]
     ff0:      	ldr	x2, [sp, #0x20]
     ff4:      	mov	x0, #-0x3333333333333334 // =-3689348814741910324
     ff8:      	movk	x0, #0xcccd
     ffc:      	umulh	x0, x2, x0
    1000:      	lsr	x1, x0, #3
    1004:      	mov	x0, x1
    1008:      	lsl	x0, x0, #2
    100c:      	add	x0, x0, x1
    1010:      	lsl	x0, x0, #1
    1014:      	sub	x1, x2, x0
    1018:      	mov	w0, w1
    101c:      	sub	w0, w0, #0x1
    1020:      	mov	w2, w0
    1024:      	ldr	w1, [sp, #0x18]
    1028:      	adrp	x0, 0x20000 <data_start>
    102c:      	add	x0, x0, #0x18
    1030:      	bl	0x8d8 <region_pipeline>
    1034:      	mov	w1, w0
    1038:      	ldr	w0, [sp, #0x1c]
    103c:      	add	w0, w0, w1
    1040:      	str	w0, [sp, #0x1c]
    1044:      	ldr	w2, [sp, #0x1c]
    1048:      	ldr	w1, [sp, #0x18]
    104c:      	adrp	x0, 0x20000 <data_start>
    1050:      	add	x0, x0, #0x18
    1054:      	bl	0xca0 <region_outputs>
    1058:      	mov	w1, w0
    105c:      	ldr	w0, [sp, #0x1c]
    1060:      	add	w0, w0, w1
    1064:      	str	w0, [sp, #0x1c]
    1068:      	ldr	x0, [sp, #0x20]
    106c:      	add	x0, x0, #0x1
    1070:      	str	x0, [sp, #0x20]
    1074:      	ldr	x1, [sp, #0x20]
    1078:      	ldr	x0, [sp, #0x28]
    107c:      	cmp	x1, x0
    1080:      	b.lo	0xfb4 <main+0xa0>
    1084:      	add	x0, sp, #0x48
    1088:      	mov	x1, x0
    108c:      	mov	w0, #0x1                // =1
    1090:      	bl	0x760 <clock_gettime@plt>
    1094:      	cmp	w0, #0x0
    1098:      	b.eq	0x10a4 <main+0x190>
    109c:      	mov	w0, #0x2                // =2
    10a0:      	b	0x1138 <main+0x224>
    10a4:      	ldr	x1, [sp, #0x48]
    10a8:      	ldr	x0, [sp, #0x38]
    10ac:      	sub	x0, x1, x0
    10b0:      	fmov	d0, x0
    10b4:      	scvtf	d1, d0
    10b8:      	ldr	x1, [sp, #0x50]
    10bc:      	ldr	x0, [sp, #0x40]
    10c0:      	sub	x0, x1, x0
    10c4:      	fmov	d0, x0
    10c8:      	scvtf	d0, d0
    10cc:      	adrp	x0, 0x1000 <main+0xec>
    10d0:      	ldr	d2, [x0, #0x1a0]
    10d4:      	fmul	d0, d0, d2
    10d8:      	fadd	d0, d1, d0
    10dc:      	str	d0, [sp, #0x30]
    10e0:      	adrp	x0, 0x20000 <data_start>
    10e4:      	add	x0, x0, #0x18
    10e8:      	ldr	w1, [x0]
    10ec:      	adrp	x0, 0x20000 <data_start>
    10f0:      	add	x0, x0, #0x18
    10f4:      	ldr	w2, [x0, #0x4]
    10f8:      	adrp	x0, 0x20000 <data_start>
    10fc:      	add	x0, x0, #0x18
    1100:      	ldr	w3, [x0, #0x8]
    1104:      	adrp	x0, 0x20000 <data_start>
    1108:      	add	x0, x0, #0x24
    110c:      	ldr	w0, [x0]
    1110:      	mov	w5, w0
    1114:      	mov	w4, w3
    1118:      	mov	w3, w2
    111c:      	mov	w2, w1
    1120:      	ldr	w1, [sp, #0x1c]
    1124:      	ldr	d0, [sp, #0x30]
    1128:      	adrp	x0, 0x1000 <main+0xec>
    112c:      	add	x0, x0, #0x188
    1130:      	bl	0x7a0 <printf@plt>
    1134:      	mov	w0, #0x0                // =0
    1138:      	mov	w1, w0
    113c:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1dcc8>
    1140:      	ldr	x0, [x0, #0xfe8]
    1144:      	ldr	x3, [sp, #0x58]
    1148:      	ldr	x2, [x0]
    114c:      	subs	x3, x3, x2
    1150:      	mov	x2, #0x0                // =0
    1154:      	b.eq	0x115c <main+0x248>
    1158:      	bl	0x770 <__stack_chk_fail@plt>
    115c:      	mov	w0, w1
    1160:      	ldp	x29, x30, [sp, #0x60]
    1164:      	add	sp, sp, #0x70
    1168:      	ret

Disassembly of section .fini:

000000000000116c <_fini>:
    116c:      	nop
    1170:      	stp	x29, x30, [sp, #-0x10]!
    1174:      	mov	x29, sp
    1178:      	ldp	x29, x30, [sp], #0x10
    117c:      	ret
