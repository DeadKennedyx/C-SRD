
/work/experiments/runs/private-declarations-cost-linux-20261110/gcc-O0/original:	file format elf64-littleaarch64

Disassembly of section .init:

00000000000006f0 <_init>:
     6f0:      	nop
     6f4:      	stp	x29, x30, [sp, #-0x10]!
     6f8:      	mov	x29, sp
     6fc:      	bl	0x7f4 <call_weak_fn>
     700:      	ldp	x29, x30, [sp], #0x10
     704:      	ret

Disassembly of section .plt:

0000000000000710 <.plt>:
     710:      	stp	x16, x30, [sp, #-0x10]!
     714:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e0a8>
     718:      	ldr	x17, [x16, #0xf80]
     71c:      	add	x16, x16, #0xf80
     720:      	br	x17
     724:      	nop
     728:      	nop
     72c:      	nop

0000000000000730 <strtoul@plt>:
     730:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e0a8>
     734:      	ldr	x17, [x16, #0xf88]
     738:      	add	x16, x16, #0xf88
     73c:      	br	x17

0000000000000740 <__libc_start_main@plt>:
     740:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e0a8>
     744:      	ldr	x17, [x16, #0xf90]
     748:      	add	x16, x16, #0xf90
     74c:      	br	x17

0000000000000750 <__cxa_finalize@plt>:
     750:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e0a8>
     754:      	ldr	x17, [x16, #0xf98]
     758:      	add	x16, x16, #0xf98
     75c:      	br	x17

0000000000000760 <clock_gettime@plt>:
     760:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e0a8>
     764:      	ldr	x17, [x16, #0xfa0]
     768:      	add	x16, x16, #0xfa0
     76c:      	br	x17

0000000000000770 <__stack_chk_fail@plt>:
     770:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e0a8>
     774:      	ldr	x17, [x16, #0xfa8]
     778:      	add	x16, x16, #0xfa8
     77c:      	br	x17

0000000000000780 <__gmon_start__@plt>:
     780:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e0a8>
     784:      	ldr	x17, [x16, #0xfb0]
     788:      	add	x16, x16, #0xfb0
     78c:      	br	x17

0000000000000790 <abort@plt>:
     790:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e0a8>
     794:      	ldr	x17, [x16, #0xfb8]
     798:      	add	x16, x16, #0xfb8
     79c:      	br	x17

00000000000007a0 <printf@plt>:
     7a0:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e0a8>
     7a4:      	ldr	x17, [x16, #0xfc0]
     7a8:      	add	x16, x16, #0xfc0
     7ac:      	br	x17

Disassembly of section .text:

00000000000007c0 <_start>:
     7c0:      	nop
     7c4:      	mov	x29, #0x0               // =0
     7c8:      	mov	x30, #0x0               // =0
     7cc:      	mov	x5, x0
     7d0:      	ldr	x1, [sp]
     7d4:      	add	x2, sp, #0x8
     7d8:      	mov	x6, sp
     7dc:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e0a8>
     7e0:      	ldr	x0, [x0, #0xff0]
     7e4:      	mov	x3, #0x0                // =0
     7e8:      	mov	x4, #0x0                // =0
     7ec:      	bl	0x740 <__libc_start_main@plt>
     7f0:      	bl	0x790 <abort@plt>

00000000000007f4 <call_weak_fn>:
     7f4:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e0a8>
     7f8:      	ldr	x0, [x0, #0xfe0]
     7fc:      	cbz	x0, 0x804 <call_weak_fn+0x10>
     800:      	b	0x780 <__gmon_start__@plt>
     804:      	ret
     808:      	nop
     80c:      	nop

0000000000000810 <deregister_tm_clones>:
     810:      	adrp	x0, 0x20000 <data_start>
     814:      	add	x0, x0, #0x10
     818:      	adrp	x1, 0x20000 <data_start>
     81c:      	add	x1, x1, #0x10
     820:      	cmp	x1, x0
     824:      	b.eq	0x83c <deregister_tm_clones+0x2c>
     828:      	adrp	x1, 0x1f000 <__FRAME_END__+0x1e0a8>
     82c:      	ldr	x1, [x1, #0xfd0]
     830:      	cbz	x1, 0x83c <deregister_tm_clones+0x2c>
     834:      	mov	x16, x1
     838:      	br	x16
     83c:      	ret

0000000000000840 <register_tm_clones>:
     840:      	adrp	x0, 0x20000 <data_start>
     844:      	add	x0, x0, #0x10
     848:      	adrp	x1, 0x20000 <data_start>
     84c:      	add	x1, x1, #0x10
     850:      	sub	x1, x1, x0
     854:      	lsr	x2, x1, #63
     858:      	add	x1, x2, x1, asr #3
     85c:      	asr	x1, x1, #1
     860:      	cbz	x1, 0x878 <register_tm_clones+0x38>
     864:      	adrp	x2, 0x1f000 <__FRAME_END__+0x1e0a8>
     868:      	ldr	x2, [x2, #0xff8]
     86c:      	cbz	x2, 0x878 <register_tm_clones+0x38>
     870:      	mov	x16, x2
     874:      	br	x16
     878:      	ret
     87c:      	nop

0000000000000880 <__do_global_dtors_aux>:
     880:      	paciasp
     884:      	stp	x29, x30, [sp, #-0x20]!
     888:      	mov	x29, sp
     88c:      	str	x19, [sp, #0x10]
     890:      	adrp	x19, 0x20000 <data_start>
     894:      	ldrb	w0, [x19, #0x10]
     898:      	tbnz	w0, #0x0, 0x8c0 <__do_global_dtors_aux+0x40>
     89c:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e0a8>
     8a0:      	ldr	x0, [x0, #0xfd8]
     8a4:      	cbz	x0, 0x8b4 <__do_global_dtors_aux+0x34>
     8a8:      	adrp	x0, 0x20000 <data_start>
     8ac:      	ldr	x0, [x0, #0x8]
     8b0:      	bl	0x750 <__cxa_finalize@plt>
     8b4:      	bl	0x810 <deregister_tm_clones>
     8b8:      	mov	w0, #0x1                // =1
     8bc:      	strb	w0, [x19, #0x10]
     8c0:      	ldr	x19, [sp, #0x10]
     8c4:      	ldp	x29, x30, [sp], #0x20
     8c8:      	autiasp
     8cc:      	ret

00000000000008d0 <frame_dummy>:
     8d0:      	bti	c
     8d4:      	b	0x840 <register_tm_clones>

00000000000008d8 <region_pipeline>:
     8d8:      	stp	x29, x30, [sp, #-0x40]!
     8dc:      	mov	x29, sp
     8e0:      	str	x19, [sp, #0x10]
     8e4:      	str	x0, [sp, #0x28]
     8e8:      	str	w1, [sp, #0x24]
     8ec:      	str	w2, [sp, #0x20]
     8f0:      	ldr	x0, [sp, #0x28]
     8f4:      	ldr	w0, [x0]
     8f8:      	str	w0, [sp, #0x34]
     8fc:      	ldr	w1, [sp, #0x24]
     900:      	ldr	w0, [sp, #0x34]
     904:      	add	w19, w1, w0
     908:      	mov	w0, w19
     90c:      	lsl	w0, w0, #1
     910:      	add	w0, w0, w19
     914:      	add	w0, w0, #0xb
     918:      	str	w0, [sp, #0x30]
     91c:      	ldr	w1, [sp, #0x30]
     920:      	ldr	w0, [sp, #0x34]
     924:      	sub	w0, w1, w0
     928:      	str	w0, [sp, #0x24]
     92c:      	mov	w0, w19
     930:      	bl	0xaa4 <record_event>
     934:      	ldr	w0, [sp, #0x20]
     938:      	cmp	w0, #0x0
     93c:      	b.ge	0x9d4 <region_pipeline+0xfc>
     940:      	ldr	w0, [sp, #0x24]
     944:      	b	0x9ec <region_pipeline+0x114>
     948:      	ldr	w0, [sp, #0x24]
     94c:      	bl	0xae4 <next_value>
     950:      	str	w0, [sp, #0x34]
     954:      	ldr	w1, [sp, #0x24]
     958:      	ldr	w0, [sp, #0x34]
     95c:      	add	w0, w1, w0
     960:      	str	w0, [sp, #0x24]
     964:      	ldr	w1, [sp, #0x34]
     968:      	mov	w0, w1
     96c:      	lsl	w0, w0, #2
     970:      	add	w0, w0, w1
     974:      	ldr	w1, [sp, #0x30]
     978:      	add	w0, w1, w0
     97c:      	str	w0, [sp, #0x38]
     980:      	ldr	w1, [sp, #0x38]
     984:      	ldr	w0, [sp, #0x34]
     988:      	sub	w0, w1, w0
     98c:      	str	w0, [sp, #0x3c]
     990:      	ldr	w0, [sp, #0x3c]
     994:      	add	w0, w0, w19
     998:      	str	w0, [sp, #0x30]
     99c:      	ldr	w0, [sp, #0x38]
     9a0:      	bl	0xaa4 <record_event>
     9a4:      	ldr	w0, [sp, #0x38]
     9a8:      	add	w0, w0, #0x7
     9ac:      	str	w0, [sp, #0x38]
     9b0:      	ldr	x0, [sp, #0x28]
     9b4:      	ldr	w1, [sp, #0x38]
     9b8:      	str	w1, [x0]
     9bc:      	ldr	w1, [sp, #0x24]
     9c0:      	ldr	w0, [sp, #0x30]
     9c4:      	add	w0, w1, w0
     9c8:      	str	w0, [sp, #0x24]
     9cc:      	ldr	w0, [sp, #0x34]
     9d0:      	bl	0xaa4 <record_event>
     9d4:      	ldr	w0, [sp, #0x20]
     9d8:      	sub	w1, w0, #0x1
     9dc:      	str	w1, [sp, #0x20]
     9e0:      	cmp	w0, #0x0
     9e4:      	b.gt	0x948 <region_pipeline+0x70>
     9e8:      	ldr	w0, [sp, #0x24]
     9ec:      	ldr	x19, [sp, #0x10]
     9f0:      	ldp	x29, x30, [sp], #0x40
     9f4:      	ret

00000000000009f8 <region_outputs>:
     9f8:      	stp	x29, x30, [sp, #-0x40]!
     9fc:      	mov	x29, sp
     a00:      	str	x19, [sp, #0x10]
     a04:      	str	x0, [sp, #0x28]
     a08:      	str	w1, [sp, #0x24]
     a0c:      	str	w2, [sp, #0x20]
     a10:      	mov	w19, #0x11              // =17
     a14:      	ldr	w0, [sp, #0x24]
     a18:      	add	w0, w19, w0
     a1c:      	str	w0, [sp, #0x38]
     a20:      	ldr	w1, [sp, #0x38]
     a24:      	mov	w0, w1
     a28:      	lsl	w0, w0, #1
     a2c:      	add	w0, w0, w1
     a30:      	ldr	w1, [sp, #0x20]
     a34:      	add	w0, w1, w0
     a38:      	str	w0, [sp, #0x24]
     a3c:      	ldr	w0, [sp, #0x24]
     a40:      	sub	w0, w0, w19
     a44:      	str	w0, [sp, #0x20]
     a48:      	ldr	w0, [sp, #0x24]
     a4c:      	bl	0xaa4 <record_event>
     a50:      	ldr	w0, [sp, #0x24]
     a54:      	add	w0, w0, #0x7
     a58:      	str	w0, [sp, #0x3c]
     a5c:      	ldr	x0, [sp, #0x28]
     a60:      	add	x0, x0, #0x8
     a64:      	ldr	w1, [sp, #0x3c]
     a68:      	str	w1, [x0]
     a6c:      	ldr	x0, [sp, #0x28]
     a70:      	ldr	w1, [sp, #0x20]
     a74:      	str	w1, [x0]
     a78:      	ldr	x0, [sp, #0x28]
     a7c:      	add	x0, x0, #0x4
     a80:      	str	w19, [x0]
     a84:      	ldr	w1, [sp, #0x24]
     a88:      	ldr	w0, [sp, #0x20]
     a8c:      	cmp	w1, w0
     a90:      	cset	w0, eq
     a94:      	and	w0, w0, #0xff
     a98:      	ldr	x19, [sp, #0x10]
     a9c:      	ldp	x29, x30, [sp], #0x40
     aa0:      	ret

0000000000000aa4 <record_event>:
     aa4:      	sub	sp, sp, #0x10
     aa8:      	str	w0, [sp, #0xc]
     aac:      	adrp	x0, 0x20000 <data_start>
     ab0:      	add	x0, x0, #0x24
     ab4:      	ldr	w1, [x0]
     ab8:      	mov	w0, w1
     abc:      	lsl	w0, w0, #5
     ac0:      	add	w1, w0, w1
     ac4:      	ldr	w0, [sp, #0xc]
     ac8:      	eor	w1, w1, w0
     acc:      	adrp	x0, 0x20000 <data_start>
     ad0:      	add	x0, x0, #0x24
     ad4:      	str	w1, [x0]
     ad8:      	nop
     adc:      	add	sp, sp, #0x10
     ae0:      	ret

0000000000000ae4 <next_value>:
     ae4:      	stp	x29, x30, [sp, #-0x20]!
     ae8:      	mov	x29, sp
     aec:      	str	w0, [sp, #0x1c]
     af0:      	ldr	w0, [sp, #0x1c]
     af4:      	bl	0xaa4 <record_event>
     af8:      	adrp	x0, 0x20000 <data_start>
     afc:      	add	x0, x0, #0x18
     b00:      	ldr	w1, [x0, #0x4]
     b04:      	ldr	w0, [sp, #0x1c]
     b08:      	add	w1, w1, w0
     b0c:      	adrp	x0, 0x20000 <data_start>
     b10:      	add	x0, x0, #0x18
     b14:      	str	w1, [x0, #0x4]
     b18:      	adrp	x0, 0x20000 <data_start>
     b1c:      	add	x0, x0, #0x18
     b20:      	ldr	w1, [x0, #0x4]
     b24:      	ldr	w0, [sp, #0x1c]
     b28:      	add	w0, w1, w0
     b2c:      	ldp	x29, x30, [sp], #0x20
     b30:      	ret

0000000000000b34 <main>:
     b34:      	sub	sp, sp, #0x70
     b38:      	stp	x29, x30, [sp, #0x60]
     b3c:      	add	x29, sp, #0x60
     b40:      	str	w0, [sp, #0xc]
     b44:      	str	x1, [sp]
     b48:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e0a8>
     b4c:      	ldr	x0, [x0, #0xfe8]
     b50:      	ldr	x1, [x0]
     b54:      	str	x1, [sp, #0x58]
     b58:      	mov	x1, #0x0                // =0
     b5c:      	ldr	w0, [sp, #0xc]
     b60:      	cmp	w0, #0x3
     b64:      	b.eq	0xb70 <main+0x3c>
     b68:      	mov	w0, #0x2                // =2
     b6c:      	b	0xd58 <main+0x224>
     b70:      	ldr	x0, [sp]
     b74:      	add	x0, x0, #0x8
     b78:      	ldr	x0, [x0]
     b7c:      	mov	w2, #0xa                // =10
     b80:      	mov	x1, #0x0                // =0
     b84:      	bl	0x730 <strtoul@plt>
     b88:      	str	x0, [sp, #0x28]
     b8c:      	ldr	x0, [sp]
     b90:      	add	x0, x0, #0x10
     b94:      	ldr	x0, [x0]
     b98:      	mov	w2, #0xa                // =10
     b9c:      	mov	x1, #0x0                // =0
     ba0:      	bl	0x730 <strtoul@plt>
     ba4:      	str	w0, [sp, #0x18]
     ba8:      	str	wzr, [sp, #0x1c]
     bac:      	add	x0, sp, #0x38
     bb0:      	mov	x1, x0
     bb4:      	mov	w0, #0x1                // =1
     bb8:      	bl	0x760 <clock_gettime@plt>
     bbc:      	cmp	w0, #0x0
     bc0:      	b.eq	0xbcc <main+0x98>
     bc4:      	mov	w0, #0x2                // =2
     bc8:      	b	0xd58 <main+0x224>
     bcc:      	str	xzr, [sp, #0x20]
     bd0:      	b	0xc94 <main+0x160>
     bd4:      	ldr	w0, [sp, #0x18]
     bd8:      	lsl	w0, w0, #13
     bdc:      	ldr	w1, [sp, #0x18]
     be0:      	eor	w0, w1, w0
     be4:      	str	w0, [sp, #0x18]
     be8:      	ldr	w0, [sp, #0x18]
     bec:      	lsr	w0, w0, #17
     bf0:      	ldr	w1, [sp, #0x18]
     bf4:      	eor	w0, w1, w0
     bf8:      	str	w0, [sp, #0x18]
     bfc:      	ldr	w0, [sp, #0x18]
     c00:      	lsl	w0, w0, #5
     c04:      	ldr	w1, [sp, #0x18]
     c08:      	eor	w0, w1, w0
     c0c:      	str	w0, [sp, #0x18]
     c10:      	ldr	x2, [sp, #0x20]
     c14:      	mov	x0, #-0x3333333333333334 // =-3689348814741910324
     c18:      	movk	x0, #0xcccd
     c1c:      	umulh	x0, x2, x0
     c20:      	lsr	x1, x0, #3
     c24:      	mov	x0, x1
     c28:      	lsl	x0, x0, #2
     c2c:      	add	x0, x0, x1
     c30:      	lsl	x0, x0, #1
     c34:      	sub	x1, x2, x0
     c38:      	mov	w0, w1
     c3c:      	sub	w0, w0, #0x1
     c40:      	mov	w2, w0
     c44:      	ldr	w1, [sp, #0x18]
     c48:      	adrp	x0, 0x20000 <data_start>
     c4c:      	add	x0, x0, #0x18
     c50:      	bl	0x8d8 <region_pipeline>
     c54:      	mov	w1, w0
     c58:      	ldr	w0, [sp, #0x1c]
     c5c:      	add	w0, w0, w1
     c60:      	str	w0, [sp, #0x1c]
     c64:      	ldr	w2, [sp, #0x1c]
     c68:      	ldr	w1, [sp, #0x18]
     c6c:      	adrp	x0, 0x20000 <data_start>
     c70:      	add	x0, x0, #0x18
     c74:      	bl	0x9f8 <region_outputs>
     c78:      	mov	w1, w0
     c7c:      	ldr	w0, [sp, #0x1c]
     c80:      	add	w0, w0, w1
     c84:      	str	w0, [sp, #0x1c]
     c88:      	ldr	x0, [sp, #0x20]
     c8c:      	add	x0, x0, #0x1
     c90:      	str	x0, [sp, #0x20]
     c94:      	ldr	x1, [sp, #0x20]
     c98:      	ldr	x0, [sp, #0x28]
     c9c:      	cmp	x1, x0
     ca0:      	b.lo	0xbd4 <main+0xa0>
     ca4:      	add	x0, sp, #0x48
     ca8:      	mov	x1, x0
     cac:      	mov	w0, #0x1                // =1
     cb0:      	bl	0x760 <clock_gettime@plt>
     cb4:      	cmp	w0, #0x0
     cb8:      	b.eq	0xcc4 <main+0x190>
     cbc:      	mov	w0, #0x2                // =2
     cc0:      	b	0xd58 <main+0x224>
     cc4:      	ldr	x1, [sp, #0x48]
     cc8:      	ldr	x0, [sp, #0x38]
     ccc:      	sub	x0, x1, x0
     cd0:      	fmov	d0, x0
     cd4:      	scvtf	d1, d0
     cd8:      	ldr	x1, [sp, #0x50]
     cdc:      	ldr	x0, [sp, #0x40]
     ce0:      	sub	x0, x1, x0
     ce4:      	fmov	d0, x0
     ce8:      	scvtf	d0, d0
     cec:      	adrp	x0, 0x0 <strtoul@GLIBC_2.17>
     cf0:      	ldr	d2, [x0, #0xdc0]
     cf4:      	fmul	d0, d0, d2
     cf8:      	fadd	d0, d1, d0
     cfc:      	str	d0, [sp, #0x30]
     d00:      	adrp	x0, 0x20000 <data_start>
     d04:      	add	x0, x0, #0x18
     d08:      	ldr	w1, [x0]
     d0c:      	adrp	x0, 0x20000 <data_start>
     d10:      	add	x0, x0, #0x18
     d14:      	ldr	w2, [x0, #0x4]
     d18:      	adrp	x0, 0x20000 <data_start>
     d1c:      	add	x0, x0, #0x18
     d20:      	ldr	w3, [x0, #0x8]
     d24:      	adrp	x0, 0x20000 <data_start>
     d28:      	add	x0, x0, #0x24
     d2c:      	ldr	w0, [x0]
     d30:      	mov	w5, w0
     d34:      	mov	w4, w3
     d38:      	mov	w3, w2
     d3c:      	mov	w2, w1
     d40:      	ldr	w1, [sp, #0x1c]
     d44:      	ldr	d0, [sp, #0x30]
     d48:      	adrp	x0, 0x0 <strtoul@GLIBC_2.17>
     d4c:      	add	x0, x0, #0xda8
     d50:      	bl	0x7a0 <printf@plt>
     d54:      	mov	w0, #0x0                // =0
     d58:      	mov	w1, w0
     d5c:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e0a8>
     d60:      	ldr	x0, [x0, #0xfe8]
     d64:      	ldr	x3, [sp, #0x58]
     d68:      	ldr	x2, [x0]
     d6c:      	subs	x3, x3, x2
     d70:      	mov	x2, #0x0                // =0
     d74:      	b.eq	0xd7c <main+0x248>
     d78:      	bl	0x770 <__stack_chk_fail@plt>
     d7c:      	mov	w0, w1
     d80:      	ldp	x29, x30, [sp, #0x60]
     d84:      	add	sp, sp, #0x70
     d88:      	ret

Disassembly of section .fini:

0000000000000d8c <_fini>:
     d8c:      	nop
     d90:      	stp	x29, x30, [sp, #-0x10]!
     d94:      	mov	x29, sp
     d98:      	ldp	x29, x30, [sp], #0x10
     d9c:      	ret
