
/work/experiments/runs/private-declarations-cost-linux-20261110/clang-O0/original:	file format elf64-littleaarch64

Disassembly of section .init:

0000000000000638 <_init>:
     638:      	nop
     63c:      	stp	x29, x30, [sp, #-0x10]!
     640:      	mov	x29, sp
     644:      	bl	0x734 <call_weak_fn>
     648:      	ldp	x29, x30, [sp], #0x10
     64c:      	ret

Disassembly of section .plt:

0000000000000650 <.plt>:
     650:      	stp	x16, x30, [sp, #-0x10]!
     654:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e19c>
     658:      	ldr	x17, [x16, #0xff8]
     65c:      	add	x16, x16, #0xff8
     660:      	br	x17
     664:      	nop
     668:      	nop
     66c:      	nop

0000000000000670 <strtoul@plt>:
     670:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     674:      	ldr	x17, [x16]
     678:      	add	x16, x16, #0x0
     67c:      	br	x17

0000000000000680 <__libc_start_main@plt>:
     680:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     684:      	ldr	x17, [x16, #0x8]
     688:      	add	x16, x16, #0x8
     68c:      	br	x17

0000000000000690 <__cxa_finalize@plt>:
     690:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     694:      	ldr	x17, [x16, #0x10]
     698:      	add	x16, x16, #0x10
     69c:      	br	x17

00000000000006a0 <clock_gettime@plt>:
     6a0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6a4:      	ldr	x17, [x16, #0x18]
     6a8:      	add	x16, x16, #0x18
     6ac:      	br	x17

00000000000006b0 <__gmon_start__@plt>:
     6b0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6b4:      	ldr	x17, [x16, #0x20]
     6b8:      	add	x16, x16, #0x20
     6bc:      	br	x17

00000000000006c0 <abort@plt>:
     6c0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6c4:      	ldr	x17, [x16, #0x28]
     6c8:      	add	x16, x16, #0x28
     6cc:      	br	x17

00000000000006d0 <printf@plt>:
     6d0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6d4:      	ldr	x17, [x16, #0x30]
     6d8:      	add	x16, x16, #0x30
     6dc:      	br	x17

Disassembly of section .text:

0000000000000700 <_start>:
     700:      	nop
     704:      	mov	x29, #0x0               // =0
     708:      	mov	x30, #0x0               // =0
     70c:      	mov	x5, x0
     710:      	ldr	x1, [sp]
     714:      	add	x2, sp, #0x8
     718:      	mov	x6, sp
     71c:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e19c>
     720:      	ldr	x0, [x0, #0xfd8]
     724:      	mov	x3, #0x0                // =0
     728:      	mov	x4, #0x0                // =0
     72c:      	bl	0x680 <__libc_start_main@plt>
     730:      	bl	0x6c0 <abort@plt>

0000000000000734 <call_weak_fn>:
     734:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e19c>
     738:      	ldr	x0, [x0, #0xfd0]
     73c:      	cbz	x0, 0x744 <call_weak_fn+0x10>
     740:      	b	0x6b0 <__gmon_start__@plt>
     744:      	ret
     748:      	nop
     74c:      	nop

0000000000000750 <deregister_tm_clones>:
     750:      	adrp	x0, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     754:      	add	x0, x0, #0x48
     758:      	adrp	x1, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     75c:      	add	x1, x1, #0x48
     760:      	cmp	x1, x0
     764:      	b.eq	0x77c <deregister_tm_clones+0x2c>
     768:      	adrp	x1, 0x1f000 <__FRAME_END__+0x1e19c>
     76c:      	ldr	x1, [x1, #0xfc0]
     770:      	cbz	x1, 0x77c <deregister_tm_clones+0x2c>
     774:      	mov	x16, x1
     778:      	br	x16
     77c:      	ret

0000000000000780 <register_tm_clones>:
     780:      	adrp	x0, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     784:      	add	x0, x0, #0x48
     788:      	adrp	x1, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     78c:      	add	x1, x1, #0x48
     790:      	sub	x1, x1, x0
     794:      	lsr	x2, x1, #63
     798:      	add	x1, x2, x1, asr #3
     79c:      	asr	x1, x1, #1
     7a0:      	cbz	x1, 0x7b8 <register_tm_clones+0x38>
     7a4:      	adrp	x2, 0x1f000 <__FRAME_END__+0x1e19c>
     7a8:      	ldr	x2, [x2, #0xfe0]
     7ac:      	cbz	x2, 0x7b8 <register_tm_clones+0x38>
     7b0:      	mov	x16, x2
     7b4:      	br	x16
     7b8:      	ret
     7bc:      	nop

00000000000007c0 <__do_global_dtors_aux>:
     7c0:      	paciasp
     7c4:      	stp	x29, x30, [sp, #-0x20]!
     7c8:      	mov	x29, sp
     7cc:      	str	x19, [sp, #0x10]
     7d0:      	adrp	x19, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     7d4:      	ldrb	w0, [x19, #0x48]
     7d8:      	tbnz	w0, #0x0, 0x800 <__do_global_dtors_aux+0x40>
     7dc:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e19c>
     7e0:      	ldr	x0, [x0, #0xfc8]
     7e4:      	cbz	x0, 0x7f4 <__do_global_dtors_aux+0x34>
     7e8:      	adrp	x0, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     7ec:      	ldr	x0, [x0, #0x40]
     7f0:      	bl	0x690 <__cxa_finalize@plt>
     7f4:      	bl	0x750 <deregister_tm_clones>
     7f8:      	mov	w0, #0x1                // =1
     7fc:      	strb	w0, [x19, #0x48]
     800:      	ldr	x19, [sp, #0x10]
     804:      	ldp	x29, x30, [sp], #0x20
     808:      	autiasp
     80c:      	ret

0000000000000810 <frame_dummy>:
     810:      	bti	c
     814:      	b	0x780 <register_tm_clones>

0000000000000818 <region_pipeline>:
     818:      	sub	sp, sp, #0x40
     81c:      	stp	x29, x30, [sp, #0x30]
     820:      	add	x29, sp, #0x30
     824:      	stur	x0, [x29, #-0x10]
     828:      	stur	w1, [x29, #-0x14]
     82c:      	str	w2, [sp, #0x18]
     830:      	ldur	x8, [x29, #-0x10]
     834:      	ldr	w8, [x8]
     838:      	str	w8, [sp, #0x14]
     83c:      	ldur	w8, [x29, #-0x14]
     840:      	ldr	w9, [sp, #0x14]
     844:      	add	w8, w8, w9
     848:      	str	w8, [sp, #0x10]
     84c:      	ldr	w9, [sp, #0x10]
     850:      	mov	w8, #0x3                // =3
     854:      	mul	w8, w8, w9
     858:      	add	w8, w8, #0xb
     85c:      	str	w8, [sp, #0xc]
     860:      	ldr	w8, [sp, #0xc]
     864:      	ldr	w9, [sp, #0x14]
     868:      	subs	w8, w8, w9
     86c:      	stur	w8, [x29, #-0x14]
     870:      	ldr	w0, [sp, #0x10]
     874:      	bl	0xa04 <record_event>
     878:      	ldr	w8, [sp, #0x18]
     87c:      	tbz	w8, #0x1f, 0x890 <region_pipeline+0x78>
     880:      	b	0x884 <region_pipeline+0x6c>
     884:      	ldur	w8, [x29, #-0x14]
     888:      	stur	w8, [x29, #-0x4]
     88c:      	b	0x948 <region_pipeline+0x130>
     890:      	b	0x894 <region_pipeline+0x7c>
     894:      	ldr	w8, [sp, #0x18]
     898:      	subs	w9, w8, #0x1
     89c:      	str	w9, [sp, #0x18]
     8a0:      	subs	w8, w8, #0x0
     8a4:      	b.le	0x93c <region_pipeline+0x124>
     8a8:      	b	0x8ac <region_pipeline+0x94>
     8ac:      	ldur	w0, [x29, #-0x14]
     8b0:      	bl	0xa30 <next_value>
     8b4:      	str	w0, [sp, #0x14]
     8b8:      	ldur	w8, [x29, #-0x14]
     8bc:      	ldr	w9, [sp, #0x14]
     8c0:      	add	w8, w8, w9
     8c4:      	stur	w8, [x29, #-0x14]
     8c8:      	ldr	w8, [sp, #0xc]
     8cc:      	ldr	w10, [sp, #0x14]
     8d0:      	mov	w9, #0x5                // =5
     8d4:      	mul	w9, w9, w10
     8d8:      	add	w8, w8, w9
     8dc:      	str	w8, [sp, #0x8]
     8e0:      	ldr	w8, [sp, #0x8]
     8e4:      	ldr	w9, [sp, #0x14]
     8e8:      	subs	w8, w8, w9
     8ec:      	str	w8, [sp, #0x4]
     8f0:      	ldr	w8, [sp, #0x4]
     8f4:      	ldr	w9, [sp, #0x10]
     8f8:      	add	w8, w8, w9
     8fc:      	str	w8, [sp, #0xc]
     900:      	ldr	w0, [sp, #0x8]
     904:      	bl	0xa04 <record_event>
     908:      	ldr	w8, [sp, #0x8]
     90c:      	add	w8, w8, #0x7
     910:      	str	w8, [sp, #0x8]
     914:      	ldr	w8, [sp, #0x8]
     918:      	ldur	x9, [x29, #-0x10]
     91c:      	str	w8, [x9]
     920:      	ldur	w8, [x29, #-0x14]
     924:      	ldr	w9, [sp, #0xc]
     928:      	add	w8, w8, w9
     92c:      	stur	w8, [x29, #-0x14]
     930:      	ldr	w0, [sp, #0x14]
     934:      	bl	0xa04 <record_event>
     938:      	b	0x894 <region_pipeline+0x7c>
     93c:      	ldur	w8, [x29, #-0x14]
     940:      	stur	w8, [x29, #-0x4]
     944:      	b	0x948 <region_pipeline+0x130>
     948:      	ldur	w0, [x29, #-0x4]
     94c:      	ldp	x29, x30, [sp, #0x30]
     950:      	add	sp, sp, #0x40
     954:      	ret

0000000000000958 <region_outputs>:
     958:      	sub	sp, sp, #0x30
     95c:      	stp	x29, x30, [sp, #0x20]
     960:      	add	x29, sp, #0x20
     964:      	stur	x0, [x29, #-0x8]
     968:      	stur	w1, [x29, #-0xc]
     96c:      	str	w2, [sp, #0x10]
     970:      	mov	w8, #0x11               // =17
     974:      	str	w8, [sp, #0xc]
     978:      	ldr	w8, [sp, #0xc]
     97c:      	ldur	w9, [x29, #-0xc]
     980:      	add	w8, w8, w9
     984:      	str	w8, [sp, #0x8]
     988:      	ldr	w9, [sp, #0x8]
     98c:      	mov	w8, #0x3                // =3
     990:      	mul	w8, w8, w9
     994:      	ldr	w9, [sp, #0x10]
     998:      	add	w8, w8, w9
     99c:      	stur	w8, [x29, #-0xc]
     9a0:      	ldur	w8, [x29, #-0xc]
     9a4:      	ldr	w9, [sp, #0xc]
     9a8:      	subs	w8, w8, w9
     9ac:      	str	w8, [sp, #0x10]
     9b0:      	ldur	w0, [x29, #-0xc]
     9b4:      	bl	0xa04 <record_event>
     9b8:      	ldur	w8, [x29, #-0xc]
     9bc:      	add	w8, w8, #0x7
     9c0:      	str	w8, [sp, #0x4]
     9c4:      	ldr	w8, [sp, #0x4]
     9c8:      	ldur	x9, [x29, #-0x8]
     9cc:      	str	w8, [x9, #0x8]
     9d0:      	ldr	w8, [sp, #0x10]
     9d4:      	ldur	x9, [x29, #-0x8]
     9d8:      	str	w8, [x9]
     9dc:      	ldr	w8, [sp, #0xc]
     9e0:      	ldur	x9, [x29, #-0x8]
     9e4:      	str	w8, [x9, #0x4]
     9e8:      	ldur	w8, [x29, #-0xc]
     9ec:      	ldr	w9, [sp, #0x10]
     9f0:      	subs	w8, w8, w9
     9f4:      	cset	w0, eq
     9f8:      	ldp	x29, x30, [sp, #0x20]
     9fc:      	add	sp, sp, #0x30
     a00:      	ret

0000000000000a04 <record_event>:
     a04:      	sub	sp, sp, #0x10
     a08:      	str	w0, [sp, #0xc]
     a0c:      	adrp	x9, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     a10:      	ldr	w8, [x9, #0x4c]
     a14:      	mov	w10, #0x21              // =33
     a18:      	mul	w8, w8, w10
     a1c:      	ldr	w10, [sp, #0xc]
     a20:      	eor	w8, w8, w10
     a24:      	str	w8, [x9, #0x4c]
     a28:      	add	sp, sp, #0x10
     a2c:      	ret

0000000000000a30 <next_value>:
     a30:      	sub	sp, sp, #0x20
     a34:      	stp	x29, x30, [sp, #0x10]
     a38:      	add	x29, sp, #0x10
     a3c:      	stur	w0, [x29, #-0x4]
     a40:      	ldur	w0, [x29, #-0x4]
     a44:      	bl	0xa04 <record_event>
     a48:      	ldur	w10, [x29, #-0x4]
     a4c:      	adrp	x9, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     a50:      	add	x9, x9, #0x50
     a54:      	ldr	w8, [x9, #0x4]
     a58:      	add	w8, w8, w10
     a5c:      	str	w8, [x9, #0x4]
     a60:      	ldur	w8, [x29, #-0x4]
     a64:      	ldr	w9, [x9, #0x4]
     a68:      	add	w0, w8, w9
     a6c:      	ldp	x29, x30, [sp, #0x10]
     a70:      	add	sp, sp, #0x20
     a74:      	ret

0000000000000a78 <main>:
     a78:      	sub	sp, sp, #0x80
     a7c:      	stp	x29, x30, [sp, #0x70]
     a80:      	add	x29, sp, #0x70
     a84:      	stur	wzr, [x29, #-0x4]
     a88:      	stur	w0, [x29, #-0x8]
     a8c:      	stur	x1, [x29, #-0x10]
     a90:      	ldur	w8, [x29, #-0x8]
     a94:      	subs	w8, w8, #0x3
     a98:      	b.eq	0xaac <main+0x34>
     a9c:      	b	0xaa0 <main+0x28>
     aa0:      	mov	w8, #0x2                // =2
     aa4:      	stur	w8, [x29, #-0x4]
     aa8:      	b	0xc50 <main+0x1d8>
     aac:      	ldur	x8, [x29, #-0x10]
     ab0:      	ldr	x0, [x8, #0x8]
     ab4:      	mov	x1, xzr
     ab8:      	str	x1, [sp, #0x10]
     abc:      	mov	w2, #0xa                // =10
     ac0:      	str	w2, [sp, #0x1c]
     ac4:      	bl	0x670 <strtoul@plt>
     ac8:      	ldr	x1, [sp, #0x10]
     acc:      	ldr	w2, [sp, #0x1c]
     ad0:      	stur	x0, [x29, #-0x18]
     ad4:      	ldur	x8, [x29, #-0x10]
     ad8:      	ldr	x0, [x8, #0x10]
     adc:      	bl	0x670 <strtoul@plt>
     ae0:      	mov	w8, w0
     ae4:      	stur	w8, [x29, #-0x1c]
     ae8:      	stur	wzr, [x29, #-0x20]
     aec:      	mov	w0, #0x1                // =1
     af0:      	sub	x1, x29, #0x30
     af4:      	bl	0x6a0 <clock_gettime@plt>
     af8:      	cbz	w0, 0xb0c <main+0x94>
     afc:      	b	0xb00 <main+0x88>
     b00:      	mov	w8, #0x2                // =2
     b04:      	stur	w8, [x29, #-0x4]
     b08:      	b	0xc50 <main+0x1d8>
     b0c:      	str	xzr, [sp, #0x28]
     b10:      	b	0xb14 <main+0x9c>
     b14:      	ldr	x8, [sp, #0x28]
     b18:      	ldur	x9, [x29, #-0x18]
     b1c:      	subs	x8, x8, x9
     b20:      	b.hs	0xbc4 <main+0x14c>
     b24:      	b	0xb28 <main+0xb0>
     b28:      	ldur	w9, [x29, #-0x1c]
     b2c:      	ldur	w8, [x29, #-0x1c]
     b30:      	eor	w8, w8, w9, lsl #13
     b34:      	stur	w8, [x29, #-0x1c]
     b38:      	ldur	w9, [x29, #-0x1c]
     b3c:      	ldur	w8, [x29, #-0x1c]
     b40:      	eor	w8, w8, w9, lsr #17
     b44:      	stur	w8, [x29, #-0x1c]
     b48:      	ldur	w9, [x29, #-0x1c]
     b4c:      	ldur	w8, [x29, #-0x1c]
     b50:      	eor	w8, w8, w9, lsl #5
     b54:      	stur	w8, [x29, #-0x1c]
     b58:      	ldur	w1, [x29, #-0x1c]
     b5c:      	ldr	x8, [sp, #0x28]
     b60:      	mov	x10, #0xa               // =10
     b64:      	udiv	x9, x8, x10
     b68:      	mul	x9, x9, x10
     b6c:      	subs	x8, x8, x9
     b70:      	subs	w2, w8, #0x1
     b74:      	adrp	x0, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     b78:      	add	x0, x0, #0x50
     b7c:      	str	x0, [sp, #0x8]
     b80:      	bl	0x818 <region_pipeline>
     b84:      	mov	w9, w0
     b88:      	ldr	x0, [sp, #0x8]
     b8c:      	ldur	w8, [x29, #-0x20]
     b90:      	add	w8, w8, w9
     b94:      	stur	w8, [x29, #-0x20]
     b98:      	ldur	w1, [x29, #-0x1c]
     b9c:      	ldur	w2, [x29, #-0x20]
     ba0:      	bl	0x958 <region_outputs>
     ba4:      	ldur	w8, [x29, #-0x20]
     ba8:      	add	w8, w8, w0
     bac:      	stur	w8, [x29, #-0x20]
     bb0:      	b	0xbb4 <main+0x13c>
     bb4:      	ldr	x8, [sp, #0x28]
     bb8:      	add	x8, x8, #0x1
     bbc:      	str	x8, [sp, #0x28]
     bc0:      	b	0xb14 <main+0x9c>
     bc4:      	mov	w0, #0x1                // =1
     bc8:      	add	x1, sp, #0x30
     bcc:      	bl	0x6a0 <clock_gettime@plt>
     bd0:      	cbz	w0, 0xbe4 <main+0x16c>
     bd4:      	b	0xbd8 <main+0x160>
     bd8:      	mov	w8, #0x2                // =2
     bdc:      	stur	w8, [x29, #-0x4]
     be0:      	b	0xc50 <main+0x1d8>
     be4:      	ldr	x8, [sp, #0x30]
     be8:      	ldur	x9, [x29, #-0x30]
     bec:      	subs	x8, x8, x9
     bf0:      	scvtf	d2, x8
     bf4:      	ldr	x8, [sp, #0x38]
     bf8:      	ldur	x9, [x29, #-0x28]
     bfc:      	subs	x8, x8, x9
     c00:      	scvtf	d0, x8
     c04:      	adrp	x8, 0x0 <strtoul@GLIBC_2.17>
     c08:      	ldr	d1, [x8, #0xc80]
     c0c:      	fmadd	d0, d0, d1, d2
     c10:      	str	d0, [sp, #0x20]
     c14:      	ldr	d0, [sp, #0x20]
     c18:      	ldur	w1, [x29, #-0x20]
     c1c:      	adrp	x9, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     c20:      	adrp	x8, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     c24:      	add	x8, x8, #0x50
     c28:      	ldr	w2, [x9, #0x50]
     c2c:      	ldr	w3, [x8, #0x4]
     c30:      	ldr	w4, [x8, #0x8]
     c34:      	adrp	x8, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     c38:      	ldr	w5, [x8, #0x4c]
     c3c:      	adrp	x0, 0x0 <strtoul@GLIBC_2.17>
     c40:      	add	x0, x0, #0xc88
     c44:      	bl	0x6d0 <printf@plt>
     c48:      	stur	wzr, [x29, #-0x4]
     c4c:      	b	0xc50 <main+0x1d8>
     c50:      	ldur	w0, [x29, #-0x4]
     c54:      	ldp	x29, x30, [sp, #0x70]
     c58:      	add	sp, sp, #0x80
     c5c:      	ret

Disassembly of section .fini:

0000000000000c60 <_fini>:
     c60:      	nop
     c64:      	stp	x29, x30, [sp, #-0x10]!
     c68:      	mov	x29, sp
     c6c:      	ldp	x29, x30, [sp], #0x10
     c70:      	ret
