
/work/experiments/runs/private-declarations-cost-linux-20261110/clang-O0/affine:	file format elf64-littleaarch64

Disassembly of section .init:

0000000000000638 <_init>:
     638:      	nop
     63c:      	stp	x29, x30, [sp, #-0x10]!
     640:      	mov	x29, sp
     644:      	bl	0x734 <call_weak_fn>
     648:      	ldp	x29, x30, [sp], #0x10
     64c:      	ret

Disassembly of section .plt:

0000000000000650 <.plt>:
     650:      	stp	x16, x30, [sp, #-0x10]!
     654:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1dec4>
     658:      	ldr	x17, [x16, #0xff8]
     65c:      	add	x16, x16, #0xff8
     660:      	br	x17
     664:      	nop
     668:      	nop
     66c:      	nop

0000000000000670 <strtoul@plt>:
     670:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     674:      	ldr	x17, [x16]
     678:      	add	x16, x16, #0x0
     67c:      	br	x17

0000000000000680 <__libc_start_main@plt>:
     680:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     684:      	ldr	x17, [x16, #0x8]
     688:      	add	x16, x16, #0x8
     68c:      	br	x17

0000000000000690 <__cxa_finalize@plt>:
     690:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     694:      	ldr	x17, [x16, #0x10]
     698:      	add	x16, x16, #0x10
     69c:      	br	x17

00000000000006a0 <clock_gettime@plt>:
     6a0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6a4:      	ldr	x17, [x16, #0x18]
     6a8:      	add	x16, x16, #0x18
     6ac:      	br	x17

00000000000006b0 <__gmon_start__@plt>:
     6b0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6b4:      	ldr	x17, [x16, #0x20]
     6b8:      	add	x16, x16, #0x20
     6bc:      	br	x17

00000000000006c0 <abort@plt>:
     6c0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6c4:      	ldr	x17, [x16, #0x28]
     6c8:      	add	x16, x16, #0x28
     6cc:      	br	x17

00000000000006d0 <printf@plt>:
     6d0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6d4:      	ldr	x17, [x16, #0x30]
     6d8:      	add	x16, x16, #0x30
     6dc:      	br	x17

Disassembly of section .text:

0000000000000700 <_start>:
     700:      	nop
     704:      	mov	x29, #0x0               // =0
     708:      	mov	x30, #0x0               // =0
     70c:      	mov	x5, x0
     710:      	ldr	x1, [sp]
     714:      	add	x2, sp, #0x8
     718:      	mov	x6, sp
     71c:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1dec4>
     720:      	ldr	x0, [x0, #0xfd8]
     724:      	mov	x3, #0x0                // =0
     728:      	mov	x4, #0x0                // =0
     72c:      	bl	0x680 <__libc_start_main@plt>
     730:      	bl	0x6c0 <abort@plt>

0000000000000734 <call_weak_fn>:
     734:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1dec4>
     738:      	ldr	x0, [x0, #0xfd0]
     73c:      	cbz	x0, 0x744 <call_weak_fn+0x10>
     740:      	b	0x6b0 <__gmon_start__@plt>
     744:      	ret
     748:      	nop
     74c:      	nop

0000000000000750 <deregister_tm_clones>:
     750:      	adrp	x0, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     754:      	add	x0, x0, #0x48
     758:      	adrp	x1, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     75c:      	add	x1, x1, #0x48
     760:      	cmp	x1, x0
     764:      	b.eq	0x77c <deregister_tm_clones+0x2c>
     768:      	adrp	x1, 0x1f000 <__FRAME_END__+0x1dec4>
     76c:      	ldr	x1, [x1, #0xfc0]
     770:      	cbz	x1, 0x77c <deregister_tm_clones+0x2c>
     774:      	mov	x16, x1
     778:      	br	x16
     77c:      	ret

0000000000000780 <register_tm_clones>:
     780:      	adrp	x0, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     784:      	add	x0, x0, #0x48
     788:      	adrp	x1, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     78c:      	add	x1, x1, #0x48
     790:      	sub	x1, x1, x0
     794:      	lsr	x2, x1, #63
     798:      	add	x1, x2, x1, asr #3
     79c:      	asr	x1, x1, #1
     7a0:      	cbz	x1, 0x7b8 <register_tm_clones+0x38>
     7a4:      	adrp	x2, 0x1f000 <__FRAME_END__+0x1dec4>
     7a8:      	ldr	x2, [x2, #0xfe0]
     7ac:      	cbz	x2, 0x7b8 <register_tm_clones+0x38>
     7b0:      	mov	x16, x2
     7b4:      	br	x16
     7b8:      	ret
     7bc:      	nop

00000000000007c0 <__do_global_dtors_aux>:
     7c0:      	paciasp
     7c4:      	stp	x29, x30, [sp, #-0x20]!
     7c8:      	mov	x29, sp
     7cc:      	str	x19, [sp, #0x10]
     7d0:      	adrp	x19, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     7d4:      	ldrb	w0, [x19, #0x48]
     7d8:      	tbnz	w0, #0x0, 0x800 <__do_global_dtors_aux+0x40>
     7dc:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1dec4>
     7e0:      	ldr	x0, [x0, #0xfc8]
     7e4:      	cbz	x0, 0x7f4 <__do_global_dtors_aux+0x34>
     7e8:      	adrp	x0, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     7ec:      	ldr	x0, [x0, #0x40]
     7f0:      	bl	0x690 <__cxa_finalize@plt>
     7f4:      	bl	0x750 <deregister_tm_clones>
     7f8:      	mov	w0, #0x1                // =1
     7fc:      	strb	w0, [x19, #0x48]
     800:      	ldr	x19, [sp, #0x10]
     804:      	ldp	x29, x30, [sp], #0x20
     808:      	autiasp
     80c:      	ret

0000000000000810 <frame_dummy>:
     810:      	bti	c
     814:      	b	0x780 <register_tm_clones>

0000000000000818 <region_pipeline>:
     818:      	sub	sp, sp, #0x90
     81c:      	stp	x29, x30, [sp, #0x80]
     820:      	add	x29, sp, #0x80
     824:      	mov	w10, #0xa4f5            // =42229
     828:      	movk	w10, #0x3d0d, lsl #16
     82c:      	str	w10, [sp, #0x8]
     830:      	mov	w8, #0xadf7             // =44535
     834:      	movk	w8, #0xec1, lsl #16
     838:      	mov	w9, #0x51b5             // =20917
     83c:      	movk	w9, #0x42c, lsl #16
     840:      	str	w9, [sp, #0xc]
     844:      	mov	w9, #0x32a8             // =12968
     848:      	movk	w9, #0x70ab, lsl #16
     84c:      	str	w9, [sp, #0x10]
     850:      	mov	w9, #0xd49d             // =54429
     854:      	movk	w9, #0x2188, lsl #16
     858:      	str	w9, [sp, #0x14]
     85c:      	mov	w9, #0x2b7f             // =11135
     860:      	movk	w9, #0x12a3, lsl #16
     864:      	str	w9, [sp, #0x18]
     868:      	mov	w9, #0x417c             // =16764
     86c:      	movk	w9, #0xdaf7, lsl #16
     870:      	str	w9, [sp, #0x1c]
     874:      	stur	x0, [x29, #-0x10]
     878:      	stur	w1, [x29, #-0x14]
     87c:      	stur	w2, [x29, #-0x18]
     880:      	ldur	x9, [x29, #-0x10]
     884:      	ldr	w9, [x9]
     888:      	stur	w9, [x29, #-0x1c]
     88c:      	ldur	w11, [x29, #-0x14]
     890:      	mov	w9, #0x23c7             // =9159
     894:      	movk	w9, #0xf25f, lsl #16
     898:      	mul	w11, w9, w11
     89c:      	add	w11, w11, w10
     8a0:      	stur	w11, [x29, #-0x20]
     8a4:      	ldur	w11, [x29, #-0x1c]
     8a8:      	mul	w9, w9, w11
     8ac:      	add	w9, w9, w10
     8b0:      	stur	w9, [x29, #-0x24]
     8b4:      	ldur	w9, [x29, #-0x20]
     8b8:      	ldur	w11, [x29, #-0x24]
     8bc:      	add	w9, w9, w11
     8c0:      	subs	w9, w9, w10
     8c4:      	stur	w9, [x29, #-0x28]
     8c8:      	ldur	w11, [x29, #-0x28]
     8cc:      	mov	w9, #0x3                // =3
     8d0:      	mul	w9, w9, w11
     8d4:      	mov	w11, #0xb616            // =46614
     8d8:      	movk	w11, #0x85e4, lsl #16
     8dc:      	add	w9, w9, w11
     8e0:      	mov	w11, #0x2e82            // =11906
     8e4:      	movk	w11, #0xa724, lsl #16
     8e8:      	add	w9, w9, w11
     8ec:      	subs	w9, w9, w10
     8f0:      	stur	w9, [x29, #-0x2c]
     8f4:      	ldur	w9, [x29, #-0x2c]
     8f8:      	ldur	w11, [x29, #-0x24]
     8fc:      	subs	w9, w9, w11
     900:      	add	w9, w9, w10
     904:      	stur	w9, [x29, #-0x20]
     908:      	ldur	w9, [x29, #-0x20]
     90c:      	subs	w9, w9, w10
     910:      	mul	w9, w8, w9
     914:      	stur	w9, [x29, #-0x14]
     918:      	ldur	w9, [x29, #-0x28]
     91c:      	subs	w9, w9, w10
     920:      	mul	w9, w8, w9
     924:      	stur	w9, [x29, #-0x30]
     928:      	ldur	w9, [x29, #-0x2c]
     92c:      	subs	w9, w9, w10
     930:      	mul	w8, w8, w9
     934:      	stur	w8, [x29, #-0x34]
     938:      	ldur	w0, [x29, #-0x30]
     93c:      	bl	0xcdc <record_event>
     940:      	ldur	w8, [x29, #-0x18]
     944:      	tbz	w8, #0x1f, 0x958 <region_pipeline+0x140>
     948:      	b	0x94c <region_pipeline+0x134>
     94c:      	ldur	w8, [x29, #-0x14]
     950:      	stur	w8, [x29, #-0x4]
     954:      	b	0xb40 <region_pipeline+0x328>
     958:      	b	0x95c <region_pipeline+0x144>
     95c:      	ldur	w8, [x29, #-0x18]
     960:      	subs	w9, w8, #0x1
     964:      	stur	w9, [x29, #-0x18]
     968:      	subs	w8, w8, #0x0
     96c:      	b.le	0xb34 <region_pipeline+0x31c>
     970:      	b	0x974 <region_pipeline+0x15c>
     974:      	ldur	w0, [x29, #-0x14]
     978:      	bl	0xd08 <next_value>
     97c:      	ldr	w9, [sp, #0xc]
     980:      	ldr	w10, [sp, #0x10]
     984:      	ldr	w8, [sp, #0x14]
     988:      	stur	w0, [x29, #-0x1c]
     98c:      	ldur	w11, [x29, #-0x14]
     990:      	mul	w11, w9, w11
     994:      	add	w11, w11, w10
     998:      	stur	w11, [x29, #-0x38]
     99c:      	ldur	w11, [x29, #-0x1c]
     9a0:      	mul	w11, w9, w11
     9a4:      	add	w11, w11, w10
     9a8:      	stur	w11, [x29, #-0x3c]
     9ac:      	ldur	w11, [x29, #-0x34]
     9b0:      	mul	w11, w9, w11
     9b4:      	add	w11, w11, w10
     9b8:      	str	w11, [sp, #0x40]
     9bc:      	ldur	w11, [x29, #-0x30]
     9c0:      	mul	w9, w9, w11
     9c4:      	add	w9, w9, w10
     9c8:      	str	w9, [sp, #0x3c]
     9cc:      	ldur	w9, [x29, #-0x38]
     9d0:      	ldur	w11, [x29, #-0x3c]
     9d4:      	add	w9, w9, w11
     9d8:      	subs	w9, w9, w10
     9dc:      	stur	w9, [x29, #-0x38]
     9e0:      	ldr	w9, [sp, #0x40]
     9e4:      	ldur	w12, [x29, #-0x3c]
     9e8:      	mov	w11, #0x5               // =5
     9ec:      	mul	w11, w11, w12
     9f0:      	mov	w12, #0x3560            // =13664
     9f4:      	movk	w12, #0x3d53, lsl #16
     9f8:      	add	w11, w11, w12
     9fc:      	add	w9, w9, w11
     a00:      	subs	w9, w9, w10
     a04:      	str	w9, [sp, #0x38]
     a08:      	ldr	w9, [sp, #0x38]
     a0c:      	ldur	w11, [x29, #-0x3c]
     a10:      	subs	w9, w9, w11
     a14:      	add	w9, w9, w10
     a18:      	str	w9, [sp, #0x34]
     a1c:      	ldr	w9, [sp, #0x34]
     a20:      	ldr	w11, [sp, #0x3c]
     a24:      	add	w9, w9, w11
     a28:      	subs	w9, w9, w10
     a2c:      	str	w9, [sp, #0x40]
     a30:      	ldur	w9, [x29, #-0x38]
     a34:      	subs	w9, w9, w10
     a38:      	mul	w9, w8, w9
     a3c:      	stur	w9, [x29, #-0x14]
     a40:      	ldr	w9, [sp, #0x40]
     a44:      	subs	w9, w9, w10
     a48:      	mul	w9, w8, w9
     a4c:      	stur	w9, [x29, #-0x34]
     a50:      	ldr	w9, [sp, #0x38]
     a54:      	subs	w9, w9, w10
     a58:      	mul	w9, w8, w9
     a5c:      	str	w9, [sp, #0x30]
     a60:      	ldr	w9, [sp, #0x34]
     a64:      	subs	w9, w9, w10
     a68:      	mul	w8, w8, w9
     a6c:      	str	w8, [sp, #0x2c]
     a70:      	ldr	w0, [sp, #0x30]
     a74:      	bl	0xcdc <record_event>
     a78:      	ldr	w10, [sp, #0x18]
     a7c:      	ldr	w9, [sp, #0x1c]
     a80:      	ldr	w11, [sp, #0x30]
     a84:      	mov	w8, #0x243f             // =9279
     a88:      	movk	w8, #0x52e, lsl #16
     a8c:      	mul	w8, w8, w11
     a90:      	add	w8, w8, w10
     a94:      	str	w8, [sp, #0x28]
     a98:      	ldr	w8, [sp, #0x28]
     a9c:      	mov	w11, #0x2938            // =10552
     aa0:      	movk	w11, #0x36e6, lsl #16
     aa4:      	add	w8, w8, w11
     aa8:      	subs	w8, w8, w10
     aac:      	str	w8, [sp, #0x28]
     ab0:      	ldr	w8, [sp, #0x28]
     ab4:      	subs	w10, w8, w10
     ab8:      	mov	w8, #0xcbbf             // =52159
     abc:      	movk	w8, #0x3aeb, lsl #16
     ac0:      	mul	w8, w8, w10
     ac4:      	str	w8, [sp, #0x30]
     ac8:      	ldr	w8, [sp, #0x30]
     acc:      	ldur	x10, [x29, #-0x10]
     ad0:      	str	w8, [x10]
     ad4:      	ldur	w10, [x29, #-0x14]
     ad8:      	mov	w8, #0x46b              // =1131
     adc:      	movk	w8, #0xe5f2, lsl #16
     ae0:      	mul	w10, w8, w10
     ae4:      	add	w10, w10, w9
     ae8:      	str	w10, [sp, #0x24]
     aec:      	ldur	w10, [x29, #-0x34]
     af0:      	mul	w8, w8, w10
     af4:      	add	w8, w8, w9
     af8:      	str	w8, [sp, #0x20]
     afc:      	ldr	w8, [sp, #0x24]
     b00:      	ldr	w10, [sp, #0x20]
     b04:      	add	w8, w8, w10
     b08:      	subs	w8, w8, w9
     b0c:      	str	w8, [sp, #0x24]
     b10:      	ldr	w8, [sp, #0x24]
     b14:      	subs	w9, w8, w9
     b18:      	mov	w8, #0x8843             // =34883
     b1c:      	movk	w8, #0x11f0, lsl #16
     b20:      	mul	w8, w8, w9
     b24:      	stur	w8, [x29, #-0x14]
     b28:      	ldur	w0, [x29, #-0x1c]
     b2c:      	bl	0xcdc <record_event>
     b30:      	b	0x95c <region_pipeline+0x144>
     b34:      	ldur	w8, [x29, #-0x14]
     b38:      	stur	w8, [x29, #-0x4]
     b3c:      	b	0xb40 <region_pipeline+0x328>
     b40:      	ldur	w0, [x29, #-0x4]
     b44:      	ldp	x29, x30, [sp, #0x80]
     b48:      	add	sp, sp, #0x90
     b4c:      	ret

0000000000000b50 <region_outputs>:
     b50:      	sub	sp, sp, #0x50
     b54:      	stp	x29, x30, [sp, #0x40]
     b58:      	add	x29, sp, #0x40
     b5c:      	mov	w10, #0x8e7c            // =36476
     b60:      	movk	w10, #0xe59a, lsl #16
     b64:      	mov	w8, #0x5c0b             // =23563
     b68:      	movk	w8, #0xe278, lsl #16
     b6c:      	mov	w9, #0x1fe2             // =8162
     b70:      	movk	w9, #0xe3c4, lsl #16
     b74:      	str	w9, [sp, #0x8]
     b78:      	stur	x0, [x29, #-0x8]
     b7c:      	stur	w1, [x29, #-0xc]
     b80:      	stur	w2, [x29, #-0x10]
     b84:      	ldur	w11, [x29, #-0xc]
     b88:      	mov	w9, #0x4fa3             // =20387
     b8c:      	movk	w9, #0x7ea2, lsl #16
     b90:      	mul	w11, w9, w11
     b94:      	add	w11, w11, w10
     b98:      	stur	w11, [x29, #-0x14]
     b9c:      	ldur	w11, [x29, #-0x10]
     ba0:      	mul	w9, w9, w11
     ba4:      	add	w9, w9, w10
     ba8:      	stur	w9, [x29, #-0x18]
     bac:      	mov	w9, #0xd84f             // =55375
     bb0:      	movk	w9, #0x4e61, lsl #16
     bb4:      	stur	w9, [x29, #-0x1c]
     bb8:      	ldur	w9, [x29, #-0x1c]
     bbc:      	ldur	w11, [x29, #-0x14]
     bc0:      	add	w9, w9, w11
     bc4:      	subs	w9, w9, w10
     bc8:      	str	w9, [sp, #0x20]
     bcc:      	ldr	w11, [sp, #0x20]
     bd0:      	mov	w9, #0x3                // =3
     bd4:      	mul	w9, w9, w11
     bd8:      	mov	w11, #0xe308            // =58120
     bdc:      	movk	w11, #0x34ca, lsl #16
     be0:      	add	w9, w9, w11
     be4:      	ldur	w11, [x29, #-0x18]
     be8:      	add	w9, w9, w11
     bec:      	subs	w9, w9, w10
     bf0:      	stur	w9, [x29, #-0x14]
     bf4:      	ldur	w9, [x29, #-0x14]
     bf8:      	ldur	w11, [x29, #-0x1c]
     bfc:      	subs	w9, w9, w11
     c00:      	add	w9, w9, w10
     c04:      	stur	w9, [x29, #-0x18]
     c08:      	ldur	w9, [x29, #-0x14]
     c0c:      	subs	w9, w9, w10
     c10:      	mul	w9, w8, w9
     c14:      	stur	w9, [x29, #-0xc]
     c18:      	ldur	w9, [x29, #-0x18]
     c1c:      	subs	w9, w9, w10
     c20:      	mul	w9, w8, w9
     c24:      	stur	w9, [x29, #-0x10]
     c28:      	ldur	w9, [x29, #-0x1c]
     c2c:      	subs	w9, w9, w10
     c30:      	mul	w9, w8, w9
     c34:      	str	w9, [sp, #0x1c]
     c38:      	ldr	w9, [sp, #0x20]
     c3c:      	subs	w9, w9, w10
     c40:      	mul	w8, w8, w9
     c44:      	str	w8, [sp, #0x18]
     c48:      	ldur	w0, [x29, #-0xc]
     c4c:      	bl	0xcdc <record_event>
     c50:      	ldr	w9, [sp, #0x8]
     c54:      	ldur	w10, [x29, #-0xc]
     c58:      	mov	w8, #0xef7              // =3831
     c5c:      	movk	w8, #0x3a51, lsl #16
     c60:      	mul	w8, w8, w10
     c64:      	add	w8, w8, w9
     c68:      	str	w8, [sp, #0x14]
     c6c:      	ldr	w8, [sp, #0x14]
     c70:      	mov	w10, #0x88a3            // =34979
     c74:      	movk	w10, #0x7bfb, lsl #16
     c78:      	add	w8, w8, w10
     c7c:      	subs	w8, w8, w9
     c80:      	str	w8, [sp, #0x10]
     c84:      	ldr	w8, [sp, #0x10]
     c88:      	subs	w9, w8, w9
     c8c:      	mov	w8, #0x12c7             // =4807
     c90:      	movk	w8, #0x9b90, lsl #16
     c94:      	mul	w8, w8, w9
     c98:      	str	w8, [sp, #0xc]
     c9c:      	ldr	w8, [sp, #0xc]
     ca0:      	ldur	x9, [x29, #-0x8]
     ca4:      	str	w8, [x9, #0x8]
     ca8:      	ldur	w8, [x29, #-0x10]
     cac:      	ldur	x9, [x29, #-0x8]
     cb0:      	str	w8, [x9]
     cb4:      	ldr	w8, [sp, #0x1c]
     cb8:      	ldur	x9, [x29, #-0x8]
     cbc:      	str	w8, [x9, #0x4]
     cc0:      	ldur	w8, [x29, #-0xc]
     cc4:      	ldur	w9, [x29, #-0x10]
     cc8:      	subs	w8, w8, w9
     ccc:      	cset	w0, eq
     cd0:      	ldp	x29, x30, [sp, #0x40]
     cd4:      	add	sp, sp, #0x50
     cd8:      	ret

0000000000000cdc <record_event>:
     cdc:      	sub	sp, sp, #0x10
     ce0:      	str	w0, [sp, #0xc]
     ce4:      	adrp	x9, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     ce8:      	ldr	w8, [x9, #0x4c]
     cec:      	mov	w10, #0x21              // =33
     cf0:      	mul	w8, w8, w10
     cf4:      	ldr	w10, [sp, #0xc]
     cf8:      	eor	w8, w8, w10
     cfc:      	str	w8, [x9, #0x4c]
     d00:      	add	sp, sp, #0x10
     d04:      	ret

0000000000000d08 <next_value>:
     d08:      	sub	sp, sp, #0x20
     d0c:      	stp	x29, x30, [sp, #0x10]
     d10:      	add	x29, sp, #0x10
     d14:      	stur	w0, [x29, #-0x4]
     d18:      	ldur	w0, [x29, #-0x4]
     d1c:      	bl	0xcdc <record_event>
     d20:      	ldur	w10, [x29, #-0x4]
     d24:      	adrp	x9, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     d28:      	add	x9, x9, #0x50
     d2c:      	ldr	w8, [x9, #0x4]
     d30:      	add	w8, w8, w10
     d34:      	str	w8, [x9, #0x4]
     d38:      	ldur	w8, [x29, #-0x4]
     d3c:      	ldr	w9, [x9, #0x4]
     d40:      	add	w0, w8, w9
     d44:      	ldp	x29, x30, [sp, #0x10]
     d48:      	add	sp, sp, #0x20
     d4c:      	ret

0000000000000d50 <main>:
     d50:      	sub	sp, sp, #0x80
     d54:      	stp	x29, x30, [sp, #0x70]
     d58:      	add	x29, sp, #0x70
     d5c:      	stur	wzr, [x29, #-0x4]
     d60:      	stur	w0, [x29, #-0x8]
     d64:      	stur	x1, [x29, #-0x10]
     d68:      	ldur	w8, [x29, #-0x8]
     d6c:      	subs	w8, w8, #0x3
     d70:      	b.eq	0xd84 <main+0x34>
     d74:      	b	0xd78 <main+0x28>
     d78:      	mov	w8, #0x2                // =2
     d7c:      	stur	w8, [x29, #-0x4]
     d80:      	b	0xf28 <main+0x1d8>
     d84:      	ldur	x8, [x29, #-0x10]
     d88:      	ldr	x0, [x8, #0x8]
     d8c:      	mov	x1, xzr
     d90:      	str	x1, [sp, #0x10]
     d94:      	mov	w2, #0xa                // =10
     d98:      	str	w2, [sp, #0x1c]
     d9c:      	bl	0x670 <strtoul@plt>
     da0:      	ldr	x1, [sp, #0x10]
     da4:      	ldr	w2, [sp, #0x1c]
     da8:      	stur	x0, [x29, #-0x18]
     dac:      	ldur	x8, [x29, #-0x10]
     db0:      	ldr	x0, [x8, #0x10]
     db4:      	bl	0x670 <strtoul@plt>
     db8:      	mov	w8, w0
     dbc:      	stur	w8, [x29, #-0x1c]
     dc0:      	stur	wzr, [x29, #-0x20]
     dc4:      	mov	w0, #0x1                // =1
     dc8:      	sub	x1, x29, #0x30
     dcc:      	bl	0x6a0 <clock_gettime@plt>
     dd0:      	cbz	w0, 0xde4 <main+0x94>
     dd4:      	b	0xdd8 <main+0x88>
     dd8:      	mov	w8, #0x2                // =2
     ddc:      	stur	w8, [x29, #-0x4]
     de0:      	b	0xf28 <main+0x1d8>
     de4:      	str	xzr, [sp, #0x28]
     de8:      	b	0xdec <main+0x9c>
     dec:      	ldr	x8, [sp, #0x28]
     df0:      	ldur	x9, [x29, #-0x18]
     df4:      	subs	x8, x8, x9
     df8:      	b.hs	0xe9c <main+0x14c>
     dfc:      	b	0xe00 <main+0xb0>
     e00:      	ldur	w9, [x29, #-0x1c]
     e04:      	ldur	w8, [x29, #-0x1c]
     e08:      	eor	w8, w8, w9, lsl #13
     e0c:      	stur	w8, [x29, #-0x1c]
     e10:      	ldur	w9, [x29, #-0x1c]
     e14:      	ldur	w8, [x29, #-0x1c]
     e18:      	eor	w8, w8, w9, lsr #17
     e1c:      	stur	w8, [x29, #-0x1c]
     e20:      	ldur	w9, [x29, #-0x1c]
     e24:      	ldur	w8, [x29, #-0x1c]
     e28:      	eor	w8, w8, w9, lsl #5
     e2c:      	stur	w8, [x29, #-0x1c]
     e30:      	ldur	w1, [x29, #-0x1c]
     e34:      	ldr	x8, [sp, #0x28]
     e38:      	mov	x10, #0xa               // =10
     e3c:      	udiv	x9, x8, x10
     e40:      	mul	x9, x9, x10
     e44:      	subs	x8, x8, x9
     e48:      	subs	w2, w8, #0x1
     e4c:      	adrp	x0, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     e50:      	add	x0, x0, #0x50
     e54:      	str	x0, [sp, #0x8]
     e58:      	bl	0x818 <region_pipeline>
     e5c:      	mov	w9, w0
     e60:      	ldr	x0, [sp, #0x8]
     e64:      	ldur	w8, [x29, #-0x20]
     e68:      	add	w8, w8, w9
     e6c:      	stur	w8, [x29, #-0x20]
     e70:      	ldur	w1, [x29, #-0x1c]
     e74:      	ldur	w2, [x29, #-0x20]
     e78:      	bl	0xb50 <region_outputs>
     e7c:      	ldur	w8, [x29, #-0x20]
     e80:      	add	w8, w8, w0
     e84:      	stur	w8, [x29, #-0x20]
     e88:      	b	0xe8c <main+0x13c>
     e8c:      	ldr	x8, [sp, #0x28]
     e90:      	add	x8, x8, #0x1
     e94:      	str	x8, [sp, #0x28]
     e98:      	b	0xdec <main+0x9c>
     e9c:      	mov	w0, #0x1                // =1
     ea0:      	add	x1, sp, #0x30
     ea4:      	bl	0x6a0 <clock_gettime@plt>
     ea8:      	cbz	w0, 0xebc <main+0x16c>
     eac:      	b	0xeb0 <main+0x160>
     eb0:      	mov	w8, #0x2                // =2
     eb4:      	stur	w8, [x29, #-0x4]
     eb8:      	b	0xf28 <main+0x1d8>
     ebc:      	ldr	x8, [sp, #0x30]
     ec0:      	ldur	x9, [x29, #-0x30]
     ec4:      	subs	x8, x8, x9
     ec8:      	scvtf	d2, x8
     ecc:      	ldr	x8, [sp, #0x38]
     ed0:      	ldur	x9, [x29, #-0x28]
     ed4:      	subs	x8, x8, x9
     ed8:      	scvtf	d0, x8
     edc:      	adrp	x8, 0x0 <strtoul@GLIBC_2.17>
     ee0:      	ldr	d1, [x8, #0xf58]
     ee4:      	fmadd	d0, d0, d1, d2
     ee8:      	str	d0, [sp, #0x20]
     eec:      	ldr	d0, [sp, #0x20]
     ef0:      	ldur	w1, [x29, #-0x20]
     ef4:      	adrp	x9, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     ef8:      	adrp	x8, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     efc:      	add	x8, x8, #0x50
     f00:      	ldr	w2, [x9, #0x50]
     f04:      	ldr	w3, [x8, #0x4]
     f08:      	ldr	w4, [x8, #0x8]
     f0c:      	adrp	x8, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     f10:      	ldr	w5, [x8, #0x4c]
     f14:      	adrp	x0, 0x0 <strtoul@GLIBC_2.17>
     f18:      	add	x0, x0, #0xf60
     f1c:      	bl	0x6d0 <printf@plt>
     f20:      	stur	wzr, [x29, #-0x4]
     f24:      	b	0xf28 <main+0x1d8>
     f28:      	ldur	w0, [x29, #-0x4]
     f2c:      	ldp	x29, x30, [sp, #0x70]
     f30:      	add	sp, sp, #0x80
     f34:      	ret

Disassembly of section .fini:

0000000000000f38 <_fini>:
     f38:      	nop
     f3c:      	stp	x29, x30, [sp, #-0x10]!
     f40:      	mov	x29, sp
     f44:      	ldp	x29, x30, [sp], #0x10
     f48:      	ret
