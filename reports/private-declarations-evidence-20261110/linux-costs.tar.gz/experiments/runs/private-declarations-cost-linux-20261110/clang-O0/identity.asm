
/work/experiments/runs/private-declarations-cost-linux-20261110/clang-O0/identity:	file format elf64-littleaarch64

Disassembly of section .init:

0000000000000638 <_init>:
     638:      	nop
     63c:      	stp	x29, x30, [sp, #-0x10]!
     640:      	mov	x29, sp
     644:      	bl	0x734 <call_weak_fn>
     648:      	ldp	x29, x30, [sp], #0x10
     64c:      	ret

Disassembly of section .plt:

0000000000000650 <.plt>:
     650:      	stp	x16, x30, [sp, #-0x10]!
     654:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e0cc>
     658:      	ldr	x17, [x16, #0xff8]
     65c:      	add	x16, x16, #0xff8
     660:      	br	x17
     664:      	nop
     668:      	nop
     66c:      	nop

0000000000000670 <strtoul@plt>:
     670:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     674:      	ldr	x17, [x16]
     678:      	add	x16, x16, #0x0
     67c:      	br	x17

0000000000000680 <__libc_start_main@plt>:
     680:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     684:      	ldr	x17, [x16, #0x8]
     688:      	add	x16, x16, #0x8
     68c:      	br	x17

0000000000000690 <__cxa_finalize@plt>:
     690:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     694:      	ldr	x17, [x16, #0x10]
     698:      	add	x16, x16, #0x10
     69c:      	br	x17

00000000000006a0 <clock_gettime@plt>:
     6a0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6a4:      	ldr	x17, [x16, #0x18]
     6a8:      	add	x16, x16, #0x18
     6ac:      	br	x17

00000000000006b0 <__gmon_start__@plt>:
     6b0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6b4:      	ldr	x17, [x16, #0x20]
     6b8:      	add	x16, x16, #0x20
     6bc:      	br	x17

00000000000006c0 <abort@plt>:
     6c0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6c4:      	ldr	x17, [x16, #0x28]
     6c8:      	add	x16, x16, #0x28
     6cc:      	br	x17

00000000000006d0 <printf@plt>:
     6d0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6d4:      	ldr	x17, [x16, #0x30]
     6d8:      	add	x16, x16, #0x30
     6dc:      	br	x17

Disassembly of section .text:

0000000000000700 <_start>:
     700:      	nop
     704:      	mov	x29, #0x0               // =0
     708:      	mov	x30, #0x0               // =0
     70c:      	mov	x5, x0
     710:      	ldr	x1, [sp]
     714:      	add	x2, sp, #0x8
     718:      	mov	x6, sp
     71c:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e0cc>
     720:      	ldr	x0, [x0, #0xfd8]
     724:      	mov	x3, #0x0                // =0
     728:      	mov	x4, #0x0                // =0
     72c:      	bl	0x680 <__libc_start_main@plt>
     730:      	bl	0x6c0 <abort@plt>

0000000000000734 <call_weak_fn>:
     734:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e0cc>
     738:      	ldr	x0, [x0, #0xfd0]
     73c:      	cbz	x0, 0x744 <call_weak_fn+0x10>
     740:      	b	0x6b0 <__gmon_start__@plt>
     744:      	ret
     748:      	nop
     74c:      	nop

0000000000000750 <deregister_tm_clones>:
     750:      	adrp	x0, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     754:      	add	x0, x0, #0x48
     758:      	adrp	x1, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     75c:      	add	x1, x1, #0x48
     760:      	cmp	x1, x0
     764:      	b.eq	0x77c <deregister_tm_clones+0x2c>
     768:      	adrp	x1, 0x1f000 <__FRAME_END__+0x1e0cc>
     76c:      	ldr	x1, [x1, #0xfc0]
     770:      	cbz	x1, 0x77c <deregister_tm_clones+0x2c>
     774:      	mov	x16, x1
     778:      	br	x16
     77c:      	ret

0000000000000780 <register_tm_clones>:
     780:      	adrp	x0, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     784:      	add	x0, x0, #0x48
     788:      	adrp	x1, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     78c:      	add	x1, x1, #0x48
     790:      	sub	x1, x1, x0
     794:      	lsr	x2, x1, #63
     798:      	add	x1, x2, x1, asr #3
     79c:      	asr	x1, x1, #1
     7a0:      	cbz	x1, 0x7b8 <register_tm_clones+0x38>
     7a4:      	adrp	x2, 0x1f000 <__FRAME_END__+0x1e0cc>
     7a8:      	ldr	x2, [x2, #0xfe0]
     7ac:      	cbz	x2, 0x7b8 <register_tm_clones+0x38>
     7b0:      	mov	x16, x2
     7b4:      	br	x16
     7b8:      	ret
     7bc:      	nop

00000000000007c0 <__do_global_dtors_aux>:
     7c0:      	paciasp
     7c4:      	stp	x29, x30, [sp, #-0x20]!
     7c8:      	mov	x29, sp
     7cc:      	str	x19, [sp, #0x10]
     7d0:      	adrp	x19, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     7d4:      	ldrb	w0, [x19, #0x48]
     7d8:      	tbnz	w0, #0x0, 0x800 <__do_global_dtors_aux+0x40>
     7dc:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e0cc>
     7e0:      	ldr	x0, [x0, #0xfc8]
     7e4:      	cbz	x0, 0x7f4 <__do_global_dtors_aux+0x34>
     7e8:      	adrp	x0, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     7ec:      	ldr	x0, [x0, #0x40]
     7f0:      	bl	0x690 <__cxa_finalize@plt>
     7f4:      	bl	0x750 <deregister_tm_clones>
     7f8:      	mov	w0, #0x1                // =1
     7fc:      	strb	w0, [x19, #0x48]
     800:      	ldr	x19, [sp, #0x10]
     804:      	ldp	x29, x30, [sp], #0x20
     808:      	autiasp
     80c:      	ret

0000000000000810 <frame_dummy>:
     810:      	bti	c
     814:      	b	0x780 <register_tm_clones>

0000000000000818 <region_pipeline>:
     818:      	sub	sp, sp, #0x70
     81c:      	stp	x29, x30, [sp, #0x60]
     820:      	add	x29, sp, #0x60
     824:      	stur	x0, [x29, #-0x10]
     828:      	stur	w1, [x29, #-0x14]
     82c:      	stur	w2, [x29, #-0x18]
     830:      	ldur	x8, [x29, #-0x10]
     834:      	ldr	w8, [x8]
     838:      	stur	w8, [x29, #-0x1c]
     83c:      	ldur	w8, [x29, #-0x14]
     840:      	stur	w8, [x29, #-0x20]
     844:      	ldur	w8, [x29, #-0x1c]
     848:      	stur	w8, [x29, #-0x24]
     84c:      	ldur	w8, [x29, #-0x20]
     850:      	ldur	w9, [x29, #-0x24]
     854:      	add	w8, w8, w9
     858:      	stur	w8, [x29, #-0x28]
     85c:      	ldur	w9, [x29, #-0x28]
     860:      	mov	w8, #0x3                // =3
     864:      	mul	w8, w8, w9
     868:      	add	w8, w8, #0xb
     86c:      	stur	w8, [x29, #-0x2c]
     870:      	ldur	w8, [x29, #-0x2c]
     874:      	ldur	w9, [x29, #-0x24]
     878:      	subs	w8, w8, w9
     87c:      	stur	w8, [x29, #-0x20]
     880:      	ldur	w8, [x29, #-0x20]
     884:      	stur	w8, [x29, #-0x14]
     888:      	ldur	w8, [x29, #-0x28]
     88c:      	str	w8, [sp, #0x30]
     890:      	ldur	w8, [x29, #-0x2c]
     894:      	str	w8, [sp, #0x2c]
     898:      	ldr	w0, [sp, #0x30]
     89c:      	bl	0xad4 <record_event>
     8a0:      	ldur	w8, [x29, #-0x18]
     8a4:      	tbz	w8, #0x1f, 0x8b8 <region_pipeline+0xa0>
     8a8:      	b	0x8ac <region_pipeline+0x94>
     8ac:      	ldur	w8, [x29, #-0x14]
     8b0:      	stur	w8, [x29, #-0x4]
     8b4:      	b	0x9d8 <region_pipeline+0x1c0>
     8b8:      	b	0x8bc <region_pipeline+0xa4>
     8bc:      	ldur	w8, [x29, #-0x18]
     8c0:      	subs	w9, w8, #0x1
     8c4:      	stur	w9, [x29, #-0x18]
     8c8:      	subs	w8, w8, #0x0
     8cc:      	b.le	0x9cc <region_pipeline+0x1b4>
     8d0:      	b	0x8d4 <region_pipeline+0xbc>
     8d4:      	ldur	w0, [x29, #-0x14]
     8d8:      	bl	0xb00 <next_value>
     8dc:      	stur	w0, [x29, #-0x1c]
     8e0:      	ldur	w8, [x29, #-0x14]
     8e4:      	str	w8, [sp, #0x28]
     8e8:      	ldur	w8, [x29, #-0x1c]
     8ec:      	str	w8, [sp, #0x24]
     8f0:      	ldr	w8, [sp, #0x2c]
     8f4:      	str	w8, [sp, #0x20]
     8f8:      	ldr	w8, [sp, #0x30]
     8fc:      	str	w8, [sp, #0x1c]
     900:      	ldr	w8, [sp, #0x28]
     904:      	ldr	w9, [sp, #0x24]
     908:      	add	w8, w8, w9
     90c:      	str	w8, [sp, #0x28]
     910:      	ldr	w8, [sp, #0x20]
     914:      	ldr	w10, [sp, #0x24]
     918:      	mov	w9, #0x5                // =5
     91c:      	mul	w9, w9, w10
     920:      	add	w8, w8, w9
     924:      	str	w8, [sp, #0x18]
     928:      	ldr	w8, [sp, #0x18]
     92c:      	ldr	w9, [sp, #0x24]
     930:      	subs	w8, w8, w9
     934:      	str	w8, [sp, #0x14]
     938:      	ldr	w8, [sp, #0x14]
     93c:      	ldr	w9, [sp, #0x1c]
     940:      	add	w8, w8, w9
     944:      	str	w8, [sp, #0x20]
     948:      	ldr	w8, [sp, #0x28]
     94c:      	stur	w8, [x29, #-0x14]
     950:      	ldr	w8, [sp, #0x20]
     954:      	str	w8, [sp, #0x2c]
     958:      	ldr	w8, [sp, #0x18]
     95c:      	str	w8, [sp, #0x10]
     960:      	ldr	w8, [sp, #0x14]
     964:      	str	w8, [sp, #0xc]
     968:      	ldr	w0, [sp, #0x10]
     96c:      	bl	0xad4 <record_event>
     970:      	ldr	w8, [sp, #0x10]
     974:      	str	w8, [sp, #0x8]
     978:      	ldr	w8, [sp, #0x8]
     97c:      	add	w8, w8, #0x7
     980:      	str	w8, [sp, #0x8]
     984:      	ldr	w8, [sp, #0x8]
     988:      	str	w8, [sp, #0x10]
     98c:      	ldr	w8, [sp, #0x10]
     990:      	ldur	x9, [x29, #-0x10]
     994:      	str	w8, [x9]
     998:      	ldur	w8, [x29, #-0x14]
     99c:      	str	w8, [sp, #0x4]
     9a0:      	ldr	w8, [sp, #0x2c]
     9a4:      	str	w8, [sp]
     9a8:      	ldr	w8, [sp, #0x4]
     9ac:      	ldr	w9, [sp]
     9b0:      	add	w8, w8, w9
     9b4:      	str	w8, [sp, #0x4]
     9b8:      	ldr	w8, [sp, #0x4]
     9bc:      	stur	w8, [x29, #-0x14]
     9c0:      	ldur	w0, [x29, #-0x1c]
     9c4:      	bl	0xad4 <record_event>
     9c8:      	b	0x8bc <region_pipeline+0xa4>
     9cc:      	ldur	w8, [x29, #-0x14]
     9d0:      	stur	w8, [x29, #-0x4]
     9d4:      	b	0x9d8 <region_pipeline+0x1c0>
     9d8:      	ldur	w0, [x29, #-0x4]
     9dc:      	ldp	x29, x30, [sp, #0x60]
     9e0:      	add	sp, sp, #0x70
     9e4:      	ret

00000000000009e8 <region_outputs>:
     9e8:      	sub	sp, sp, #0x50
     9ec:      	stp	x29, x30, [sp, #0x40]
     9f0:      	add	x29, sp, #0x40
     9f4:      	stur	x0, [x29, #-0x8]
     9f8:      	stur	w1, [x29, #-0xc]
     9fc:      	stur	w2, [x29, #-0x10]
     a00:      	ldur	w8, [x29, #-0xc]
     a04:      	stur	w8, [x29, #-0x14]
     a08:      	ldur	w8, [x29, #-0x10]
     a0c:      	stur	w8, [x29, #-0x18]
     a10:      	mov	w8, #0x11               // =17
     a14:      	stur	w8, [x29, #-0x1c]
     a18:      	ldur	w8, [x29, #-0x1c]
     a1c:      	ldur	w9, [x29, #-0x14]
     a20:      	add	w8, w8, w9
     a24:      	str	w8, [sp, #0x20]
     a28:      	ldr	w9, [sp, #0x20]
     a2c:      	mov	w8, #0x3                // =3
     a30:      	mul	w8, w8, w9
     a34:      	ldur	w9, [x29, #-0x18]
     a38:      	add	w8, w8, w9
     a3c:      	stur	w8, [x29, #-0x14]
     a40:      	ldur	w8, [x29, #-0x14]
     a44:      	ldur	w9, [x29, #-0x1c]
     a48:      	subs	w8, w8, w9
     a4c:      	stur	w8, [x29, #-0x18]
     a50:      	ldur	w8, [x29, #-0x14]
     a54:      	stur	w8, [x29, #-0xc]
     a58:      	ldur	w8, [x29, #-0x18]
     a5c:      	stur	w8, [x29, #-0x10]
     a60:      	ldur	w8, [x29, #-0x1c]
     a64:      	str	w8, [sp, #0x1c]
     a68:      	ldr	w8, [sp, #0x20]
     a6c:      	str	w8, [sp, #0x18]
     a70:      	ldur	w0, [x29, #-0xc]
     a74:      	bl	0xad4 <record_event>
     a78:      	ldur	w8, [x29, #-0xc]
     a7c:      	str	w8, [sp, #0x14]
     a80:      	ldr	w8, [sp, #0x14]
     a84:      	add	w8, w8, #0x7
     a88:      	str	w8, [sp, #0x10]
     a8c:      	ldr	w8, [sp, #0x10]
     a90:      	str	w8, [sp, #0xc]
     a94:      	ldr	w8, [sp, #0xc]
     a98:      	ldur	x9, [x29, #-0x8]
     a9c:      	str	w8, [x9, #0x8]
     aa0:      	ldur	w8, [x29, #-0x10]
     aa4:      	ldur	x9, [x29, #-0x8]
     aa8:      	str	w8, [x9]
     aac:      	ldr	w8, [sp, #0x1c]
     ab0:      	ldur	x9, [x29, #-0x8]
     ab4:      	str	w8, [x9, #0x4]
     ab8:      	ldur	w8, [x29, #-0xc]
     abc:      	ldur	w9, [x29, #-0x10]
     ac0:      	subs	w8, w8, w9
     ac4:      	cset	w0, eq
     ac8:      	ldp	x29, x30, [sp, #0x40]
     acc:      	add	sp, sp, #0x50
     ad0:      	ret

0000000000000ad4 <record_event>:
     ad4:      	sub	sp, sp, #0x10
     ad8:      	str	w0, [sp, #0xc]
     adc:      	adrp	x9, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     ae0:      	ldr	w8, [x9, #0x4c]
     ae4:      	mov	w10, #0x21              // =33
     ae8:      	mul	w8, w8, w10
     aec:      	ldr	w10, [sp, #0xc]
     af0:      	eor	w8, w8, w10
     af4:      	str	w8, [x9, #0x4c]
     af8:      	add	sp, sp, #0x10
     afc:      	ret

0000000000000b00 <next_value>:
     b00:      	sub	sp, sp, #0x20
     b04:      	stp	x29, x30, [sp, #0x10]
     b08:      	add	x29, sp, #0x10
     b0c:      	stur	w0, [x29, #-0x4]
     b10:      	ldur	w0, [x29, #-0x4]
     b14:      	bl	0xad4 <record_event>
     b18:      	ldur	w10, [x29, #-0x4]
     b1c:      	adrp	x9, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     b20:      	add	x9, x9, #0x50
     b24:      	ldr	w8, [x9, #0x4]
     b28:      	add	w8, w8, w10
     b2c:      	str	w8, [x9, #0x4]
     b30:      	ldur	w8, [x29, #-0x4]
     b34:      	ldr	w9, [x9, #0x4]
     b38:      	add	w0, w8, w9
     b3c:      	ldp	x29, x30, [sp, #0x10]
     b40:      	add	sp, sp, #0x20
     b44:      	ret

0000000000000b48 <main>:
     b48:      	sub	sp, sp, #0x80
     b4c:      	stp	x29, x30, [sp, #0x70]
     b50:      	add	x29, sp, #0x70
     b54:      	stur	wzr, [x29, #-0x4]
     b58:      	stur	w0, [x29, #-0x8]
     b5c:      	stur	x1, [x29, #-0x10]
     b60:      	ldur	w8, [x29, #-0x8]
     b64:      	subs	w8, w8, #0x3
     b68:      	b.eq	0xb7c <main+0x34>
     b6c:      	b	0xb70 <main+0x28>
     b70:      	mov	w8, #0x2                // =2
     b74:      	stur	w8, [x29, #-0x4]
     b78:      	b	0xd20 <main+0x1d8>
     b7c:      	ldur	x8, [x29, #-0x10]
     b80:      	ldr	x0, [x8, #0x8]
     b84:      	mov	x1, xzr
     b88:      	str	x1, [sp, #0x10]
     b8c:      	mov	w2, #0xa                // =10
     b90:      	str	w2, [sp, #0x1c]
     b94:      	bl	0x670 <strtoul@plt>
     b98:      	ldr	x1, [sp, #0x10]
     b9c:      	ldr	w2, [sp, #0x1c]
     ba0:      	stur	x0, [x29, #-0x18]
     ba4:      	ldur	x8, [x29, #-0x10]
     ba8:      	ldr	x0, [x8, #0x10]
     bac:      	bl	0x670 <strtoul@plt>
     bb0:      	mov	w8, w0
     bb4:      	stur	w8, [x29, #-0x1c]
     bb8:      	stur	wzr, [x29, #-0x20]
     bbc:      	mov	w0, #0x1                // =1
     bc0:      	sub	x1, x29, #0x30
     bc4:      	bl	0x6a0 <clock_gettime@plt>
     bc8:      	cbz	w0, 0xbdc <main+0x94>
     bcc:      	b	0xbd0 <main+0x88>
     bd0:      	mov	w8, #0x2                // =2
     bd4:      	stur	w8, [x29, #-0x4]
     bd8:      	b	0xd20 <main+0x1d8>
     bdc:      	str	xzr, [sp, #0x28]
     be0:      	b	0xbe4 <main+0x9c>
     be4:      	ldr	x8, [sp, #0x28]
     be8:      	ldur	x9, [x29, #-0x18]
     bec:      	subs	x8, x8, x9
     bf0:      	b.hs	0xc94 <main+0x14c>
     bf4:      	b	0xbf8 <main+0xb0>
     bf8:      	ldur	w9, [x29, #-0x1c]
     bfc:      	ldur	w8, [x29, #-0x1c]
     c00:      	eor	w8, w8, w9, lsl #13
     c04:      	stur	w8, [x29, #-0x1c]
     c08:      	ldur	w9, [x29, #-0x1c]
     c0c:      	ldur	w8, [x29, #-0x1c]
     c10:      	eor	w8, w8, w9, lsr #17
     c14:      	stur	w8, [x29, #-0x1c]
     c18:      	ldur	w9, [x29, #-0x1c]
     c1c:      	ldur	w8, [x29, #-0x1c]
     c20:      	eor	w8, w8, w9, lsl #5
     c24:      	stur	w8, [x29, #-0x1c]
     c28:      	ldur	w1, [x29, #-0x1c]
     c2c:      	ldr	x8, [sp, #0x28]
     c30:      	mov	x10, #0xa               // =10
     c34:      	udiv	x9, x8, x10
     c38:      	mul	x9, x9, x10
     c3c:      	subs	x8, x8, x9
     c40:      	subs	w2, w8, #0x1
     c44:      	adrp	x0, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     c48:      	add	x0, x0, #0x50
     c4c:      	str	x0, [sp, #0x8]
     c50:      	bl	0x818 <region_pipeline>
     c54:      	mov	w9, w0
     c58:      	ldr	x0, [sp, #0x8]
     c5c:      	ldur	w8, [x29, #-0x20]
     c60:      	add	w8, w8, w9
     c64:      	stur	w8, [x29, #-0x20]
     c68:      	ldur	w1, [x29, #-0x1c]
     c6c:      	ldur	w2, [x29, #-0x20]
     c70:      	bl	0x9e8 <region_outputs>
     c74:      	ldur	w8, [x29, #-0x20]
     c78:      	add	w8, w8, w0
     c7c:      	stur	w8, [x29, #-0x20]
     c80:      	b	0xc84 <main+0x13c>
     c84:      	ldr	x8, [sp, #0x28]
     c88:      	add	x8, x8, #0x1
     c8c:      	str	x8, [sp, #0x28]
     c90:      	b	0xbe4 <main+0x9c>
     c94:      	mov	w0, #0x1                // =1
     c98:      	add	x1, sp, #0x30
     c9c:      	bl	0x6a0 <clock_gettime@plt>
     ca0:      	cbz	w0, 0xcb4 <main+0x16c>
     ca4:      	b	0xca8 <main+0x160>
     ca8:      	mov	w8, #0x2                // =2
     cac:      	stur	w8, [x29, #-0x4]
     cb0:      	b	0xd20 <main+0x1d8>
     cb4:      	ldr	x8, [sp, #0x30]
     cb8:      	ldur	x9, [x29, #-0x30]
     cbc:      	subs	x8, x8, x9
     cc0:      	scvtf	d2, x8
     cc4:      	ldr	x8, [sp, #0x38]
     cc8:      	ldur	x9, [x29, #-0x28]
     ccc:      	subs	x8, x8, x9
     cd0:      	scvtf	d0, x8
     cd4:      	adrp	x8, 0x0 <strtoul@GLIBC_2.17>
     cd8:      	ldr	d1, [x8, #0xd50]
     cdc:      	fmadd	d0, d0, d1, d2
     ce0:      	str	d0, [sp, #0x20]
     ce4:      	ldr	d0, [sp, #0x20]
     ce8:      	ldur	w1, [x29, #-0x20]
     cec:      	adrp	x9, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     cf0:      	adrp	x8, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     cf4:      	add	x8, x8, #0x50
     cf8:      	ldr	w2, [x9, #0x50]
     cfc:      	ldr	w3, [x8, #0x4]
     d00:      	ldr	w4, [x8, #0x8]
     d04:      	adrp	x8, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     d08:      	ldr	w5, [x8, #0x4c]
     d0c:      	adrp	x0, 0x0 <strtoul@GLIBC_2.17>
     d10:      	add	x0, x0, #0xd58
     d14:      	bl	0x6d0 <printf@plt>
     d18:      	stur	wzr, [x29, #-0x4]
     d1c:      	b	0xd20 <main+0x1d8>
     d20:      	ldur	w0, [x29, #-0x4]
     d24:      	ldp	x29, x30, [sp, #0x70]
     d28:      	add	sp, sp, #0x80
     d2c:      	ret

Disassembly of section .fini:

0000000000000d30 <_fini>:
     d30:      	nop
     d34:      	stp	x29, x30, [sp, #-0x10]!
     d38:      	mov	x29, sp
     d3c:      	ldp	x29, x30, [sp], #0x10
     d40:      	ret
