
/work/experiments/runs/private-declarations-cost-linux-20261110/gcc-O3/affine:	file format elf64-littleaarch64

Disassembly of section .init:

00000000000006f8 <_init>:
     6f8:      	nop
     6fc:      	stp	x29, x30, [sp, #-0x10]!
     700:      	mov	x29, sp
     704:      	bl	0x9b4 <call_weak_fn>
     708:      	ldp	x29, x30, [sp], #0x10
     70c:      	ret

Disassembly of section .plt:

0000000000000710 <.plt>:
     710:      	stp	x16, x30, [sp, #-0x10]!
     714:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e108>
     718:      	ldr	x17, [x16, #0xf80]
     71c:      	add	x16, x16, #0xf80
     720:      	br	x17
     724:      	nop
     728:      	nop
     72c:      	nop

0000000000000730 <strtoul@plt>:
     730:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e108>
     734:      	ldr	x17, [x16, #0xf88]
     738:      	add	x16, x16, #0xf88
     73c:      	br	x17

0000000000000740 <__libc_start_main@plt>:
     740:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e108>
     744:      	ldr	x17, [x16, #0xf90]
     748:      	add	x16, x16, #0xf90
     74c:      	br	x17

0000000000000750 <__cxa_finalize@plt>:
     750:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e108>
     754:      	ldr	x17, [x16, #0xf98]
     758:      	add	x16, x16, #0xf98
     75c:      	br	x17

0000000000000760 <clock_gettime@plt>:
     760:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e108>
     764:      	ldr	x17, [x16, #0xfa0]
     768:      	add	x16, x16, #0xfa0
     76c:      	br	x17

0000000000000770 <__printf_chk@plt>:
     770:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e108>
     774:      	ldr	x17, [x16, #0xfa8]
     778:      	add	x16, x16, #0xfa8
     77c:      	br	x17

0000000000000780 <__stack_chk_fail@plt>:
     780:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e108>
     784:      	ldr	x17, [x16, #0xfb0]
     788:      	add	x16, x16, #0xfb0
     78c:      	br	x17

0000000000000790 <__gmon_start__@plt>:
     790:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e108>
     794:      	ldr	x17, [x16, #0xfb8]
     798:      	add	x16, x16, #0xfb8
     79c:      	br	x17

00000000000007a0 <abort@plt>:
     7a0:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e108>
     7a4:      	ldr	x17, [x16, #0xfc0]
     7a8:      	add	x16, x16, #0xfc0
     7ac:      	br	x17

Disassembly of section .text:

00000000000007c0 <main>:
     7c0:      	sub	sp, sp, #0x70
     7c4:      	adrp	x2, 0x1f000 <__FRAME_END__+0x1e108>
     7c8:      	ldr	x2, [x2, #0xfe8]
     7cc:      	stp	x29, x30, [sp, #0x30]
     7d0:      	add	x29, sp, #0x30
     7d4:      	str	x19, [sp, #0x40]
     7d8:      	mov	x19, x1
     7dc:      	ldr	x1, [x2]
     7e0:      	str	x1, [sp, #0x28]
     7e4:      	mov	x1, #0x0                // =0
     7e8:      	cmp	w0, #0x3
     7ec:      	b.eq	0x824 <main+0x64>
     7f0:      	mov	w19, #0x2               // =2
     7f4:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e108>
     7f8:      	ldr	x0, [x0, #0xfe8]
     7fc:      	ldr	x2, [sp, #0x28]
     800:      	ldr	x1, [x0]
     804:      	subs	x2, x2, x1
     808:      	mov	x1, #0x0                // =0
     80c:      	b.ne	0x970 <main+0x1b0>
     810:      	ldp	x29, x30, [sp, #0x30]
     814:      	mov	w0, w19
     818:      	ldr	x19, [sp, #0x40]
     81c:      	add	sp, sp, #0x70
     820:      	ret
     824:      	ldr	x0, [x19, #0x8]
     828:      	mov	w2, #0xa                // =10
     82c:      	mov	x1, #0x0                // =0
     830:      	str	x21, [sp, #0x48]
     834:      	bl	0x730 <strtoul@plt>
     838:      	mov	x21, x0
     83c:      	ldr	x0, [x19, #0x10]
     840:      	mov	w2, #0xa                // =10
     844:      	mov	x1, #0x0                // =0
     848:      	bl	0x730 <strtoul@plt>
     84c:      	mov	x19, x0
     850:      	add	x1, sp, #0x8
     854:      	mov	w0, #0x1                // =1
     858:      	bl	0x760 <clock_gettime@plt>
     85c:      	cbnz	w0, 0x960 <main+0x1a0>
     860:      	stp	x24, x25, [sp, #0x60]
     864:      	cbz	x21, 0x968 <main+0x1a8>
     868:      	stp	x22, x23, [sp, #0x50]
     86c:      	adrp	x22, 0x20000 <data_start>
     870:      	add	x22, x22, #0x18
     874:      	mov	x23, #-0x3333333333333334 // =-3689348814741910324
     878:      	add	x22, x22, #0x8
     87c:      	mov	x24, #0x0               // =0
     880:      	mov	w25, #0x0               // =0
     884:      	movk	x23, #0xcccd
     888:      	umulh	x1, x24, x23
     88c:      	eor	w19, w19, w19, lsl #13
     890:      	mov	x0, x22
     894:      	eor	w19, w19, w19, lsr #17
     898:      	lsr	x1, x1, #3
     89c:      	eor	w19, w19, w19, lsl #5
     8a0:      	add	x2, x1, x1, lsl #2
     8a4:      	mov	w1, w19
     8a8:      	sub	x2, x24, x2, lsl #1
     8ac:      	add	x24, x24, #0x1
     8b0:      	sub	w2, w2, #0x1
     8b4:      	bl	0xaa0 <region_pipeline>
     8b8:      	add	w25, w0, w25
     8bc:      	mov	w1, w19
     8c0:      	mov	w2, w25
     8c4:      	mov	x0, x22
     8c8:      	bl	0xc10 <region_outputs>
     8cc:      	add	w25, w0, w25
     8d0:      	cmp	x21, x24
     8d4:      	b.ne	0x888 <main+0xc8>
     8d8:      	ldp	x22, x23, [sp, #0x50]
     8dc:      	add	x1, sp, #0x18
     8e0:      	mov	w0, #0x1                // =1
     8e4:      	bl	0x760 <clock_gettime@plt>
     8e8:      	mov	w19, w0
     8ec:      	cbnz	w0, 0x954 <main+0x194>
     8f0:      	ldp	x4, x1, [sp, #0x8]
     8f4:      	adrp	x0, 0x0 <strtoul@GLIBC_2.17>
     8f8:      	adrp	x3, 0x20000 <data_start>
     8fc:      	add	x2, x3, #0x18
     900:      	ldr	d1, [x0, #0xd10]
     904:      	add	x5, x2, #0x8
     908:      	ldr	x0, [sp, #0x20]
     90c:      	ldr	w6, [x3, #0x18]
     910:      	sub	x0, x0, x1
     914:      	ldr	w3, [x2, #0x8]
     918:      	ldr	x1, [sp, #0x18]
     91c:      	scvtf	d0, x0
     920:      	mov	w2, w25
     924:      	sub	x0, x1, x4
     928:      	adrp	x1, 0x0 <strtoul@GLIBC_2.17>
     92c:      	ldp	w4, w5, [x5, #0x4]
     930:      	fmul	d0, d0, d1
     934:      	scvtf	d1, x0
     938:      	add	x1, x1, #0xcf8
     93c:      	mov	w0, #0x2                // =2
     940:      	fadd	d0, d0, d1
     944:      	bl	0x770 <__printf_chk@plt>
     948:      	ldr	x21, [sp, #0x48]
     94c:      	ldp	x24, x25, [sp, #0x60]
     950:      	b	0x7f4 <main+0x34>
     954:      	ldr	x21, [sp, #0x48]
     958:      	ldp	x24, x25, [sp, #0x60]
     95c:      	b	0x7f0 <main+0x30>
     960:      	ldr	x21, [sp, #0x48]
     964:      	b	0x7f0 <main+0x30>
     968:      	mov	w25, #0x0               // =0
     96c:      	b	0x8dc <main+0x11c>
     970:      	stp	x21, x22, [sp, #0x48]
     974:      	stp	x23, x24, [sp, #0x58]
     978:      	str	x25, [sp, #0x68]
     97c:      	bl	0x780 <__stack_chk_fail@plt>

0000000000000980 <_start>:
     980:      	nop
     984:      	mov	x29, #0x0               // =0
     988:      	mov	x30, #0x0               // =0
     98c:      	mov	x5, x0
     990:      	ldr	x1, [sp]
     994:      	add	x2, sp, #0x8
     998:      	mov	x6, sp
     99c:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e108>
     9a0:      	ldr	x0, [x0, #0xff0]
     9a4:      	mov	x3, #0x0                // =0
     9a8:      	mov	x4, #0x0                // =0
     9ac:      	bl	0x740 <__libc_start_main@plt>
     9b0:      	bl	0x7a0 <abort@plt>

00000000000009b4 <call_weak_fn>:
     9b4:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e108>
     9b8:      	ldr	x0, [x0, #0xfe0]
     9bc:      	cbz	x0, 0x9c4 <call_weak_fn+0x10>
     9c0:      	b	0x790 <__gmon_start__@plt>
     9c4:      	ret
     9c8:      	nop
     9cc:      	nop

00000000000009d0 <deregister_tm_clones>:
     9d0:      	adrp	x0, 0x20000 <data_start>
     9d4:      	add	x0, x0, #0x10
     9d8:      	adrp	x1, 0x20000 <data_start>
     9dc:      	add	x1, x1, #0x10
     9e0:      	cmp	x1, x0
     9e4:      	b.eq	0x9fc <deregister_tm_clones+0x2c>
     9e8:      	adrp	x1, 0x1f000 <__FRAME_END__+0x1e108>
     9ec:      	ldr	x1, [x1, #0xfd0]
     9f0:      	cbz	x1, 0x9fc <deregister_tm_clones+0x2c>
     9f4:      	mov	x16, x1
     9f8:      	br	x16
     9fc:      	ret

0000000000000a00 <register_tm_clones>:
     a00:      	adrp	x0, 0x20000 <data_start>
     a04:      	add	x0, x0, #0x10
     a08:      	adrp	x1, 0x20000 <data_start>
     a0c:      	add	x1, x1, #0x10
     a10:      	sub	x1, x1, x0
     a14:      	lsr	x2, x1, #63
     a18:      	add	x1, x2, x1, asr #3
     a1c:      	asr	x1, x1, #1
     a20:      	cbz	x1, 0xa38 <register_tm_clones+0x38>
     a24:      	adrp	x2, 0x1f000 <__FRAME_END__+0x1e108>
     a28:      	ldr	x2, [x2, #0xff8]
     a2c:      	cbz	x2, 0xa38 <register_tm_clones+0x38>
     a30:      	mov	x16, x2
     a34:      	br	x16
     a38:      	ret
     a3c:      	nop

0000000000000a40 <__do_global_dtors_aux>:
     a40:      	paciasp
     a44:      	stp	x29, x30, [sp, #-0x20]!
     a48:      	mov	x29, sp
     a4c:      	str	x19, [sp, #0x10]
     a50:      	adrp	x19, 0x20000 <data_start>
     a54:      	ldrb	w0, [x19, #0x10]
     a58:      	tbnz	w0, #0x0, 0xa80 <__do_global_dtors_aux+0x40>
     a5c:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e108>
     a60:      	ldr	x0, [x0, #0xfd8]
     a64:      	cbz	x0, 0xa74 <__do_global_dtors_aux+0x34>
     a68:      	adrp	x0, 0x20000 <data_start>
     a6c:      	ldr	x0, [x0, #0x8]
     a70:      	bl	0x750 <__cxa_finalize@plt>
     a74:      	bl	0x9d0 <deregister_tm_clones>
     a78:      	mov	w0, #0x1                // =1
     a7c:      	strb	w0, [x19, #0x10]
     a80:      	ldr	x19, [sp, #0x10]
     a84:      	ldp	x29, x30, [sp], #0x20
     a88:      	autiasp
     a8c:      	ret

0000000000000a90 <frame_dummy>:
     a90:      	bti	c
     a94:      	b	0xa00 <register_tm_clones>
     a98:      	nop
     a9c:      	nop

0000000000000aa0 <region_pipeline>:
     aa0:      	stp	x29, x30, [sp, #-0x60]!
     aa4:      	mov	w4, #0x6ab4             // =27316
     aa8:      	movk	w4, #0x72f8, lsl #16
     aac:      	mov	x29, sp
     ab0:      	stp	x23, x24, [sp, #0x30]
     ab4:      	mov	x23, x0
     ab8:      	mov	w0, #0x86a1             // =34465
     abc:      	stp	x19, x20, [sp, #0x10]
     ac0:      	movk	w0, #0x487e, lsl #16
     ac4:      	ldr	w19, [x23]
     ac8:      	mov	w3, #0xf383             // =62339
     acc:      	mov	w24, #0xdd61            // =56673
     ad0:      	stp	x25, x26, [sp, #0x40]
     ad4:      	mov	w25, #0x2dcc            // =11724
     ad8:      	movk	w24, #0x3c16, lsl #16
     adc:      	madd	w19, w19, w0, w4
     ae0:      	stp	x27, x28, [sp, #0x50]
     ae4:      	madd	w1, w1, w0, w19
     ae8:      	movk	w3, #0x377e, lsl #16
     aec:      	movk	w25, #0xa04a, lsl #16
     af0:      	stp	x21, x22, [sp, #0x20]
     af4:      	mov	w22, w2
     af8:      	add	w27, w1, w1, lsl #1
     afc:      	add	w27, w27, w3
     b00:      	madd	w21, w1, w24, w25
     b04:      	sub	w19, w27, w19
     b08:      	mov	w0, w21
     b0c:      	mul	w19, w19, w24
     b10:      	bl	0xc90 <record_event>
     b14:      	cmp	w22, #0x0
     b18:      	b.le	0xbf0 <region_pipeline+0x150>
     b1c:      	mov	w20, #0xe9ef            // =59887
     b20:      	mov	w0, #0x32f2             // =13042
     b24:      	movk	w20, #0xf824, lsl #16
     b28:      	movk	w0, #0x8713, lsl #16
     b2c:      	madd	w27, w27, w24, w25
     b30:      	mov	w25, w22
     b34:      	madd	w21, w21, w20, w0
     b38:      	mov	w24, #0x44e9            // =17641
     b3c:      	mov	w22, #0x9979            // =39289
     b40:      	movk	w24, #0x18e6, lsl #16
     b44:      	movk	w22, #0xc389, lsl #16
     b48:      	mov	w0, w19
     b4c:      	bl	0xcb0 <next_value>
     b50:      	madd	w1, w0, w20, w22
     b54:      	mov	w26, w0
     b58:      	madd	w19, w19, w20, w22
     b5c:      	mov	w4, #0x650f             // =25871
     b60:      	sub	w0, w21, w1
     b64:      	movk	w4, #0x4a25, lsl #16
     b68:      	add	w28, w19, w1
     b6c:      	add	w19, w1, w1, lsl #2
     b70:      	mov	w1, #0x9a1c             // =39452
     b74:      	mov	w5, #0x89d2             // =35282
     b78:      	movk	w1, #0xf1d9, lsl #16
     b7c:      	add	w19, w19, w1
     b80:      	movk	w5, #0x31cc, lsl #16
     b84:      	madd	w19, w27, w20, w19
     b88:      	add	w0, w0, w19
     b8c:      	mul	w19, w19, w4
     b90:      	madd	w27, w0, w4, w5
     b94:      	add	w0, w19, w24
     b98:      	bl	0xc90 <record_event>
     b9c:      	mov	w4, #0x7985             // =31109
     ba0:      	mov	w0, #0xb5b4             // =46516
     ba4:      	movk	w4, #0x9a24, lsl #16
     ba8:      	movk	w0, #0x73a3, lsl #16
     bac:      	mov	w1, #0x802b             // =32811
     bb0:      	mov	w2, #0x44f0             // =17648
     bb4:      	movk	w1, #0x95b, lsl #16
     bb8:      	madd	w28, w28, w4, w0
     bbc:      	mov	w5, #0x3e83             // =16003
     bc0:      	mov	w4, #0xf6b6             // =63158
     bc4:      	madd	w1, w27, w1, w28
     bc8:      	movk	w2, #0x18e6, lsl #16
     bcc:      	movk	w5, #0x32e9, lsl #16
     bd0:      	add	w19, w19, w2
     bd4:      	movk	w4, #0xd630, lsl #16
     bd8:      	str	w19, [x23]
     bdc:      	mov	w0, w26
     be0:      	madd	w19, w1, w5, w4
     be4:      	bl	0xc90 <record_event>
     be8:      	subs	w25, w25, #0x1
     bec:      	b.ne	0xb48 <region_pipeline+0xa8>
     bf0:      	ldp	x21, x22, [sp, #0x20]
     bf4:      	mov	w0, w19
     bf8:      	ldp	x19, x20, [sp, #0x10]
     bfc:      	ldp	x23, x24, [sp, #0x30]
     c00:      	ldp	x25, x26, [sp, #0x40]
     c04:      	ldp	x27, x28, [sp, #0x50]
     c08:      	ldp	x29, x30, [sp], #0x60
     c0c:      	ret

0000000000000c10 <region_outputs>:
     c10:      	mov	w6, #0x2ef1             // =12017
     c14:      	mov	w5, #0x7c43             // =31811
     c18:      	movk	w6, #0x9c54, lsl #16
     c1c:      	movk	w5, #0x6316, lsl #16
     c20:      	mov	w4, #0x8cd3             // =36051
     c24:      	stp	x29, x30, [sp, #-0x30]!
     c28:      	movk	w4, #0xd4fc, lsl #16
     c2c:      	madd	w2, w2, w6, w5
     c30:      	mov	w3, #0x211              // =529
     c34:      	madd	w1, w1, w4, w2
     c38:      	movk	w3, #0x6cbb, lsl #16
     c3c:      	mov	x29, sp
     c40:      	stp	x19, x20, [sp, #0x10]
     c44:      	mov	w20, #0x39c0            // =14784
     c48:      	movk	w20, #0x3598, lsl #16
     c4c:      	mul	w19, w1, w3
     c50:      	str	x21, [sp, #0x20]
     c54:      	mov	x21, x0
     c58:      	add	w0, w19, w20
     c5c:      	add	w20, w20, #0x7
     c60:      	bl	0xc90 <record_event>
     c64:      	sub	w0, w20, #0x18
     c68:      	mov	w1, #0x11               // =17
     c6c:      	add	w20, w19, w20
     c70:      	add	w19, w19, w0
     c74:      	stp	w19, w1, [x21]
     c78:      	mov	w0, #0x0                // =0
     c7c:      	str	w20, [x21, #0x8]
     c80:      	ldp	x19, x20, [sp, #0x10]
     c84:      	ldr	x21, [sp, #0x20]
     c88:      	ldp	x29, x30, [sp], #0x30
     c8c:      	ret

0000000000000c90 <record_event>:
     c90:      	adrp	x2, 0x20000 <data_start>
     c94:      	ldr	w1, [x2, #0x18]
     c98:      	add	w1, w1, w1, lsl #5
     c9c:      	eor	w1, w1, w0
     ca0:      	str	w1, [x2, #0x18]
     ca4:      	ret
     ca8:      	nop
     cac:      	nop

0000000000000cb0 <next_value>:
     cb0:      	adrp	x4, 0x20000 <data_start>
     cb4:      	add	x2, x4, #0x18
     cb8:      	ldr	w1, [x4, #0x18]
     cbc:      	ldr	w3, [x2, #0xc]
     cc0:      	add	w1, w1, w1, lsl #5
     cc4:      	add	w3, w0, w3
     cc8:      	eor	w1, w1, w0
     ccc:      	add	w0, w3, w0
     cd0:      	str	w1, [x4, #0x18]
     cd4:      	str	w3, [x2, #0xc]
     cd8:      	ret

Disassembly of section .fini:

0000000000000cdc <_fini>:
     cdc:      	nop
     ce0:      	stp	x29, x30, [sp, #-0x10]!
     ce4:      	mov	x29, sp
     ce8:      	ldp	x29, x30, [sp], #0x10
     cec:      	ret
