
/work/experiments/runs/private-declarations-cost-linux-20261110/gcc-O3/identity:	file format elf64-littleaarch64

Disassembly of section .init:

00000000000006f8 <_init>:
     6f8:      	nop
     6fc:      	stp	x29, x30, [sp, #-0x10]!
     700:      	mov	x29, sp
     704:      	bl	0x9b4 <call_weak_fn>
     708:      	ldp	x29, x30, [sp], #0x10
     70c:      	ret

Disassembly of section .plt:

0000000000000710 <.plt>:
     710:      	stp	x16, x30, [sp, #-0x10]!
     714:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e200>
     718:      	ldr	x17, [x16, #0xf80]
     71c:      	add	x16, x16, #0xf80
     720:      	br	x17
     724:      	nop
     728:      	nop
     72c:      	nop

0000000000000730 <strtoul@plt>:
     730:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e200>
     734:      	ldr	x17, [x16, #0xf88]
     738:      	add	x16, x16, #0xf88
     73c:      	br	x17

0000000000000740 <__libc_start_main@plt>:
     740:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e200>
     744:      	ldr	x17, [x16, #0xf90]
     748:      	add	x16, x16, #0xf90
     74c:      	br	x17

0000000000000750 <__cxa_finalize@plt>:
     750:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e200>
     754:      	ldr	x17, [x16, #0xf98]
     758:      	add	x16, x16, #0xf98
     75c:      	br	x17

0000000000000760 <clock_gettime@plt>:
     760:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e200>
     764:      	ldr	x17, [x16, #0xfa0]
     768:      	add	x16, x16, #0xfa0
     76c:      	br	x17

0000000000000770 <__printf_chk@plt>:
     770:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e200>
     774:      	ldr	x17, [x16, #0xfa8]
     778:      	add	x16, x16, #0xfa8
     77c:      	br	x17

0000000000000780 <__stack_chk_fail@plt>:
     780:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e200>
     784:      	ldr	x17, [x16, #0xfb0]
     788:      	add	x16, x16, #0xfb0
     78c:      	br	x17

0000000000000790 <__gmon_start__@plt>:
     790:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e200>
     794:      	ldr	x17, [x16, #0xfb8]
     798:      	add	x16, x16, #0xfb8
     79c:      	br	x17

00000000000007a0 <abort@plt>:
     7a0:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e200>
     7a4:      	ldr	x17, [x16, #0xfc0]
     7a8:      	add	x16, x16, #0xfc0
     7ac:      	br	x17

Disassembly of section .text:

00000000000007c0 <main>:
     7c0:      	sub	sp, sp, #0x70
     7c4:      	adrp	x2, 0x1f000 <__FRAME_END__+0x1e200>
     7c8:      	ldr	x2, [x2, #0xfe8]
     7cc:      	stp	x29, x30, [sp, #0x30]
     7d0:      	add	x29, sp, #0x30
     7d4:      	str	x19, [sp, #0x40]
     7d8:      	mov	x19, x1
     7dc:      	ldr	x1, [x2]
     7e0:      	str	x1, [sp, #0x28]
     7e4:      	mov	x1, #0x0                // =0
     7e8:      	cmp	w0, #0x3
     7ec:      	b.eq	0x824 <main+0x64>
     7f0:      	mov	w19, #0x2               // =2
     7f4:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e200>
     7f8:      	ldr	x0, [x0, #0xfe8]
     7fc:      	ldr	x2, [sp, #0x28]
     800:      	ldr	x1, [x0]
     804:      	subs	x2, x2, x1
     808:      	mov	x1, #0x0                // =0
     80c:      	b.ne	0x970 <main+0x1b0>
     810:      	ldp	x29, x30, [sp, #0x30]
     814:      	mov	w0, w19
     818:      	ldr	x19, [sp, #0x40]
     81c:      	add	sp, sp, #0x70
     820:      	ret
     824:      	ldr	x0, [x19, #0x8]
     828:      	mov	w2, #0xa                // =10
     82c:      	mov	x1, #0x0                // =0
     830:      	str	x21, [sp, #0x48]
     834:      	bl	0x730 <strtoul@plt>
     838:      	mov	x21, x0
     83c:      	ldr	x0, [x19, #0x10]
     840:      	mov	w2, #0xa                // =10
     844:      	mov	x1, #0x0                // =0
     848:      	bl	0x730 <strtoul@plt>
     84c:      	mov	x19, x0
     850:      	add	x1, sp, #0x8
     854:      	mov	w0, #0x1                // =1
     858:      	bl	0x760 <clock_gettime@plt>
     85c:      	cbnz	w0, 0x960 <main+0x1a0>
     860:      	stp	x24, x25, [sp, #0x60]
     864:      	cbz	x21, 0x968 <main+0x1a8>
     868:      	stp	x22, x23, [sp, #0x50]
     86c:      	adrp	x22, 0x20000 <data_start>
     870:      	add	x22, x22, #0x18
     874:      	mov	x23, #-0x3333333333333334 // =-3689348814741910324
     878:      	add	x22, x22, #0x8
     87c:      	mov	x24, #0x0               // =0
     880:      	mov	w25, #0x0               // =0
     884:      	movk	x23, #0xcccd
     888:      	umulh	x1, x24, x23
     88c:      	eor	w19, w19, w19, lsl #13
     890:      	mov	x0, x22
     894:      	eor	w19, w19, w19, lsr #17
     898:      	lsr	x1, x1, #3
     89c:      	eor	w19, w19, w19, lsl #5
     8a0:      	add	x2, x1, x1, lsl #2
     8a4:      	mov	w1, w19
     8a8:      	sub	x2, x24, x2, lsl #1
     8ac:      	add	x24, x24, #0x1
     8b0:      	sub	w2, w2, #0x1
     8b4:      	bl	0xaa0 <region_pipeline>
     8b8:      	add	w25, w0, w25
     8bc:      	mov	w1, w19
     8c0:      	mov	w2, w25
     8c4:      	mov	x0, x22
     8c8:      	bl	0xb50 <region_outputs>
     8cc:      	add	w25, w0, w25
     8d0:      	cmp	x21, x24
     8d4:      	b.ne	0x888 <main+0xc8>
     8d8:      	ldp	x22, x23, [sp, #0x50]
     8dc:      	add	x1, sp, #0x18
     8e0:      	mov	w0, #0x1                // =1
     8e4:      	bl	0x760 <clock_gettime@plt>
     8e8:      	mov	w19, w0
     8ec:      	cbnz	w0, 0x954 <main+0x194>
     8f0:      	ldp	x4, x1, [sp, #0x8]
     8f4:      	adrp	x0, 0x0 <strtoul@GLIBC_2.17>
     8f8:      	adrp	x3, 0x20000 <data_start>
     8fc:      	add	x2, x3, #0x18
     900:      	ldr	d1, [x0, #0xc20]
     904:      	add	x5, x2, #0x8
     908:      	ldr	x0, [sp, #0x20]
     90c:      	ldr	w6, [x3, #0x18]
     910:      	sub	x0, x0, x1
     914:      	ldr	w3, [x2, #0x8]
     918:      	ldr	x1, [sp, #0x18]
     91c:      	scvtf	d0, x0
     920:      	mov	w2, w25
     924:      	sub	x0, x1, x4
     928:      	adrp	x1, 0x0 <strtoul@GLIBC_2.17>
     92c:      	ldp	w4, w5, [x5, #0x4]
     930:      	fmul	d0, d0, d1
     934:      	scvtf	d1, x0
     938:      	add	x1, x1, #0xc08
     93c:      	mov	w0, #0x2                // =2
     940:      	fadd	d0, d0, d1
     944:      	bl	0x770 <__printf_chk@plt>
     948:      	ldr	x21, [sp, #0x48]
     94c:      	ldp	x24, x25, [sp, #0x60]
     950:      	b	0x7f4 <main+0x34>
     954:      	ldr	x21, [sp, #0x48]
     958:      	ldp	x24, x25, [sp, #0x60]
     95c:      	b	0x7f0 <main+0x30>
     960:      	ldr	x21, [sp, #0x48]
     964:      	b	0x7f0 <main+0x30>
     968:      	mov	w25, #0x0               // =0
     96c:      	b	0x8dc <main+0x11c>
     970:      	stp	x21, x22, [sp, #0x48]
     974:      	stp	x23, x24, [sp, #0x58]
     978:      	str	x25, [sp, #0x68]
     97c:      	bl	0x780 <__stack_chk_fail@plt>

0000000000000980 <_start>:
     980:      	nop
     984:      	mov	x29, #0x0               // =0
     988:      	mov	x30, #0x0               // =0
     98c:      	mov	x5, x0
     990:      	ldr	x1, [sp]
     994:      	add	x2, sp, #0x8
     998:      	mov	x6, sp
     99c:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e200>
     9a0:      	ldr	x0, [x0, #0xff0]
     9a4:      	mov	x3, #0x0                // =0
     9a8:      	mov	x4, #0x0                // =0
     9ac:      	bl	0x740 <__libc_start_main@plt>
     9b0:      	bl	0x7a0 <abort@plt>

00000000000009b4 <call_weak_fn>:
     9b4:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e200>
     9b8:      	ldr	x0, [x0, #0xfe0]
     9bc:      	cbz	x0, 0x9c4 <call_weak_fn+0x10>
     9c0:      	b	0x790 <__gmon_start__@plt>
     9c4:      	ret
     9c8:      	nop
     9cc:      	nop

00000000000009d0 <deregister_tm_clones>:
     9d0:      	adrp	x0, 0x20000 <data_start>
     9d4:      	add	x0, x0, #0x10
     9d8:      	adrp	x1, 0x20000 <data_start>
     9dc:      	add	x1, x1, #0x10
     9e0:      	cmp	x1, x0
     9e4:      	b.eq	0x9fc <deregister_tm_clones+0x2c>
     9e8:      	adrp	x1, 0x1f000 <__FRAME_END__+0x1e200>
     9ec:      	ldr	x1, [x1, #0xfd0]
     9f0:      	cbz	x1, 0x9fc <deregister_tm_clones+0x2c>
     9f4:      	mov	x16, x1
     9f8:      	br	x16
     9fc:      	ret

0000000000000a00 <register_tm_clones>:
     a00:      	adrp	x0, 0x20000 <data_start>
     a04:      	add	x0, x0, #0x10
     a08:      	adrp	x1, 0x20000 <data_start>
     a0c:      	add	x1, x1, #0x10
     a10:      	sub	x1, x1, x0
     a14:      	lsr	x2, x1, #63
     a18:      	add	x1, x2, x1, asr #3
     a1c:      	asr	x1, x1, #1
     a20:      	cbz	x1, 0xa38 <register_tm_clones+0x38>
     a24:      	adrp	x2, 0x1f000 <__FRAME_END__+0x1e200>
     a28:      	ldr	x2, [x2, #0xff8]
     a2c:      	cbz	x2, 0xa38 <register_tm_clones+0x38>
     a30:      	mov	x16, x2
     a34:      	br	x16
     a38:      	ret
     a3c:      	nop

0000000000000a40 <__do_global_dtors_aux>:
     a40:      	paciasp
     a44:      	stp	x29, x30, [sp, #-0x20]!
     a48:      	mov	x29, sp
     a4c:      	str	x19, [sp, #0x10]
     a50:      	adrp	x19, 0x20000 <data_start>
     a54:      	ldrb	w0, [x19, #0x10]
     a58:      	tbnz	w0, #0x0, 0xa80 <__do_global_dtors_aux+0x40>
     a5c:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e200>
     a60:      	ldr	x0, [x0, #0xfd8]
     a64:      	cbz	x0, 0xa74 <__do_global_dtors_aux+0x34>
     a68:      	adrp	x0, 0x20000 <data_start>
     a6c:      	ldr	x0, [x0, #0x8]
     a70:      	bl	0x750 <__cxa_finalize@plt>
     a74:      	bl	0x9d0 <deregister_tm_clones>
     a78:      	mov	w0, #0x1                // =1
     a7c:      	strb	w0, [x19, #0x10]
     a80:      	ldr	x19, [sp, #0x10]
     a84:      	ldp	x29, x30, [sp], #0x20
     a88:      	autiasp
     a8c:      	ret

0000000000000a90 <frame_dummy>:
     a90:      	bti	c
     a94:      	b	0xa00 <register_tm_clones>
     a98:      	nop
     a9c:      	nop

0000000000000aa0 <region_pipeline>:
     aa0:      	stp	x29, x30, [sp, #-0x50]!
     aa4:      	mov	x29, sp
     aa8:      	stp	x19, x20, [sp, #0x10]
     aac:      	ldr	w20, [x0]
     ab0:      	stp	x23, x24, [sp, #0x30]
     ab4:      	mov	x24, x0
     ab8:      	add	w23, w20, w1
     abc:      	stp	x21, x22, [sp, #0x20]
     ac0:      	mov	w0, w23
     ac4:      	add	w22, w23, w23, lsl #1
     ac8:      	add	w22, w22, #0xb
     acc:      	str	x25, [sp, #0x40]
     ad0:      	sub	w21, w22, w20
     ad4:      	mov	w25, w2
     ad8:      	bl	0xba0 <record_event>
     adc:      	cmp	w25, #0x0
     ae0:      	b.le	0xb2c <region_pipeline+0x8c>
     ae4:      	nop
     ae8:      	mov	w0, w21
     aec:      	bl	0xbc0 <next_value>
     af0:      	mov	w19, w0
     af4:      	sub	w0, w23, w0
     af8:      	add	w21, w19, w21
     afc:      	add	w20, w19, w19, lsl #2
     b00:      	add	w20, w20, w22
     b04:      	add	w22, w0, w20
     b08:      	mov	w0, w20
     b0c:      	add	w20, w20, #0x7
     b10:      	bl	0xba0 <record_event>
     b14:      	str	w20, [x24]
     b18:      	mov	w0, w19
     b1c:      	add	w21, w21, w22
     b20:      	bl	0xba0 <record_event>
     b24:      	subs	w25, w25, #0x1
     b28:      	b.ne	0xae8 <region_pipeline+0x48>
     b2c:      	ldp	x19, x20, [sp, #0x10]
     b30:      	mov	w0, w21
     b34:      	ldp	x21, x22, [sp, #0x20]
     b38:      	ldp	x23, x24, [sp, #0x30]
     b3c:      	ldr	x25, [sp, #0x40]
     b40:      	ldp	x29, x30, [sp], #0x50
     b44:      	ret
     b48:      	nop
     b4c:      	nop

0000000000000b50 <region_outputs>:
     b50:      	stp	x29, x30, [sp, #-0x20]!
     b54:      	mov	x29, sp
     b58:      	stp	x19, x20, [sp, #0x10]
     b5c:      	add	w19, w1, #0x11
     b60:      	mov	x20, x0
     b64:      	add	w19, w19, w19, lsl #1
     b68:      	add	w19, w19, w2
     b6c:      	mov	w0, w19
     b70:      	bl	0xba0 <record_event>
     b74:      	add	w1, w19, #0x7
     b78:      	mov	w2, #0x11               // =17
     b7c:      	sub	w19, w19, #0x11
     b80:      	stp	w19, w2, [x20]
     b84:      	str	w1, [x20, #0x8]
     b88:      	mov	w0, #0x0                // =0
     b8c:      	ldp	x19, x20, [sp, #0x10]
     b90:      	ldp	x29, x30, [sp], #0x20
     b94:      	ret
     b98:      	nop
     b9c:      	nop

0000000000000ba0 <record_event>:
     ba0:      	adrp	x2, 0x20000 <data_start>
     ba4:      	ldr	w1, [x2, #0x18]
     ba8:      	add	w1, w1, w1, lsl #5
     bac:      	eor	w1, w1, w0
     bb0:      	str	w1, [x2, #0x18]
     bb4:      	ret
     bb8:      	nop
     bbc:      	nop

0000000000000bc0 <next_value>:
     bc0:      	adrp	x4, 0x20000 <data_start>
     bc4:      	add	x2, x4, #0x18
     bc8:      	ldr	w1, [x4, #0x18]
     bcc:      	ldr	w3, [x2, #0xc]
     bd0:      	add	w1, w1, w1, lsl #5
     bd4:      	add	w3, w0, w3
     bd8:      	eor	w1, w1, w0
     bdc:      	add	w0, w3, w0
     be0:      	str	w1, [x4, #0x18]
     be4:      	str	w3, [x2, #0xc]
     be8:      	ret

Disassembly of section .fini:

0000000000000bec <_fini>:
     bec:      	nop
     bf0:      	stp	x29, x30, [sp, #-0x10]!
     bf4:      	mov	x29, sp
     bf8:      	ldp	x29, x30, [sp], #0x10
     bfc:      	ret
