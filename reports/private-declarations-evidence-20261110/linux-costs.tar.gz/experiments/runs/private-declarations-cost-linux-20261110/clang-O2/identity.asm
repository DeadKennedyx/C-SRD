
/work/experiments/runs/private-declarations-cost-linux-20261110/clang-O2/identity:	file format elf64-littleaarch64

Disassembly of section .init:

0000000000000638 <_init>:
     638:      	nop
     63c:      	stp	x29, x30, [sp, #-0x10]!
     640:      	mov	x29, sp
     644:      	bl	0x734 <call_weak_fn>
     648:      	ldp	x29, x30, [sp], #0x10
     64c:      	ret

Disassembly of section .plt:

0000000000000650 <.plt>:
     650:      	stp	x16, x30, [sp, #-0x10]!
     654:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e314>
     658:      	ldr	x17, [x16, #0xff8]
     65c:      	add	x16, x16, #0xff8
     660:      	br	x17
     664:      	nop
     668:      	nop
     66c:      	nop

0000000000000670 <strtoul@plt>:
     670:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     674:      	ldr	x17, [x16]
     678:      	add	x16, x16, #0x0
     67c:      	br	x17

0000000000000680 <__libc_start_main@plt>:
     680:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     684:      	ldr	x17, [x16, #0x8]
     688:      	add	x16, x16, #0x8
     68c:      	br	x17

0000000000000690 <__cxa_finalize@plt>:
     690:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     694:      	ldr	x17, [x16, #0x10]
     698:      	add	x16, x16, #0x10
     69c:      	br	x17

00000000000006a0 <clock_gettime@plt>:
     6a0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6a4:      	ldr	x17, [x16, #0x18]
     6a8:      	add	x16, x16, #0x18
     6ac:      	br	x17

00000000000006b0 <__gmon_start__@plt>:
     6b0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6b4:      	ldr	x17, [x16, #0x20]
     6b8:      	add	x16, x16, #0x20
     6bc:      	br	x17

00000000000006c0 <abort@plt>:
     6c0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6c4:      	ldr	x17, [x16, #0x28]
     6c8:      	add	x16, x16, #0x28
     6cc:      	br	x17

00000000000006d0 <printf@plt>:
     6d0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6d4:      	ldr	x17, [x16, #0x30]
     6d8:      	add	x16, x16, #0x30
     6dc:      	br	x17

Disassembly of section .text:

0000000000000700 <_start>:
     700:      	nop
     704:      	mov	x29, #0x0               // =0
     708:      	mov	x30, #0x0               // =0
     70c:      	mov	x5, x0
     710:      	ldr	x1, [sp]
     714:      	add	x2, sp, #0x8
     718:      	mov	x6, sp
     71c:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e314>
     720:      	ldr	x0, [x0, #0xfd8]
     724:      	mov	x3, #0x0                // =0
     728:      	mov	x4, #0x0                // =0
     72c:      	bl	0x680 <__libc_start_main@plt>
     730:      	bl	0x6c0 <abort@plt>

0000000000000734 <call_weak_fn>:
     734:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e314>
     738:      	ldr	x0, [x0, #0xfd0]
     73c:      	cbz	x0, 0x744 <call_weak_fn+0x10>
     740:      	b	0x6b0 <__gmon_start__@plt>
     744:      	ret
     748:      	nop
     74c:      	nop

0000000000000750 <deregister_tm_clones>:
     750:      	adrp	x0, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     754:      	add	x0, x0, #0x48
     758:      	adrp	x1, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     75c:      	add	x1, x1, #0x48
     760:      	cmp	x1, x0
     764:      	b.eq	0x77c <deregister_tm_clones+0x2c>
     768:      	adrp	x1, 0x1f000 <__FRAME_END__+0x1e314>
     76c:      	ldr	x1, [x1, #0xfc0]
     770:      	cbz	x1, 0x77c <deregister_tm_clones+0x2c>
     774:      	mov	x16, x1
     778:      	br	x16
     77c:      	ret

0000000000000780 <register_tm_clones>:
     780:      	adrp	x0, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     784:      	add	x0, x0, #0x48
     788:      	adrp	x1, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     78c:      	add	x1, x1, #0x48
     790:      	sub	x1, x1, x0
     794:      	lsr	x2, x1, #63
     798:      	add	x1, x2, x1, asr #3
     79c:      	asr	x1, x1, #1
     7a0:      	cbz	x1, 0x7b8 <register_tm_clones+0x38>
     7a4:      	adrp	x2, 0x1f000 <__FRAME_END__+0x1e314>
     7a8:      	ldr	x2, [x2, #0xfe0]
     7ac:      	cbz	x2, 0x7b8 <register_tm_clones+0x38>
     7b0:      	mov	x16, x2
     7b4:      	br	x16
     7b8:      	ret
     7bc:      	nop

00000000000007c0 <__do_global_dtors_aux>:
     7c0:      	paciasp
     7c4:      	stp	x29, x30, [sp, #-0x20]!
     7c8:      	mov	x29, sp
     7cc:      	str	x19, [sp, #0x10]
     7d0:      	adrp	x19, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     7d4:      	ldrb	w0, [x19, #0x48]
     7d8:      	tbnz	w0, #0x0, 0x800 <__do_global_dtors_aux+0x40>
     7dc:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e314>
     7e0:      	ldr	x0, [x0, #0xfc8]
     7e4:      	cbz	x0, 0x7f4 <__do_global_dtors_aux+0x34>
     7e8:      	adrp	x0, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     7ec:      	ldr	x0, [x0, #0x40]
     7f0:      	bl	0x690 <__cxa_finalize@plt>
     7f4:      	bl	0x750 <deregister_tm_clones>
     7f8:      	mov	w0, #0x1                // =1
     7fc:      	strb	w0, [x19, #0x48]
     800:      	ldr	x19, [sp, #0x10]
     804:      	ldp	x29, x30, [sp], #0x20
     808:      	autiasp
     80c:      	ret

0000000000000810 <frame_dummy>:
     810:      	bti	c
     814:      	b	0x780 <register_tm_clones>

0000000000000818 <region_pipeline>:
     818:      	stp	x29, x30, [sp, #-0x50]!
     81c:      	str	x25, [sp, #0x10]
     820:      	stp	x24, x23, [sp, #0x20]
     824:      	stp	x22, x21, [sp, #0x30]
     828:      	stp	x20, x19, [sp, #0x40]
     82c:      	mov	x29, sp
     830:      	ldr	w8, [x0]
     834:      	mov	x19, x0
     838:      	mov	w22, w2
     83c:      	add	w20, w8, w1
     840:      	add	w9, w20, w20, lsl #1
     844:      	mov	w0, w20
     848:      	add	w24, w9, #0xb
     84c:      	sub	w21, w24, w8
     850:      	bl	0x910 <record_event>
     854:      	cmp	w22, #0x1
     858:      	b.lt	0x8a8 <region_pipeline+0x90>
     85c:      	add	w25, w22, #0x1
     860:      	mov	w0, w21
     864:      	bl	0x928 <next_value>
     868:      	add	w8, w0, w0, lsl #2
     86c:      	mov	w22, w0
     870:      	add	w21, w0, w21
     874:      	add	w23, w8, w24
     878:      	sub	w8, w23, w0
     87c:      	mov	w0, w23
     880:      	add	w24, w8, w20
     884:      	bl	0x910 <record_event>
     888:      	add	w8, w23, #0x7
     88c:      	mov	w0, w22
     890:      	add	w21, w21, w24
     894:      	str	w8, [x19]
     898:      	bl	0x910 <record_event>
     89c:      	sub	w25, w25, #0x1
     8a0:      	cmp	w25, #0x1
     8a4:      	b.hi	0x860 <region_pipeline+0x48>
     8a8:      	mov	w0, w21
     8ac:      	ldp	x20, x19, [sp, #0x40]
     8b0:      	ldr	x25, [sp, #0x10]
     8b4:      	ldp	x22, x21, [sp, #0x30]
     8b8:      	ldp	x24, x23, [sp, #0x20]
     8bc:      	ldp	x29, x30, [sp], #0x50
     8c0:      	ret

00000000000008c4 <region_outputs>:
     8c4:      	stp	x29, x30, [sp, #-0x30]!
     8c8:      	str	x21, [sp, #0x10]
     8cc:      	stp	x20, x19, [sp, #0x20]
     8d0:      	mov	x29, sp
     8d4:      	add	w8, w1, w1, lsl #1
     8d8:      	mov	x19, x0
     8dc:      	add	w20, w8, w2
     8e0:      	add	w0, w20, #0x33
     8e4:      	add	w21, w20, #0x22
     8e8:      	bl	0x910 <record_event>
     8ec:      	add	w9, w20, #0x3a
     8f0:      	mov	w8, #0x11               // =17
     8f4:      	mov	w0, wzr
     8f8:      	str	w21, [x19]
     8fc:      	stp	w8, w9, [x19, #0x4]
     900:      	ldp	x20, x19, [sp, #0x20]
     904:      	ldr	x21, [sp, #0x10]
     908:      	ldp	x29, x30, [sp], #0x30
     90c:      	ret

0000000000000910 <record_event>:
     910:      	adrp	x8, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     914:      	ldr	w9, [x8, #0x4c]
     918:      	add	w9, w9, w9, lsl #5
     91c:      	eor	w9, w9, w0
     920:      	str	w9, [x8, #0x4c]
     924:      	ret

0000000000000928 <next_value>:
     928:      	adrp	x8, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     92c:      	adrp	x10, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     930:      	ldr	w9, [x8, #0x4c]
     934:      	ldr	w11, [x10, #0x54]
     938:      	add	w9, w9, w9, lsl #5
     93c:      	add	w11, w11, w0
     940:      	str	w11, [x10, #0x54]
     944:      	eor	w9, w9, w0
     948:      	add	w0, w11, w0
     94c:      	str	w9, [x8, #0x4c]
     950:      	ret

0000000000000954 <main>:
     954:      	cmp	w0, #0x3
     958:      	b.ne	0xa2c <main+0xd8>
     95c:      	sub	sp, sp, #0x70
     960:      	stp	x29, x30, [sp, #0x20]
     964:      	stp	x26, x25, [sp, #0x30]
     968:      	stp	x24, x23, [sp, #0x40]
     96c:      	stp	x22, x21, [sp, #0x50]
     970:      	stp	x20, x19, [sp, #0x60]
     974:      	add	x29, sp, #0x20
     978:      	ldr	x0, [x1, #0x8]
     97c:      	mov	x19, x1
     980:      	mov	x1, xzr
     984:      	mov	w2, #0xa                // =10
     988:      	bl	0x670 <strtoul@plt>
     98c:      	ldr	x8, [x19, #0x10]
     990:      	mov	x20, x0
     994:      	mov	x1, xzr
     998:      	mov	w2, #0xa                // =10
     99c:      	mov	x0, x8
     9a0:      	bl	0x670 <strtoul@plt>
     9a4:      	mov	x21, x0
     9a8:      	add	x1, sp, #0x10
     9ac:      	mov	w0, #0x1                // =1
     9b0:      	bl	0x6a0 <clock_gettime@plt>
     9b4:      	cbnz	w0, 0xa48 <main+0xf4>
     9b8:      	cbz	x20, 0xa34 <main+0xe0>
     9bc:      	mov	x25, #-0x3333333333333334 // =-3689348814741910324
     9c0:      	mov	x23, xzr
     9c4:      	mov	w19, wzr
     9c8:      	mov	w24, #-0x1              // =-1
     9cc:      	movk	x25, #0xcccd
     9d0:      	mov	w26, #0xa               // =10
     9d4:      	adrp	x22, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     9d8:      	add	x22, x22, #0x50
     9dc:      	umulh	x8, x23, x25
     9e0:      	eor	w9, w21, w21, lsl #13
     9e4:      	mov	x0, x22
     9e8:      	eor	w9, w9, w9, lsr #17
     9ec:      	eor	w21, w9, w9, lsl #5
     9f0:      	lsr	x8, x8, #3
     9f4:      	mov	w1, w21
     9f8:      	msub	w2, w8, w26, w24
     9fc:      	bl	0x818 <region_pipeline>
     a00:      	add	w19, w0, w19
     a04:      	mov	x0, x22
     a08:      	mov	w1, w21
     a0c:      	mov	w2, w19
     a10:      	bl	0x8c4 <region_outputs>
     a14:      	subs	x20, x20, #0x1
     a18:      	add	w19, w19, w0
     a1c:      	add	x23, x23, #0x1
     a20:      	add	w24, w24, #0x1
     a24:      	b.ne	0x9dc <main+0x88>
     a28:      	b	0xa38 <main+0xe4>
     a2c:      	mov	w0, #0x2                // =2
     a30:      	ret
     a34:      	mov	w19, wzr
     a38:      	mov	x1, sp
     a3c:      	mov	w0, #0x1                // =1
     a40:      	bl	0x6a0 <clock_gettime@plt>
     a44:      	cbz	w0, 0xa68 <main+0x114>
     a48:      	mov	w0, #0x2                // =2
     a4c:      	ldp	x20, x19, [sp, #0x60]
     a50:      	ldp	x22, x21, [sp, #0x50]
     a54:      	ldp	x24, x23, [sp, #0x40]
     a58:      	ldp	x26, x25, [sp, #0x30]
     a5c:      	ldp	x29, x30, [sp, #0x20]
     a60:      	add	sp, sp, #0x70
     a64:      	ret
     a68:      	ldp	x8, x9, [sp]
     a6c:      	adrp	x0, 0x0 <strtoul@GLIBC_2.17>
     a70:      	add	x0, x0, #0xae0
     a74:      	ldp	x10, x11, [sp, #0x10]
     a78:      	mov	w1, w19
     a7c:      	sub	x8, x8, x10
     a80:      	sub	x9, x9, x11
     a84:      	scvtf	d0, x8
     a88:      	scvtf	d1, x9
     a8c:      	adrp	x8, 0x0 <strtoul@GLIBC_2.17>
     a90:      	ldr	d2, [x8, #0xad8]
     a94:      	adrp	x8, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     a98:      	add	x8, x8, #0x50
     a9c:      	adrp	x9, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     aa0:      	ldr	w4, [x8, #0x8]
     aa4:      	ldp	w2, w3, [x8]
     aa8:      	fmadd	d0, d1, d2, d0
     aac:      	ldr	w5, [x9, #0x4c]
     ab0:      	bl	0x6d0 <printf@plt>
     ab4:      	mov	w0, wzr
     ab8:      	b	0xa4c <main+0xf8>

Disassembly of section .fini:

0000000000000abc <_fini>:
     abc:      	nop
     ac0:      	stp	x29, x30, [sp, #-0x10]!
     ac4:      	mov	x29, sp
     ac8:      	ldp	x29, x30, [sp], #0x10
     acc:      	ret
