
/work/experiments/runs/private-declarations-cost-linux-20261110/clang-O2/affine:	file format elf64-littleaarch64

Disassembly of section .init:

0000000000000638 <_init>:
     638:      	nop
     63c:      	stp	x29, x30, [sp, #-0x10]!
     640:      	mov	x29, sp
     644:      	bl	0x734 <call_weak_fn>
     648:      	ldp	x29, x30, [sp], #0x10
     64c:      	ret

Disassembly of section .plt:

0000000000000650 <.plt>:
     650:      	stp	x16, x30, [sp, #-0x10]!
     654:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e23c>
     658:      	ldr	x17, [x16, #0xff8]
     65c:      	add	x16, x16, #0xff8
     660:      	br	x17
     664:      	nop
     668:      	nop
     66c:      	nop

0000000000000670 <strtoul@plt>:
     670:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     674:      	ldr	x17, [x16]
     678:      	add	x16, x16, #0x0
     67c:      	br	x17

0000000000000680 <__libc_start_main@plt>:
     680:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     684:      	ldr	x17, [x16, #0x8]
     688:      	add	x16, x16, #0x8
     68c:      	br	x17

0000000000000690 <__cxa_finalize@plt>:
     690:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     694:      	ldr	x17, [x16, #0x10]
     698:      	add	x16, x16, #0x10
     69c:      	br	x17

00000000000006a0 <clock_gettime@plt>:
     6a0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6a4:      	ldr	x17, [x16, #0x18]
     6a8:      	add	x16, x16, #0x18
     6ac:      	br	x17

00000000000006b0 <__gmon_start__@plt>:
     6b0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6b4:      	ldr	x17, [x16, #0x20]
     6b8:      	add	x16, x16, #0x20
     6bc:      	br	x17

00000000000006c0 <abort@plt>:
     6c0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6c4:      	ldr	x17, [x16, #0x28]
     6c8:      	add	x16, x16, #0x28
     6cc:      	br	x17

00000000000006d0 <printf@plt>:
     6d0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6d4:      	ldr	x17, [x16, #0x30]
     6d8:      	add	x16, x16, #0x30
     6dc:      	br	x17

Disassembly of section .text:

0000000000000700 <_start>:
     700:      	nop
     704:      	mov	x29, #0x0               // =0
     708:      	mov	x30, #0x0               // =0
     70c:      	mov	x5, x0
     710:      	ldr	x1, [sp]
     714:      	add	x2, sp, #0x8
     718:      	mov	x6, sp
     71c:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e23c>
     720:      	ldr	x0, [x0, #0xfd8]
     724:      	mov	x3, #0x0                // =0
     728:      	mov	x4, #0x0                // =0
     72c:      	bl	0x680 <__libc_start_main@plt>
     730:      	bl	0x6c0 <abort@plt>

0000000000000734 <call_weak_fn>:
     734:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e23c>
     738:      	ldr	x0, [x0, #0xfd0]
     73c:      	cbz	x0, 0x744 <call_weak_fn+0x10>
     740:      	b	0x6b0 <__gmon_start__@plt>
     744:      	ret
     748:      	nop
     74c:      	nop

0000000000000750 <deregister_tm_clones>:
     750:      	adrp	x0, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     754:      	add	x0, x0, #0x48
     758:      	adrp	x1, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     75c:      	add	x1, x1, #0x48
     760:      	cmp	x1, x0
     764:      	b.eq	0x77c <deregister_tm_clones+0x2c>
     768:      	adrp	x1, 0x1f000 <__FRAME_END__+0x1e23c>
     76c:      	ldr	x1, [x1, #0xfc0]
     770:      	cbz	x1, 0x77c <deregister_tm_clones+0x2c>
     774:      	mov	x16, x1
     778:      	br	x16
     77c:      	ret

0000000000000780 <register_tm_clones>:
     780:      	adrp	x0, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     784:      	add	x0, x0, #0x48
     788:      	adrp	x1, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     78c:      	add	x1, x1, #0x48
     790:      	sub	x1, x1, x0
     794:      	lsr	x2, x1, #63
     798:      	add	x1, x2, x1, asr #3
     79c:      	asr	x1, x1, #1
     7a0:      	cbz	x1, 0x7b8 <register_tm_clones+0x38>
     7a4:      	adrp	x2, 0x1f000 <__FRAME_END__+0x1e23c>
     7a8:      	ldr	x2, [x2, #0xfe0]
     7ac:      	cbz	x2, 0x7b8 <register_tm_clones+0x38>
     7b0:      	mov	x16, x2
     7b4:      	br	x16
     7b8:      	ret
     7bc:      	nop

00000000000007c0 <__do_global_dtors_aux>:
     7c0:      	paciasp
     7c4:      	stp	x29, x30, [sp, #-0x20]!
     7c8:      	mov	x29, sp
     7cc:      	str	x19, [sp, #0x10]
     7d0:      	adrp	x19, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     7d4:      	ldrb	w0, [x19, #0x48]
     7d8:      	tbnz	w0, #0x0, 0x800 <__do_global_dtors_aux+0x40>
     7dc:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e23c>
     7e0:      	ldr	x0, [x0, #0xfc8]
     7e4:      	cbz	x0, 0x7f4 <__do_global_dtors_aux+0x34>
     7e8:      	adrp	x0, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     7ec:      	ldr	x0, [x0, #0x40]
     7f0:      	bl	0x690 <__cxa_finalize@plt>
     7f4:      	bl	0x750 <deregister_tm_clones>
     7f8:      	mov	w0, #0x1                // =1
     7fc:      	strb	w0, [x19, #0x48]
     800:      	ldr	x19, [sp, #0x10]
     804:      	ldp	x29, x30, [sp], #0x20
     808:      	autiasp
     80c:      	ret

0000000000000810 <frame_dummy>:
     810:      	bti	c
     814:      	b	0x780 <register_tm_clones>

0000000000000818 <region_pipeline>:
     818:      	stp	x29, x30, [sp, #-0x60]!
     81c:      	stp	x28, x27, [sp, #0x10]
     820:      	stp	x26, x25, [sp, #0x20]
     824:      	stp	x24, x23, [sp, #0x30]
     828:      	stp	x22, x21, [sp, #0x40]
     82c:      	stp	x20, x19, [sp, #0x50]
     830:      	mov	x29, sp
     834:      	ldr	w8, [x0]
     838:      	mov	w9, #0x23c7             // =9159
     83c:      	mov	w11, #0xa4f5            // =42229
     840:      	movk	w9, #0xf25f, lsl #16
     844:      	movk	w11, #0x3d0d, lsl #16
     848:      	mov	x19, x0
     84c:      	mul	w10, w8, w9
     850:      	add	w22, w8, w1
     854:      	mov	w21, w2
     858:      	madd	w9, w1, w9, w10
     85c:      	mov	w0, w22
     860:      	add	w24, w9, w11
     864:      	mov	w11, #0xd3e2            // =54242
     868:      	add	w9, w24, w24, lsl #1
     86c:      	movk	w11, #0x55f5, lsl #16
     870:      	sub	w9, w9, w10
     874:      	mov	w10, #0xadf7            // =44535
     878:      	movk	w10, #0xec1, lsl #16
     87c:      	madd	w20, w9, w10, w11
     880:      	bl	0x9d8 <record_event>
     884:      	cmp	w21, #0x1
     888:      	b.lt	0x950 <region_pipeline+0x138>
     88c:      	mov	w8, #0x51b5             // =20917
     890:      	mov	w9, #0x73e9             // =29673
     894:      	mov	w27, #0x46b             // =1131
     898:      	movk	w8, #0x42c, lsl #16
     89c:      	movk	w9, #0x6c4d, lsl #16
     8a0:      	mov	w28, #0x519f            // =20895
     8a4:      	mul	w23, w22, w8
     8a8:      	mov	w8, #0x50ca             // =20682
     8ac:      	mov	w26, #0x8843            // =34883
     8b0:      	movk	w8, #0x81b1, lsl #16
     8b4:      	madd	w24, w24, w9, w8
     8b8:      	add	w25, w21, #0x1
     8bc:      	movk	w27, #0xe5f2, lsl #16
     8c0:      	movk	w28, #0x94ed, lsl #16
     8c4:      	movk	w26, #0x11f0, lsl #16
     8c8:      	mov	w0, w20
     8cc:      	bl	0x9f0 <next_value>
     8d0:      	mov	w8, #0x9889             // =39049
     8d4:      	mov	w10, #0xfd48            // =64840
     8d8:      	mov	w9, #0xae4b             // =44619
     8dc:      	movk	w8, #0x14dd, lsl #16
     8e0:      	movk	w10, #0x3357, lsl #16
     8e4:      	mov	w11, #0xd49d            // =54429
     8e8:      	madd	w8, w0, w8, w24
     8ec:      	movk	w9, #0xfbd3, lsl #16
     8f0:      	movk	w11, #0x2188, lsl #16
     8f4:      	madd	w9, w0, w9, w23
     8f8:      	mov	w21, w0
     8fc:      	add	w20, w0, w20
     900:      	add	w8, w8, w10
     904:      	mov	w10, #0xad8             // =2776
     908:      	movk	w10, #0xcf0a, lsl #16
     90c:      	madd	w22, w8, w11, w10
     910:      	mov	w10, #0x2b8             // =696
     914:      	movk	w10, #0xcca8, lsl #16
     918:      	add	w9, w9, w10
     91c:      	mov	w0, w22
     920:      	add	w24, w9, w8
     924:      	bl	0x9d8 <record_event>
     928:      	mul	w8, w20, w27
     92c:      	mov	w0, w21
     930:      	madd	w8, w24, w28, w8
     934:      	mul	w20, w8, w26
     938:      	add	w8, w22, #0x7
     93c:      	str	w8, [x19]
     940:      	bl	0x9d8 <record_event>
     944:      	sub	w25, w25, #0x1
     948:      	cmp	w25, #0x1
     94c:      	b.hi	0x8c8 <region_pipeline+0xb0>
     950:      	mov	w0, w20
     954:      	ldp	x20, x19, [sp, #0x50]
     958:      	ldp	x22, x21, [sp, #0x40]
     95c:      	ldp	x24, x23, [sp, #0x30]
     960:      	ldp	x26, x25, [sp, #0x20]
     964:      	ldp	x28, x27, [sp, #0x10]
     968:      	ldp	x29, x30, [sp], #0x60
     96c:      	ret

0000000000000970 <region_outputs>:
     970:      	stp	x29, x30, [sp, #-0x30]!
     974:      	str	x21, [sp, #0x10]
     978:      	stp	x20, x19, [sp, #0x20]
     97c:      	mov	x29, sp
     980:      	mov	w8, #0xeee9             // =61161
     984:      	mov	w9, #0x4fa3             // =20387
     988:      	mov	x19, x0
     98c:      	movk	w8, #0x7be6, lsl #16
     990:      	movk	w9, #0x7ea2, lsl #16
     994:      	mul	w8, w1, w8
     998:      	madd	w8, w2, w9, w8
     99c:      	mov	w9, #0x5c0b             // =23563
     9a0:      	movk	w9, #0xe278, lsl #16
     9a4:      	mul	w20, w8, w9
     9a8:      	add	w0, w20, #0x33
     9ac:      	add	w21, w20, #0x22
     9b0:      	bl	0x9d8 <record_event>
     9b4:      	add	w9, w20, #0x3a
     9b8:      	mov	w8, #0x11               // =17
     9bc:      	mov	w0, wzr
     9c0:      	str	w21, [x19]
     9c4:      	stp	w8, w9, [x19, #0x4]
     9c8:      	ldp	x20, x19, [sp, #0x20]
     9cc:      	ldr	x21, [sp, #0x10]
     9d0:      	ldp	x29, x30, [sp], #0x30
     9d4:      	ret

00000000000009d8 <record_event>:
     9d8:      	adrp	x8, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     9dc:      	ldr	w9, [x8, #0x4c]
     9e0:      	add	w9, w9, w9, lsl #5
     9e4:      	eor	w9, w9, w0
     9e8:      	str	w9, [x8, #0x4c]
     9ec:      	ret

00000000000009f0 <next_value>:
     9f0:      	adrp	x8, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     9f4:      	adrp	x10, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     9f8:      	ldr	w9, [x8, #0x4c]
     9fc:      	ldr	w11, [x10, #0x54]
     a00:      	add	w9, w9, w9, lsl #5
     a04:      	add	w11, w11, w0
     a08:      	str	w11, [x10, #0x54]
     a0c:      	eor	w9, w9, w0
     a10:      	add	w0, w11, w0
     a14:      	str	w9, [x8, #0x4c]
     a18:      	ret

0000000000000a1c <main>:
     a1c:      	cmp	w0, #0x3
     a20:      	b.ne	0xaf4 <main+0xd8>
     a24:      	sub	sp, sp, #0x70
     a28:      	stp	x29, x30, [sp, #0x20]
     a2c:      	stp	x26, x25, [sp, #0x30]
     a30:      	stp	x24, x23, [sp, #0x40]
     a34:      	stp	x22, x21, [sp, #0x50]
     a38:      	stp	x20, x19, [sp, #0x60]
     a3c:      	add	x29, sp, #0x20
     a40:      	ldr	x0, [x1, #0x8]
     a44:      	mov	x19, x1
     a48:      	mov	x1, xzr
     a4c:      	mov	w2, #0xa                // =10
     a50:      	bl	0x670 <strtoul@plt>
     a54:      	ldr	x8, [x19, #0x10]
     a58:      	mov	x20, x0
     a5c:      	mov	x1, xzr
     a60:      	mov	w2, #0xa                // =10
     a64:      	mov	x0, x8
     a68:      	bl	0x670 <strtoul@plt>
     a6c:      	mov	x21, x0
     a70:      	add	x1, sp, #0x10
     a74:      	mov	w0, #0x1                // =1
     a78:      	bl	0x6a0 <clock_gettime@plt>
     a7c:      	cbnz	w0, 0xb10 <main+0xf4>
     a80:      	cbz	x20, 0xafc <main+0xe0>
     a84:      	mov	x25, #-0x3333333333333334 // =-3689348814741910324
     a88:      	mov	x23, xzr
     a8c:      	mov	w19, wzr
     a90:      	mov	w24, #-0x1              // =-1
     a94:      	movk	x25, #0xcccd
     a98:      	mov	w26, #0xa               // =10
     a9c:      	adrp	x22, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     aa0:      	add	x22, x22, #0x50
     aa4:      	umulh	x8, x23, x25
     aa8:      	eor	w9, w21, w21, lsl #13
     aac:      	mov	x0, x22
     ab0:      	eor	w9, w9, w9, lsr #17
     ab4:      	eor	w21, w9, w9, lsl #5
     ab8:      	lsr	x8, x8, #3
     abc:      	mov	w1, w21
     ac0:      	msub	w2, w8, w26, w24
     ac4:      	bl	0x818 <region_pipeline>
     ac8:      	add	w19, w0, w19
     acc:      	mov	x0, x22
     ad0:      	mov	w1, w21
     ad4:      	mov	w2, w19
     ad8:      	bl	0x970 <region_outputs>
     adc:      	subs	x20, x20, #0x1
     ae0:      	add	w19, w19, w0
     ae4:      	add	x23, x23, #0x1
     ae8:      	add	w24, w24, #0x1
     aec:      	b.ne	0xaa4 <main+0x88>
     af0:      	b	0xb00 <main+0xe4>
     af4:      	mov	w0, #0x2                // =2
     af8:      	ret
     afc:      	mov	w19, wzr
     b00:      	mov	x1, sp
     b04:      	mov	w0, #0x1                // =1
     b08:      	bl	0x6a0 <clock_gettime@plt>
     b0c:      	cbz	w0, 0xb30 <main+0x114>
     b10:      	mov	w0, #0x2                // =2
     b14:      	ldp	x20, x19, [sp, #0x60]
     b18:      	ldp	x22, x21, [sp, #0x50]
     b1c:      	ldp	x24, x23, [sp, #0x40]
     b20:      	ldp	x26, x25, [sp, #0x30]
     b24:      	ldp	x29, x30, [sp, #0x20]
     b28:      	add	sp, sp, #0x70
     b2c:      	ret
     b30:      	ldp	x8, x9, [sp]
     b34:      	adrp	x0, 0x0 <strtoul@GLIBC_2.17>
     b38:      	add	x0, x0, #0xba8
     b3c:      	ldp	x10, x11, [sp, #0x10]
     b40:      	mov	w1, w19
     b44:      	sub	x8, x8, x10
     b48:      	sub	x9, x9, x11
     b4c:      	scvtf	d0, x8
     b50:      	scvtf	d1, x9
     b54:      	adrp	x8, 0x0 <strtoul@GLIBC_2.17>
     b58:      	ldr	d2, [x8, #0xba0]
     b5c:      	adrp	x8, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     b60:      	add	x8, x8, #0x50
     b64:      	adrp	x9, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     b68:      	ldr	w4, [x8, #0x8]
     b6c:      	ldp	w2, w3, [x8]
     b70:      	fmadd	d0, d1, d2, d0
     b74:      	ldr	w5, [x9, #0x4c]
     b78:      	bl	0x6d0 <printf@plt>
     b7c:      	mov	w0, wzr
     b80:      	b	0xb14 <main+0xf8>

Disassembly of section .fini:

0000000000000b84 <_fini>:
     b84:      	nop
     b88:      	stp	x29, x30, [sp, #-0x10]!
     b8c:      	mov	x29, sp
     b90:      	ldp	x29, x30, [sp], #0x10
     b94:      	ret
