
/work/experiments/runs/private-declarations-cost-linux-20261110/gcc-Os/identity:	file format elf64-littleaarch64

Disassembly of section .init:

00000000000006f8 <_init>:
     6f8:      	nop
     6fc:      	stp	x29, x30, [sp, #-0x10]!
     700:      	mov	x29, sp
     704:      	bl	0x9b4 <call_weak_fn>
     708:      	ldp	x29, x30, [sp], #0x10
     70c:      	ret

Disassembly of section .plt:

0000000000000710 <.plt>:
     710:      	stp	x16, x30, [sp, #-0x10]!
     714:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e238>
     718:      	ldr	x17, [x16, #0xf80]
     71c:      	add	x16, x16, #0xf80
     720:      	br	x17
     724:      	nop
     728:      	nop
     72c:      	nop

0000000000000730 <strtoul@plt>:
     730:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e238>
     734:      	ldr	x17, [x16, #0xf88]
     738:      	add	x16, x16, #0xf88
     73c:      	br	x17

0000000000000740 <__libc_start_main@plt>:
     740:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e238>
     744:      	ldr	x17, [x16, #0xf90]
     748:      	add	x16, x16, #0xf90
     74c:      	br	x17

0000000000000750 <__cxa_finalize@plt>:
     750:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e238>
     754:      	ldr	x17, [x16, #0xf98]
     758:      	add	x16, x16, #0xf98
     75c:      	br	x17

0000000000000760 <clock_gettime@plt>:
     760:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e238>
     764:      	ldr	x17, [x16, #0xfa0]
     768:      	add	x16, x16, #0xfa0
     76c:      	br	x17

0000000000000770 <__printf_chk@plt>:
     770:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e238>
     774:      	ldr	x17, [x16, #0xfa8]
     778:      	add	x16, x16, #0xfa8
     77c:      	br	x17

0000000000000780 <__stack_chk_fail@plt>:
     780:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e238>
     784:      	ldr	x17, [x16, #0xfb0]
     788:      	add	x16, x16, #0xfb0
     78c:      	br	x17

0000000000000790 <__gmon_start__@plt>:
     790:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e238>
     794:      	ldr	x17, [x16, #0xfb8]
     798:      	add	x16, x16, #0xfb8
     79c:      	br	x17

00000000000007a0 <abort@plt>:
     7a0:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e238>
     7a4:      	ldr	x17, [x16, #0xfc0]
     7a8:      	add	x16, x16, #0xfc0
     7ac:      	br	x17

Disassembly of section .text:

00000000000007c0 <main>:
     7c0:      	sub	sp, sp, #0x70
     7c4:      	stp	x29, x30, [sp, #0x30]
     7c8:      	add	x29, sp, #0x30
     7cc:      	stp	x19, x20, [sp, #0x40]
     7d0:      	mov	x19, x1
     7d4:      	adrp	x1, 0x1f000 <__FRAME_END__+0x1e238>
     7d8:      	ldr	x1, [x1, #0xfe8]
     7dc:      	stp	x22, x23, [sp, #0x50]
     7e0:      	stp	x24, x25, [sp, #0x60]
     7e4:      	ldr	x2, [x1]
     7e8:      	str	x2, [sp, #0x28]
     7ec:      	mov	x2, #0x0                // =0
     7f0:      	cmp	w0, #0x3
     7f4:      	b.eq	0x81c <main+0x5c>
     7f8:      	mov	w19, #0x2               // =2
     7fc:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e238>
     800:      	ldr	x0, [x0, #0xfe8]
     804:      	ldr	x2, [sp, #0x28]
     808:      	ldr	x1, [x0]
     80c:      	subs	x2, x2, x1
     810:      	mov	x1, #0x0                // =0
     814:      	b.eq	0x92c <main+0x16c>
     818:      	bl	0x780 <__stack_chk_fail@plt>
     81c:      	ldr	x0, [x19, #0x8]
     820:      	mov	w2, #0xa                // =10
     824:      	mov	x1, #0x0                // =0
     828:      	bl	0x730 <strtoul@plt>
     82c:      	mov	x24, x0
     830:      	ldr	x0, [x19, #0x10]
     834:      	mov	w2, #0xa                // =10
     838:      	mov	x1, #0x0                // =0
     83c:      	bl	0x730 <strtoul@plt>
     840:      	mov	w19, w0
     844:      	add	x1, sp, #0x8
     848:      	mov	w0, #0x1                // =1
     84c:      	bl	0x760 <clock_gettime@plt>
     850:      	cbnz	w0, 0x7f8 <main+0x38>
     854:      	adrp	x22, 0x20000 <data_start>
     858:      	add	x22, x22, #0x14
     85c:      	add	x22, x22, #0x4
     860:      	mov	x20, #0x0               // =0
     864:      	mov	w23, #0x0               // =0
     868:      	mov	x25, #0xa               // =10
     86c:      	cmp	x20, x24
     870:      	b.ne	0x8e8 <main+0x128>
     874:      	add	x1, sp, #0x18
     878:      	mov	w0, #0x1                // =1
     87c:      	bl	0x760 <clock_gettime@plt>
     880:      	mov	w19, w0
     884:      	cbnz	w0, 0x7f8 <main+0x38>
     888:      	ldr	x4, [sp, #0x10]
     88c:      	adrp	x3, 0x20000 <data_start>
     890:      	ldr	x1, [sp, #0x20]
     894:      	add	x0, x3, #0x14
     898:      	ldr	w6, [x3, #0x14]
     89c:      	mov	w2, w23
     8a0:      	sub	x1, x1, x4
     8a4:      	ldr	x4, [sp, #0x8]
     8a8:      	scvtf	d0, x1
     8ac:      	adrp	x1, 0x0 <strtoul@GLIBC_2.17>
     8b0:      	ldr	w3, [x0, #0x4]
     8b4:      	ldr	w5, [x0, #0xc]
     8b8:      	ldr	d1, [x1, #0xc08]
     8bc:      	ldr	x1, [sp, #0x18]
     8c0:      	fmul	d0, d0, d1
     8c4:      	sub	x1, x1, x4
     8c8:      	ldr	w4, [x0, #0x8]
     8cc:      	mov	w0, #0x2                // =2
     8d0:      	scvtf	d1, x1
     8d4:      	adrp	x1, 0x0 <strtoul@GLIBC_2.17>
     8d8:      	add	x1, x1, #0xbec
     8dc:      	fadd	d0, d0, d1
     8e0:      	bl	0x770 <__printf_chk@plt>
     8e4:      	b	0x7fc <main+0x3c>
     8e8:      	udiv	x2, x20, x25
     8ec:      	eor	w19, w19, w19, lsl #13
     8f0:      	mov	x0, x22
     8f4:      	eor	w19, w19, w19, lsr #17
     8f8:      	msub	x2, x2, x25, x20
     8fc:      	eor	w19, w19, w19, lsl #5
     900:      	mov	w1, w19
     904:      	add	x20, x20, #0x1
     908:      	sub	w2, w2, #0x1
     90c:      	bl	0xa98 <region_pipeline>
     910:      	add	w23, w23, w0
     914:      	mov	w1, w19
     918:      	mov	w2, w23
     91c:      	mov	x0, x22
     920:      	bl	0xb40 <region_outputs>
     924:      	add	w23, w0, w23
     928:      	b	0x86c <main+0xac>
     92c:      	ldp	x29, x30, [sp, #0x30]
     930:      	mov	w0, w19
     934:      	ldp	x19, x20, [sp, #0x40]
     938:      	ldp	x22, x23, [sp, #0x50]
     93c:      	ldp	x24, x25, [sp, #0x60]
     940:      	add	sp, sp, #0x70
     944:      	ret
     948:      	nop
     94c:      	nop
     950:      	nop
     954:      	nop
     958:      	nop
     95c:      	nop
     960:      	nop
     964:      	nop
     968:      	nop
     96c:      	nop
     970:      	nop
     974:      	nop
     978:      	nop
     97c:      	nop

0000000000000980 <_start>:
     980:      	nop
     984:      	mov	x29, #0x0               // =0
     988:      	mov	x30, #0x0               // =0
     98c:      	mov	x5, x0
     990:      	ldr	x1, [sp]
     994:      	add	x2, sp, #0x8
     998:      	mov	x6, sp
     99c:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e238>
     9a0:      	ldr	x0, [x0, #0xff0]
     9a4:      	mov	x3, #0x0                // =0
     9a8:      	mov	x4, #0x0                // =0
     9ac:      	bl	0x740 <__libc_start_main@plt>
     9b0:      	bl	0x7a0 <abort@plt>

00000000000009b4 <call_weak_fn>:
     9b4:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e238>
     9b8:      	ldr	x0, [x0, #0xfe0]
     9bc:      	cbz	x0, 0x9c4 <call_weak_fn+0x10>
     9c0:      	b	0x790 <__gmon_start__@plt>
     9c4:      	ret
     9c8:      	nop
     9cc:      	nop

00000000000009d0 <deregister_tm_clones>:
     9d0:      	adrp	x0, 0x20000 <data_start>
     9d4:      	add	x0, x0, #0x10
     9d8:      	adrp	x1, 0x20000 <data_start>
     9dc:      	add	x1, x1, #0x10
     9e0:      	cmp	x1, x0
     9e4:      	b.eq	0x9fc <deregister_tm_clones+0x2c>
     9e8:      	adrp	x1, 0x1f000 <__FRAME_END__+0x1e238>
     9ec:      	ldr	x1, [x1, #0xfd0]
     9f0:      	cbz	x1, 0x9fc <deregister_tm_clones+0x2c>
     9f4:      	mov	x16, x1
     9f8:      	br	x16
     9fc:      	ret

0000000000000a00 <register_tm_clones>:
     a00:      	adrp	x0, 0x20000 <data_start>
     a04:      	add	x0, x0, #0x10
     a08:      	adrp	x1, 0x20000 <data_start>
     a0c:      	add	x1, x1, #0x10
     a10:      	sub	x1, x1, x0
     a14:      	lsr	x2, x1, #63
     a18:      	add	x1, x2, x1, asr #3
     a1c:      	asr	x1, x1, #1
     a20:      	cbz	x1, 0xa38 <register_tm_clones+0x38>
     a24:      	adrp	x2, 0x1f000 <__FRAME_END__+0x1e238>
     a28:      	ldr	x2, [x2, #0xff8]
     a2c:      	cbz	x2, 0xa38 <register_tm_clones+0x38>
     a30:      	mov	x16, x2
     a34:      	br	x16
     a38:      	ret
     a3c:      	nop

0000000000000a40 <__do_global_dtors_aux>:
     a40:      	paciasp
     a44:      	stp	x29, x30, [sp, #-0x20]!
     a48:      	mov	x29, sp
     a4c:      	str	x19, [sp, #0x10]
     a50:      	adrp	x19, 0x20000 <data_start>
     a54:      	ldrb	w0, [x19, #0x10]
     a58:      	tbnz	w0, #0x0, 0xa80 <__do_global_dtors_aux+0x40>
     a5c:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e238>
     a60:      	ldr	x0, [x0, #0xfd8]
     a64:      	cbz	x0, 0xa74 <__do_global_dtors_aux+0x34>
     a68:      	adrp	x0, 0x20000 <data_start>
     a6c:      	ldr	x0, [x0, #0x8]
     a70:      	bl	0x750 <__cxa_finalize@plt>
     a74:      	bl	0x9d0 <deregister_tm_clones>
     a78:      	mov	w0, #0x1                // =1
     a7c:      	strb	w0, [x19, #0x10]
     a80:      	ldr	x19, [sp, #0x10]
     a84:      	ldp	x29, x30, [sp], #0x20
     a88:      	autiasp
     a8c:      	ret

0000000000000a90 <frame_dummy>:
     a90:      	bti	c
     a94:      	b	0xa00 <register_tm_clones>

0000000000000a98 <region_pipeline>:
     a98:      	stp	x29, x30, [sp, #-0x50]!
     a9c:      	mov	x29, sp
     aa0:      	stp	x19, x20, [sp, #0x10]
     aa4:      	ldr	w19, [x0]
     aa8:      	stp	x23, x24, [sp, #0x30]
     aac:      	mov	x24, x0
     ab0:      	add	w23, w19, w1
     ab4:      	mov	w0, w23
     ab8:      	stp	x21, x22, [sp, #0x20]
     abc:      	add	w20, w23, w23, lsl #1
     ac0:      	add	w20, w20, #0xb
     ac4:      	str	x25, [sp, #0x40]
     ac8:      	sub	w19, w20, w19
     acc:      	mov	w25, w2
     ad0:      	bl	0xb8c <record_event>
     ad4:      	tbz	w25, #0x1f, 0xb30 <region_pipeline+0x98>
     ad8:      	ldp	x21, x22, [sp, #0x20]
     adc:      	mov	w0, w19
     ae0:      	ldp	x19, x20, [sp, #0x10]
     ae4:      	ldp	x23, x24, [sp, #0x30]
     ae8:      	ldr	x25, [sp, #0x40]
     aec:      	ldp	x29, x30, [sp], #0x50
     af0:      	ret
     af4:      	mov	w0, w19
     af8:      	bl	0xba4 <next_value>
     afc:      	add	w22, w0, w0, lsl #2
     b00:      	mov	w21, w0
     b04:      	add	w22, w22, w20
     b08:      	sub	w20, w23, w0
     b0c:      	add	w19, w19, w0
     b10:      	add	w20, w20, w22
     b14:      	mov	w0, w22
     b18:      	add	w22, w22, #0x7
     b1c:      	bl	0xb8c <record_event>
     b20:      	str	w22, [x24]
     b24:      	add	w19, w19, w20
     b28:      	mov	w0, w21
     b2c:      	bl	0xb8c <record_event>
     b30:      	sub	w25, w25, #0x1
     b34:      	cmn	w25, #0x1
     b38:      	b.ne	0xaf4 <region_pipeline+0x5c>
     b3c:      	b	0xad8 <region_pipeline+0x40>

0000000000000b40 <region_outputs>:
     b40:      	stp	x29, x30, [sp, #-0x20]!
     b44:      	mov	x29, sp
     b48:      	stp	x19, x20, [sp, #0x10]
     b4c:      	add	w19, w1, #0x11
     b50:      	mov	x20, x0
     b54:      	add	w19, w19, w19, lsl #1
     b58:      	add	w19, w19, w2
     b5c:      	mov	w0, w19
     b60:      	bl	0xb8c <record_event>
     b64:      	add	w0, w19, #0x7
     b68:      	sub	w19, w19, #0x11
     b6c:      	str	w19, [x20]
     b70:      	str	w0, [x20, #0x8]
     b74:      	mov	w0, #0x11               // =17
     b78:      	str	w0, [x20, #0x4]
     b7c:      	mov	w0, #0x0                // =0
     b80:      	ldp	x19, x20, [sp, #0x10]
     b84:      	ldp	x29, x30, [sp], #0x20
     b88:      	ret

0000000000000b8c <record_event>:
     b8c:      	adrp	x2, 0x20000 <data_start>
     b90:      	ldr	w1, [x2, #0x14]
     b94:      	add	w1, w1, w1, lsl #5
     b98:      	eor	w1, w1, w0
     b9c:      	str	w1, [x2, #0x14]
     ba0:      	ret

0000000000000ba4 <next_value>:
     ba4:      	stp	x29, x30, [sp, #-0x10]!
     ba8:      	mov	w3, w0
     bac:      	mov	x29, sp
     bb0:      	bl	0xb8c <record_event>
     bb4:      	adrp	x1, 0x20000 <data_start>
     bb8:      	add	x1, x1, #0x14
     bbc:      	ldr	w0, [x1, #0x8]
     bc0:      	add	w0, w3, w0
     bc4:      	str	w0, [x1, #0x8]
     bc8:      	add	w0, w0, w3
     bcc:      	ldp	x29, x30, [sp], #0x10
     bd0:      	ret

Disassembly of section .fini:

0000000000000bd4 <_fini>:
     bd4:      	nop
     bd8:      	stp	x29, x30, [sp, #-0x10]!
     bdc:      	mov	x29, sp
     be0:      	ldp	x29, x30, [sp], #0x10
     be4:      	ret
