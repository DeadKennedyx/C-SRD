
/work/experiments/runs/private-declarations-cost-linux-20261110/clang-O2-lto/affine:	file format elf64-littleaarch64

Disassembly of section .init:

0000000000000638 <_init>:
     638:      	nop
     63c:      	stp	x29, x30, [sp, #-0x10]!
     640:      	mov	x29, sp
     644:      	bl	0x734 <call_weak_fn>
     648:      	ldp	x29, x30, [sp], #0x10
     64c:      	ret

Disassembly of section .plt:

0000000000000650 <.plt>:
     650:      	stp	x16, x30, [sp, #-0x10]!
     654:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e398>
     658:      	ldr	x17, [x16, #0xff8]
     65c:      	add	x16, x16, #0xff8
     660:      	br	x17
     664:      	nop
     668:      	nop
     66c:      	nop

0000000000000670 <strtoul@plt>:
     670:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     674:      	ldr	x17, [x16]
     678:      	add	x16, x16, #0x0
     67c:      	br	x17

0000000000000680 <__libc_start_main@plt>:
     680:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     684:      	ldr	x17, [x16, #0x8]
     688:      	add	x16, x16, #0x8
     68c:      	br	x17

0000000000000690 <__cxa_finalize@plt>:
     690:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     694:      	ldr	x17, [x16, #0x10]
     698:      	add	x16, x16, #0x10
     69c:      	br	x17

00000000000006a0 <clock_gettime@plt>:
     6a0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6a4:      	ldr	x17, [x16, #0x18]
     6a8:      	add	x16, x16, #0x18
     6ac:      	br	x17

00000000000006b0 <__gmon_start__@plt>:
     6b0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6b4:      	ldr	x17, [x16, #0x20]
     6b8:      	add	x16, x16, #0x20
     6bc:      	br	x17

00000000000006c0 <abort@plt>:
     6c0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6c4:      	ldr	x17, [x16, #0x28]
     6c8:      	add	x16, x16, #0x28
     6cc:      	br	x17

00000000000006d0 <printf@plt>:
     6d0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6d4:      	ldr	x17, [x16, #0x30]
     6d8:      	add	x16, x16, #0x30
     6dc:      	br	x17

Disassembly of section .text:

0000000000000700 <_start>:
     700:      	nop
     704:      	mov	x29, #0x0               // =0
     708:      	mov	x30, #0x0               // =0
     70c:      	mov	x5, x0
     710:      	ldr	x1, [sp]
     714:      	add	x2, sp, #0x8
     718:      	mov	x6, sp
     71c:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e398>
     720:      	ldr	x0, [x0, #0xfd8]
     724:      	mov	x3, #0x0                // =0
     728:      	mov	x4, #0x0                // =0
     72c:      	bl	0x680 <__libc_start_main@plt>
     730:      	bl	0x6c0 <abort@plt>

0000000000000734 <call_weak_fn>:
     734:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e398>
     738:      	ldr	x0, [x0, #0xfd0]
     73c:      	cbz	x0, 0x744 <call_weak_fn+0x10>
     740:      	b	0x6b0 <__gmon_start__@plt>
     744:      	ret
     748:      	nop
     74c:      	nop

0000000000000750 <deregister_tm_clones>:
     750:      	adrp	x0, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     754:      	add	x0, x0, #0x48
     758:      	adrp	x1, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     75c:      	add	x1, x1, #0x48
     760:      	cmp	x1, x0
     764:      	b.eq	0x77c <deregister_tm_clones+0x2c>
     768:      	adrp	x1, 0x1f000 <__FRAME_END__+0x1e398>
     76c:      	ldr	x1, [x1, #0xfc0]
     770:      	cbz	x1, 0x77c <deregister_tm_clones+0x2c>
     774:      	mov	x16, x1
     778:      	br	x16
     77c:      	ret

0000000000000780 <register_tm_clones>:
     780:      	adrp	x0, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     784:      	add	x0, x0, #0x48
     788:      	adrp	x1, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     78c:      	add	x1, x1, #0x48
     790:      	sub	x1, x1, x0
     794:      	lsr	x2, x1, #63
     798:      	add	x1, x2, x1, asr #3
     79c:      	asr	x1, x1, #1
     7a0:      	cbz	x1, 0x7b8 <register_tm_clones+0x38>
     7a4:      	adrp	x2, 0x1f000 <__FRAME_END__+0x1e398>
     7a8:      	ldr	x2, [x2, #0xfe0]
     7ac:      	cbz	x2, 0x7b8 <register_tm_clones+0x38>
     7b0:      	mov	x16, x2
     7b4:      	br	x16
     7b8:      	ret
     7bc:      	nop

00000000000007c0 <__do_global_dtors_aux>:
     7c0:      	paciasp
     7c4:      	stp	x29, x30, [sp, #-0x20]!
     7c8:      	mov	x29, sp
     7cc:      	str	x19, [sp, #0x10]
     7d0:      	adrp	x19, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     7d4:      	ldrb	w0, [x19, #0x48]
     7d8:      	tbnz	w0, #0x0, 0x800 <__do_global_dtors_aux+0x40>
     7dc:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e398>
     7e0:      	ldr	x0, [x0, #0xfc8]
     7e4:      	cbz	x0, 0x7f4 <__do_global_dtors_aux+0x34>
     7e8:      	adrp	x0, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     7ec:      	ldr	x0, [x0, #0x40]
     7f0:      	bl	0x690 <__cxa_finalize@plt>
     7f4:      	bl	0x750 <deregister_tm_clones>
     7f8:      	mov	w0, #0x1                // =1
     7fc:      	strb	w0, [x19, #0x48]
     800:      	ldr	x19, [sp, #0x10]
     804:      	ldp	x29, x30, [sp], #0x20
     808:      	autiasp
     80c:      	ret

0000000000000810 <frame_dummy>:
     810:      	bti	c
     814:      	b	0x780 <register_tm_clones>

0000000000000818 <main>:
     818:      	cmp	w0, #0x3
     81c:      	b.ne	0xa24 <main+0x20c>
     820:      	sub	sp, sp, #0x80
     824:      	stp	x29, x30, [sp, #0x20]
     828:      	stp	x28, x27, [sp, #0x30]
     82c:      	stp	x26, x25, [sp, #0x40]
     830:      	stp	x24, x23, [sp, #0x50]
     834:      	stp	x22, x21, [sp, #0x60]
     838:      	stp	x20, x19, [sp, #0x70]
     83c:      	add	x29, sp, #0x20
     840:      	ldr	x0, [x1, #0x8]
     844:      	mov	x19, x1
     848:      	mov	x1, xzr
     84c:      	mov	w2, #0xa                // =10
     850:      	bl	0x670 <strtoul@plt>
     854:      	ldr	x8, [x19, #0x10]
     858:      	mov	x20, x0
     85c:      	mov	x1, xzr
     860:      	mov	w2, #0xa                // =10
     864:      	mov	x0, x8
     868:      	bl	0x670 <strtoul@plt>
     86c:      	mov	x21, x0
     870:      	add	x1, sp, #0x10
     874:      	mov	w0, #0x1                // =1
     878:      	bl	0x6a0 <clock_gettime@plt>
     87c:      	cbnz	w0, 0xa68 <main+0x250>
     880:      	adrp	x23, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     884:      	adrp	x25, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     888:      	adrp	x22, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     88c:      	adrp	x26, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     890:      	cbz	x20, 0xa54 <main+0x23c>
     894:      	mov	w9, #0x23c7             // =9159
     898:      	ldr	w24, [x23, #0x50]
     89c:      	ldr	w22, [x26, #0x4c]
     8a0:      	ldr	w7, [x25, #0x54]
     8a4:      	mov	w12, #0xa4f5            // =42229
     8a8:      	mov	w13, #0xadf7            // =44535
     8ac:      	mov	w14, #0xd3e2            // =54242
     8b0:      	mov	w18, #0xae4b            // =44619
     8b4:      	mov	w0, #0x9889             // =39049
     8b8:      	mov	w1, #0xfd48             // =64840
     8bc:      	mov	w2, #0x2b8              // =696
     8c0:      	mov	w3, #0xd49d             // =54429
     8c4:      	mov	w4, #0xad8              // =2776
     8c8:      	mov	w5, #0x46b              // =1131
     8cc:      	mov	w6, #0x519f             // =20895
     8d0:      	mov	w26, #0x8843            // =34883
     8d4:      	mov	w27, #0x4fa3            // =20387
     8d8:      	mov	w28, #0xeee9            // =61161
     8dc:      	mov	w30, #0x5c0b            // =23563
     8e0:      	mov	x8, xzr
     8e4:      	mov	w19, wzr
     8e8:      	movk	w9, #0xf25f, lsl #16
     8ec:      	movk	w12, #0x3d0d, lsl #16
     8f0:      	movk	w13, #0xec1, lsl #16
     8f4:      	movk	w14, #0x55f5, lsl #16
     8f8:      	movk	w18, #0xfbd3, lsl #16
     8fc:      	movk	w0, #0x14dd, lsl #16
     900:      	movk	w1, #0x3357, lsl #16
     904:      	movk	w2, #0xcca8, lsl #16
     908:      	movk	w3, #0x2188, lsl #16
     90c:      	movk	w4, #0xcf0a, lsl #16
     910:      	movk	w5, #0xe5f2, lsl #16
     914:      	movk	w6, #0x94ed, lsl #16
     918:      	movk	w26, #0x11f0, lsl #16
     91c:      	movk	w27, #0x7ea2, lsl #16
     920:      	movk	w28, #0x7be6, lsl #16
     924:      	movk	w30, #0xe278, lsl #16
     928:      	b	0x95c <main+0x144>
     92c:      	add	w19, w25, w19
     930:      	mul	w10, w21, w28
     934:      	add	x8, x8, #0x1
     938:      	madd	w10, w19, w27, w10
     93c:      	cmp	x8, x20
     940:      	mov	w7, #0x11               // =17
     944:      	mul	w15, w10, w30
     948:      	add	w10, w24, w24, lsl #5
     94c:      	add	w11, w15, #0x33
     950:      	add	w24, w15, #0x22
     954:      	eor	w22, w10, w11
     958:      	b.eq	0xa2c <main+0x214>
     95c:      	eor	w15, w21, w21, lsl #13
     960:      	mov	x10, #-0x3333333333333334 // =-3689348814741910324
     964:      	mul	w25, w24, w9
     968:      	movk	x10, #0xcccd
     96c:      	eor	w15, w15, w15, lsr #17
     970:      	umulh	x23, x8, x10
     974:      	mov	w10, #0xa               // =10
     978:      	eor	w21, w15, w15, lsl #5
     97c:      	madd	w15, w21, w9, w25
     980:      	lsr	x23, x23, #3
     984:      	add	w15, w15, w12
     988:      	msub	w23, w23, w10, w8
     98c:      	add	w16, w15, w15, lsl #1
     990:      	sub	w16, w16, w25
     994:      	cmp	w23, #0x2
     998:      	madd	w25, w16, w13, w14
     99c:      	add	w16, w22, w22, lsl #5
     9a0:      	add	w22, w24, w21
     9a4:      	eor	w24, w16, w22
     9a8:      	b.lo	0x92c <main+0x114>
     9ac:      	mov	w10, #0x51b5            // =20917
     9b0:      	mov	w11, #0x50ca            // =20682
     9b4:      	movk	w10, #0x42c, lsl #16
     9b8:      	movk	w11, #0x81b1, lsl #16
     9bc:      	mul	w22, w22, w10
     9c0:      	mov	w10, #0x73e9            // =29673
     9c4:      	movk	w10, #0x6c4d, lsl #16
     9c8:      	madd	w15, w15, w10, w11
     9cc:      	add	w7, w7, w25
     9d0:      	add	w24, w24, w24, lsl #5
     9d4:      	sub	w23, w23, #0x1
     9d8:      	add	w16, w7, w25
     9dc:      	cmp	w23, #0x1
     9e0:      	madd	w15, w16, w0, w15
     9e4:      	add	w10, w16, w25
     9e8:      	eor	w24, w24, w25
     9ec:      	madd	w17, w16, w18, w22
     9f0:      	mul	w10, w10, w5
     9f4:      	add	w15, w15, w1
     9f8:      	add	w17, w17, w2
     9fc:      	madd	w11, w15, w3, w4
     a00:      	add	w15, w17, w15
     a04:      	add	w17, w24, w24, lsl #5
     a08:      	madd	w10, w15, w6, w10
     a0c:      	eor	w11, w17, w11
     a10:      	mul	w25, w10, w26
     a14:      	add	w10, w11, w11, lsl #5
     a18:      	eor	w24, w10, w16
     a1c:      	b.hi	0x9cc <main+0x1b4>
     a20:      	b	0x92c <main+0x114>
     a24:      	mov	w0, #0x2                // =2
     a28:      	ret
     a2c:      	adrp	x26, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     a30:      	adrp	x23, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     a34:      	add	w8, w15, #0x3a
     a38:      	str	w22, [x26, #0x4c]
     a3c:      	adrp	x25, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     a40:      	adrp	x22, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     a44:      	str	w24, [x23, #0x50]
     a48:      	str	w7, [x25, #0x54]
     a4c:      	str	w8, [x22, #0x58]
     a50:      	b	0xa58 <main+0x240>
     a54:      	mov	w19, wzr
     a58:      	mov	x1, sp
     a5c:      	mov	w0, #0x1                // =1
     a60:      	bl	0x6a0 <clock_gettime@plt>
     a64:      	cbz	w0, 0xa8c <main+0x274>
     a68:      	mov	w0, #0x2                // =2
     a6c:      	ldp	x20, x19, [sp, #0x70]
     a70:      	ldp	x22, x21, [sp, #0x60]
     a74:      	ldp	x24, x23, [sp, #0x50]
     a78:      	ldp	x26, x25, [sp, #0x40]
     a7c:      	ldp	x28, x27, [sp, #0x30]
     a80:      	ldp	x29, x30, [sp, #0x20]
     a84:      	add	sp, sp, #0x80
     a88:      	ret
     a8c:      	ldp	x8, x9, [sp]
     a90:      	adrp	x0, 0x0 <strtoul@GLIBC_2.17>
     a94:      	add	x0, x0, #0xb00
     a98:      	ldp	x10, x11, [sp, #0x10]
     a9c:      	ldr	w2, [x23, #0x50]
     aa0:      	ldr	w3, [x25, #0x54]
     aa4:      	mov	w1, w19
     aa8:      	ldr	w4, [x22, #0x58]
     aac:      	ldr	w5, [x26, #0x4c]
     ab0:      	sub	x8, x8, x10
     ab4:      	sub	x9, x9, x11
     ab8:      	scvtf	d0, x8
     abc:      	scvtf	d1, x9
     ac0:      	adrp	x8, 0x0 <strtoul@GLIBC_2.17>
     ac4:      	ldr	d2, [x8, #0xaf8]
     ac8:      	fmadd	d0, d1, d2, d0
     acc:      	bl	0x6d0 <printf@plt>
     ad0:      	mov	w0, wzr
     ad4:      	b	0xa6c <main+0x254>

Disassembly of section .fini:

0000000000000ad8 <_fini>:
     ad8:      	nop
     adc:      	stp	x29, x30, [sp, #-0x10]!
     ae0:      	mov	x29, sp
     ae4:      	ldp	x29, x30, [sp], #0x10
     ae8:      	ret
