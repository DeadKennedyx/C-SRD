
/work/experiments/runs/private-declarations-cost-linux-20261110/clang-O2-lto/original:	file format elf64-littleaarch64

Disassembly of section .init:

0000000000000638 <_init>:
     638:      	nop
     63c:      	stp	x29, x30, [sp, #-0x10]!
     640:      	mov	x29, sp
     644:      	bl	0x734 <call_weak_fn>
     648:      	ldp	x29, x30, [sp], #0x10
     64c:      	ret

Disassembly of section .plt:

0000000000000650 <.plt>:
     650:      	stp	x16, x30, [sp, #-0x10]!
     654:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e484>
     658:      	ldr	x17, [x16, #0xff8]
     65c:      	add	x16, x16, #0xff8
     660:      	br	x17
     664:      	nop
     668:      	nop
     66c:      	nop

0000000000000670 <strtoul@plt>:
     670:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     674:      	ldr	x17, [x16]
     678:      	add	x16, x16, #0x0
     67c:      	br	x17

0000000000000680 <__libc_start_main@plt>:
     680:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     684:      	ldr	x17, [x16, #0x8]
     688:      	add	x16, x16, #0x8
     68c:      	br	x17

0000000000000690 <__cxa_finalize@plt>:
     690:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     694:      	ldr	x17, [x16, #0x10]
     698:      	add	x16, x16, #0x10
     69c:      	br	x17

00000000000006a0 <clock_gettime@plt>:
     6a0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6a4:      	ldr	x17, [x16, #0x18]
     6a8:      	add	x16, x16, #0x18
     6ac:      	br	x17

00000000000006b0 <__gmon_start__@plt>:
     6b0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6b4:      	ldr	x17, [x16, #0x20]
     6b8:      	add	x16, x16, #0x20
     6bc:      	br	x17

00000000000006c0 <abort@plt>:
     6c0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6c4:      	ldr	x17, [x16, #0x28]
     6c8:      	add	x16, x16, #0x28
     6cc:      	br	x17

00000000000006d0 <printf@plt>:
     6d0:      	adrp	x16, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     6d4:      	ldr	x17, [x16, #0x30]
     6d8:      	add	x16, x16, #0x30
     6dc:      	br	x17

Disassembly of section .text:

0000000000000700 <_start>:
     700:      	nop
     704:      	mov	x29, #0x0               // =0
     708:      	mov	x30, #0x0               // =0
     70c:      	mov	x5, x0
     710:      	ldr	x1, [sp]
     714:      	add	x2, sp, #0x8
     718:      	mov	x6, sp
     71c:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e484>
     720:      	ldr	x0, [x0, #0xfd8]
     724:      	mov	x3, #0x0                // =0
     728:      	mov	x4, #0x0                // =0
     72c:      	bl	0x680 <__libc_start_main@plt>
     730:      	bl	0x6c0 <abort@plt>

0000000000000734 <call_weak_fn>:
     734:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e484>
     738:      	ldr	x0, [x0, #0xfd0]
     73c:      	cbz	x0, 0x744 <call_weak_fn+0x10>
     740:      	b	0x6b0 <__gmon_start__@plt>
     744:      	ret
     748:      	nop
     74c:      	nop

0000000000000750 <deregister_tm_clones>:
     750:      	adrp	x0, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     754:      	add	x0, x0, #0x48
     758:      	adrp	x1, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     75c:      	add	x1, x1, #0x48
     760:      	cmp	x1, x0
     764:      	b.eq	0x77c <deregister_tm_clones+0x2c>
     768:      	adrp	x1, 0x1f000 <__FRAME_END__+0x1e484>
     76c:      	ldr	x1, [x1, #0xfc0]
     770:      	cbz	x1, 0x77c <deregister_tm_clones+0x2c>
     774:      	mov	x16, x1
     778:      	br	x16
     77c:      	ret

0000000000000780 <register_tm_clones>:
     780:      	adrp	x0, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     784:      	add	x0, x0, #0x48
     788:      	adrp	x1, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     78c:      	add	x1, x1, #0x48
     790:      	sub	x1, x1, x0
     794:      	lsr	x2, x1, #63
     798:      	add	x1, x2, x1, asr #3
     79c:      	asr	x1, x1, #1
     7a0:      	cbz	x1, 0x7b8 <register_tm_clones+0x38>
     7a4:      	adrp	x2, 0x1f000 <__FRAME_END__+0x1e484>
     7a8:      	ldr	x2, [x2, #0xfe0]
     7ac:      	cbz	x2, 0x7b8 <register_tm_clones+0x38>
     7b0:      	mov	x16, x2
     7b4:      	br	x16
     7b8:      	ret
     7bc:      	nop

00000000000007c0 <__do_global_dtors_aux>:
     7c0:      	paciasp
     7c4:      	stp	x29, x30, [sp, #-0x20]!
     7c8:      	mov	x29, sp
     7cc:      	str	x19, [sp, #0x10]
     7d0:      	adrp	x19, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     7d4:      	ldrb	w0, [x19, #0x48]
     7d8:      	tbnz	w0, #0x0, 0x800 <__do_global_dtors_aux+0x40>
     7dc:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e484>
     7e0:      	ldr	x0, [x0, #0xfc8]
     7e4:      	cbz	x0, 0x7f4 <__do_global_dtors_aux+0x34>
     7e8:      	adrp	x0, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     7ec:      	ldr	x0, [x0, #0x40]
     7f0:      	bl	0x690 <__cxa_finalize@plt>
     7f4:      	bl	0x750 <deregister_tm_clones>
     7f8:      	mov	w0, #0x1                // =1
     7fc:      	strb	w0, [x19, #0x48]
     800:      	ldr	x19, [sp, #0x10]
     804:      	ldp	x29, x30, [sp], #0x20
     808:      	autiasp
     80c:      	ret

0000000000000810 <frame_dummy>:
     810:      	bti	c
     814:      	b	0x780 <register_tm_clones>

0000000000000818 <main>:
     818:      	cmp	w0, #0x3
     81c:      	b.ne	0x960 <main+0x148>
     820:      	sub	sp, sp, #0x70
     824:      	stp	x29, x30, [sp, #0x20]
     828:      	str	x25, [sp, #0x30]
     82c:      	stp	x24, x23, [sp, #0x40]
     830:      	stp	x22, x21, [sp, #0x50]
     834:      	stp	x20, x19, [sp, #0x60]
     838:      	add	x29, sp, #0x20
     83c:      	ldr	x0, [x1, #0x8]
     840:      	mov	x19, x1
     844:      	mov	x1, xzr
     848:      	mov	w2, #0xa                // =10
     84c:      	bl	0x670 <strtoul@plt>
     850:      	ldr	x8, [x19, #0x10]
     854:      	mov	x20, x0
     858:      	mov	x1, xzr
     85c:      	mov	w2, #0xa                // =10
     860:      	mov	x0, x8
     864:      	bl	0x670 <strtoul@plt>
     868:      	mov	x21, x0
     86c:      	add	x1, sp, #0x10
     870:      	mov	w0, #0x1                // =1
     874:      	bl	0x6a0 <clock_gettime@plt>
     878:      	cbnz	w0, 0x994 <main+0x17c>
     87c:      	adrp	x22, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     880:      	adrp	x23, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     884:      	adrp	x24, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     888:      	adrp	x25, 0x20000 <_GLOBAL_OFFSET_TABLE_+0x48>
     88c:      	cbz	x20, 0x980 <main+0x168>
     890:      	ldr	w14, [x22, #0x50]
     894:      	ldr	w15, [x25, #0x4c]
     898:      	mov	x9, #-0x3333333333333334 // =-3689348814741910324
     89c:      	ldr	w11, [x23, #0x54]
     8a0:      	mov	x8, xzr
     8a4:      	mov	w19, wzr
     8a8:      	movk	x9, #0xcccd
     8ac:      	mov	w10, #0xa               // =10
     8b0:      	b	0x8e0 <main+0xc8>
     8b4:      	add	w11, w21, w21, lsl #1
     8b8:      	add	w19, w14, w19
     8bc:      	add	w13, w16, w16, lsl #5
     8c0:      	add	x8, x8, #0x1
     8c4:      	add	w11, w11, w19
     8c8:      	cmp	x8, x20
     8cc:      	add	w12, w11, #0x33
     8d0:      	add	w14, w11, #0x22
     8d4:      	mov	w11, #0x11              // =17
     8d8:      	eor	w15, w13, w12
     8dc:      	b.eq	0x968 <main+0x150>
     8e0:      	umulh	x12, x8, x9
     8e4:      	eor	w13, w21, w21, lsl #13
     8e8:      	add	w17, w15, w15, lsl #5
     8ec:      	eor	w13, w13, w13, lsr #17
     8f0:      	eor	w21, w13, w13, lsl #5
     8f4:      	lsr	x12, x12, #3
     8f8:      	add	w13, w14, w21
     8fc:      	msub	w12, w12, w10, w8
     900:      	add	w16, w13, w13, lsl #1
     904:      	add	w15, w16, #0xb
     908:      	eor	w16, w17, w13
     90c:      	cmp	w12, #0x2
     910:      	sub	w14, w15, w14
     914:      	b.lo	0x8b4 <main+0x9c>
     918:      	add	w16, w16, w16, lsl #5
     91c:      	add	w11, w11, w14
     920:      	sub	w12, w12, #0x1
     924:      	add	w17, w11, w14
     928:      	cmp	w12, #0x1
     92c:      	eor	w16, w16, w14
     930:      	add	w18, w17, w17, lsl #2
     934:      	add	w14, w17, w14
     938:      	add	w16, w16, w16, lsl #5
     93c:      	add	w15, w18, w15
     940:      	eor	w16, w16, w15
     944:      	sub	w15, w15, w17
     948:      	add	w16, w16, w16, lsl #5
     94c:      	add	w15, w15, w13
     950:      	add	w14, w14, w15
     954:      	eor	w16, w16, w17
     958:      	b.hi	0x918 <main+0x100>
     95c:      	b	0x8b4 <main+0x9c>
     960:      	mov	w0, #0x2                // =2
     964:      	ret
     968:      	add	w8, w12, #0x7
     96c:      	str	w14, [x22, #0x50]
     970:      	str	w15, [x25, #0x4c]
     974:      	str	w8, [x24, #0x58]
     978:      	str	w11, [x23, #0x54]
     97c:      	b	0x984 <main+0x16c>
     980:      	mov	w19, wzr
     984:      	mov	x1, sp
     988:      	mov	w0, #0x1                // =1
     98c:      	bl	0x6a0 <clock_gettime@plt>
     990:      	cbz	w0, 0x9b4 <main+0x19c>
     994:      	mov	w0, #0x2                // =2
     998:      	ldp	x20, x19, [sp, #0x60]
     99c:      	ldr	x25, [sp, #0x30]
     9a0:      	ldp	x22, x21, [sp, #0x50]
     9a4:      	ldp	x24, x23, [sp, #0x40]
     9a8:      	ldp	x29, x30, [sp, #0x20]
     9ac:      	add	sp, sp, #0x70
     9b0:      	ret
     9b4:      	ldp	x8, x9, [sp]
     9b8:      	adrp	x0, 0x0 <strtoul@GLIBC_2.17>
     9bc:      	add	x0, x0, #0xa28
     9c0:      	ldp	x10, x11, [sp, #0x10]
     9c4:      	ldr	w2, [x22, #0x50]
     9c8:      	ldr	w3, [x23, #0x54]
     9cc:      	mov	w1, w19
     9d0:      	ldr	w4, [x24, #0x58]
     9d4:      	ldr	w5, [x25, #0x4c]
     9d8:      	sub	x8, x8, x10
     9dc:      	sub	x9, x9, x11
     9e0:      	scvtf	d0, x8
     9e4:      	scvtf	d1, x9
     9e8:      	adrp	x8, 0x0 <strtoul@GLIBC_2.17>
     9ec:      	ldr	d2, [x8, #0xa20]
     9f0:      	fmadd	d0, d1, d2, d0
     9f4:      	bl	0x6d0 <printf@plt>
     9f8:      	mov	w0, wzr
     9fc:      	b	0x998 <main+0x180>

Disassembly of section .fini:

0000000000000a00 <_fini>:
     a00:      	nop
     a04:      	stp	x29, x30, [sp, #-0x10]!
     a08:      	mov	x29, sp
     a0c:      	ldp	x29, x30, [sp], #0x10
     a10:      	ret
