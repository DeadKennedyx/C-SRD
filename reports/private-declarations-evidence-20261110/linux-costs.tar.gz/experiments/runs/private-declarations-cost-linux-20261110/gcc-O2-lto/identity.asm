
/work/experiments/runs/private-declarations-cost-linux-20261110/gcc-O2-lto/identity:	file format elf64-littleaarch64

Disassembly of section .init:

00000000000006f8 <_init>:
     6f8:      	nop
     6fc:      	stp	x29, x30, [sp, #-0x10]!
     700:      	mov	x29, sp
     704:      	bl	0xa34 <call_weak_fn>
     708:      	ldp	x29, x30, [sp], #0x10
     70c:      	ret

Disassembly of section .plt:

0000000000000710 <.plt>:
     710:      	stp	x16, x30, [sp, #-0x10]!
     714:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e3b0>
     718:      	ldr	x17, [x16, #0xf80]
     71c:      	add	x16, x16, #0xf80
     720:      	br	x17
     724:      	nop
     728:      	nop
     72c:      	nop

0000000000000730 <strtoul@plt>:
     730:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e3b0>
     734:      	ldr	x17, [x16, #0xf88]
     738:      	add	x16, x16, #0xf88
     73c:      	br	x17

0000000000000740 <__libc_start_main@plt>:
     740:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e3b0>
     744:      	ldr	x17, [x16, #0xf90]
     748:      	add	x16, x16, #0xf90
     74c:      	br	x17

0000000000000750 <__cxa_finalize@plt>:
     750:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e3b0>
     754:      	ldr	x17, [x16, #0xf98]
     758:      	add	x16, x16, #0xf98
     75c:      	br	x17

0000000000000760 <clock_gettime@plt>:
     760:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e3b0>
     764:      	ldr	x17, [x16, #0xfa0]
     768:      	add	x16, x16, #0xfa0
     76c:      	br	x17

0000000000000770 <__printf_chk@plt>:
     770:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e3b0>
     774:      	ldr	x17, [x16, #0xfa8]
     778:      	add	x16, x16, #0xfa8
     77c:      	br	x17

0000000000000780 <__stack_chk_fail@plt>:
     780:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e3b0>
     784:      	ldr	x17, [x16, #0xfb0]
     788:      	add	x16, x16, #0xfb0
     78c:      	br	x17

0000000000000790 <__gmon_start__@plt>:
     790:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e3b0>
     794:      	ldr	x17, [x16, #0xfb8]
     798:      	add	x16, x16, #0xfb8
     79c:      	br	x17

00000000000007a0 <abort@plt>:
     7a0:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e3b0>
     7a4:      	ldr	x17, [x16, #0xfc0]
     7a8:      	add	x16, x16, #0xfc0
     7ac:      	br	x17

Disassembly of section .text:

00000000000007c0 <main>:
     7c0:      	sub	sp, sp, #0x50
     7c4:      	adrp	x2, 0x1f000 <__FRAME_END__+0x1e3b0>
     7c8:      	ldr	x2, [x2, #0xfe8]
     7cc:      	stp	x29, x30, [sp, #0x30]
     7d0:      	add	x29, sp, #0x30
     7d4:      	stp	x19, x20, [sp, #0x40]
     7d8:      	mov	x19, x1
     7dc:      	ldr	x1, [x2]
     7e0:      	str	x1, [sp, #0x28]
     7e4:      	mov	x1, #0x0                // =0
     7e8:      	cmp	w0, #0x3
     7ec:      	b.eq	0x824 <main+0x64>
     7f0:      	mov	w20, #0x2               // =2
     7f4:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e3b0>
     7f8:      	ldr	x0, [x0, #0xfe8]
     7fc:      	ldr	x2, [sp, #0x28]
     800:      	ldr	x1, [x0]
     804:      	subs	x2, x2, x1
     808:      	mov	x1, #0x0                // =0
     80c:      	b.ne	0x9c8 <main+0x208>
     810:      	ldp	x29, x30, [sp, #0x30]
     814:      	mov	w0, w20
     818:      	ldp	x19, x20, [sp, #0x40]
     81c:      	add	sp, sp, #0x50
     820:      	ret
     824:      	ldr	x0, [x19, #0x8]
     828:      	mov	w2, #0xa                // =10
     82c:      	mov	x1, #0x0                // =0
     830:      	bl	0x730 <strtoul@plt>
     834:      	mov	x20, x0
     838:      	ldr	x0, [x19, #0x10]
     83c:      	mov	w2, #0xa                // =10
     840:      	mov	x1, #0x0                // =0
     844:      	bl	0x730 <strtoul@plt>
     848:      	mov	x19, x0
     84c:      	add	x1, sp, #0x18
     850:      	mov	w0, #0x1                // =1
     854:      	bl	0x760 <clock_gettime@plt>
     858:      	cbnz	w0, 0x7f0 <main+0x30>
     85c:      	cbz	x20, 0x9c0 <main+0x200>
     860:      	adrp	x10, 0x20000 <data_start>
     864:      	add	x0, x10, #0x18
     868:      	mov	x9, #-0x3333333333333334 // =-3689348814741910324
     86c:      	mov	w11, w19
     870:      	ldr	w1, [x10, #0x18]
     874:      	mov	x8, #0x0                // =0
     878:      	ldp	w3, w0, [x0, #0x8]
     87c:      	mov	w19, #0x0               // =0
     880:      	movk	x9, #0xcccd
     884:      	nop
     888:      	eor	w11, w11, w11, lsl #13
     88c:      	umulh	x6, x8, x9
     890:      	add	w1, w1, w1, lsl #5
     894:      	eor	w11, w11, w11, lsr #17
     898:      	lsr	x6, x6, #3
     89c:      	eor	w11, w11, w11, lsl #5
     8a0:      	add	w12, w11, w3
     8a4:      	add	x6, x6, x6, lsl #2
     8a8:      	eor	w1, w1, w12
     8ac:      	add	w4, w12, w12, lsl #1
     8b0:      	sub	x6, x8, x6, lsl #1
     8b4:      	add	w4, w4, #0xb
     8b8:      	sub	w2, w6, #0x1
     8bc:      	sub	w3, w4, w3
     8c0:      	cbz	w6, 0x914 <main+0x154>
     8c4:      	sub	w6, w6, #0x2
     8c8:      	cbz	w2, 0x914 <main+0x154>
     8cc:      	nop
     8d0:      	add	w0, w0, w3
     8d4:      	add	w1, w1, w1, lsl #5
     8d8:      	add	w5, w3, w0
     8dc:      	eor	w1, w1, w3
     8e0:      	sub	w2, w12, w5
     8e4:      	add	w3, w3, w5
     8e8:      	add	w7, w5, w5, lsl #2
     8ec:      	add	w1, w1, w1, lsl #5
     8f0:      	add	w4, w7, w4
     8f4:      	sub	w6, w6, #0x1
     8f8:      	eor	w1, w1, w4
     8fc:      	add	w4, w2, w4
     900:      	add	w3, w3, w4
     904:      	add	w1, w1, w1, lsl #5
     908:      	eor	w1, w1, w5
     90c:      	cmn	w6, #0x1
     910:      	b.ne	0x8d0 <main+0x110>
     914:      	add	w2, w11, #0x11
     918:      	add	w19, w19, w3
     91c:      	add	w1, w1, w1, lsl #5
     920:      	add	x8, x8, #0x1
     924:      	add	w2, w2, w2, lsl #1
     928:      	mov	w0, #0x11               // =17
     92c:      	add	w2, w2, w19
     930:      	eor	w1, w1, w2
     934:      	sub	w3, w2, #0x11
     938:      	cmp	x20, x8
     93c:      	b.ne	0x888 <main+0xc8>
     940:      	add	x5, x10, #0x18
     944:      	add	w2, w2, #0x7
     948:      	str	w1, [x10, #0x18]
     94c:      	stp	w3, w0, [x5, #0x8]
     950:      	str	w2, [x5, #0x10]
     954:      	add	x1, sp, #0x8
     958:      	mov	w0, #0x1                // =1
     95c:      	bl	0x760 <clock_gettime@plt>
     960:      	mov	w20, w0
     964:      	cbnz	w0, 0x7f0 <main+0x30>
     968:      	adrp	x1, 0x0 <strtoul@GLIBC_2.17>
     96c:      	adrp	x3, 0x20000 <data_start>
     970:      	ldp	x4, x2, [sp, #0x18]
     974:      	ldr	d1, [x1, #0xb50]
     978:      	ldp	x1, x0, [sp, #0x8]
     97c:      	ldr	w6, [x3, #0x18]
     980:      	sub	x0, x0, x2
     984:      	add	x2, x3, #0x18
     988:      	add	x5, x2, #0x8
     98c:      	scvtf	d0, x0
     990:      	sub	x0, x1, x4
     994:      	ldr	w3, [x2, #0x8]
     998:      	adrp	x1, 0x0 <strtoul@GLIBC_2.17>
     99c:      	ldp	w4, w5, [x5, #0x4]
     9a0:      	add	x1, x1, #0xb38
     9a4:      	fmul	d0, d0, d1
     9a8:      	scvtf	d1, x0
     9ac:      	mov	w2, w19
     9b0:      	mov	w0, #0x2                // =2
     9b4:      	fadd	d0, d0, d1
     9b8:      	bl	0x770 <__printf_chk@plt>
     9bc:      	b	0x7f4 <main+0x34>
     9c0:      	mov	w19, #0x0               // =0
     9c4:      	b	0x954 <main+0x194>
     9c8:      	bl	0x780 <__stack_chk_fail@plt>
     9cc:      	nop
     9d0:      	nop
     9d4:      	nop
     9d8:      	nop
     9dc:      	nop
     9e0:      	nop
     9e4:      	nop
     9e8:      	nop
     9ec:      	nop
     9f0:      	nop
     9f4:      	nop
     9f8:      	nop
     9fc:      	nop

0000000000000a00 <_start>:
     a00:      	nop
     a04:      	mov	x29, #0x0               // =0
     a08:      	mov	x30, #0x0               // =0
     a0c:      	mov	x5, x0
     a10:      	ldr	x1, [sp]
     a14:      	add	x2, sp, #0x8
     a18:      	mov	x6, sp
     a1c:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e3b0>
     a20:      	ldr	x0, [x0, #0xff0]
     a24:      	mov	x3, #0x0                // =0
     a28:      	mov	x4, #0x0                // =0
     a2c:      	bl	0x740 <__libc_start_main@plt>
     a30:      	bl	0x7a0 <abort@plt>

0000000000000a34 <call_weak_fn>:
     a34:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e3b0>
     a38:      	ldr	x0, [x0, #0xfe0]
     a3c:      	cbz	x0, 0xa44 <call_weak_fn+0x10>
     a40:      	b	0x790 <__gmon_start__@plt>
     a44:      	ret
     a48:      	nop
     a4c:      	nop

0000000000000a50 <deregister_tm_clones>:
     a50:      	adrp	x0, 0x20000 <data_start>
     a54:      	add	x0, x0, #0x10
     a58:      	adrp	x1, 0x20000 <data_start>
     a5c:      	add	x1, x1, #0x10
     a60:      	cmp	x1, x0
     a64:      	b.eq	0xa7c <deregister_tm_clones+0x2c>
     a68:      	adrp	x1, 0x1f000 <__FRAME_END__+0x1e3b0>
     a6c:      	ldr	x1, [x1, #0xfd0]
     a70:      	cbz	x1, 0xa7c <deregister_tm_clones+0x2c>
     a74:      	mov	x16, x1
     a78:      	br	x16
     a7c:      	ret

0000000000000a80 <register_tm_clones>:
     a80:      	adrp	x0, 0x20000 <data_start>
     a84:      	add	x0, x0, #0x10
     a88:      	adrp	x1, 0x20000 <data_start>
     a8c:      	add	x1, x1, #0x10
     a90:      	sub	x1, x1, x0
     a94:      	lsr	x2, x1, #63
     a98:      	add	x1, x2, x1, asr #3
     a9c:      	asr	x1, x1, #1
     aa0:      	cbz	x1, 0xab8 <register_tm_clones+0x38>
     aa4:      	adrp	x2, 0x1f000 <__FRAME_END__+0x1e3b0>
     aa8:      	ldr	x2, [x2, #0xff8]
     aac:      	cbz	x2, 0xab8 <register_tm_clones+0x38>
     ab0:      	mov	x16, x2
     ab4:      	br	x16
     ab8:      	ret
     abc:      	nop

0000000000000ac0 <__do_global_dtors_aux>:
     ac0:      	paciasp
     ac4:      	stp	x29, x30, [sp, #-0x20]!
     ac8:      	mov	x29, sp
     acc:      	str	x19, [sp, #0x10]
     ad0:      	adrp	x19, 0x20000 <data_start>
     ad4:      	ldrb	w0, [x19, #0x10]
     ad8:      	tbnz	w0, #0x0, 0xb00 <__do_global_dtors_aux+0x40>
     adc:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e3b0>
     ae0:      	ldr	x0, [x0, #0xfd8]
     ae4:      	cbz	x0, 0xaf4 <__do_global_dtors_aux+0x34>
     ae8:      	adrp	x0, 0x20000 <data_start>
     aec:      	ldr	x0, [x0, #0x8]
     af0:      	bl	0x750 <__cxa_finalize@plt>
     af4:      	bl	0xa50 <deregister_tm_clones>
     af8:      	mov	w0, #0x1                // =1
     afc:      	strb	w0, [x19, #0x10]
     b00:      	ldr	x19, [sp, #0x10]
     b04:      	ldp	x29, x30, [sp], #0x20
     b08:      	autiasp
     b0c:      	ret

0000000000000b10 <frame_dummy>:
     b10:      	bti	c
     b14:      	b	0xa80 <register_tm_clones>

Disassembly of section .fini:

0000000000000b18 <_fini>:
     b18:      	nop
     b1c:      	stp	x29, x30, [sp, #-0x10]!
     b20:      	mov	x29, sp
     b24:      	ldp	x29, x30, [sp], #0x10
     b28:      	ret
