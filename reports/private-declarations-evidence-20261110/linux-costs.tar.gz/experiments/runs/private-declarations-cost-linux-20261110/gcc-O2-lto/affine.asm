
/work/experiments/runs/private-declarations-cost-linux-20261110/gcc-O2-lto/affine:	file format elf64-littleaarch64

Disassembly of section .init:

00000000000006f8 <_init>:
     6f8:      	nop
     6fc:      	stp	x29, x30, [sp, #-0x10]!
     700:      	mov	x29, sp
     704:      	bl	0xb34 <call_weak_fn>
     708:      	ldp	x29, x30, [sp], #0x10
     70c:      	ret

Disassembly of section .plt:

0000000000000710 <.plt>:
     710:      	stp	x16, x30, [sp, #-0x10]!
     714:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e26c>
     718:      	ldr	x17, [x16, #0xf80]
     71c:      	add	x16, x16, #0xf80
     720:      	br	x17
     724:      	nop
     728:      	nop
     72c:      	nop

0000000000000730 <strtoul@plt>:
     730:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e26c>
     734:      	ldr	x17, [x16, #0xf88]
     738:      	add	x16, x16, #0xf88
     73c:      	br	x17

0000000000000740 <__libc_start_main@plt>:
     740:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e26c>
     744:      	ldr	x17, [x16, #0xf90]
     748:      	add	x16, x16, #0xf90
     74c:      	br	x17

0000000000000750 <__cxa_finalize@plt>:
     750:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e26c>
     754:      	ldr	x17, [x16, #0xf98]
     758:      	add	x16, x16, #0xf98
     75c:      	br	x17

0000000000000760 <clock_gettime@plt>:
     760:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e26c>
     764:      	ldr	x17, [x16, #0xfa0]
     768:      	add	x16, x16, #0xfa0
     76c:      	br	x17

0000000000000770 <__printf_chk@plt>:
     770:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e26c>
     774:      	ldr	x17, [x16, #0xfa8]
     778:      	add	x16, x16, #0xfa8
     77c:      	br	x17

0000000000000780 <__stack_chk_fail@plt>:
     780:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e26c>
     784:      	ldr	x17, [x16, #0xfb0]
     788:      	add	x16, x16, #0xfb0
     78c:      	br	x17

0000000000000790 <__gmon_start__@plt>:
     790:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e26c>
     794:      	ldr	x17, [x16, #0xfb8]
     798:      	add	x16, x16, #0xfb8
     79c:      	br	x17

00000000000007a0 <abort@plt>:
     7a0:      	adrp	x16, 0x1f000 <__FRAME_END__+0x1e26c>
     7a4:      	ldr	x17, [x16, #0xfc0]
     7a8:      	add	x16, x16, #0xfc0
     7ac:      	br	x17

Disassembly of section .text:

00000000000007c0 <main>:
     7c0:      	sub	sp, sp, #0x90
     7c4:      	adrp	x2, 0x1f000 <__FRAME_END__+0x1e26c>
     7c8:      	ldr	x2, [x2, #0xfe8]
     7cc:      	stp	x29, x30, [sp, #0x30]
     7d0:      	add	x29, sp, #0x30
     7d4:      	stp	x19, x20, [sp, #0x40]
     7d8:      	mov	x19, x1
     7dc:      	ldr	x1, [x2]
     7e0:      	str	x1, [sp, #0x28]
     7e4:      	mov	x1, #0x0                // =0
     7e8:      	cmp	w0, #0x3
     7ec:      	b.eq	0x824 <main+0x64>
     7f0:      	mov	w19, #0x2               // =2
     7f4:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e26c>
     7f8:      	ldr	x0, [x0, #0xfe8]
     7fc:      	ldr	x2, [sp, #0x28]
     800:      	ldr	x1, [x0]
     804:      	subs	x2, x2, x1
     808:      	mov	x1, #0x0                // =0
     80c:      	b.ne	0xae4 <main+0x324>
     810:      	ldp	x29, x30, [sp, #0x30]
     814:      	mov	w0, w19
     818:      	ldp	x19, x20, [sp, #0x40]
     81c:      	add	sp, sp, #0x90
     820:      	ret
     824:      	ldr	x0, [x19, #0x8]
     828:      	mov	w2, #0xa                // =10
     82c:      	mov	x1, #0x0                // =0
     830:      	stp	x21, x22, [sp, #0x50]
     834:      	bl	0x730 <strtoul@plt>
     838:      	mov	x21, x0
     83c:      	ldr	x0, [x19, #0x10]
     840:      	mov	w2, #0xa                // =10
     844:      	mov	x1, #0x0                // =0
     848:      	bl	0x730 <strtoul@plt>
     84c:      	mov	x19, x0
     850:      	add	x1, sp, #0x18
     854:      	mov	w0, #0x1                // =1
     858:      	bl	0x760 <clock_gettime@plt>
     85c:      	cbnz	w0, 0xad4 <main+0x314>
     860:      	cbz	x21, 0xadc <main+0x31c>
     864:      	adrp	x0, 0x20000 <data_start>
     868:      	adrp	x1, 0x20000 <data_start>
     86c:      	add	x0, x0, #0x18
     870:      	stp	x23, x24, [sp, #0x60]
     874:      	ldr	w4, [x1, #0x18]
     878:      	mov	w24, #0x39af            // =14767
     87c:      	mov	w22, #0x86a1            // =34465
     880:      	movk	w24, #0x3598, lsl #16
     884:      	mov	w2, #0xdd61             // =56673
     888:      	mov	w23, #0x2dcc            // =11724
     88c:      	mov	w8, #0xe9ef             // =59887
     890:      	mov	w12, #0x9979            // =39289
     894:      	mov	w11, #0x650f            // =25871
     898:      	mov	w30, #0x89d2            // =35282
     89c:      	mov	w18, #0x44e9            // =17641
     8a0:      	mov	w17, #0x7985            // =31109
     8a4:      	mov	w16, #0xb5b4            // =46516
     8a8:      	mov	w15, #0x802b            // =32811
     8ac:      	mov	w14, #0x3e83            // =16003
     8b0:      	mov	w13, #0xf6b6            // =63158
     8b4:      	stp	x25, x26, [sp, #0x70]
     8b8:      	mov	x25, #-0x3333333333333334 // =-3689348814741910324
     8bc:      	add	w26, w24, #0x11
     8c0:      	stp	x27, x28, [sp, #0x80]
     8c4:      	mov	w3, w19
     8c8:      	ldp	w27, w7, [x0, #0x8]
     8cc:      	mov	w0, #0x9a1c             // =39452
     8d0:      	mov	x19, #0x0               // =0
     8d4:      	mov	w20, #0x0               // =0
     8d8:      	movk	x25, #0xcccd
     8dc:      	movk	w22, #0x487e, lsl #16
     8e0:      	movk	w2, #0x3c16, lsl #16
     8e4:      	movk	w23, #0xa04a, lsl #16
     8e8:      	movk	w8, #0xf824, lsl #16
     8ec:      	movk	w12, #0xc389, lsl #16
     8f0:      	movk	w11, #0x4a25, lsl #16
     8f4:      	movk	w30, #0x31cc, lsl #16
     8f8:      	movk	w18, #0x18e6, lsl #16
     8fc:      	movk	w17, #0x9a24, lsl #16
     900:      	movk	w16, #0x73a3, lsl #16
     904:      	movk	w15, #0x95b, lsl #16
     908:      	movk	w14, #0x32e9, lsl #16
     90c:      	movk	w13, #0xd630, lsl #16
     910:      	movk	w0, #0xf1d9, lsl #16
     914:      	nop
     918:      	eor	w3, w3, w3, lsl #13
     91c:      	mov	w1, #0x6ab4             // =27316
     920:      	movk	w1, #0x72f8, lsl #16
     924:      	umulh	x5, x19, x25
     928:      	eor	w3, w3, w3, lsr #17
     92c:      	add	w4, w4, w4, lsl #5
     930:      	madd	w10, w27, w22, w1
     934:      	mov	w27, #0xf383            // =62339
     938:      	eor	w3, w3, w3, lsl #5
     93c:      	lsr	x5, x5, #3
     940:      	movk	w27, #0x377e, lsl #16
     944:      	add	x5, x5, x5, lsl #2
     948:      	madd	w9, w3, w22, w10
     94c:      	sub	x5, x19, x5, lsl #1
     950:      	sub	w6, w5, #0x1
     954:      	add	w1, w9, w9, lsl #1
     958:      	add	w1, w1, w27
     95c:      	madd	w9, w9, w2, w23
     960:      	sub	w10, w1, w10
     964:      	eor	w4, w4, w9
     968:      	mul	w27, w10, w2
     96c:      	cbz	w5, 0x9e8 <main+0x228>
     970:      	sub	w5, w5, #0x2
     974:      	cbz	w6, 0x9e8 <main+0x228>
     978:      	mov	w6, #0x32f2             // =13042
     97c:      	madd	w1, w1, w2, w23
     980:      	movk	w6, #0x8713, lsl #16
     984:      	madd	w9, w9, w8, w6
     988:      	add	w7, w7, w27
     98c:      	madd	w28, w27, w8, w12
     990:      	add	w10, w27, w7
     994:      	add	w4, w4, w4, lsl #5
     998:      	eor	w4, w4, w27
     99c:      	sub	w5, w5, #0x1
     9a0:      	madd	w6, w10, w8, w12
     9a4:      	add	w4, w4, w4, lsl #5
     9a8:      	add	w27, w28, w6
     9ac:      	sub	w28, w9, w6
     9b0:      	add	w6, w6, w6, lsl #2
     9b4:      	add	w6, w6, w0
     9b8:      	madd	w27, w27, w17, w16
     9bc:      	madd	w6, w1, w8, w6
     9c0:      	add	w28, w28, w6
     9c4:      	madd	w6, w6, w11, w18
     9c8:      	madd	w1, w28, w11, w30
     9cc:      	eor	w4, w4, w6
     9d0:      	add	w4, w4, w4, lsl #5
     9d4:      	madd	w27, w1, w15, w27
     9d8:      	eor	w4, w4, w10
     9dc:      	madd	w27, w27, w14, w13
     9e0:      	cmn	w5, #0x1
     9e4:      	b.ne	0x988 <main+0x1c8>
     9e8:      	mov	w1, #0x8cd3             // =36051
     9ec:      	mov	w5, #0x7c43             // =31811
     9f0:      	movk	w5, #0x6316, lsl #16
     9f4:      	movk	w1, #0xd4fc, lsl #16
     9f8:      	add	w20, w20, w27
     9fc:      	add	w4, w4, w4, lsl #5
     a00:      	madd	w1, w3, w1, w5
     a04:      	mov	w5, #0x2ef1             // =12017
     a08:      	movk	w5, #0x9c54, lsl #16
     a0c:      	add	x19, x19, #0x1
     a10:      	mov	w7, #0x11               // =17
     a14:      	madd	w1, w20, w5, w1
     a18:      	mov	w5, #0x211              // =529
     a1c:      	movk	w5, #0x6cbb, lsl #16
     a20:      	mul	w1, w1, w5
     a24:      	add	w5, w1, w26
     a28:      	add	w27, w1, w24
     a2c:      	eor	w4, w5, w4
     a30:      	cmp	x21, x19
     a34:      	b.ne	0x918 <main+0x158>
     a38:      	adrp	x0, 0x20000 <data_start>
     a3c:      	add	x2, x0, #0x18
     a40:      	ldp	x23, x24, [sp, #0x60]
     a44:      	mov	w3, #0x39c7             // =14791
     a48:      	ldp	x25, x26, [sp, #0x70]
     a4c:      	stp	w27, w7, [x2, #0x8]
     a50:      	ldp	x27, x28, [sp, #0x80]
     a54:      	movk	w3, #0x3598, lsl #16
     a58:      	str	w4, [x0, #0x18]
     a5c:      	add	w1, w1, w3
     a60:      	str	w1, [x2, #0x10]
     a64:      	add	x1, sp, #0x8
     a68:      	mov	w0, #0x1                // =1
     a6c:      	bl	0x760 <clock_gettime@plt>
     a70:      	mov	w19, w0
     a74:      	cbnz	w0, 0xad4 <main+0x314>
     a78:      	adrp	x1, 0x0 <strtoul@GLIBC_2.17>
     a7c:      	adrp	x3, 0x20000 <data_start>
     a80:      	ldp	x4, x2, [sp, #0x18]
     a84:      	ldr	d1, [x1, #0xc50]
     a88:      	ldp	x1, x0, [sp, #0x8]
     a8c:      	ldr	w6, [x3, #0x18]
     a90:      	sub	x0, x0, x2
     a94:      	add	x2, x3, #0x18
     a98:      	add	x5, x2, #0x8
     a9c:      	scvtf	d0, x0
     aa0:      	sub	x0, x1, x4
     aa4:      	ldr	w3, [x2, #0x8]
     aa8:      	adrp	x1, 0x0 <strtoul@GLIBC_2.17>
     aac:      	ldp	w4, w5, [x5, #0x4]
     ab0:      	add	x1, x1, #0xc38
     ab4:      	fmul	d0, d0, d1
     ab8:      	scvtf	d1, x0
     abc:      	mov	w2, w20
     ac0:      	mov	w0, #0x2                // =2
     ac4:      	fadd	d0, d0, d1
     ac8:      	bl	0x770 <__printf_chk@plt>
     acc:      	ldp	x21, x22, [sp, #0x50]
     ad0:      	b	0x7f4 <main+0x34>
     ad4:      	ldp	x21, x22, [sp, #0x50]
     ad8:      	b	0x7f0 <main+0x30>
     adc:      	mov	w20, #0x0               // =0
     ae0:      	b	0xa64 <main+0x2a4>
     ae4:      	stp	x21, x22, [sp, #0x50]
     ae8:      	stp	x23, x24, [sp, #0x60]
     aec:      	stp	x25, x26, [sp, #0x70]
     af0:      	stp	x27, x28, [sp, #0x80]
     af4:      	bl	0x780 <__stack_chk_fail@plt>
     af8:      	nop
     afc:      	nop

0000000000000b00 <_start>:
     b00:      	nop
     b04:      	mov	x29, #0x0               // =0
     b08:      	mov	x30, #0x0               // =0
     b0c:      	mov	x5, x0
     b10:      	ldr	x1, [sp]
     b14:      	add	x2, sp, #0x8
     b18:      	mov	x6, sp
     b1c:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e26c>
     b20:      	ldr	x0, [x0, #0xff0]
     b24:      	mov	x3, #0x0                // =0
     b28:      	mov	x4, #0x0                // =0
     b2c:      	bl	0x740 <__libc_start_main@plt>
     b30:      	bl	0x7a0 <abort@plt>

0000000000000b34 <call_weak_fn>:
     b34:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e26c>
     b38:      	ldr	x0, [x0, #0xfe0]
     b3c:      	cbz	x0, 0xb44 <call_weak_fn+0x10>
     b40:      	b	0x790 <__gmon_start__@plt>
     b44:      	ret
     b48:      	nop
     b4c:      	nop

0000000000000b50 <deregister_tm_clones>:
     b50:      	adrp	x0, 0x20000 <data_start>
     b54:      	add	x0, x0, #0x10
     b58:      	adrp	x1, 0x20000 <data_start>
     b5c:      	add	x1, x1, #0x10
     b60:      	cmp	x1, x0
     b64:      	b.eq	0xb7c <deregister_tm_clones+0x2c>
     b68:      	adrp	x1, 0x1f000 <__FRAME_END__+0x1e26c>
     b6c:      	ldr	x1, [x1, #0xfd0]
     b70:      	cbz	x1, 0xb7c <deregister_tm_clones+0x2c>
     b74:      	mov	x16, x1
     b78:      	br	x16
     b7c:      	ret

0000000000000b80 <register_tm_clones>:
     b80:      	adrp	x0, 0x20000 <data_start>
     b84:      	add	x0, x0, #0x10
     b88:      	adrp	x1, 0x20000 <data_start>
     b8c:      	add	x1, x1, #0x10
     b90:      	sub	x1, x1, x0
     b94:      	lsr	x2, x1, #63
     b98:      	add	x1, x2, x1, asr #3
     b9c:      	asr	x1, x1, #1
     ba0:      	cbz	x1, 0xbb8 <register_tm_clones+0x38>
     ba4:      	adrp	x2, 0x1f000 <__FRAME_END__+0x1e26c>
     ba8:      	ldr	x2, [x2, #0xff8]
     bac:      	cbz	x2, 0xbb8 <register_tm_clones+0x38>
     bb0:      	mov	x16, x2
     bb4:      	br	x16
     bb8:      	ret
     bbc:      	nop

0000000000000bc0 <__do_global_dtors_aux>:
     bc0:      	paciasp
     bc4:      	stp	x29, x30, [sp, #-0x20]!
     bc8:      	mov	x29, sp
     bcc:      	str	x19, [sp, #0x10]
     bd0:      	adrp	x19, 0x20000 <data_start>
     bd4:      	ldrb	w0, [x19, #0x10]
     bd8:      	tbnz	w0, #0x0, 0xc00 <__do_global_dtors_aux+0x40>
     bdc:      	adrp	x0, 0x1f000 <__FRAME_END__+0x1e26c>
     be0:      	ldr	x0, [x0, #0xfd8]
     be4:      	cbz	x0, 0xbf4 <__do_global_dtors_aux+0x34>
     be8:      	adrp	x0, 0x20000 <data_start>
     bec:      	ldr	x0, [x0, #0x8]
     bf0:      	bl	0x750 <__cxa_finalize@plt>
     bf4:      	bl	0xb50 <deregister_tm_clones>
     bf8:      	mov	w0, #0x1                // =1
     bfc:      	strb	w0, [x19, #0x10]
     c00:      	ldr	x19, [sp, #0x10]
     c04:      	ldp	x29, x30, [sp], #0x20
     c08:      	autiasp
     c0c:      	ret

0000000000000c10 <frame_dummy>:
     c10:      	bti	c
     c14:      	b	0xb80 <register_tm_clones>

Disassembly of section .fini:

0000000000000c18 <_fini>:
     c18:      	nop
     c1c:      	stp	x29, x30, [sp, #-0x10]!
     c20:      	mov	x29, sp
     c24:      	ldp	x29, x30, [sp], #0x10
     c28:      	ret
