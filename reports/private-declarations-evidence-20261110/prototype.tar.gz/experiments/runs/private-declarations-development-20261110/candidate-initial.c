#include <stdint.h>

extern uint32_t next_value(uint32_t value);
extern void record_event(uint32_t value);

uint32_t region_pipeline(uint32_t *buffer, uint32_t x, int limit)
{
    uint32_t y = buffer[0];
    unsigned int csrd_frame_208_0 = ((428335287u * (x)) + 2542628964u); unsigned int csrd_frame_208_1 = ((428335287u * (y)) + 2542628964u); unsigned int csrd_frame_208_2 = (((csrd_frame_208_0) + (csrd_frame_208_1)) - 2542628964u); unsigned int csrd_frame_208_3 = (((((3u * (csrd_frame_208_2)) + 3504676664u)) + (2959349825u)) - 2542628964u); csrd_frame_208_0 = (((csrd_frame_208_3) - (csrd_frame_208_1)) + 2542628964u); x = (2171403527u * ((csrd_frame_208_0) - 2542628964u)); register unsigned int sum = (2171403527u * ((csrd_frame_208_2) - 2542628964u)); unsigned int bias = (2171403527u * ((csrd_frame_208_3) - 2542628964u))

;
    record_event(sum);
    if (limit < 0) return x;
    while (limit-- > 0) {
        y = next_value(x);
        {
            unsigned int csrd_frame_420_0 = ((1377831353u * (x)) + 2074855321u); unsigned int csrd_frame_420_1 = ((1377831353u * (y)) + 2074855321u); unsigned int csrd_frame_420_2 = ((1377831353u * (bias)) + 2074855321u); unsigned int csrd_frame_420_3 = ((1377831353u * (sum)) + 2074855321u); csrd_frame_420_0 = (((csrd_frame_420_0) + (csrd_frame_420_1)) - 2074855321u); unsigned int csrd_frame_420_4 = (((csrd_frame_420_2) + (((5u * (csrd_frame_420_1)) + 290513308u))) - 2074855321u); unsigned int csrd_frame_420_5 = (((csrd_frame_420_4) - (csrd_frame_420_1)) + 2074855321u); csrd_frame_420_2 = (((csrd_frame_420_5) + (csrd_frame_420_3)) - 2074855321u); x = (2418486409u * ((csrd_frame_420_0) - 2074855321u)); bias = (2418486409u * ((csrd_frame_420_2) - 2074855321u)); unsigned int x = (2418486409u * ((csrd_frame_420_4) - 2074855321u)); unsigned int local = (2418486409u * ((csrd_frame_420_5) - 2074855321u))


;
            record_event(x);
            { unsigned int csrd_frame_580_0 = ((501859349u * (x)) + 2081414684u); csrd_frame_580_0 = (((csrd_frame_580_0) + (1299462831u)) - 2081414684u); x = (3914984253u * ((csrd_frame_580_0) - 2081414684u));}
            buffer[0] = x;
        }
        { unsigned int csrd_frame_637_0 = ((1367280105u * (x)) + 4125332493u); unsigned int csrd_frame_637_1 = ((1367280105u * (bias)) + 4125332493u); csrd_frame_637_0 = (((csrd_frame_637_0) + (csrd_frame_637_1)) - 4125332493u); x = (711089753u * ((csrd_frame_637_0) - 4125332493u));}
        record_event(y);
    }
    return x;
}

int region_outputs(uint32_t *buffer, uint32_t x, uint32_t y)
{
    unsigned int csrd_frame_766_0 = ((3806782871u * (x)) + 223765317u); unsigned int csrd_frame_766_1 = ((3806782871u * (y)) + 223765317u); unsigned int csrd_frame_766_2 = 514564684u; unsigned int csrd_frame_766_3 = (((csrd_frame_766_2) + (csrd_frame_766_0)) - 223765317u); csrd_frame_766_0 = (((((3u * (csrd_frame_766_3)) + 3847436662u)) + (csrd_frame_766_1)) - 223765317u); csrd_frame_766_1 = (((csrd_frame_766_0) - (csrd_frame_766_2)) + 223765317u); x = (2342644263u * ((csrd_frame_766_0) - 223765317u)); y = (2342644263u * ((csrd_frame_766_1) - 223765317u)); register unsigned int pending = (2342644263u * ((csrd_frame_766_2) - 223765317u)); unsigned int mix = (2342644263u * ((csrd_frame_766_3) - 223765317u))


;
    record_event(x);
    {
        unsigned int csrd_frame_909_0 = ((1915923793u * (x)) + 383732809u); unsigned int csrd_frame_909_1 = (((csrd_frame_909_0) + (910297472u)) - 383732809u); unsigned int y = (2577185713u * ((csrd_frame_909_1) - 383732809u));
        buffer[2] = y;
    }
    buffer[0] = y;
    buffer[1] = pending;
    return x == y;
}
